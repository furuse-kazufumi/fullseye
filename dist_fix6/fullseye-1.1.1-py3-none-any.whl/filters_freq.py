"""周波数領域/畳み込み/復元フィルタ(HALCON "Filters" chapter の genuine 実装, numpy).

FFT 畳み込み・相関・位相相関・Wiener 復元・調和補間・PSF 生成・Gabor エネルギー。
image = 2D float64。
"""
from __future__ import annotations

import numpy as np


def _img(a):
    return np.asarray(a, dtype=np.float64)


def convol_fft(image, filter_mask):
    """FFT による線形畳み込み(convol_fft/convol_image)。"""
    from scipy.signal import fftconvolve
    return fftconvolve(_img(image), _img(filter_mask), mode="same")


def convol_image(image, filter_mask):
    """空間畳み込み(convol_image)。"""
    from scipy.ndimage import convolve
    return convolve(_img(image), _img(filter_mask), mode="reflect")


def correlation_fft(image1, image2):
    """FFT による相互相関(correlation_fft)。"""
    a = _img(image1); b = _img(image2)
    F = np.fft.rfft2(a); G = np.fft.rfft2(b, s=a.shape)
    return np.fft.irfft2(F * np.conj(G), s=a.shape)


def phase_correlation_fft(image1, image2, window: str | None = "hann", whitening: float = 0.5):
    """位相相関で並進 (drow, dcol) を推定(phase_correlation_fft)。返りは image1 の image2 に対するずれ(整数画素)。

    相互パワースペクトル R = F·conj(G) を |R|^``whitening`` で割ってから逆変換し、最大の位置を読む。
    ``whitening`` = 1 は古典的な位相相関(全白色化)、0 は素の相互相関、既定 0.5 はその間。``window = "hann"``(既定)は
    平均を引いて 2 次元の Hann 窓を掛けてから変換する、``None`` は掛けない。

    ★既定を替えた理由(2026-10-06): 0.4.0 までの「窓なし + 全白色化」は、帯域の限られた像(地面・自然な写真のように
    高い周波数にほとんど信号の無い像)を **周期的でない切り出し** で比べると、信号の無い周波数のビン(切り出しの縁の
    不連続の漏れと丸め)が白色化で信号のあるビンと同じ重みになり、正しいずれでなく 0 の近く(例: 真 (−2, −5) に (1, 0))を
    返した。np.roll の周期的なずれでは厳密だったので、それだけの門では見えなかった。場面 6 種 × 60 通りのずれ(64 × 64)で、
    旧の既定は帯域の限られた切り出し 0 %・低域の切り出し 0 % の当たり、新しい既定はどの場面も 100 %(周期的なずれも 100 %)。
    窓だけでは直らない(白色化が主因)。旧の挙動は ``window=None, whitening=1.0``。
    **符号**: ``image2 = np.roll(image1, (dr, dc))`` のとき ``(row_shift, col_shift) = (−dr, −dc)``(image1 を image2 に
    重ねるのに要る移動)。``residue.crt_displacement(image0, image1)`` は**逆向き**(image0 から image1 への移動 ``+d``)
    なので、2 つを取り替えるときは符号を反転すること(``tests/test_displacement_sign_conventions.py`` が両方を固定)。
    **Raises** ValueError: 形が違う・2 次元でない、window の綴り違い、whitening が [0, 1] の外。"""
    a = _img(image1); b = _img(image2)
    if a.ndim != 2 or a.shape != b.shape:
        raise ValueError("phase_correlation_fft: image1 and image2 must be 2-D arrays of the same shape, got %s and %s" % (a.shape, b.shape))
    if window not in ("hann", None):
        raise ValueError("phase_correlation_fft: window must be 'hann' or None, got %r" % (window,))
    w = float(whitening) if not isinstance(whitening, bool) else float("nan")
    if not (0.0 <= w <= 1.0):
        raise ValueError("phase_correlation_fft: whitening must be in [0, 1], got %r" % (whitening,))
    if window == "hann":
        win = np.outer(np.hanning(a.shape[0]), np.hanning(a.shape[1]))
        a = (a - a.mean()) * win
        b = (b - b.mean()) * win
    F = np.fft.fft2(a); G = np.fft.fft2(b)
    R = F * np.conj(G)
    if w > 0.0:
        R /= np.abs(R) ** w + 1e-12
    corr = np.fft.ifft2(R).real
    pk = np.unravel_index(np.argmax(corr), corr.shape)
    dr = pk[0] - (a.shape[0] if pk[0] > a.shape[0] // 2 else 0)
    dc = pk[1] - (a.shape[1] if pk[1] > a.shape[1] // 2 else 0)
    return {"row_shift": float(dr), "col_shift": float(dc),
            "peak": float(corr[pk]), "correlation": corr, "window": window, "whitening": w}


def phase_correlation_shift(image1, image2, window: str | None = "hann",
                            whitening: float = 0.5,
                            method: str = "upsample",
                            upsample_factor: int = 100) -> dict:
    """2 枚の画像の位置合わせに必要なサブピクセル移動量を位相限定相関で求める。

    The default ``method="upsample"`` refines the whitening-aware periodic
    FFT peak by evaluating a 1.5-pixel neighbourhood with a matrix-multiply
    local DFT using only NumPy (``upsample_factor=100`` by default).
    ``method="parabola"`` is faster, but its wrapped three-point parabola is
    biased about 0.166 px toward the integer grid. On the fixed 96x112 truth
    gates, parabola errors are 0.166 px (Hann) / 0.172 px (no window), versus
    0.010 px for upsampling with either window; upsampling is required to stay
    within 0.02 px and within 0.01 px of scikit-image when it is installed.
    The local DFT follows Guizar-Sicairos, Thurman & Fienup (2008), Optics
    Letters 33(2), 156-158, doi:10.1364/OL.33.000156. The sign convention is explicit: when
    ``image2 = shift(image1, d)``, the result is approximately ``-d``, so
    ``shift(image2, result)`` approximately equals ``image1``.
    Returns ``row_shift``/``col_shift`` (also ``dy``/``dx``), ``peak`` and
    ``peak_ratio`` (largest peak divided by the best peak outside its 3x3
    neighbourhood). Constant or relatively textureless inputs raise ``ValueError``.
    """
    a = _img(image1); b = _img(image2)
    if (a.ndim == 2 and b.ndim == 2
            and (not np.all(np.isfinite(a)) or not np.all(np.isfinite(b)))):
        raise ValueError("phase_correlation_shift: images must contain only finite values")
    if method not in ("parabola", "upsample"):
        raise ValueError("phase_correlation_shift: method must be 'parabola' or 'upsample'")
    if isinstance(upsample_factor, bool) or not isinstance(upsample_factor, (int, np.integer)) or upsample_factor < 1:
        raise ValueError("phase_correlation_shift: upsample_factor must be a positive integer")
    def _relative_texture(im):
        scale = abs(float(np.mean(im))) + float(np.ptp(im))
        return 0.0 if scale == 0.0 else float(np.std(im)) / scale
    if a.ndim == 2 and (_relative_texture(a) <= 1e-12
                        or _relative_texture(b) <= 1e-12):
        raise ValueError("phase_correlation_shift: images have no usable texture")
    base = phase_correlation_fft(a, b, window=window, whitening=whitening)
    corr = base["correlation"]
    iy, ix = np.unravel_index(np.argmax(corr), corr.shape)
    if method == "parabola":
        def _offset(vm, v0, vp):
            denom = vm - 2.0 * v0 + vp
            if denom == 0.0 or not np.isfinite(denom):
                return 0.0
            return float(np.clip(0.5 * (vm - vp) / denom, -0.5, 0.5))
        dy = float(base["row_shift"] + _offset(corr[(iy - 1) % corr.shape[0], ix],
                                                    corr[iy, ix], corr[(iy + 1) % corr.shape[0], ix]))
        dx = float(base["col_shift"] + _offset(corr[iy, (ix - 1) % corr.shape[1]],
                                                    corr[iy, ix], corr[iy, (ix + 1) % corr.shape[1]]))
    else:
        factor = int(upsample_factor)
        shifts = np.array([base["row_shift"], base["col_shift"]], dtype=float)
        if factor > 1:
            shifts = np.round(shifts * factor) / factor
            region_size = int(np.ceil(1.5 * factor))
            dftshift = np.fix(region_size / 2.0)
            offsets = dftshift - shifts * factor
            aa, bb = a, b
            if window == "hann":
                win = np.outer(np.hanning(a.shape[0]), np.hanning(a.shape[1]))
                aa, bb = (a - a.mean()) * win, (b - b.mean()) * win
            spectrum = np.fft.fft2(aa) * np.conj(np.fft.fft2(bb))
            if base["whitening"] > 0.0:
                spectrum /= np.abs(spectrum) ** base["whitening"] + 1e-12

            # Each axis is a dense DFT matrix; no padded full-frame FFT is made.
            data = spectrum.conj()
            for n_items, offset in reversed(list(zip(data.shape, offsets))):
                kernel = ((np.arange(region_size)[:, None] - offset)
                          * np.fft.fftfreq(n_items, d=factor))
                data = np.tensordot(np.exp(-2j * np.pi * kernel), data,
                                    axes=(1, -1))
            local_corr = data.conj()
            maxima = np.array(np.unravel_index(np.argmax(np.abs(local_corr)),
                                               local_corr.shape), dtype=float)
            shifts += (maxima - dftshift) / factor
        dy, dx = map(float, shifts)
    masked = corr.copy()
    for yy in ((iy - 1) % corr.shape[0], iy, (iy + 1) % corr.shape[0]):
        for xx in ((ix - 1) % corr.shape[1], ix, (ix + 1) % corr.shape[1]):
            masked[yy, xx] = -np.inf
    second = float(np.max(masked))
    ratio = float(base["peak"] / max(second, np.finfo(float).eps))
    return {"row_shift": dy, "col_shift": dx, "dy": dy, "dx": dx,
            "peak": base["peak"], "peak_ratio": ratio,
            "window": window, "whitening": base["whitening"], "method": method}


def gen_gauss_filter(sigma=1.0, size=None):
    """正規化 2D ガウスフィルタマスク(gen_gauss_filter)。"""
    s = float(sigma)
    n = int(size) if size else int(2 * np.ceil(3 * s) + 1)
    ax = np.arange(n) - (n - 1) / 2
    g = np.exp(-(ax[:, None] ** 2 + ax[None, :] ** 2) / (2 * s * s))
    return g / g.sum()


def gen_mean_filter(size=3):
    """平均(box)フィルタマスク(gen_mean_filter)。"""
    n = int(size)
    return np.ones((n, n)) / (n * n)


def gen_filter_mask(coeffs):
    """任意係数のフィルタマスクを生成(gen_filter_mask)。"""
    return _img(coeffs)


def gen_psf_motion(length=9, angle=0.0):
    """直線ブラー(モーション)PSF(gen_psf_motion)。"""
    L = int(length)
    psf = np.zeros((L, L))
    a = np.deg2rad(angle)
    c = (L - 1) / 2
    for t in np.linspace(-c, c, L * 4):
        r = int(round(c - t * np.sin(a))); col = int(round(c + t * np.cos(a)))
        if 0 <= r < L and 0 <= col < L:
            psf[r, col] = 1.0
    s = psf.sum()
    return psf / s if s > 0 else psf


def gen_psf_defocus(radius=3):
    """円形ボケ(デフォーカス)PSF(gen_psf_defocus)。"""
    r = int(radius); n = 2 * r + 1
    yy, xx = np.mgrid[-r:r + 1, -r:r + 1]
    psf = (xx * xx + yy * yy <= r * r).astype(float)
    return psf / psf.sum()


def gen_savitzky_golay_filter(size=5, order=2, deriv=0):
    """Savitzky-Golay 平滑/微分 1D フィルタ係数(gen_savitzky_golay_filter)。"""
    from scipy.signal import savgol_coeffs
    return savgol_coeffs(int(size), int(order), deriv=int(deriv))


def wiener_filter(image, psf, noise=0.01):
    """Wiener デコンボリューション(wiener_filter)。"""
    im = _img(image); h = _img(psf)
    H = np.fft.fft2(h, s=im.shape)
    row_phase = np.exp(-2j * np.pi * np.fft.fftfreq(im.shape[0]) * ((h.shape[0] - 1) / 2))
    col_phase = np.exp(-2j * np.pi * np.fft.fftfreq(im.shape[1]) * ((h.shape[1] - 1) / 2))
    H *= row_phase[:, None]
    H *= col_phase[None, :]
    Hn = H
    G = np.fft.fft2(im)
    W = np.conj(Hn) / (np.abs(Hn) ** 2 + float(noise))
    return np.fft.ifft2(G * W).real


def harmonic_interpolation(image, region):
    """穴(region=True)を Laplace 方程式(調和関数)で埋める(harmonic_interpolation)。"""
    im = _img(image).copy(); m = np.asarray(region, bool)
    for _ in range(500):
        avg = 0.25 * (np.roll(im, 1, 0) + np.roll(im, -1, 0)
                      + np.roll(im, 1, 1) + np.roll(im, -1, 1))
        new = np.where(m, avg, im)
        if np.abs(new - im)[m].max() < 1e-6:
            im = new; break
        im = new
    return im



def vector_field_length(vfield_row, vfield_col):
    """ベクトル場の各点の大きさ(vector_field_length)。"""
    return np.hypot(_img(vfield_row), _img(vfield_col))


def energy_gabor(image_real, image_imag):
    """Gabor 実/虚応答からエネルギー(振幅二乗)(energy_gabor)。"""
    return _img(image_real) ** 2 + _img(image_imag) ** 2


def gauss_distribution(sigma, n=256):
    """正規分布の確率密度テーブル(gauss_distribution)。ノイズモデル用。"""
    x = np.linspace(-4 * sigma, 4 * sigma, int(n))
    return np.exp(-x ** 2 / (2 * sigma ** 2)) / (np.sqrt(2 * np.pi) * sigma)


def sp_distribution(p_salt=0.05, p_pepper=0.05, n=256):
    """salt-and-pepper ノイズ分布(両端に質量、中央一様)(sp_distribution)。"""
    d = np.full(int(n), (1 - p_salt - p_pepper) / max(1, n - 2))
    d[0] = p_pepper; d[-1] = p_salt
    return d


def noise_distribution_mean(images):
    """複数観測から画素ごとノイズ標準偏差の平均を推定(noise_distribution_mean)。"""
    stack = np.stack([np.asarray(im, float) for im in images], axis=0)
    return float(stack.std(axis=0).mean())
