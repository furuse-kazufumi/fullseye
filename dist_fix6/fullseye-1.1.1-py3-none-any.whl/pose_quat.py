"""ポーズ/四元数演算(HALCON "Transformations" chapter の genuine 実装, numpy).

四元数 q=[w,x,y,z]、ポーズ pose=[tx,ty,tz, rx,ry,rz(rad)]、二重四元数 dq=[qr(4),qd(4)]。
剛体変換の各表現間の変換・合成・逆・補間。純粋な代数=曖昧さのない genuine 実装。
"""
from __future__ import annotations

import numpy as np


def _q(a):
    return np.asarray(a, dtype=np.float64)


def _unit(v, what, hint):
    """向きを持つベクトルを厳密に単位化する。長さ 0 なら **拒否**する。

    2026-09-01 の敵対監査で、ここが `norm + 1e-12` で割っていたために 2 通りの
    無言の誤りが起きていた:

      * **零ベクトルが通ってしまう。** ``quat_normalize([0,0,0,0])`` は
        ``[0,0,0,0]`` を返し、それを ``quat_to_hom_mat3d`` に渡すと**単位行列**
        になる ―― 「回転が定義できない」が「回転しない」に化ける。
        ``axis_angle_to_quat(0,0,0,1.0)`` も同様に、軸を持たない回転要求が
        ノルム 0.878 の非単位四元数(= 再正規化後は恒等)になっていた。
      * **正しい入力まで系統的に縮む。** 分母に 1e-12 を足すと商のノルムが
        1 をわずかに下回るので、そこから作った回転行列は直交から外れる
        (実測 |RᵀR − I| = 4.0e-12)。丸め誤差ではなく一方向の縮みで、
        合成を重ねるほど溜まる。

    したがって「長さ 0 は拒否、それ以外は厳密に割る」に直した。
    """
    n = float(np.linalg.norm(v))
    if not np.isfinite(n):
        raise ValueError("%s must be finite (got norm %r)" % (what, n))
    if n == 0.0:
        raise ValueError("%s has zero length, so %s — pass a non-zero vector"
                         % (what, hint))
    return v / n


# ── 四元数 ─────────────────────────────────────────────────────────────────── #
def axis_angle_to_quat(ax, ay, az, angle):
    """回転軸 ``(ax, ay, az)`` と回転角 ``angle``(ラジアン)から単位四元数 ``(w, x, y, z)`` を作る。

    軸は内部で単位化する(長さは問わない)。``w = cos(angle/2)``、``(x, y, z) = 軸 · sin(angle/2)``。
    右手系で、軸の正の向きから見て反時計回りが正の角。**Raises** ``ValueError``: 軸の長さが 0 / 非有限。
    """
    n = _unit(np.array([ax, ay, az], float), "the rotation axis (ax, ay, az)",
              "there is no rotation to describe")
    return np.concatenate([[np.cos(angle / 2)], n * np.sin(angle / 2)])


def quat_normalize(q):
    """四元数 ``(w, x, y, z)`` を長さ 1 に正規化して返す(回転を表す形にする)。

    長さで厳密に割る(微小量を足して縮ませない)。**Raises** ``ValueError``: 長さ 0 / 非有限
    (回転を表さないものを「回転しない」に化けさせない)。
    """
    return _unit(_q(q), "the quaternion",
                 "it denotes no rotation (a rotor must have unit length)")


def quat_conjugate(q):
    """四元数 ``(w, x, y, z)`` の共役 ``(w, −x, −y, −z)`` を返す(単位四元数なら逆回転)。

    四元数は ``(w, x, y, z)``(スカラー部が先頭)、積は Hamilton 積。
    """
    q = _q(q)
    return np.array([q[0], -q[1], -q[2], -q[3]])


def quat_compose(q1, q2):
    """2 つの四元数の Hamilton 積 ``q1 ⊗ q2`` を返す(回転の合成: 先に q2、次に q1)。

    四元数は ``(w, x, y, z)``(スカラー部が先頭)、積は Hamilton 積。 点への作用は ``q p q*`` なので、
    ``quat_compose(q1, q2)`` は「q2 で回してから q1 で回す」回転になる。正規化はしない。
    """
    w1, x1, y1, z1 = _q(q1)
    w2, x2, y2, z2 = _q(q2)
    return np.array([
        w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2,
        w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
        w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2,
        w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2])


def quat_to_hom_mat3d(q):
    """四元数 ``(w, x, y, z)`` を 4×4 同次変換行列(回転のみ、並進 0)に変換する。

    入力は先に :func:`quat_normalize` で単位化する。行列は列ベクトルに左から掛ける規約
    (``p' = R p``)で、:func:`quat_rotate_point_3d` と同じ回転を表す。
    """
    w, x, y, z = quat_normalize(q)
    R = np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
                  [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
                  [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)]])
    H = np.eye(4)
    H[:3, :3] = R
    return H


def quat_rotate_point_3d(q, px, py, pz):
    """四元数 ``q = (w, x, y, z)`` で 3-D 点 ``(px, py, pz)`` を回転し、``(3,)`` 配列で返す。

    ``q p q*``(``p`` は純四元数 ``(0, px, py, pz)``)で計算する能動回転(同じ座標系の中で点を回す)。
    ``q`` は単位四元数を渡すこと(正規化はしない —— 長さ s の四元数は点を s² 倍に伸ばす)。
    """
    qp = np.concatenate([[0.0], [px, py, pz]])
    r = quat_compose(quat_compose(q, qp), quat_conjugate(q))
    return r[1:]


def quat_interpolate(q1, q2, t=0.5):
    """2 つの回転(四元数 ``(w, x, y, z)``)の間を球面線形補間(slerp)する。

    ``t = 0`` で ``q1``、``t = 1`` で ``q2``。両方を単位化し、内積が負なら ``q2`` の符号を反転して
    短い方の弧を通る。ほぼ同じ回転(内積 > 0.9995)は線形補間 + 正規化に切り替える。
    """
    q1, q2 = quat_normalize(q1), quat_normalize(q2)
    d = float(np.dot(q1, q2))
    if d < 0:
        q2, d = -q2, -d
    if d > 0.9995:
        return quat_normalize(q1 + t * (q2 - q1))
    th = np.arccos(np.clip(d, -1, 1))
    return (np.sin((1 - t) * th) * q1 + np.sin(t * th) * q2) / np.sin(th)


def _mat_to_quat(R):
    tr = np.trace(R)
    if tr > 0:
        s = np.sqrt(tr + 1.0) * 2
        w = 0.25 * s
        x = (R[2, 1] - R[1, 2]) / s
        y = (R[0, 2] - R[2, 0]) / s
        z = (R[1, 0] - R[0, 1]) / s
    else:
        i = int(np.argmax(np.diag(R)))
        j, k = (i + 1) % 3, (i + 2) % 3
        s = np.sqrt(R[i, i] - R[j, j] - R[k, k] + 1.0) * 2
        q = np.zeros(4)
        q[0] = (R[k, j] - R[j, k]) / s
        q[i + 1] = 0.25 * s
        q[j + 1] = (R[j, i] + R[i, j]) / s
        q[k + 1] = (R[k, i] + R[i, k]) / s
        return quat_normalize(q)
    return quat_normalize(np.array([w, x, y, z]))


# ── pose = [tx,ty,tz, rx,ry,rz] ────────────────────────────────────────────── #
def _as_pose(pose, fn="pose"):
    """pose を 6/7 要素ベクトル ``(tx, ty, tz, rx, ry, rz[, type])`` に揃える。

    ★2026-09-19(GenSpark 第 14 報 D-1): ``pose_to_hom_mat3d_local`` が返す 4×4 を ``pose_to_quat`` に
    戻すと ``_pose_to_R`` の ``pose[4]`` で IndexError(4×4 の 5 行目を引く)—— **自分の出力を自分で
    受けられず**、文は深い位置の添字エラーで原因が読めなかった。4×4 / 3×3 は行列として受け(回転部と
    並進を ``hom_mat3d_to_pose_local`` で戻す)、それ以外の形は何が要るかを言って断る。
    """
    try:
        p = np.asarray(pose, dtype=float)
    except (TypeError, ValueError):
        raise ValueError("%s: pose must be a 6/7-vector (tx, ty, tz, rx, ry, rz[, type]) or a 3x3 / 4x4 matrix, "
                         "got %s" % (fn, type(pose).__name__)) from None
    if p.shape == (4, 4):
        return hom_mat3d_to_pose_local(p)
    if p.shape == (3, 3):
        H = np.eye(4)
        H[:3, :3] = p
        return hom_mat3d_to_pose_local(H)
    if p.ndim == 1 and p.size in (6, 7):
        return p
    raise ValueError("%s: pose must be a 6/7-vector (tx, ty, tz, rx, ry, rz[, type]) or a 3x3 / 4x4 matrix, "
                     "got shape %s" % (fn, p.shape))


def _pose_to_R(pose):
    pose = _as_pose(pose, "_pose_to_R")
    rx, ry, rz = pose[3], pose[4], pose[5]
    cx, sx = np.cos(rx), np.sin(rx)
    cy, sy = np.cos(ry), np.sin(ry)
    cz, sz = np.cos(rz), np.sin(rz)
    Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
    Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    return Rz @ Ry @ Rx


def _R_to_euler(R):
    # ★2026-10-07 レビュー修正: ry = ±90°(ジンバルロック)では R[2,1], R[2,2], R[1,0], R[0,0] が
    # どれも丸め屑になり、rx, rz を屑の atan2 で決めていた(ry=90° ちょうどで行列の往復誤差 0.16)。
    # cos(ry) = hypot(R[0,0], R[1,0]) が √ε 未満なら rx と rz は和/差しか決まらないので rx = 0 に
    # 固定し、rz を残りの成分から取る(R[0,1] = −sin rz, R[1,1] = cos rz が ±90° の両方で成り立つ)。
    cy = float(np.hypot(R[0, 0], R[1, 0]))
    ry = np.arctan2(-R[2, 0], cy)
    if cy < np.sqrt(np.finfo(float).eps):
        rx = 0.0
        rz = np.arctan2(-R[0, 1], R[1, 1])
    else:
        rx = np.arctan2(R[2, 1], R[2, 2])
        rz = np.arctan2(R[1, 0], R[0, 0])
    return rx, ry, rz


def create_pose(tx=0.0, ty=0.0, tz=0.0, rx=0.0, ry=0.0, rz=0.0):
    """並進 ``(tx, ty, tz)`` と回転角 ``(rx, ry, rz)``(ラジアン)から pose の 6 要素ベクトルを作る。

    回転は ``R = Rz(rz) · Ry(ry) · Rx(rx)``(:func:`pose_to_hom_mat3d_local`)、点は
    ``p' = R p + t``。並進の単位は呼び手の座標の単位。HALCON の 7 番目の type 要素は付けない。
    """
    return np.array([tx, ty, tz, rx, ry, rz], float)


def pose_to_hom_mat3d_local(pose):
    """HALCON 流の pose ``(tx, ty, tz, rx, ry, rz[, type])`` を 4×4 同次行列に(``Rz·Ry·Rx``、角はラジアン)。
    4×4 / 3×3 を渡すとそのまま行列として通る(``_as_pose``)。"""
    pose = _as_pose(pose, "pose_to_hom_mat3d_local")
    H = np.eye(4)
    H[:3, :3] = _pose_to_R(pose)
    H[:3, 3] = pose[:3]
    return H


def hom_mat3d_to_pose_local(H):
    """4×4 同次変換行列を pose ``(tx, ty, tz, rx, ry, rz)``(角はラジアン)に戻す。

    回転部を ``R = Rz · Ry · Rx`` と分解する(:func:`pose_to_hom_mat3d_local` の逆)。``ry = ±90°``
    (ジンバルロック)では ``rx`` と ``rz`` は和・差しか決まらないので ``rx = 0`` に固定する。
    """
    H = np.asarray(H, float)
    rx, ry, rz = _R_to_euler(H[:3, :3])
    return np.array([H[0, 3], H[1, 3], H[2, 3], rx, ry, rz])


def pose_compose(p1, p2):
    """2 つの pose を合成する: 行列で ``H(p1) · H(p2)``(先に p2、次に p1 を当てる)。

    pose は ``(tx, ty, tz, rx, ry, rz[, type])``(角はラジアン、``R = Rz·Ry·Rx``、``p' = R p + t``)。
    3×3 / 4×4 の行列も受ける。返りは 6 要素の pose。
    """
    return hom_mat3d_to_pose_local(pose_to_hom_mat3d_local(p1) @ pose_to_hom_mat3d_local(p2))


def pose_invert(p):
    """pose の逆変換(``H(p)⁻¹``)を 6 要素の pose で返す。

    ``pose_compose(p, pose_invert(p))`` は恒等(丸め誤差まで)。規約は :func:`pose_compose` と同じ。
    """
    raw = np.asarray(p, dtype=float)
    if raw.shape == (4, 4):
        R = raw[:3, :3]
        rigid = (np.allclose(R.T @ R, np.eye(3), rtol=0.0, atol=1e-9)
                 and abs(float(np.linalg.det(R)) - 1.0) <= 1e-9
                 and np.allclose(raw[3], [0, 0, 0, 1], rtol=0.0, atol=1e-9))
        if not rigid:
            return hom_mat3d_to_pose_local(np.linalg.inv(raw))
        H = raw
    else:
        H = pose_to_hom_mat3d_local(p)
        R = H[:3, :3]
    inv = np.eye(4)
    inv[:3, :3] = R.T
    inv[:3, 3] = -(R.T @ H[:3, 3])
    return hom_mat3d_to_pose_local(inv)


def pose_to_quat(pose):
    """pose(6/7 ベクトル、または 3×3 / 4×4 行列)の回転部を単位四元数 ``(w, x, y, z)`` に。"""
    return _mat_to_quat(_pose_to_R(pose))


def quat_to_pose(q, tx=0.0, ty=0.0, tz=0.0):
    """四元数 ``(w, x, y, z)`` の回転と並進 ``(tx, ty, tz)`` から pose ``(tx, ty, tz, rx, ry, rz)`` を作る。

    回転は :func:`quat_to_hom_mat3d` で行列にしてから ``R = Rz·Ry·Rx`` の角(ラジアン)に分解する。
    """
    rx, ry, rz = _R_to_euler(quat_to_hom_mat3d(q)[:3, :3])
    return np.array([tx, ty, tz, rx, ry, rz])


def pose_average(poses):
    """複数の pose の平均(並進は算術平均、回転は四元数の符号を揃えた平均を正規化)を返す。

    ``poses`` は (N, 6) の pose の並び。四元数は最初の 1 つとの内積が負なら符号を反転してから
    平均する(``q`` と ``−q`` は同じ回転なので、揃えないと ±179° の組が恒等に潰れる)。回転が互いに近い
    ときの近似(厳密な回転の平均ではない)。
    """
    poses = np.asarray(poses, float).reshape(-1, 6)
    t = poses[:, :3].mean(0)
    qs = np.array([pose_to_quat(p) for p in poses])
    # ★2026-10-07 レビュー修正: 符号を w の正負で揃えると、w≈0 をまたぐ組(yaw +179° と −179°)が
    # 反対の半球に分かれ、平均が恒等(0°)に潰れた。最初の四元数を基準に、内積が負のものを反転する。
    s = np.sign(qs @ qs[0])
    s[s == 0.0] = 1.0
    qs *= s[:, None]
    qm = quat_normalize(qs.mean(0))
    return quat_to_pose(qm, *t)


def convert_pose_type(pose, order="xyz"):
    """pose の並びを返す(genuine な型変換の簡易版=恒等で type タグを付す)。"""
    return {"pose": np.asarray(pose, float), "type": order}


def get_pose_type(pose):
    """pose の型を返す。この実装の pose は常に ``"point_3d_and_euler_xyz"``(並進 + 角)。

    HALCON の ``get_pose_type`` に合わせた口で、回転の順は ``R = Rz·Ry·Rx``(角はラジアン)。
    引数の中身は見ない(どの pose を渡しても同じ文字列)。
    """
    return "point_3d_and_euler_xyz"


# ── 球面座標 ───────────────────────────────────────────────────────────────── #
def convert_point_3d_cart_to_spher(x, y, z):
    """直交座標の点 ``(x, y, z)`` を球面座標 ``(r, lon, lat)`` に変換する(角はラジアン)。

    ``r = |p|``、経度 ``lon = atan2(y, x)``(x 軸から、z 軸まわりに反時計回り)、緯度
    ``lat = asin(z / r)``(xy 平面から z の正の向きへ)。原点では ``lat = 0``。

    ★2026-11-05(敵対的検証 geometry、未再現の疑いを確認): 以前は ``asin(z / (r + 1e-12))``
    で、極付近は単位スケールでも 1.4e-6 rad ずれ(asin の傾きが 1 で発散)、r = 1e-12 の点は
    緯度 90° が 30° になった。``atan2(z, hypot(x, y))``(同じ量、尺度に依らず正確)で計算する。
    """
    r = np.sqrt(x * x + y * y + z * z)
    lon = np.arctan2(y, x)
    lat = np.arctan2(z, np.hypot(x, y))
    return np.array([r, lon, lat])


def convert_point_3d_spher_to_cart(r, lon, lat):
    """球面座標 ``(r, lon, lat)``(角はラジアン)を直交座標 ``(x, y, z)`` に戻す。

    ``x = r cos(lat) cos(lon)``、``y = r cos(lat) sin(lon)``、``z = r sin(lat)``
    (:func:`convert_point_3d_cart_to_spher` の逆)。
    """
    return np.array([r * np.cos(lat) * np.cos(lon),
                     r * np.cos(lat) * np.sin(lon),
                     r * np.sin(lat)])


# ── 二重四元数 ─────────────────────────────────────────────────────────────── #
def pose_to_dual_quat(pose):
    """pose(6/7 ベクトル、または 3×3 / 4×4 行列)を双対四元数 ``(qr[4], qd[4])`` に(qd = ½·t·qr)。"""
    pose = _as_pose(pose, "pose_to_dual_quat")
    qr = pose_to_quat(pose)
    t = np.concatenate([[0.0], np.asarray(pose[:3], float)])
    qd = 0.5 * quat_compose(t, qr)
    return np.concatenate([qr, qd])


def dual_quat_to_pose(dq):
    """双対四元数 ``(qr[4], qd[4])`` を pose ``(tx, ty, tz, rx, ry, rz)`` に戻す。

    並進は ``t = 2 · qd ⊗ qr*`` のベクトル部、回転は ``qr`` から(:func:`quat_to_pose`)。
    :func:`pose_to_dual_quat` の逆。四元数は ``(w, x, y, z)``。
    """
    dq = _q(dq)
    qr, qd = dq[:4], dq[4:8]
    t = 2 * quat_compose(qd, quat_conjugate(qr))
    return np.concatenate([t[1:], quat_to_pose(qr)[3:]])


def dual_quat_normalize(dq):
    """双対四元数 ``(qr[4], qd[4])`` を実部 ``qr`` の長さで割って正規化する。

    8 成分すべてを ``|qr|`` で割る(``qr`` と ``qd`` の直交条件までは直さない)。
    **Raises** ``ValueError``: ``qr`` の長さが 0 / 非有限(剛体変換を表さない)。
    """
    dq = _q(dq)
    n = float(np.linalg.norm(dq[:4]))
    if n == 0.0 or not np.isfinite(n):
        raise ValueError("the real part of the dual quaternion has zero length, "
                         "so it denotes no rigid motion — pass a non-zero rotor")
    return dq / n


def dual_quat_conjugate(dq):
    """双対四元数 ``(qr, qd)`` の四元数共役 ``(qr*, qd*)`` を返す(単位双対四元数なら逆の剛体変換)。

    実部・双対部それぞれのベクトル部の符号を反転する(双対数としての共役 ``qr − ε qd`` ではない)。
    """
    dq = _q(dq)
    return np.concatenate([quat_conjugate(dq[:4]), quat_conjugate(dq[4:8])])


def dual_quat_trans_point_3d(dq, px, py, pz):
    """双対四元数の剛体変換で 3-D 点 ``(px, py, pz)`` を写し、``(3,)`` 配列で返す。

    ``p' = R p + t``(回転 ``R`` は実部 ``qr``、並進 ``t`` は :func:`dual_quat_to_pose` から)。
    """
    return dual_quat_to_pose(dq)[:3] + quat_rotate_point_3d(_q(dq)[:4], px, py, pz)


def dual_quat_compose(dq1, dq2):
    """二重四元数の合成(剛体変換の合成、dual_quat_compose)。"""
    dq1, dq2 = _q(dq1), _q(dq2)
    qr = quat_compose(dq1[:4], dq2[:4])
    qd = quat_compose(dq1[:4], dq2[4:8]) + quat_compose(dq1[4:8], dq2[:4])
    return np.concatenate([qr, qd])


def dual_quat_interpolate(dq1, dq2, t=0.5):
    """二重四元数の補間(pose 経由で並進 lerp + 回転 slerp、dual_quat_interpolate)。"""
    p1, p2 = dual_quat_to_pose(dq1), dual_quat_to_pose(dq2)
    tt = (1 - t) * p1[:3] + t * p2[:3]
    q = quat_interpolate(pose_to_quat(p1), pose_to_quat(p2), t)
    pose = np.concatenate([tt, quat_to_pose(q)[3:]])
    return pose_to_dual_quat(pose)


def screw_to_dual_quat(lx, ly, lz, mx, my, mz, theta=0.0, d=0.0):
    """スクリュー(軸方向 l, モーメント m, 回転角 theta, 並進 d)を二重四元数へ(screw_to_dual_quat)。"""
    l = _unit(np.array([lx, ly, lz], float), "the screw axis (lx, ly, lz)",
              "there is no screw motion to describe")
    m = np.array([mx, my, mz], float)
    ct, st = np.cos(theta / 2), np.sin(theta / 2)
    qr = np.concatenate([[ct], st * l])
    qd = np.concatenate([[-d / 2 * st], st * m + d / 2 * ct * l])
    return np.concatenate([qr, qd])


def dual_quat_to_screw(dq):
    """二重四元数からスクリュー成分(角度・並進・軸)を返す(dual_quat_to_screw)。"""
    dq = _q(dq)
    qr, qd = dq[:4], dq[4:8]
    # ★2026-11-05(敵対的検証 geometry、未再現の疑いを確認): 以前は θ = 2 acos(w)、
    # sin(θ/2) = sqrt(1 − w²) + 1e-12 で、小さい回転では 1 − w² が桁落ちして 0 になり
    # (θ = 2e-8 で θ → 0、d → 5000、|axis| → 10000)、境界付近は 1e-12 の足し算で軸が縮んだ。
    # sin(θ/2) はベクトル部のノルムそのもの、θ は atan2 で取る(単位四元数で同じ量)。
    sn = float(np.linalg.norm(qr[1:]))
    theta = 2 * np.arctan2(sn, qr[0])
    if sn < 1e-9:
        # ★2026-10-07 レビュー修正: 回転が無い(純並進)と sin(θ/2)=0 で割れず、旧実装は
        # 軸 0・並進 0 を返して並進を丸ごと失った。qr = ±1 なら qd = ±(0, t/2) なので
        # t = 2·sign(w)·qd[1:]、軸 = t/|t|、d = |t|(並進も無ければ軸 0・d 0)。
        tv = 2.0 * np.sign(qr[0] if qr[0] != 0 else 1.0) * qd[1:]
        tn = float(np.linalg.norm(tv))
        axis = tv / tn if tn > 0.0 else np.zeros(3)
        return {"theta": float(theta), "d": tn, "axis": axis}
    st = sn
    l = qr[1:] / st
    d = -2 * qd[0] / st
    return {"theta": float(theta), "d": float(d), "axis": l}
