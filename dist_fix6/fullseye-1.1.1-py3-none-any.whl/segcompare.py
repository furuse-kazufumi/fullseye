# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""Compare two segmentations — contingency, variation of information, Rand indices (numpy only).

Connectomics lives on this question: a neuron segmentation from electron microscopy is
scored against a proofread ground truth by how much it **splits** true objects and how
much it **merges** different ones. The standard measures are all functions of one table,
the contingency table ``n_ij`` (pixels labelled ``i`` in the truth and ``j`` in the
candidate), so every op here builds that table first and reads its answer off it.

Three operators (``labels2d, labels2d -> table``; the arrays may be 2-D or 3-D):

  * :func:`seg_contingency` — the table itself (sparse: the label pairs that co-occur).
  * :func:`seg_variation_of_information` — VOI = H(a|b) + H(b|a) with its two halves named:
    ``split = H(b|a)`` (the candidate cuts true objects) and ``merge = H(a|b)`` (the
    candidate glues different objects). Meila 2007.
  * :func:`seg_rand` — Rand index, adjusted Rand index (Hubert & Arabie 1985) and the
    adapted Rand error of the CREMI / SNEMI challenges (Arganda-Carreras et al. 2015),
    with the pair precision and recall it is made of.

Two more (``labels2d[, labels2d], table -> table``) read the **wiring diagram** a segmentation
implies from synapse annotations (each synapse's pre and post point):

  * :func:`seg_synapse_partners` — which object each synapse end lands in, and the distinct
    (pre object, post object) connections.
  * :func:`seg_wiring_variation` — the same VOI split / merge measured where the wiring is
    read: at the synapse ends, and over synapses grouped by connection.
  * :func:`seg_synapse_nri` — neural reconstruction integrity (Reilly et al. 2018): the F-score
    of pairs of synapse ends kept together, which is exactly ``1 - adapted Rand error`` over
    the ends (checked inside).
  * :func:`seg_wiring_exposure` (``labels2d, table -> table``) — what a cut of (or a hidden merge
    inside) each object can cost in ends-level bits, from its end count alone: the bound
    ``s / 2n``, the worst reachable, and the binomial expectation for evenly spread ends.

``a`` is the ground truth and ``b`` the candidate — the split/merge names depend on it.
``ignore_label`` drops every pixel whose **truth** label equals it (the convention of the
challenges, where 0 marks unlabelled space).

Identities (the tests are built on these): relabelling either input by any permutation
changes nothing; ``VOI(a, a) == 0`` and ``ARI(a, a) == 1``; VOI is a metric (symmetric,
triangle inequality); cutting one true region of ``m`` pixels into two equal halves raises
``split`` by exactly ``m / N`` bits and leaves ``merge`` at 0; the Rand index equals a
brute-force count over all pixel pairs. Second implementations: scikit-image
``variation_of_information`` / ``adapted_rand_error`` and scikit-learn
``adjusted_rand_score`` (pinned in the tests when installed).

Provenance: Meila, *J. Multivariate Anal.* 2007 (VOI); Rand, *JASA* 1971; Hubert & Arabie,
*J. Classif.* 1985 (ARI); Arganda-Carreras et al., *Front. Neuroanat.* 2015 (adapted Rand,
SNEMI3D); the CREMI challenge (cremi.org).
"""
from __future__ import annotations

import math

import numpy as np

MAX_SEG_PIXELS = 500_000_000


def _labels(x, name, op):
    if isinstance(x, (str, bytes)) or np.ma.is_masked(x):
        raise ValueError("%s: %s must be an integer label array" % (op, name))
    a = np.asarray(x)
    if a.dtype.kind == "b":
        a = a.astype(np.int64)
    if a.dtype.kind == "f":
        if not np.isfinite(a).all() or not np.array_equal(a, np.round(a)):
            raise ValueError("%s: %s has non-integer values — labels must be integers" % (op, name))
        a = a.astype(np.int64)
    if a.dtype.kind not in "iu":
        raise ValueError("%s: %s has dtype %s — labels must be integers" % (op, name, a.dtype))
    if a.ndim not in (2, 3):
        raise ValueError("%s: %s must be a 2-D or 3-D label array, got %d-D" % (op, name, a.ndim))
    if a.size == 0:
        raise ValueError("%s: %s is empty" % (op, name))
    if a.size > MAX_SEG_PIXELS:
        raise ValueError("%s: %s has %d pixels, over the %d cap" % (op, name, a.size, MAX_SEG_PIXELS))
    return a


def _table(a, b, ignore_label, op):
    a = _labels(a, "a", op)
    b = _labels(b, "b", op)
    if a.shape != b.shape:
        raise ValueError("%s: a %r and b %r differ in shape" % (op, a.shape, b.shape))
    a, b = a.ravel(), b.ravel()
    if ignore_label is not None:
        keep = a != int(ignore_label)
        a, b = a[keep], b[keep]
        if a.size == 0:
            raise ValueError("%s: every pixel carries ignore_label=%r in the truth" % (op, ignore_label))
    ua, ia = np.unique(a, return_inverse=True)
    ub, ib = np.unique(b, return_inverse=True)
    pair = ia.astype(np.int64) * len(ub) + ib
    up, cnt = np.unique(pair, return_counts=True)
    return ua, ub, up // len(ub), up % len(ub), cnt.astype(np.int64), int(a.size)


def seg_contingency(a, b, ignore_label=None):
    """The contingency table of truth ``a`` against candidate ``b`` (sparse).

    Returns ``labels_a`` / ``labels_b`` (the distinct labels), ``rows`` / ``cols`` (indices
    into them) and ``counts`` for every co-occurring pair, plus ``n`` (pixels counted),
    ``row_sums`` (size of each truth object) and ``col_sums`` (size of each candidate object).
    ``counts.sum() == n``, ``row_sums.sum() == col_sums.sum() == n``.

    **Raises** ``ValueError``: non-integer, non-finite, boolean-free-but-string or masked input;
    not 2-D / 3-D; empty; different shapes; every pixel ignored.
    """
    ua, ub, r, c, cnt, n = _table(a, b, ignore_label, "seg_contingency")
    return {"labels_a": ua, "labels_b": ub, "rows": r, "cols": c, "counts": cnt, "n": n,
            "row_sums": np.bincount(r, weights=cnt, minlength=len(ua)).astype(np.int64),
            "col_sums": np.bincount(c, weights=cnt, minlength=len(ub)).astype(np.int64)}


def _entropy(p):
    p = p[p > 0]
    return float(-(p * np.log2(p)).sum())


def _conditional(cnt, given, n):
    """H(X | Y) in bits from the joint counts ``cnt`` and the counts ``given`` of Y on each cell.

    Summed directly as ``-sum p_xy log2(n_xy / n_y)`` — not ``H(X, Y) - H(Y)``, whose two
    large terms leave ~1e-15 of rounding dust when the answer is exactly 0 (a relabelling).
    A cell with ``n_xy == n_y`` contributes ``log2(1.0) == 0`` exactly.
    """
    cnt = np.asarray(cnt, dtype=np.float64)
    return float(max(-(cnt / n * np.log2(cnt / given)).sum(), 0.0))


def seg_variation_of_information(a, b, ignore_label=None):
    """Variation of information between truth ``a`` and candidate ``b``, in bits.

    Returns ``voi`` = ``split`` + ``merge``, with ``split = H(b|a)`` (how much the candidate
    cuts true objects apart) and ``merge = H(a|b)`` (how much it glues different true objects
    together), plus the entropies ``h_a``, ``h_b`` and the mutual information ``mi``.

    **Raises** ``ValueError``: as :func:`seg_contingency`.
    """
    ua, ub, r, c, cnt, n = _table(a, b, ignore_label, "seg_variation_of_information")
    na = np.bincount(r, weights=cnt, minlength=len(ua))
    nb = np.bincount(c, weights=cnt, minlength=len(ub))
    h_a, h_b = _entropy(na / n), _entropy(nb / n)
    split = _conditional(cnt, na[r], n)      # H(b|a)
    merge = _conditional(cnt, nb[c], n)      # H(a|b)
    return {"voi": split + merge, "split": split, "merge": merge,
            "h_a": h_a, "h_b": h_b, "mi": max(h_a - merge, 0.0), "n": n}


def seg_rand(a, b, ignore_label=None):
    """Rand index, adjusted Rand index and the adapted Rand error (CREMI / SNEMI).

    With ``n_ij`` the contingency table, ``a_i`` / ``b_j`` its row and column sums and ``N``
    the pixel count:

      * ``rand_index`` = fraction of pixel pairs on which the two agree (same/different);
      * ``adjusted_rand_index`` = Hubert & Arabie's chance-corrected version (1 = identical,
        about 0 = independent);
      * ``adapted_rand_error`` = 1 - F over **pairs of distinct pixels**: pair ``precision`` =
        (sum n_ij^2 - N) / (sum b_j^2 - N) — of the pairs the candidate puts together, the
        fraction the truth also puts together — and ``recall`` = (sum n_ij^2 - N) /
        (sum a_i^2 - N) (Arganda-Carreras et al. 2015). The ``- N`` removes each pixel's pair
        with itself. scikit-image's ``adapted_rand_error`` returns the same error, but its
        ``precision`` is divided by the **truth** pairs (its code sums the rows of the
        truth-by-test table), i.e. it is this ``recall``; its docstring says otherwise.

    **Raises** ``ValueError``: as :func:`seg_contingency`; fewer than 2 counted pixels.
    """
    op = "seg_rand"
    ua, ub, r, c, cnt, n = _table(a, b, ignore_label, op)
    if n < 2:
        raise ValueError("%s: need at least 2 pixels to form a pair" % op)
    ai = np.bincount(r, weights=cnt, minlength=len(ua))
    bj = np.bincount(c, weights=cnt, minlength=len(ub))
    cnt = cnt.astype(np.float64)

    def pairs(x):
        return float((x * (x - 1) / 2.0).sum())

    s_ij, s_a, s_b = pairs(cnt), pairs(ai), pairs(bj)
    total = n * (n - 1) / 2.0
    agree = total + 2.0 * s_ij - s_a - s_b
    expected = s_a * s_b / total
    denom = 0.5 * (s_a + s_b) - expected
    ari = 1.0 if denom == 0 else (s_ij - expected) / denom
    sq_ij = float((cnt ** 2).sum()) - n          # ordered pairs of distinct pixels, same in both
    sq_a = float((ai ** 2).sum()) - n            # ... same in the truth
    sq_b = float((bj ** 2).sum()) - n            # ... same in the candidate
    precision = sq_ij / sq_b if sq_b > 0 else 1.0
    recall = sq_ij / sq_a if sq_a > 0 else 1.0
    are = 1.0 - (2.0 * precision * recall / (precision + recall) if precision + recall > 0 else 0.0)
    return {"rand_index": agree / total, "adjusted_rand_index": float(ari),
            "adapted_rand_error": float(are), "precision": precision, "recall": recall, "n": n}


# --------------------------------------------------------------------------- wiring
# A connectome is read off a segmentation: each synapse is a (pre, post) pair of points,
# and the connection it belongs to is (object under pre, object under post). So every
# split or merge of the segmentation turns into an error of the wiring diagram — and the
# same VOI, taken over synapses grouped by connection, says which kind.


def _points(p, name, op, ndim):
    if isinstance(p, (str, bytes)):
        raise ValueError("%s: %s must be an (n, %d) array of coordinates" % (op, name, ndim))
    arr = np.asarray(p, dtype=np.float64)
    if arr.ndim != 2 or arr.shape[1] != ndim or arr.shape[0] == 0:
        raise ValueError("%s: %s must be a non-empty (n, %d) array, got shape %r" % (op, name, ndim, arr.shape))
    if not np.isfinite(arr).all():
        raise ValueError("%s: %s has non-finite coordinates" % (op, name))
    return arr


def _lookup(labels, pts, spacing, name, op):
    q = pts / spacing
    # ★2026-10-07: 43*0.1/0.1 = 42.99999999999999 → floor で 1 voxel 手前に落ちた(spacing 0.1 で 1000 個中 47 個)。
    #   整数のごく近く(相対 1e-9)は整数に寄せてから floor
    q_int = np.rint(q)
    q = np.where(np.abs(q - q_int) < 1e-9 * np.maximum(1.0, np.abs(q)), q_int, q)
    idx = np.floor(q).astype(np.int64)
    bad = (idx < 0) | (idx >= np.asarray(labels.shape))
    if bad.any():
        i = int(np.nonzero(bad.any(axis=1))[0][0])
        raise ValueError("%s: %s point %d at %r falls outside the volume" % (op, name, i, pts[i].tolist()))
    return labels[tuple(idx.T)]


def _split_synapses(synapses, op):
    """``{"pre": (n, d), "post": (n, d)}`` or an ``(n, 2, d)`` array -> (pre, post)."""
    if isinstance(synapses, dict):
        if "pre" not in synapses or "post" not in synapses:
            raise ValueError("%s: synapses must have 'pre' and 'post' columns, got %r" % (op, sorted(synapses)))
        return synapses["pre"], synapses["post"]
    if isinstance(synapses, (str, bytes)):
        raise ValueError("%s: synapses must be a table {'pre', 'post'} or an (n, 2, d) array" % op)
    arr = np.asarray(synapses, dtype=np.float64)
    if arr.ndim != 3 or arr.shape[1] != 2:
        raise ValueError("%s: synapses must be a table {'pre', 'post'} or an (n, 2, d) array, got shape %r"
                         % (op, arr.shape))
    return arr[:, 0], arr[:, 1]


def _synapse_ids(labels, synapses, spacing, name, op):
    lab = _labels(labels, name, op)
    pre, post = _split_synapses(synapses, op)
    pre = _points(pre, "pre", op, lab.ndim)
    post = _points(post, "post", op, lab.ndim)
    if len(pre) != len(post):
        raise ValueError("%s: pre has %d points but post has %d" % (op, len(pre), len(post)))
    sp = np.ones(lab.ndim) if spacing is None else np.asarray(spacing, dtype=np.float64).ravel()
    if sp.shape != (lab.ndim,) or not np.isfinite(sp).all() or (sp <= 0).any():
        raise ValueError("%s: spacing must be %d positive numbers, got %r" % (op, lab.ndim, spacing))
    return (_lookup(lab, pre, sp, "pre", op).astype(np.int64),
            _lookup(lab, post, sp, "post", op).astype(np.int64))


def _codes(u, v):
    """Group synapses by their (pre object, post object) pair; returns a connection index per synapse."""
    pair = np.stack([u, v], axis=1)
    edges, inv, cnt = np.unique(pair, axis=0, return_inverse=True, return_counts=True)
    return edges, inv.ravel(), cnt


def seg_synapse_partners(labels, synapses, spacing=None, background=0):
    """Read the wiring diagram a segmentation implies: which object each synapse connects.

    ``synapses`` is a table ``{"pre": (n, ndim), "post": (n, ndim)}`` (or an ``(n, 2, ndim)``
    array) holding the two ends of ``n`` synapses in physical units (divided by ``spacing`` per axis, default 1, then floored to a voxel).
    Returns ``pre_ids`` / ``post_ids`` (the object under each end), ``connection`` (index
    of each synapse's connection in ``edges``), ``edges`` (``(k, 2)`` distinct
    (pre object, post object) pairs), ``synapses_per_edge``, ``n_background`` (synapses
    with an end on ``background``) and ``n_autapse`` (both ends in the same non-background
    object — a merge, or a real autapse).

    **Raises** ``ValueError``: bad labels (as :func:`seg_contingency`); ``synapses`` not a
    table with ``pre`` / ``post`` nor an ``(n, 2, ndim)`` array; points not ``(n, ndim)``, non-finite, of different counts or outside the volume; bad spacing.
    """
    op = "seg_synapse_partners"
    u, v = _synapse_ids(labels, synapses, spacing, "labels", op)
    edges, conn, cnt = _codes(u, v)
    bg = int(background)
    return {"pre_ids": u, "post_ids": v, "connection": conn, "edges": edges,
            "synapses_per_edge": cnt.astype(np.int64),
            "n_background": int(((u == bg) | (v == bg)).sum()),
            "n_autapse": int(((u == v) & (u != bg)).sum()), "n": int(len(u))}


def _voi_codes(ca, cb):
    """split = H(cb|ca), merge = H(ca|cb) for two integer codings of the same items."""
    n = len(ca)
    _, ia = np.unique(ca, return_inverse=True)
    _, ib = np.unique(cb, return_inverse=True)
    ia, ib = ia.ravel().astype(np.int64), ib.ravel().astype(np.int64)
    up, pc = np.unique(ia * (int(ib.max()) + 1) + ib, return_counts=True)
    r, c = up // (int(ib.max()) + 1), up % (int(ib.max()) + 1)
    split = _conditional(pc, np.bincount(ia)[r], n)
    merge = _conditional(pc, np.bincount(ib)[c], n)
    return split, merge, ia, ib


def seg_wiring_variation(a, b, synapses, spacing=None, background=0):
    """How a candidate segmentation ``b`` corrupts the wiring diagram of truth ``a``, in bits.

    Two levels, both VOI split / merge (``synapses`` as in :func:`seg_synapse_partners`):

      * **synapse ends** (``split`` / ``merge``, ``voi``): the segmentation VOI measured only
        at the ``2n`` synapse ends instead of every pixel. ``split`` = two ends on one true
        neuron now on different objects (the neuron was cut between its synapses); ``merge``
        = ends on different true neurons now on one object (they were glued). Cutting a
        neuron whose ``s`` ends divide ``s1`` / ``s2`` raises ``split`` by exactly
        ``(s / 2n)·H2(s1 / s)``. Pixels far from any synapse cost nothing here.
      * **connections** (``connection_split`` / ``connection_merge``): synapses grouped by
        their (pre object, post object) pair — one true connection scattered over several,
        or different true connections fused into one (synapses attributed to the wrong
        partner). A connection with a single synapse cannot scatter, so this level is blind
        to cuts that only rename a one-synapse connection; the ends level is not.

    Provenance: the ends level is the "synapse VI" of Plaza, Scheffer & Chklovskii 2014
    (*Focused proofreading*, arXiv:1409.1199; VI over the voxels carrying synaptic
    annotations, implemented in NeuroProof, C++). The connection level, the lost-synapse
    convention and the per-edit closed forms (``(s/2n)·H2(s1/s)`` for a cut) are this module's. Synapses with an end on
    ``background`` in the truth are dropped; in the candidate, each such synapse is **lost**
    and counted in ``n_lost`` as its own singleton at both levels (not one shared
    "background" object, which would fake a huge merge). Also returns ``split_connections`` (true connections
    spread over 2+ candidate ones), ``merged_connections`` (candidate connections holding
    synapses of 2+ true ones), ``edges_a`` / ``edges_b`` and ``n`` (synapses scored).

    **Raises** ``ValueError``: as :func:`seg_synapse_partners`; shapes of ``a`` and ``b``
    differ; no synapse left after dropping background in the truth.
    """
    op = "seg_wiring_variation"
    ua, va = _synapse_ids(a, synapses, spacing, "a", op)
    ub, vb = _synapse_ids(b, synapses, spacing, "b", op)
    if np.shape(a) != np.shape(b):
        raise ValueError("%s: a %r and b %r differ in shape" % (op, np.shape(a), np.shape(b)))
    bg = int(background)
    keep = (ua != bg) & (va != bg)
    if not keep.any():
        raise ValueError("%s: every synapse has an end on background in the truth" % op)
    ua, va, ub, vb = ua[keep], va[keep], ub[keep], vb[keep]
    n = len(ua)
    # ends: a candidate end on background is its own singleton (lost), never one shared object
    ends_a = np.concatenate([ua, va])
    ends_b = np.concatenate([ub, vb]).copy()
    off = ends_b == bg
    ends_b[off] = int(max(ends_b.max(), 0)) + 1 + np.arange(int(off.sum()))
    split, merge, _, _ = _voi_codes(ends_a, ends_b)
    # connections
    ea, ca, _ = _codes(ua, va)
    lost = (ub == bg) | (vb == bg)
    _, cb, _ = _codes(ub, vb)
    cb = cb.copy()
    cb[lost] = cb.max() + 1 + np.arange(int(lost.sum()))     # each lost synapse on its own
    c_split, c_merge, ia, ib = _voi_codes(ca, cb)
    pairs = np.unique(np.stack([ia, ib], 1), axis=0)
    n_b_per_a = np.bincount(pairs[:, 0])
    n_a_per_b = np.bincount(pairs[:, 1])
    return {"voi": split + merge, "split": split, "merge": merge,
            "connection_split": c_split, "connection_merge": c_merge,
            "split_connections": int((n_b_per_a > 1).sum()),
            "merged_connections": int((n_a_per_b > 1).sum()),
            "n_lost": int(lost.sum()), "edges_a": int(len(ea)),
            "edges_b": int(len(np.unique(np.stack([ub, vb], 1)[~lost], axis=0))), "n": int(n)}


def seg_synapse_nri(a, b, synapses, spacing=None, background=0):
    """Neural reconstruction integrity (Reilly et al. 2018) of candidate ``b`` against truth ``a``.

    NRI scores the pairs of synapse **ends** that a reconstruction keeps together. Over the
    ``2n`` ends (``synapses`` as in :func:`seg_synapse_partners`; ends on ``background`` in
    the truth are dropped, ends on background in the candidate are singletons), a pair of
    ends that lies in one truth neuron **and** one candidate object is a true positive; a
    pair in one truth neuron but different candidate objects is a false negative (a split);
    a pair in one candidate object but different truth neurons is a false positive (a
    merge). ``nri = 2TP / (2TP + FP + FN)`` with the pair ``precision`` and ``recall``.

    Identity (checked inside, fail-closed): with ``n_ij`` the contingency table of the ends,
    ``TP = sum C(n_ij, 2)``, ``TP + FN = sum C(s_i, 2)``, ``TP + FP = sum C(t_j, 2)``, so NRI
    is exactly ``1 - adapted_rand_error`` of :func:`seg_rand` taken over the ends (the
    ``- N`` form of the pair counts is ``2 C(n, 2)``). Both are computed and must agree to
    1e-12. Returns ``nri``, ``precision``, ``recall``, ``tp``, ``fp``, ``fn``, ``n_ends``, and ``n_lost``.

    **Raises** ``ValueError``: as :func:`seg_wiring_variation`; fewer than 2 ends.
    """
    op = "seg_synapse_nri"
    ua, va = _synapse_ids(a, synapses, spacing, "a", op)
    ub, vb = _synapse_ids(b, synapses, spacing, "b", op)
    if np.shape(a) != np.shape(b):
        raise ValueError("%s: a %r and b %r differ in shape" % (op, np.shape(a), np.shape(b)))
    bg = int(background)
    ends_a = np.concatenate([ua, va])
    ends_b = np.concatenate([ub, vb]).copy()
    keep = ends_a != bg
    ends_a, ends_b = ends_a[keep], ends_b[keep]
    if ends_a.size < 2:
        raise ValueError("%s: need at least 2 synapse ends outside the background" % op)
    off = ends_b == bg
    ends_b[off] = int(max(ends_b.max(), 0)) + 1 + np.arange(int(off.sum()))
    _, ia = np.unique(ends_a, return_inverse=True)
    _, ib = np.unique(ends_b, return_inverse=True)
    ia, ib = ia.ravel().astype(np.int64), ib.ravel().astype(np.int64)
    _, cnt = np.unique(ia * (int(ib.max()) + 1) + ib, return_counts=True)

    def pairs(x):
        x = np.asarray(x, dtype=np.float64)
        return float((x * (x - 1) / 2.0).sum())

    tp = pairs(cnt)
    fn = pairs(np.bincount(ia)) - tp
    fp = pairs(np.bincount(ib)) - tp
    precision = tp / (tp + fp) if tp + fp > 0 else 1.0
    recall = tp / (tp + fn) if tp + fn > 0 else 1.0
    nri = 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn > 0 else 1.0
    other = seg_rand(ends_a.reshape(1, -1), ends_b.reshape(1, -1))
    if abs(nri - (1.0 - other["adapted_rand_error"])) > 1e-12:
        raise ValueError("%s: NRI and 1 - adapted Rand error over the ends disagree (%r vs %r) — a bug in one of them"
                         % (op, nri, 1.0 - other["adapted_rand_error"]))
    return {"nri": float(nri), "precision": float(precision), "recall": float(recall),
            "tp": tp, "fp": fp, "fn": fn, "n_ends": int(ends_a.size), "n_lost": int(off.sum())}



def _expected_h2_binomial(s, p):
    """E[H2(K / s)] for K ~ Binomial(s, p), as an exact finite sum (log-space weights)."""
    s = int(s)
    if s <= 0:
        return 0.0
    k = np.arange(s + 1, dtype=np.float64)
    lw = (np.array([math.lgamma(s + 1) - math.lgamma(i + 1) - math.lgamma(s - i + 1) for i in range(s + 1)])
          + k * math.log(p) + (s - k) * math.log(1.0 - p))
    w = np.exp(lw)
    q = k / s
    h = np.zeros(s + 1)
    inner = (q > 0) & (q < 1)
    h[inner] = -(q[inner] * np.log2(q[inner]) + (1 - q[inner]) * np.log2(1 - q[inner]))
    return float((w * h).sum())


def seg_wiring_exposure(labels, synapses, spacing=None, background=0, p=0.5):
    """How much wiring each object stakes on staying one piece — from synapse end counts alone.

    Cutting an object whose ``s`` synapse ends (``synapses`` as in :func:`seg_synapse_partners`)
    fall ``s1`` / ``s - s1`` on the two sides costs exactly ``(s / 2n) * H2(s1 / s)`` bits of
    ends-level split (:func:`seg_wiring_variation`), and a hidden merge of two neurons inside
    one object costs the same expression as merge. So what an object can cost is fixed by its
    end count before any geometry is known:

    * ``bound = s / 2n`` — the supremum over all cuts (reached when the ends halve). The bounds
      sum to ``n_ends / 2n``: exactly 1 bit when no end lies on ``background``.
    * ``worst = (s / 2n) * H2(floor(s / 2) / s)`` — the largest cost a cut can actually reach.
    * ``expected = (s / 2n) * E[H2(K / s)]``, ``K ~ Binomial(s, p)`` — the cost of a cut that
      puts each end on the cut-off side independently with probability ``p`` (default 1/2,
      the cut through the object's median voxel with ends spread evenly over it). This is the
      count-only prediction; the gap to the observed cost is the spatial clustering of the ends.
    * ``density = (s / 2n) / (voxels / N)`` — the object's share of ends over its share of the
      ``N`` voxels of the volume. For an edit, wiring bits / pixel bits = density × (H2 of the
      end fractions / H2 of the voxel fractions): merges have the second factor near 1 (ends
      follow voxels), so their ratio is the density; a cut's second factor is
      ``H2(s1 / s) / 1`` and is what the binomial predicts.

    Objects with no end are not listed. Returns ``labels``, ``voxels``, ``ends``, ``density``,
    ``bound``, ``worst``, ``expected`` (aligned arrays), ``n`` synapses, ``n_ends`` kept,
    ``n_background`` ends dropped, ``total_bound``, ``total_expected``.

    **Raises** ``ValueError``: as :func:`seg_synapse_partners`; ``p`` not strictly inside
    (0, 1); no end outside the background.
    """
    op = "seg_wiring_exposure"
    p = float(p)
    if not (0.0 < p < 1.0) or not np.isfinite(p):
        raise ValueError("%s: p must lie strictly inside (0, 1), got %r" % (op, p))
    u, v = _synapse_ids(labels, synapses, spacing, "labels", op)
    lab = np.asarray(labels)
    n = int(len(u))
    bg = int(background)
    ends = np.concatenate([u, v])
    ends = ends[ends != bg]
    if ends.size == 0:
        raise ValueError("%s: every synapse end lies on the background" % op)
    ids, s = np.unique(ends, return_counts=True)
    vox = np.array([int((lab == i).sum()) for i in ids], dtype=np.int64)
    share = s / (2.0 * n)
    half = np.floor(s / 2.0) / s
    worst = np.where((half > 0) & (half < 1),
                     -(half * np.log2(np.where(half > 0, half, 1)) + (1 - half) * np.log2(np.where(half < 1, 1 - half, 1))),
                     0.0)
    expected = np.array([_expected_h2_binomial(int(k), p) for k in s])
    return {"labels": ids.astype(np.int64), "voxels": vox, "ends": s.astype(np.int64),
            "density": share / (vox / float(lab.size)),
            "bound": share, "worst": share * worst, "expected": share * expected,
            "n": n, "n_ends": int(ends.size), "n_background": int(2 * n - ends.size),
            "total_bound": float(share.sum()), "total_expected": float((share * expected).sum())}
