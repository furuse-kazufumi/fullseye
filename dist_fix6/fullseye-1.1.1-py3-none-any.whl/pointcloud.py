"""Point-cloud geometry primitives (numpy + scipy).

The 3-D companion to :mod:`stereo` (which builds the cloud) and :mod:`registration`
(which aligns it). Surface normals give a grasp its approach direction and let a
registration use point-to-plane error; voxel downsampling thins a dense depth
cloud to something ICP can chew on. Frame convention: ``points`` is (N, 3) in
metric world/camera units.

Reference (public): Hoppe et al., "Surface Reconstruction from Unorganized
Points", SIGGRAPH 1992 (local-PCA normals); voxel-grid downsampling is standard
point-cloud practice.
"""
from __future__ import annotations

import numpy as np

__all__ = ["estimate_normals", "voxel_downsample",
           "remove_statistical_outliers", "remove_radius_outliers", "fpfh"]


def estimate_normals(points, k: int = 16, viewpoint=None) -> np.ndarray:
    """Per-point surface normal by local PCA over the ``k`` nearest neighbours.

    The normal is the eigenvector of the neighbourhood covariance with the
    smallest eigenvalue (the direction of least spread = perpendicular to the
    local surface). Normals are sign-ambiguous; pass *viewpoint* (e.g. the camera
    position) to orient them consistently toward it. Returns unit normals (N, 3)."""
    from scipy.spatial import cKDTree

    P = np.asarray(points, np.float64)
    if P.ndim != 2 or P.shape[1] != 3:
        raise ValueError("points must be (N, 3)")
    n = P.shape[0]
    if n == 0:                              # empty cloud (nothing in view) -> empty normals
        return np.empty((0, 3), np.float64)
    kk = int(min(max(3, k), n))
    _, idx = cKDTree(P).query(P, k=kk)
    if kk == 1:                                   # degenerate: only one point
        idx = idx.reshape(n, 1)
    nb = P[idx]                                   # (N, k, 3)
    c = nb - nb.mean(1, keepdims=True)
    cov = np.einsum("nki,nkj->nij", c, c)         # (N, 3, 3) covariance per point
    _, V = np.linalg.eigh(cov)                    # ascending eigenvalues
    normals = V[:, :, 0]                          # smallest-eigenvalue direction
    if viewpoint is not None:
        d = np.asarray(viewpoint, np.float64) - P
        flip = np.einsum("ni,ni->n", normals, d) < 0
        normals[flip] *= -1.0
    norm = np.linalg.norm(normals, axis=1, keepdims=True)
    return normals / np.maximum(norm, 1e-12)


def voxel_downsample(points, voxel: float = 0.05) -> np.ndarray:
    """Thin a cloud to one point (the cell centroid) per occupied voxel of side
    *voxel*. Order is not preserved. Returns (M, 3) with M <= N — the standard way
    to bound ICP cost and even out non-uniform depth sampling density.

    Fail-closed on non-finite input: a NaN/inf coordinate raises ``ValueError``
    (drop invalid rows first, e.g. ``P[np.isfinite(P).all(1)]`` — an organized
    depth cloud keeps NaN for holes). Before 2026-11-09 a single NaN made the
    grid origin ``P.min(0)`` NaN, every key the same garbage value, and the whole
    cloud collapsed silently to one NaN point (20000-point bracket -> shape (1, 3)).
    ``voxel`` must be finite and > 0."""
    P = np.asarray(points, np.float64)
    if P.ndim != 2 or P.shape[1] != 3:
        raise ValueError("points must be (N, 3)")
    vox = float(voxel)
    if not np.isfinite(vox) or vox <= 0.0:
        raise ValueError("voxel must be finite and > 0, got %r" % (voxel,))
    if not np.isfinite(P).all():
        bad = int((~np.isfinite(P).all(axis=1)).sum())
        raise ValueError("points contains non-finite values (%d of %d rows); "
                         "drop them first, e.g. P[np.isfinite(P).all(1)]" % (bad, P.shape[0]))
    if P.shape[0] == 0:
        return P.copy()
    keys = np.floor((P - P.min(0)) / vox).astype(np.int64)
    _, inv = np.unique(keys, axis=0, return_inverse=True)
    inv = inv.ravel()
    m = int(inv.max()) + 1
    out = np.zeros((m, 3))
    counts = np.zeros(m)
    np.add.at(out, inv, P)
    np.add.at(counts, inv, 1.0)
    return out / counts[:, None]


def remove_statistical_outliers(points, k: int = 16, std_ratio: float = 2.0):
    """Drop points whose mean distance to their *k* nearest neighbours is a global
    outlier (greater than ``mean + std_ratio*std`` over all points). Cleans stray
    stereo/depth points before registration or normal estimation. Returns
    ``(filtered, keep)`` — the surviving (M, 3) points and the boolean keep mask."""
    from scipy.spatial import cKDTree

    P = np.asarray(points, np.float64)
    if P.ndim != 2 or P.shape[1] != 3:
        raise ValueError("points must be (N, 3)")
    n = P.shape[0]
    if n < 3:
        return P.copy(), np.ones(n, bool)
    kk = int(min(max(1, k), n - 1))
    d, _ = cKDTree(P).query(P, k=kk + 1)          # +1: the first neighbour is self (d=0)
    mean_d = d[:, 1:].mean(axis=1)
    thr = float(mean_d.mean() + float(std_ratio) * mean_d.std())
    keep = mean_d <= thr
    return P[keep], keep


def remove_radius_outliers(points, radius: float, min_neighbors: int = 4):
    """Drop points with fewer than *min_neighbors* other points within *radius*
    (isolated specks). Returns ``(filtered, keep)`` like
    :func:`remove_statistical_outliers`."""
    from scipy.spatial import cKDTree

    P = np.asarray(points, np.float64)
    if P.ndim != 2 or P.shape[1] != 3:
        raise ValueError("points must be (N, 3)")
    if float(radius) <= 0.0:
        raise ValueError("radius must be > 0, got %r" % (radius,))
    n = P.shape[0]
    if n == 0:
        return P.copy(), np.ones(0, bool)
    counts = cKDTree(P).query_ball_point(P, r=float(radius), return_length=True)
    keep = (np.asarray(counts) - 1) >= int(min_neighbors)   # -1 excludes the point itself
    return P[keep], keep


def _spfh(P, N, idx, bins):
    """Simplified Point Feature Histogram per point: bin the Darboux-frame angles
    (alpha, phi, theta) between a point and each neighbour into ``bins`` bins each."""
    M = P.shape[0]
    out = np.zeros((M, 3 * bins))
    ea = np.linspace(-1.0, 1.0, bins + 1)
    et = np.linspace(-np.pi, np.pi, bins + 1)
    for start in range(0, M, 256):
        stop = min(start + 256, M)
        neigh = idx[start:stop, 1:]
        if neigh.shape[1] == 0:
            continue
        d = P[neigh] - P[start:stop, None, :]
        dist = np.linalg.norm(d, axis=2)
        valid = dist > 1e-12
        safe_dist = np.where(valid, dist, 1.0)
        d = d / safe_dist[:, :, None]
        u = N[start:stop, None, :]
        nq = N[neigh]
        v = np.cross(d, u)
        vn = np.linalg.norm(v, axis=2)
        valid &= vn > 1e-12
        v = v / np.where(vn > 1e-12, vn, 1.0)[:, :, None]
        w = np.cross(np.broadcast_to(u, v.shape), v)
        features = (
            np.sum(v * nq, axis=2),
            np.sum(d * u, axis=2),
            np.arctan2(np.sum(w * nq, axis=2), np.sum(u * nq, axis=2)),
        )
        rows = np.broadcast_to(np.arange(start, stop)[:, None], neigh.shape)[valid]
        for segment, (values, edges) in enumerate(zip(features, (ea, ea, et))):
            selected = values[valid]
            columns = np.searchsorted(edges, selected, side="right") - 1
            columns[selected == edges[-1]] = bins - 1
            inside = (columns >= 0) & (columns < bins)
            np.add.at(out, (rows[inside], segment * bins + columns[inside]), 1.0)
    shaped = out.reshape(M, 3, bins)
    totals = shaped.sum(axis=2, keepdims=True)
    np.divide(shaped * 100.0, totals, out=shaped, where=totals > 0.0)
    return out


def fpfh(points, normals=None, k: int = 16, bins: int = 11):
    """Fast Point Feature Histogram descriptor per point (Rusu et al. 2009).

    A rotation-invariant ``3*bins``-D local-geometry signature built from the
    Darboux-frame angles between each point and its neighbours (and their normals),
    then smoothed by its neighbours' SPFHs. Matching these across two clouds gives
    correspondences for :func:`registration.feature_register`, which registers
    shapes whose *global* axes are ambiguous (so :func:`registration.pca_align`
    fails) but whose *local* geometry is distinctive. Returns (N, 3*bins).

    ★ **The invariance depends on the normals being consistently oriented, and
    until 2026-09-06 the default path did not give that.** The Darboux frame is
    built from the normal, so flipping a normal changes the descriptor. Plain
    PCA normals (:func:`estimate_normals`) have an **arbitrary sign** per point:
    measured on 800 points rotated by 90 degrees, every normal matched up to
    sign (``|cos| = 1.0000`` for all of them) but **42.4 % came back flipped**,
    and the descriptor moved by ``max|diff| = 7.3e+02``. Feature matching then
    failed exactly where it was supposed to help — a registration PoC measured
    the success rate falling 100 / 92 / 8 / 25 / 0 % as the initial rotation
    grew, which is impossible for a rotation-invariant descriptor.

    So when *normals* is omitted this now calls
    :func:`normals_orient.estimate_oriented_normals` (PCA normals plus Hoppe's
    minimum-spanning-tree orientation), which **is** rotation-equivariant:
    0 % sign flips at 37, 90 and 143 degrees, and the descriptor then matches
    to ``max|diff| ~ 1e-12``. It costs 2.6x the plain normal estimate, which is
    about 8 % of this function's total time (20000 points: 188 ms of 1534 ms).

    If you pass *normals* yourself, **orienting them is your job** — this
    function cannot tell an intentionally inward-facing normal from a flipped
    one. Use ``normals_orient.orient_normals`` on an existing field, or
    ``estimate_normals(points, viewpoint=...)`` when you know the sensor
    position (a viewpoint rotates with the cloud, so that is invariant too)."""
    from scipy.spatial import cKDTree

    P = np.asarray(points, np.float64)
    if P.ndim != 2 or P.shape[1] != 3:
        raise ValueError("points must be (N, 3)")
    if P.shape[0] < 2:
        return np.zeros((P.shape[0], 3 * bins))
    if normals is not None:
        N = np.asarray(normals, np.float64)
    else:
        # 向き付き法線でなければ回転不変にならない(上の注記の実測)。
        from normals_orient import estimate_oriented_normals
        N = estimate_oriented_normals(P, k=k)
    kk = int(min(k + 1, P.shape[0]))
    dist, idx = cKDTree(P).query(P, k=kk)
    if kk == 1:
        dist, idx = dist.reshape(-1, 1), idx.reshape(-1, 1)
    spfh = _spfh(P, N, idx, bins)
    out = spfh.copy()
    for i in range(P.shape[0]):
        neigh, dd = idx[i, 1:], dist[i, 1:]
        if neigh.size == 0:
            continue
        wgt = 1.0 / np.maximum(dd, 1e-12)
        out[i] = spfh[i] + (wgt[:, None] * spfh[neigh]).sum(0) / neigh.size
    return out
