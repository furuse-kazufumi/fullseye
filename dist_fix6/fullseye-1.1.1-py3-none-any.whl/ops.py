"""imgevolve — MULTI-SORT typed image-op registry (toward HALCON-scale).

The key upgrade for HALCON coverage: operators are typed by SORT, mirroring
HALCON's data model:

  image   : gray raster, float64 in [0,1]
  region  : a binary mask (float 0/1) — HALCON's Region
  feature : a scalar/tuple measurement (float) — HALCON's control tuple

Pipelines follow the canonical machine-vision shape
  image --(segment)--> region --(region morph / select)--> region --(measure)--> feature
and the type-aware decoder guarantees each stage is sort-compatible (an op only
runs on a value of its `in_sort`). Adding operators — in any sort — makes the
evolutionary search and codegen pick them up automatically.

Genome = [0,1]^GENOME_LEN: N_SLOTS stages x (op-select t, a, b). At each slot the
candidate set is the ops whose in_sort matches the running sort (+ the sort-neutral
identity), so t indexes into that filtered set. Deterministic decode.

stdlib + numpy + scipy.ndimage only. C support is a growing image-sort subset.
"""
from __future__ import annotations

import threading
from dataclasses import dataclass
from typing import Callable, Optional

import numpy as np
from scipy import ndimage
import normalized_threshold as _normalized_threshold

from fslib import FsValueError

IMAGE, REGION, FEATURE, ANY = "image", "region", "feature", "any"
CONTOUR, MATCH = "contour", "match"   # XLD subpixel contours / template-match result
VOLUME = "volume"                     # 3D voxel array (CT/MRI/depth stacks)
COLOR = "color"                       # multichannel H x W x 3 (RGB); reached via cfa_to_rgb
# Sorts opened by the typed bridge (backends_typed): the evolution vocabulary and
# the typed op catalogs (ops3d / ops1d / opsmath / opsoptics) were two disjoint
# universes — 742 ops vs 382 ops overlapping in only 3 names (measured
# 2026-09-01), so evolution could never combine a point-cloud or 1-D operator.
# These sorts are BRAND NEW, which is what makes the bridge safe: `_candidates`
# filters on `in_sort`, so adding ops under a sort nothing used before cannot
# change the candidate list length of any existing sort — and it is that length
# that decides which op a genome decodes to (see docs/WAVE0_STABLE_SLOTS.md).
POINTS = "points"                     # (N,3) point cloud
SIGNAL = "signal"                     # 1-D array (profiles, spectra, sensor series)
MATRIX = "matrix"                     # general 2-D numeric matrix (linear algebra)
CIMAGE = "cimage"                     # 2-D complex image (HALCON complex format)
# 以下 3 つは 2026-09-01 の光子計数 / ライトフィールド族と一緒に入った。
# **新設の sort なので既存 sort の候補リストは 1 つも動かない**(= ゲノム →
# op の写像は不変。docs/WAVE0_STABLE_SLOTS.md の安全規約)。入口 op は
# image を入力に取るため既存 sort の候補を変えてしまう — したがって
# この 3 sort は入口ごと wide 語彙(IMGEVOLVE_WIDE_VOCAB=1)側に置く。
LIGHTFIELD = "lightfield"             # 4-D (V,U,H,W) light field
COUNTS = "counts"                     # 非負の 1-D 光子カウント/レート
HISTCUBE = "histcube"                 # (H,W,T) 到達時刻ヒストグラム立方体
# keypoints = 像面上の (N,2) 点。**points((N,3) の点群)とは別の sort**。
# 2026-09-02 まで両者は同じ 'points' sort に写されており、``_sort_ok`` は
# points に ``shape[1] == 3`` を要求するので、(N,2) を返す/取る橋渡し op は
# 全部 fail-soft に落ちていた —— tb_project_points / tb_points_zyx_to_keypoints_uv /
# tb_keypoints_uv_to_points / tb_keypoints_to_image2d の 4 件が、あらゆる入力で
# 「定数ゼロ」か「入力の素通し」を返していた(実測)。つまり進化は
# **「3 次元を撮る」という基本的な写像を一度も使えていなかった**。
# 型を分ける基準(混ぜると例外でなく黙って別物になるか)にも合致する。
KEYPOINTS = "keypoints"               # (N,2) 像面上の点


# Matching context: the locate problem sets a reference template here before scoring
# (matching needs a model + a search image; the pipeline threads the image, the model
# comes from context). Honest coupling — documented.
class _MatchCtx:
    """Dict-like matching context whose store is THREAD-LOCAL.

    Two evaluators scoring different models in parallel (evolution sweeps run the
    scorers on a thread pool) used to share one module-level dict: B's template
    overwrote A's and A then returned a plausible-but-wrong ``[corr, y, x]`` with no
    exception. Each thread now sees the template IT set, which removes that race for
    the reachable pattern. Dict-like on purpose: callers save/restore via
    ``ctx["template"]`` / ``ctx.get("template")``.

    Precondition (honest disclosure — this is a per-call global, not a per-call
    argument, because a registry op's signature is fixed at ``(v, a, b)``):
    ``set_match_template`` must be called on the SAME thread immediately before the
    matching op that consumes it. Given that, this is race-free. Two known limits
    it does NOT solve, neither reachable in-repo (evolution builds the dataset and
    sets the template on the main thread; the only thread pool, ``scale.py``, has
    workers that merely READ via ``fn`` and never set a template):
      * a thread pool reused across tasks reads its OWN last-set template, so a
        worker must re-set per task rather than rely on a later main-thread set;
      * a thread that never set one inherits the last template set anywhere (a
        best-effort seed for the build-on-main / score-on-fresh-worker flow), which
        is not a guarantee under two threads scoring DIFFERENT templates at once.
    When no template was ever set, the matching ops return a zero (no-match) vector
    rather than a wrong match, so the failure mode is fail-closed, not silent-wrong.
    """

    def __init__(self) -> None:
        self._tl = threading.local()
        self._shared: dict = {"template": None}   # fallback for threads that never set one

    def __getitem__(self, key: str):
        try:
            return getattr(self._tl, key)
        except AttributeError:
            return self._shared[key]

    def __setitem__(self, key: str, value) -> None:
        setattr(self._tl, key, value)
        self._shared[key] = value

    def get(self, key: str, default=None):
        return getattr(self._tl, key, self._shared.get(key, default))


_MATCH_CTX = _MatchCtx()


def set_match_template(t) -> None:
    """テンプレートマッチング系 op が使うテンプレート画像を、このスレッドに登録する(``None`` で解除)。

    マッチング系 op は ``a`` / ``b`` しか取らないので、テンプレートは引数ではなくここで
    スレッドローカルな ``_MATCH_CTX`` に先に置く(float64 の配列にして保持)。未登録のまま
    呼ぶとそれらの op は no-match(``[0, 0, 0]``)を返す。
    """
    _MATCH_CTX["template"] = None if t is None else np.asarray(t, np.float64)


def _k(a: float) -> int:
    return (3, 5, 7, 9)[min(3, int(a * 4))]


def _it(a: float) -> int:
    return 1 + int(a * 3)  # morphology iterations 1..4


def _require_finite_image(v, operator: str) -> None:
    """Reject non-finite floating/complex raster inputs without scanning integers."""
    x = np.asarray(v)
    if x.dtype.kind in "fc" and not np.isfinite(x).all():
        raise FsValueError(f"{operator}: image input contains NaN or infinity")


def _norm(x):
    if np.size(x) == 0:                        # ★2026-09-20: 0 要素で np.max が生の numpy 文を出す(入口の門の同族)
        return x
    mx = float(np.max(np.abs(x)))
    return x / mx if mx > 1e-8 else x


#: **LoG は零和作用素なのに、離散化すると直流が漏れる。**
#: ``scipy.ndimage.gaussian_laplace`` はガウシアンを 4σ で打ち切るので、離散カーネルの
#: 総和が厳密には 0 にならない。結果、**一様な面に対して ``-1.92e-4 x c`` という系統的な
#: 応答**が出る(丸め屑ではない。c に比例する)。そのあと画像ごとに正規化すると、
#: その偏りが**唯一の値**なので全面フルスケールに化ける —— 実測 2026-09-16:
#: `log`(絶対値→正規化)は一様画像で**全画素 1.0**、`laplace_of_gauss`(符号つき)は
#: **全画素 0**(最大の負)を返した。
#: 実害は空フレームだけではない。**明るさを一律に足しただけで応答が変わる**
#: (+0.5 で最大 9.6e-5、ゼロ交差の位置もずれる)—— 二階微分がそうなってはいけない。
#: 平均を引いてから掛ければ直流成分が消え、厳密に不変になる(残差 1.7e-17 を実測)。
#: ``ndimage.laplace`` の 5 点カーネルは総和がちょうど 0 なので、この処置は要らない。
def _log_dc_free(x, sigma):
    """直流を抜いてから LoG を掛ける。``x`` の平均は零和作用素の出力に寄与しない。"""
    x = np.asarray(x, np.float64)
    return ndimage.gaussian_laplace(x - float(np.mean(x)), sigma)


def _shift_edge(x, dy, dx):
    """Shift like ``np.roll`` but REPLICATE the border instead of wrapping around.

    ``np.roll`` is circular, so a neighbourhood built from it makes the first
    column/row see the LAST column/row of the image. Every local neighbourhood
    here must stay inside the image, so out-of-image taps are clamped to the
    nearest in-image pixel (``mode="edge"``). Interior values are bit-identical
    to ``np.roll``; only the border ring changes.
    """
    x = np.asarray(x, np.float64)
    H, W = x.shape[0], x.shape[1]
    py0, py1, px0, px1 = max(dy, 0), max(-dy, 0), max(dx, 0), max(-dx, 0)
    p = np.pad(x, ((py0, py1), (px0, px1)), mode="edge")
    return p[py1:py1 + H, px1:px1 + W]


def _signed01(x):
    """Map a signed response to [0,1] with the zero-crossing at 0.5 (preserves the
    negative half that a plain _norm→[-1,1] would lose to the pipeline's clip)."""
    x = np.asarray(x, np.float64)
    m = float(np.max(np.abs(x))) if x.size else 0.0
    return np.clip(x / (2 * m) + 0.5, 0, 1) if m > 1e-8 else np.full_like(x, 0.5)


def _bin(v):
    return (np.asarray(v) > 0.5)


# --- image -> image ---------------------------------------------------------- #
def _identity(v, a, b):
    """恒等写像。HALCON の ``copy_image``（Copy an image and allocate new memory for it.）に対応付けられているが、実装は新しいメモリを確保して複製する ``copy_image`` とは異なり、入力の配列をそのまま返すだけ（複製しない）。

``a``, ``b`` は未使用。sort が ``ANY``（image/region/feature いずれの入力にも一致）なのはこの op だけの特別扱いで、パイプラインの型を変えずに「何もしない」スロットを置くために使う（進化がスロット数を埋めたいだけのとき等）。値を作り直さず入力をそのまま返すため、呼び出し側で戻り値を書き換えると入力の配列も一緒に変わる点に注意。"""
    return v
def _gaussian(v, a, b):
    """等方ガウシアン平滑化。HALCON の ``gauss_filter``（Smooth using discrete Gauss functions.）に相当。

``a`` が標準偏差 σ を ``0.3〜3.0`` に線形に振る（``σ = 0.3 + 2.7a``）。``b`` が**端の扱い**を選ぶ: ``b <= 0.5`` で ``reflect``(端画素を複製して折り返す。scipy の既定で、2026-09-17 までの挙動)、以降 ``nearest`` / ``constant``(0 で埋める)/ ``wrap``(反対側から巻き取る)。★**σ が 0.375 未満(``a`` が約 0.028 未満)だと ``reflect`` と ``nearest`` が原理的に一致する**(``scipy`` の窓の半径は ``int(4σ + 0.5)`` で、ここでは 1 画素。はみ出しが 1 画素なので複製先が同じ)—— 端の扱いを変えたのに結果が動かないときは、まず σ の小ささを疑うこと(σ = 1 では最大 0.05 程度変わる)。実装は ``scipy.ndimage.gaussian_filter``。ノイズ除去や後段のエッジ検出前のぼかしに使う。σ が大きいほど細部が失われる。"""
    return ndimage.gaussian_filter(v, sigma=0.3 + 2.7 * a, mode=_border(b))
def _mean_box(v, a, b):
    """矩形窓の単純平均（box）フィルタ。HALCON の ``mean_image``（Smooth by averaging.）に相当。

``a`` が窓の一辺を ``3,5,7,9`` の4段階（``_k(a)``、``a`` を4分割して丸める）に切り替える。``b`` が**端の扱い**を選ぶ: ``b <= 0.5`` で ``reflect``(端画素を複製して折り返す。scipy の既定で、2026-09-17 までの挙動)、以降 ``nearest`` / ``constant``(0 で埋める)/ ``wrap``(反対側から巻き取る)。★**窓が 3 のときは ``reflect`` と ``nearest`` が原理的に一致する**(はみ出しが 1 画素なので複製先が同じ)—— 端の扱いを変えたのに結果が動かないときは、まず窓の大きさを疑うこと(窓 9 では 3 通りとも変わる)。ガウシアンより計算は軽いがリンギングが出やすく、エッジがぼやける。

**端の扱い**: 端画素を重複させて折り返す (d c b a | a b c d、scipy の既定 ``reflect``)(2026-09-16 に実測して記録)。"""
    return ndimage.uniform_filter(v, size=_k(a), mode=_border(b))


def _mean_box_wh(v, a, b):
    """幅と高さを独立に選ぶ平均（box）フィルタ。HALCON の ``mean_image``（Smooth by averaging.）に相当。

``a`` が窓の幅、``b`` が窓の高さで、各ノブは ``1 + 2 * min(7, int(8 * clip(knob, 0, 1)))`` で
奇数 1, 3, …, 15 に写す（偶数の幅・高さを次の奇数へ切り上げるのと同じ）。境界は常に
``reflect``。幅と高さが同じなら、同じ窓・``reflect`` の ``mean_box`` とビット一致する。
例: ``_mean_box_wh(np.eye(5), 0.2, 0.4)``。

NaN を含む画像では NaN がその画素を参照する平均窓の出力へ伝播する。
    """
    width = 1 + 2 * min(7, int(8 * np.clip(a, 0.0, 1.0)))
    height = 1 + 2 * min(7, int(8 * np.clip(b, 0.0, 1.0)))
    return ndimage.uniform_filter(v, size=(height, width), mode="reflect")
def _median(v, a, b):
    """メディアン（中央値）フィルタ。HALCON の ``median_image``（Compute a median filter with various masks.）に相当。

``a`` が窓サイズを ``3,5,7,9``（``_k(a)``）に振る。``b`` が**端の扱い**を選ぶ: ``b <= 0.5`` で ``reflect``(端画素を複製して折り返す。scipy の既定で、2026-09-17 までの挙動)、以降 ``nearest`` / ``constant``(0 で埋める)/ ``wrap``(反対側から巻き取る)。★**窓が 3 のときは ``reflect`` と ``nearest`` が原理的に一致する**(はみ出しが 1 画素なので複製先が同じ)—— 端の扱いを変えたのに結果が動かないときは、まず窓の大きさを疑うこと(窓 9 では 3 通りとも変わる)。塩胡椒ノイズなど外れ値に強く、ガウシアン平滑よりエッジを保ちやすい。

NaN を含む画像では scipy の中央値選択により NaN が一部の窓の出力へ伝播する。"""
    return ndimage.median_filter(v, size=_k(a), mode=_border(b))
def _min_filter(v, a, b):
    """矩形窓内の最小値フィルタ（グレースケール侵食に相当）。HALCON の ``gray_erosion_rect``（Determine the minimum gray value within a rectangle.）に相当。

``a`` が窓サイズを ``3,5,7,9``（``_k(a)``）に振る。``b`` は未使用。明るい小さな構造（点状の輝点等）を消し、暗い領域を広げる。"""
    return ndimage.minimum_filter(v, size=_k(a))
def _max_filter(v, a, b):
    """矩形窓内の最大値フィルタ（グレースケール膨張に相当）。HALCON の ``gray_dilation_rect``（Determine the maximum gray value within a rectangle.）に相当。

``a`` が窓サイズを ``3,5,7,9``（``_k(a)``）に振る。``b`` は未使用。暗い小さな欠陥（ピンホール等）を消し、明るい領域を広げる。"""
    return ndimage.maximum_filter(v, size=_k(a))
def _percentile(v, a, b):
    """任意パーセンタイルのランクフィルタ。HALCON の ``rank_image``（Compute a rank filter with arbitrary masks.）に相当。

``a`` が窓サイズを ``3,5,7,9``（``_k(a)``）に、``b`` が抽出するパーセンタイルを ``5〜95%``（``int(5+90b)``）に振る。``b`` が 0 に近いほど ``_min_filter``、1 に近いほど ``_max_filter``、中間で ``_median`` に近づく——3 op を 1 つに統合した一般形。"""
    return ndimage.percentile_filter(v, percentile=int(5 + 90 * b), size=_k(a))
def _erode_g(v, a, b):
    """グレースケール侵食（暗い側に広げる）。HALCON の ``gray_erosion``（Perform a gray value erosion on an image.）に相当。

``a`` が構造要素の一辺を ``3,5,7,9``（``_k(a)``）に振る。``b`` が**構造要素の形**を選ぶ: ``b <= 0.5`` で正方形(2026-09-17 までの挙動、分離可能なので最速)、以降 ``十字`` / ``円板`` / ``水平線``。円板は HALCON の ``gen_disc_se`` に、水平線は方向性のある欠陥(横筋・スジ)を残したまま縦方向だけ均すのに使う。★正方形以外は footprint 経由になるので**目に見えて遅い**。正方形のときは矩形窓の最小値フィルタと等価（``_min_filter``）。"""
    return _morph(ndimage.grey_erosion, v, a, b)
def _dilate_g(v, a, b):
    """グレースケール膨張（明るい側に広げる）。HALCON の ``gray_dilation``（Perform a gray value dilation on an image.）に相当。

``a`` が構造要素の一辺を ``3,5,7,9``（``_k(a)``）に振る。``b`` が**構造要素の形**を選ぶ: ``b <= 0.5`` で正方形(2026-09-17 までの挙動、分離可能なので最速)、以降 ``十字`` / ``円板`` / ``水平線``。円板は HALCON の ``gen_disc_se`` に、水平線は方向性のある欠陥(横筋・スジ)を残したまま縦方向だけ均すのに使う。★正方形以外は footprint 経由になるので**目に見えて遅い**。正方形のときは矩形窓の最大値フィルタと等価（``_max_filter``）。"""
    return _morph(ndimage.grey_dilation, v, a, b)
def _open_g(v, a, b):
    """グレースケールオープニング（侵食してから膨張）。HALCON の ``gray_opening``（Perform a gray value opening on an image.）に相当。

``a`` が構造要素の一辺を ``3,5,7,9``（``_k(a)``）に振る。``b`` が**構造要素の形**を選ぶ: ``b <= 0.5`` で正方形(2026-09-17 までの挙動、分離可能なので最速)、以降 ``十字`` / ``円板`` / ``水平線``。円板は HALCON の ``gen_disc_se`` に、水平線は方向性のある欠陥(横筋・スジ)を残したまま縦方向だけ均すのに使う。★正方形以外は footprint 経由になるので**目に見えて遅い**。明るい小さな突起（ノイズ状の輝点）を除去しつつ、大きな明域の形はほぼ保つ。"""
    return _morph(ndimage.grey_opening, v, a, b)
def _close_g(v, a, b):
    """グレースケールクロージング（膨張してから侵食）。HALCON の ``gray_closing``（Perform a gray value closing on an image.）に相当。

``a`` が構造要素の一辺を ``3,5,7,9``（``_k(a)``）に振る。``b`` が**構造要素の形**を選ぶ: ``b <= 0.5`` で正方形(2026-09-17 までの挙動、分離可能なので最速)、以降 ``十字`` / ``円板`` / ``水平線``。円板は HALCON の ``gen_disc_se`` に、水平線は方向性のある欠陥(横筋・スジ)を残したまま縦方向だけ均すのに使う。★正方形以外は footprint 経由になるので**目に見えて遅い**。暗い小さな欠け（ノイズ状の暗点）を埋めつつ、大きな暗域の形はほぼ保つ。"""
    return _morph(ndimage.grey_closing, v, a, b)
def _tophat(v, a, b):
    """ホワイトトップハット（原画像 − オープニング）。HALCON の ``gray_tophat``（Perform a gray value top hat transformation on an image.）に相当。

``a`` が構造要素の一辺を ``3,5,7,9``（``_k(a)``）に振る。``b`` は未使用。背景より明るく、構造要素より小さい局所的な輝点だけを浮き上がらせる（照明ムラを消して欠陥だけ残す用途）。結果は ``_norm`` で最大絶対値 1 に正規化される。"""
    return _norm(ndimage.white_tophat(v, size=_k(a)))
def _bothat(v, a, b):
    """ブラックトップハット（クロージング − 原画像）。HALCON の ``gray_bothat``（Perform a gray value bottom hat transformation on an image.）に相当。

``a`` が構造要素の一辺を ``3,5,7,9``（``_k(a)``）に振る。``b`` は未使用。背景より暗く、構造要素より小さい局所的な暗点だけを浮き上がらせる。結果は ``_norm`` で正規化される。"""
    return _norm(ndimage.black_tophat(v, size=_k(a)))
def _morph_grad(v, a, b):
    """モルフォロジー勾配（膨張 − 侵食）。HALCON の ``gray_range_rect``（Determine the gray value range within a rectangle.）に相当。

``a`` が構造要素の一辺を ``3,5,7,9``（``_k(a)``）に振る。``b`` は未使用。窓内の最大値と最小値の差を返すため、エッジ検出フィルタ（Sobel 等）に似た働きをするが方向を持たない。結果は ``_norm`` で正規化される。"""
    return _norm(ndimage.morphological_gradient(v, size=_k(a)))
def _sobel_mag(v, a, b):
    """Sobel フィルタによる勾配強度（エッジ検出）。HALCON の ``sobel_amp``（Detect edges (amplitude) using the Sobel operator.）に相当。

縦横それぞれの Sobel 応答のユークリッドノルム ``hypot(Gx, Gy)`` を取り、``_norm`` で正規化する。``a``, ``b`` は未使用（カーネルサイズ・向きとも固定）。"""
    return _norm(np.hypot(ndimage.sobel(v, 1), ndimage.sobel(v, 0)))
def _laplace(v, a, b): return _norm(np.abs(ndimage.laplace(v)))
def _prewitt_mag(v, a, b):
    """Prewitt フィルタによる勾配強度（エッジ検出）。HALCON の ``prewitt_amp``（Detect edges (amplitude) using the Prewitt operator.）に相当。

縦横それぞれの Prewitt 応答のユークリッドノルムを取り、``_norm`` で正規化する。``a``, ``b`` は未使用。Sobel と同系統だが平均カーネル（重み無し）を使うぶんノイズにはやや弱い。"""
    return _norm(np.hypot(ndimage.prewitt(v, 1), ndimage.prewitt(v, 0)))


def _roberts_mag(v, a, b):
    """Roberts クロス勾配による勾配強度（エッジ検出）。HALCON の ``roberts``（Detect edges using the Roberts filter.）に相当。

2×2 の対角差分（``v - shift(-1,-1)`` と ``shift(0,-1) - shift(-1,0)``）のユークリッドノルムを ``_norm`` で正規化する。``a``, ``b`` は未使用。カーネルが小さい（2×2）ためノイズに敏感だが応答の局在性は高い。境界は ``_shift_edge`` によりレプリケート（折り返しなし）。"""
    return _norm(np.hypot(v - _shift_edge(v, -1, -1), _shift_edge(v, 0, -1) - _shift_edge(v, -1, 0)))


def _dog(v, a, b):
    """差分ガウシアン（Difference of Gaussians, DoG）。HALCON の ``diff_of_gauss``（Approximate the LoG operator (Laplace of Gaussian).）に相当。

``a`` が細かい方のぼかし σ₁ を ``0.5〜2.5`` に、``b`` が粗い方のぼかし σ₂ を ``1.0〜5.0`` に振る（``|gauss(σ₁) - gauss(σ₂)|`` を ``_norm`` で正規化）。2 つのスケールの中間の大きさを持つ斑点・エッジを強調する、LoG の近似。σ₁ と σ₂ が近いほど応答は弱くなる。"""
    return _norm(np.abs(ndimage.gaussian_filter(v, 0.5 + 2.0 * a) - ndimage.gaussian_filter(v, 1.0 + 4.0 * b)))


def _edge_transition_width(v, a, b):
    """**エッジの遷移幅**(= その場の実効 PSF の広がり)を画素単位で測る。

``a`` が測定窓の一辺を ``3,5,7,9``(``_k(a)``)に振る。``b`` が振幅と勾配の推定量を
選ぶ: ``b <= 0.5`` は窓内の**最大 − 最小**(素直・鋭いが外れ値に弱い)、
``b > 0.5`` は**分位点**で、``b`` を上げるほど分位が 90/10 から 60/40 へ寄って
雑音に鈍くなる(そのぶん段差も丸まる = 取引になっている)。

幅 ≒ 局所の振幅 ÷ 局所の最大勾配。段差が 1 画素で立ち上がれば幅は 1 付近、
ぼけて 5 画素かけて立ち上がれば 5 付近になる。ぼけを**作る** ``simulate_defocus``
の対で、こちらは**測る**側。合焦判定・モーションブラー量・解像限界・
文字が読める大きさかの判定に使える。

**窓が遷移より狭いと過小評価になる**(窓の中に振幅の全部が入らないため)。
出力が 0.7 を超えたら ``a`` を上げて測り直すのが実用則。

**正規化は画像ごとではない**(窓の一辺という定数で割るだけ)ので、
**値は画像間で比較できる**。出力 1.0 は「遷移幅が窓と同じ = 窓より広いかもしれず**測り切れていない**」
の意味で、``a`` を上げて測り直す合図。平坦部やエッジの無い場所は 0。

★**空フレームでは全 0 を返す**(「端が無い」)。床を画像自身の振幅に対する相対量
だけで置くと、一様な画像では基準まで丸め屑になり、屑どうしの比が構造に化ける ——
実測で 0.5 一色に 1e-12 の雑音を乗せただけの画像が幅 3.49(= 窓の半分)を返した。
**振幅そのものが絶対床 1e-6 に届かない画像には端が無い**と言い切る。
端の扱いは ``scipy.ndimage`` の既定 ``reflect``。内部で 8 bit に落とす処理は無い。"""
    x = np.asarray(v, np.float64)
    k = _k(a)
    # ★勾配は**片側差分の大きい方**で取る。``np.gradient`` の中心差分は 1 画素で
    #   立ち上がる段差を 2 画素に広げてしまい(段差の頂点で 0.5 しか出ない)、
    #   理想の段差が幅 2.00 と報告される —— 測る道具が理想ケースで 2 倍を返す。
    #   片側差分なら段差で 1.0、傾斜 m の斜面でも m となり、どちらも正しい。
    gxf = np.diff(x, axis=1, append=x[:, -1:])
    gxb = np.diff(x, axis=1, prepend=x[:, :1])
    gyf = np.diff(x, axis=0, append=x[-1:, :])
    gyb = np.diff(x, axis=0, prepend=x[:1, :])
    grad = np.hypot(np.maximum(np.abs(gxf), np.abs(gxb)),
                    np.maximum(np.abs(gyf), np.abs(gyb)))
    scale = float(np.ptp(x))
    if scale < 1e-6:                                   # 平坦な画像に端は無い
        return np.zeros_like(x)
    t = float(np.clip(b, 0.0, 1.0))
    if t <= 0.5:
        amp = ndimage.maximum_filter(x, size=k) - ndimage.minimum_filter(x, size=k)
        gmax = ndimage.maximum_filter(grad, size=k)
    else:                                              # 雑音に鈍い分位点版
        hi = 90.0 - 30.0 * (t - 0.5) / 0.5             # 90 -> 60 パーセンタイル
        amp = (ndimage.percentile_filter(x, hi, size=k)
               - ndimage.percentile_filter(x, 100.0 - hi, size=k))
        gmax = ndimage.percentile_filter(grad, hi, size=k)
    floor = 1e-3 * scale                               # 相対床(屑の増幅を止める)
    w = np.where(gmax > floor, amp / np.maximum(gmax, floor), 0.0)
    return np.clip(w, 0.0, float(k)) / float(k)


def _runlength_smear(v, a, b):
    """**走査長平滑化(RLSA)**。行内の字の隙間を埋めて、字を「行」の塊にまとめる。

版面解析(どこが行で、どこが段か)の基本部品。``a`` が**埋める隙間の長さ**を
``3,5,9,15,25,41,65`` 画素(``b`` の向きに沿った線)に振り、``b`` が向きと
合成を選ぶ: ``b <= 0.5`` は**水平のみ**、``0.5 < b <= 0.75`` は**垂直のみ**、
``b > 0.75`` は**水平と垂直の小さい方**(= 古典 RLSA の 2 パス AND 合成。
両方向で埋まった所だけが残るので、行だけでなく**段組みの塊**が出る)。

★**既存の ``gclose`` と一部重なる**。``gclose`` は ``b`` で水平線の構造要素を
選べるので、水平 RLSA は原理的に書ける。ここが足すのは 2 つ ——
(1) 隙間が **3〜9 画素でなく 65 画素まで**振れる(``_k`` の上限では行がつながらない。
文字の間隔は 96 px の字なら 10〜30 画素ある)、(2) **2 方向の AND 合成**は
単一の構造要素による閉じでは書けない。片方だけなら ``gclose`` を使うほうが速い。

濃淡画像にそのまま掛かる(内部で二値化しない)。灰色の閉じ演算なので、
**暗い隙間を埋める**方向に働く —— 字が明るく背景が暗い画像で使うこと。
逆なら先に ``invert`` を通す。端の扱いは ``scipy.ndimage`` の既定の ``reflect``。
空フレーム(定数画像)は**そのまま返る**(埋めるべき隙間が無い)。値域は入力のまま
[0,1] に収まり、画像ごとの正規化はしない(**値は画像間で比較できる**)。"""
    x = np.asarray(v, np.float64)
    gap = (3, 5, 9, 15, 25, 41, 65)[min(6, int(float(np.clip(a, 0.0, 1.0)) * 7))]
    t = float(np.clip(b, 0.0, 1.0))
    h = ndimage.grey_closing(x, size=(1, gap), mode="reflect")
    if t <= 0.5:
        return np.clip(h, 0.0, 1.0)
    w = ndimage.grey_closing(x, size=(gap, 1), mode="reflect")
    if t <= 0.75:
        return np.clip(w, 0.0, 1.0)
    return np.clip(np.minimum(h, w), 0.0, 1.0)          # 2 パス AND 合成


def _gamma(v, a, b):
    """ガンマ補正（べき乗変換）。HALCON の ``pow_image``（Raise an image to a power.）に相当。

``a`` が指数 γ を ``0.5〜2.0`` に**線形に**振る（``γ = 0.5 + 1.5a``、``v**γ``、入力は先に ``[0,1]`` へ clip）。**既定の ``a=0.5`` は γ=1.25 であって素通しではない** —— 何もしない設定（γ=1）が要るなら ``a=1/3`` を渡す。``b`` は未使用。γ<1 で暗部を持ち上げ（明るくする）、γ>1 で暗部をさらに沈める（コントラストを付ける）。"""
    return np.clip(v, 0, 1) ** (0.5 + 1.5 * a)
def _invert(v, a, b):
    """階調反転（ネガポジ反転）。HALCON の ``invert_image``（Invert an image.）に相当。

``1 - clip(v,0,1)`` を返すだけ。``a``, ``b`` は未使用。

- 入力を先に [0,1] へ clip してから反転するので、範囲外の値は**飽和してから**反転される(1.3 → 0、-0.2 → 1)。値域が [0,1] でない配列は前段で正規化しておくこと。
- 返り値は入力と同形の float、値域 [0,1]。NaN は clip を素通りして NaN のまま返る(``ops.py`` 直登録の op なので backend の guard は掛からない —— 非有限を止めたいなら ``fullseye.apply`` 経由で ``on_error="raise"``)。
- 2 回掛けると元に戻る(対合)。region に掛ければ前景/背景が入れ替わるが、region 用には ``invert_region``(補集合)がある。
- 使いどころ: 暗い対象を ``threshold`` で「明るい側」として拾う前の反転、``dc_rpca_sparse`` の暗い残差や ``xpil_contour`` の黒い線を正の信号にする、距離変換の「内側ほど暗い」を「内側ほど明るい」に読み替える。"""
    return 1.0 - np.clip(v, 0, 1)
def _scale_clip(v, a, b):
    """ゲインとオフセットによる線形階調変換。HALCON の ``scale_image``（Scale the gray values of an image.）に相当。

``a`` がゲイン（コントラスト）を ``0.5〜2.0`` 倍に、``b`` がオフセット（明るさ）を ``-0.5〜+0.5`` に振る（``clip(gain*v + offset, 0, 1)``）。``b=0.5`` がオフセット 0（変化なし）に対応する点に注意。"""
    return np.clip((0.5 + 1.5 * a) * v + (b - 0.5), 0, 1)


def _equalize(v, a, b):
    """ヒストグラム均等化（線形化）。HALCON の ``equ_histo_image``（Histogram linearization of images）に相当。

``a``, ``b`` は未使用。``[0,1]`` を 256 ビンに分けたヒストグラムの累積分布関数（CDF）を求め、各画素値をその CDF で置き換えることで、出力のヒストグラムがほぼ一様になるよう引き伸ばす。コントラストが低い（値域が狭い）画像を見やすくするのに使う。全画素が同一値だと CDF が定義できず ``cdf[-1]`` が 0 になり、変換は事実上恒等（変化なし）になる。"""
    x = np.asarray(v, np.float64)
    lo = float(np.nanmin(x)) if x.size else 0.0
    hi = float(np.nanmax(x)) if x.size else 1.0
    # [0,1] の外を clip すると CDF が全部 1 になり、平坦化が恒等に化ける
    # (0..255 の float を渡すと出力が一様に 1.0)。範囲外のときだけ実データの
    # 範囲でビンを張る —— [0,1] 内の入力に対する結果は**一切変えない**。
    if hi > 1.0 or lo < 0.0:
        span = (lo, hi) if hi > lo else (lo, lo + 1.0)
    else:
        x = np.clip(x, 0, 1); span = (0.0, 1.0)
    hist, edges = np.histogram(x, 256, span)
    cdf = np.cumsum(hist).astype(np.float64); cdf = cdf / cdf[-1] if cdf[-1] > 0 else cdf
    return np.interp(x.ravel(), (edges[:-1] + edges[1:]) / 2, cdf).reshape(x.shape)


def _sigmoid(v, a, b):
    """ロジスティック関数（シグモイド）による S 字型のコントラスト強調。HALCON の ``scale_image_max``（Maximum gray value spreading in the value range 0 to 255.）に対応付けられているが、ダイナミックレンジを最大まで引き伸ばす ``scale_image_max`` とは処理内容が異なる（近似というより別物に近い）。

``a`` が S字の傾き ``k = 4 + 12a``（``4〜16``）を、``b`` が中心（変曲点）の位置 ``x0 = 0.2 + 0.6b``（``0.2〜0.8``）を振る（``1/(1+exp(-k*(v-x0)))``）。``x0`` 付近の階調差を強調し、両端の階調差は圧縮する。"""
    return 1.0 / (1.0 + np.exp(-(4.0 + 12.0 * a) * (np.clip(v, 0, 1) - (0.2 + 0.6 * b))))


def _bilateral(v, a, b):
    """エッジ保存平滑化（bilateral filter）。HALCON の ``bilateral_filter``（bilateral filtering of an image.）に相当。

``a`` が空間方向の広がり ``σ_s = 1.0 + 3.0a`` を、``b`` が明るさ方向の許容差 ``σ_r = 0.05 + 0.4b`` を振る。近傍窓は半径 ``r=2``（5×5）固定で ``a`` では変わらない。近傍の重みは ``exp(-距離²/2σ_s²) × exp(-明度差²/2σ_r²)`` の積で、明度差が大きい（=エッジをまたぐ）画素は重みが小さくなるため、平滑化しつつ輪郭を保てる。窓内を Python の二重ループで回すため他の平滑化 op より遅い。

**端の扱い**: 端の画素を複製する(最近傍)(2026-09-16 に実測して記録)。"""
    ss, sr, r = 1.0 + 3.0 * a, 0.05 + 0.4 * b, 2
    out = np.zeros_like(v, np.float64); wsum = np.zeros_like(v, np.float64)
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            sh = _shift_edge(v, dy, dx)   # edge-clamped: never wraps to the opposite border
            w = np.exp(-(dx * dx + dy * dy) / (2 * ss * ss)) * np.exp(-((sh - v) ** 2) / (2 * sr * sr))
            out += w * sh; wsum += w
    return out / np.maximum(wsum, 1e-8)


def _box_sums_valid(x, k):
    """``k x k`` の窓の総和(窓が全部画像の中に入る位置だけ)。軸ごとの累積和なので O(N)。
    2 次元の積分画像ではなく**軸ごと**に累積するのは、累積値が画素数ではなく行(列)の
    長さまでしか大きくならず、桁落ちが 2 桁小さいため。"""
    c = np.cumsum(x, axis=0)
    c = np.concatenate([np.zeros((1, x.shape[1])), c], axis=0)
    s = c[k:] - c[:-k]
    c = np.cumsum(s, axis=1)
    c = np.concatenate([np.zeros((s.shape[0], 1)), c], axis=1)
    return c[:, k:] - c[:, :-k]


#: Kuwahara の同点判定に使う分散の丸め桁。丸めた値で比べ、同点は宣言順(左上・右上・
#: 左下・右下)で決める。丸めないと、足し算の順序の違いだけ(1e-17)で勝つ象限が
#: 環境ごとに入れ替わる。
_KUWAHARA_TIE_DIGITS = 10


def _kuwahara_radius(a):
    """``a`` を窓の半径 1..10 へ(線形、半分は切り上げ)。"""
    return 1 + int(np.floor(float(np.clip(a, 0.0, 1.0)) * 9 + 0.5))


def _kuwahara(v, a, b):
    """Kuwahara フィルタ(1976)。4 つの重なる窓のうち分散が最小の窓の平均を出す、縁を保つ平滑化。

油絵調の見た目にも使われる。

各画素について、その画素を角に含む ``(r+1) x (r+1)`` の窓を 4 つ(左上・右上・左下・
右下。隣り合う窓は中心の行と列を共有して重なる)とり、**分散がいちばん小さい窓の
平均**を出力する。縁をまたぐ窓は分散が大きいので選ばれず、画素は縁の「自分と同じ側」
の窓の平均になる。だから平坦部は均され、段差は鈍らない(``gaussian`` は段差をなだらかに
してしまう)。

``a`` が窓の半径 ``r = 1 + floor(9a + 0.5)``(``1〜10``、窓の一辺は ``r+1``)を振る。大きい
ほど均す範囲が広がり、細い構造は消える。``b`` は未使用。

計算量は **O(N)**: 窓の和と二乗和を軸ごとの累積和で求めるので、半径に依存しない
(分散は ``E[x^2] - E[x]^2``、全体の平均を引いてから計算して桁落ちを抑える)。
分散の同点は、小数 10 桁に丸めた値で比べ、宣言順(左上・右上・左下・右下)で決める。

**端の扱い**: 端の画素を複製する(最近傍)。端の画素の窓は、画像の外を端の値で埋めて
作る。

**適用条件**: (1) 4 象限の方向は軸に揃っているので、斜めの縁では選ばれた窓が縁に
沿わず、角の丸まりや「ブロック状」の模様が出る(一般化 Kuwahara はこれを直す)。
(2) 半径が大きいと細い線は消える。(3) 出力は入力の局所平均だけから作るので、値域は
入力の外に出ない。"""
    x = np.asarray(v, np.float64)
    r = _kuwahara_radius(a)
    H, W = x.shape[0], x.shape[1]
    mu = float(np.mean(x))
    xp = np.pad(x - mu, r, mode="edge")
    k = r + 1
    n = float(k * k)
    m = _box_sums_valid(xp, k) / n
    q = _box_sums_valid(xp * xp, k) / n
    var = np.maximum(q - m * m, 0.0)
    # 窓の左上の位置(パディング後の座標): 画素 (y,x) は (y+r, x+r)
    sl = ((slice(0, H), slice(0, W)), (slice(0, H), slice(r, r + W)),
          (slice(r, r + H), slice(0, W)), (slice(r, r + H), slice(r, r + W)))
    means = np.stack([m[s] for s in sl])
    vars_ = np.round(np.stack([var[s] for s in sl]), _KUWAHARA_TIE_DIGITS)
    pick = np.argmin(vars_, axis=0)
    out = np.take_along_axis(means, pick[None], axis=0)[0] + mu
    return np.clip(out, 0.0, 1.0)


#: XDoG の既定値(Winnemoller・Kyprianidis・Olsen 2012 の記号)。``k`` は 2 つ目の
#: ガウシアンの幅の比、``tau`` は引く量の重み、``phi`` は閾値の鋭さ。
_XDOG_K, _XDOG_TAU, _XDOG_PHI = 1.6, 0.98, 50.0


def _xdog_response(x, sigma, k, tau):
    """``D = G_sigma * x - tau * G_(k sigma) * x``(端は複製)。"""
    g1 = ndimage.gaussian_filter(x, sigma, mode="nearest")
    g2 = ndimage.gaussian_filter(x, k * sigma, mode="nearest")
    return g1 - tau * g2


def _xdog_threshold(d, eps, phi):
    """ソフト閾値 ``T(u) = 1 (u >= eps)、1 + tanh(phi (u - eps)) (u < eps)``。"""
    t = np.ones_like(d)
    low = d < eps
    t[low] = 1.0 + np.tanh(phi * (d[low] - eps))
    return t


def _xdog(v, a, b):
    """XDoG(拡張ガウス差分、Winnemoller・Kyprianidis・Olsen 2012)による線画・墨絵調のスタイライズ。

``D = G_sigma - tau * G_(k sigma)`` を作り(``G`` はガウシアンのぼかし)、ソフト閾値
``T(u) = 1 (u >= eps)、1 + tanh(phi (u - eps)) (u < eps)`` を通す。出力は ``0〜1`` で、
紙の白(1)の上に、縁の暗い側だけが黒(0)に沈む。``tau = 1`` なら ``D`` は通常の DoG、
``phi`` を無限大にすると閾値は ``D >= eps`` の二値(DoG の符号)になる。

``a`` がぼかしの幅 ``sigma = 0.5 + 2.5a``(``0.5〜3.0``)を、``b`` が閾値の位置
``eps = 0.1b``(``0〜0.1``)を振る。``sigma`` は線の太さと拾う縁の大きさ、``eps`` を
上げると平坦部も黒く沈み(``tau < 1`` のとき明るい平坦部の ``D`` は ``(1 - tau) x 明るさ``
で、最大 0.02)、墨を塗ったような絵になる。残りは固定: ``k = 1.6``、``tau = 0.98``、
``phi = 50``(``D`` の振れは縁で ±0.1 前後なので、遷移幅は約 0.02)。

**端の扱い**: 端の画素を複製する(最近傍)。

**適用条件**: (1) 出力は入力の明るさの階調を捨てる(ほぼ二値)。計測には使わず見せ方
のための op。(2) ``tau`` を 1 にしない既定では、真っ白な平坦部は ``D = 0.02`` で
``eps`` を 0.02 超に上げると黒くなる。(3) 雑音の多い画像は ``sigma`` を上げないと
雑音が線になる。"""
    x = np.asarray(v, np.float64)
    sigma = 0.5 + 2.5 * float(np.clip(a, 0.0, 1.0))
    eps = 0.1 * float(np.clip(b, 0.0, 1.0))
    d = _xdog_response(x, sigma, _XDOG_K, _XDOG_TAU)
    return np.clip(_xdog_threshold(d, eps, _XDOG_PHI), 0.0, 1.0)


def _local_bimodality(v, a, b):
    """**局所の二峰性**(bimodality coefficient)。閾値を 1 つも選ばずに「ここは 2 つの
値に分かれているか」だけを 0〜1 の地図で返す。

``a`` が窓の一辺を ``9, 15, 25, 41`` に振る(大きいほど推定は安定するが、細い構造は
周りに溶ける)。``b`` が**コントラストの床**を ``max(1e-5, 0.25b x 画像の値域)`` に
振る ―― 窓の標準偏差がこれ未満なら 0 を返す(b=0 でも 1e-5 の絶対床は残る)。

``BC = (歪度^2 + 1) / 尖度`` で、窓の 1〜4 次モーメント(箱型平均 4 回)だけから
閉形式に出る。**平行移動にもスケールにも不変**なので、薄い模様でも濃い模様でも
同じ値になる。参照値は解析解で決まっていて、実測もそこへ収束する(窓 41):

* **2 点分布(半々の 2 値)= 1.0**(尖度 1 が下限)―― 段差の真上で実測 1.0000
* **一様分布 = 5/9 = 0.5556** ―― 一様乱数で実測 0.5598
* **正規分布 = 1/3 = 0.3333** ―― 正規乱数で実測 0.3306

``> 5/9`` が「一様より尖った 2 山」の古典的な目安。★**一峰でも 0 にはならない**
―― 正規分布の床は 1/3 であって 0 ではないので、使えるのは 0.33〜1.0 の帯である。

**出典と、引き継いでいる限界**(Pfister, Schwarz, Janczyk, Dale & Freeman 2013,
*Frontiers in Psychology* 4:700)。★**歪んだ単峰分布が偽陽性を出す**: 論文の図では
**明らかに単峰の分布が BC = 0.73**、**本当に二峰の分布が BC = 0.67** で、順位が
逆転している。歪度が絶対値で大きいほど、山の数と無関係に BC が上がるため。
**この op も同じ性質を持つ** —— 片側に尾を引く窓(暗い地に明るい点が少しだけ、など)は
高く出る。二峰性の判定を 1 本で決めず、``local_std`` や ``otsu`` の分離度と併せること。
なお論文の式は標本補正つき ``(m3^2+1)/(m4 + 3(n-1)^2/((n-2)(n-3)))`` で、この op は
**母集団版**を使う(窓は 81〜1,681 標本あり補正は無視できる。上の参照値 1/3・5/9・1.0 は
母集団版で厳密に成り立つ)。

**閾値を選ぶ側の一般化との関係**: Barron (2020) の Generalized Histogram Thresholding
(arXiv:2007.07350)は Otsu・Minimum Error Thresholding・重み付きパーセンタイル閾値を
特殊ケースとして包含し、**どの閾値にするか**を連続に補間する。この op は対になる側で、
**そもそも閾値が在るか**を測る。

**なぜ閾値を選ぶ op(``otsu`` / ``threshold``)の前に要るか**: 二値化はどんな画像
でも答えを返すが、山が 1 つしか無い窓では**意味の無い位置で切る**(``otsu`` の
docstring が自ら認めている限界)。この op は切る前に「そもそも分かれるのか」を
返すので、「分かれない場所は切らない」と決められる。文字のマスが 1 色の地に 1 色の
字か、板が均一に照っているか、傷が本当に地と別の階調かの判定に使う。

★**床は必須**。一様な面では分散が丸め屑になり、屑どうしの 3 次・4 次の比が構造に
化ける ―― 床を画像の値域に対する相対量だけで置いた版は、0.5 一色に振幅 1e-12〜1e-8
の屑を乗せただけの画像で **BC の最大が 1.0000** になった(値域そのものが屑なので
相対床が効かない)。絶対床 1e-5 を併せて初めて 0 に落ちる(実測)。

**正規化しない**(値は BC そのもの)ので、**画像間で比較できる**。縁は反射
(``mode="reflect"``)。空フレームは全 0。★窓が広いので**タイル分割してはいけない**
(``scale.py`` に理由つきで登録済み)。
"""
    x = np.asarray(v, np.float64)
    win = (9, 15, 25, 41)[min(3, int(float(np.clip(a, 0.0, 1.0)) * 4))]
    size = (win, win)
    m1 = ndimage.uniform_filter(x, size=size, mode="reflect")
    m2 = ndimage.uniform_filter(x * x, size=size, mode="reflect")
    m3 = ndimage.uniform_filter(x ** 3, size=size, mode="reflect")
    m4 = ndimage.uniform_filter(x ** 4, size=size, mode="reflect")
    var = np.maximum(m2 - m1 * m1, 0.0)
    mu3 = m3 - 3.0 * m1 * m2 + 2.0 * m1 ** 3
    mu4 = m4 - 4.0 * m1 * m3 + 6.0 * m1 * m1 * m2 - 3.0 * m1 ** 4
    scale = float(np.ptp(x))
    # ★相対床だけでは足りない: 一様面 + 丸め屑では**値域そのものが屑**なので、
    #   相対床も屑まで下がってしまう。絶対床 1e-5(画像は [0,1] 契約)を併せる。
    sd = max(1e-5, 0.25 * float(np.clip(b, 0.0, 1.0)) * scale)
    ok = (var > sd * sd) & (mu4 > 0.0)
    safe = np.where(ok, var, 1.0)
    skew2 = np.where(ok, mu3 * mu3 / safe ** 3, 0.0)
    kurt = np.where(ok, mu4 / (safe * safe), 1.0)
    out = np.where(ok, (skew2 + 1.0) / np.maximum(kurt, 1e-12), 0.0)
    return np.clip(out, 0.0, 1.0)


def _std_filter(v, a, b):
    """局所窓内の標準偏差（テクスチャの粗さの指標）。HALCON の ``deviation_image``（Calculate the standard deviation of gray values within rectangular windows.）に相当。

``a`` が窓サイズを ``3,5,7,9``（``_k(a)``）に振る。``b`` は未使用。``E[v²]-E[v]²`` を窓ごとに求めて平方根を取り（負の丸め誤差は 0 にクランプ）、``_norm`` で正規化する。値が大きいほどその窓内の階調が激しく変化している（テクスチャがある/エッジが多い）ことを示す。"""
    k = _k(a)
    # 平均を引いてから分散を取る。``E[x^2]-E[x]^2`` は桁落ちし、**完全に一様な画像
    # でも 1e-15 級の偽分散が残る**。``sqrt`` がそれを 3e-8 まで 8 桁持ち上げ、
    # ``_norm`` の素通し閾値 (1e-8) を越えてフルスケール化する —— 空フレームが
    # 「全面が最大テクスチャ」として返る(実測 2026-09-16: 一様 0.51 で全画素 1.0、
    # 一様 0.50 では 0.0)。GPU 経路 ``accel.py:_std_filter`` は既にこれを閾値で
    # 回避していたが、CPU 経路は直っていなかった。定数を引けば一様画像で厳密に
    # 0 になるので、閾値を置くより素性が良い。
    v0 = np.asarray(v, np.float64) - float(np.mean(v))
    m = ndimage.uniform_filter(v0, k); m2 = ndimage.uniform_filter(v0 * v0, k)
    return _norm(np.sqrt(np.maximum(m2 - m * m, 0.0)))



#: ``sigma`` の**残る偏り**を抜く係数(正規母集団)。不偏分散の平方根はまだ σ を
#: 低く見積もる —— ``c4(n) = sqrt(2/(n-1)) * Γ(n/2) / Γ((n-1)/2)``、おおよそ
#: ``1 - 1/(4n)``。窓が小さいほど効く(実測 2026-09-16: 3x3 窓では分散補正だけだと
#: 真値の 96.9%、``c4`` まで入れて 99.9%)。``gammaln`` 経由にするのは、``Γ`` を
#: 直に取ると大きい窓で溢れるため。
def _c4(n: int) -> float:
    from scipy.special import gammaln
    import math
    return math.sqrt(2.0 / (n - 1)) * math.exp(gammaln(n / 2.0) - gammaln((n - 1) / 2.0))


def _local_std(v, a, b):
    """局所窓内の標準偏差を**入力と同じ単位で**返す(正規化しない)。HALCON の ``deviation_image``（Calculate the standard deviation of gray values within rectangular windows.）に相当。

``a`` が窓の**幅**を、``b`` が窓の**高さ**をそれぞれ ``3,5,7,9``（``_k``）に振る —— HALCON の ``deviation_image(image, width, height)`` と同じく矩形窓を取れる。

**``std_filter`` との違いはここだけで、そこが肝心**: ``std_filter`` は出力をその画像の最大値で正規化するので、**画像をまたいで値を比較できない**(弱いテクスチャしか無い画像では雑音が 1.0 まで持ち上がる)。この op は割らないので、**別の画像・別の時刻の値とそのまま比べられる**。HALCON の ``deviation_image`` も正規化しないので、意味としてはこちらが忠実。平滑化フィルタの ``sigma_image`` とは別物(あちらは σ を使って平滑化する)。

**推定量と誤差(閉形式)**: 窓の画素数を ``n = 幅 x 高さ`` として、平均を引いた分散を ``n/(n-1)`` で不偏化し、さらに ``sigma`` の残る偏りを ``c4(n) ≈ 1 - 1/(4n)`` で抜く。したがって推定はほぼ無偏(実測: 真値の 99.8〜100.1%)。**1 画素あたりの相対標準誤差は ``1/sqrt(2(n-1))``** —— 3x3 窓で約 25%、9x9 窓で約 7.9%(実測が理論と一致)。粗さや雑音量を数字で言うときは、この幅を併記すること。

入力が ``[0,1]`` なら出力は ``0`` 以上 ``0.55`` 以下(最大は窓の半分が 0・半分が 1 のとき)。"""
    w, h = _k(a), _k(b)
    x = np.asarray(v, np.float64)
    # 平均を引いてから分散を取る(`_std_filter` と同じ理由 —— 桁落ちで一様面に偽分散が残る)
    x0 = x - float(np.mean(x))
    m = ndimage.uniform_filter(x0, size=(h, w))
    m2 = ndimage.uniform_filter(x0 * x0, size=(h, w))
    n = w * h
    var = np.maximum(m2 - m * m, 0.0) * (n / (n - 1.0))
    return np.sqrt(var) / _c4(n)


def _structure_tensor(x, sigma, rho):
    """構造テンソル ``J = G_rho * (grad I)(grad I)^T`` の 3 成分を返す。

    ``sigma`` は微分を取る前の平滑(雑音を微分で増幅しないため)、``rho`` は
    テンソルを積分する窓の広さ。**2 つのスケールは別物**で、``rho`` を 0 にすると
    テンソルの階数が 1 に落ちて向きしか残らない(異方度が常に 1 になる)。
    """
    g = ndimage.gaussian_filter(np.asarray(x, np.float64), sigma)
    gy, gx = np.gradient(g)
    return (ndimage.gaussian_filter(gx * gx, rho),
            ndimage.gaussian_filter(gy * gy, rho),
            ndimage.gaussian_filter(gx * gy, rho))


#: 構造テンソルが「向きを持っている」と言える下限(テンソルの跡に対する相対量)。
#: ★一様な面では勾配が丸め屑しか残らず、``arctan2`` はその屑の符号で**任意の角度**を
#: 返す —— 明るさを 0.01 変えただけで向きが一斉に変わる。絶対値の床では画像の
#: 明るさに依存してしまうので、必ず**相対量**で切る。
_ST_FLOOR = 1e-6


def _st_orientation(v, a, b):
    """局所の**縞の走る向き**(構造テンソルの主軸)を ``[0,1]`` に写して返す。

``0`` と ``1`` がともに水平、``0.5`` が垂直にあたる(向きは 180 度で一周するので、
``0`` と ``1`` は同じ向き —— **この出力を差分すると境目で偽の段差が出る**ことに注意)。

**角の向き**: 角は (行, 列) の画像座標(行は下向き)で列軸から測るので、**画面上では時計回り**。
画面上で反時計回りに θ 度回った縞は ``(180 - θ) / 180`` を返す(HALCON の
``orientation_region`` / ``orientation_xld`` = 画面上で反時計回りとは逆向き。``xg_orientation`` と同じ向き)。

``a`` が微分前の平滑 ``sigma``(0.5〜3.0 画素)、``b`` が積分窓 ``rho``(1.0〜8.0 画素)。
``rho`` は「どれくらいの広さで向きが揃っているとみなすか」で、繊維や研磨目のピッチより
大きく取る。

**適用条件**: 向きが定義できるのは**勾配が構造的に偏っている所だけ**。テンソルの
異方度が跡に対して ``1e-6`` を下回る画素(平坦面・等方な雑音)は「向き未定義」として
``0.5`` を返す —— ここで床を置かないと、一様な面で丸め屑が ``arctan2`` に増幅されて
**明るさを 0.01 変えただけで向きが一斉に反転する**。向きの確からしさは
``structure_tensor_coherence`` で別に測ること。

**用途**: 繊維強化材の繊維配向、圧延・研磨の条痕方向、木目、結晶粒の伸長方向。
HALCON に対応する単体 op は無い。"""
    x = np.asarray(v, np.float64)
    sigma = 0.5 + 2.5 * float(np.clip(a, 0.0, 1.0))
    rho = 1.0 + 7.0 * float(np.clip(b, 0.0, 1.0))
    jxx, jyy, jxy = _structure_tensor(x, sigma, rho)
    d = jxx - jyy
    mag = np.sqrt(d * d + 4.0 * jxy * jxy)          # lambda1 - lambda2
    tr = jxx + jyy                                   # lambda1 + lambda2
    scale = float(np.max(tr)) if tr.size else 0.0
    weak = mag <= max(np.finfo(np.float64).tiny, _ST_FLOOR * scale)
    th = 0.5 * np.arctan2(2.0 * jxy, d)              # 勾配の主軸 (-pi/2, pi/2]
    th = th + 0.5 * np.pi                            # 縞の向き = 勾配に直交
    return np.where(weak, 0.5, (th / np.pi) % 1.0)


def _st_coherence(v, a, b):
    """局所の**向きの揃い具合**(構造テンソルの異方度)を ``[0,1]`` で返す。

``(lambda1 - lambda2) / (lambda1 + lambda2)`` そのもの。``1`` は完全に一方向(理想的な縞)、
``0`` は等方(平坦面・白色雑音・十字の交点)。``a``/``b`` は
``structure_tensor_orientation`` と同じ 2 つのスケール。

**``structure_tensor_orientation`` と対で使う**: 向きの図は全画素に値が入るので、
向きが意味を持たない所も色がつく。この op を重みにして初めて「どこの向きを信じてよいか」
が分かる。

**適用条件と既知の落とし穴**: (1) ``b``(積分窓)が小さすぎるとテンソルの階数が 1 に
落ちて**どこでも 1 に貼りつく** —— 揃っているのではなく測れていない。(2) 2 方向が
同じ強さで交差する所(織物の交点・格子)では ``0`` に落ちる —— 「構造が無い」のでは
なく「向きが 1 つに決まらない」で、平坦面と区別できない。区別したいときは
``local_std`` を併記する。

跡が全画像最大の ``1e-6`` を下回る画素は ``0`` を返す(平坦面)。HALCON に対応する
単体 op は無い。"""
    x = np.asarray(v, np.float64)
    sigma = 0.5 + 2.5 * float(np.clip(a, 0.0, 1.0))
    rho = 1.0 + 7.0 * float(np.clip(b, 0.0, 1.0))
    jxx, jyy, jxy = _structure_tensor(x, sigma, rho)
    d = jxx - jyy
    mag = np.sqrt(d * d + 4.0 * jxy * jxy)
    tr = jxx + jyy
    scale = float(np.max(tr)) if tr.size else 0.0
    floor = max(np.finfo(np.float64).tiny, _ST_FLOOR * scale)
    return np.where(tr <= floor, 0.0, mag / np.maximum(tr, floor))


def _local_thickness(v, a, b):
    """各前景画素に「そこを覆える**最大の円の直径**」を入れて返す(局所肉厚)。

明るい側を前景とみなす閾値が ``b``(0.1〜0.9)。``a`` が測る上限の半径(1〜12 画素)で、
出力はその上限で割って ``[0,1]`` に収めてある —— **絶対値が要るときは ``a`` から
上限を逆算して掛け戻すこと**。

粒径・気孔径・肉厚を「1 枚の地図」として出す古典的な量で、モルフォロジーの
粒度測定(granulometry)と同じもの: ある画素の値が ``r`` なら、その画素は半径 ``r`` の
円による開処理を生き残る。距離変換で内接円の半径を求め、半径の大きい順にその円が
覆う範囲へ書き込む、という素直な実装。

**適用条件**: (1) 前景を 1 つの閾値で決めるので、照明むらがあると太さが場所によって
偏る —— 先に ``local_threshold`` などで平坦化すること。(2) 上限 ``a`` より太い構造は
**上限で頭打ちになる**(飽和しているかは出力の最大値が 1.0 に貼りついているかで分かる)。
(3) 画素単位の量なので、直径が 3 画素を切ると量子化の刻みが 30% を超える。

**用途**: 鋳巣・発泡体の気孔径分布、粉体の粒径、薄肉部の検出、繊維の太さ。
3-D 版は ``ops3d`` の ``vol_wall_thickness``。HALCON に対応する単体 op は無い。"""
    x = np.asarray(v, np.float64)
    rmax = 1 + int(round(float(np.clip(a, 0.0, 1.0)) * 11))       # 1..12
    thr = 0.1 + 0.8 * float(np.clip(b, 0.0, 1.0))
    mask = x > thr
    if not mask.any():
        return np.zeros_like(x)
    d = ndimage.distance_transform_edt(mask)
    out = np.zeros_like(x)
    yy, xx = np.mgrid[-rmax:rmax + 1, -rmax:rmax + 1]
    for r in range(rmax, 0, -1):
        centres = d >= r
        if not centres.any():
            continue
        disc = (yy * yy + xx * xx) <= r * r
        covered = ndimage.binary_dilation(centres, structure=disc)
        out = np.where(covered & (out == 0.0), 2.0 * r, out)
    # ★膨張は前景をはみ出す。連続の世界では半径 r の円は収まっているが、**離散の
    #   円板**で膨らませると境界の外の画素まで塗る —— 実測で前景 197 画素の円に
    #   対し外へ 48 画素(24%)漏れ、そのせいで粒度分布の生存率が 1.0 を超えた。
    #   太さは前景の量なので、必ず前景で切る。
    out = np.where(mask, out, 0.0)
    return np.clip(out / (2.0 * rmax), 0.0, 1.0)


# -------------------------------------------------------------------------- #
# 矛盾から作った 3 本(TRIZ)
#
# どれも「1 つ選ぶと損をする」形の矛盾を、選ばずに済ませることで解いている:
#   窓の大きさ -> 場所ごとに選ぶ(scale_select_std)
#   誤差の仮定 -> データ自身に測らせる(bootstrap_std_error)
#   閾値       -> 全部試して畳む(persistence_map)
# -------------------------------------------------------------------------- #
def _local_std_k(x, k):
    """窓 ``k x k`` の不偏な局所標準偏差(`_local_std` の中身を窓だけで呼べる形)。"""
    x0 = np.asarray(x, np.float64)
    x0 = x0 - float(np.mean(x0))
    m = ndimage.uniform_filter(x0, size=k)
    m2 = ndimage.uniform_filter(x0 * x0, size=k)
    n = k * k
    var = np.maximum(m2 - m * m, 0.0) * (n / (n - 1.0))
    return np.sqrt(var) / _c4(n)


def _scale_select_std(v, a, b):
    """画素ごとに**窓の大きさを選ぶ**局所標準偏差(Lepski / ICI 規則)。

窓を広げるほど推定は安定するが(相対標準誤差 ``1/sqrt(2(n-1))``)、縁がにじんで
分解能が落ちる —— **大きさを 1 つ選ぶ限りこの矛盾は解けない**。解き方は「時間でも
場所でもなく**場所ごとに別の答えを持つ**」こと: 小さい窓から順に、推定値の信頼区間が
交わり続ける間だけ窓を広げ、交わらなくなった 1 つ手前で止める。平坦な所では大きな窓
(安定)、縁の近くでは小さな窓(にじまない)が自動で選ばれる。

``a`` が試す窓の上限(``3,5,7,9,11,13,15`` のどこまでか)、``b`` が信頼区間の倍率
``gamma``(1.0〜3.0)。``gamma`` を大きくすると窓が伸びやすくなる(安定寄り)。

**``local_std`` との関係**: ``local_std`` は窓を固定する。平坦部の推定を締めたくて
窓を広げると縁がにじむ、という取引をこちらは場所ごとに解く。**縁の鋭さを保ったまま
平坦部の誤差だけ下げられる**のが取り柄で、代わりに計算量が窓の数だけ増える。

**適用条件**: (1) 「交わるか」の判定は誤差限界が正しいことに依存する —— 白色雑音
でない(空間相関のある)雑音では窓が伸びすぎる。(2) ``gamma`` が小さすぎると常に
最小窓が選ばれ、``local_std`` の 3x3 と同じになる(効いていないときの見分け方)。"""
    x = np.asarray(v, np.float64)
    all_k = (3, 5, 7, 9, 11, 13, 15)
    n_k = 1 + int(round(float(np.clip(a, 0.0, 1.0)) * (len(all_k) - 1)))
    ks = all_k[:max(2, n_k)]
    gamma = 1.0 + 2.0 * float(np.clip(b, 0.0, 1.0))
    lo = np.full(x.shape, -np.inf)
    hi = np.full(x.shape, np.inf)
    alive = np.ones(x.shape, bool)
    out = None
    for k in ks:
        s = _local_std_k(x, k)
        e = gamma * s / np.sqrt(2.0 * (k * k - 1.0))
        nlo, nhi = np.maximum(lo, s - e), np.minimum(hi, s + e)
        ok = alive & (nlo <= nhi)
        out = s.copy() if out is None else np.where(ok, s, out)
        lo, hi, alive = np.where(ok, nlo, lo), np.where(ok, nhi, hi), ok
        if not alive.any():
            break
    return out


def _bootstrap_std_error(v, a, b):
    """局所標準偏差の**標準誤差**を、分布を仮定せずに測る(ブートストラップ)。

``local_std`` が併記する誤差 ``1/sqrt(2(n-1))`` は**雑音が正規分布**という仮定の
上に立っている。外れ値や二峰性があると、その式は本当のばらつきを過小に言う。
ここでは窓の中の値を**そこから重複ありで取り直して**統計量を作り直し、その散らばり
そのものを誤差とする —— 仮定が要らない代わりに計算で買う。

``a`` が窓(3〜9 画素)、``b`` が取り直しの回数(8〜64)。出力は窓内の標準偏差に
対する**相対**標準誤差で、``1.0`` が「100 % ぶれる」。

**読み方**: **絶対値ではなく、場所ごとの比で読む**。正規分布の白色雑音に当てると
閉形式 ``1/sqrt(2(n-1))`` より**低めに出る**(ブートストラップは小標本で標準偏差の
ばらつきを過小に言う)。実測(``b=1.0``、取り直し 64 回):

    窓 3x3 (n=9)  実測 0.216 / 閉形式 0.250 = 0.86
    窓 5x5 (n=25) 実測 0.133 / 閉形式 0.144 = 0.92
    窓 7x7 (n=49) 実測 0.096 / 閉形式 0.102 = 0.94
    窓 9x9 (n=81) 実測 0.076 / 閉形式 0.079 = 0.96

つまり窓が大きくなるほど近づく。**読みどころは「どこが周りより高いか」**で、
そこは分布が正規から外れている(傷・外れ値・二つの材質の境目)。外れ値を 2 % 混ぜた
画像では中央値が閉形式の **1.8 倍**まで跳ね上がり、正規の場合(0.9 倍前後)と
はっきり分かれる —— この差が使いどころ。``local_std`` と並べて、「ばらつきの
大きさ」と「その数字の信用できなさ」を同時に見る。

**適用条件**: (1) 窓が小さいとブートストラップ自体がぶれるうえ、上のとおり
系統的に低く出る。(2) 取り直し回数(``b``)を増やすと地図は滑らかになるが、
真の誤差が下がるわけではない。(3) 決定的にするため種は固定してある —— 同じ入力なら
必ず同じ出力を返す。(4) **仮定を計算で買う op**なので遅い: 実測で 128x128 が
0.26 秒、256x256 が 1.27 秒(``b=1.0``、64 回)。閉形式で足りる場面では
``local_std`` の誤差限界を使うこと —— この op は「その閉形式が信用できるか」を
確かめたいときの道具。"""
    x = np.asarray(v, np.float64)
    k = _k(a)
    reps = 8 + int(round(float(np.clip(b, 0.0, 1.0)) * 56))       # 8..64
    pad = k // 2
    xp = np.pad(x, pad, mode="reflect")
    win = np.lib.stride_tricks.sliding_window_view(xp, (k, k))
    flat = win.reshape(x.shape[0], x.shape[1], k * k)
    rng = np.random.default_rng(20260917)                          # 決定的
    idx = rng.integers(0, k * k, size=(reps, k * k))
    stds = np.empty((reps,) + x.shape, np.float64)
    for r in range(reps):
        samp = flat[..., idx[r]]
        stds[r] = samp.std(axis=-1, ddof=1)
    base = stds.mean(axis=0)
    se = stds.std(axis=0, ddof=1)
    return np.clip(se / np.maximum(base, 1e-12), 0.0, 1.0)


def _persistence_map(v, a, b):
    """**閾値を選ばずに**「山の目立ち具合」を測る(0 次元パーシステンス)。

閾値を 1 つ選ぶと適用範囲が狭まる —— という矛盾は
「**全部の閾値を試して、結果が変わらない所だけ残す**」ことで解ける。高い方から水位を下げていき、新しい山が現れた
高さ(誕生)と、その山がより高い山に飲まれた高さ(消滅)の差を、その山の
**persistence(目立ち具合)** とする。地形でいう「突出度(prominence)」そのもの。

出力は各画素に「その画素が属する山の persistence」を入れた地図。``a`` は残す下限
(これ未満の山は 0 にする)、``b`` は連結の仕方(0.5 未満で 4 近傍、以上で 8 近傍)。

**``h_maxima`` / MSER との違い**: ``xsk2_h_maxima`` は ``h`` をひとつ選んで
「それ以上の山」を返す —— つまり閾値を 1 つ選んでいる。こちらは
**全部の h についての答えを 1 枚に畳んだもの**なので、後から好きな水準で切れる。MSER は
「面積が安定な領域」を探すので似た発想だが、あちらは領域の形、こちらは高さ。

**適用条件**: (1) 画像全体で一番高い山は消滅しないので、``最大値 - 最小値`` を
persistence とする(慣例)。**そのため背景は全体最大の値(1.0)を持つ** ——
背景は一番最後に処理され、そのときには成分がすべて併合されているので、位相的には
確かに全体成分に属する。**山の高さを読む地図であって、背景を 0 にする地図ではない**。
背景を落としたいなら閾値 op と掛けるか、``a`` で下限を上げること(``a=0.45`` で
高さ 0.3 の山だけが消え、1.0 と 0.6 は残ることを実測した)。(2) 平坦な台地(同じ値が続く)は 1 つの山として
扱われる。(3) 計算は画素を降順に走査する union-find なので、大きな画像では
``h_maxima`` より遅い。"""
    x = np.asarray(v, np.float64)
    if x.ndim == 3:
        x = x.mean(axis=2)
    h, w = x.shape
    n = h * w
    order = np.argsort(x.reshape(-1))[::-1]
    parent = np.full(n, -1, np.int64)
    birth = np.zeros(n, np.float64)
    pers = np.zeros(n, np.float64)
    root_of = np.full(n, -1, np.int64)
    eight = float(b) >= 0.5
    offs = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    if eight:
        offs += [(-1, -1), (-1, 1), (1, -1), (1, 1)]

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    flat = x.reshape(-1)
    seen = np.zeros(n, bool)
    for p in order:
        y0, x0 = divmod(int(p), w)
        parent[p] = p
        birth[p] = flat[p]
        seen[p] = True
        for dy, dx in offs:
            yy, xx = y0 + dy, x0 + dx
            if not (0 <= yy < h and 0 <= xx < w):
                continue
            q = yy * w + xx
            if not seen[q]:
                continue
            rp, rq = find(int(p)), find(q)
            if rp == rq:
                continue
            # 年長者(誕生が高いほう)が残る
            if birth[rp] >= birth[rq]:
                keep, die = rp, rq
            else:
                keep, die = rq, rp
            pers[die] = birth[die] - flat[p]
            parent[die] = keep
        root_of[p] = find(int(p))
    span = float(flat.max() - flat.min())
    # 最後まで生き残った成分(全体の最大)は消滅しないので、慣例どおり span を持たせる
    for i in range(n):
        if parent[i] == i and pers[i] == 0.0:
            pers[i] = span
    # ★各画素には「入った時点で属していた山」の persistence を入れる。
    #   ここで find(i)(= 最終的な根)を引くと、全画素が最後に残った 1 つの山の値に
    #   なってしまう —— 実測で高さ 1.0 / 0.6 / 0.3 の 3 つの山が全部 1.000 になった。
    out = pers[root_of].astype(np.float64)
    out = out.reshape(h, w)
    floor = float(np.clip(a, 0.0, 1.0)) * span
    out = np.where(out >= floor, out, 0.0)
    # ★画像の最小値そのものの台地(たいていは背景)は 0 にする。そこは最後に
    #   処理されて全体最大の山に吸収されるので、放っておくと**背景一面が最大値**に
    #   なって地図が読めない(実測で背景が 1.000 になった)。閾値を新たに選ぶのでは
    #   なく「最小値ちょうど」だけを落とすので、閾値フリーの性質は保たれる。
    out = np.where(x > flat.min(), out, 0.0)
    return np.clip(out / max(span, 1e-12), 0.0, 1.0)


# -------------------------------------------------------------------------- #
# 量子化・ビット深度
#
# HALCON 側にあるのは bit_slice / bit_and のようなビット操作だけで、量子化器
# そのもの(丸め・ディザ・最適量子化・圧伸)と、その誤差を測る道具は 1 本も無い。
# ここは閉形式の誤差(刻み Δ に対して分散 Δ²/12)を持つので、「数理解析で
# ルールベースを強化する」という方針にそのまま乗る領域。
# -------------------------------------------------------------------------- #
def _levels(a) -> int:
    """``a`` を量子化の段数 ``2**bits`` に振る(bits = 1..8)。"""
    return 1 << (1 + int(round(float(np.clip(a, 0.0, 1.0)) * 7)))


def _quantize_uniform(v, a, b):
    """一様量子化器(**丸め**)。``a`` がビット数 1〜8、``b`` は未使用。

``round(x * (L-1)) / (L-1)``、``L = 2**bits``。刻みは ``Δ = 1/(L-1)``。

**``xpil_posterize`` との違いはここで、無視できない**: あちらは PIL の実装で
**下位ビットを切り捨てる**ので、出力の平均が入力より ``Δ/2`` だけ低い。
一様分布の入力で実測すると、bits=4 で平均誤差 ``-0.0312``(理論 ``-Δ/2 = -0.03125``)。
分散はどちらも ``Δ²/12`` で同じだが、偏りがある分だけ二乗誤差が

    切り捨て: Δ²/12 + (Δ/2)² = Δ²/3     丸め: Δ²/12

と **4 倍**ちがう。明るさを測る前段に置くなら丸めでなければならない。

**適用条件と誤差(閉形式)**: 入力が刻みに対して十分ばらついている(量子化雑音が
入力と無相関とみなせる)とき、誤差は ``[-Δ/2, +Δ/2]`` の一様分布で、平均 0・
分散 ``Δ²/12``。**この仮定が崩れるのは平坦部**で、そこでは誤差が信号と相関して
縞(バンディング)になる —— 誤差を雑音として扱いたいなら ``dither_ordered`` か
``dither_floyd_steinberg`` を通すこと。段差が見えているかは ``banding_map`` で測れる。"""
    x = np.asarray(v, np.float64)
    L = _levels(a)
    q = float(L - 1)
    return np.clip(np.round(np.clip(x, 0.0, 1.0) * q) / q, 0.0, 1.0)


def _quantization_error(v, a, b):
    """量子化で失われた量 ``|x - Q(x)|`` を ``Δ/2`` で割って ``[0,1]`` にした地図。

``a`` がビット数 1〜8(``_quantize_uniform`` と同じ振り方)、``b`` は未使用。
``1.0`` が「その画素で取りうる最大の誤差(``Δ/2``)」にあたる。

**何のために見るのか**: 誤差が一様に散っていれば量子化雑音として扱ってよい。
**特定の等高線に沿って揃っていたら、そこがバンディングの出る場所**。数字で言うと、
正しく振る舞っているとき地図の平均は ``0.5`` 付近(一様分布の平均)に来る。"""
    x = np.clip(np.asarray(v, np.float64), 0.0, 1.0)
    L = _levels(a)
    delta = 1.0 / float(L - 1)
    return np.clip(np.abs(x - _quantize_uniform(x, a, b)) / (0.5 * delta), 0.0, 1.0)


def _dither_ordered(v, a, b):
    """順序ディザ(Bayer 行列)で量子化する。``a`` がビット数 1〜8、``b`` が行列の大きさ。

量子化の**前に**、画素位置で決まる決まった量(Bayer 行列、``b`` が 2x2 / 4x4 / 8x8 を
振る)を足してから丸める。平坦部の誤差が画素ごとに散るので、段差が細かい市松に化けて
**縞が見えなくなる**。誤差そのものは減らない —— 見え方を変えているだけで、
平均二乗誤差はむしろ ``_quantize_uniform`` よりわずかに大きい。

**誤差拡散(``dither_floyd_steinberg``)との使い分け**: 順序ディザは
**画素ごとに独立**なので、タイル分割しても継ぎ目が出ず、並列化も自由、
同じ入力に必ず同じ出力を返す。誤差拡散のほうが見た目は滑らかだが、
走査順に依存するので**切り出す位置を変えると結果が変わる**。"""
    x = np.clip(np.asarray(v, np.float64), 0.0, 1.0)
    L = _levels(a)
    delta = 1.0 / float(L - 1)
    n = (2, 4, 8)[min(2, int(float(np.clip(b, 0.0, 1.0)) * 3))]
    m = _bayer(n)
    H, W = x.shape[:2]
    tile = np.tile(m, (H // n + 1, W // n + 1))[:H, :W]
    if x.ndim == 3:
        tile = tile[..., None]
    q = float(L - 1)
    return np.clip(np.round(np.clip(x + (tile - 0.5) * delta, 0.0, 1.0) * q) / q, 0.0, 1.0)


def _bayer(n: int) -> np.ndarray:
    """``n x n`` の Bayer 行列を ``[0,1)`` に正規化して返す(n は 2 の冪)。"""
    m = np.array([[0.0]])
    while m.shape[0] < n:
        k = m.shape[0]
        m = np.block([[4 * m, 4 * m + 2], [4 * m + 3, 4 * m + 1]])
    # ★``m / n**2`` ではなく ``(m + 0.5) / n**2``。前者は値が {0, 1/4, 1/2, 3/4} と
    #   なって平均が 0.375 にしかならず、ディザ全体が暗い側へ偏る(1 ビットの傾斜で
    #   平均が 0.031 ずれるのを実測した)。閾値は刻みの**真ん中**に並べる。
    return (m + 0.5) / float(n * n)


def _dither_floyd_steinberg(v, a, b):
    """誤差拡散ディザ(Floyd–Steinberg)。``a`` がビット数 1〜8、``b`` は未使用。

各画素を丸めたあと、出た誤差を右 7/16・左下 3/16・下 5/16・右下 1/16 に配る。
**平均は保たれる**(局所的に足し引きが釣り合う)ので、平坦な階調が縞にならずに
点の密度で表現される。1 ビットまで落としても絵として読めるのはこれのため。

**適用条件**: (1) 走査順に依存するので、**画像を切り出す位置を変えると結果が変わる**
—— タイル処理や並列化には向かない(そちらは ``dither_ordered``)。(2) 誤差を隣へ
送るので、細い線の周りに尾を引く。(3) ここでは素直な逐次実装なので、大きな画像では
``dither_ordered`` よりずっと遅い。"""
    x = np.clip(np.asarray(v, np.float64), 0.0, 1.0)
    if x.ndim != 2:
        x = x.mean(axis=2)
    L = _levels(a)
    q = float(L - 1)
    out = x.copy()
    H, W = out.shape
    for y in range(H):
        for xi in range(W):
            old = out[y, xi]
            new = round(old * q) / q
            out[y, xi] = new
            err = old - new
            if xi + 1 < W:
                out[y, xi + 1] += err * (7.0 / 16.0)
            if y + 1 < H:
                if xi > 0:
                    out[y + 1, xi - 1] += err * (3.0 / 16.0)
                out[y + 1, xi] += err * (5.0 / 16.0)
                if xi + 1 < W:
                    out[y + 1, xi + 1] += err * (1.0 / 16.0)
    return np.clip(out, 0.0, 1.0)


def _quantize_lloyd_max(v, a, b):
    """入力の分布に合わせた**最適な**量子化(Lloyd–Max、1-D の k-means)。

``a`` が段数のビット数 1〜8、``b`` は反復回数(1〜20)。一様量子化が刻みを等間隔に
置くのに対し、こちらは**画素値が混んでいる所に刻みを細かく置く**。代表値は各区間の
重心、区間の境は隣り合う代表値の中点 —— この 2 つを交互に当てるのが Lloyd の反復で、
**二乗誤差は単調に減る**(増えることはない)。

**一様量子化との差が出る条件**: 入力のヒストグラムが偏っているとき。一様分布を
入れると一様量子化と一致するので、**差が出ないこと自体が正しさの確認になる**。
暗部に画素が集中した画像(影の多い検査画像、蛍光像)では同じビット数で誤差が下がる。

**適用条件**: (1) 出力は入力に依存した代表値の集合なので、**画像ごとに符号表が違う**
—— 別の画像と画素値を直接比べられない(比べたいなら一様量子化)。(2) 空いた区間は
そのまま残る(代表値が動かない)。(3) 反復は局所解に落ちうるが、1-D では初期値を
分位点に取れば実用上安定する。"""
    x = np.clip(np.asarray(v, np.float64), 0.0, 1.0)
    L = _levels(a)
    iters = 1 + int(round(float(np.clip(b, 0.0, 1.0)) * 19))
    flat = x.reshape(-1)
    # 初期値は分位点 —— 等間隔から始めると空の区間が残りやすい
    c = np.quantile(flat, (np.arange(L) + 0.5) / L)
    c = np.unique(c)
    if c.size < 2:
        return np.full_like(x, float(c[0]) if c.size else 0.0)
    for _ in range(iters):
        edges = 0.5 * (c[1:] + c[:-1])
        idx = np.searchsorted(edges, flat)
        tot = np.bincount(idx, weights=flat, minlength=c.size)
        cnt = np.bincount(idx, minlength=c.size)
        moved = cnt > 0
        c = np.where(moved, tot / np.maximum(cnt, 1), c)
        c = np.sort(c)
    edges = 0.5 * (c[1:] + c[:-1])
    return np.clip(c[np.searchsorted(edges, x)], 0.0, 1.0)


def _companding_mu_law(v, a, b):
    """μ 則の圧伸(compand = compress + expand)。``a`` が μ、``b`` がビット数。

``F(x) = ln(1 + mu*x) / ln(1 + mu)`` で暗部を伸ばしてから量子化し、逆変換で戻す。
結果として**刻みが暗部で細かく明部で粗くなる** —— 目も撮像系も暗部の差に敏感なので、
同じビット数で見た目の劣化が小さい。電話の音声符号化(G.711)と同じ原理で、
画像では対数的な階調割り当てにあたる。

``a`` は ``mu = 1 + 254*a``(1〜255、``a=0`` で実質そのまま)、``b`` がビット数 1〜8。

**Lloyd–Max との違い**: あちらは**その画像の分布**に合わせるので符号表が画像ごとに
変わる。こちらは**固定の曲線**なので、別の画像・別の装置と値をそのまま比べられる。
分布が対数的に偏っているという仮定が当たっていれば近い性能が出て、外れていれば
Lloyd–Max のほうが良い。

**適用条件(実測つき)**: 入力が ``[0,1]`` で、**0 付近に画素が集中している**とき。
指数分布の合成画像で一様量子化と比べると、暗部集中なら二乗誤差は ``0.57`` 倍
(3 bit)・``0.51`` 倍(5 bit)に下がる。**明部集中では逆に ``7.7`` 倍(3 bit)・
``18`` 倍(5 bit)悪化する** —— 白地に暗い傷、という検査画像はまさにこれなので、
そのときは ``1 - x`` を通してから当てること。段数が非常に少ないとき(2 bit)は
曲線が強すぎて偏った分布でも一様量子化に負ける(実測 1.17 倍)。"""
    x = np.clip(np.asarray(v, np.float64), 0.0, 1.0)
    mu = 1.0 + 254.0 * float(np.clip(a, 0.0, 1.0))
    L = _levels(b)
    q = float(L - 1)
    y = np.log1p(mu * x) / np.log1p(mu)          # 圧縮
    y = np.round(y * q) / q                       # 量子化
    return np.clip((np.expm1(y * np.log1p(mu))) / mu, 0.0, 1.0)   # 伸張


def _banding_map(v, a, b):
    """階調の**段差(バンディング)が見えている場所**を返す。``a`` がビット数、``b`` が窓。

段差が「見える」条件は 3 つそろったときで、この op はその 3 つを順に掛ける。

1. **刻みの上に乗っている** —— 値が ``k*Δ`` の格子にある。量子化していない画像に
   バンディングは無い(浮動小数の雑音はここで落ちる)。
2. **窓の中がちょうど 1 刻みだけ動く** —— 窓内の最大と最小の差(peak-to-peak)が
   ``Δ`` の 1 倍。0 倍(平坦)でも 2 倍以上(本物の輪郭)でもない。
3. **まばらな線である** —— 段差は等高線に沿った細い線として出る。広い範囲が一斉に
   反応しているなら、それは段差ではなく**ディザや細かい模様**。

``a`` は量子化のビット数 1〜8(入力が既に量子化済みなら、その段数を指定する)。
``b`` は窓の広さ(3〜9 画素)。

**この 3 段にした理由(実測)**: peak-to-peak だけで判定したところ、白色雑音で
画素の **41.7 %**、順序ディザ済みの画像で **97.7 %** が「段差」と出た —— 局所の
ptp がたまたま ``Δ`` になるだけで条件を満たしてしまうため。条件 1 が雑音を、
条件 3 がディザを落とす。3-bit に量子化した傾斜では **7.0 %**(段差の線そのもの)
が残る。

**適用条件**: (1) 入力のビット数を間違えると全く効かない —— 分からないときは
``effective_bit_depth`` で先に測る。(2) 入力が一度でも滑らかに補間・再標本化
されていると条件 1 が崩れる(格子から外れる)。段差を測るなら**量子化した直後の
画像に当てる**こと。"""
    x = np.clip(np.asarray(v, np.float64), 0.0, 1.0)
    if x.ndim == 3:
        x = x.mean(axis=2)
    L = _levels(a)
    delta = 1.0 / float(L - 1)
    k = _k(b)
    # 1. 刻みの格子に乗っているか(窓内の全画素が格子の近くにあること)
    off = np.abs(x * (L - 1) - np.round(x * (L - 1)))          # 0..0.5
    on_ladder = ndimage.maximum_filter(off, size=k) < 0.05
    # 2. 窓内の peak-to-peak がちょうど 1 刻み
    ptp = ndimage.maximum_filter(x, size=k) - ndimage.minimum_filter(x, size=k)
    one_step = np.clip(1.0 - np.abs(ptp / delta - 1.0), 0.0, 1.0)
    hot = np.where(on_ladder, one_step, 0.0)
    # 3. まばらであること —— 広い窓の半分以上が反応していたら段差ではない
    dense = ndimage.uniform_filter(hot, size=3 * k)
    return np.clip(hot * np.clip(2.0 * (1.0 - dense), 0.0, 1.0), 0.0, 1.0)


def _effective_bit_depth(v, a, b):
    """画像が**実際に**使っているビット数を推定して ``[0,1]`` に写して返す(feature)。

``8`` ビットの器に入っていても、中身が ``6`` ビット相当しかないことはよくある ——
低ビットのセンサを引き伸ばした、一度 JPEG を通した、ガンマを掛けた、など。
ここでは占有している階調の**実際の間隔**から実効ビット数を推定する:
出現した画素値を並べ、隣り合う値の差の**最頻値**を刻み ``Δ`` とみて
``bits = log2(1 + 1/Δ)``。返り値は ``bits / 16`` (``a``/``b`` は未使用)。

**適用条件と外れ方**: (1) ★**画素数が上限を決める**。階調がほぼ連続(浮動小数の
まま処理した画像)では、最小の刻みは「値が N 個あるときの平均間隔 ~1/N」なので、
推定は ``log2(N)`` 付近で頭打ちになる —— 128x128(N=16384)の連続画像で実測
**13.7 bit**。16 に飽和するわけではないので、**「これ以上は測れない」線を
画素数から先に引いておくこと**(小さな切り抜きで測ると低く出る)。(2) 非線形な変換(ガンマ・対数)を通った後は
刻みが場所によって違うので、最頻値は「代表的な刻み」であって一様な刻みではない。
(3) ディザが掛かっている画像では階調が埋まるので、実効ビット数は**高く**出る ——
それは「情報として何ビット分あるか」ではなく「何段使っているか」の答え。"""
    x = np.clip(np.asarray(v, np.float64), 0.0, 1.0)
    u = np.unique(x)
    if u.size < 3:
        return 1.0 / 16.0
    d = np.diff(u)
    d = d[d > 1e-12]
    if d.size == 0:
        return 1.0 / 16.0
    # 最頻の刻み: 差を対数ビンに落として一番混んでいる所の中央値を取る
    lo = float(d.min())
    bins = np.round(np.log2(d / lo) * 4.0).astype(int)
    vals, cnt = np.unique(bins, return_counts=True)
    step = float(np.median(d[bins == vals[int(np.argmax(cnt))]]))
    bits = float(np.log2(1.0 + 1.0 / max(step, 1e-12)))
    return float(np.clip(bits, 1.0, 16.0) / 16.0)



# --------------------------------------------------------------------------- #
# 2 つ目のノブ(``b``)に選択肢を持たせる
#
# ★**歴史的な挙動を ``b <= 0.5`` の帯に置く**。これらの op の ``b`` は 2026-09-17 まで
#   「未使用」で、保存済みの進化プログラムが持つ ``b`` の値は事実上ばらばらに散って
#   いる。新しい選択肢を上半分だけに割り当てれば、**およそ半数の既存プログラムは
#   1 ビットも結果が変わらない**(全域に割り当てると全部変わる)。
#   `b <= 0.5` が旧実装とビット一致することは tests/test_knob_b_options.py が固定する。
# --------------------------------------------------------------------------- #

#: 端の扱い。``reflect`` が scipy の既定 = これまでの挙動。
_BORDER_MODES = ("reflect", "nearest", "constant", "wrap")


def _border(b) -> str:
    """``b`` を scipy の ``mode`` に写す。``b <= 0.5`` は必ず ``reflect``。"""
    x = float(np.clip(b, 0.0, 1.0))
    # ★境目は **0.5 を含めて**歴史側に置く。0.5 は「まん中」として既定値に使われて
    #   いて(api.apply の既定、studio の中央、保存済みプログラムの初期値)、ここを
    #   新しい側に入れると**既定のまま呼んだだけで答えが変わる**。実測で gaussian と
    #   その HALCON 別名の一致検査まで割れた。
    if x <= 0.5:
        return "reflect"
    return _BORDER_MODES[1 + min(2, int((x - 0.5) / (0.5 / 3.0)))]


#: 構造要素の形。正方形 = これまでの挙動(``size=k`` の分離可能な高速経路)。
_SE_SHAPES = ("square", "cross", "disc", "line")


def _se(b, k):
    """``b`` を構造要素に写す。``b <= 0.5`` は ``None``(= 正方形の高速経路)。

    円板と十字は HALCON が ``gen_disc_se`` / 任意形状で持っているもので、
    ここが「常に正方形」だったのが 2-D 側の積み残しだった(各 op の docstring に
    「HALCON の任意形状構造要素とは異なり常に正方形」と書いてあった)。
    """
    x = float(np.clip(b, 0.0, 1.0))
    if x <= 0.5:                                     # 0.5 は歴史側(既定値のため)
        return None
    which = 1 + min(2, int((x - 0.5) / (0.5 / 3.0)))
    r = k // 2
    yy, xx = np.mgrid[-r:r + 1, -r:r + 1]
    if which == 1:
        return (yy == 0) | (xx == 0)                    # 十字
    if which == 2:
        return (yy * yy + xx * xx) <= r * r             # 円板
    return yy == 0                                      # 水平線


def _morph(fn, v, a, b):
    """``b`` で構造要素を選ぶモルフォロジー。正方形は従来どおり ``size=`` 経路。"""
    k = _k(a)
    fp = _se(b, k)
    return fn(v, size=k) if fp is None else fn(v, footprint=fp)


def _fft_mask(v, cutoff, high):
    H, W = v.shape
    rad = np.sqrt(np.fft.fftfreq(H)[:, None] ** 2 + np.fft.fftfreq(W)[None, :] ** 2)
    mask = (rad > cutoff) if high else (rad <= cutoff)
    return np.real(np.fft.ifft2(np.fft.fft2(v) * mask))


def _lowpass(v, a, b):
    """FFT による低域通過フィルタ（ぼかし）。HALCON に対応する単体 op は指定されていない。

``a`` が遮断周波数 ``cutoff = 0.05 + 0.4a``（正規化周波数、0〜0.5 がナイキストまでの範囲）を振る。``b`` は未使用。2-D FFT で ``rad <= cutoff`` の低周波成分だけを残し、逆 FFT の実部を ``[0,1]`` に clip する。``a`` が小さいほど強くぼける。境界は周期的（FFT の性質上、画像端は反対側と隣接するとみなされる）に扱われ、``ndimage`` 系フィルタの ``reflect``/``edge`` とは境界処理が異なる点に注意。"""
    return np.clip(_fft_mask(v, 0.05 + 0.4 * a, False), 0, 1)
def _highpass(v, a, b):
    """FFT による高域通過フィルタ（輪郭・高周波成分の抽出）。HALCON の ``highpass_image``（Extract high frequency components from an image.）に相当。

``a`` が遮断周波数 ``cutoff = 0.02 + 0.3a`` を振る。``b`` は未使用。2-D FFT で ``rad > cutoff`` の高周波成分だけを残し、逆 FFT の実部を ``_signed01`` で ``[0,1]`` へ写す（0.5 が「変化なし」、それより明暗が高周波成分の符号を表す）。低域フィルタ同様、境界は周期的（FFT）に扱われる。"""
    return _signed01(_fft_mask(v, 0.02 + 0.3 * a, True))
def _unsharp(v, a, b):
    """Unsharp mask. ★出口で [0,1] に clip する(2026-09-02)。

    ``v + k*(v - blur)`` は定義上オーバーシュートする(実測 min=-0.1499 /
    max=+1.1499)。`_apply` は段間で同じ clip を掛けるので
    **パイプライン結果はビット不変**だが、`fullseye.apply` を単発で呼ぶ経路だけは生値が出ていて、
    `image` の [0,1] 契約を破ったまま保存すると黒/白に潰れていた。GPU 側
    (`accel._unsharp`)も同じ clip を持つ。

**端の扱い**: 端画素を重複させて折り返す (d c b a | a b c d、scipy の既定 ``reflect``)(2026-09-16 に実測して記録)。"""
    return np.clip(v + (1.5 * a) * (v - ndimage.gaussian_filter(v, 0.5 + 1.5 * b)), 0, 1)


# --- image -> region (segmentation) ------------------------------------------ #
def _threshold(v, a, b):
    """大域しきい値処理（グローバルスレッショルド）。HALCON の ``threshold``（Segment an image using global threshold.）に相当。

``a`` がしきい値そのもの（``0〜1``）で、``v > a`` を満たす画素を前景（1）とする region を返す。``b`` は未使用。HALCON の ``threshold`` は下限・上限の 2 値を取れる帯域しきい値だが、この実装は下限のみの片側しきい値。

Raises:
    FsValueError: NaN / inf を含む画像。"""
    _require_finite_image(v, "threshold")
    return (v > a).astype(np.float64)


def _ptile_threshold(v, a, b):
    """面積率で決める P-tile しきい値を feature として返す。

``a`` を ``p = 0.001 + 0.998*a``（CDF の端を除く面積率）、``b < 0.5`` を明側、
それ以外を暗側に写す。Doyle (1962) の順位統計であり、値域の利得・オフセットを
つまみにしない。詳細な ``p`` と極性を名前付きで渡す公開 API は
``fullseye.ledger.ptile_threshold``。

**空入力は分布を持たないため拒否し、しきい値を捏造しない。**
"""
    p = 0.001 + 0.998 * float(np.clip(a, 0.0, 1.0))
    polarity = "bright" if float(b) < 0.5 else "dark"
    return _normalized_threshold.ptile_threshold(v, p=p, polarity=polarity)


def _image_standardize(v, a, b):
    """画像を標準化し、符号付き偏差を ``[0,1]`` の強度画像へ写す。

``a`` の 3 帯が ``zscore`` / ``robust`` / ``percentile``。``b`` はクリップ幅を
1〜6 尺度に写し、``-幅`` / ``+幅`` を 0 / 1、零偏差を 0.5 にする。百分位方式は
1 / 99 % を使う。生の σ 単位は ``normalized_threshold.image_standardize_raw`` を使う。
image sort が ``[0,1]`` を要求するため、登録 op は生の標準化値を返さない。

**空入力は尺度を推定できないため拒否する。定数入力は全 0.5 を返す（理由: 偏差 0
を符号付き強度表現の中立点へ写すため）。**
"""
    which = min(2, int(float(np.clip(a, 0.0, 1.0)) * 3.0))
    method = ("zscore", "robust", "percentile")[which]
    clip_sigma = 1.0 + 5.0 * float(np.clip(b, 0.0, 1.0))
    return _normalized_threshold.image_standardize(
        v, method=method, p_lo=1.0, p_hi=99.0, clip_sigma=clip_sigma)


def _sigma_threshold(v, a, b):
    """画像を頑健標準化し、``k = 2 + 3*a`` σで二値化する。

``b`` の 3 帯が明側 ``x>k`` / 暗側 ``x<-k`` / 両側 ``|x|>k``。``image`` sort
の入力は ``[0,1]`` 強度なので、この 2-D レジストリ版は中央値と 1.4826×MAD で
内部標準化してから比較する。名前付き API は既に σ 単位の入力も直接扱える。

**空入力は σ単位を検査できないため拒否し、空 region へ黙って落とさない。**
"""
    k = 2.0 + 3.0 * float(np.clip(a, 0.0, 1.0))
    polarity = ("bright", "dark", "both")[min(2, int(float(np.clip(b, 0.0, 1.0)) * 3.0))]
    return _normalized_threshold.sigma_threshold(
        v, k=k, polarity=polarity, standardization="robust").astype(np.float64)


def _otsu(v, a, b):
    """大津の判別分析法（Otsu's method）による自動しきい値処理。HALCON の ``binary_threshold``（Segment an image using binary thresholding.）に相当。

``a``, ``b`` は未使用（しきい値は入力から自動で決まる）。**入力の実際の範囲**(有限な画素の最小〜最大)を 256 ビンのヒストグラムに分け(``[0,1]`` の固定の幅ではない —— 値域の狭い像でも分解能が落ちず、アフィン変換に等変。``bin_threshold`` / ``binary_threshold`` / ``auto_threshold`` も同じ関数を通る)、クラス間分散 ``ω(1-ω)`` を最大化するビンを全探索して選び、**そのビンの上端**をしきい値として、それ以上の画素を前景とする(ビンの中点で切ると argmax ビンに居る背景画素が前景側に混ざる —— 2026-09-26 に直した。``docs/hardening/otsu-threshold-at-the-bin-midpoint.md``)。前景・背景 2 クラスの分離を仮定するため、ヒストグラムが単峰（1 山）の画像では意図しない位置で切れることがある。

**判別できない入力の扱い**（2026-09-19 の外部レビュー #7 / #8 で明文化）: 有限の画素が 1 つも無い入力（全 NaN / inf）はしきい値が定義できないので ``ValueError`` を投げる（``fullseye.apply`` の既定の方針では台帳に記録して region の既定値へ落ち、``on_error="raise"`` でそのまま止まる。以前は numpy の RuntimeWarning を出しつつ黙って全 0 を返していた）。空白フレーム（定数画像）は山が 1 つも無いので、値が 0 なら全画素が背景、0 より大きければ**全画素が前景**になる（``docs/op_blank_frame.json`` に測定あり）。定数かどうかは呼ぶ側で ``np.ptp`` 等で先に弾くこと。"""
    x = np.asarray(v, np.float64)
    if x.size and not np.isfinite(x).any():
        raise ValueError("otsu: no finite pixel in the input (all NaN/inf) — a threshold is undefined; "
                         "mask or fill the NaN first (e.g. np.nan_to_num) or check np.isfinite(img).any()")
    finite = np.isfinite(x)
    lo = float(x[finite].min()) if x.size else 0.0
    hi = float(x[finite].max()) if x.size else 1.0
    # [0,1] の外を clip すると**判別の対象そのものが潰れる**。0..255 の float
    # (8 bit 相当)を渡すと全画素が 1 に飽和し、「全画素が前景」が返っていた
    # (2026-09-06 実測: 正解との IoU が 1.0000 -> 0.2578。警告も例外も無し)。
    # 大津のしきい値はアフィン変換に等変であるべきなので、これは仕様ではなく穴。
    # ★2026-11-09 点検: [0,1] に収まる入力だけは [0,1] を 256 ビンに切っていたので、値域 0.40〜0.45 の
    #   像では分解能が全幅の 1/256 に落ち、誤分類 3.59 %(実データの範囲で切る skimage・bin_threshold は
    #   3.09 %)。同じ大津を名乗る bin_threshold と答えが割れた。いつも実データの範囲を [0,1] に
    #   伸ばしてから同じ 256 ビンに切る(定数の像は下の「正なら前景」)。
    if not hi > lo:
        return (x > 0).astype(np.float64)
    x = (x - lo) / (hi - lo)
    hist, edges = np.histogram(x, 256, (0.0, 1.0))
    p = hist.astype(np.float64) / max(1, hist.sum()); omega = np.cumsum(p)
    mids = (edges[:-1] + edges[1:]) / 2; mu = np.cumsum(p * mids); mu_t = mu[-1]
    den = omega * (1 - omega); sb = np.where(den > 1e-12, (mu_t * omega - mu) ** 2 / np.maximum(den, 1e-12), 0.0)
    # ★**しきい値は argmax ビンの「上端」で取る**(2026-09-26)。中点で取ると、
    # argmax が指すのは**背景の山を含むビン**なので、その中点より上に居る背景画素
    # 自身が前景に入る。背景 0.30 / 明部 0.90 の板では 400 px の答えが 4,096 px
    # (全画素)になり、例外も警告も出なかった —— skimage と OpenCV は同じ絵で
    # 400 を返す。ビンの上端で切れば argmax ビンの画素は全部背景側に落ちる。
    # 試験の入力に必ず雑音が載っていたため 30 年物の門が全部通していた
    # (docs/hardening/otsu-threshold-at-the-bin-midpoint.md)。
    if not np.any(den > 1e-12):
        # 占有ビンが 1 つしかない = 分けるべき山が無い(定数画像)。しきい値は
        # 定義できないので、ビン格子の都合で決めずに「正なら前景」と明示する。
        return (x > 0).astype(np.float64)
    return (x >= edges[int(np.argmax(sb)) + 1]).astype(np.float64)


#: **平坦な面を「差がある」と言わないための許容差。**
#: 適応的しきい値は「画素が周囲より明るいか」を見るが、オフセットが 0 のとき
#: ``v > filter(v)`` は「1 ULP でも明るければ真」という意味になる。完全に一様な
#: 面でも ``uniform_filter`` / ``gaussian_filter`` の積算順序によっては結果が
#: 最下位 1 ビットだけ下に丸まり、**面の全画素が前景になる**(実測 2026-09-16:
#: c=0.05 の一様画像で filter が ``-6.939e-18`` = ``spacing(0.05)`` ちょうど
#: ずれ、576 画素すべてが前景になった。c=0.06 では 0 画素)。検査では「再現しない
#: 全面欠陥」として出る。
#: 1e-9 は 16-bit 画像の量子化幅(1.5e-5)より 4 桁小さく実信号を削らない一方、
#: 丸め屑(1e-17)より 8 桁大きいので確実に切れる。
_FLAT_TOL = 1e-9


def _dyn_threshold(v, a, b):
    _require_finite_image(v, "dyn_threshold")
    return (v - ndimage.uniform_filter(v, size=_k(a))
            > (b - 0.5) * 0.4 + _FLAT_TOL).astype(np.float64)


# --- region -> region -------------------------------------------------------- #
def _reg_erode(v, a, b):
    """領域（region）の二値侵食。HALCON の ``erosion_circle``（Erode a region with a circular structuring element.）に相当。

``a`` が反復回数を ``1〜4``（``_it(a)``）に振る。``b`` は未使用。構造要素は ``scipy.ndimage.binary_erosion`` の既定（十字形、4近傍相当）で、HALCON の円形構造要素とは形が異なる（近似）。入力は ``v > 0.5`` で二値化してから処理する。"""
    return ndimage.binary_erosion(_bin(v), iterations=_it(a)).astype(np.float64)
def _reg_dilate(v, a, b):
    """領域（region）の二値膨張。HALCON の ``dilation_circle``（Dilate a region with a circular structuring element.）に相当。

``a`` が反復回数を ``1〜4``（``_it(a)``）に振る。``b`` は未使用。構造要素は scipy 既定の十字形（円形ではない、近似）。"""
    return ndimage.binary_dilation(_bin(v), iterations=_it(a)).astype(np.float64)
def _reg_open(v, a, b):
    """領域（region）の二値オープニング（侵食してから膨張）。HALCON の ``opening_circle``（Open a region with a circular structuring element.）に相当。

``a`` が反復回数を ``1〜4``（``_it(a)``）に振る。``b`` は未使用。細い突起や小さな孤立領域を除去する。構造要素は scipy 既定の十字形。"""
    return ndimage.binary_opening(_bin(v), iterations=_it(a)).astype(np.float64)
def _binary_closing_unbounded(m, iterations):
    """十字の構造要素を ``iterations`` 回 —— 画像の外へ続く平面の上の closing を画像に切り戻す(外は背景)。

    ``binary_closing`` の ``border_value=0`` は縁の前景を削り(拡大性が破れる)、``border_value=1`` は画像の外を
    前景とみなして縁の近くに楔を生やす。余白 0 を付けて閉じ、切り戻せばどちらも起きない
    (敵対的検証 2026-11-05 第 2 巡 P3)。
    """
    it = int(iterations)
    pad = it + 1
    mp = np.pad(np.asarray(m, bool), pad, mode="constant", constant_values=False)
    return ndimage.binary_closing(mp, iterations=it)[pad:-pad, pad:-pad]


def _reg_close(v, a, b):
    """領域（region）の二値クロージング（膨張してから侵食）。HALCON の ``closing_circle``（Close a region with a circular structuring element.）に相当。

``a`` が反復回数を ``1〜4``（``_it(a)``）に振る。``b`` は未使用。細い切れ込みや小さな穴を埋める。

**画像の縁**: 平面は画像の外へ続き、外は背景とみなす（余白 0 を付けて閉じてから切り戻す）。closing は拡大的（入力の前景を削らない）で、縁の近くに新しい前景も作らない。2026-11-05（敵対的検証 第 2 巡 P3）までは ``border_value=1`` で画像の外を前景とみなしており、縁の近くの孤立画素から角の楔が生えていた（20×20 の (1,1) の 1 画素が a=1 で 10 画素に）。"""
    return _binary_closing_unbounded(_bin(v), _it(a)).astype(np.float64)
def _fill_holes(v, a, b):
    """領域内の穴埋め。HALCON の ``fill_up``（Fill up holes in regions.）に相当。

``a``, ``b`` は未使用。前景に完全に囲まれた背景画素（穴）をすべて前景に変える（``scipy.ndimage.binary_fill_holes``）。画像端に接する背景は穴とみなされないため埋まらない。

**連結性**: 穴の判定に使う**背景は 4 連結**(``scipy.ndimage.binary_fill_holes`` の既定)。斜めだけで繋がった背景は繋がっているとみなさないので、市松模様では内側の背景画素がすべて穴として埋まる(8x8 で 32 -> 50 画素。実測して scipy の 4 連結参照と位置まで一致、8 連結とは不一致)。第 2 実装がここで別の連結性を選び、差分検査で露見した。"""
    return ndimage.binary_fill_holes(_bin(v)).astype(np.float64)


def _select_largest(v, a, b):
    """最大面積の連結領域だけを残す。HALCON の ``select_shape_std``（Select regions of a given shape.）に相当。

``a``, ``b`` は未使用（常に「最大」を選ぶ）。連結成分ラベリング（**前景は 8 連結** = HALCON の ``connection`` の既定。2026-11-05 敵対的検証 第 2 巡 P1 までは 4 連結で、斜めに接する 2 つの塊の片方だけを残していた）後、画素数が最大の 1 成分だけを 1、それ以外を 0 にする。入力に前景が無ければ全 0 を返す。HALCON の ``select_shape_std`` は面積以外の形状基準（円形度等）や複数選択にも対応するが、この実装は面積最大の単一選択のみ。

Raises:
    FsValueError: NaN / inf を含む画像。"""
    _require_finite_image(v, "select_largest")
    lab, n = ndimage.label(_bin(v), structure=np.ones((3, 3), bool))
    if n == 0:
        return np.zeros_like(v, np.float64)
    sizes = ndimage.sum(np.ones_like(lab), lab, index=range(1, n + 1))
    return (lab == (int(np.argmax(sizes)) + 1)).astype(np.float64)


def _remove_small(v, a, b):
    """小さい連結領域を面積で除去する。HALCON の ``select_shape``（Choose regions with the aid of shape features.）に相当。

``a`` が除去のしきい値（画素数）を、画像全体の画素数に対する割合 ``0.01〜0.16``（``(0.01+0.15a) * 画素数``）として振る。``b`` は未使用。しきい値以上の面積を持つ連結成分だけを残す。**連結性は 8 連結**（HALCON の ``connection`` の既定。2026-11-05 敵対的検証 第 2 巡 P1 までは scipy ``label`` の既定の 4 連結で、斜めに接する塊を別々に数えて小さいとみなし消していた）。"""
    lab, n = ndimage.label(_bin(v), structure=np.ones((3, 3), bool))
    if n == 0:
        return np.zeros_like(v, np.float64)
    sizes = ndimage.sum(np.ones_like(lab), lab, index=range(1, n + 1))
    thr = (0.01 + 0.15 * a) * v.size
    keep = np.zeros_like(v, np.float64)
    for i, s in enumerate(sizes, 1):
        if s >= thr:
            keep[lab == i] = 1.0
    return keep


def _invert_region(v, a, b):
    """領域の補集合（前景/背景の反転）。HALCON の ``complement``（Return the complement of a region.）に相当。

``a``, ``b`` は未使用。``v > 0.5`` で二値化してから 1 から引くだけ（前景と背景を入れ替える）。"""
    return 1.0 - _bin(v).astype(np.float64)


# --- region -> feature (measurement) ----------------------------------------- #
def _blob_count(v, a, b, connectivity=8):
    """Number of connected components in the region (HALCON `count_obj`).

    ``v > 0.5`` を前景として連結成分にラベルを付け、その個数を ``np.float64`` で返す
    (前景が無ければ 0)。``a``, ``b`` は未使用。

    2026-08-30: 8 連結既定に修正(HALCON パリティ — `connection`/計数の既定は
    8 連結。従来は scipy.ndimage.label の既定 = 4 連結で、対角接触した 2 画素を
    2 個と数えていた: KNOWN_ISSUES #1)。旧 4 連結は connectivity=4 で。

    Raises:
        FsValueError: NaN / inf を含む画像。
    """
    _require_finite_image(v, "blob_count")
    st = ndimage.generate_binary_structure(2, 2 if int(connectivity) == 8 else 1)
    _, n = ndimage.label(_bin(v), structure=st)
    return np.float64(n)


def _area_frac(v, a, b):
    """領域が占める画素の割合（面積率）を返す特徴量。HALCON の ``area_center``（Area and center of regions.）とは異なり、面積のみを返し重心は計算しない（機能の一部だけの対応）。

``a``, ``b`` は未使用。``v > 0.5`` で二値化した画素の平均値（= 前景画素数 / 全画素数）をスカラーで返す。値域は ``[0,1]``。"""
    m = _bin(v)
    if m.size == 0:
        # ★2026-10-07: 0 画素の面積率は 0/0(np.mean が NaN を返し、guard が黙って置き換えていた)
        raise ValueError("area_frac: empty region (0 pixels) — the area fraction is 0/0")
    return np.float64(np.mean(m))


# --- more image -> image ----------------------------------------------------- #
def _grad_dir(v, a, b):
    """勾配方向（エッジの向き）を画像として返す。対応する HALCON op は指定されていない（fullseye 独自）。

``a``, ``b`` は未使用。Sobel 応答から ``atan2(Gy, Gx)`` で角度（``-π〜π``）を求め、``[0,1]`` へ線形に写す。``0`` と ``1`` はどちらも同じ角度（``-π``≡``π``）に対応する周期量である点に注意——連続的に変化する向きでも出力が 0 と 1 の間で不連続にジャンプし得る。平坦な領域では勾配がほぼ 0 で方向が不定になり、ノイズの影響を受けやすい。"""
    return (np.arctan2(ndimage.sobel(v, 0), ndimage.sobel(v, 1)) + np.pi) / (2 * np.pi)


def _log(v, a, b):
    """ラプラシアン・オブ・ガウシアン（LoG）フィルタ。HALCON の ``laplace_of_gauss``（LoG-Operator (Laplace of Gaussian).）に相当。

``a`` がガウシアンの標準偏差 σ を ``0.5〜3.0`` に振る。``b`` は未使用。``scipy.ndimage.gaussian_laplace`` の絶対値を ``_norm`` で正規化する（符号を捨てているため、暗背景上の明斑点と明背景上の暗斑点を区別できない）。ブロブ（斑点状構造）検出やエッジ検出に使う。"""
    return _norm(np.abs(_log_dc_free(v, 0.5 + 2.5 * a)))


# --- more image -> region ---------------------------------------------------- #
def _canny(v, a, b):
    """簡易 Canny 風エッジ検出（region を返す）。HALCON の ``edges_image``（Extract edges using Deriche, Lanser, Shen, or Canny filters.）に対応付けられているが、非極大抑制やヒステリシスしきい値処理は行わない簡略版（近似）。

``a`` が事前平滑化のガウシアン σ を ``0.5〜2.0`` に、``b`` がしきい値を ``0.1〜0.6`` に振る。ガウシアンでぼかした画像に Sobel 勾配強度を掛け、正規化した値を ``b`` で二値化するだけ——本家 Canny の細線化（1画素幅への収束）は無いため、エッジは本来の Canny より太く、複数画素にまたがって残る。"""
    g = ndimage.gaussian_filter(v, 0.5 + 1.5 * a)
    m = _norm(np.hypot(ndimage.sobel(g, 1), ndimage.sobel(g, 0)))
    return (m > (0.1 + 0.5 * b)).astype(np.float64)


def _local_max(v, a, b):
    return ((v >= ndimage.maximum_filter(v, size=_k(a))) & (v > (0.3 + 0.4 * b))).astype(np.float64)


# --- more region ops --------------------------------------------------------- #
def _dist_transform(v, a, b):
    """ユークリッド距離変換。HALCON の ``distance_transform``（Compute the distance transformation of a region.）に相当。

``a``, ``b`` は未使用。各前景画素について最も近い背景画素までのユークリッド距離を求め（``scipy.ndimage.distance_transform_edt``）、``_norm`` でその画像内の最大値を 1 に正規化する（画像間で絶対距離の比較はできない）。骨格化・粒の中心検出等の前処理に使う。

**背景が 1 画素も無い**(全面が前景)とき、最も近い背景は画像の中に無い —— どの画素も「無限に遠い」ので、正規化した答えは**一様 1.0**(``xsp_chamfer_dist`` / ``cv_dist`` と同じ)。2026-11-05(敵対的検証 第 2 巡 P4)までは ``distance_transform_edt`` が画像の外の (-1, 0) に背景があるかのような斜面を返し、左右の反転で値が変わっていた。前景が無ければ 0。

Raises:
    FsValueError: NaN / inf を含む画像。"""
    _require_finite_image(v, "dist_transform")
    m = _bin(v)
    if m.size and m.all():
        return np.ones(m.shape, np.float64)       # 背景なし -> どこも最遠 = 正規化 1.0
    return _norm(ndimage.distance_transform_edt(m))


def _dist_transform_abs(v, a, b):
    """正規化しない絶対画素距離の距離変換。HALCON の ``distance_transform``（Compute the distance transformation of a region.）に相当。

    ``a`` で距離の種類を選ぶ: ``a < 1/3`` はユークリッド、``1/3 <= a < 2/3`` は市街地（L1）、
    それ以上はチェス盤（L∞）。``b < 0.5`` は各前景画素から最も近い背景画素までの距離、
    ``b >= 0.5`` は各背景画素から最も近い前景画素までの距離を返す。出力は float64 の画像で、
    ``dist_transform`` と違い画像内の最大値で正規化しない（背景に囲まれた 3×3 と 9×9 の正方形の
    中心はそれぞれ 2 と 5）。例: ``_dist_transform_abs(np.pad(np.ones((3, 3)), 1), 0, 0)[2, 2]`` は 2.0。

    ★2026-11-05（敵対的検証 第 2 巡 P4b）まで、この例は ``np.ones((3, 3))``（背景が無い）と書いており、
    実際の値は 2.0 でなく 2.236 だった（下の縮退入力）。

    **距離を測る相手が画像に無い**（``b < 0.5`` で背景が 1 画素も無い、``b >= 0.5`` で前景が無い）とき、
    距離は定義されない（無限）。そのときは**一様 0**（「距離場が無い」）を返す —— 空の領域は正当な入力で
    （``b >= 0.5`` の全面背景も、``b < 0.5`` の全面前景も）、例外にはしない。0 は距離として読まないこと:
    相手の有無は入力側で ``region.any()`` / ``(~region).any()`` を確かめる。どちらの向きでも一様なので
    像の反転・回転と可換。2026-11-05（敵対的検証 第 2 巡 P4）までは ``distance_transform_edt`` が画像の外の
    (-1, 0) に相手があるかのような斜面（3×3 で 1〜3.6）を、``cdt`` は一様 -1 を返していた。

    HALCON の参照 op は ``int4`` の近似を返す。この op は厳密な float64 距離を返し、
    互換 API ではない。

    Raises:
        FsValueError: NaN / inf を含む画像。
    """
    _require_finite_image(v, "dist_transform_abs")
    mask = _bin(v) if b < 0.5 else ~_bin(v)
    if mask.size and mask.all():
        return np.zeros(mask.shape, np.float64)   # 相手が無い -> 距離場なし(一様 0、斜面や -1 ではない)
    if a < (1.0 / 3.0):
        return ndimage.distance_transform_edt(mask).astype(np.float64)
    metric = "taxicab" if a < (2.0 / 3.0) else "chessboard"
    return ndimage.distance_transform_cdt(mask, metric=metric).astype(np.float64)


def _region_boundary(v, a, b):
    """領域の輪郭（境界リング）を抽出する。HALCON の ``boundary``（Reduce a region to its boundary.）に相当。

``a``, ``b`` は未使用。二値化した領域から、1 回侵食した領域を差し引くことで、幅 1 画素の輪郭を残す。**穴のある領域では穴の輪郭も返る**（「領域 − 収縮版」は定義上、外側からも穴の側からも 1 画素を残す。実測で確認）。出力は region（0/1）のまま。"""
    return (_bin(v).astype(np.float64) - ndimage.binary_erosion(_bin(v)).astype(np.float64)).clip(0, 1)


def _convex_fill(v, a, b):
    """凸包に近い形へ穴・くびれを埋める（クロージングによる近似）。HALCON の ``shape_trans``（Transform the shape of a region.）の凸包変換に相当することを意図しているが、実装は反復回数の多いクロージングであり、厳密な凸包計算ではない（近似）。

``a`` が反復回数を ``3〜6``（``_it(a)+2``）に振る。``b`` は未使用。二値クロージングを掛けるだけなので、反復回数を超える大きさのくびれ・穴は埋まらない（真の凸包なら必ず埋まる）。クロージングは画像の外へ続く平面の上で行って切り戻す（2026-11-05 敵対的検証 第 2 巡 P3 までは ``border_value=1`` で、画像の外を前景とみなして縁の近くに楔を生やしていた）。"""
    return _binary_closing_unbounded(_bin(v), _it(a) + 2).astype(np.float64)


# --- image -> contour (XLD) -------------------------------------------------- #
def _edges_sub_pix(v, a, b):
    """Gradient-band edge contours, refined to **sub-pixel** accuracy along the normal.

    ``a`` = 勾配強度のしきい値 ``0.15 + 0.5a``。返すのは XLD 輪郭 dict
    ``{"shape", "cs": [(N,2) の (row, col), ...]}``。

    ★2026-09-02: それまで返していたのは ``np.where`` が出す **整数の画素座標**
    そのもので、``sub_pix`` を名乗りながらサブピクセル精度が無かった
    (KNOWN_ISSUES #3 / docs/FULLSEYE_OP_ARTICLE_SPEC.md に「ピクセル精度実装」と
    明記されていた)。放物線当てはめによる法線方向の精密化を追加して、名前と
    実態を合わせた。**点の個数・連結成分の分け方は変えていない**(座標が 1 px
    未満動くだけ)ので、下流の輪郭選別・計数はそのまま。

    実測(真の位置が列 20.37 の合成ステップエッジ、a=0.2): 旧実装が返す列は
    {20.0, 21.0} のみで平均絶対誤差 **0.500 px**、精密化後は {20.324, 20.370} で
    平均絶対誤差 **0.0228 px**(約 22 倍改善)。

    正直な限界: 抽出母集団は「しきい値を超えた勾配帯」全体(非極大抑制は
    していない)なので、太いエッジでは帯の全画素が稜線へ寄せられて **重なった
    点**になる。1 画素幅の連鎖が要るなら `canny` を、より高精度な等値線が要るなら
    `threshold_sub_pix`(実測 0.001 px)を使うこと。
    Raises:
        FsValueError: NaN / inf を含む画像。
    """
    _require_finite_image(v, "edges_sub_pix")
    from backend_safe import gradient_normals, subpixel_refine_edges

    g, ny, nx = gradient_normals(v)
    m = _norm(g)
    lab, n = ndimage.label(m > (0.15 + 0.5 * a), structure=np.ones((3, 3)))
    cs = []
    for i in range(1, n + 1):
        ys, xs = np.where(lab == i)
        if len(ys) >= 3:
            pts = np.stack([ys, xs], 1).astype(np.float64)
            cs.append(subpixel_refine_edges(pts, m, ny, nx))
    return {"shape": v.shape, "cs": cs}


# --- contour -> contour ------------------------------------------------------ #
def _select_contours(cv, a, b):
    """点数（長さ）でフィルタして XLD 輪郭を選別する。HALCON の ``select_contours_xld``（Select XLD contours according to several features.）に相当。

``a`` が残す最小点数のしきい値を ``3〜43``（``3 + int(40a)``）に振る。``b`` は未使用。輪郭を構成する点の数（≒長さ）がしきい値未満のものを丸ごと捨てる。HALCON 版は点数以外にも円形度・凸性などの特徴で選べるが、この実装は点数のみ。"""
    thr = 3 + int(a * 40)
    return {"shape": cv["shape"], "cs": [c for c in cv["cs"] if len(c) >= thr]}


def _smooth_contours(cv, a, b):
    """移動平均による XLD 輪郭の平滑化。HALCON の ``smooth_contours_xld``（Smooth an XLD contour.）に相当。

``a`` が平滑化窓の半幅を ``1〜4``（窓長 ``2w+1 = 3,5,7,9``）に振る。``b`` は未使用。各輪郭の ``(row, col)`` 列を独立に等重み移動平均（``np.convolve`` の ``"same"`` モード）で均す。点数が窓長の 2 倍以下の短い輪郭はそのまま素通しする（平滑化されない）。"""
    w = 1 + int(a * 3); out = []
    k = np.ones(2 * w + 1) / (2 * w + 1)
    for c in cv["cs"]:
        if len(c) > 2 * w + 1:
            # ★端は**端の値で**埋める。以前は ``np.convolve(x, k, "same")`` で、
            # これは両端の w 点を**ゼロと**平均する —— 輪郭の始点と終点が
            # 原点 (0,0) の方向へ最大 50 px 以上引きずられ、輪郭 140 本ぶんの
            # 赤い筋が左上へ収束する図になった(2026-09-06、op ごとの図を初めて
            # 作ったときに発見。数値テストでは平均ずれ 0.3 px で見えなかった)。
            out.append(np.stack(
                [np.convolve(np.pad(c[:, i], w, mode="edge"), k, "valid")
                 for i in (0, 1)], 1))
        else:
            out.append(c)
    return {"shape": cv["shape"], "cs": out}


def _fit_line_contours(cv, a, b):
    """各 XLD 輪郭を 1 本の直線で近似する。HALCON の ``fit_line_contour_xld``（Approximate XLD contours by line segments.）に相当。

``a``, ``b`` は未使用。輪郭点群の重心を通り、SVD（特異値分解）で求めた第一主成分方向を直線の向きとして採用し（全点との距離二乗和を最小化する直線）、元の点群の射影範囲に等間隔に打ち直した点列に置き換える。HALCON 版は折れ線（複数線分）に分割できるが、この実装は輪郭全体を 1 本の直線にする点が異なる。点が 2 点未満の輪郭はそのまま返す。"""
    out = []
    for c in cv["cs"]:
        if len(c) >= 2:
            mean = c.mean(0)  # full_matrices=False: U は捨てるのに (N,N) を確保していた(2026-09-06 実測 20000 点で 3.73 s / 3.2 GB → 0.88 ms、Vt はビット一致)
            _, _, vt = np.linalg.svd(c - mean, full_matrices=False)
            d = vt[0]
            t = (c - mean) @ d
            out.append(mean + np.outer(np.linspace(t.min(), t.max(), max(2, len(c))), d))
        else:
            out.append(c)
    return {"shape": cv["shape"], "cs": out}


# --- contour -> region ------------------------------------------------------- #
def _contours_to_region(cv, a, b):
    """XLD 輪郭をラスタ化して region に変換する。HALCON の ``gen_region_contour_xld``（Create a region from an XLD contour.）に相当。

``a`` が仕上げに掛ける膨張の反復回数を ``1〜3``（``1 + int(2a)``）に振る。``b`` は未使用。輪郭点の実数座標を最近傍の画素へ丸めてマスクを立て、点間が疎で線がつながらないぶんを膨張で補う（サブピクセル精度は失われる）。"""
    H, W = cv["shape"]; mask = np.zeros((H, W), np.float64)
    for c in cv["cs"]:
        idx = np.clip(np.round(c).astype(int), [0, 0], [H - 1, W - 1])
        mask[idx[:, 0], idx[:, 1]] = 1.0
    return ndimage.binary_dilation(mask > 0.5, iterations=1 + int(a * 2)).astype(np.float64)


# --- contour -> feature ------------------------------------------------------ #
def _count_contours(cv, a, b):
    """輪郭（オブジェクト）の本数を返す特徴量。HALCON の ``count_obj``（Number of objects in a tuple.）に相当。

``a``, ``b`` は未使用。輪郭リストの長さをそのまま返すだけ。

- 入力は XLD 輪郭 dict ``{"shape": (H, W), "cs": [(N_i, 2), ...]}``。数えるのは ``cs`` の要素数で、各輪郭の点数・長さ・閉じているかは見ない(点が 1 つの輪郭も 1 本)。
- 返り値は ``np.float64``(sort ``feature``)。0 本なら 0.0。
- 前段の輪郭抽出(``sk_find_contours`` / ``edges_sub_pix`` / ``hx_gen_contours_skeleton``)がどう分割するかで値が決まる —— 同じ形でも 1 画素の切れ目で本数が増える。本数を安定させたいなら ``select_contours``(長さでの選別)や ``hx_union_adjacent_contours`` を間に置く。
- 「物体の数」として使うなら ``connection``(region の連結成分)+ ``count_regions`` 相当のほうが切れ目に強い。"""
    return np.float64(len(cv["cs"]))


def _total_length(cv, a, b):
    """全 XLD 輪郭の合計弧長を返す特徴量。HALCON の ``length_xld``（Length of contours or polygons.）に相当。

``a``, ``b`` は未使用。各輪郭について隣接点間のユークリッド距離を足し合わせたもの（折れ線の全長）を、全輪郭ぶん合算する。点が 2 点未満の輪郭は長さ 0 として扱われる。"""
    tot = 0.0
    for c in cv["cs"]:
        if len(c) >= 2:
            tot += float(np.sum(np.hypot(np.diff(c[:, 0]), np.diff(c[:, 1]))))
    return np.float64(tot)


# --- image -> match (template matching) -------------------------------------- #
def _ncc_map(v, T):
    """Normalized cross-correlation of template `T` over image `v` (Lewis 1995).

    Value at (y,x) is Pearson's correlation between `T` and the T-sized window
    centred there::

        sum_w (I_w - mean_w)(T - mean_T) / (||I_w - mean_w|| * ||T - mean_T||)

    so it is bounded to [-1,1], invariant to the window's brightness/contrast,
    and 1.0 exactly for a match up to a positive affine map. Raw correlation
    (no local normalization) instead peaks on whatever is brightest/largest.
    Positions where the template does not fully overlap the image, flat windows
    and a zero-energy template all score 0 (no match).

    "Flat" and "zero-energy" are judged relative to the data (template energy against its
    own magnitude, window energy against the image's RMS contrast), and the image is
    centred on its mean first, so the map is the same for ``a·v + b`` at any ``a > 0``
    (★2026-11-05 敵対的検証: the absolute ``1e-12`` floors zeroed the whole map for an
    image scaled by 1e-7, and the uncentred ``E[v²] − E[v]²`` lost a 1e-3 contrast on a
    1e5 offset).

    **Border rule (contract)**: only full-overlap positions are scored, exactly like
    ``cv2.matchTemplate`` (valid).  A target cut by the image border therefore scores 0 at
    its true position and the peak can silently move to a look-alike elsewhere
    (★2026-11-09 op 点検: a 39×39 target 2 px past the left edge scored 0.0 instead of
    0.9987 and the peak hopped 101 px to its twin).  For partial overlap use
    ``matching.ncc_map_partial`` (masked NCC, NaN = not searched) or
    ``matching.ncc_locate_ex`` (reports the overlap and whether the border was hit).

    **Non-finite image** (★2026-11-09): a NaN/inf pixel raises ``FsValueError`` (as
    ``matching._ncc_map`` does).  It used to turn the whole map into 0 silently, so
    ``ncc_locate`` returned ``[0, 0, 0]`` for one NaN pixel.  ``matching.ncc_map_partial``
    treats such pixels as missing instead.

    **Speed** (★2026-11-09): 2-D maps are computed by ``matching._ncc_map`` (FFT
    correlation + integral images, exact recomputation of unstable windows) and placed at
    the window centres; the values agree with the former direct ``ndimage.correlate``
    path to rounding: max |diff| < 1e-12 on uniform-random images (512², 480×640 and 30
    random sizes); on a smooth image with a 1e5 DC offset both paths are ~2.5e-8 from
    the exact (centred) correlation for a 15² template and ~7e-11 for 63² (the image is
    centred on its mean before the FFT — without that the error was 1.16e-4).  512×512
    with a 63×63 template went from 0.47–0.74 s to ~0.03 s; 15×15 is unchanged.
    """
    v = np.asarray(v, np.float64)
    T = np.asarray(T, np.float64)
    if T.ndim != v.ndim:
        return np.zeros_like(v)
    if v.size and not np.isfinite(v).all():
        raise FsValueError("ncc_locate: image input contains NaN or infinity — mask or fill it "
                           "first, or use matching.ncc_map_partial (treats them as missing)")
    Tz = T - float(T.mean())
    tnorm = float(np.sqrt(np.sum(Tz * Tz)))
    t_mag = float(np.max(np.abs(T))) if T.size else 0.0
    if not np.isfinite(tnorm) or tnorm == 0.0 or tnorm <= 1e-12 * t_mag * np.sqrt(T.size):
        return np.zeros_like(v)
    if v.ndim == 2:
        import matching as _matching                         # 遅延 import(循環を避ける)
        # ★2026-11-09 独立レビュー: 先に画像全体の平均を引く(旧経路と同じ中心化)。引かずに
        #   FFT へ渡すと、DC 1e5 の滑らかな画像で誤差が 3.8e-8 → 1.16e-4 に悪化した。
        vc = v - float(v.mean()) if v.size else v
        valid = _matching._ncc_map(T, vc)                    # (H-h+1, W-w+1)、左上の取り決め
        out = np.zeros_like(v)
        if valid.size:
            r0, c0 = T.shape[0] // 2, T.shape[1] // 2        # 中心の取り決めへ
            out[r0:r0 + valid.shape[0], c0:c0 + valid.shape[1]] = valid
        return out
    if v.size:
        v = v - float(v.mean())                              # NCC は v の定数加算に不変
    num = ndimage.correlate(v, Tz, mode="constant")          # sum(Tz) == 0 -> mean-free
    m1 = ndimage.uniform_filter(v, size=T.shape, mode="constant")
    m2 = ndimage.uniform_filter(v * v, size=T.shape, mode="constant")
    den = np.sqrt(np.maximum(m2 - m1 * m1, 0.0) * float(T.size)) * tnorm
    ok = np.zeros(v.shape, bool)                             # full-overlap positions only
    lo = tuple(s // 2 for s in T.shape)
    hi = tuple(n - (s - 1 - s // 2) for n, s in zip(v.shape, T.shape))
    if all(h > l for l, h in zip(lo, hi)):
        ok[tuple(slice(l, h) for l, h in zip(lo, hi))] = True
    out = np.zeros_like(v)
    # 平坦な窓の判定は画像全体の RMS コントラストに対する相対量(単位の画像では従来の 1e-12 と同程度)。
    v_rms = float(np.sqrt(np.mean(v * v))) if v.size else 0.0
    den_floor = 1e-12 * v_rms * np.sqrt(float(T.size)) * tnorm
    np.divide(num, den, out=out, where=ok & (den > den_floor) & (den > 0))
    return np.clip(out, -1.0, 1.0)


def _ncc_locate(v, a, b):
    """正規化相互相関（NCC）によるテンプレートマッチングで最良位置を探す。HALCON の ``find_ncc_model``（Find the best matches of an NCC model in an image.）に相当。

``a``, ``b`` は未使用——テンプレートは引数ではなく ``set_match_template`` でスレッドローカルな ``_MATCH_CTX`` に事前登録しておく（マッチング系 op 共通の作法、``_MatchCtx`` の docstring 参照）。``_ncc_map``（NCC 相関マップ、Lewis 1995 の定義で ``[-1,1]``）を計算し、その最大値の位置を ``[相関値, y, x]`` で返す。テンプレート未設定、または入力が 2 次元画像でない場合は ``[0,0,0]``（no-match）を返す——fail-closed。回転・スケール変化には非対応（``_shape_locate`` は回転を扱う）。

**縁の規則**: 調べるのはテンプレートの窓が画像に全部入る位置だけ（``cv2.matchTemplate`` の valid と同じ）。画像の縁で切れた対象は真の位置で調べられず、別の位置（同形の別物体など）を答えることがある。はみ出しを扱うのは ``fullseye.ncc_map_partial`` / ``fullseye.ncc_locate_ex``（重なった画素だけで相関を計り、重なり率と状態を返す）。**NaN / inf を含む画像**は例外 ``FsValueError``（``fs.op.ncc_locate`` / ``fs.apply`` は入口で拒否）。パイプライン経路（``ops.RT`` / ``run_stages``）では例外を guard が握って no-match の ``[0,0,0]`` を返し、``fs.fallbacks()`` に記録する（★2026-11-09 op 点検: 以前は NaN 1 画素でマップ全体が黙って 0 になり、記録なしに ``[0,0,0]`` を返していた）。"""
    T = _MATCH_CTX.get("template")
    if T is None or not (isinstance(v, np.ndarray) and v.ndim == 2):
        return np.array([0.0, 0.0, 0.0])
    corr = _ncc_map(v, T)
    idx = np.unravel_index(int(np.argmax(corr)), corr.shape)
    return np.array([float(corr[idx]), float(idx[0]), float(idx[1])])


# --- geometry (image -> image; calibration/rectification building blocks) ----- #
def _deskew(v, a, b):
    """**傾きを測って起こす**(deskew)。角度をノブで与えるのではなく、画像から推定する。

``a`` が探索の範囲 ``±(2 + 43a)°`` を振る(a=0 で ±2°、a=1 で ±45°)。``b`` が
精緻化の刻み ``1/(1 + round(9b))°`` を振る(b=0 で 1° 刻み、b=1 で 0.1° 刻み。
細かいほど遅い ―― ここが取引になっている)。

判定量は**横方向の射影プロファイルの差分二乗和**。ある角度で回したときに行が
揃うと、行方向に潰した濃度の折れ線が最も激しく上下する。1° 刻みで粗く探し、
最良の ±1° を ``b`` の刻みで詰める。同点なら**角度の小さい方**を採るので、
構造の無い画像・空フレームでは 0°(= 入力をそのまま返す)に落ちる。

* 探索は**長辺 256 画素に間引いた写し**で行う(角度は間引きで変わらない)。
  原寸で回すのは最後の 1 回だけ。512x512 で最も広い探索でも実測 121 ms。
* 点数は回転後の**中央の正方形**(一辺 = ``min(H,W)/sqrt(2)``)だけで取る ――
  どの角度でも枠内に収まる範囲なので、角の埋めかたが点数に混ざらない。
* **枠外は縁の中央値で埋める**(``mode="constant"``)。既存の ``rotate_image`` は
  鏡映で埋めるため、帳票を起こすと**四隅に鏡文字が写り込む**(向こうの docstring が
  自ら「枠外を背景色で埋めたい用途には向かない」と認めている)。起こしたものを
  そのまま OCR・切り出しへ渡せるのが、この op の足し前。

**実測の精度と限界**(行間 14 画素・幅 384 画素の合成頁): ``b=1``(0.1° 刻み)で
1 / 2 / 3.7 / 5 / 12 / 20° のいずれも**誤差 0.00°**。ただし **0.6° 未満の傾きは
0 を返す** ―― 頁の幅いっぱいでも行のずれが 1 画素に届かず、射影の鋭さが補間の
丸まりに埋もれるため。細かく測りたければ入力を大きくする(判定量は幅に比例する)。

**先行研究**: 射影プロファイルで傾きを測るのは古典で、Postl (1986) が**分散**を、
Baird (1987) が**二乗和 + 粗密の角度探索**を判定量にした。この op は Baird の系譜で、
新しいのは手法ではなく**縁の扱い**である(下記)。

★**以前は差分基準が +3.0 度 ずれていた。その原因が確定した。** 2026-09-17 の事前測定で、
真値 −7/−3/+3/+7 度 に対し分散基準は誤差 0.0 度、差分基準は 4 本すべて +3.0 度 ずれ、原因は
``ndimage.rotate`` が作る縁の人工物だろうが「``mode="constant"`` で消えるかは未検証」と
記録していた。**塗り方ではなく見る範囲が原因だった** —— 回転後の内接正方形だけで点を
取ると、差分基準でも 1/2/3.7/5/12/20 度 のすべてで誤差 0.00 度 になる(実測)。

**値域は入力のまま**(線形補間と縁の中央値はどちらも値域を広げない)。★空フレーム
(値域 1e-9 未満)と 8 画素未満の入力はそのまま返す。★**タイル分割してはいけない**
―― 角度は画像全体から 1 つ決まるもので、タイルごとに測ると各タイルが別々の角度で
回る(``scale.py`` に理由つきで登録済み)。
"""
    x = np.asarray(v, np.float64)
    h, w = x.shape[:2]
    if h < 8 or w < 8 or float(np.ptp(x)) < 1e-9:
        return x.copy()
    stride = max(1, int(np.ceil(max(h, w) / 256.0)))
    small = x[::stride, ::stride]
    side = int(min(small.shape) / np.sqrt(2.0))
    if side < 4:
        return x.copy()

    def score(ang: float) -> float:
        r = small if ang == 0.0 else ndimage.rotate(
            small, ang, reshape=False, order=1, mode="nearest")
        r0 = (r.shape[0] - side) // 2
        c0 = (r.shape[1] - side) // 2
        d = np.diff(r[r0:r0 + side, c0:c0 + side].sum(axis=1))
        return float(np.dot(d, d))

    t_max = 2.0 + 43.0 * float(np.clip(a, 0.0, 1.0))
    fine = 1.0 / (1 + int(round(float(np.clip(b, 0.0, 1.0)) * 9)))
    half = np.arange(0.0, t_max + 1e-9, 1.0)
    best, best_s = 0.0, -np.inf
    # 同点なら 0° 側を残すため、|角度| の小さい順に見て**厳密に**上回ったときだけ更新。
    for ang in sorted(np.unique(np.concatenate([half, -half, [t_max, -t_max]])),
                      key=lambda t: (abs(t), t)):
        s = score(float(ang))
        if s > best_s:
            best_s, best = s, float(ang)
    lo, hi = max(-t_max, best - 1.0), min(t_max, best + 1.0)
    for ang in sorted(np.unique(np.concatenate([np.arange(lo, hi + 1e-9, fine),
                                                [best, 0.0]])),
                      key=lambda t: (abs(t - best), t)):
        s = score(float(ang))
        if s > best_s:
            best_s, best = s, float(ang)
    if abs(best) < 1e-9:
        return x.copy()
    border = np.concatenate([x[0, :], x[-1, :], x[:, 0], x[:, -1]])
    return ndimage.rotate(x, best, reshape=False, order=1, mode="constant",
                          cval=float(np.median(border)))


def _rotate_img(v, a, b):
    """Rotate about the image centre by ``-45° + 90°·a`` (a=0.5 → 0°). ``b`` unused.

    ★呼び出し規約(2026-09-02 に明文化。実装は変えていない):

    * **キャンバスを変えない** (``reshape=False``)。出力の shape は入力と同じで、
      回転で枠外へ出た画素は捨てられる。
    * **枠外は鏡映で埋める** (``mode="reflect"``)。つまり回すと **四隅に元画像が
      折り返して写り込む**(帳票を回すと隅に鏡文字が出る)。

    どちらが正典かは用途で割れる。**この op の正典は「連鎖しても常に同じ形・
    同じ値域の画像が出ること」** — 進化パイプラインは image を段間で無条件に
    繋ぐので、shape が変わる/枠外に定数が入ると後段の統計(平均・分散・
    ヒストグラム)が回転量に依存して動いてしまう。鏡映は「無から作った定数」で
    はなく画像自身の統計を保つので、この用途ではこちらを採る。

    **deskew(帳票の傾き補正)には向かない**: 折り返した鏡文字が OCR / 二値化に
    そのまま乗る。背景色で埋めたい場合はこの op を使わず、
    ``scipy.ndimage.rotate(v, ang, reshape=True, mode="constant", cval=bg)`` を
    直接呼ぶこと(``fullseye.apply`` の 2 つまみ界面では背景色を渡せない)。
    同じ規約が backends_auto の ``rotate_image`` (``_sh_geom`` kind="rotate")にも
    そのまま当てはまる。
    """
    return np.clip(ndimage.rotate(v, angle=-45 + 90 * a, reshape=False, mode="reflect"), 0, 1)


def _rescale_img(v, a, b):
    """Isotropic centre-preserving rescale by ``s = 0.7 + 0.6·a``, canvas kept.

    ``b`` = **補間の次数** — ``(0, 1, 3, 3)[min(3, int(4b))]``(0 = 最近傍、
    1 = 双一次、3 = 三次スプライン)。``b=0.5`` は 3 次で、``b`` が死んでいた頃の
    既定(``ndimage`` の order=3)と **ビット一致**する。

    ★2026-09-02: それまで ``rescale_img`` / ``zoom_image_factor`` /
    ``zoom_image_size`` は **3 つとも同じ実装**(実測: 相互の最大差 0.0 と
    4.9e-14)で、3 つとも ``b`` を使っていなかった。3 つの役割を分けた:

    * ``rescale_img``      — 等方倍率 1 つ + **補間次数**(この関数)
    * ``zoom_image_factor``— 縦横 **2 つの倍率**(HALCON の ScaleHeight/ScaleWidth)
    * ``zoom_image_size``  — **目標サイズ**指定(出力 shape が変わる)

    HALCON 名も実態に合わせて ``zoom_image_size`` → ``zoom_image_factor`` へ
    付け替えた(この op はサイズではなく倍率で駆動するため)。
    """
    s = 0.7 + 0.6 * a
    order = (0, 1, 3, 3)[min(3, int(np.clip(b, 0.0, 1.0) * 4))]
    # 中心は ((H-1)/2, (W-1)/2)(画素中心の規約)。2026-11-05(敵対的検証 第 2 巡 P8 の兄弟)までは H/2。
    off = ((v.shape[0] - 1) / 2 * (1 - 1 / s), (v.shape[1] - 1) / 2 * (1 - 1 / s))
    return np.clip(ndimage.affine_transform(v, np.array([1 / s, 1 / s]), offset=off,
                                            order=order, mode="reflect"), 0, 1)


def _affine_warp(v, a, b):
    """任意のアフィン変換（回転+せん断）を画像に適用する。HALCON の ``affine_trans_image``（Apply an arbitrary affine 2D transformation to images.）に相当。

``a`` が回転角を ``-20°〜+20°`` に、``b`` がせん断量を ``-0.2〜+0.2`` に振る。回転中心は画像の中心、境界は ``reflect``（鏡映）で埋め、結果を ``[0,1]`` に clip する。平行移動・拡大縮小は含まない（``_rescale_img``/``_rotate_img`` が別 op として存在）。"""
    ang = np.deg2rad(-20 + 40 * a); sh = (b - 0.5) * 0.4
    M = np.array([[np.cos(ang), -np.sin(ang) + sh], [np.sin(ang), np.cos(ang)]])
    c = (np.array(v.shape[:2], np.float64) - 1.0) / 2.0     # 画素中心の規約(2026-11-05 P8 の兄弟、以前は shape/2)
    return np.clip(ndimage.affine_transform(v, M, offset=c - M @ c, mode="reflect"), 0, 1)


# --- more filters (OpenCV/skimage families) ---------------------------------- #
def _gabor(v, a, b):
    """Gabor energy |v * g| — an oriented band-pass texture response.

    - ``a`` — **向き** ``θ = π·a`` [rad]。カーネルの余弦は回転後の x 方向に走るので、
      ``a=0`` (θ=0) は **縦縞**(列方向に明暗が変わる模様)に最も強く応答し、
      ``a=0.5`` (θ=90°) は **横縞**に応答する。``a=1`` は θ=180° で a=0 と同じ向き。
    - ``b`` — 空間周波数 ``0.1 + 0.3·b`` [cycles/px]。

    ★正規化(2026-09-02 の修正): **カーネルの L1 ノルムで割る固定スケール**。
    以前は ``_norm`` = その画像での最大絶対値で割っていたため、**応答の大小そのもの
    が消えていた**。実測(96×96 の横縞、周波数 0.25): 生の畳み込みの平均振幅は
    θ=0° が 0.0165、θ=90° が 0.9077 で **54.9 倍**の差があるのに、``_norm`` を通すと
    平均は 0.3554 対 0.4790 = **1.35 倍**まで潰れていた —— 向きを見分けるための
    特徴量なのに識別力が消えていた(向きごとに別の除数で割っていたのだから当然)。
    ``|v| <= 1`` なら ``|v * g| <= sum|g|`` なので L1 で割れば値域 [0,1] を保ったまま
    **op を跨いで比較できる絶対スケール**になる。
    """
    theta = np.pi * a; freq = 0.1 + 0.3 * b; k = 7
    yy, xx = np.mgrid[-k:k + 1, -k:k + 1]
    xr = xx * np.cos(theta) + yy * np.sin(theta)
    g = np.exp(-(xx * xx + yy * yy) / 8.0) * np.cos(2 * np.pi * freq * xr)
    g = g - g.mean()   # DC-free (zero-mean) kernel: a Gabor is band-pass, not a brightness detector
    l1 = float(np.abs(g).sum())
    resp = np.abs(ndimage.convolve(np.clip(v, 0, 1), g, mode="reflect"))
    return np.clip(resp / l1, 0, 1) if l1 > 1e-12 else np.zeros_like(resp)


def _clip_limit_cdf(hist, climit_counts):
    """Contrast-limited CDF: clip the histogram, redistribute the excess, normalise.

    Zuiderveld (1994) の CLAHE の "CL"。各ビンを ``climit_counts`` で切り、
    切り落とした総量を全ビンへ均等に配り直してから累積して [0,1] に正規化する。
    再配分するので **CDF の終端は常に 1.0**(= 画像の最大値は 1.0 に写る)。

    ``climit_counts`` はビンの **平均カウント** を単位にした倍率で与えるのが CLAHE の
    習わし(OpenCV の ``clipLimit`` と同じ意味)。1.0 倍 = 全ビンを平均に均す =
    トーンマップが直線 = コントラスト強調ゼロ、256 倍(= ビン数)= 1 ビンが取り得る
    最大カウントなので **切り取りが一度も効かない = 素の AHE**。
    """
    h = np.asarray(hist, np.float64)
    total = float(h.sum())
    if total <= 0:
        return h
    excess = float(np.sum(np.maximum(h - climit_counts, 0.0)))
    if excess > 0:
        h = np.minimum(h, climit_counts) + excess / h.size
    cdf = np.cumsum(h)
    return cdf / cdf[-1] if cdf[-1] > 0 else cdf


def _clahe(v, a, b):
    """Contrast-Limited Adaptive Histogram Equalization (tiled, bilinearly blended).

    - ``a`` — タイル数 ``nb = 2 + int(3a)`` (画像を nb×nb に分割)
    - ``b`` — **clip limit**。ビン平均カウントに対する倍率 ``256**b`` で与える
      (``b=0`` → 1 倍 = 完全に平坦化されたヒストグラム = トーンマップ直線 =
      強調ゼロ、``b=1`` → 256 倍 = 1 ビンが取り得る最大値なので切り取りが
      効かない = 素の AHE、``b=0.5`` → 16 倍。OpenCV の既定 ``clipLimit=40`` は
      おおよそ ``b=0.665``)。

    ★2026-09-02(この修正): それまで ``b`` は **完全に死んでいた**(実測:
    ``max|clahe(x,0.5,0.0) - clahe(x,0.5,1.0)| == 0.0`` きっかり)。CLAHE の
    "C" は contrast **limited** の C であり、clip limit こそが AHE と CLAHE を
    分ける当のものなので、**実装は AHE であって CLAHE ではなかった** ——
    名前が嘘をついていた。ここで clip limit を実装して ``b`` に割り当て、
    ``b=1`` が旧実装とビット一致する端になるよう倍率を選んである
    (切り取りが起きない上限 = ビン数 256 倍)。

    Tiles PARTITION the image (linspace boundaries, so the last tile absorbs the
    H % nb / W % nb remainder), each tile's clip-limited CDF is its local tone map,
    and every pixel blends the maps of its (up to) 4 nearest tile centres with
    bilinear weights — the standard CLAHE interpolation (Zuiderveld 1994).

    2026-08-30: 補間を追加(KNOWN_ISSUES #4 — 旧実装はタイルごとに独立に平坦化
    しており、タイル境界に不連続(肉眼で見える格子)が出ていた)。タイル中心の
    近傍領域ではそのタイルの CDF がそのまま支配的なので、旧実装と同じ写像族の
    連続版になっている。
    """
    nb = 2 + int(a * 3)
    H, W = v.shape
    x = np.clip(np.asarray(v, np.float64), 0, 1)
    # clip limit を「その領域の全画素数に対する割合」で持つ。
    #   b=1 -> 256**0 = 1.0 (きっかり) -> climit = n -> どのビンも超えられない = 素の AHE
    #   b=0 -> 256**-1 = 1/256        -> climit = 平均カウント -> 完全平坦 = 強調ゼロ
    # b=1 で climit が n と **厳密に**一致するようこの形で書く(倍率を掛けてから
    # 256 で割ると丸めで n をわずかに下回り、定数タイルで余計な再配分が起きる)。
    clip_frac = 256.0 ** (float(np.clip(b, 0.0, 1.0)) - 1.0)
    ys = np.linspace(0, H, nb + 1).astype(int)
    xs = np.linspace(0, W, nb + 1).astype(int)
    cy = (ys[:-1] + ys[1:]) / 2.0                       # tile centres (pixel coords)
    cx = (xs[:-1] + xs[1:]) / 2.0
    edges = np.linspace(0.0, 1.0, 257)
    mids = (edges[:-1] + edges[1:]) / 2.0

    # Global CDF: the fallback map for degenerate (empty) tiles, which linspace
    # can produce when nb exceeds the image side.
    ghist, _ = np.histogram(x, 256, (0, 1))
    gcdf = _clip_limit_cdf(ghist, clip_frac * float(x.size))

    cdfs = np.empty((nb, nb, 256), np.float64)          # per-tile tone maps at bin mids
    for i in range(nb):
        for j in range(nb):
            blk = x[ys[i]:ys[i + 1], xs[j]:xs[j + 1]]
            if blk.size:
                hist, _ = np.histogram(blk, 256, (0, 1))
                # clip limit はタイルの画素数に対する割合(b=1 で blk.size = 切り取り無効)
                cdfs[i, j] = _clip_limit_cdf(hist, clip_frac * float(blk.size))
            else:
                cdfs[i, j] = gcdf

    def _tent(centers, n):
        """Clamped bilinear (tent) weights, one (n,) vector per tile; sums to 1."""
        pos = np.arange(n, dtype=np.float64)
        ws = []
        for i in range(len(centers)):
            w = np.zeros(n)
            if i > 0:
                gap = max(centers[i] - centers[i - 1], 1e-12)
                m = (pos >= centers[i - 1]) & (pos < centers[i])
                w[m] = (pos[m] - centers[i - 1]) / gap
            if i < len(centers) - 1:
                gap = max(centers[i + 1] - centers[i], 1e-12)
                m = (pos >= centers[i]) & (pos <= centers[i + 1])
                w[m] = np.minimum(1.0, (centers[i + 1] - pos[m]) / gap)
            else:
                w[pos >= centers[i]] = 1.0
            if i == 0:
                w[pos <= centers[0]] = 1.0
            ws.append(w)
        return ws

    wy, wx = _tent(cy, H), _tent(cx, W)
    out = np.zeros_like(x)
    for i in range(nb):
        ri = np.nonzero(wy[i] > 0)[0]
        if ri.size == 0:
            continue
        r0, r1 = int(ri[0]), int(ri[-1]) + 1            # tent support is contiguous
        for j in range(nb):
            ci = np.nonzero(wx[j] > 0)[0]
            if ci.size == 0:
                continue
            c0, c1 = int(ci[0]), int(ci[-1]) + 1
            sub = x[r0:r1, c0:c1]
            mapped = np.interp(sub.ravel(), mids, cdfs[i, j]).reshape(sub.shape)
            out[r0:r1, c0:c1] += (wy[i][r0:r1, None] * wx[j][None, c0:c1]) * mapped
    return np.clip(out, 0.0, 1.0)


def _corner_response(v, a, b):
    """Harris コーナー検出の応答値（コーナーらしさ）を画像として返す。HALCON の ``points_harris``（Detect points of interest using the Harris operator.）に相当。

``a`` が構造テンソルを平滑化するガウシアンの σ を ``0.5〜2.5`` に振る。``b`` は未使用（Harris の経験定数 ``k=0.04`` は固定）。Sobel 勾配 ``Gx, Gy`` から構造テンソル成分 ``Gx², Gy², Gx*Gy`` をガウシアンで平滑化し、``det - k*trace²`` を ``_signed01`` で ``[0,1]`` に写す（0.5 が応答ゼロ、大きいほどコーナーらしく、小さいほどエッジらしい）。座標リストではなく応答マップを返す点が HALCON の ``points_harris``（座標を返す）と異なる——極大点抽出は別途 ``_local_max`` 等と組み合わせる必要がある。"""
    gx = ndimage.sobel(v, 1); gy = ndimage.sobel(v, 0); s = 0.5 + 2.0 * a
    axx = ndimage.gaussian_filter(gx * gx, s); ayy = ndimage.gaussian_filter(gy * gy, s)
    axy = ndimage.gaussian_filter(gx * gy, s)
    return _signed01(axx * ayy - axy * axy - 0.04 * (axx + ayy) ** 2)


def _adaptive_gauss_thresh(v, a, b):
    """ガウシアン平滑化した局所平均を基準にした適応的しきい値処理。HALCON の ``local_threshold``（Segment an image using local thresholding.）に相当。

``a`` が基準を作るガウシアンの σ を ``1.0〜4.0`` に、``b`` がオフセットを ``-0.15〜+0.15``（``(b-0.5)*0.3``）に振る。``v - gaussian_filter(v, σ) > offset`` を満たす画素を前景にする。**完全に平坦な面は(オフセットが 0 でも)前景にならない** —— 差が ``1e-9`` を超えたときだけ前景とするので、一様な面で平滑化が最下位 1 ビットずれても全面が前景に反転しない。照明ムラがある画像で大域しきい値（``_threshold``/``_otsu``）より安定する。近い op に ``_dyn_threshold`` があるが、そちらは箱型平均（``uniform_filter``）を基準にし、オフセット幅も異なる（``±0.2``）——同じ「適応的しきい値」でも基準の平滑化方式とパラメータ範囲が違う別実装。"""
    return (v - ndimage.gaussian_filter(v, 1.0 + 3.0 * a)
            > (b - 0.5) * 0.3 + _FLAT_TOL).astype(np.float64)


# --- shape-based matching (rotation invariant; image -> match) --------------- #
def _shape_locate(v, a, b):
    """回転を考慮したテンプレートマッチング（shape-based matching）。HALCON の ``find_shape_model``（Find the best matches of a shape model in an image.）に相当。

``a``, ``b`` は未使用——テンプレートは ``_ncc_locate`` と同じく ``set_match_template`` で事前登録する。テンプレートを ``0°〜330°`` まで ``30°`` 刻みで回転させながらそれぞれ ``_ncc_map``（NCC）を計算し、全位置・全角度を通じて最良の相関を ``[相関値, y, x, 角度]`` で返す。角度の刻みが粗い（30°）ぶん、HALCON の ``find_shape_model`` のような連続的な角度精度は出ない——大まかな向き検出用（刻みを指定し副刻みまで詰めるのは ``matching.shape_locate_fine``）。テンプレート未設定時は ``[0,0,0,0]``。

**回転テンプレートの四隅は相関に入れない**（★2026-11-09 op 点検）。``reshape=False`` で回すと四隅が外から来るので、その画素をマスクで除き、残りの画素だけで Pearson 相関を計る（``matching._MaskedNCC``）。以前は四隅を 0 で埋めたまま相関を取っていたので、背景が 0 でない画像では正しい角度でも得点が構造的に下がった（背景 0.5・30° 回転で 0.7794 → 修正後 0.981）。調べる位置は、回したテンプレートの有効画素が全部画像の内側に入る位置だけ（角度 0 では ``ncc_locate`` の full-overlap と同じで、得点も丸め誤差で一致）。NaN / inf を含む画像は ``FsValueError``（パイプライン経路 ``ops.RT`` / ``run_stages`` では 4 要素の ``[0,0,0,0]`` を返して ``fs.fallbacks()`` に記録）。"""
    T = _MATCH_CTX.get("template")
    if T is None or not (isinstance(v, np.ndarray) and v.ndim == 2):
        return np.array([0.0, 0.0, 0.0, 0.0])
    import matching as _matching                             # 遅延 import(循環を避ける)
    v = np.asarray(v, np.float64)
    T = np.asarray(T, np.float64)
    if v.size and not np.isfinite(v).all():
        raise FsValueError("shape_locate: image input contains NaN or infinity")
    if T.ndim != 2 or T.size == 0 or not np.isfinite(T).all():
        return np.array([0.0, 0.0, 0.0, 0.0])
    engine = _matching._MaskedNCC(v, T.shape)
    best = [-1e18, 0.0, 0.0, 0.0]
    for ang in range(0, 360, 30):
        corr = _matching._shape_scores(engine, T, ang)       # masked NCC per rotation
        idx = np.unravel_index(int(np.argmax(corr)), corr.shape)
        m = float(corr[idx])
        if m > best[0]:
            best = [m, float(idx[0]), float(idx[1]), float(ang)]
    return np.array(best)


# --- classification (region -> feature; OCR/decision basis) ------------------ #
def _classify_shape(v, a, b):
    """最大の連結領域について円形度（circularity）を計算する形状分類の基礎特徴量。対応する単体の HALCON op は指定されていない。

``a``, ``b`` は未使用。最大面積の連結成分（前景は 8 連結、2026-11-05 まで 4 連結）について ``4π×面積 / 周長²`` を計算し、理想円で 1 になるよう ``min(1.0, ...)`` で頭打ちにする（数値誤差で 1 をわずかに超えるのを防ぐ）。周長は領域からその侵食を引いた境界画素数（``_region_boundary`` と同じ考え方）で近似するため、輪郭ベースの周長より粗い。前景が無ければ 0 を返す。コード中のコメントの通り、OCR・良否判定など「形状で分類する」処理の土台として使うことを想定している。"""
    lab, n = ndimage.label(_bin(v), structure=np.ones((3, 3), bool))
    if n == 0:
        return np.float64(0.0)
    sizes = ndimage.sum(np.ones_like(lab), lab, index=range(1, n + 1))
    mask = lab == (int(np.argmax(sizes)) + 1)
    area = float(mask.sum())
    per = float((mask.astype(np.float64) - ndimage.binary_erosion(mask).astype(np.float64)).sum())
    return np.float64(min(1.0, 4 * np.pi * area / (per * per)) if per > 0 else 0.0)  # ~1 circle


# --- barcode-lite (image -> feature; count dark bars on the mid scanline) ---- #
def _decode_barcode(v, a, b):
    """中央走査線上の明暗の切り替わり回数を数える簡易バーコード風特徴量。HALCON の ``find_bar_code``（Detect and read bar code symbols in an image.）とは似て非なるもので、シンボル体系の判定やデータのデコードは一切行わない（バー「数」を数えるだけ）。

``a`` が「暗い」とみなすしきい値を ``0.3〜0.7`` に振る。``b`` は未使用。画像中央の行（``v.shape[0]//2``）だけを見て、``v < しきい値`` の画素を 1 とした列に対し、0→1 に立ち上がる回数（暗いバーの本数）を数える。実際のバーコードのデータ（数字・文字列）は得られない。"""
    row = (v[v.shape[0] // 2] < (0.3 + 0.4 * a)).astype(int)
    return np.float64(int((np.diff(np.concatenate([[0], row, [0]])) == 1).sum()))


# --- 3D volume ops (scipy.ndimage is N-D; CT/MRI/depth stacks) --------------- #
def _vol_gaussian(v, a, b):
    """3D ボリュームの等方ガウシアン平滑化。対応する HALCON op は指定されていない。

``a`` が標準偏差 σ を ``0.3〜3.0``（``0.3+2.7a``）に振る。``b`` が**端の扱い**を選ぶ: ``b <= 0.5`` で ``reflect``(端画素を複製して折り返す。scipy の既定で、2026-09-17 までの挙動)、以降 ``nearest`` / ``constant``(0 で埋める)/ ``wrap``(反対側から巻き取る)。★**σ が 0.375 未満(``a`` が約 0.028 未満)だと ``reflect`` と ``nearest`` が原理的に一致する**(``scipy`` の窓の半径は ``int(4σ + 0.5)`` で、ここでは 1 画素。はみ出しが 1 画素なので複製先が同じ)—— 端の扱いを変えたのに結果が動かないときは、まず σ の小ささを疑うこと(σ = 1 では最大 0.05 程度変わる)。``scipy.ndimage`` は次元非依存（N-D）なので、2-D の ``_gaussian`` と全く同じ式をそのまま 3 軸（CT/MRI/深度スタック等）に適用する。"""
    return ndimage.gaussian_filter(v, sigma=0.3 + 2.7 * a, mode=_border(b))


def _vol_median(v, a, b):
    """3D ボリュームのメディアンフィルタ。対応する HALCON op は指定されていない。

窓サイズは ``3``（3×3×3）に固定——``a``, ``b`` はどちらも未使用（2-D 版 ``_median`` と異なり ``_k(a)`` を使っていないため、進化パラメータで強さを変えられない）。"""
    return ndimage.median_filter(v, size=3)


def _vol_erode(v, a, b):
    """3D ボリュームのグレースケール侵食。対応する HALCON op は指定されていない。

構造要素の一辺は ``size = 1 + 2*(1 + int(a))``。``a`` は ``[0,1)`` の範囲では ``int(a)`` が常に 0 になるため実質サイズ ``3`` 固定で、``a`` が ``1.0``（``decode`` の ``np.clip`` で上限に張り付いたとき）になったときだけ ``5`` に切り替わる、実質 2 値スイッチにしかなっていない（``_vol_dilate`` も同じ式で同じ性質）。``b`` も未使用。"""
    return ndimage.grey_erosion(v, size=1 + 2 * (1 + int(a)))


def _vol_dilate(v, a, b):
    """3D ボリュームのグレースケール膨張。対応する HALCON op は指定されていない。

``_vol_erode`` と同じ式 ``size = 1 + 2*(1 + int(a))`` を使うため、``a`` はほぼ効かない（``a`` が ``[0,1)`` の間は ``int(a)`` が常に 0 で実質サイズ ``3`` 固定、``a=1.0`` のときだけ ``5``）。``b`` も未使用。半径を連続的に振りたい場合は球形構造要素版（``_vol_dilation_ball`` 等、``int(a*3)`` を使い ``a`` が実際に効く）を使うこと。"""
    return ndimage.grey_dilation(v, size=1 + 2 * (1 + int(a)))


def _vol_threshold(v, a, b):
    """3D ボリュームの大域しきい値処理（2-D の ``_threshold`` の 3D 版）。対応する HALCON op は指定されていない。

``a`` がしきい値そのもの（``0〜1``）で、``v > a`` を満たすボクセルを 1 にする。``b`` は未使用。出力は二値ボリューム（0/1 の float64）。"""
    return (v > a).astype(np.float64)                    # volume -> binary volume


# 3D 二値(領域)モルフォロジ(2026-08-31)。accel_vol に GPU kernel が先に実装
# 済みで core 名が無く bridge から永久に到達不能だった層 — ここが SoT になる。
# cross = 6 近傍(generate_binary_structure(3,1))、ball = x²+y²+z²<=r²
# (skimage.morphology.ball と同式)。境界は scipy 既定 border_value=0(背景)。
def _vol_ball_fp(r):
    if r <= 0:
        return np.ones((1, 1, 1), bool)
    zz, yy, xx = np.mgrid[-r:r + 1, -r:r + 1, -r:r + 1]
    return (xx * xx + yy * yy + zz * zz) <= r * r


def _vol_reg_dilate(v, a, b):
    """3D 二値領域の膨張（region ボリュームの膨張）。対応する HALCON op は指定されていない。

``a`` が反復回数を ``1〜4``（``max(1, 1+int(3a))``）に振る。``b`` は未使用。構造要素は 6 近傍（``generate_binary_structure(3,1)``、十字形）。反復回数を明示的に ``1`` 以上へクランプしているのは、scipy が ``iterations<1`` を「収束するまで反復」と解釈し、``a`` が小さい側で全充填・全消去に発散するのを防ぐため（敵対的レビューで見つかった不具合の修正、D3）。"""
    # iterations は 1 以上へクランプ。scipy は iterations<1 を「収束まで反復」と
    # 解釈するため、a<0 を渡すと全充填/全消去に発散する(敵対レビュー D3)
    st = ndimage.generate_binary_structure(3, 1)
    return ndimage.binary_dilation(_bin(v), st, iterations=max(1, 1 + int(a * 3))).astype(np.float64)


def _vol_reg_erode(v, a, b):
    """3D 二値領域の侵食（region ボリュームの侵食）。対応する HALCON op は指定されていない。

``a`` が反復回数を ``1〜4``（``max(1, 1+int(3a))``）に振る。``b`` は未使用。構造要素は 6 近傍（十字形）。``_vol_reg_dilate`` と同じ理由で反復回数を ``1`` 以上にクランプしている。"""
    st = ndimage.generate_binary_structure(3, 1)
    return ndimage.binary_erosion(_bin(v), st, iterations=max(1, 1 + int(a * 3))).astype(np.float64)


def _vol_dilation_ball(v, a, b):
    """球形構造要素による 3D 二値膨張。対応する HALCON op は指定されていない。

``a`` が球の半径を ``1〜4``（``1+int(3a)``）に振る。``b`` は未使用。球は ``x²+y²+z² <= r²`` で作る（``skimage.morphology.ball`` と同じ定義）。``_vol_reg_dilate``（6近傍固定）より広い近傍を扱え、``a`` で半径そのものを直接変えられる。"""
    return ndimage.binary_dilation(_bin(v), _vol_ball_fp(1 + int(a * 3))).astype(np.float64)


def _vol_erosion_ball(v, a, b):
    """球形構造要素による 3D 二値侵食。対応する HALCON op は指定されていない。

``a`` が球の半径を ``1〜4``（``1+int(3a)``）に振る。``b`` は未使用。球の定義は ``_vol_dilation_ball`` と同じ。"""
    return ndimage.binary_erosion(_bin(v), _vol_ball_fp(1 + int(a * 3))).astype(np.float64)


def _vol_opening_ball(v, a, b):
    """球形構造要素による 3D 二値オープニング（侵食してから同じ球で膨張）。対応する HALCON op は指定されていない。

``a`` が球の半径を ``1〜4``（``1+int(3a)``）に振る。``b`` は未使用。侵食と膨張に同じ半径の球を使うため、球より小さい突起・細い連結だけを選択的に除去する。"""
    fp = _vol_ball_fp(1 + int(a * 3))
    return ndimage.binary_dilation(
        ndimage.binary_erosion(_bin(v), fp), fp).astype(np.float64)


def _vol_mip(v, a, b):
    """最大値投影（Maximum Intensity Projection, MIP）で 3D ボリュームを 2D 画像に潰す。対応する HALCON op は指定されていない。

``a``, ``b`` は未使用。先頭軸（``axis=0``、スライス/深さ方向）に沿った最大値を取り、``_norm`` でそのスライスの最大絶対値を 1 に正規化する。CT/MRI の読影でよく使う投影法。"""
    return _norm(np.max(v, axis=0))                      # volume -> image (max-intensity projection)


def _vol_slice(v, a, b):
    """3D ボリュームから 1 枚の 2D スライスを取り出す。対応する HALCON op は指定されていない。

``a`` が取り出すスライス番号を先頭軸（``axis=0``）に沿って ``0`` から ``shape[0]-1`` まで線形に振る（``int(a * shape[0])`` を範囲内にクランプ）。``b`` は未使用。値は ``[0,1]`` に clip して返す（3D フィルタ後に生じ得るオーバーシュートの後始末）。"""
    return np.clip(v[min(v.shape[0] - 1, int(a * v.shape[0]))], 0, 1)  # volume -> image


def _vol_count(v, a, b):
    """3D ボリューム中の連結成分（ブロブ）の個数を返す特徴量。対応する HALCON op は指定されていない。

``a``, ``b`` は未使用。しきい値は ``0.5`` に固定（``v > 0.5`` で二値化してから ``scipy.ndimage.label``）。連結性は scipy の既定構造要素（面で接する 6 近傍相当）で、稜・頂点だけで接する（26 近傍でしか繋がらない）ボクセルは別ブロブとして数えられる——2-D の ``_blob_count`` が HALCON パリティのため 8 連結を明示指定しているのとは対照的に、こちらは既定のまま連結性を明示していない。"""
    return np.float64(ndimage.label(np.asarray(v) > 0.5)[1])          # volume -> feature (3D blobs)


@dataclass
class Op:
    name: str
    category: str
    halcon: str
    in_sort: str
    out_sort: str
    fn: Callable
    c_stmt: Optional[Callable[[float, float], str]] = None
    #: op の説明。**関数の docstring が第一の置き場**で、これはその代わりが要る
    #: ときの受け皿 —— backend の op 表は lambda で書かれているものが多く、
    #: lambda に docstring は書けない。各 backend が module-level ``DOCS``
    #: (op 名 -> 説明)を出すと、下の登録ループがここへ入れる。
    #: 読む側(``tools/opdocs.py`` / Studio ヘルプ)は ``fn.__doc__ or op.doc``。
    doc: str = ""

    def __reduce__(self):
        # ★pickle は**名前で**(2026-09-19 外部レビュー N5): ``fn`` は ``backend_safe._safe``
        # のクロージャで pickle できず、Op を丸ごと multiprocessing / joblib に渡すと
        # PicklingError で止まっていた(``Pipeline`` は名前を持つので通る、という非対称)。
        # 復元先は**復元する側の環境の登録**: backend が入っていない環境で戻すと
        # KeyError(不足 extra の案内つき)になり、黙って別の実装にはならない。
        return (_op_from_name, (self.name,))


def _op_from_name(name: str) -> "Op":
    """pickle の復元先(``Op.__reduce__``)。名前をこの環境の登録で引く。"""
    op = _BY_NAME.get(name)
    if op is None:
        raise KeyError("operator %r is not registered in this environment (unpickling an Op resolves "
                       "by name; install the backend extra it needs — fullseye.apply(img, %r) explains which)"
                       % (name, name))
    return op


def _cf(x: float) -> str:
    """A C ``float`` literal equal to ``(float)x``.

    ★2026-11-05 redteam I21: knobs were written with ``%.6f``, so a threshold 0.3921566 became
    ``0.392157f`` -- a different float32 -- and a pixel of 100/255 (between the two) thresholded
    to 1 in Python and 0 in the generated C. The literal is now the shortest decimal of
    ``np.float32(x)`` itself (round-to-nearest-even, the same as C's ``(float)x``); that decimal
    is within half a float64 ulp of the float32, so the compiler reads back exactly that float
    (no double rounding near a float32 midpoint). A ``.0`` is added when the text would
    otherwise be an integer literal (``1f`` is not valid C)."""
    text = repr(float(np.float32(x)))
    if not any(ch in text for ch in ".eEn"):                    # "1" -> "1.0" ("nan"/"inf" excluded)
        text += ".0"
    return text + "f"


def _c(name):
    return {
        "gaussian": lambda a, b: f"gaussian(buf, w, h, {_cf(0.3 + 2.7 * a)});",
        "mean_box": lambda a, b: f"box(buf, w, h, {_k(a)});",
        "gamma": lambda a, b: f"gamma_op(buf, w, h, {_cf(0.5 + 1.5 * a)});",
        "invert": lambda a, b: "invert(buf, w, h);",
        "scale_clip": lambda a, b: f"scale_clip(buf, w, h, {_cf(0.5 + 1.5 * a)}, {_cf(b - 0.5)});",
        "threshold": lambda a, b: f"threshold(buf, w, h, {_cf(a)});",
        "unsharp": lambda a, b: f"sharpen(buf, w, h, {_cf(1.5 * a)}, {_cf(0.5 + 1.5 * b)});",
        "sobel_mag": lambda a, b: "sobel_mag(buf, w, h);",
    }.get(name)


_DEFS = [
    ("identity", "misc", "copy_image", ANY, ANY, _identity),
    # image -> image
    ("gaussian", "smoothing", "gauss_filter", IMAGE, IMAGE, _gaussian),
    ("mean_box", "smoothing", "mean_image", IMAGE, IMAGE, _mean_box),
    ("mean_box_wh", "smoothing", "mean_image", IMAGE, IMAGE, _mean_box_wh),
    ("bilateral", "smoothing", "bilateral_filter", IMAGE, IMAGE, _bilateral),
    ("kuwahara", "smoothing", None, IMAGE, IMAGE, _kuwahara),
    ("unsharp", "smoothing", "emphasize", IMAGE, IMAGE, _unsharp),
    ("median", "rank", "median_image", IMAGE, IMAGE, _median),
    ("min_filter", "rank", "gray_erosion_rect", IMAGE, IMAGE, _min_filter),
    ("max_filter", "rank", "gray_dilation_rect", IMAGE, IMAGE, _max_filter),
    ("percentile", "rank", "rank_image", IMAGE, IMAGE, _percentile),
    ("gerode", "morphology", "gray_erosion", IMAGE, IMAGE, _erode_g),
    ("gdilate", "morphology", "gray_dilation", IMAGE, IMAGE, _dilate_g),
    ("gopen", "morphology", "gray_opening", IMAGE, IMAGE, _open_g),
    ("gclose", "morphology", "gray_closing", IMAGE, IMAGE, _close_g),
    ("runlength_smear", "morphology", None, IMAGE, IMAGE, _runlength_smear),
    ("tophat", "morphology", "gray_tophat", IMAGE, IMAGE, _tophat),
    ("bothat", "morphology", "gray_bothat", IMAGE, IMAGE, _bothat),
    ("morph_grad", "morphology", "gray_range_rect", IMAGE, IMAGE, _morph_grad),
    ("sobel_mag", "edges", "sobel_amp", IMAGE, IMAGE, _sobel_mag),
    ("laplace", "edges", "laplace", IMAGE, IMAGE, _laplace),
    ("prewitt_mag", "edges", "prewitt_amp", IMAGE, IMAGE, _prewitt_mag),
    ("roberts_mag", "edges", "roberts", IMAGE, IMAGE, _roberts_mag),
    ("dog", "edges", "diff_of_gauss", IMAGE, IMAGE, _dog),
    ("edge_transition_width", "edges", None, IMAGE, IMAGE, _edge_transition_width),
    ("gamma", "gray", "pow_image", IMAGE, IMAGE, _gamma),
    ("quantize_uniform", "gray", None, IMAGE, IMAGE, _quantize_uniform),
    ("quantize_lloyd_max", "gray", None, IMAGE, IMAGE, _quantize_lloyd_max),
    ("quantization_error", "gray", None, IMAGE, IMAGE, _quantization_error),
    ("dither_ordered", "gray", None, IMAGE, IMAGE, _dither_ordered),
    ("dither_floyd_steinberg", "gray", None, IMAGE, IMAGE, _dither_floyd_steinberg),
    ("companding_mu_law", "gray", None, IMAGE, IMAGE, _companding_mu_law),
    ("banding_map", "gray", None, IMAGE, IMAGE, _banding_map),
    ("effective_bit_depth", "features", None, IMAGE, FEATURE, _effective_bit_depth),
    ("invert", "gray", "invert_image", IMAGE, IMAGE, _invert),
    ("scale_clip", "gray", "scale_image", IMAGE, IMAGE, _scale_clip),
    ("equalize", "gray", "equ_histo_image", IMAGE, IMAGE, _equalize),
    ("sigmoid", "gray", "scale_image_max", IMAGE, IMAGE, _sigmoid),
    ("lowpass", "frequency", "", IMAGE, IMAGE, _lowpass),
    ("highpass", "frequency", "highpass_image", IMAGE, IMAGE, _highpass),
    ("std_filter", "texture", "deviation_image", IMAGE, IMAGE, _std_filter),
    ("local_bimodality", "texture", None, IMAGE, IMAGE, _local_bimodality),
    ("local_std", "texture", None, IMAGE, IMAGE, _local_std),
    ("scale_select_std", "texture", None, IMAGE, IMAGE, _scale_select_std),
    ("xdog", "edges", None, IMAGE, IMAGE, _xdog),
    ("bootstrap_std_error", "texture", None, IMAGE, IMAGE, _bootstrap_std_error),
    ("persistence_map", "morphology", None, IMAGE, IMAGE, _persistence_map),
    ("structure_tensor_orientation", "texture", None, IMAGE, IMAGE, _st_orientation),
    ("structure_tensor_coherence", "texture", None, IMAGE, IMAGE, _st_coherence),
    ("local_thickness", "morphology", None, IMAGE, IMAGE, _local_thickness),
    # image -> region (segmentation)
    ("threshold", "segmentation", "threshold", IMAGE, REGION, _threshold),
    ("ptile_threshold", "segmentation", "", IMAGE, FEATURE, _ptile_threshold),
    ("image_standardize", "gray", "", IMAGE, IMAGE, _image_standardize),
    ("sigma_threshold", "segmentation", "", IMAGE, REGION, _sigma_threshold),
    ("otsu", "segmentation", "binary_threshold", IMAGE, REGION, _otsu),
    ("dyn_threshold", "segmentation", "dyn_threshold", IMAGE, REGION, _dyn_threshold),
    # region -> region
    ("reg_erode", "region", "erosion_circle", REGION, REGION, _reg_erode),
    ("reg_dilate", "region", "dilation_circle", REGION, REGION, _reg_dilate),
    ("reg_open", "region", "opening_circle", REGION, REGION, _reg_open),
    ("reg_close", "region", "closing_circle", REGION, REGION, _reg_close),
    ("fill_holes", "region", "fill_up", REGION, REGION, _fill_holes),
    ("select_largest", "region", "select_shape_std", REGION, REGION, _select_largest),
    ("remove_small", "region", "select_shape", REGION, REGION, _remove_small),
    ("invert_region", "region", "complement", REGION, REGION, _invert_region),
    # region -> feature (measurement)
    ("blob_count", "features", "count_obj", REGION, FEATURE, _blob_count),
    ("area_frac", "features", "area_center", REGION, FEATURE, _area_frac),
    # extra image ops
    ("grad_dir", "edges", "", IMAGE, IMAGE, _grad_dir),
    ("log", "edges", "laplace_of_gauss", IMAGE, IMAGE, _log),
    # extra segmentation (image -> region)
    ("canny", "segmentation", "edges_image", IMAGE, REGION, _canny),
    ("local_max", "segmentation", "local_max_sub_pix", IMAGE, REGION, _local_max),
    # extra region ops
    ("dist_transform", "region", "distance_transform", REGION, IMAGE, _dist_transform),
    ("dist_transform_abs", "region", "distance_transform", REGION, IMAGE, _dist_transform_abs),
    ("region_boundary", "region", "boundary", REGION, REGION, _region_boundary),
    ("convex_fill", "region", "shape_trans", REGION, REGION, _convex_fill),
    # image -> contour (XLD)
    ("edges_sub_pix", "contour", "edges_sub_pix", IMAGE, CONTOUR, _edges_sub_pix),
    # contour -> contour
    ("select_contours", "contour", "select_contours_xld", CONTOUR, CONTOUR, _select_contours),
    ("smooth_contours", "contour", "smooth_contours_xld", CONTOUR, CONTOUR, _smooth_contours),
    ("fit_line_contours", "contour", "fit_line_contour_xld", CONTOUR, CONTOUR, _fit_line_contours),
    # contour -> region / feature
    ("contours_to_region", "contour", "gen_region_contour_xld", CONTOUR, REGION, _contours_to_region),
    ("count_contours", "features", "count_obj", CONTOUR, FEATURE, _count_contours),
    ("total_length", "features", "length_xld", CONTOUR, FEATURE, _total_length),
    # image -> match (template matching)
    ("ncc_locate", "matching", "find_ncc_model", IMAGE, MATCH, _ncc_locate),
    # geometry (calibration/rectification basis)
    ("rotate_img", "geometry", "rotate_image", IMAGE, IMAGE, _rotate_img),
    ("deskew", "geometry", None, IMAGE, IMAGE, _deskew),
    # halcon 名は zoom_image_size → zoom_image_factor へ訂正(2026-09-02): この op は
    # 目標サイズではなく **倍率** で駆動する。目標サイズ版は backends_auto の
    # `zoom_image_size` が本当に実装している。
    ("rescale_img", "geometry", "zoom_image_factor", IMAGE, IMAGE, _rescale_img),
    ("affine_warp", "geometry", "affine_trans_image", IMAGE, IMAGE, _affine_warp),
    # extra filters
    ("gabor", "texture", "gen_gabor", IMAGE, IMAGE, _gabor),
    ("clahe", "gray", "", IMAGE, IMAGE, _clahe),
    ("corner_response", "edges", "points_harris", IMAGE, IMAGE, _corner_response),
    ("adaptive_gauss_thresh", "segmentation", "local_threshold", IMAGE, REGION, _adaptive_gauss_thresh),
    # shape-based matching (rotation invariant)
    ("shape_locate", "matching", "find_shape_model", IMAGE, MATCH, _shape_locate),
    # classification (OCR/decision basis)
    ("classify_shape", "classification", "", REGION, FEATURE, _classify_shape),
    # barcode
    ("decode_barcode", "barcode", "find_bar_code", IMAGE, FEATURE, _decode_barcode),
    # 3D volume (CT/MRI/depth stacks)
    ("vol_gaussian", "3d", "", VOLUME, VOLUME, _vol_gaussian),
    ("vol_median", "3d", "", VOLUME, VOLUME, _vol_median),
    ("vol_erode", "3d", "", VOLUME, VOLUME, _vol_erode),
    ("vol_dilate", "3d", "", VOLUME, VOLUME, _vol_dilate),
    ("vol_threshold", "3d", "", VOLUME, VOLUME, _vol_threshold),
    ("vol_reg_dilate", "3d", "", VOLUME, VOLUME, _vol_reg_dilate),
    ("vol_reg_erode", "3d", "", VOLUME, VOLUME, _vol_reg_erode),
    ("vol_dilation_ball", "3d", "", VOLUME, VOLUME, _vol_dilation_ball),
    ("vol_erosion_ball", "3d", "", VOLUME, VOLUME, _vol_erosion_ball),
    ("vol_opening_ball", "3d", "", VOLUME, VOLUME, _vol_opening_ball),
    ("vol_mip", "3d", "", VOLUME, IMAGE, _vol_mip),
    ("vol_slice", "3d", "", VOLUME, IMAGE, _vol_slice),
    ("vol_count", "features", "", VOLUME, FEATURE, _vol_count),
]

REGISTRY: list[Op] = [Op(n, c, h, i, o, f, _c(n)) for (n, c, h, i, o, f) in _DEFS]
RT: dict[str, Callable] = {op.name: op.fn for op in REGISTRY}
_BY_NAME: dict[str, Op] = {op.name: op for op in REGISTRY}
OPS = tuple((op.name, op.fn) for op in REGISTRY)  # back-compat
N_OPS = len(REGISTRY)
N_SLOTS = 6
GENOME_LEN = N_SLOTS * 3

# Optional library backends (scikit-image / OpenCV): wrap the ecosystem so op count
# scales without reimplementing. Disable with IMGEVOLVE_NO_BACKENDS=1 for the pure,
# always-deterministic numpy/scipy core. Adding backends only widens per-sort
# candidate sets — GENOME_LEN is unchanged.
import os as _os  # noqa: E402
import io as _io  # noqa: E402  (module_requirements がソースを読む)

#: op 名 → それを登録したモジュール名("ops" = このファイルのコア定義、他は backends_*)。
#: ★2026-09-19 の外部レビュー(#1): scikit-image 無しの環境で ``sk_canny`` を呼ぶと
#: 「unknown operator」になり、**存在しない**のか **backend が入っていない**のかを
#: 区別できなかった。fn は ``backend_safe._safe`` に包まれて ``__module__`` を失う
#: ので、登録の側で出自を残す(後勝ち = ``REGISTRY`` の重複解消と同じ規則)。
#: ``imgevolve.py index`` がこれを ``module`` / ``requires`` として索引に書き、
#: ``api._resolve`` が未登録の名前を引かれたときに索引から不足 extra を案内する。
OP_MODULE: dict[str, str] = {op.name: "ops" for op in REGISTRY}

#: optional 依存の import 名 → (pip 配布名, ``pyproject.toml`` の extra 名)。
#: ★pyproject の optional-dependencies と食い違うと案内が嘘になるので
#: ``tests/test_usability_review_2026_09_19.py`` が突き合わせる。
OPTIONAL_DEPS: dict[str, tuple[str, str]] = {
    "skimage": ("scikit-image", "skimage"),
    "cv2": ("opencv-python", "opencv"),
    "PIL": ("Pillow", "pil"),
    "pywt": ("PyWavelets", "wavelets"),
    "torch": ("torch", "gpu"),
    "kornia": ("kornia", "gpu"),
    "mahotas": ("mahotas", "extra"),
    "SimpleITK": ("SimpleITK", "extra"),
    "mitsuba": ("mitsuba", "gi"),
    "imageio": ("imageio", "video"),
    "tifffile": ("tifffile", "volume"),
    "matplotlib": ("matplotlib", "polygon"),
    "mediapipe": ("mediapipe", "handpose"),
}

#: ``fullseye[all]`` に入っている import 名(pyproject の ``all`` と test が突き合わせる)。
#: 案内文が「(or fullseye[all])」と言えるのは不足がこの集合に収まるときだけ。
OPTIONAL_IN_ALL: frozenset = frozenset({"skimage", "cv2", "PIL", "pywt", "torch", "kornia",
                                        "mahotas", "SimpleITK", "imageio", "tifffile"})

_MODULE_REQUIREMENTS_CACHE: dict[str, list[str]] = {}


def module_requirements(mod: str) -> list[str]:
    """モジュール *mod* のソースが import する optional 依存(import 名、整列)。

    実行せず **AST で静的に読む**ので、依存が入っていない環境でも同じ答えになる
    (索引は full 環境で生成し、core 環境で読む —— 両方で一致しなければならない)。
    関数の中の遅延 import も拾う。粒度はモジュール単位: ``backends`` のように
    1 モジュールが skimage と cv2 を別々の build で使う場合、その op は両方を
    「使う」と出る —— 案内文は「このモジュールが使う」「その中で入っていないもの」
    を分けて書き、op 単位の必要十分は主張しない。ソースが読めなければ ``[]``。
    """
    if mod in _MODULE_REQUIREMENTS_CACHE:
        return _MODULE_REQUIREMENTS_CACHE[mod]
    import ast
    import importlib.util
    found: set[str] = set()
    try:
        spec = importlib.util.find_spec(mod)
        src = _io.open(spec.origin, encoding="utf-8").read() if spec and spec.origin else ""
        tree = ast.parse(src) if src else None
    except Exception:  # noqa: BLE001 - ソースが無い/読めない: 案内を諦めるだけで登録は壊さない
        tree = None
    if tree is not None:
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for a in node.names:
                    found.add(a.name.split(".")[0])
            elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
                found.add(node.module.split(".")[0])
    req = sorted(n for n in found if n in OPTIONAL_DEPS)
    _MODULE_REQUIREMENTS_CACHE[mod] = req
    return req


if _os.environ.get("IMGEVOLVE_NO_BACKENDS", "") != "1":
    _extra = []
    FAILED_BACKENDS: list = []   # (module, error) for backends whose build() raised

    for _mod in ("backends", "backends_dl", "backends_auto", "backends_color",
                 "backends_extra", "backends_pil", "backends_scipy",
                 "backends_ski2", "backends_cv2b", "backends_r3", "backends_kornia",
                 "backends_filters2", "backends_regions2", "backends_subpix", "backends_xldgeom",
                 "backends_regions3", "backends_imgtools", "backends_measure1d",
                 "backends_physics", "backends_decomp",
                 "backends_inverse", "backends_transform2", "backends_segment2", "backends_tomo",
                 # Physical-AI / evolution op wave (all halcon="", new capabilities):
                 # sim2real sensor corruption (aug_), artificial-life / cellular automata
                 # (alife_), and tactile / contact-from-shading (tac_).
                 "backends_aug", "backends_alife", "backends_tactile", "backends_texture",
                 # more cellular-automata / artificial-life (Langton / Wolfram-1D /
                 # Lenia / Abelian sandpile) and control-point deformable warps
                 # (thin-plate spline / B-spline FFD / moving least squares). All
                 # halcon="" new capabilities; numpy/scipy-native, deterministic.
                 "backends_alife2", "backends_deform",
                 # HALCON coverage 拡充: 未カバーの実 operator を genuine numpy 実装
                 # (gen_circle/ellipse/rectangle2/checker/grid, convol_gabor,
                 #  fit_surface_first/second_order, cooc_feature_image, full_domain)。
                 "backends_halcon_ext",
                 # self-expanding registry: macro ("DNA") ops condensed from evolved
                 # champions (backends_macro.py). LAST, so it can reference any backend
                 # op and minimally perturbs existing registration indices.
                 "backends_macro",
                 # typed bridge: the ops3d / ops1d / opsmath / opsoptics catalogs
                 # exposed to evolution. AFTER macro so every existing SLOTS index
                 # (macro ops included) is preserved. Registers only NEW in_sorts by
                 # default, which is what keeps decode byte-identical — see
                 # backends_typed's docstring and docs/WAVE0_STABLE_SLOTS.md.
                 "backends_typed",
                 # entry bridges: image -> points/signal/video/volume/lightfield/
                 # rgbimage/cimage/counts/beatcube/matrix/keypoints. category
                 # "bridge" — `_candidates` EXCLUDES it, so evolution's candidate
                 # lists (and every genome -> op index) stay byte-identical while
                 # the name path (apply / Studio / figures / docs) can reach the
                 # 161 ops those sorts feed. See backends_bridge's docstring.
                 "backends_bridge"):
        try:
            _b = __import__(_mod)
            _new = _b.build(Op, IMAGE, REGION, FEATURE, CONTOUR, _norm, _bin)
            # backend が module-level DOCS を出していれば積む。**op 名で引く
            # 明示の指定**なので docstring より強い —— backends_r3 の 56 op は
            # 汎用ファクトリが返す**同一の関数オブジェクト**を共有していて、
            # その docstring を説明に使うと 56 本が同じ文言になる。
            _docs = getattr(_b, "DOCS", None) or {}
            for _op in _new:
                if not _op.doc:
                    _op.doc = (_docs.get(_op.name) or "").strip()
            _extra += _new
            for _op in _new:
                OP_MODULE[_op.name] = _mod        # 後勝ち(REGISTRY の重複解消と同じ)
        except Exception as _e:  # noqa: BLE001 - optional backend; recorded, never silent
            # A backend that fails to import used to VANISH: every op it defines
            # silently missing from the registry, evolution / coverage none the
            # wiser. Keep the registry importable, but leave a trace.
            FAILED_BACKENDS.append((_mod, "%s: %s" % (type(_e).__name__, _e)))
            try:
                import backend_safe as _bs
                _bs.record(_mod, _e, None, source="import")
            except Exception:  # pragma: no cover - the ledger itself must never break import
                pass
    # 名前の衝突を弾く。**op 名は addressing の鍵**で、``RT`` / ``_BY_NAME`` /
    # ``SLOTS`` はどれも後勝ちの dict なので、同名を 2 つ登録すると先に入った方が
    # 名前では二度と引けなくなる(``decode_by_names`` が再現できない)。一方
    # ``_candidates`` はリストを走査するので**両方が抽選に入り、その op だけ
    # 当たる確率が 2 倍**になる。
    #
    # 2026-09-02 実測: laplace / dyn_threshold / local_max / edges_sub_pix の 4 件が
    # ``ops.py`` のコア定義(index 17/31/45/49)と ``backends_auto`` の再定義
    # (210/236/244/276)で衝突していた。9 通りの入力で両者の出力は完全一致
    # (= 純粋な重複)。``backends_auto.build`` は自分の spec 内だけ HALCON 名で
    # de-dup しており、コアが既に登録した名前を知らない。
    #
    # 残すのは**最後に登録された方**。``RT`` / ``_BY_NAME`` は元々「後勝ち」の
    # dict なので、こうすると**名前で引ける実装は 1 ビットも変わらない** ――
    # 4 件はいずれも「コアの fallback + backends_auto の fail-closed ``_safe``
    # ラッパが勝つ」という意図的な上書きで(tests/test_opdocs.py に pin されて
    # いた)、勝者を入れ替えてはいけない。消えるのは抽選の二重取りだけ。
    # backend が不在の環境ではコア定義しか登録されないので、fallback も保たれる。
    #
    # 捨てた分は ``DROPPED_DUPLICATES`` に残す —— 黙って消すと「登録したのに
    # 使えない」になるので、テストが「ちょうどこの集合だけ」を検査できるようにする。
    DROPPED_DUPLICATES = []
    if _extra:
        _all = REGISTRY + _extra
        _last = {}
        for _i, _op in enumerate(_all):
            _last[_op.name] = _i
        REGISTRY = [_op for _i, _op in enumerate(_all) if _last[_op.name] == _i]
        DROPPED_DUPLICATES = [_op.name for _i, _op in enumerate(_all)
                              if _last[_op.name] != _i]
        RT = {op.name: op.fn for op in REGISTRY}
        _BY_NAME = {op.name: op for op in REGISTRY}
        OPS = tuple((op.name, op.fn) for op in REGISTRY)
        N_OPS = len(REGISTRY)


# --------------------------------------------------------------------------- #
# 契約は**全 op に掛ける**(2026-09-05)                                          #
# --------------------------------------------------------------------------- #
# `backend_safe.guard` は「例外は台帳に記録して sort に合う値へ落とす / 返り値は
# 有限で sort として妥当」を約束する。ところが実測すると **881 op のうち 395 本
# (45%)がガードを一度も通っていなかった** —— ガードを使うのは backend の裁量で、
# 使わない family がそのぶんだけ契約の外にいた。
#
# 実害: 0 サイズの入力で 14 op が NaN / Inf を返し、`fullseye.apply()` 経由でも
# そのまま出ていた(0 除算。空配列の平均・分散・比)。ガードを通っていれば
# `sanitize` が拾って sort の fallback に落とし、台帳にも残る。
#
# 「仕組みがある ≠ 全経路が通る」の 4 度目なので、**backend の裁量ではなく
# 登録の側で一律に掛ける**。既にガード済みの op は二重に包まない。
# `sanitize` は有限で契約内の出力には**触らない**ので、正常な op の出力は
# 1 ビットも変わらない(tests/test_ops_guard_coverage.py が指紋で固定)。
#: **非有限値がその op の意味を運んでいる** op。ここに載せた op は例外の
#: 記録だけガードし、返り値には触らない。
#:
#: 実測 2026-09-05: ``tb_geodesic_distances`` は「不達 = inf」と docstring に
#: 明記している。sanitize を通すと ``nan_to_num(posinf=1.0)`` で **inf が 1.0**
#: になり、到達可能な点の最大距離 1.70 より**小さい**値に化けた ——
#: 「届かない」が「近い」に見える。例外にならず**もっともらしく間違う**ので、
#: 数字を見ても誰も気づけない。有限性の契約は [0,1] の画像を想定していて、
#: 距離を運ぶ signal には素直に当てはまらない。
#: **この表は tests/test_backends_typed_liveness.py の KNOWN_NONFINITE_BY_CONTRACT と
#: 一致していなければならない**(test_op_descriptions 系がそれを検査する)。
#: 2026-09-05 の実測: 一律ガードを入れたとき、自分の probe では特異行列を
#: 作っていなかったので `tb_mat_cond` を取りこぼし、既存のテストに拾われた ——
#: **「自分が思いついた入力で確かめた」は「確かめた」ではない**。
NONFINITE_IS_MEANINGFUL = {
    "tb_geodesic_distances": "不達を inf で表す(docstring に明記)。1.0 に潰すと"
                             "『届かない』が『近い』に化ける。",
    "tb_mat_cond": "スペクトル条件数 s_max/s_min。厳密に特異な行列は s_min=0 なので"
                   "inf が正しい答え(mathops.mat_cond は例外を投げず inf を返す)。"
                   "有限に潰すと『十分に良条件』と読めてしまう。",
}


#: ``image`` を名乗るが **[0,1] は契約でない** op -> なぜそうなのか。
#:
#: ``NONFINITE_IS_MEANINGFUL`` の兄弟。あちらが「inf がこの op の答えだ」を
#: 記録するように、こちらは「1 を超える値がこの op の答えだ」を記録する。
#:
#: 経緯(2026-09-14〜15): 探針バンクを 151 op ぶん広げた結果、
#: ``test_every_image_op_stays_in_the_unit_range`` が**初めてこれらに届いた**。
#: 門は正しい場所に立っている —— 露わになったのは、``image`` という 1 つの sort が
#: **「[0,1] の絵」と「物理量/生の大きさを運ぶ 2 次元配列」の 2 つを兼ねている**
#: ことのほう。[[feedback_split_types_when_mixing_lies_silently]] の形そのもので、
#: 419 op が ``image`` を名乗る中にこの 11 本が紛れている。
#:
#: **これは免罪符ではなく未決の記録である。** 正しい決着は「物理量の 2 次元配列」に
#: 別の sort を与えることで、そこまでは下流(閾値・合成・目標画像との差分)が
#: これらを受け取ると黙って無意味になる。理由は推測で書かず、**各 op の
#: docstring の一次記述と実測値**を引く(下の数字は探針バンクでの実測)。
#:
#: 台帳に**足す前に必ず実装を読むこと** —— 2026-09-15 に ``tb_project`` を
#: ここへ入れかけたが、読んだら (N,3) → **(N,2) の画素座標**を返す op が
#: ``image2d`` を名乗っていただけで、値域ではなく**型が嘘**だった
#: (``ops3d.py`` の同じ嘘は ``project_points`` で 2026-09-02 に直され、
#: この 1 行が取り残されていた)。台帳行きにしていたら欠陥を隠していた。
UNIT_RANGE_IS_NOT_THE_CONTRACT = {
    "dist_transform_abs":
        "絶対画素距離(物理量)。正規化版は dist_transform。",
    "tb_project_spherical":
        "画素値は slant range sqrt(x^2+y^2+z^2)(座標の単位 = メートル)。"
        "docstring が『画素値は slant range』と明記。実測 0 .. 12.53。",
    "tb_project_cylindrical":
        "画素値は z 軸からの水平半径 rho = hypot(x, y)。同上。実測 0 .. 715.0。",
    "tb_spectrogram":
        "各列は unnormalised |rfft(frame * hann)|。docstring は 2/win で割るのを"
        "**誤りと名指し**し(Hann が既に信号の一部を捨てているため)、正しい"
        "変換は 2/w.sum() だと実測値つきで書いている。実測 0 .. 76.27。",
    "tb_range_doppler_map":
        "2 次元 FFT の生の大きさ。``normalize=True`` で振幅に直せるが既定は"
        "``False`` = 生、と docstring が明記。実測 0 .. 75.2。",
    "tb_keypoints_to_image2d":
        "**計数**画像。round(v), round(u) の画素に 1 ずつ加算するので、"
        "同じ画素に n 点が落ちれば n。0/1 の絵ではない。",
    "tb_cx_ifft":
        "逆 FFT の実部(既定 ``real=True``)。負の値が信号を運ぶ。実測 -0.0505 .. 0.295。",
    "tb_cx_real":
        "複素場の実部。docstring が『raw, not clamped』と明記。負は意味を持つ。",
    "tb_cx_imag": "同上(虚部)。",
    "tb_lf_depth_from_focus":
        "画素ごとの EPI 傾き s。負 = 手前、正 = 奥で、符号が奥行きの向きを運ぶ。"
        "既定の掃引範囲は slopes=(-2 .. 2)。",
    "tb_lf_epi_slope":
        "同上(構造テンソルの閉形式 s = -(J_ux + J_vy)/(J_xx + J_yy))。"
        "傾きは符号つきで、範囲は場面次第。",
    "tb_monogenic_phase":
        "局所位相 atan2(|R|, f) の**ラジアン**。docstring が『In [0, pi]』と明記"
        "(Riesz ベクトルの符号は向きの側が運ぶので半回転)。実測 0.0196 .. 3.1338 "
        "= ちょうど [0, pi]。**この op は display=True で [0,1] に写す道を持ちながら"
        "既定を False にしている** —— 理由も docstring にあり、『表示用の倍率が"
        "黙って計測に紛れ込むと、何も知らせないまま pi 倍になる』。",
    "tb_monogenic_orientation":
        "局所方位 atan2(R2, R1) の**ラジアン**。docstring が『Radians in [0, pi)』"
        "と明記(方位は pi を法として定義される: 10 度の縞と 190 度の縞は同じ縞)。"
        "実測 0.0004 .. 3.1405。同じく display=True が [0,1] 版を返す。",
    "tb_quat_norm":
        "画素ごとの四元数の絶対値 |q|。docstring が『**Raw / unnormalised**、"
        "絶対値は計量量で 1 を日常的に超える(QFT スペクトルの DC 項は巨大)』"
        "と明記し、表示用は ``imgio.normalize`` を使えと指している。",
}


#: 複素数を返す sort(``backends_bridge._COMPLEX_SORTS`` と同じ集合)。
_COMPLEX_OUT_SORTS = frozenset({"cimage", "beatcube"})


#: ★2026-11-09 独立レビュー: ``match`` sort の既定の fallback は 3 要素 ``[0, 0, 0]``
#: (``backend_safe.fallback``)。4 要素 ``[得点, 行, 列, 角度]`` を返す op が例外で
#: fallback に落ちると、返りの長さが 3 に変わっていた(``shape_locate`` が NaN 1 画素で
#: ``[0,0,0]``)。長さが既定と違う op はここで fallback の形を揃える。
_ON_FAIL_BY_OP = {
    "shape_locate": lambda v: np.zeros(4),
}


def _wrap_unguarded() -> int:
    """登録済みで未ガードの op を ``guard`` で包む。包んだ数を返す。"""
    import backend_safe as _bs
    n = 0
    for _op in REGISTRY:
        if getattr(_op.fn, "__fullseye_guarded__", False):
            continue
        if _op.name in NONFINITE_IS_MEANINGFUL:
            # 例外の記録は掛けるが、返り値は書き換えない
            _sort = _op.out_sort

            def _keep(out, v, _s=_sort, _bs=_bs):
                return _bs.fallback(v, _s) if out is None else out

            _op.fn = _bs.guard(_op.fn, _sort, name=_op.name, finish=_keep)
        elif _op.out_sort in _COMPLEX_OUT_SORTS:
            # ★2026-10-07: 複素の sort は sanitize(実 sort 向けの規約で**実部だけ**を返す)を通さない。
            #   以前は tb_angular_spectrum_propagate / tb_cx_apply_transfer_function / tb_fmcw_window_apply が
            #   cimage / beatcube を名乗りながら float64 を返していた(虚部を黙って捨てる = 位相が消える)。
            #   backends_bridge の橋は同じ理由で既に素通しにしていた —— その規約をこちらにも揃える。
            _op.fn = _bs.guard(_op.fn, _op.out_sort, name=_op.name,
                               finish=lambda out, v, _s=_op.out_sort, _n=_op.name, _bs=_bs:
                               _bs._keep_complex(out, v, _s, _n))
        else:
            _op.fn = _bs.guard(_op.fn, _op.out_sort, name=_op.name,
                               on_fail=_ON_FAIL_BY_OP.get(_op.name))
        n += 1
    return n


GUARD_WRAPPED_AT_REGISTRATION = _wrap_unguarded()

#: ★**ネイティブ側が退化入力でプロセスごと落ちる op の台帳**(2026-09-05)。
#:
#: `guard` は Python の例外しか捕まえられない。C/C++ の中で境界の外へ書き込まれたら
#: そこで終わりで、利用者のパイプラインごと消える —— fail-soft の最悪の破れ方。
#: 入口で弾く以外に手が無いので、**理由つきでここに載せて登録時に関門を掛ける**。
#:
#: **プラットフォームで挙動が違う**のがこの台帳の存在理由。下の 3 本は
#: Linux(Ubuntu 24.04 / Python 3.12 / PyPI の wheel)では落ちるが、
#: **Windows では同じ入力で 1 件も再現しなかった**。ネイティブのビルドが違えば
#: 境界の壊れ方も違うということなので、「この種類の入力なら大丈夫」という
#: 細かい線引きは信用できない —— **退化入力はまとめて拒否する**。
#:
#: 直したら消す、ではなく**上流が直ったことを確認できたら**消す(こちらは
#: 自分のコードではないので、消す条件が違う)。
NATIVE_CRASHES_ON_DEGENERATE = {
    "cv_cc_count":
        "OpenCV の connectedComponents に 0 サイズを渡すと Linux ビルドで SIGSEGV。",
    "xsitk_minmax_curv_flow":
        "SimpleITK の MinMaxCurvatureFlow は非有限で SIGSEGV。**一部だけ NaN の"
        "画像でも落ちる**(欠測を含む実データで普通に起こる形)。",
    "xsk3_h_minima":
        "skimage の h_minima(内部で morphology.reconstruction)は全 NaN で SIGSEGV。"
        "同じ族の xsk2_reconstruction / xsk2_h_maxima は 0.1.8 で塞いだのに、"
        "**この兄弟を見落としていた**。",
    "xsk_random_walker":
        "skimage の random_walker は**一部の NaN**でハングする(Fable レビュー実測: "
        "512 px で 0.1% の NaN → 60 秒超、正常時 0.17 秒。128 px では 1.4 秒で返る = "
        "規模で顕在化)。全 NaN は即 ValueError なので退化スイープには映らなかった。"
        "クラッシュではなく**ハング**だが、利用者から見た害は同じ。",
}


def _wrap_native_crash_guards() -> int:
    """`NATIVE_CRASHES_ON_DEGENERATE` の op に、入口の関門を掛ける。

    既にガード済みの op も対象なので、``_wrap_unguarded`` とは別の走査にする。
    弾いた入力は ``ValueError`` になり、外側の ``guard`` が台帳に記録して
    sort に合う値へ落とす —— **落ちない**という約束は守られる。
    """
    import backend_safe as _bs
    n = 0
    for _op in REGISTRY:
        why = NATIVE_CRASHES_ON_DEGENERATE.get(_op.name)
        if not why:
            continue

        def _pre(v, a, b, _inner=_op.fn, _name=_op.name, _why=why):
            arr = None if isinstance(v, dict) else np.asarray(v)
            if arr is not None:
                if arr.size == 0:
                    raise ValueError("%s: 0 サイズ入力は拒否(%s)" % (_name, _why))
                if arr.dtype.kind in "fc" and not np.all(np.isfinite(arr)):
                    raise ValueError("%s: 非有限を含む入力は拒否(%s)" % (_name, _why))
            return _inner(v, a, b)

        _pre.__doc__ = getattr(_op.fn, "__doc__", None)
        _op.fn = _bs.guard(_pre, _op.out_sort, name=_op.name)
        n += 1
    return n


def _label_guarded_functions_with_their_op_name() -> int:
    """劣化を記録するとき、**どの op か**が分かるようにする。

    ★2026-09-05 の実測でぶつかった: `backend_safe.guard` は記録名を
    ``name`` → ファサードが実行中の op(``current_op``) → 関数の ``__qualname__``
    の順で決める。ギャラリーや進化ループのように **ファサードを通さず
    ``op.fn(...)`` を直に呼ぶ**経路では最初の 2 つが無いので、
    ``build.<locals>._hog`` のようなクロージャ名が記録される。
    同じ工場関数から作られた op は**全部同じ名前に潰れ**、
    実測で 473 op が 161 キーになっていた —— 劣化しても犯人が分からない。

    直し方: `_safe` は 24 のバックエンドに重複定義された同型ラッパ族なので、
    呼び出し側 30 箇所を触らない。`guard` が ``w.__wrapped__`` を残しているので、
    **登録が済んだあとに内側の関数へ本名を書き込む**。記録は
    ``getattr(fn, "__qualname__")`` を読むだけなので、**実行時コストはゼロ**。

    ラッパが多段(``_f64_first`` → ``_safe`` → native 関門)のこともあるので、
    ``__wrapped__`` の鎖を辿って全部に書く。書けない相手(builtin, partial)は飛ばす。
    """
    n = 0
    for _op in REGISTRY:
        fn = getattr(_op.fn, "__wrapped__", None)
        depth = 0
        while fn is not None and depth < 8:
            try:
                if getattr(fn, "__qualname__", None) != _op.name:
                    fn.__qualname__ = _op.name
                    n += 1
            except (AttributeError, TypeError):        # builtin / partial 等
                pass
            fn = getattr(fn, "__wrapped__", None)
            depth += 1
    return n


NATIVE_CRASH_GUARDS = _wrap_native_crash_guards()
#: 記録名を本名にした関数の数(潰れたキーの再発をここで数える)。
OP_NAME_LABELS = _label_guarded_functions_with_their_op_name()
RT = {op.name: op.fn for op in REGISTRY}
_BY_NAME = {op.name: op for op in REGISTRY}
OPS = tuple((op.name, op.fn) for op in REGISTRY)
N_OPS = len(REGISTRY)


def categories() -> dict[str, list[str]]:
    out: dict[str, list[str]] = {}
    for op in REGISTRY:
        out.setdefault(op.category, []).append(op.name)
    return out


#: 進化の候補から**除く** category。``bridge``(backends_bridge)は image を入力に
#: 取る入口 op なので、候補に入れると image の候補リストが伸び、既存ゲノムが
#: 別の op に写る(docs/WAVE0_STABLE_SLOTS.md)。名前で引く経路(``RT`` /
#: ``_BY_NAME`` / ``fullseye.apply`` / Studio / 図)にはそのまま見える。
#: ``tests/test_wave0.py`` が候補リストの不変を、``tests/test_backends_bridge.py``
#: がこの除外を固定する。
_NOT_A_CANDIDATE = frozenset({"bridge"})


def _candidates(sort: str) -> list[Op]:
    return [op for op in REGISTRY
            if (op.in_sort == sort or op.in_sort == ANY)
            and op.category not in _NOT_A_CANDIDATE]


@dataclass
class Stage:
    op: str
    a: float
    b: float
    sort: str  # the sort this stage operates on (for readability/codegen)


def decode(genome, start: str = IMAGE) -> list[Stage]:
    """Type-aware decode: each slot picks a sort-compatible op; sort threads through."""
    g = np.clip(np.asarray(genome, np.float64), 0.0, 1.0)
    sort = start
    out: list[Stage] = []
    for i in range(N_SLOTS):
        t, a, b = g[3 * i], g[3 * i + 1], g[3 * i + 2]
        cands = _candidates(sort)
        op = cands[min(len(cands) - 1, int(t * len(cands)))]
        out.append(Stage(op.name, float(a), float(b), sort))
        if op.name != "identity":
            sort = op.out_sort
    return out


#: 値域が [0,1] と決まっている sort。``_apply`` の段間クリップはこの規約のもの。
#: 座標や振幅を運ぶ新 sort(points/signal/matrix/cimage)に同じクリップを掛けると
#: **データを破壊する** — 実測 2026-09-01: 点群 (N,3) は 2-D ndarray なので
#: クリップ対象になり、[0,10] の座標が [0,1] に潰れて hand baseline が trivial を
#: 下回った(0.194 vs 0.684)。既存 sort の挙動は 1 ビットも変えないため、
#: 「新 sort だけを除外する」形で書く(既存 champion のスコアは不変)。
_UNCLIPPED_SORTS = frozenset({POINTS, SIGNAL, MATRIX, CIMAGE,
                              LIGHTFIELD, COUNTS, HISTCUBE, KEYPOINTS})


def _effective_out_sort(st):
    """その stage を出た値の sort。

    ``identity`` のように ``out_sort == ANY`` の op は「入ってきた sort を保つ」
    という意味なので、宣言をそのまま読むと sort を見失う。実測 2026-09-01:
    ANY を素直に読んだせいで、**何もしない 6 段が点群を [0,1] にクリップして
    いた** — 同じ「何もしないパイプライン」がゲノム経路 0.2016 / 名前経路
    0.6616 と食い違い、進化が trivial baseline に到達できない真因だった。
    """
    op = _BY_NAME.get(st.op)
    if op is None:
        return None
    return st.sort if op.out_sort == ANY else op.out_sort


def _apply(stages, img):
    v = np.asarray(img, np.float64)
    for st in stages:
        v = RT[st.op](v, st.a, st.b)
        if isinstance(v, np.ndarray) and v.ndim in (2, 3):
            if _effective_out_sort(st) not in _UNCLIPPED_SORTS:
                v = np.clip(v, 0.0, 1.0)
    return v


def run_genome(genome, img, start: str = IMAGE):
    """Run the decoded pipeline; returns an image/region (2-D), volume (3-D), or feature."""
    return _apply(decode(genome, start), img)


def run_stages(stages: list, img):
    return _apply(stages, img)


def apply_genome(genome, img):
    """Back-compat: coerce the final value to a 2-D array (feature -> constant image)."""
    v = run_genome(genome, img)
    if isinstance(v, np.ndarray) and v.ndim == 2:
        return v
    if isinstance(v, dict):                       # contour -> use the contour count
        v = float(len(v.get("cs", [])))
    try:
        m = float(np.clip(np.mean(np.asarray(v, np.float64)), 0, 1))
    except Exception:
        m = 0.0
    return np.full(img.shape, m, np.float64)


def stage(op: str, a: float, b: float) -> Stage:
    """Build one typed stage (for hand-written baseline pipelines)."""
    return Stage(op, a, b, _BY_NAME[op].in_sort)


def pipeline_str(genome, start: str = IMAGE) -> str:
    parts = [f"{s.op}(a={s.a:.2f},b={s.b:.2f})" for s in decode(genome, start) if s.op != "identity"]
    return " -> ".join(parts) if parts else "identity"


# --------------------------------------------------------------------------- #
# Wave-0: stable op slots + name-pinned (cross-install) champion records.       #
# --------------------------------------------------------------------------- #
# SLOTS freezes each op's registration-order index the moment REGISTRY is fully
# built (core _DEFS first, then any optional backends in import order). decode()
# indexes _candidates(sort) in exactly this order, so within a given install the
# genome->op mapping is deterministic and documented by SLOTS.
#
# CROSS-INSTALL CAVEAT (honest): the index a genome resolves to depends on how
# many candidates a sort has, which grows with the optional backends present in
# THIS install. Re-sorting _candidates to a globally stable order WOULD change
# that mapping and therefore change every existing champion — so decode() is
# deliberately left byte-identical (proven in tests/test_wave0.py). Reproducing a
# champion across installs is done by op NAME instead of index: pipeline_stages()
# records the champion as (name, a, b) and decode_by_names() rebuilds the exact
# pipeline from those names, independent of the index layout. See docs/WAVE0_STABLE_SLOTS.md.
#
# A few names occur twice (a backend overrides a core op, e.g. "laplace"). Like RT
# and _BY_NAME, SLOTS resolves a name to its LAST (canonical) occurrence — the op
# that actually executes (decode() stores a name; _apply runs RT[name]). Name-pinned
# reload is therefore consistent with execution on both sides.
SLOTS: dict[str, int] = {op.name: i for i, op in enumerate(REGISTRY)}




def stages_str(stages) -> str:
    """Render a decoded pipeline (list[Stage]) to the same string form as
    pipeline_str, but from stages rather than a genome (drops identity)."""
    parts = [f"{s.op}(a={s.a:.2f},b={s.b:.2f})" for s in stages if s.op != "identity"]
    return " -> ".join(parts) if parts else "identity"


def pipeline_stages(genome, start: str = IMAGE) -> list[dict]:
    """Name-pinned champion record: the decoded pipeline as a list of
    ``{"op", "a", "b", "sort"}`` dicts (identity dropped). Index-independent, so
    it reloads to the SAME pipeline on any install that has the named ops, via
    :func:`decode_by_names`. This is the cross-install-reproducible counterpart
    to the index-based :func:`decode`."""
    return [{"op": s.op, "a": float(s.a), "b": float(s.b), "sort": s.sort}
            for s in decode(genome, start) if s.op != "identity"]


def genome_for_names(stage_specs, start: str = IMAGE):
    """名前で書いたパイプライン → それを decode するゲノム(不可能なら ``None``)。

    :func:`decode` の逆写像。``decode`` は各スロットで
    ``cands[int(t*len(cands))]`` を引くので、目的の op が候補リストの何番目かが
    分かれば ``t`` を作れる(区間の中央を取る)。埋まらないスロットは
    ``identity`` で詰める。

    **何のためか**: 進化を **既知の baseline から始められる**ようにするため。
    候補が狭い sort では、ランダム初期化で「何もしない」パイプラインに当たる
    確率が ``(1/候補数)**スロット数`` になり事実上ゼロで、進化が trivial にすら
    到達できない(実測 2026-09-01: 点群 25 候補 × 6 スロットで 4e-9。3200 評価の
    探索でも locked 0.436 と、何もしない 0.675 を下回った)。そのままでは
    「進化は baseline を超えたか」の比較が空虚になる。

    ``None`` を返すのは、その op がそのスロットの sort の候補に居ないとき
    (= そのパイプラインはこの encoding では表現できない)。**近い op で
    代用しない** — 別物を種にしたら実験の意味が変わる。
    """
    slots = list(stage_specs)
    if len(slots) > N_SLOTS:
        return None
    g = np.zeros(GENOME_LEN, np.float64)
    sort = start
    for i in range(N_SLOTS):
        if i < len(slots):
            spec = slots[i]
            name = spec[0] if isinstance(spec, tuple) else spec["op"]
            a = float(spec[1] if isinstance(spec, tuple) else spec.get("a", 0.5))
            b = float(spec[2] if isinstance(spec, tuple) else spec.get("b", 0.5))
        else:
            name, a, b = "identity", 0.5, 0.5
        cands = _candidates(sort)
        idx = next((j for j, o in enumerate(cands) if o.name == name), None)
        if idx is None:
            return None                       # この encoding では表現できない
        g[3 * i] = (idx + 0.5) / len(cands)   # その区間の中央 = 端の丸めに強い
        g[3 * i + 1], g[3 * i + 2] = a, b
        if name != "identity":
            sort = _BY_NAME[name].out_sort
    return g


def decode_by_names(stage_specs) -> list[Stage]:
    """Reconstruct a pipeline from op NAMES (independent of registry index order).

    ``stage_specs`` is an iterable of either ``(name, a, b)`` tuples or dicts with
    keys ``op``/``a``/``b``. Each op's ``in_sort`` is resolved from ``_BY_NAME``,
    so a champion saved by name (see :func:`pipeline_stages`) rebuilds to the same
    pipeline regardless of which optional backends shifted the index layout. Raises
    ``KeyError`` (fail-closed) if a named op is absent in this install."""
    out: list[Stage] = []
    for spec in stage_specs:
        if isinstance(spec, dict):
            name = spec["op"]
            a = float(spec.get("a", 0.0))
            b = float(spec.get("b", 0.0))
        else:
            name, a, b = spec[0], float(spec[1]), float(spec[2])
        out.append(Stage(name, a, b, _BY_NAME[name].in_sort))
    return out


def psnr(a, b) -> float:
    mse = float(np.mean((np.asarray(a, np.float64) - np.asarray(b, np.float64)) ** 2))
    return 99.0 if mse <= 1e-12 else float(10.0 * np.log10(1.0 / mse))
