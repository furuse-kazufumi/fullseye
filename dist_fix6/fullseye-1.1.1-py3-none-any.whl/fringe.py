# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""fringe — 構造化光による位相シフト・プロファイロメトリ(3D 形状計測)。

産業 3D スキャンの中核となる「縞投影(fringe projection)」の復号一式を提供する。プロジェクタが
正弦縞パターンを対象に投影し、カメラが撮る。物体の高さで縞が変形するので、その位相ずれから高さを
復元する(三角測量の一種)。Physical AI 用の 3D 計測サンプル(既知形状 → 縞画像 → 復元)生成にも使う。

パイプライン:
    位相シフト N 枚 → wrapped_phase(-π,π] → unwrap_phase_2d(連続位相) → phase_to_height(高さ)
    (絶対次数が要るときは Gray code を併用: graycode_decode で整数フリンジ次数を出す)

規約(重要):
    * 画像は numpy 2D 配列、値域 [0,1] を想定(範囲外でも計算は通るが変調度の意味が薄れる)。
    * 位相シフト量は等間隔 δ_n = 2πn/N(n = 0..N-1)。
    * wrapped_phase は φ = atan2(Σ_n I_n sin δ_n, Σ_n I_n cos δ_n)(標準 N-step 公式)。
      本モジュールの synthesize_fringes は I_n = a + b·cos(φ - δ_n) で縞を作るので、この公式が
      与位相 φ をそのまま(符号反転なしで)復元する — 生成と復号の符号規約を一致させてある。

limitations(正直な制約):
    * 位相アンラップ(spatial unwrap)は Itoh の仮定「隣接画素の真の位相差 < π」に依存する。
      急峻な段差・深い穴・オクルージョン境界では破綻し得る(縞次数の飛びを誤る)。絶対性が要る
      場面では graycode_decode(または多周波位相)で次数を確定させること。
    * unwrap は大域オフセット(+2πm の定数)の不定性を残す。参照平面位相 ref_phase の減算で
      相対高さは正しく出るが、絶対高さ 0 面の同定には較正(k と ref_phase)が要る。
    * 低変調画素(影・飽和・低反射)は位相が不定。modulation() でマスクして NaN 化するのが安全。
"""
from __future__ import annotations

import numpy as np

try:  # skimage は必須依存だが、無い環境では unwrap のみ graceful に失敗させる
    from skimage.restoration import unwrap_phase as _sk_unwrap_phase
    _HAVE_SKIMAGE = True
except Exception:  # pragma: no cover - 環境依存
    _sk_unwrap_phase = None
    _HAVE_SKIMAGE = False


# --------------------------------------------------------------------------- #
# 内部ヘルパ                                                                    #
# --------------------------------------------------------------------------- #
def _as_stack(images) -> np.ndarray:
    """位相シフト画像列 → (N, H, W) float 配列に正規化+検証。

    images: 長さ N のシーケンス(各 2D 画像)または (N, H, W) 配列。N >= 3 が必須。
    """
    if images is None:
        raise ValueError("images must not be None (pass a phase-shift image sequence)")
    stack = np.asarray(images, dtype=np.float64)
    if stack.ndim != 3:
        raise ValueError(
            f"phase-shift image sequence must be 3-dimensional (N, H, W): got shape={stack.shape}"
        )
    n = stack.shape[0]
    if n < 3:
        raise ValueError(f"N-step phase shifting requires N >= 3: N={n}")
    if not np.all(np.isfinite(stack)):
        raise ValueError("phase-shift images contain non-finite values (NaN/Inf)")
    return stack


def _principal(phi):
    """``arctan2`` の主値 ``[-π, π]`` を ``(-π, π]`` に写す(``-π`` は ``+π`` へ)。

    ``arctan2(-0.0, c<0)`` は ``-π`` を返す。tensordot の和が ``-0.0`` になる画素
    (例: 位相 0 の縞の 3 段)で起き、文書の値域 ``(-π, π]`` を外れていた(2026-11-05)。
    """
    phi = np.asarray(phi, dtype=np.float64)
    return np.where(phi <= -np.pi, np.pi, phi)


def _phase_sums(stack: np.ndarray):
    """Σ_n I_n sin δ_n(=s)と Σ_n I_n cos δ_n(=c)を返す(δ_n = 2πn/N)。"""
    n = stack.shape[0]
    delta = 2.0 * np.pi * np.arange(n) / n
    # (N,) と (N,H,W) の n 軸縮約
    s = np.tensordot(np.sin(delta), stack, axes=(0, 0))
    c = np.tensordot(np.cos(delta), stack, axes=(0, 0))
    return s, c


def _modulation_from_sums(stack: np.ndarray, s: np.ndarray, c: np.ndarray):
    """既に求めた位相和から変調度を作る。"""
    amp = (2.0 / stack.shape[0]) * np.hypot(s, c)
    mean = stack.mean(axis=0)
    gamma = np.zeros_like(amp)
    # ★床は画素ごとの相対量(その画素の |I_n| の最大の 64 eps 倍)。2026-11-05 まで絶対の
    # 1e-12 で、全体を 1e-13 倍した同じデータの変調度が 0 になり、decode_fringe と
    # grating_three_image_retrieve(P = N の経路だけ)が「有効画素なし」で拒否していた。
    scale = np.abs(stack).max(axis=0)
    valid = np.abs(mean) > 64.0 * np.finfo(np.float64).eps * scale
    gamma[valid] = amp[valid] / mean[valid]
    return gamma


# --------------------------------------------------------------------------- #
# 1. wrapped phase                                                             #
# --------------------------------------------------------------------------- #
def wrapped_phase(images, method="general") -> np.ndarray:
    """N-step 位相シフト縞画像から wrapped phase (-π, π] を求める。

    標準 N-step 公式 φ = atan2(Σ_n I_n sin(2πn/N), Σ_n I_n cos(2πn/N))。N >= 3 の等間隔位相シフトを
    仮定。返り値は各画素の巻き込み位相(-π,π] の 2D 配列。

    images: 長さ N のシーケンス(各 2D [0,1] 画像)または (N, H, W) 配列。

    計算: 位相シフト量を等間隔 ``δ_n = 2πn/N``(``n = 0..N-1``)とし、
    ``s = Σ_n I_n sin δ_n``、``c = Σ_n I_n cos δ_n`` を ``tensordot`` で取って
    ``np.arctan2(s, c)``。``I_n = a + b cos(φ - δ_n)`` のモデル(``synthesize_fringes``
    と同じ符号規約)なら ``φ`` が符号反転なしで戻る。平均輝度 ``a`` は消えるので
    バイアスの影響を受けない。

    入力と検証(``ValueError``): ``None`` / 3-D ``(N, H, W)`` に変換できない /
    ``N < 3`` / NaN・Inf を含む。値域 ``[0, 1]`` は前提であって検査はしない(範囲外
    でも計算は通る)。

    返り値: ``(H, W)`` float64、値域 ``(-π, π]``。``s = c = 0`` の画素(縞が無い・
    変調ゼロ)は ``arctan2(0, 0) = 0`` を返し、エラーにも NaN にもならない —
    信頼できる画素を選ぶには ``modulation``(同モジュールの関数)で変調度を見る
    (``decode_fringe`` の ``min_modulation`` がそれを行う)。

    注意: 位相シフト量が等間隔でない・枚数と順序が合っていない画像列を渡すと、
    エラーにならず「もっともらしく間違った」位相が出る。次段は
    ``unwrap_phase_2d``(空間展開)か ``absolute_phase``(粗い絶対位相で次数確定)。
    """
    stack = _as_stack(images)
    if method == "general":
        s, c = _phase_sums(stack)
    elif method == "four_step":
        if stack.shape[0] != 4:
            raise ValueError("method='four_step' requires exactly 4 images")
        s = stack[1] - stack[3]
        c = stack[0] - stack[2]
    else:
        raise ValueError("method must be 'general' or 'four_step'")
    return _principal(np.arctan2(s, c))


# --------------------------------------------------------------------------- #
# 2. modulation(データ変調度 = 信頼度マップ)                                   #
# --------------------------------------------------------------------------- #
def modulation(images) -> np.ndarray:
    """縞のデータ変調度(fringe contrast = 振幅/平均)を返す。信頼度マップとして使う。

    振幅 b = (2/N)·sqrt(s² + c²)、平均 a = mean_n I_n(s,c は Σ I sin/cos)。変調度 γ = b/a。
    影・飽和・低反射で γ は小さくなる。低変調画素をマスクして位相を NaN 化するのに使う。
    平均が 0 の画素は γ=0(位相が定義できない)とする。「0」はその画素の画像値の
    最大に対する相対量で判定する(``|mean| <= 64 eps · max_n |I_n|``)ので、画像全体の
    尺度(1 でも 1e-13 でも)で答えは変わらない。
    """
    stack = _as_stack(images)
    s, c = _phase_sums(stack)
    return _modulation_from_sums(stack, s, c)


# --------------------------------------------------------------------------- #
# 3. 2D 位相アンラップ(skimage ラッパ / NaN・マスク対応)                        #
# --------------------------------------------------------------------------- #
def unwrap_phase_2d(wrapped, mask=None, crop_valid=False) -> np.ndarray:
    """wrapped phase を skimage.restoration.unwrap_phase で連続位相に展開する。

    wrapped: wrapped_phase の出力(2D)。NaN を含んでよい(無効画素として扱う)。
    mask:    省略可。True = 有効画素(numpy masked array の慣習とは逆にした直感的な向き)。
             NaN 画素と mask=False 画素は無効としてアンラップから除外し、出力では NaN を返す。
    crop_valid: 省略可(既定 False = 全面処理)。True なら有効画素の外接矩形だけを skimage に渡し、
             外側は NaN のまま返す(無効画素が多い枠つき画像で速い別経路。有効画素の位相は全面処理と 2π の整数倍のオフセットを除いて一致する。島ごとのオフセットは skimage の版で変わりうる)。

    返り値: 連続位相(2D float)。無効画素は NaN。大域オフセット(+2πm)の不定性は残る。

    手順: 無効画素(``wrapped`` の非有限 ∪ ``mask == False``)が無ければ
    ``skimage.restoration.unwrap_phase(arr)`` をそのまま呼ぶ。あれば無効画素を 0 で
    埋めた ``numpy.ma`` の masked array として渡し(skimage は masked 画素を展開から
    除外する)、出力の無効画素を NaN に戻す。

    検証: scikit-image が import できない環境では ``RuntimeError``(``ImportError``
    ではない)。``wrapped`` が 2-D でない、``mask`` の形が違う、**全画素が無効**
    (アンラップする画素が無い)は ``ValueError``。

    前提(Itoh の条件): 隣接する有効画素の真の位相差が ``π`` 未満。急な段差・深い穴・
    オクルージョン境界では 2π の飛びを誤り、その先の領域全体が ``2πm`` ずれる。
    マスクで島に分かれた領域どうしの相対次数は決まらない(島ごとに独立な
    オフセット)。絶対性が要るときは ``graycode_decode`` → ``absolute_phase`` の
    画素独立な次数確定を使う。

    使いどころ: ``wrapped_phase`` → 本 op → ``phase_to_height``(同モジュールの
    関数、``height = k (phase - ref_phase)``)。★展開の大域オフセット ``2πm`` は
    展開ごとに決まる(起点の分岐は入力の位相の場に依る)ので、参照面と計測面を
    **別々に展開して引いても相殺しない**(2026-11-05 まで「相殺する」と書いていたが、
    60 条件中 24 で高さが ``k·2π`` ずれた)。参照を引くときは ``decode_fringe`` の
    ``ref_phase`` を使う —— 巻き込み位相の差を先に取ってから 1 回だけ展開する。

    空の入力(``wrapped`` が 0 要素)は ValueError。
    """
    if (len(wrapped) if isinstance(wrapped, (list, tuple)) else np.asarray(wrapped).size) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("unwrap_phase_2d: wrapped is empty — pass at least one element")
    if not _HAVE_SKIMAGE or _sk_unwrap_phase is None:
        raise RuntimeError(
            "skimage.restoration.unwrap_phase is unavailable (install scikit-image)"
        )
    arr = np.asarray(wrapped, dtype=np.float64)
    if arr.ndim != 2:
        raise ValueError(f"unwrap_phase_2d expects a 2D array: got shape={arr.shape}")

    invalid = ~np.isfinite(arr)
    if mask is not None:
        mask = np.asarray(mask, dtype=bool)
        if mask.shape != arr.shape:
            raise ValueError(
                f"mask shape {mask.shape} does not match wrapped shape {arr.shape}"
            )
        invalid = invalid | (~mask)

    if not invalid.any():
        return np.asarray(_sk_unwrap_phase(arr), dtype=np.float64)

    if invalid.all():
        raise ValueError("no valid pixels (all pixels are NaN/masked)")

    if crop_valid:
        rows, cols = np.nonzero(~invalid)
        row_slice = slice(rows.min(), rows.max() + 1)
        col_slice = slice(cols.min(), cols.max() + 1)
        sub_invalid = invalid[row_slice, col_slice]
        sub = np.ma.array(np.where(sub_invalid, 0.0, arr[row_slice, col_slice]),
                          mask=sub_invalid)
        unwrapped = _sk_unwrap_phase(sub)
        out = np.full(arr.shape, np.nan, dtype=np.float64)
        data = np.asarray(np.ma.getdata(unwrapped), dtype=np.float64)
        data[sub_invalid] = np.nan
        out[row_slice, col_slice] = data
        return out

    # 無効画素を masked array で除外してアンラップ(skimage が対応)。
    filled = np.where(invalid, 0.0, arr)
    ma = np.ma.array(filled, mask=invalid)
    unwrapped_ma = _sk_unwrap_phase(ma)
    out = np.array(np.ma.getdata(unwrapped_ma), dtype=np.float64)
    out[invalid] = np.nan
    return out


# --------------------------------------------------------------------------- #
# 4. Gray code デコード(絶対フリンジ次数)                                       #
# --------------------------------------------------------------------------- #
def graycode_decode(bit_images, thresh=0.5) -> np.ndarray:
    """Gray code ビット画像列 → 整数フリンジ次数マップ(絶対次数)。

    bit_images: 長さ K のシーケンス(各 2D 画像、明=1 / 暗=0)。**MSB first**(bit_images[0] が
                最上位ビット)。thresh で二値化する。
    thresh:     二値化しきい値(画素値 >= thresh を 1)。

    処理: 各ビット面を二値化 → MSB first で Gray 値を組み立て → Gray→binary 変換
          (binary = gray ^ (gray>>1) ^ ... ^ (gray>>(K-1)))で絶対次数(整数)を返す。
    返り値: dtype int64 の 2D 次数マップ(値域 0..2**K-1)。

    検証(``ValueError``): ``None`` / ``(K, H, W)`` に変換できない / ``K < 1`` /
    ``K > 62``(int64 に収まらない) / NaN・Inf を含む。``thresh`` は検査しない
    (画素値と同じスケールで与える。``[0, 1]`` 画像なら 0.5 が既定)。

    二値化は固定閾値 ``>= thresh`` のみ — 反転パターン(ネガ画像)との比較や
    局所閾値は行わない。影・低反射で暗く出た画素は 0 ビットとして復号され、
    エラーにならず誤った次数になるので、``modulation`` などで作った信頼マスクを
    呼び手が別に持つこと。

    次数の意味: Gray 符号は隣接コードが 1 ビットしか違わないので、境界画素の
    二値化誤りは次数を ±1 しかずらさない(binary 符号なら大きく飛ぶ)。返る整数を
    投影機コラム番号や縞の絶対次数として、``absolute_phase`` の ``coarse``
    (``2π * 次数`` を位相に換算)や ``triangulate_column`` の ``column`` に使う。
    """
    if bit_images is None:
        raise ValueError("bit_images must not be None")
    bits_stack = np.asarray(bit_images, dtype=np.float64)
    if bits_stack.ndim != 3:
        raise ValueError(
            f"bit_images must be 3-dimensional (K, H, W): got shape={bits_stack.shape}"
        )
    k = bits_stack.shape[0]
    if k < 1:
        raise ValueError("no Gray code bit planes given")
    if k > 62:
        raise ValueError(f"too many bits (int64 requires K<=62): K={k}")
    if not np.all(np.isfinite(bits_stack)):
        raise ValueError("bit_images contain non-finite values (NaN/Inf)")

    # 二値化 → Gray 整数(MSB first)
    binimg = (bits_stack >= thresh).astype(np.int64)
    gray = np.zeros(bits_stack.shape[1:], dtype=np.int64)
    for i in range(k):
        gray |= binimg[i] << (k - 1 - i)

    # Gray → binary: 並列 prefix XOR。各段で確定済みの幅を倍にする。
    binary = gray.copy()
    shift = 1
    while shift < k:
        binary ^= binary >> shift
        shift <<= 1
    return binary


# --------------------------------------------------------------------------- #
# 5. 位相 → 高さ(参照平面線形モデル)                                            #
# --------------------------------------------------------------------------- #
def phase_to_height(phase, ref_phase, k) -> np.ndarray:
    """参照平面線形モデルで位相を高さに変換する: height = k·(phase - ref_phase)。

    phase:     計測対象の(アンラップ済み)連続位相。NaN を含んでよい(そのまま伝播)。
    ref_phase: 参照平面(高さ 0)の連続位相。スカラも 2D 配列も可。
    k:         較正定数(位相→高さのスケール、単位/rad)。符号反転もここで吸収できる。

    位相シフト法の高さは Δφ に線形で、Δφ = phase - ref_phase。較正 k は既知形状で決める。
    """
    ph = np.asarray(phase, dtype=np.float64)
    ref = np.asarray(ref_phase, dtype=np.float64)
    if ref.ndim != 0 and ref.shape != ph.shape:
        raise ValueError(
            f"ref_phase shape {ref.shape} does not match phase shape {ph.shape}"
        )
    kf = float(k)
    return kf * (ph - ref)


# --------------------------------------------------------------------------- #
# 6. 便利関数: 位相シフト画像列 → 高さ                                           #
# --------------------------------------------------------------------------- #
def decode_fringe(phase_shift_images, ref_phase=None, k=1.0,
                  mask=None, min_modulation=None, method="general") -> np.ndarray:
    """位相シフト画像列を一括復号: wrapped → unwrap →(参照減算で)高さ。

    phase_shift_images: N-step 位相シフト縞画像列((N,H,W) または長さ N のシーケンス)。
    ref_phase:          参照平面(高さ 0)のアンラップ済み位相。None なら高さ = k·(unwrapped)。
    k:                  位相→高さ較正定数。
    mask:               省略可。True=有効画素。無効画素は NaN。
    min_modulation:     省略可。指定すると modulation < この値の画素を低信頼として無効化。

    返り値: 高さマップ(2D float)。ref_phase=None のときは k を掛けた連続位相を返す。
    無効画素は NaN。

    手順(実装どおり): ``wrapped_phase`` → 信頼マスクを組む(``min_modulation`` が
    あれば ``modulation(stack) >= min_modulation``、``mask`` があればそれと AND)→
    ``ref_phase`` が ``None`` なら ``k * unwrap_phase_2d(wrapped, mask=信頼マスク)``、
    あれば ``k * unwrap_phase_2d(wrap(wrapped − ref_phase), mask=信頼マスク)``
    (大域の ``2πm`` は中央値を ``[−π, π]`` に入れる分岐)。

    引数:
    - ``phase_shift_images``: ``(N, H, W)``、``N >= 3``、等間隔位相シフト。
    - ``ref_phase``: スカラまたは ``(H, W)``。参照面(高さ 0)の位相 —— 本 op で
      ``ref_phase=None, k=1`` として復号した結果でも、解析的な位相でもよい。
      ★差を先に取ってから展開する: ``Δ = wrap(wrapped − ref_phase)`` を 1 回だけ
      ``unwrap_phase_2d`` し、``ref_phase`` の ``2πm`` のずれは wrap で消える。
      残る展開の大域の ``2πm`` は「有効画素の中央値が ``[−π, π]`` に入る」分岐に
      揃える(視野の過半が参照面から位相で π 未満の高さにある、という前提)。
      2026-11-05 まで計測面と参照面を別々に展開して引いていて、展開の起点の分岐が
      両者で違うと高さが ``k·2πm`` ずれた(60 条件中 24)。
    - ``k``: 位相→高さの較正定数(単位/rad)。``synthesize_fringes`` の
      ``phase_gain`` の逆数に対応。
    - ``mask``: ``(H, W)`` の bool、True = 有効。``min_modulation``: 変調度の下限
      (``[0, 1]`` 程度。影・飽和の画素を落とす)。

    検証(``ValueError``): 画像列が 3-D でない・``N < 3``・非有限 / ``mask`` の形が
    違う / ``ref_phase`` の形が違う / 有効画素がゼロ。scikit-image が無ければ
    ``RuntimeError``。

    返り値: ``(H, W)`` float64。無効画素は NaN。単位は ``k`` の単位。

    注意: 空間アンラップに依存するので、段差・オクルージョンで島に分かれた場面では
    島ごとに ``2πm k`` の高さオフセットが残りうる。絶対高さが要る場面は
    ``graycode_decode`` → ``absolute_phase`` → ``triangulate_column`` の経路。
    """
    stack = _as_stack(phase_shift_images)
    if method == "general":
        s, c = _phase_sums(stack)
    elif method == "four_step":
        if stack.shape[0] != 4:
            raise ValueError("method='four_step' requires exactly 4 images")
        s, c = stack[1] - stack[3], stack[0] - stack[2]
    else:
        raise ValueError("method must be 'general' or 'four_step'")
    wrapped = _principal(np.arctan2(s, c))

    reliab = None
    if min_modulation is not None:
        reliab = _modulation_from_sums(stack, s, c) >= float(min_modulation)
    if mask is not None:
        m = np.asarray(mask, dtype=bool)
        reliab = m if reliab is None else (reliab & m)

    if ref_phase is None:
        return float(k) * unwrap_phase_2d(wrapped, mask=reliab)
    ref = np.asarray(ref_phase, dtype=np.float64)
    if ref.ndim != 0 and ref.shape != wrapped.shape:
        raise ValueError(
            f"ref_phase shape {ref.shape} does not match phase shape {wrapped.shape}"
        )
    # 差を先に取ってから 1 回だけ展開する(別々に展開すると起点の分岐が揃わない)
    diff = wrapped - ref
    diff = np.mod(diff + np.pi, 2.0 * np.pi) - np.pi
    un = unwrap_phase_2d(diff, mask=reliab)
    med = float(np.nanmedian(un))
    un = un - 2.0 * np.pi * np.round(med / (2.0 * np.pi))
    return float(k) * un


def fringe_ftp_phase(image, carrier_axis="x", carrier_period=None,
                     bandwidth=0.35, k=1.0, min_modulation=None,
                     return_info=False):
    """縞 1 枚から高さ・位相を Takeda の Fourier transform profilometry で復元する。

    2-D FFT の直流から離れた片側一次スペクトルを窓で抜き、複素解析信号へ戻して
    位相を展開し、搬送波の線形ランプを除く。``carrier_axis`` は位相が増える方向
    (``"x"``=列、``"y"``=行)。``carrier_period`` は画素単位で、省略時は指定軸の
    正周波数側にある最大ピークから推定する。★画像が視野の中で周期的(DFT に漏れが無い)
    ときだけ整数ビンを搬送波とし、そうでなければピークの両隣 1 ビンで DTFT のパワーを
    細かく評価してサブビンに直す(2026-11-05 まで常に整数ビンに丸め、7.3 px の縞が
    7.11 px と読まれて位相 RMS 0.63 rad の傾きが残った)。推定した搬送波は、対象の位相の
    搬送軸方向の一様な傾きと区別できない(どちらも同じ画像を作る)—— 傾きを残したい、
    あるいは搬送波が既知なら ``carrier_period`` を渡す。``bandwidth`` は搬送周波数に対する
    Gaussian 窓の標準偏差の比(0 < bandwidth < 1)。``k`` は rad から高さへの係数。

    返り値は通常 ``height``。``return_info=True`` なら ``(height, info)`` となり、
    ``info`` は搬送波を除いた ``phase``、実際に使った
    ``carrier_period``、``carrier_frequency``、``estimated_carrier``、解析信号の
    ``modulation`` を持つ。高さは既存の ``phase_to_height(phase, 0, k)`` で作る。

    業務上の言い方では「縞 1 枚から高さ」「1枚の縞画像から位相」を求める op。

    1 枚で済む代わりに、対象位相の空間帯域が搬送波と直流/反対側サイドバンドの間に
    収まる必要がある。急な高さ、段差、オクルージョンでは帯域重なりと Itoh 条件違反で
    誤る。3 枚以上を撮れて広い帯域や低い搬送波を扱うなら ``decode_fringe`` の位相
    シフト法を使う。一定画像や、抽出した変調振幅が画像の動的範囲に対して小さすぎる
    画像は丸め誤差から位相を作らず ``ValueError`` にする。

    出典: M. Takeda, H. Ina and S. Kobayashi, “Fourier-transform method of
    fringe-pattern analysis for computer-based topography and interferometry,”
    J. Opt. Soc. Am. 72(1), 156–160 (1982), doi:10.1364/JOSA.72.000156.
    """
    im = np.asarray(image, dtype=np.float64)
    if im.ndim != 2 or im.size == 0:
        raise ValueError(f"fringe_ftp_phase expects a non-empty 2D image: got shape={im.shape}")
    if not np.all(np.isfinite(im)):
        raise ValueError("fringe_ftp_phase: image contains NaN/Inf")
    axis = {"x": 1, "y": 0, 1: 1, 0: 0}.get(carrier_axis)
    if axis is None:
        raise ValueError("carrier_axis must be 'x' or 'y'")
    bw = float(bandwidth)
    if not 0.0 < bw < 1.0:
        raise ValueError("bandwidth must satisfy 0 < bandwidth < 1")
    dynamic = float(np.ptp(im))
    # ★床は画像自身の尺度の相対量(2026-11-05 まで max(|im|, 1.0) で、1e-15 倍した
    # 同じ縞を「一定」と拒否していた —— modulation の絶対床 O6 の兄弟)
    scale = float(np.max(np.abs(im)))
    if dynamic <= 64.0 * np.finfo(float).eps * scale or scale == 0.0:
        raise ValueError("fringe_ftp_phase: image is constant (no fringe modulation)")

    centered = im - float(np.mean(im))
    spectrum = np.fft.fftshift(np.fft.fft2(centered))
    h, w = im.shape
    fy = np.fft.fftshift(np.fft.fftfreq(h))[:, None]
    fx = np.fft.fftshift(np.fft.fftfreq(w))[None, :]
    along = fx if axis == 1 else fy
    cross = fy if axis == 1 else fx
    estimated = carrier_period is None
    if estimated:
        # A carrier must be separated from DC by at least two DFT bins.  Integrating
        # over the transverse direction makes the estimate stable for 2-D phase fields.
        power = np.abs(spectrum) ** 2
        profile = power.sum(axis=0 if axis == 1 else 1)
        freq = np.fft.fftshift(np.fft.fftfreq(w if axis == 1 else h))
        min_f = 2.0 / (w if axis == 1 else h)
        eligible = freq >= min_f
        if not np.any(eligible):
            raise ValueError("fringe_ftp_phase: image is too small to separate a carrier")
        idxs = np.flatnonzero(eligible)
        peak_i = int(idxs[np.argmax(profile[eligible])])
        positive_power = profile[eligible]
        prominence = float(positive_power.max()) / max(
            float(np.median(positive_power)), np.finfo(float).tiny)
        if prominence < 5.0:
            raise ValueError(
                "fringe_ftp_phase: no distinct carrier peak "
                f"(spectral prominence {prominence:.3g} < 5)"
            )
        carrier_f = float(freq[peak_i])
        # ★DFT のビン(1/画素数)に丸めたままにしない: 7.3 px の縞が 7.11 px と読まれ、
        # 残った 1 次の傾きが位相 RMS 0.63 rad になっていた(2026-11-05)。
        # 画像が視野の中で周期的(搬送波が整数周期 + 周期的な対象、合成データの理想)なら
        # DFT は厳密で、整数ビンが搬送波そのもの —— その印は搬送波と直流から 8 ビン以上
        # 離れた帯域に漏れが無いこと(パワーの中央値がピークの 1e-12 未満)。漏れがある
        # (端で切れた縞、雑音のある実データ)ときは、ピークの両隣 1 ビンの範囲で搬送軸に
        # 沿った DTFT のパワー(横方向に和、単一正弦波の最尤推定)を細かい格子で評価し、
        # 放物線で細分してサブビンに直す。
        n_al = w if axis == 1 else h
        k_pk = int(round(carrier_f * n_al))
        kk = np.round(freq * n_al).astype(np.int64)
        far = (kk > 8) & (np.abs(kk - k_pk) > 8)
        periodic = bool(far.any()) and float(np.median(profile[far])) < 1e-12 * float(profile[peak_i])
        if not periodic:
            rows = centered if axis == 1 else centered.T          # (横, 搬送軸)
            grid = carrier_f + np.linspace(-1.0, 1.0, 201) / n_al
            basis = np.exp(-2j * np.pi * np.outer(np.arange(n_al), grid))
            pw = (np.abs(rows @ basis) ** 2).sum(axis=0)
            j = int(np.argmax(pw))
            cf = float(grid[j])
            if 0 < j < grid.size - 1:
                y0, y1, y2 = np.log(pw[j - 1:j + 2] + np.finfo(float).tiny)
                den = y0 - 2.0 * y1 + y2
                if den < 0.0:
                    cf += 0.5 * (y0 - y2) / den * float(grid[1] - grid[0])
            if 0.0 < cf < 0.5:
                carrier_f = cf
    else:
        period = float(carrier_period)
        if not np.isfinite(period) or period <= 2.0:
            raise ValueError("carrier_period must be finite and greater than 2 pixels")
        carrier_f = 1.0 / period
        if carrier_f >= 0.5:
            raise ValueError("carrier_period puts the carrier at/above Nyquist")

    sigma = max(carrier_f * bw, 1.0 / max(h, w))
    window = np.exp(-0.5 * (((along - carrier_f) / sigma) ** 2 + (cross / sigma) ** 2))
    analytic = np.fft.ifft2(np.fft.ifftshift(spectrum * window))
    amp = 2.0 * np.abs(analytic)
    relative_mod = float(np.percentile(amp, 75)) / dynamic
    if min_modulation is None:
        min_modulation = 0.05
    if relative_mod < float(min_modulation):
        raise ValueError(
            "fringe_ftp_phase: no separable fringe sideband "
            f"(relative modulation {relative_mod:.3g} < {float(min_modulation):.3g})"
        )
    wrapped = np.angle(analytic)
    unwrapped = unwrap_phase_2d(wrapped)
    coord = (np.arange(w)[None, :] if axis == 1 else np.arange(h)[:, None])
    phase = unwrapped - 2.0 * np.pi * carrier_f * coord
    phase -= float(np.nanmean(phase))
    height = phase_to_height(phase, 0.0, k)
    info = {
        "phase": phase,
        "carrier_period": 1.0 / carrier_f,
        "carrier_frequency": carrier_f,
        "estimated_carrier": estimated,
        "modulation": amp,
        "relative_modulation": relative_mod,
    }
    return (height, info) if return_info else height


# --------------------------------------------------------------------------- #
# 7. 合成ヘルパ: 既知 height map → 位相シフト縞画像列                            #
# --------------------------------------------------------------------------- #
def synthesize_fringes(height, n_steps=4, freq=1.0, phase_gain=1.0,
                       bias=0.5, amplitude=0.5, axis=1, noise=0.0,
                       seed=None, return_phase=False):
    """既知の height map から N-step 位相シフト縞画像列を合成する(テスト/サンプル生成用)。

    モデル: 総位相 φ(x,y) = φ_carrier + phase_gain·height。搬送波 φ_carrier は視野を横切る線形
    ランプ(freq 周期)。各フレームは I_n = bias + amplitude·cos(φ - δ_n), δ_n = 2πn/N。
    この符号規約により wrapped_phase(...) は総位相 φ をそのまま復元する。

    height:      2D 配列(計測対象の高さ場、任意単位)。
    n_steps:     位相シフト枚数 N(>=3)。
    freq:        視野幅を横切る搬送波の周期数(縞本数)。0 なら搬送波なし(height のみ)。
    phase_gain:  高さ→位相の変換ゲイン(rad/単位)。復号側の較正 k = 1/phase_gain に対応。
    bias:        平均輝度 a(既定 0.5)。
    amplitude:   縞振幅 b(既定 0.5)。bias±amplitude が [0,1] に収まると自然。
    axis:        搬送波の方向(1 = 列方向 x に沿う既定、0 = 行方向 y)。
    noise:       付加ガウスノイズの標準偏差(0 で無ノイズ)。
    seed:        ノイズ用乱数シード。
    return_phase: True なら (images, total_phase) を返す(テスト・デバッグ用)。

    返り値: (N, H, W) float 配列(値域 [0,1] にクリップ)。return_phase=True なら位相も。

    空の入力(``height`` が 0 要素)は ValueError。
    """
    if (len(height) if isinstance(height, (list, tuple)) else np.asarray(height).size) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("synthesize_fringes: height is empty — pass at least one element")
    h = np.asarray(height, dtype=np.float64)
    if h.ndim != 2:
        raise ValueError(f"height must be a 2D array: got shape={h.shape}")
    n = int(n_steps)
    if n < 3:
        raise ValueError(f"n_steps must be >= 3: n_steps={n}")
    if axis not in (0, 1):
        raise ValueError(f"axis must be 0 (rows) or 1 (cols): axis={axis}")
    if amplitude < 0 or bias < 0:
        raise ValueError("bias / amplitude must be non-negative")

    rows, cols = h.shape
    # 搬送波: axis に沿った [0,1) 正規化座標 × 2π × freq
    if axis == 1:
        length = max(cols, 1)
        coord = (np.arange(cols, dtype=np.float64) / length)[None, :]
    else:
        length = max(rows, 1)
        coord = (np.arange(rows, dtype=np.float64) / length)[:, None]
    carrier = 2.0 * np.pi * float(freq) * coord  # broadcast → (rows, cols)
    carrier = np.broadcast_to(carrier, h.shape)

    total_phase = carrier + float(phase_gain) * h

    if noise and seed is None:   # 敵対的検証 2026-11-05 第 2 巡 T7(lockin / photoncount と同じ規約)
        raise ValueError("synthesize_fringes: noise needs an explicit integer seed (seed=None would draw fresh noise on every call)")
    rng = np.random.default_rng(seed)
    images = np.empty((n, rows, cols), dtype=np.float64)
    for idx in range(n):
        delta = 2.0 * np.pi * idx / n
        frame = float(bias) + float(amplitude) * np.cos(total_phase - delta)
        if noise:
            frame = frame + rng.normal(0.0, float(noise), size=frame.shape)
        images[idx] = np.clip(frame, 0.0, 1.0)

    if return_phase:
        return images, total_phase
    return images


# --------------------------------------------------------------------------- #
# 8. 絶対位相(粗い推定で 2π 次数を確定する)                                     #
# --------------------------------------------------------------------------- #
def absolute_phase(wrapped, coarse) -> np.ndarray:
    """巻き込み位相を、粗いが絶対的な位相推定で「次数確定」して絶対位相にする。

    Φ = wrapped + 2π·round((coarse − wrapped) / 2π)

    wrapped: wrapped_phase の出力 (-π,π] の 2D 配列(高精度・絶対次数なし)。
    coarse:  同形の 2D 配列。**絶対だが粗い**位相推定 [rad]。Gray code で復号した投影機
             コラム番号を位相に直したもの(2π·freq·col/width)が典型。NaN 可(出力も NaN)。

    返り値: 絶対位相 [rad](2D float64)。無効画素(どちらかが NaN)は NaN。

    なぜ必要か(空間アンラップとの違い): `unwrap_phase_2d` は隣接画素を辿って 2π 跳びを
    繋ぐので、(a) 大域オフセット +2πm が残り、(b) オクルージョンで切れた島の間では次数が
    伝播できない。本 op は画素ごとに独立に次数を決めるため、**島に分かれた場面でも絶対**で、
    伝播も要らない。その代わり coarse の誤差が半周期(π)未満であることが要件。

    要件(fail-closed): |coarse − Φ_true| < π。これを破ると round が隣の次数を選び、
    その画素だけ 2π ぶん(= 縞 1 本ぶんの奥行き)静かにずれる。Gray code の粗さ(±0.5 コラム)
    を位相に直した量が半周期を超えないよう、縞本数 freq を選ぶこと
    (例: 投影機幅 512 px・freq 24 → 1 周期 21.3 px、Gray の ±0.5 px は余裕で内側)。

    ★次数の誤りは戻り値から見分けられない(2026-11-09 実測): 多周波の時間的アンラップ
    (16/4/1 mm、比 4、20 万画素)で位相雑音 σφ = 0.10/0.20/0.30/0.40/0.60 rad のとき、
    0/0.097/2.57/11.6/36.8 % の画素が 2π 次数を誤り、どれも有限の値で返る。**残差を見る**:
    ``Phi = absolute_phase(w, c); resid = c - Phi`` とし、``|resid| > 0.8π`` 程度の画素を疑わしいと
    して捨てる(上の条件で誤りの 33〜74 % を拾う。要件 |coarse − Φ| < π の破れの兆し)。
    coarse の単位(ラジアン)も検査しない —— 度を渡すと 1106 rad(真 19.35)のような値が黙って返る。
    次数を確かめる別の op はまだ無い(残差と印を返す op は op を足す便で入れる)。

    Raises: 形状不一致・2D でない・wrapped が (-π,π] を大きく外れる場合に ValueError。

    来歴(公開文献): Gray code と位相シフトを併用して絶対位相を得る合成法 —
    Sansoni et al., *Appl. Opt.* 38(31) 1999 / Zhang, *Opt. Lasers Eng.* 48 2010(総説)。
    Gray code そのものの投影は Inokuchi et al., *ICPR* 1984。
    """
    w = np.asarray(wrapped, dtype=np.float64)
    c = np.asarray(coarse, dtype=np.float64)
    if w.ndim != 2:
        raise ValueError(f"wrapped must be a 2D array: got shape={w.shape}")
    if c.shape != w.shape:
        raise ValueError(f"coarse shape {c.shape} does not match wrapped shape {w.shape}")
    finite = np.isfinite(w)
    if finite.any() and np.nanmax(np.abs(w[finite])) > np.pi + 1e-6:
        raise ValueError(
            "wrapped must lie in (-pi, pi] (did you pass an already-unwrapped phase?): "
            f"max|wrapped|={float(np.nanmax(np.abs(w[finite]))):.6g}"
        )
    two_pi = 2.0 * np.pi
    with np.errstate(invalid="ignore"):
        order = np.round((c - w) / two_pi)
    return w + two_pi * order


# --------------------------------------------------------------------------- #
# 9. 三角測量(投影機コラム → カメラ深度)                                        #
# --------------------------------------------------------------------------- #
def triangulate_column(column, k_cam, k_proj, rot, trans) -> np.ndarray:
    """各カメラ画素の「投影機コラム番号」から深度 Z を三角測量する(構造化光の最終段)。

    構造化光スキャナの幾何そのもの: カメラ画素 (u,v) は 1 本の視線を張り、投影機のコラム
    番号 u_p は 1 枚の平面(投影機中心とそのコラムを含む平面)を張る。視線と平面の交点が
    表面の 3D 点で、そのカメラ系 Z が深度になる。**閉じた式**なので反復も最適化も要らない。

    column: (H, W) の投影機コラム番号(**サブピクセル実数**)。位相から出した値をそのまま
            渡せる。NaN = 未確定画素(出力も NaN)。
    k_cam:  カメラ内部行列 3x3(fx, fy, cx, cy[, skew])。画素中心は整数座標
            (`render3d.render_mesh` / `camera.depth_to_points` と同じ約束)。
    k_proj: 投影機内部行列 3x3。使うのは第 0 行(コラム方向)と第 2 行だけ。
    rot:    3x3 回転。カメラ系 → 投影機系(X_proj = rot·X_cam + trans)。
    trans:  長さ 3 の並進(同上、単位はシーンと同じ)。**ゼロベクトルは禁止**
            (基線 0 = カメラと投影機が同一点。平面と視線が交わらず深度が定義できない)。

    返り値: (H, W) float64 の深度マップ(カメラ前方の Z、`render_mesh` の depth と同じ量)。
            交点が後方(Z<=0)や視線が平面と平行な画素は NaN。

    導出: X_cam = Z·d(d = K_cam⁻¹[u,v,1])。投影機側のコラム条件は
    (K_proj[0] − u_p·K_proj[2])·X_proj = 0。X_proj = rot·X_cam + trans を代入して
    Z について解くと Z = −(a·trans) / (a·(rot·d))、a = K_proj[0] − u_p·K_proj[2]。

    Raises: 形状・行列不正、基線ゼロ、特異なカメラ行列で ValueError。

    来歴(公開文献): 光線と平面の交点による構造化光三角測量 — Hartley & Zisserman,
    *Multiple View Geometry* 2nd ed. §12(射影幾何の交わり)/ Salvi et al.,
    *Pattern Recognition* 43 2010(構造化光パターンの分類と復号)。

    空の入力(``column`` が 0 要素)は ValueError。
    """
    if (len(column) if isinstance(column, (list, tuple)) else np.asarray(column).size) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("triangulate_column: column is empty — pass at least one element")
    col = np.asarray(column, dtype=np.float64)
    if col.ndim != 2:
        raise ValueError(f"column must be a 2D (H, W) map: got shape={col.shape}")
    kc = np.asarray(k_cam, dtype=np.float64)
    kp = np.asarray(k_proj, dtype=np.float64)
    for nm, m in (("k_cam", kc), ("k_proj", kp)):
        if m.shape != (3, 3) or not np.all(np.isfinite(m)):
            raise ValueError(f"{nm} must be a finite 3x3 intrinsic matrix: got shape={m.shape}")
    if abs(float(np.linalg.det(kc))) < 1e-12:
        raise ValueError("k_cam is singular (zero focal length?)")
    R = np.asarray(rot, dtype=np.float64)
    if R.shape != (3, 3) or not np.all(np.isfinite(R)):
        raise ValueError(f"rot must be a finite 3x3 rotation: got shape={R.shape}")
    t = np.asarray(trans, dtype=np.float64).reshape(-1)
    if t.shape != (3,) or not np.all(np.isfinite(t)):
        raise ValueError(f"trans must be a finite length-3 vector: got shape={t.shape}")
    if float(np.linalg.norm(t)) < 1e-12:
        raise ValueError("zero baseline: camera and projector coincide, depth is undefined")

    h, w = col.shape
    v_i, u_i = np.mgrid[0:h, 0:w].astype(np.float64)
    # M・b を一度だけ作ると、画素ごとの視線・平面ベクトル(H,W,3)が不要になる。
    M = kp @ R @ np.linalg.inv(kc)
    b = kp @ t
    denom = ((M[0, 0] - col * M[2, 0]) * u_i
             + (M[0, 1] - col * M[2, 1]) * v_i
             + (M[0, 2] - col * M[2, 2]))
    num = col * b[2] - b[0]
    with np.errstate(divide="ignore", invalid="ignore"):
        z = num / denom
    bad = ~np.isfinite(z) | (np.abs(denom) < 1e-12) | (z <= 0.0) | ~np.isfinite(col)
    z[bad] = np.nan
    return z
