"""異種構造の統合(TRIZ 統合/複合)= 全5構造を組み合わせる。

マトリクスの「行」(データ構造)を掛け合わせる層: どの構造も共通表現(点群 / voxel)へ**変換**して
寄せれば、**異種構造間の相互マッチ**(例: CAD mesh vs LiDAR 点群スキャン = Physical AI 典型課題)や
**多構造フュージョン**(mesh + points + depth → 1 つの密度 voxel)ができる。変換グラフ(match3d)が土台。
"""
import numpy as np

import match3d as X
import feat_fpfh


def to_points(data, kind, samples=20000, **kw):
    """任意の 3D 構造 → 点群(共通表現)。全5構造を 1 本の入口へ統合。

    kind: "points"(N,3)/ "mesh"=(vertices,faces)/ "depth"=depth+{fx,fy,cx,cy[,stride]}/
          "voxel"=密度 grid+{iso}/ "3dgs"=means(N,3)。

    ``kind`` ごとの変換(実装どおり):
    - ``"points"`` / ``"3dgs"``: ``np.asarray(data, float)`` を返すだけ(形の検査は
      しない。``(N, 3)`` を渡すのは呼び手の責任)。
    - ``"mesh"``: ``data = (vertices, faces)``。``match3d.mesh_to_points`` で面積重みの
      一様サンプリングを ``samples`` 点(既定 20000、seed 固定 = 決定的)。
    - ``"depth"``: ``data`` は深度マップ ``(H, W)``、``kw`` に ``fx, fy, cx, cy`` が
      **必須**(無ければ ``KeyError``)、``stride`` は任意(既定 1、間引き)。
      ``match3d.depth_to_points`` のピンホール逆投影で、``depth > 0`` の画素だけを
      ``(x, y, z)`` 点にする(カメラ座標、x = 列方向、y = 行方向、z = 深度)。
    - ``"voxel"``: 密度 grid ``(D, H, W)`` を ``kw["iso"]``(既定 0.5)で閾値し、
      ``np.argwhere`` の **整数 index 座標** ``(z, y, x)`` を float にした点群。
      物理座標には直さない(spacing は掛けない)。

    返り値: ``(N, 3)`` float64。``kind`` が上記以外なら ``ValueError``。
    ``samples`` は ``"mesh"`` 以外では無視される。

    注意: ``"voxel"`` の座標は配列 index 順 ``(z, y, x)``、``"depth"`` はカメラ座標
    ``(x, y, z)`` と、種別ごとに軸の意味が違う。異種を ``register_cross`` /
    ``fuse_to_voxel`` で混ぜるときは、この差を呼び手が揃えておくこと。

    空の入力(``data`` が 0 要素)は ValueError。
    """
    if (len(data) if isinstance(data, (list, tuple)) else data.numel() if hasattr(data, "numel") else np.asarray(data).size) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("to_points: data is empty — pass at least one element")
    if kind == "points":
        return np.asarray(data, float)
    if kind == "mesh":
        return X.mesh_to_points(data[0], data[1], samples)
    if kind == "depth":
        return X.depth_to_points(data, kw["fx"], kw["fy"], kw["cx"], kw["cy"], kw.get("stride", 1))
    if kind == "voxel":
        return np.argwhere(np.asarray(data) > kw.get("iso", 0.5)).astype(float)
    if kind == "3dgs":
        return np.asarray(data, float)
    raise ValueError(f"unknown structure kind: {kind}")


def _np(x):
    return x.detach().cpu().numpy() if hasattr(x, "detach") else np.asarray(x)


def register_cross(src, src_kind, dst, dst_kind, method="fpfh", samples=15000, **kw):
    """異種構造間の剛体登録。両者を点群へ変換 → 登録器(fpfh=大回転/icp=要 coarse init)。

    例: register_cross((verts,faces),"mesh", scan_pts,"points") で CAD↔スキャン整合。返り値 (R, t)。

    手順: ``to_points(src, src_kind, samples, **kw)`` と ``to_points(dst, dst_kind,
    samples, **kw)`` で両者を点群にし、``method`` で登録器を選ぶ。
    - ``"fpfh"``(既定): ``feat_fpfh.register_fpfh(ps, pd)`` を既定パラメータで呼ぶ
      (FPFH 記述子 + RANSAC、初期姿勢不要、大回転・部分重なりに対応)。
    - ``"icp"``: ``match3d.icp_point2point_3d(ps, pd, iters=50)``(最近傍対応 +
      Kabsch)。初期姿勢の引数は渡さないので、``src`` が ``dst`` に近い(粗く
      合っている)ことが前提。
    - それ以外は ``ValueError``。

    返り値: ``(R, t)`` — ``R`` は ``(3, 3)``、``t`` は ``(3,)`` の numpy 配列(torch tensor
    は CPU の numpy に変換して返す)。慣習は ``dst ≈ src @ R.T + t``。

    注意:
    - ``**kw`` は **両方の** ``to_points`` に同じものが渡る(``"depth"`` の ``fx, fy, cx,
      cy`` や ``"voxel"`` の ``iso`` を片側だけに与えることはできない)。
    - ``samples`` は ``"mesh"`` のサンプル数(既定 15000)。点群の個数・形は検査しない。
    - 座標系の違い(``to_points`` 参照: voxel は ``(z, y, x)`` index、depth はカメラ
      ``(x, y, z)``)は吸収しない。
    - 精度を締めるには fpfh の結果を初期値に ``icp_point2point_3d`` を直接呼ぶ。
    """
    ps = to_points(src, src_kind, samples, **kw)
    pd = to_points(dst, dst_kind, samples, **kw)
    if method == "fpfh":
        out = feat_fpfh.register_fpfh(ps, pd)
        return _np(out[0]), _np(out[1])
    if method == "icp":
        R, t, _ = X.icp_point2point_3d(ps, pd, iters=50)
        return _np(R), _np(t)
    raise ValueError(f"unknown registration method: {method}")


def fuse_to_voxel(items, size=64, bounds=None, device="cpu", smooth=0.8):
    """複数構造を共通密度 voxel へ融合(TRIZ 統合)。items=[(data,kind,params_dict), ...]。

    mesh(topology)+ points(sample)+ depth(観測)等の相補的な構造を 1 表現に。返り値 (voxel, bounds)。

    手順: 各 ``(data, kind, params)`` を ``to_points(data, kind, **params)`` で点群にして
    縦に連結し、``match3d.points_to_voxel`` で ``size^3`` の密度 grid に splat する
    (各点が落ちる cell を +1、``smooth > 0`` なら σ = ``smooth`` voxel の Gaussian で
    平滑)。``bounds=None`` なら連結点群の ``(min, max)`` を格子範囲にする。

    引数:
    - ``items``: 空でない list/tuple で、各要素が長さ 3 の ``(data, kind, params_dict)``
      (``params_dict`` は ``dict`` 必須)。``to_points`` の ``samples`` を変えたければ
      ``params`` に ``samples=`` を入れる。
    - ``size``: 1 軸の voxel 数(立方格子固定)。
    - ``bounds``: ``(lo, hi)`` それぞれ長さ 3。複数の雲を同じ格子に載せるとき(比較・
      ``voxel_iou``)は必ず明示する。
    - ``device``: torch デバイス(``"cpu"`` / ``"cuda"``)。``smooth``: Gaussian σ [voxel]。

    返り値: ``(voxel, bounds)`` — ``voxel`` は ``(size, size, size)`` float64 の
    **点数密度**(合計 ≈ 総点数、確率ではない)、``bounds`` は実際に使った ``(lo, hi)``。
    格子 index は ``points_to_voxel`` の ``floor((p - lo) / span * (size - 1))`` で、
    軸 0 が点の x 成分に対応する(voxel の軸順 = 点の成分順)。

    検証(``ValueError``): ``items`` が list/tuple でない・空・要素が 3 組でない・
    ``params`` が dict でない(生データを直接渡す誤用を入口で止める)。
    """
    # fail-closed: items は [(data, kind, params), ...]。生データを渡す誤用は
    # 素の TypeError で深部から落ちる(連鎖ファザー実測)ので入口で明示拒否
    if not isinstance(items, (list, tuple)) or not items or not all(
            isinstance(it, (list, tuple)) and len(it) == 3
            and isinstance(it[2], dict) for it in items):
        raise ValueError("items must be a non-empty list of (data, kind, "
                         "params_dict) triples — e.g. [((V, F), 'mesh', {}), "
                         "(pts, 'points', {})], got %r" % (type(items).__name__,))
    allpts = [to_points(d, k, **p) for d, k, p in items]
    P = np.vstack(allpts)
    if bounds is None:
        bounds = (P.min(0), P.max(0))
    return X.points_to_voxel(P, size, bounds, device, smooth=smooth), bounds
