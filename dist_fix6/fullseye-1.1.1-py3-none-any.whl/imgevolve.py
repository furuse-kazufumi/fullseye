"""imgevolve — single CLI entry point (designed to be usable by a future agent).

A future Claude Code session should be able to *use* this HALCON-parity library
without re-reading the source. Discover and invoke everything from here:

    py -3.11 imgevolve.py ops                    # list every implemented operator
    py -3.11 imgevolve.py ops --search edge      # search by name / halcon / category
    py -3.11 imgevolve.py ops --sort region      # filter by input sort
    py -3.11 imgevolve.py has gauss_filter       # is a HALCON op implemented? how to call it
    py -3.11 imgevolve.py apply gauss_filter in.png out.png --a 0.6
    py -3.11 imgevolve.py apply add_image a.png out.png --input2 b.png   # n-ary op (two inputs)
    py -3.11 imgevolve.py pipeline in.png out.png --ops "gauss_filter,sobel_amp,otsu"
    py -3.11 imgevolve.py coverage               # honest coverage numbers
    py -3.11 imgevolve.py index                  # (re)write docs/OP_INDEX.json (machine-readable)
    py -3.11 imgevolve.py algo list              # general-algorithm tier (sorts/reductions)
    py -3.11 imgevolve.py algo run quicksort --seq 3,1,2   # -> [1.0, 2.0, 3.0]
    py -3.11 imgevolve.py algo emit-c mergesort  # standalone, compilable C
    py -3.11 imgevolve.py algo difftest all      # honest gate (Python==oracle, C==Python bit-for-bit)
    py -3.11 imgevolve.py synth in.png out.png   # learn a texture -> synthesise a similar image
    py -3.11 imgevolve.py synth in.png out.png --method patch --size 320x320

Sorts: image (gray H*W [0,1]) / color (H*W*3 RGB) / region (binary) / feature
(scalar) / contour (XLD) / volume (3-D). `apply` loads the input to match the
op's in_sort and serialises the output by its out_sort (feature -> printed,
contour -> point count + optional raster).
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)


def _load_registry():
    import ops
    return ops


def _all_ops():
    """Every operator across the three tiers, as uniform dicts."""
    ops = _load_registry()
    # ★module / requires(2026-09-19): 「unknown operator」が backend 不足を隠していた
    # (外部レビュー #1)。索引が出自と optional 依存を持てば、core 環境の
    # ``api._resolve`` が同梱の複製(fullseye/data/OP_INDEX.json)から不足 extra を
    # 案内できる。requires は AST で静的に読むので、生成環境に依らず同じ値。
    rows = [{"name": o.name, "halcon": o.halcon, "in_sort": o.in_sort,
             "out_sort": o.out_sort, "category": o.category, "tier": "registry",
             "module": ops.OP_MODULE.get(o.name, "ops"),
             "requires": ops.module_requirements(ops.OP_MODULE.get(o.name, "ops"))}
            for o in ops.REGISTRY]
    # ★握り潰さない(2026-09-06 の敵対的レビュー)。`imgops_nary` は numpy と
    # scipy しか要らない一次モジュールなので、import に失敗するのは「壊れた
    # checkout」であって「その環境には無い機能」ではない。以前は
    # `except Exception: pass` で、**この関数が生成器と検査の両方を兼ねている**
    # ため、17 op が丸ごと消えた索引を CI が緑のまま公開できた。
    import imgops_nary as NA
    rows += [{"name": o.name, "halcon": o.halcon, "in_sort": o.in_sorts[0],
              "out_sort": o.out_sort, "category": "nary", "tier": "nary",
              "arity": o.arity, "in_sorts": list(o.in_sorts)}
             for o in NA.build_nary()]
    assert len(rows) > len(ops.REGISTRY), "nary 層が空(build_nary が何も返さない)"
    return rows


# ---- image I/O ------------------------------------------------------------- #
def _to01_by_dtype(im):
    """Integer samples / their dtype max (uint8 /255, uint16 /65535); float as is."""
    im = np.asarray(im)
    if im.dtype.kind in "ui":
        return im.astype(np.float64) / float(np.iinfo(im.dtype).max)
    return im.astype(np.float64)


#: 復号器が 1 つも無い時の 1 行(%s = 呼ばれ方に合わせた CLI 名)。ASCII だけで書く(cp932 の端末でも同じ文で出る)。
_NO_IMAGE_CODEC = ("%s: reading and writing image files needs OpenCV or Pillow, and neither is installed here. "
                   'Install one:  pip install "fullseye[opencv]"   (or:  pip install "fullseye[pil]")')


def _image_codec() -> str:
    """CLI の画像の読み書きに使う部品: ``"cv2"``(在れば)か ``"pil"``(cv2 が無い時)。

    ★2026-11-13(配布物の検証 M2): ``pip install fullseye`` だけ(numpy と scipy)で ``fullseye apply`` /
    ``pipeline`` が ``No module named 'cv2'`` の生の traceback で落ちていた(``fullseye --help`` の最初の例)。
    ``[pil]`` や ``[gui]`` を入れても直らなかった(ここは cv2 を直に import していた)。cv2 が無ければ Pillow に倒し、
    どちらも無ければ、どの extra を入れればよいかを 1 行で言って止める(``SystemExit`` = rc 1、traceback なし)。
    """
    try:
        import cv2  # noqa: F401
        return "cv2"
    except ImportError:
        pass
    try:
        import PIL.Image  # noqa: F401
        return "pil"
    except ImportError:
        raise SystemExit(_NO_IMAGE_CODEC % _prog()) from None


#: Pillow が 16 bit の灰を持つ形(``np.asarray`` で uint16 になる)
_PIL_16BIT_MODES = ("I;16", "I;16L", "I;16B", "I;16N")


def _imread_pil(path, sort):
    """cv2 の無い環境の読み込み(Pillow)。約束は cv2 の経路と同じ: color は RGB、灰は 16 bit の標本を保って
    dtype の最大値で割る、region は 0.5 で 2 値、EXIF の向きを守る(``cv2.imread`` と同じ)。"""
    from PIL import Image, ImageOps
    try:
        with Image.open(path) as im0:
            im = ImageOps.exif_transpose(im0)
            if im.mode in _PIL_16BIT_MODES or im.mode == "I":
                a = np.asarray(im)
                if a.dtype.kind == "i" and a.size and a.min() >= 0 and a.max() <= 65535:
                    a = a.astype(np.uint16)          # 32 bit の箱に入った 16 bit の標本(古い Pillow の "I")
                g = _to01_by_dtype(a)
                if sort == "color":
                    return np.repeat(g[:, :, None], 3, axis=2)
            elif sort == "color":
                return _to01_by_dtype(np.asarray(im.convert("RGB")))
            else:
                g = _to01_by_dtype(np.asarray(im.convert("L")))
    except (OSError, ValueError) as e:              # 無い・壊れた・画像でない(UnidentifiedImageError も OSError)
        raise SystemExit("cannot read %s (%s)" % (path, e)) from None
    return (g > 0.5).astype(np.float64) if sort == "region" else g


def _imread(path, sort):
    if _image_codec() == "pil":
        return _imread_pil(path, sort)
    # ★2026-10-24: IMREAD_COLOR / IMREAD_GRAYSCALE alone demote a 16-bit file to
    #   8 bits (cv2 drops the low byte) and the result was then divided by 255.
    #   IMREAD_ANYDEPTH keeps the samples; scaling follows the decoded dtype.
    import cv2
    if sort == "color":
        im = cv2.imread(path, cv2.IMREAD_COLOR | cv2.IMREAD_ANYDEPTH)
        if im is None:
            raise SystemExit("cannot read %s" % path)
        return _to01_by_dtype(im[:, :, ::-1])                  # BGR->RGB
    im = cv2.imread(path, cv2.IMREAD_GRAYSCALE | cv2.IMREAD_ANYDEPTH)
    if im is None:
        raise SystemExit("cannot read %s" % path)
    g = _to01_by_dtype(im)
    return (g > 0.5).astype(np.float64) if sort == "region" else g


def _imwrite(path, v):
    codec = _image_codec()
    v = np.asarray(v)
    if codec == "pil":
        if v.ndim == 3 and v.shape[-1] == 1:
            v = v[:, :, 0]
        out = np.clip(np.asarray(v, np.float64) * 255, 0, 255).astype(np.uint8)    # RGB のまま(Pillow は RGB)
        from PIL import Image
        try:
            Image.fromarray(out).save(path)
        except (OSError, ValueError, KeyError, TypeError) as e:    # 未対応の拡張子・書けない場所・形
            raise SystemExit("cannot write %s (%s)" % (path, e)) from None
        return
    import cv2
    if v.ndim == 3 and v.shape[-1] == 3:
        out = np.clip(v * 255, 0, 255).astype(np.uint8)[:, :, ::-1]     # RGB->BGR
    else:
        out = np.clip(np.asarray(v, np.float64) * 255, 0, 255).astype(np.uint8)
    cv2.imwrite(path, out)


# ---- subcommands ----------------------------------------------------------- #
def cmd_ops(a):
    """op の一覧。

    ★2026-09-25: この一覧はレジストリと n-ary しか見ておらず、``--search msa`` が
    **``0 ops match`` と言い切って**いた —— 台帳には 4 件在るのに。同じ欠陥は
    ``has`` では 2026-09-20 に(N131「発見面と判定面が別だった」)、``api.list_ops``
    では 2026-09-25 に塞がれており、**この一覧だけが 3 面目として残っていた**。

    既定の並びは据え置き(画像の語彙)。ただし**台帳に当たりが在るのに黙らない** ——
    件数の下に何件隠れているかを出す。0 件と「0 件に見えているだけ」は別物である。
    """
    import api as _api
    rows = _all_ops()
    ledger = _api.ledger_rows()
    kw = _api._fold(a.search or "")                      # 大小とアクセントを畳む(GenSpark N85 / N132)

    def _hit(r):
        if a.sort and _api._fold(r["in_sort"] or "") != _api._fold(a.sort):
            return False
        return not kw or kw in _api._fold(
            r["name"] + " " + (r["halcon"] or "") + " " + (r["category"] or ""))

    shown = rows + (ledger if a.include_ledger else [])
    for r in sorted(shown, key=lambda r: (r["tier"], r["in_sort"] or "", r["name"])):
        if not _hit(r):
            continue
        print("%-26s %-8s->%-8s  halcon=%-24s [%s/%s]"
              % (r["name"], r["in_sort"] or "-", r["out_sort"] or "-", r["halcon"] or "-",
                 r["tier"], r["category"]))
    print("--- %d ops match ---" % sum(1 for r in shown if _hit(r)))
    if not a.include_ledger:
        hidden = sum(1 for r in ledger if _hit(r))
        if hidden:
            print("--- 台帳層にさらに %d 件(--include-ledger で並ぶ; "
                  "呼び方は fullseye.op_assist('<op>')) ---" % hidden)
    return 0


def _disposition(op):
    p = os.path.join(HERE, "docs", "OP_DISPOSITION.json")
    if not os.path.exists(p):
        return None
    return json.load(open(p, encoding="utf-8"))["dispositions"].get(op)


def cmd_has(a):
    rows = _all_ops()
    q = a.op.lower()
    hits = [r for r in rows if q in (r["name"].lower(), (r["halcon"] or "").lower())]
    if not hits:
        # ★2026-09-20(GenSpark 第 37 報 N131): 台帳 op(`color_lut`)と汎用アルゴリズム(`quicksort`)は索引に
        # 載っているのに `has` が「unknown」と答えていた —— 発見面(索引)と判定面(registry + nary)が別だった。
        # 索引(同梱複製)の台帳行と algo 層をここで引く。
        import api as _api
        row = _api._shipped_index().get(a.op) or {}
        if row.get("tier") == "ledger":
            print("IMPLEMENTED (typed ledger): name=%s  %s->%s  ledger=%s  module=%s  tier=ledger"
                  % (a.op, row.get("in_sort") or "?", row.get("out_sort") or "?", row.get("ledger"), row.get("module")))
            print("  call: python: fullseye.op_run(%r, <inputs>)   — fullseye.op_assist(%r) shows inputs and parameters"
                  % (a.op, a.op))
            return 0
        try:
            import algo as _algo
            aop = _algo.find_algo(a.op)
        except Exception:                                # noqa: BLE001 - algo tier optional
            aop = None
        if aop is not None:
            print("IMPLEMENTED (general-algorithm tier): name=%s  %s->%s  tier=algo" % (aop.name, aop.in_sort, aop.out_sort))
            print("  call: %s algo run %s --seq 3,1,2   (python: fullseye.list_ops(include_algo=True); not an image op)"
                  % (_prog(), aop.name))
            return 0
        # ★2026-11-11(外部監査 v1.0.0): 索引に在る op が optional 依存(extra)の不足で登録されていないとき、
        #   「unknown op」と言っていた(`apply` は MissingBackendError で正しく案内する)。在るが足りない、と言う。
        import api as _api
        import opnames as _opnames
        hint = _api._explain_unregistered(_opnames.REGISTRY_ALIASES.get(a.op, a.op))
        if hint is not None:
            print("EXISTS but not available in this environment: %s" % hint)
            return 1
        # Every one of the 2313 real ops still gets a truthful response.
        d = _disposition(a.op)
        if d:
            print("NOT genuinely implemented: %s" % a.op)
            print("  disposition: %s" % d["status"])
            print("  reason: %s  [chapter=%s, arity=%d]" % (d["reason"], d["chapter"], d["arity"]))
            return 0
        near = [r for r in rows if q in r["name"].lower() or q in (r["halcon"] or "").lower()]
        print("unknown op: %s — neither an op name, a HALCON alias, nor a HALCON reference operator "
              "(search: %s ops --search <word>, or fullseye.op_find('<words>'))" % (a.op, _prog()))
        if near:
            print("  near:", ", ".join(sorted({r["halcon"] or r["name"] for r in near}))[:400])
        return 1
    for r in hits:
        print("IMPLEMENTED: halcon=%s  name=%s  %s->%s  tier=%s"
              % (r["halcon"], r["name"], r["in_sort"], r["out_sort"], r["tier"]))
        if r["tier"] == "registry":
            nm = r["halcon"] or r["name"]
            print("  call: fullseye apply %s <in> <out> --a A --b B   (installed CLI; in a checkout: py -3.11 imgevolve.py apply %s ...)"
                  % (nm, nm))
            print("        python: fullseye.apply(img, %r, a, b)" % r["name"])
        else:
            print("  n-ary (%d inputs) — use imgops_nary.build_nary() programmatically" % r.get("arity", 2))
    return 0


def _find_op(ops, key):
    # Exact op name wins; only then fall back to the HALCON alias. Several ops
    # share a halcon alias (e.g. remove_small carries halcon='select_shape'),
    # so first-match-wins on (name OR halcon) could bind `apply <name>` to an
    # unrelated op. Among halcon matches, prefer the canonical op (name==halcon).
    for o in ops.REGISTRY:
        if o.name == key:
            return o
    # Canonical alias (opnames.REGISTRY_ALIASES, phase 1): same rule and order as api.find_op.
    import opnames as _opnames
    target = _opnames.REGISTRY_ALIASES.get(key)
    if target is not None:
        return _find_op(ops, target)
    halcon_hits = [o for o in ops.REGISTRY if o.halcon == key]
    if not halcon_hits:
        return None
    for o in halcon_hits:
        if o.name == o.halcon:
            return o
    return halcon_hits[0]


def _apply_nary(a, nop):
    """``apply <nary op> A OUT --input2 B``: the n-ary tier from the CLI (GenSpark N60, 2026-09-20)."""
    import api as _api
    if not a.input2:
        raise SystemExit("%r takes %d inputs (%s): pass the second image with --input2 PATH, e.g.\n  %s apply %s %s %s --input2 <second.png>"
                         % (nop.name, nop.arity, " + ".join(nop.in_sorts), _prog(), nop.name, a.inp, a.out))
    if nop.arity != 2:
        raise SystemExit("%r takes %d inputs; the CLI carries two (--input2). Use fullseye.apply([...], %r) in Python."
                         % (nop.name, nop.arity, nop.name))
    xs = [_imread(a.inp, nop.in_sorts[0]), _imread(a.input2, nop.in_sorts[1])]
    out = _api.apply(xs, nop.name, a.a, a.b, on_error="raise")
    _imwrite(a.out, out)
    print("applied %s (%s -> %s) -> %s" % (nop.name, " + ".join(nop.in_sorts), nop.out_sort, a.out))
    return 0


def cmd_apply(a):
    ops = _load_registry()
    op = _find_op(ops, a.op)
    if op is None:
        import api as _api
        nop = _api._nary_by_name().get(a.op)
        if nop is not None:
            return _apply_nary(a, nop)
        raise SystemExit("unknown op %r (try: %s has %s)" % (a.op, _prog(), a.op))
    if a.input2:
        raise SystemExit("%r takes one input; --input2 is for the n-ary ops (see: %s ops --search nary)"
                         % (op.name, _prog()))
    v = _imread(a.inp, op.in_sort)
    # ★2026-11-05(敵対的検証 C1 の兄弟): 以前は生の ops.RT を呼び、apply の入口の契約(ノブの有限性・
    #   0..1 の範囲、空・次元、extra_checks、fallback の guard と台帳)を飛ばしていた —— `--a 5` / `--a nan`
    #   が黙って通った。n 項の枝(_apply_nary)と同じく api.apply を on_error="raise" で通す(CLI は fail-closed)。
    import api as _api
    out = _api.apply(v, op.name, a.a, a.b, on_error="raise")
    if op.out_sort == "feature":
        print("feature %s = %s" % (op.halcon or op.name, float(np.asarray(out).reshape(-1)[0])))
        return 0
    if op.out_sort == "contour":
        H, W = out["shape"]
        mask = np.zeros((H, W), np.float64)
        for c in out["cs"]:
            idx = np.clip(np.round(c).astype(int), [0, 0], [H - 1, W - 1])
            mask[idx[:, 0], idx[:, 1]] = 1.0
        _imwrite(a.out, mask)
        print("contour %s: %d contours -> %s (rasterised)" % (op.halcon or op.name, len(out["cs"]), a.out))
        return 0
    _imwrite(a.out, out)
    print("applied %s (%s->%s) -> %s" % (op.halcon or op.name, op.in_sort, op.out_sort, a.out))
    return 0


def cmd_pipeline(a):
    ops = _load_registry()
    names = [s.strip() for s in a.ops.split(",") if s.strip()]
    if not names:
        raise SystemExit("--ops must name at least one op (comma-separated), got %r" % a.ops)   # GenSpark N146: 生の IndexError だった
    resolved = []
    for nm in names:
        op = _find_op(ops, nm)
        if op is None:
            raise SystemExit("unknown op in pipeline: %r" % nm)
        resolved.append(op)
    v = _imread(a.inp, resolved[0].in_sort)
    # ★2026-11-05(敵対的検証 C1 の兄弟): 段ごとに生の ops.RT を呼んでいたので、型連鎖
    #   (gaussian,vol_gaussian)もノブも検査されなかった。run_pipeline(何も走らせる前に型連鎖とノブを
    #   検査する)を on_error="raise" で通す。
    import api as _api
    v = _api.run_pipeline(v, [(op.name, a.a, a.b) for op in resolved], on_error="raise")
    if isinstance(v, np.ndarray):
        _imwrite(a.out, v)
        print("pipeline %s -> %s %s" % (" -> ".join(names), a.out, getattr(v, "shape", "")))
    else:
        print("pipeline %s -> %s" % (" -> ".join(names), type(v).__name__))
    return 0


def cmd_run(a):
    """Run a saved pipeline (Studio JSON or an ops string) via FullseyeEngine."""
    import engine
    import imgio
    if str(a.pipeline).lower().endswith(".json"):
        eng = engine.FullseyeEngine.load(a.pipeline)
    else:
        eng = engine.FullseyeEngine.from_ops(a.pipeline, a=a.a, b=a.b)

    if a.describe or a.to_python:
        if a.to_python:
            print(eng.to_python())
        else:
            print("pipeline %r: %s -> %s" % (eng.name, eng.input_sort(), eng.output_sort()))
            for d in eng.describe():
                mark = "" if d["known"] else "   [UNKNOWN OP]"
                print("  %2d. %-24s a=%.2f b=%.2f   [%s -> %s]%s"
                      % (d["index"], d["op"], d["a"], d["b"], d["in_sort"], d["out_sort"], mark))
            for p in eng.validate():
                print("  ! %-7s stage %d: %s" % (p["severity"], p["index"], p["message"]))
        if a.inp is None:
            return 0

    errors = [p for p in eng.validate() if p["severity"] == "error"]
    if errors:
        raise SystemExit("pipeline has errors: " + "; ".join(p["message"] for p in errors))
    if a.inp is None:
        raise SystemExit("need an input image (or use --describe / --to-python)")

    _image_codec()                  # 読み書きの部品が 1 つも無ければ 1 行で止める(imgio の ValueError の traceback にしない)
    img = imgio.load(a.inp)
    if a.stepwise:
        for i, s in enumerate(eng.run_stepwise(img)):
            shp = getattr(s, "shape", type(s).__name__)
            if a.out and isinstance(s, np.ndarray) and s.ndim in (2, 3):
                base, ext = os.path.splitext(a.out)
                imgio.save("%s_%02d%s" % (base, i, ext or ".png"), s)
            print("  step %2d  %-24s -> %s" % (i, eng.stages[i][0], shp))
        return 0

    result = eng.run(img, upto=a.upto)
    if isinstance(result, np.ndarray) and result.ndim in (2, 3):
        if a.out:
            imgio.save(a.out, result)
            print("run %s -> %s %s" % (eng.name, a.out, result.shape))
        else:
            print("run %s -> result %s (pass --out to save)" % (eng.name, result.shape))
    else:
        print("run %s -> %s = %r" % (eng.name, type(result).__name__, result))
    return 0


def cmd_coverage(a):
    import honest_summary
    return honest_summary.main()


def _prog() -> str:
    """呼ばれ方に合わせた CLI 名: console_script なら ``fullseye``、checkout なら ``py -3.11 imgevolve.py``。"""
    import re as _re
    import sys as _s
    # ★os.path.basename は実行 OS の区切りしか知らない —— Linux では ``C:\\...\\fullseye.exe`` が丸ごと 1 要素になり
    # 「fullseye で始まらない」と判定された(手元 Windows 緑・CI Linux 赤)。両方の区切りで最後の要素を取る。
    base = _re.split(r"[\\/]", _s.argv[0] or "")[-1].lower()
    if base.startswith("fullseye"):
        return "fullseye"
    # ★2026-11-11(外部ユーザー指摘): ``python -m fullseye``(argv[0] は fullseye/__main__.py)は PyPI から入れた人の入口で、
    #   imgevolve.py は checkout にしか無い。-m 経由を checkout の綴りと取り違えて、無いファイルを勧めていた。
    if base == "__main__.py" and _re.split(r"[\\/]", _s.argv[0])[-2:-1] == ["fullseye"]:
        return "python -m fullseye"
    return "py -3.11 imgevolve.py"


def cmd_parity(a):
    # ★parity.main() は自分で sys.argv を読む —— サブコマンド名 "parity" が残っていると
    # 「unrecognized arguments: parity」で落ちていた(GenSpark 第 6 報 N6)。accel / bench と同じく argv を差し替える。
    import sys as _s
    _s.argv = ["parity.py"]
    import parity
    return parity.main()


def cmd_accel(a):
    import sys as _s
    _s.argv = ["accel.py", "--device", a.device]
    import accel
    return accel.main()


def cmd_bench(a):
    import sys as _s
    _s.argv = ["bench.py", "--n", str(a.n), "--size", str(a.size), "--device", a.device]
    import bench
    return bench.main()


def _build_op_index():
    """`docs/OP_INDEX.json` の中身をそのまま返す(書き込みはしない)。

    ★`cmd_index` から切り出した(2026-09-06)。名前を `_` で始めるのは、これが CLI と
    検査のための内部関数で、ファサードから届く公開 API ではないから
    (`tests/test_public_reachability.py` が「見えない公開名」を数えて止める)。以前は組み立てが `cmd_index` の
    中にしか無く、鮮度を確かめる検査は `_all_ops()` を呼ぶしかなかった。すると
    **tier の再分類(color)が検査から見えない**ので、検査は「ずれている」と
    言い続けるか、tier を見ないよう緩めるかの二択になる。生成物そのものを
    返す関数を 1 つ置けば、検査は**公開されるものと同じもの**と比べられる。
    """
    rows = _all_ops()
    # 握り潰さない —— color 層が黙って空になると、tier の内訳だけが静かに縮む。
    import backends_color as CL
    cov = CL.coverage()
    col = set(cov["halcon_names"])
    # ★2026-10-18(外部レビュー 0.6.0 N228 の再現で見つけた): color 層は OpenCV が要る(extra `opencv`)。
    #   素の `pip install fullseye` では空が正しいのに、ここが無条件に assert していたので `fullseye index` が
    #   AssertionError で落ちていた。黙って空になるのを止めたいのは OpenCV が在るときだけ。
    assert col or not cov.get("has_cv2"), "color 層が空(backends_color.coverage が何も返さない)"
    for r in rows:
        if r["halcon"] in col:
            r["tier"] = "color"
    rows += _ledger_rows({r["name"] for r in rows})
    _assign_gpu_tier(rows)
    return {
        "n_ops": len(rows),
        "tiers": {t: sum(1 for r in rows if r["tier"] == t) for t in
                  sorted({r["tier"] for r in rows})},
        # 台帳 op には入力ゼロ(カタログを返すだけ)のものがあり in_sort が None。
        # None を sort の語彙に混ぜない(MCP が in_sort の enum に使う)。
        "sorts": sorted({r["in_sort"] for r in rows if r["in_sort"]}
                        | {r["out_sort"] for r in rows if r["out_sort"]}),
        "ops": sorted(rows, key=lambda r: (r["tier"], r["name"])),
    }


def _assign_gpu_tier(rows) -> None:
    """各 op 行に ``gpu_tier``(4 値)を付ける。規則は ``tools/gpu_tier_rules.py``
    (型 in_sort/out_sort と正本名簿 ``fullseye/data/gpu_required.json`` から導く)。
    手書きのフラグは drift するので、索引を組むこの一点でだけ機械的に付ける。"""
    # ★2026-11-04(統合 GPU): 規則は tools/ にあるので、imgevolve.py の隣に tools/ が無い置き方(変異探針の
    # 小さな作業木: imgevolve.py だけを写し、本体は PYTHONPATH で引く)では見つからず索引が組めなかった。
    # imgevolve.py の隣を先に、無ければ sys.path の各所の tools/ を探す。
    for base in [HERE] + [p for p in sys.path if p]:
        tools = os.path.join(base, "tools")
        if os.path.isfile(os.path.join(tools, "gpu_tier_rules.py")):
            if tools not in sys.path:
                sys.path.insert(0, tools)
            break
    import gpu_tier_rules
    gpu_tier_rules.assign(rows)


def _ledger_rows(taken):
    """型付き台帳(``opassist._LEDGERS`` の 33 族)を索引の行にする。

    ★2026-09-15 まで索引は ``ops.REGISTRY`` + n-ary の 918 op だけで、**台帳の
    1,025 op(optics 124 / 3d 357 / annotate 51 / reprconv 42 …)が 1 つも載って
    いなかった**。台帳は ``fullseye.op_find``(語幹検索)と ``fullseye.ledger``
    (属性呼び出し)から届くのに、機械可読の入口からは構造的に見えない ——
    [[feedback_registered_only_gates_miss_unregistered]] と同じ形で、索引の
    件数の門は「レジストリと一致」を見ていたので欠落に盲目だった。

    族の一覧は **``opassist._LEDGERS`` を正本にする**(``fs.op_find`` /
    ``fs.ledger`` が引く集合と同じ)。ここに別の表を持つと、族を足したときに
    片方だけ増える。

    * ``tier`` は ``"ledger"``、``ledger`` に台帳モジュール名、``dim`` に
      ノートの置き場(``docs/ops/<dim>/``)、``in_sorts`` に宣言入力の全部。
    * ``in_sort`` は宣言入力の先頭(無ければ None)。台帳の型語彙(``table`` /
      ``pairs`` / ``image2d`` …)はそのまま —— 2-D の語彙に翻訳すると
      「繋がる鎖」を偽る。
    * 同名は**先に来た族が勝つ**(``fullseye.ledger`` と同じ規則。実測の重複は
      ``gaussians_to_voxel`` の ops3d / opsreprconv だけ)。2-D レジストリと同名の
      台帳 op(``ops1d`` の 2 件、``ops3d`` の 1 件)は 2-D 側の行を残す ——
      その名前で ``fullseye.apply`` が動くのはそちらだから。
    * 族の import 失敗は**握らない**。台帳は numpy/scipy だけで組める一次モジュール
      なので、失敗は「壊れた checkout」であって「無い機能」ではない。

    ★2026-09-25: 組み立ての本体は ``api.ledger_rows()`` に移した。同じ規則の表が
    2 つ在ると、族を足したときに片方だけ増える —— 実際に ``api.list_ops()`` は
    この層を 1 op も返さないまま取り残されていた(上の註の逆向きの事故)。
    """
    import api as _api
    return [r for r in _api.ledger_rows() if r["name"] not in taken]


def _index_default_out() -> str:
    """既定の書き先。checkout では ``docs/OP_INDEX.json``(生成物の正本)、``docs/`` の無い場所 —— wheel の
    site-packages —— では **カレントディレクトリ**。

    ★2026-09-20(GenSpark 第 32 報 N115 / 第 55 報 N198): wheel から ``fullseye index`` を叩くと site-packages の
    中に ``docs/OP_INDEX.json`` を作り、同梱の ``fullseye/data/OP_INDEX.json`` と別の値(その環境の生きた
    registry)を持つ「3 つ目の索引」が生まれていた。インストール先に書かない。
    """
    # ★2026-10-18(外部レビュー 0.6.0 N228): checkout の判定が「HERE に docs/ が在るか」だけだった。wheel の
    #   HERE は site-packages そのものなので、別のパッケージが site-packages/docs/ を置いていると、そこへ
    #   OP_INDEX.json を書きに行く(読み取り専用の環境では落ちる)。checkout にしか無い正本の組で判定する。
    docs = os.path.join(HERE, "docs")
    is_checkout = (os.path.isfile(os.path.join(docs, "OP_INDEX.json"))
                   and os.path.isfile(os.path.join(HERE, "tools", "regen_all.py")))
    return os.path.join(docs, "OP_INDEX.json") if is_checkout else os.path.join(os.getcwd(), "OP_INDEX.json")


def _index_vs_shipped(rows) -> list:
    """生きた registry の索引と同梱索引の差を、理由(入っていない optional backend)つきの行にする。

    数が違うのは正常(同梱 = ビルド環境、CLI = この環境)だが、**違う理由を言わない数字は 3 系統目の真実に
    見える**(第 55 報 N198)。差集合と、その op が要る backend のうちこの環境に無いものを出す。
    """
    import api as _api_
    import ops as _ops_
    shipped = _api_._shipped_index()
    if not shipped:
        return ["[index] no shipped index found to compare against"]
    live = {r["name"] for r in rows}
    missing = sorted(n for n in shipped if n not in live)
    extra = sorted(n for n in live if n not in shipped)
    lines = []
    if not missing and not extra:
        return ["[index] this environment matches the shipped index (%d ops)" % len(shipped)]
    lines.append("[index] this environment vs the shipped index (fullseye/data/OP_INDEX.json, %d ops): "
                 "%d op(s) missing here, %d only here" % (len(shipped), len(missing), len(extra)))
    if missing:
        import importlib.util
        need: dict = {}
        for n in missing:
            for m in shipped[n].get("requires") or []:
                if importlib.util.find_spec(m) is None:
                    need.setdefault(m, []).append(n)
        lines.append("[index]   missing: %s%s" % (", ".join(missing[:10]), " …" if len(missing) > 10 else ""))
        deps = _ops_.OPTIONAL_DEPS
        for m, names in sorted(need.items()):
            pip, extra_name = deps.get(m, (m, None))
            lines.append("[index]   %d of them need %r (not installed here): pip install %s"
                         % (len(names), m, ('"fullseye[%s]"' % extra_name) if extra_name else pip))
        unexplained = [n for n in missing if not any(importlib.util.find_spec(m) is None for m in (shipped[n].get("requires") or []))]
        if unexplained:
            lines.append("[index]   %d missing for another reason (fullseye.FAILED_BACKENDS / fullseye has <name>): %s"
                         % (len(unexplained), ", ".join(unexplained[:10])))
    if extra:
        lines.append("[index]   only here (newer than the shipped copy): %s%s" % (", ".join(extra[:10]), " …" if len(extra) > 10 else ""))
    return lines


def cmd_index(a):
    out = _build_op_index()
    rows = out["ops"]
    p = a.out or _index_default_out()
    os.makedirs(os.path.dirname(os.path.abspath(p)), exist_ok=True)
    json.dump(out, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    order = ["registry", "nary", "ledger", "color"]
    tiers = out["tiers"]
    shown = " / ".join("%s %d" % (t, tiers[t]) for t in order if t in tiers)
    shown += "".join(" / %s %d" % (t, n) for t, n in tiers.items() if t not in order)
    print("[index] %d ops (%s) -> %s" % (len(rows), shown, p))
    for line in _index_vs_shipped(rows):
        print(line)
    return 0


def cmd_algo(a):
    """General-algorithm tier (algo-c parity): list / run / emit C or Python / difftest.

    A separate, opt-in tier from the image ops (sequences, not rasters). See
    ``algo.py`` and ``docs/GENERAL_ALGORITHMS.md``.
    """
    import algo
    if a.action == "list":
        for op in algo.ALGO_REGISTRY:
            print("%-10s %-4s->%-6s [%-6s]  %s"
                  % (op.name, op.in_sort, op.out_sort, op.category, op.provenance))
        print("--- %d general-algorithm ops (seq/scalar tier) ---" % len(algo.ALGO_REGISTRY))
        return 0
    if a.action == "run":
        if a.op is None or algo.find_algo(a.op) is None:
            raise SystemExit("run needs a known op (try: %s algo list)" % _prog())
        if not a.seq.strip():
            # ★2026-09-20(GenSpark 第 53 報 N187、再現): --seq 無しは空列を「ソートして」[] を印字し rc 0 だった。
            raise SystemExit("run needs --seq (comma-separated numbers), e.g. %s algo run %s --seq 3,1,2" % (_prog(), a.op))
        seq = [float(x) for x in a.seq.split(",") if x.strip()]
        print(algo.run_algo(a.op, seq))
        return 0
    if a.action in ("emit-c", "emit-py"):
        import algo_codegen
        if a.op is None or algo.find_algo(a.op) is None:
            raise SystemExit("%s needs a known op (try: %s algo list)" % (a.action, _prog()))
        op = algo.ALGO_BY_NAME[a.op]
        print(algo_codegen.emit_c(op) if a.action == "emit-c" else algo_codegen.emit_python(op))
        return 0
    if a.action == "difftest":
        import algo_difftest
        cc = None if a.no_c else "auto"
        names = algo.algo_names() if a.op in (None, "all") else [a.op]
        rc = 0
        for nm in names:
            if algo.find_algo(nm) is None:
                raise SystemExit("unknown algo op: %r (try: %s algo list)" % (nm, _prog()))
            r = algo_difftest.difftest(nm, a.workdir, cc=cc)
            cb = r["c_backend"]
            extra = (" bit_identical=%s" % cb.get("c_vs_python_bit_identical")) if cb.get("status") == "ran" else ""
            print("[algo:%s] python pass=%s | C %s%s | c_verified=%s -> passed=%s"
                  % (nm, r["python_pass"], cb.get("status"), extra, r["c_verified"], r["passed"]))
            if not r["passed"]:
                rc = 1
        return rc
    return 0


def cmd_synth(a):
    """Learn a texture from an image and synthesise a NEW, similar one (synth.py)."""
    import imgio
    import synth
    _image_codec()                  # run と同じ(cv2 も Pillow も無い環境で traceback にしない)
    img = imgio.load(a.inp)
    size = None
    if a.size:
        h, w = a.size.lower().split("x")
        size = (int(h), int(w))
    out = synth.synthesize_like(img, size=size, seed=a.seed, method=a.method)
    imgio.save(a.out, out)
    d = synth.feature_distance(img, out)
    nov = synth.patch_novelty(out, img)
    pyr = synth.pyramid_stat_distance(img, out)            # per-scale marginal match
    print("synth %s -> %s  spectrum_l2=%.4f hist_chi2=%.4f pyramid=%.4f novelty=%.5f"
          % (a.method, a.out, d["spectrum_l2"], d["hist_chi2"], pyr, nov))
    return 0


def cmd_samples(a):
    """Opt-in sample datasets: list URLs / open the save folder / (optionally) fetch.

    Nothing is bundled in the wheel — you fetch each dataset from its own source,
    so fullseye never redistributes third-party data.
    """
    import sample_data as sd
    act = a.action
    if act == "where":
        print(sd.data_dir()); return 0
    if act == "open":
        print("samples folder: %s" % sd.open_dir()); return 0
    if act == "list":
        print("Sample data is NOT bundled - fetch it from the source URL below.")
        print("folder: %s   (open it with: fullseye samples open)\n" % sd.data_dir())
        for e in sd.catalog():
            if a.category and e["category"] != a.category:
                continue
            have = "[have]" if sd.verify(e["id"]) else "[    ]"
            size = ("%.0f MB" % (e["bytes"] / 1e6)) if e.get("bytes") else "?"
            print("%s %-15s %-8s %s" % (have, e["id"], e["category"], e["name"]))
            print("        %s  commercial=%s  %s" % (e["license"], e["commercial"], size))
            print("        url : %s"
                  % (e["url"] or ("(no direct URL - source page) " + e["source_page"])))
            if e.get("attribution"):
                print("        cite: %s" % e["attribution"])
        return 0
    if act == "verify":
        ids = list(sd._BY_ID) if a.all else ([a.id] if a.id else [])
        if not ids:
            print("give a sample id or --all"); return 2
        rc = 0
        for i in ids:
            ok = sd.verify(i)
            print("%-15s %s" % (i, "OK" if ok else "missing/mismatch"))
            rc = rc or (0 if ok else 1)
        return rc
    if act == "download":
        if a.all:
            ids = [e["id"] for e in sd.catalog() if e["access"] == "direct"]
        elif a.category:
            ids = [e["id"] for e in sd.catalog()
                   if e["category"] == a.category and e["access"] == "direct"]
        elif a.id:
            ids = [a.id]
        else:
            print("give a sample id, --all, or --category <cat>"); return 2
        for i in ids:
            try:
                sd.download(i, yes=a.yes)
            except Exception as ex:  # fail-closed: report and move on
                print("[%s] error: %s" % (i, ex))
        if not a.yes:
            print("\n(nothing downloaded - add --yes to opt in)")
        return 0
    print("unknown action %r" % act); return 2


def _tolerate_unencodable_output() -> None:
    """標準出力 / 標準エラーで、その符号化で書けない文字を置き換える(符号化そのものは変えない)。

    ★2026-11-13(配布物の検証 M3): 日本語 Windows で出力をパイプやファイルへ回すと標準出力は cp932(strict)になり、
    help の「—」などで ``UnicodeEncodeError``(rc=1)になっていた —— ``fullseye --help > h.txt``・
    ``fullseye has <無い名前>``・``fullseye samples list``。標準出力は ``replace``(書けない字は ``?``)、
    標準エラーは Python の既定と同じ ``backslashreplace``。Windows の端末(コンソールは UTF-8)や UTF-8 の
    パイプでは置き換える字が無いので、見た目は変わらない。``fullseye setup`` の手当てと同じ。
    """
    for name, handler in (("stdout", "replace"), ("stderr", "backslashreplace")):
        stream = getattr(sys, name, None)
        if stream is None or getattr(stream, "errors", None) not in ("strict", "surrogateescape"):
            continue
        try:
            stream.reconfigure(errors=handler)
        except (AttributeError, ValueError, OSError):   # reconfigure の無い流れ(差し替えられた stdout など)
            pass


def main() -> int:
    _tolerate_unencodable_output()
    # ★help の実行例(2026-09-19、GenSpark 第 6 報 N9 / K2): 配布物では console_script `fullseye` が入口で、
    # `py -3.11 imgevolve.py` は checkout 専用の綴り。呼ばれ方に合わせて例文を書き換える。
    # ★利用者向けの名乗りは fullseye(imgevolve は旧作業名)。checkout 開発者向けの綴りは epilog にだけ残す。
    # ★2026-11-12: 引数なしは「必須引数が無い」エラー(rc=2)でなく、次に何をするかの案内を出す(rc=0)。
    #   `fullseye setup` は対話的な初期設定(fullseye/setup_cmd.py)。自前の argparse に丸ごと渡す。
    if len(sys.argv) == 1:
        from fullseye import setup_cmd as _sc
        print(_sc.guidance(_sc.detect_lang()))
        return 0
    if sys.argv[1] == "setup":
        from fullseye import setup_cmd as _sc
        return _sc.main(sys.argv[2:])
    ap = argparse.ArgumentParser(prog=_prog() if _prog().startswith("python -m") else None,
                                 description=__doc__.replace("py -3.11 imgevolve.py", _prog())
                                 .replace("imgevolve — single CLI", "fullseye — single CLI", 1),
                                 formatter_class=argparse.RawDescriptionHelpFormatter,
                                 epilog="(installed: `fullseye <cmd>` or `python -m fullseye <cmd>`; "
                                        "for developers, in a checkout: `py -3.11 imgevolve.py <cmd>`)")
    import api as _api
    ap.add_argument("--version", action="version", version="fullseye %s" % _api.__version__)   # N19: 無かった
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("ops", help="list/search implemented operators")
    # ★2026-10-18(外部レビュー 0.6.0 N217): `fullseye algo list` に倣って `fullseye ops list` と打つと
    #   rc=2(unrecognized arguments)だった。`list` は既定の動作と同じなので、語として受けて同じものを出す。
    p.add_argument("action", nargs="?", choices=["list"], default="list",
                   help="`list` (the default; accepted for symmetry with `fullseye algo list`)")
    p.add_argument("--search", default="")
    p.add_argument("--sort", default="")
    p.add_argument("--include-ledger", action="store_true",
                   help="型付き台帳の op も並べる(既定は画像の語彙だけ)")
    p.set_defaults(fn=cmd_ops)

    p = sub.add_parser("has", help="is a HALCON op implemented + how to call it")
    p.add_argument("op")
    p.set_defaults(fn=cmd_has)

    p = sub.add_parser("apply", help="apply one operator to an image (n-ary ops such as add_image: add --input2)")
    p.add_argument("op"); p.add_argument("inp"); p.add_argument("out")
    p.add_argument("--a", type=float, default=0.5); p.add_argument("--b", type=float, default=0.5)
    p.add_argument("--input2", default="", metavar="PATH",
                   help="second input for an n-ary op: apply add_image a.png out.png --input2 b.png")
    p.set_defaults(fn=cmd_apply)

    p = sub.add_parser("pipeline", help="apply a comma-separated op sequence")
    p.add_argument("inp"); p.add_argument("out"); p.add_argument("--ops", required=True)
    p.add_argument("--a", type=float, default=0.5); p.add_argument("--b", type=float, default=0.5)
    p.set_defaults(fn=cmd_pipeline)

    p = sub.add_parser("run", help="run a saved pipeline (JSON or ops string) via FullseyeEngine")
    p.add_argument("pipeline", help="a pipeline .json (Studio 'Save pipeline') or a comma-separated ops string")
    p.add_argument("inp", nargs="?", default=None, help="input image (omit with --describe / --to-python)")
    p.add_argument("--out", default="", help="save the result here")
    p.add_argument("--upto", type=int, default=None, help="run only stages 0..N")
    p.add_argument("--stepwise", action="store_true", help="report/save each stage's result")
    p.add_argument("--describe", action="store_true", help="print pipeline I/O + validation, then exit if no input")
    p.add_argument("--to-python", action="store_true", dest="to_python", help="print the pipeline as a Python function")
    p.add_argument("--a", type=float, default=0.5); p.add_argument("--b", type=float, default=0.5)
    p.set_defaults(fn=cmd_run)

    p = sub.add_parser("coverage", help="print honest coverage numbers")
    p.set_defaults(fn=cmd_coverage)

    p = sub.add_parser("index", help="(re)write machine-readable docs/OP_INDEX.json")
    p.add_argument("--out", default="")
    p.set_defaults(fn=cmd_index)

    p = sub.add_parser("parity", help="cross-backend parity evidence (independent impls agree)")
    p.set_defaults(fn=cmd_parity)

    p = sub.add_parser("accel", help="GPU-ready batch backend: parity vs CPU registry ops")
    p.add_argument("--device", default="cpu")
    p.set_defaults(fn=cmd_accel)

    p = sub.add_parser("bench", help="throughput: CPU baseline vs batch (add --device cuda on a GPU); memory ~ 2 x n x size^2 x 8 bytes (default 200 x 256^2 = ~210 MB), use --n 50 --size 128 in a small container")
    p.add_argument("--n", type=int, default=200, help="images per batch (default 200)")
    p.add_argument("--size", type=int, default=256, help="image side in pixels (default 256)")
    p.add_argument("--device", default="cpu")
    p.set_defaults(fn=cmd_bench)

    p = sub.add_parser("algo", help="general-algorithm tier (algo-c): list/run/emit-c/emit-py/difftest")
    p.add_argument("action", choices=["list", "run", "emit-c", "emit-py", "difftest"])
    p.add_argument("op", nargs="?", default=None, help="op name (or 'all' for difftest)")
    p.add_argument("--seq", default="", help="run: comma-separated numbers, e.g. --seq 3,1,2")
    p.add_argument("--workdir", default="out/algo", help="difftest: where to emit/compile")
    p.add_argument("--no-c", action="store_true", help="difftest: force the honest C skip")
    p.set_defaults(fn=cmd_algo)

    p = sub.add_parser("synth", help="learn a texture from an image and synthesise a similar one")
    p.add_argument("inp"); p.add_argument("out")
    p.add_argument("--method", default="spectral", choices=["spectral", "pyramid", "patch"])
    p.add_argument("--size", default="", help="output HxW, e.g. 256x256 (default: source size)")
    p.add_argument("--seed", type=int, default=0)
    p.set_defaults(fn=cmd_synth)

    p = sub.add_parser("samples",
                       help="opt-in sample datasets (not bundled): list URLs / open folder / fetch")
    p.add_argument("action", nargs="?", default="list", choices=["list", "open", "where", "download", "verify"],
                   help="list: show datasets+URLs; open: open the save folder; "
                        "download/verify: optional convenience")
    p.add_argument("id", nargs="?", default=None, help="a sample id (see `samples list`)")
    p.add_argument("--all", action="store_true", help="apply to all direct-download entries")
    p.add_argument("--category", default="", help="filter by category (mesh/volume/image/...)")
    p.add_argument("--yes", action="store_true",
                   help="opt in to actually download (otherwise only prints what would be fetched)")
    p.set_defaults(fn=cmd_samples)

    p = sub.add_parser("setup", help="interactive first-time setup: check the environment, register Studio in the "
                                     "Start menu, install optional deps, set up AI integration "
                                     "(--yes / --dry-run / --lang ja|en)")
    p.add_argument("rest", nargs="*", help=argparse.SUPPRESS)
    p.set_defaults(fn=lambda a: __import__("fullseye.setup_cmd", fromlist=["main"]).main(a.rest))

    a = ap.parse_args()
    return a.fn(a)


if __name__ == "__main__":
    raise SystemExit(main())
