"""One honest number: distinct real HALCON operators imgevolve GENUINELY does.

Ties the three grounded measurements together — no memory, no inflation:

  registry coverage   distinct real HALCON ops named by an evolvable Op.halcon
                      (halcon_coverage.analyze; core ops are hand-verified, auto
                      ops are functionally gated below)
  functional gate     of the auto-generated ops, how many actually run + return
                      the declared sort on canonical inputs (verify_auto)
  n-ary tier          real HALCON multi-input ops implemented outside the single
                      -image thread (imgops_nary), disjoint from the registry

Headline = |registry-covered  ∪  n-ary names|, all functional. Writes
docs/HALCON_PARITY.md.

    py -3.11 honest_summary.py
"""
from __future__ import annotations

import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))


def main() -> int:
    import ops as R
    import halcon_coverage as HC
    import verify_auto as VA
    import imgops_nary as NA

    ops_json = os.path.join(HERE, "data", "halcon_operators.json")
    if not os.path.exists(ops_json):
        # ★wheel には data/halcon_operators.json を**同梱しない**(MVTec のリファレンスの説明文を含むため。
        # 名前だけは halcon_names_data として出荷している)。`fullseye coverage` が FileNotFoundError で落ちていた
        # (GenSpark 第 6 報 N5)ので、無いなら何が要るかと数字の在処を言って終える。
        print("coverage: this command needs the checkout's data/halcon_operators.json (the HALCON reference "
              "list with chapters and descriptions), which is not shipped in the wheel. The current numbers are "
              "in docs/HALCON_PARITY.md of the repository (https://github.com/furuse-kazufumi/fullseye); "
              "the shipped name list alone is halcon_names_data.HALCON_NAMES.")
        return 1
    data = HC.load_operators(ops_json)
    vers = HC.load_versions(os.path.join(HERE, "data", "halcon_versions.json"))
    a = HC.analyze(data, R.REGISTRY, vers)
    reg_covered = set(a["covered"])
    n_real = a["n_real"]

    gate = VA.run(verbose_failures=False)          # prints its own line
    auto_pass = set(gate["passing_ops"])

    nary = NA.coverage()
    nary_names = set(nary["halcon_names"])

    import backends_color as CL
    col_cov = CL.coverage()
    col_ver = CL.verify()
    col_names = set(col_cov["halcon_names"])
    col_pass = set(col_ver.get("passing", []))
    col_fail = [n for n in col_names if n not in col_pass]

    # Every registry-covered name is functional: core ops run in the pipeline
    # (regression-tested) and auto ops are those that passed the gate. Flag any
    # registry-covered auto op that did NOT pass (should be none).
    auto_names = {(s["halcon"]) for s in __import__("backends_auto").load_specs()}
    reg_auto = reg_covered & auto_names
    reg_auto_failing = reg_auto - auto_pass

    # ★Exclude auto ops that FAILED the functional gate from the headline — they
    # were previously only [warn]-printed while still counted, inflating the
    # "functionally gated" parity number with ops the gate rejects.
    reg_counted = reg_covered - reg_auto_failing
    total = reg_counted | nary_names
    lines = [
        "# HALCON parity — what imgevolve genuinely DOES (not just names)",
        "",
        "Grounded in the scraped MVTec reference (%d real operators, v%s). Counts"
        % (n_real, data["version"]),
        "below are real numpy/scipy/skimage/cv2 implementations that run: core ops",
        "are regression-tested; auto ops must pass the functional gate (which rejects",
        "anything not returning the declared sort — %d gate-failing auto op(s) are"
        % len(reg_auto_failing),
        "excluded here, not counted).",
        "",
        "## Headline",
        "- **%d / %d distinct real HALCON operators implemented (%.1f%%)**"
        % (len(total), n_real, 100.0 * len(total) / n_real),
        # ★2026-09-08: この行はこう書いてあった ——
        #   "= %d evolvable registry ops + %d n-ary capability ops (disjoint)."
        # 実測すると **979 + 17 = 979**、つまり n-ary の 17 本は
        # ``reg_counted`` の**部分集合**(``nary_names - reg_counted`` は空)。
        # 見出しの 979 は正しいのに、内訳の行だけが「足し算」に見え、読者が足すと
        # 996 になる。数字が合っていても**説明が嘘をつく**形なので直した。
        # 内訳が和として成り立つかは ``tests/test_honest_summary_arithmetic.py`` が毎回見る。
        # ★2026-11-05(敵対的検証 第 2 巡 D2): ここは「= %d evolvable registry ops」だったが、registry の
        #   Op.halcon が名乗るのは 388 名だけで、残りは facade と台帳の対応。出どころ別に数えて書く。
        "  = %d names: %s (of which %d are also reachable through the"
        % (len(reg_counted), HC.source_breakdown_text(a["covered_by_source"], reg_counted),
           len(reg_counted & nary_names)),
        "  n-ary capability tier — a subset, not an addition; %d n-ary-only)."
        % (len(nary_names - reg_counted)),
        "- dangling registry `Op.halcon` (fake names): **%d** (fail-closed)." % len(a["dangling"]),
        "- partial analogues (the name is claimed but only part of the job is done): **%d**, "
        "not counted above — %s (what each does and does not do: docs/HALCON_COVERAGE.md)."
        % (len(a["partial"]), ", ".join(a["partial"])),
        "",
        "## Evolvable registry (single-image pipeline, coverage-counted)",
        "- registry ops: %d ; distinct real HALCON ops covered: **%d** (all sources; through "
        "registry `Op.halcon` alone: %d)"
        % (a["n_registry"], len(reg_covered), len(a["covered_by_source"]["registry"])),
        "- auto-generated ops passing the functional gate: %d / %d"
        % (gate["n_pass"], gate["n_specs"]),
        "- auto ops counted in coverage but FAILING the gate: %d %s"
        % (len(reg_auto_failing), sorted(reg_auto_failing) or "(none — honest)"),
        "",
        "## N-ary capability tier (multi-input; genuine, not evolvable)",
        "- ops: %d (all pass functional gate) — %s"
        % (nary["n_ops"], ", ".join(sorted(nary_names))),
        "",
        "## Color (multichannel) sort — first-class, in the evolvable registry",
        "- ops: %d (color functional gate %d/%d pass; reached via cfa_to_rgb bridge) — %s"
        % (col_cov["n_ops"], len(col_pass), col_cov["n_ops"], ", ".join(sorted(col_names))),
        "- color ops counted in coverage but FAILING their gate: %d %s"
        % (len(col_fail), sorted(col_fail) or "(none — honest)"),
        "",
        "## Honest scope",
        "- In scope = algorithmic operators (Filters/Image/Regions/Morphology/",
        "  Segmentation/Transformations/XLD/Matching/Inspection). Out of scope =",
        "  HDevelop plumbing (Graphics/Tuple/System/File/Develop/Control/Matrix) and",
        "  trained-model/proprietary chapters (OCR/Classification/Deep-Learning/3D/",
        "  Calibration), where only generic approximations are possible.",
        "- Coverage counts a nearest functional analogue, not signature-level parity.",
        "",
    ]
    md = os.path.join(HERE, "docs", "HALCON_PARITY.md")
    open(md, "w", encoding="utf-8").write("\n".join(lines))
    print("\n".join(lines[3:14]))
    print("[ok] wrote %s" % md)
    if reg_auto_failing:
        print("[warn] %d covered auto ops fail the gate — investigate: %s"
              % (len(reg_auto_failing), sorted(reg_auto_failing)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
