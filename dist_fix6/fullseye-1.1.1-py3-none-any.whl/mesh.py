"""3-D mesh / point-cloud file readers and geometry helpers (numpy + scipy only).

The *import* side of the perception stack: this turns a 3-D object file — a CAD
part, a scanned prop, the collision mesh of a MuJoCo asset — into the plain numpy
arrays the rest of the library already speaks, so a physical-AI project can hand
a robot something to look at and to grasp:

    import fullseye as fs
    V, F = fs.read_mesh("part.stl")            # (nv,3) float64, (nf,3) int64
    model = fs.sample_surface(V, F, 4000)      # -> (N,3) cloud
    n     = fs.estimate_normals(model)         # pointcloud.py: grasp approach dirs
    T     = fs.register(scan, model)           # registration.py: object pose
    occ, origin = fs.voxelize(V, F, 0.01)      # -> the `volume` sort (3-D array)

Four formats are read, chosen because each is completely specified by a public,
dependency-free spec — no third-party parser (and no GPL code) is needed:

  ``.obj``  Wavefront OBJ — Wavefront Technologies' *Advanced Visualizer* file
            format (public spec; ``v`` / ``f`` records).
  ``.stl``  binary **and** ASCII — 3D Systems, *StereoLithography Interface
            Specification* (1989). Binary STL is little-endian by spec.
  ``.ply``  ASCII and binary (little- **and** big-endian) — Greg Turk, "The PLY
            Polygon File Format" (Stanford, 1994).
  ``.off``  Object File Format — the Geomview / Princeton Shape Benchmark spec.

Point clouds additionally read ``.xyz`` (plain ``x y z [r g b]`` text), ``.pcd``
(Point Cloud Library format — ``ascii``, ``binary`` and LZF ``binary_compressed``)
and ``.npy`` / ``.npz`` (a numpy ``(N, 3)`` or ``(N, 6=xyz+rgb)`` array).

Export is symmetric with import. :func:`write_mesh` writes every format
:func:`read_mesh` reads (``.obj`` / ``.off`` / ASCII+binary ``.ply`` exactly in
float64; binary ``.stl`` in float32), and :func:`write_points` writes ``.ply``
(binary or ASCII), ``.xyz`` and ``.npy`` / ``.npz`` (the numpy formats round-trip
coordinates and colours exactly).

Honest limitations (nothing here claims more than its round-trip test proves):

  * Polygons with more than 3 corners are **fan-triangulated** (correct for
    convex faces, which is what these formats carry in practice; a concave
    n-gon can produce triangles outside the polygon).
  * :func:`voxelize` is **surface** voxelization — it marks the cells a triangle
    passes through, it does not fill the interior.
  * PLY vertex properties beyond ``x/y/z`` and an RGB triple are **ignored**
    (normals, alpha, confidence, custom properties). Element types other than
    ``vertex`` / ``face`` are parsed for structure but dropped.
  * Materials, textures, normals, groups, smoothing and per-face attributes are
    not read from any format — this module returns geometry only.
  * PCD ``binary_compressed`` uses PCL's LZF codec, decompressed here in pure
    Python; correct but not fast for very large clouds (bounded by
    ``MAX_FILE_BYTES``). PCD ``COUNT != 1`` per field is refused, and non-xyz
    fields (intensity, normals, curvature) are dropped — only ``x/y/z`` and an
    ``rgb`` triple are returned.
  * The heavier formats (glTF/GLB, COLLADA, LAS) are **not** supported here; they
    need more than numpy and belong in an optional extra.
  * ``.npy`` / ``.npz`` load with ``allow_pickle=False``, so an object-array or
    pickled archive is refused rather than executed (untrusted-input safety).
  * STL carries no vertex sharing, so :func:`read_mesh` welds bit-identical
    coordinates into shared vertices; coordinates that differ in the last float
    bit stay separate.

Every reader is **fail-closed** on untrusted input: magic bytes and headers are
validated, declared element counts are checked against the bytes actually
present, counts and file size are capped (``MAX_FILE_BYTES`` / ``MAX_ELEMENTS``),
and NaN/Inf coordinates are rejected. A malformed file raises ``ValueError`` with
a message naming the file and the problem — it never returns partial garbage.
"""
from __future__ import annotations

import io
import os
import re

import numpy as np

__all__ = [
    "read_mesh", "read_points", "write_mesh", "write_points",
    "sample_surface", "mesh_to_points", "voxelize",
    "bounds", "recenter", "normalize_scale",
    "MESH_FORMATS", "POINT_FORMATS", "WRITE_MESH_FORMATS", "WRITE_POINT_FORMATS",
]

#: Extensions :func:`read_mesh` accepts.
MESH_FORMATS = (".obj", ".stl", ".ply", ".off")
#: Extensions :func:`read_points` accepts.
POINT_FORMATS = (".ply", ".xyz", ".txt", ".pts", ".asc", ".obj", ".pcd", ".off",
                 ".stl", ".npy", ".npz")
#: Extensions :func:`write_mesh` accepts (every format :func:`read_mesh` reads).
WRITE_MESH_FORMATS = (".obj", ".stl", ".ply", ".off")
#: Extensions :func:`write_points` accepts.
WRITE_POINT_FORMATS = (".ply", ".xyz", ".txt", ".pts", ".asc", ".npy", ".npz")

#: Refuse files larger than this (untrusted input / accidental DoS guard).
MAX_FILE_BYTES = 1 << 29          # 512 MiB
#: Refuse a declared vertex/face/element count larger than this.
MAX_ELEMENTS = 50_000_000
#: Refuse a voxel grid with more cells than this (a bool array of that size).
MAX_VOXELS = 1 << 27              # ~134 M cells = 134 MB as bool
_MAX_SUBDIV = 4096                # per-triangle rasterisation subdivisions
_MAX_VOXEL_SAMPLES = 50_000_000   # total rasterisation samples across the mesh
_CHUNK = 1 << 20                  # sample points held in memory at once

_PLY_TYPES = {
    "char": "i1", "int8": "i1", "uchar": "u1", "uint8": "u1",
    "short": "i2", "int16": "i2", "ushort": "u2", "uint16": "u2",
    "int": "i4", "int32": "i4", "uint": "u4", "uint32": "u4",
    "float": "f4", "float32": "f4", "double": "f8", "float64": "f8",
}
_OFF_MAGIC = ("OFF", "COFF", "NOFF", "CNOFF", "STOFF", "STCOFF", "4OFF", "NCOFF")
#: PCD TYPE code (F/I/U) -> numpy kind, per the PCL PCD spec.
_PCD_KIND = {"F": "f", "I": "i", "U": "u"}


# ---- low-level guards ------------------------------------------------------ #
def _ext(path: str) -> str:
    return os.path.splitext(str(path))[1].lower()


def _read_bytes(path: str) -> bytes:
    """Read a file whole after checking it exists and is within the size cap."""
    p = str(path)
    if not os.path.isfile(p):
        raise FileNotFoundError(p)
    size = os.path.getsize(p)
    if size == 0:
        raise ValueError("%s is empty" % p)
    if size > MAX_FILE_BYTES:
        raise ValueError("%s is %d bytes, over the %d-byte cap (mesh.MAX_FILE_BYTES)"
                         % (p, size, MAX_FILE_BYTES))
    with open(p, "rb") as f:
        return f.read()


def _text(raw: bytes) -> str:
    return raw.decode("utf-8", "replace")


def _check_count(n: int, what: str, src: str) -> int:
    if n < 0:
        raise ValueError("%s: negative %s count (%d)" % (src, what, n))
    if n > MAX_ELEMENTS:
        raise ValueError("%s: declares %d %s, over the %d cap (mesh.MAX_ELEMENTS)"
                         % (src, n, what, MAX_ELEMENTS))
    return n


def _floats(tokens, what: str, src: str) -> np.ndarray:
    """Token list -> float64 array, with a message that names the file."""
    try:
        return np.array(tokens, dtype=np.float64)
    except (ValueError, TypeError):
        raise ValueError("%s: malformed %s — expected numbers, got %r"
                         % (src, what, list(tokens)[:6])) from None


def _ints(tokens, what: str, src: str) -> np.ndarray:
    try:
        return np.array(tokens, dtype=np.int64)
    except (ValueError, TypeError):
        raise ValueError("%s: malformed %s — expected integers, got %r"
                         % (src, what, list(tokens)[:6])) from None


def _one_int(tok, what: str, src: str) -> int:
    try:
        return int(tok)
    except (ValueError, TypeError):
        raise ValueError("%s: malformed %s — expected an integer, got %r"
                         % (src, what, tok)) from None


def _finite_points(P, what: str, src: str) -> np.ndarray:
    """Coerce to (N, 3) float64 and reject NaN/Inf (a poisoned coordinate would
    silently corrupt every downstream registration / grasp computation)."""
    A = np.asarray(P, np.float64)
    if A.size == 0:
        return np.zeros((0, 3), np.float64)
    if A.ndim != 2 or A.shape[1] != 3:
        raise ValueError("%s: %s must be (N, 3), got %r" % (src, what, (A.shape,)))
    bad = ~np.isfinite(A)
    if bad.any():
        row = int(np.flatnonzero(bad.any(axis=1))[0])
        raise ValueError("%s: %s contain %d non-finite value(s) (first at index %d: %r)"
                         % (src, what, int(bad.sum()), row, A[row].tolist()))
    return A


def _fan_triangulate(faces, src: str) -> np.ndarray:
    """Polygon faces -> (nf, 3) int64 triangles by fan triangulation.

    *faces* is a list of index sequences **or** a uniform 2-D index array.
    A ``k``-gon becomes ``k-2`` triangles ``(f0, fi, fi+1)``; face order is kept.
    """
    if isinstance(faces, np.ndarray) and faces.ndim == 2:
        P, k = faces.astype(np.int64), int(faces.shape[1])
        if k < 3:
            raise ValueError("%s: face with %d vertices (need >= 3)" % (src, k))
    else:
        if len(faces) == 0:
            return np.zeros((0, 3), np.int64)
        sizes = np.fromiter((len(f) for f in faces), np.int64, len(faces))
        if int(sizes.min()) < 3:
            raise ValueError("%s: face with %d vertices (need >= 3)" % (src, int(sizes.min())))
        if int(sizes.min()) != int(sizes.max()):
            out = []
            for f in faces:
                f = np.asarray(f, np.int64)
                for i in range(1, len(f) - 1):
                    out.append((f[0], f[i], f[i + 1]))
            return np.asarray(out, np.int64).reshape(-1, 3)
        k = int(sizes[0])
        P = np.asarray([np.asarray(f, np.int64) for f in faces], np.int64).reshape(-1, k)
    if P.shape[0] == 0:
        return np.zeros((0, 3), np.int64)
    tris = np.stack([np.stack([P[:, 0], P[:, i], P[:, i + 1]], axis=1)
                     for i in range(1, k - 1)], axis=1)          # (m, k-2, 3)
    return tris.reshape(-1, 3).astype(np.int64)


def _finish_mesh(V, faces, src: str):
    """Validate vertices, triangulate faces, bounds-check every index."""
    V = _finite_points(V, "vertices", src)
    F = _fan_triangulate(faces, src)
    if F.size:
        lo, hi = int(F.min()), int(F.max())
        if lo < 0 or hi >= V.shape[0]:
            raise ValueError("%s: face index %d out of range for %d vertices"
                             % (src, hi if hi >= V.shape[0] else lo, V.shape[0]))
    return V, F


def _weld(P: np.ndarray):
    """Per-corner triangle soup (3m, 3) -> shared (V, F) by exact coordinate match."""
    V, inv = np.unique(P, axis=0, return_inverse=True)
    return V.astype(np.float64), np.asarray(inv).ravel().reshape(-1, 3).astype(np.int64)


# ---- Wavefront OBJ --------------------------------------------------------- #
def _read_obj_vertices(raw: bytes, src: str):
    """``v`` records -> (V, C). Colours only when a line carries exactly 6 numbers
    (``x y z r g b``, the common vertex-colour extension); ``v x y z w`` keeps w
    out of the colours."""
    # ★2026-11-05 redteam I14: records are keyword + whitespace (any blanks, tabs included);
    # "v\t1 2 3" and "f\t1 2 3" used to be skipped because the test was startswith("v ").
    rows, widths = [], []
    for ln in _text(raw).splitlines():
        s = ln.strip()
        if not s or s[0] == "#":
            continue
        parts = s.split()
        if parts[0] != "v":
            continue
        if len(parts) < 4:
            raise ValueError("%s: OBJ 'v' record needs 3 coordinates, got %r" % (src, s[:60]))
        rows.append(parts[1:7])
        widths.append(len(parts) - 1)
    # OBJ declares no counts, so "not one v record" cannot be told from "not an OBJ":
    # fail closed rather than hand back an empty mesh for an arbitrary file.
    if not rows:
        raise ValueError("%s: no 'v' vertex records — not a Wavefront OBJ file?" % src)
    V = _floats([r[:3] for r in rows], "OBJ vertex", src)
    C = None
    if all(w == 6 for w in widths):
        C = np.clip(_floats([r[3:6] for r in rows], "OBJ vertex colour", src), 0.0, 1.0)
    return V, C


def _read_obj(raw: bytes, src: str):
    V, _ = _read_obj_vertices(raw, src)
    nv_seen, seen, faces = 0, 0, []
    for ln in _text(raw).splitlines():
        s = ln.strip()
        if not s or s[0] == "#":
            continue
        keyword = s.split(None, 1)[0]
        if keyword == "v":
            seen += 1
            continue
        if keyword != "f":
            continue
        nv_seen = seen
        idx = []
        for tok in s.split()[1:]:
            first = tok.split("/")[0]
            if not first:
                raise ValueError("%s: OBJ face vertex %r has no vertex index" % (src, tok))
            i = _one_int(first, "OBJ face index", src)
            if i == 0:
                raise ValueError("%s: OBJ indices are 1-based, got 0" % src)
            idx.append(i - 1 if i > 0 else nv_seen + i)      # negative = relative, per spec
        if len(idx) < 3:
            raise ValueError("%s: OBJ face with %d vertices (need >= 3)" % (src, len(idx)))
        faces.append(np.asarray(idx, np.int64))
    return _finish_mesh(V, faces, src)


# ---- OFF ------------------------------------------------------------------- #
def _off_lines(raw: bytes) -> list:
    out = []
    for ln in _text(raw).splitlines():
        s = ln.split("#")[0].strip()
        if s:
            out.append(s)
    return out


def _read_off(raw: bytes, src: str):
    lines = _off_lines(raw)
    if not lines:
        raise ValueError("%s: OFF file has no content" % src)
    head = lines[0].split()
    if head[0].upper() not in _OFF_MAGIC:
        raise ValueError("%s: not an OFF file — first line is %r, expected an 'OFF' magic"
                         % (src, lines[0][:40]))
    if len(head) >= 4:                       # counts on the magic line: "OFF 8 12 0"
        counts, li = head[1:4], 1
    else:
        if len(lines) < 2:
            raise ValueError("%s: OFF file ends before its counts line" % src)
        counts, li = lines[1].split(), 2
    if len(counts) < 3:
        raise ValueError("%s: OFF counts line needs 'nvert nface nedge', got %r"
                         % (src, " ".join(counts)))
    nv = _check_count(_one_int(counts[0], "OFF vertex count", src), "vertices", src)
    nf = _check_count(_one_int(counts[1], "OFF face count", src), "faces", src)
    if len(lines) < li + nv + nf:
        raise ValueError("%s: OFF declares %d vertices + %d faces but only %d data lines follow"
                         % (src, nv, nf, len(lines) - li))
    # ★2026-11-05 redteam I13: a "4" in the magic (Geomview "[ST][C][N][4]OFF") means every
    # vertex is homogeneous ``x y z w`` -- the point is (x/w, y/w, z/w). w used to be dropped
    # (4OFF "2 0 0 2" read as (2, 0, 0) instead of (1, 0, 0)).
    homogeneous = "4" in head[0]
    ncoord = 4 if homogeneous else 3
    vrows = []
    for i in range(nv):
        t = lines[li + i].split()
        if len(t) < ncoord:
            raise ValueError("%s: OFF vertex line %d has %d value(s), need %d"
                             % (src, i, len(t), ncoord))
        vrows.append(t[:ncoord])
    if not vrows:
        V = np.zeros((0, 3))
    elif homogeneous:
        H = _floats(vrows, "OFF homogeneous vertex", src)
        w = H[:, 3]
        if not np.all(np.isfinite(w)) or np.any(w == 0):
            bad = int(np.flatnonzero(~np.isfinite(w) | (w == 0))[0])
            raise ValueError("%s: 4OFF vertex %d has w = %r — a point at infinity has no position"
                             % (src, bad, float(w[bad])))
        V = H[:, :3] / w[:, None]
    else:
        V = _floats(vrows, "OFF vertex", src)
    faces = []
    for i in range(nf):
        t = lines[li + nv + i].split()
        k = _one_int(t[0], "OFF face size", src) if t else 0
        if k < 3:
            raise ValueError("%s: OFF face line %d declares %d vertices (need >= 3)"
                             % (src, i, k))
        if len(t) < k + 1:
            raise ValueError("%s: OFF face line %d declares %d indices but carries %d"
                             % (src, i, k, len(t) - 1))
        faces.append(_ints(t[1:k + 1], "OFF face index", src))
    return _finish_mesh(V, faces, src)


# ---- STL (binary + ASCII) --------------------------------------------------- #
_STL_DTYPE = np.dtype([("normal", "<f4", (3,)), ("v", "<f4", (3, 3)), ("attr", "<u2")])


def _read_stl(raw: bytes, src: str):
    head = raw[:5].lower()
    probe = raw[:4096].lower()
    # A binary STL whose 80-byte header happens to start with "solid" (some
    # exporters write one) is recognised by its exact size 84 + 50*n first.
    if len(raw) >= 84:
        n_tri = int(np.frombuffer(raw, "<u4", count=1, offset=80)[0])
        if 84 + _STL_DTYPE.itemsize * n_tri == len(raw):
            return _read_stl_binary(raw, src)
    if head == b"solid" and b"facet" in probe:
        return _read_stl_ascii(raw, src)
    if len(raw) < 84:
        raise ValueError("%s: %d bytes is neither a binary STL (needs an 80-byte header + "
                         "4-byte triangle count) nor an ASCII STL ('solid' + 'facet' records)"
                         % (src, len(raw)))
    return _read_stl_binary(raw, src)


def _read_stl_ascii(raw: bytes, src: str):
    toks = _text(raw).split()
    rows, i, n = [], 0, len(toks)
    while i < n:
        if toks[i] == "vertex":
            if i + 3 >= n:
                raise ValueError("%s: ASCII STL ends inside a 'vertex' record" % src)
            rows.append(toks[i + 1:i + 4])
            i += 4
        else:
            i += 1
    if not rows:
        raise ValueError("%s: ASCII STL has no 'vertex' records" % src)
    if len(rows) % 3:
        raise ValueError("%s: ASCII STL has %d vertex records, not a multiple of 3"
                         % (src, len(rows)))
    _check_count(len(rows) // 3, "triangles", src)
    P = _finite_points(_floats(rows, "STL vertex", src), "vertices", src)
    V, F = _weld(P)
    return _finish_mesh(V, F, src)


def _read_stl_binary(raw: bytes, src: str):
    n = int(np.frombuffer(raw, "<u4", count=1, offset=80)[0])       # spec: little-endian
    _check_count(n, "triangles", src)
    need = 84 + _STL_DTYPE.itemsize * n
    if need > len(raw):
        raise ValueError("%s: binary STL header declares %d triangles (%d bytes) but the "
                         "file holds %d bytes" % (src, n, need, len(raw)))
    if n == 0:
        return np.zeros((0, 3), np.float64), np.zeros((0, 3), np.int64)
    tri = np.frombuffer(raw, _STL_DTYPE, count=n, offset=84)
    P = _finite_points(tri["v"].astype(np.float64).reshape(-1, 3), "vertices", src)
    V, F = _weld(P)
    return _finish_mesh(V, F, src)


# ---- PLY ------------------------------------------------------------------- #
def _ply_header(raw: bytes, src: str):
    """-> (format, elements, data_offset). Elements keep their declared property
    list so the body reader knows the exact byte / token layout."""
    if not raw.startswith(b"ply"):
        raise ValueError("%s: not a PLY file — missing the 'ply' magic" % src)
    # ★ match the whole line: a comment that merely mentions end_header used to
    #   end the header there and shift the binary body (silent garbage).
    m = re.search(rb"(?m)^[ \t]*end_header[ \t]*\r?$", raw)
    if m is None:
        raise ValueError("%s: PLY header has no 'end_header' line" % src)
    end = m.start()
    nl = raw.find(b"\n", end)
    if nl < 0:
        raise ValueError("%s: PLY 'end_header' line is not terminated" % src)
    fmt, elements = None, []
    for ln in raw[:end].decode("ascii", "replace").splitlines():
        parts = ln.split()
        if not parts:
            continue
        key = parts[0]
        if key == "format":
            if len(parts) < 2:
                raise ValueError("%s: PLY 'format' line is incomplete" % src)
            fmt = parts[1]
        elif key == "element":
            if len(parts) < 3:
                raise ValueError("%s: PLY 'element' line is incomplete" % src)
            cnt = _check_count(_one_int(parts[2], "PLY element count", src),
                               "%r elements" % parts[1], src)
            elements.append({"name": parts[1], "count": cnt, "props": []})
        elif key == "property":
            if not elements:
                raise ValueError("%s: PLY 'property' before any 'element'" % src)
            if len(parts) >= 2 and parts[1] == "list":
                if len(parts) < 5:
                    raise ValueError("%s: PLY list property is incomplete: %r" % (src, ln[:60]))
                if parts[2] not in _PLY_TYPES or parts[3] not in _PLY_TYPES:
                    raise ValueError("%s: unsupported PLY property type in %r" % (src, ln[:60]))
                elements[-1]["props"].append({"kind": "list", "count_type": parts[2],
                                              "type": parts[3], "name": parts[4]})
            else:
                if len(parts) < 3:
                    raise ValueError("%s: PLY property is incomplete: %r" % (src, ln[:60]))
                if parts[1] not in _PLY_TYPES:
                    raise ValueError("%s: unsupported PLY property type %r" % (src, parts[1]))
                elements[-1]["props"].append({"kind": "scalar", "type": parts[1],
                                              "name": parts[2]})
    if fmt not in ("ascii", "binary_little_endian", "binary_big_endian"):
        raise ValueError("%s: unsupported PLY format %r (want ascii / binary_little_endian "
                         "/ binary_big_endian)" % (src, fmt))
    return fmt, elements, nl + 1


def _ply_ascii(elements, text: str, src: str) -> dict:
    toks = text.split()
    pos, out = 0, {}
    for el in elements:
        n, props = el["count"], el["props"]
        sc, li = {}, {}
        if props and all(p["kind"] == "scalar" for p in props):
            k, need = len(props), n * len(props)
            if pos + need > len(toks):
                raise ValueError("%s: PLY element %r declares %d rows (%d values) but only "
                                 "%d values remain" % (src, el["name"], n, need, len(toks) - pos))
            block = _floats(toks[pos:pos + need], "PLY %r data" % el["name"], src).reshape(n, k)
            pos += need
            for j, p in enumerate(props):
                sc[p["name"]] = block[:, j]
        else:
            for p in props:
                (sc if p["kind"] == "scalar" else li)[p["name"]] = (
                    np.zeros(n, np.float64) if p["kind"] == "scalar" else [])
            for i in range(n):
                for p in props:
                    if pos >= len(toks):
                        raise ValueError("%s: PLY element %r ends after %d of %d rows"
                                         % (src, el["name"], i, n))
                    if p["kind"] == "scalar":
                        sc[p["name"]][i] = _floats([toks[pos]], "PLY %r" % p["name"], src)[0]
                        pos += 1
                    else:
                        c = _one_int(toks[pos], "PLY list length", src)
                        pos += 1
                        if c < 0 or pos + c > len(toks):
                            raise ValueError("%s: PLY list of length %d at row %d runs past the "
                                             "end of the file" % (src, c, i))
                        li[p["name"]].append(_ints(toks[pos:pos + c], "PLY list value", src))
                        pos += c
        out[el["name"]] = {"scalars": sc, "lists": li, "count": n,
                           "types": {p["name"]: p["type"] for p in props}}
    return out


def _ply_binary(elements, raw: bytes, offset: int, endian: str, src: str) -> dict:
    out, total = {}, len(raw)
    for el in elements:
        n, props = el["count"], el["props"]
        sc, li = {}, {}
        if props and all(p["kind"] == "scalar" for p in props):
            dt = np.dtype([("f%d" % j, endian + _PLY_TYPES[p["type"]])
                           for j, p in enumerate(props)])
            need = dt.itemsize * n
            if offset + need > total:
                raise ValueError("%s: PLY element %r declares %d rows (%d bytes) but only %d "
                                 "bytes remain" % (src, el["name"], n, need, total - offset))
            arr = np.frombuffer(raw, dt, count=n, offset=offset)
            offset += need
            for j, p in enumerate(props):
                sc[p["name"]] = arr["f%d" % j].astype(np.float64)
        elif len(props) == 1 and props[0]["kind"] == "list" and n > 0:
            p = props[0]
            ct, vt = endian + _PLY_TYPES[p["count_type"]], endian + _PLY_TYPES[p["type"]]
            csz = np.dtype(ct).itemsize
            if offset + csz > total:
                raise ValueError("%s: PLY element %r declares %d rows but the data ends at the "
                                 "first length field" % (src, el["name"], n))
            k = int(np.frombuffer(raw, ct, count=1, offset=offset)[0])
            if k < 0:
                raise ValueError("%s: PLY negative list length (%d)" % (src, k))
            dt = np.dtype([("n", ct), ("v", vt, (k,))])
            uniform = False
            if k >= 1 and offset + dt.itemsize * n <= total:
                arr = np.frombuffer(raw, dt, count=n, offset=offset)
                if bool(np.all(arr["n"] == k)):                    # every row has k entries
                    li[p["name"]] = arr["v"].astype(np.int64)      # (n, k) — fast path
                    offset += dt.itemsize * n
                    uniform = True
            if not uniform:
                offset, li[p["name"]] = _ply_binary_lists(raw, offset, n, ct, vt, el, src)
        else:
            rows = {p["name"]: (np.zeros(n, np.float64) if p["kind"] == "scalar" else [])
                    for p in props}
            for i in range(n):
                for p in props:
                    if p["kind"] == "scalar":
                        dt = np.dtype(endian + _PLY_TYPES[p["type"]])
                        if offset + dt.itemsize > total:
                            raise ValueError("%s: PLY element %r ends after %d of %d rows"
                                             % (src, el["name"], i, n))
                        rows[p["name"]][i] = float(np.frombuffer(raw, dt, count=1,
                                                                 offset=offset)[0])
                        offset += dt.itemsize
                    else:
                        ct = np.dtype(endian + _PLY_TYPES[p["count_type"]])
                        vt = np.dtype(endian + _PLY_TYPES[p["type"]])
                        if offset + ct.itemsize > total:
                            raise ValueError("%s: PLY element %r ends after %d of %d rows"
                                             % (src, el["name"], i, n))
                        c = int(np.frombuffer(raw, ct, count=1, offset=offset)[0])
                        offset += ct.itemsize
                        if c < 0 or offset + c * vt.itemsize > total:
                            raise ValueError("%s: PLY list of length %d at row %d runs past the "
                                             "end of the file" % (src, c, i))
                        rows[p["name"]].append(np.frombuffer(raw, vt, count=c,
                                                             offset=offset).astype(np.int64))
                        offset += c * vt.itemsize
            for p in props:
                (sc if p["kind"] == "scalar" else li)[p["name"]] = rows[p["name"]]
        out[el["name"]] = {"scalars": sc, "lists": li, "count": n,
                           "types": {p["name"]: p["type"] for p in props}}
    return out


def _ply_binary_lists(raw: bytes, offset: int, n: int, ct: str, vt: str, el, src: str):
    """Ragged binary list element (faces of mixed degree) — sequential fallback."""
    cdt, vdt, total, out = np.dtype(ct), np.dtype(vt), len(raw), []
    for i in range(n):
        if offset + cdt.itemsize > total:
            raise ValueError("%s: PLY element %r ends after %d of %d rows"
                             % (src, el["name"], i, n))
        c = int(np.frombuffer(raw, cdt, count=1, offset=offset)[0])
        offset += cdt.itemsize
        if c < 0 or offset + c * vdt.itemsize > total:
            raise ValueError("%s: PLY list of length %d at row %d runs past the end of the file"
                             % (src, c, i))
        out.append(np.frombuffer(raw, vdt, count=c, offset=offset).astype(np.int64))
        offset += c * vdt.itemsize
    return offset, out


def _ply_data(raw: bytes, src: str) -> dict:
    fmt, elements, offset = _ply_header(raw, src)
    if fmt == "ascii":
        return _ply_ascii(elements, raw[offset:].decode("utf-8", "replace"), src)
    endian = "<" if fmt == "binary_little_endian" else ">"
    return _ply_binary(elements, raw, offset, endian, src)


def _ply_xyz(el, src: str) -> np.ndarray:
    sc = el["scalars"]
    missing = [c for c in ("x", "y", "z") if c not in sc]
    if missing:
        raise ValueError("%s: PLY vertex element lacks propert%s %s"
                         % (src, "y" if len(missing) == 1 else "ies", ", ".join(missing)))
    return np.column_stack([sc["x"], sc["y"], sc["z"]]).astype(np.float64)


def _ply_rgb(el):
    """RGB in [0, 1] from whichever colour naming the file uses, else None.
    Integer channels are divided by their dtype maximum; float channels are
    assumed already normalised and clipped."""
    sc, types = el["scalars"], el["types"]
    for trio in (("red", "green", "blue"), ("r", "g", "b"),
                 ("diffuse_red", "diffuse_green", "diffuse_blue")):
        if all(c in sc for c in trio):
            C = np.column_stack([sc[c] for c in trio]).astype(np.float64)
            dt = np.dtype(_PLY_TYPES.get(types.get(trio[0], "uchar"), "u1"))
            if dt.kind in "iu":
                C = C / float(np.iinfo(dt).max)
            return np.clip(C, 0.0, 1.0)
    return None


def _read_ply_mesh(raw: bytes, src: str):
    data = _ply_data(raw, src)
    if "vertex" not in data:
        raise ValueError("%s: PLY has no 'vertex' element" % src)
    V = _ply_xyz(data["vertex"], src)
    faces = np.zeros((0, 3), np.int64)
    face = data.get("face")
    if face is not None and face["count"]:
        for key in ("vertex_indices", "vertex_index", "vertex-indices"):
            if key in face["lists"]:
                faces = face["lists"][key]
                break
        else:
            if face["lists"]:
                faces = next(iter(face["lists"].values()))
            else:
                raise ValueError("%s: PLY 'face' element has no vertex-index list property" % src)
    return _finish_mesh(V, faces, src)


def _read_ply_points(raw: bytes, src: str):
    data = _ply_data(raw, src)
    if "vertex" not in data:
        raise ValueError("%s: PLY has no 'vertex' element" % src)
    return _ply_xyz(data["vertex"], src), _ply_rgb(data["vertex"])


# ---- XYZ / PCD (points only) ------------------------------------------------ #
def _read_xyz(raw: bytes, src: str):
    """Plain text ``x y z [r g b]``, one point per line (``#`` starts a comment)."""
    rows = []
    comma_lines = plain_lines = comment_lines = 0
    for i, ln in enumerate(_text(raw).splitlines()):
        s = ln.split("#")[0].strip()
        if not s:
            comment_lines += ln.strip().startswith("#")
            continue
        if "," in s:
            # ★ A comma is a column separator only when it is the ONLY one on the
            #   line. "1,5 2,5 3,5" (decimal commas, European locale) used to be
            #   re-split into 6 columns and read as xyz + colour (silently wrong).
            toks = [t.strip() for t in s.split(",")]
            if any((not t) or len(t.split()) != 1 for t in toks):
                raise ValueError("%s: XYZ line %d mixes ',' with whitespace (decimal commas?) "
                                 "— use '.' as the decimal mark and one separator" % (src, i + 1))
            comma_lines += 1
            rows.append(toks)
        else:
            plain_lines += 1
            rows.append(s.split())
    if comma_lines and plain_lines:
        raise ValueError("%s: XYZ file mixes comma-separated and whitespace-separated lines"
                         % src)
    if not rows:
        # ★2026-11-05 redteam I26: write_points writes a 0-point cloud as a header comment
        # ("# 0 points ..."), and that file must read back as a (0, 3) cloud. A file with no
        # comment and no data (only blanks) is still refused -- it is not a point cloud.
        if comment_lines:
            return np.zeros((0, 3), np.float64), None
        raise ValueError("%s: XYZ file has no data lines" % src)
    _check_count(len(rows), "points", src)
    w = len(rows[0])
    if w < 3:
        raise ValueError("%s: XYZ needs at least 3 columns (x y z), first line has %d"
                         % (src, w))
    bad = next((i for i, r in enumerate(rows) if len(r) != w), None)
    if bad is not None:
        raise ValueError("%s: XYZ line %d has %d columns, expected %d — the file is not a "
                         "uniform 'x y z [r g b]' table" % (src, bad, len(rows[bad]), w))
    A = _floats(rows, "XYZ row", src).reshape(len(rows), w)
    C = None
    if w >= 6:
        C = A[:, 3:6]
        if np.isfinite(C).all() and C.max() > 1.0:       # 0..255 convention
            C = C / 255.0
        C = np.clip(C, 0.0, 1.0)
    return A[:, :3], C


def _pcd_header(raw: bytes, src: str):
    """Parse the ASCII PCD header -> ``(hdr, data_offset)``. The header is ASCII
    even for a binary body, so it is scanned byte-line by byte-line and the byte
    offset just past the ``DATA`` line's newline is returned for the binary readers
    (PCL, *The PCD (Point Cloud Data) file format*)."""
    fields = types = sizes = counts = None
    npts = width = height = data = None
    offset, pos, n = 0, 0, len(raw)
    while pos < n:
        nl = raw.find(b"\n", pos)
        end, nxt = (n, n) if nl < 0 else (nl, nl + 1)
        s = raw[pos:end].decode("ascii", "replace").strip()
        pos = nxt
        if not s or s.startswith("#"):
            continue
        parts = s.split()
        key = parts[0].upper()
        if key == "FIELDS":
            fields = parts[1:]
        elif key == "SIZE":
            sizes = parts[1:]
        elif key == "TYPE":
            types = parts[1:]
        elif key == "COUNT":
            counts = parts[1:]
        elif key == "WIDTH":
            width = _one_int(parts[1], "PCD WIDTH", src) if len(parts) > 1 else None
        elif key == "HEIGHT":
            height = _one_int(parts[1], "PCD HEIGHT", src) if len(parts) > 1 else None
        elif key == "POINTS":
            npts = _one_int(parts[1], "PCD POINTS", src) if len(parts) > 1 else None
        elif key == "DATA":
            data = parts[1].lower() if len(parts) > 1 else ""
            offset = nxt
            break
    if data is None:
        raise ValueError("%s: no PCD 'DATA' line — not a PCD file?" % src)
    if npts is None and width is not None and height is not None:
        npts = width * height
    hdr = {"fields": fields, "types": types, "sizes": sizes, "counts": counts,
           "npts": npts, "width": width, "height": height, "data": data,
           "low": [f.lower() for f in fields] if fields else []}
    return hdr, offset


def _pcd_check_layout(hdr: dict, src: str) -> None:
    """Constraints shared by every PCD body encoding."""
    if not hdr["fields"]:
        raise ValueError("%s: PCD header has no 'FIELDS' line" % src)
    counts = hdr["counts"]
    if counts is not None and any(c != "1" for c in counts):
        raise ValueError("%s: PCD COUNT != 1 per field is not supported (got %r)"
                         % (src, " ".join(counts)))


def _pcd_np_type(tc: str, sz, src: str) -> str:
    """PCD ``(TYPE, SIZE)`` -> a little-endian numpy dtype string. PCD binary is
    written in the host byte order, which is little-endian on every platform PCL
    targets; that is what is honoured here."""
    kind = _PCD_KIND.get(str(tc).upper())
    if kind is None:
        raise ValueError("%s: unsupported PCD TYPE %r (want F, I or U)" % (src, tc))
    try:
        s = int(sz)
    except (ValueError, TypeError):
        raise ValueError("%s: malformed PCD SIZE %r" % (src, sz)) from None
    if kind == "f" and s not in (4, 8):
        raise ValueError("%s: PCD float SIZE %d unsupported (want 4 or 8)" % (src, s))
    if kind in "iu" and s not in (1, 2, 4, 8):
        raise ValueError("%s: PCD %s SIZE %d unsupported (want 1/2/4/8)"
                         % (src, "int" if kind == "i" else "uint", s))
    return "<%s%d" % (kind, s)


def _pcd_binary_layout(hdr: dict, src: str):
    """Validate + return the per-field numpy dtype strings for a binary PCD."""
    fields, types, sizes = hdr["fields"], hdr["types"], hdr["sizes"]
    if types is None or sizes is None:
        raise ValueError("%s: binary PCD needs both SIZE and TYPE header lines" % src)
    if not (len(fields) == len(sizes) == len(types)):
        raise ValueError("%s: PCD FIELDS/SIZE/TYPE lengths differ (%d/%d/%d)"
                         % (src, len(fields), len(sizes), len(types)))
    if hdr["npts"] is None:
        raise ValueError("%s: binary PCD needs a POINTS or WIDTH*HEIGHT count" % src)
    return [_pcd_np_type(types[j], sizes[j], src) for j in range(len(fields))]


def _pcd_extract(col: dict, hdr: dict, src: str):
    """Column dict (field name -> 1-D array) -> ``(P, C)``. ``x/y/z`` build the
    cloud; colours come from ``r/g/b``, ``red/green/blue`` (0..255) or a packed
    ``rgb``/``rgba`` field, exactly as the ASCII path always has. Non-xyz/rgb
    fields (intensity, normals, curvature, ...) are dropped."""
    low, types = hdr["low"], hdr["types"]
    for axis in ("x", "y", "z"):
        if axis not in col:
            raise ValueError("%s: PCD FIELDS %r has no %r field"
                             % (src, " ".join(hdr["fields"]), axis))
    P = np.column_stack([col[a].astype(np.float64) for a in ("x", "y", "z")])
    C = None
    for trio in (("r", "g", "b"), ("red", "green", "blue")):
        if all(c in col for c in trio):
            C = np.clip(np.column_stack([col[c].astype(np.float64) for c in trio])
                        / 255.0, 0.0, 1.0)
            break
    if C is None and ("rgb" in col or "rgba" in col):
        name = "rgb" if "rgb" in col else "rgba"
        j = low.index(name)
        kind = (types[j].upper() if types is not None and j < len(types) else "F")
        vals = col[name]
        packed = (vals.astype(np.float32).view(np.uint32) if kind == "F"
                  else vals.astype(np.int64).astype(np.uint32))
        C = np.clip(np.column_stack([(packed >> 16) & 255, (packed >> 8) & 255,
                                     packed & 255]).astype(np.float64) / 255.0, 0.0, 1.0)
    return P, C


def _read_pcd(raw: bytes, src: str):
    """PCD (Point Cloud Library file format), all three encodings:

      * ``ascii`` — whitespace ``FIELDS`` values, one point per line.
      * ``binary`` — packed little-endian records (array-of-structures).
      * ``binary_compressed`` — LZF-compressed, structure-of-arrays layout.

    Only the ``x/y/z`` (and ``r/g/b`` / packed ``rgb``) fields are returned;
    ``COUNT != 1`` is refused. Fields are read with the declared ``SIZE``/``TYPE``.
    """
    hdr, offset = _pcd_header(raw, src)
    _pcd_check_layout(hdr, src)
    data = hdr["data"]
    if data == "ascii":
        return _read_pcd_ascii(raw, offset, hdr, src)
    if data == "binary":
        return _read_pcd_binary(raw, offset, hdr, src)
    if data == "binary_compressed":
        return _read_pcd_binary_compressed(raw, offset, hdr, src)
    raise ValueError("%s: PCD DATA %r is not supported — want 'ascii', 'binary' or "
                     "'binary_compressed'" % (src, data))


def _read_pcd_ascii(raw: bytes, offset: int, hdr: dict, src: str):
    fields, npts = hdr["fields"], hdr["npts"]
    rows = []
    for ln in raw[offset:].decode("utf-8", "replace").splitlines():
        s = ln.strip()
        if not s or s.startswith("#"):
            continue
        rows.append(s.split())
    if npts is None:
        npts = len(rows)
    _check_count(npts, "points", src)
    if len(rows) < npts:
        raise ValueError("%s: PCD declares %d points but only %d data rows follow"
                         % (src, npts, len(rows)))
    rows = rows[:npts]
    nf = len(fields)
    bad = next((i for i, r in enumerate(rows) if len(r) != nf), None)
    if bad is not None:
        raise ValueError("%s: PCD row %d has %d values, expected %d (one per FIELD)"
                         % (src, bad, len(rows[bad]), nf))
    A = _floats(rows, "PCD row", src).reshape(npts, nf) if npts else np.zeros((0, nf))
    col = {hdr["low"][j]: A[:, j] for j in range(nf)}
    return _pcd_extract(col, hdr, src)


def _read_pcd_binary(raw: bytes, offset: int, hdr: dict, src: str):
    formats = _pcd_binary_layout(hdr, src)
    npts = _check_count(int(hdr["npts"]), "points", src)
    dt = np.dtype([("f%d" % j, formats[j]) for j in range(len(formats))])
    need = dt.itemsize * npts
    if offset + need > len(raw):
        raise ValueError("%s: binary PCD declares %d points (%d bytes) but only %d bytes "
                         "follow the header" % (src, npts, need, len(raw) - offset))
    if npts == 0:
        col = {hdr["low"][j]: np.zeros(0, formats[j]) for j in range(len(formats))}
    else:
        arr = np.frombuffer(raw, dt, count=npts, offset=offset)
        col = {hdr["low"][j]: arr["f%d" % j] for j in range(len(formats))}
    return _pcd_extract(col, hdr, src)


def _read_pcd_binary_compressed(raw: bytes, offset: int, hdr: dict, src: str):
    formats = _pcd_binary_layout(hdr, src)
    npts = _check_count(int(hdr["npts"]), "points", src)
    if offset + 8 > len(raw):
        raise ValueError("%s: binary_compressed PCD ends before its 8-byte size header" % src)
    csize, usize = (int(v) for v in np.frombuffer(raw, "<u4", count=2, offset=offset))
    body = offset + 8
    if csize > len(raw) - body:
        raise ValueError("%s: binary_compressed PCD declares %d compressed bytes but only %d "
                         "follow" % (src, csize, len(raw) - body))
    sizes = [np.dtype(f).itemsize for f in formats]
    expect = int(np.sum(sizes)) * npts
    if usize != expect:
        raise ValueError("%s: binary_compressed PCD uncompressed size %d != %d "
                         "(fields x points)" % (src, usize, expect))
    if usize > MAX_FILE_BYTES:
        raise ValueError("%s: binary_compressed PCD uncompressed size %d over the %d-byte cap "
                         "(mesh.MAX_FILE_BYTES)" % (src, usize, MAX_FILE_BYTES))
    buf = _lzf_decompress(raw[body:body + csize], usize, src)
    # binary_compressed is structure-of-arrays: every point's field 0, then every
    # point's field 1, ... — the transpose of the packed binary record layout.
    col, off = {}, 0
    for j, fmt in enumerate(formats):
        col[hdr["low"][j]] = (np.frombuffer(buf, fmt, count=npts, offset=off)
                              if npts else np.zeros(0, fmt))
        off += sizes[j] * npts
    return _pcd_extract(col, hdr, src)


def _lzf_decompress(data: bytes, expected_len: int, src: str) -> bytes:
    """Decompress an LZF stream (Marc Lehmann's *liblzf*, the codec PCL uses for
    ``binary_compressed`` PCD). Pure-Python and bounds-checked: a control byte
    ``< 32`` is a literal run of ``ctrl+1`` bytes; otherwise it is a back-reference
    whose length is ``(ctrl >> 5) + 2`` (extended by one byte when the field is 7)
    at distance ``((ctrl & 0x1f) << 8) + next + 1``. Every offset is validated
    against the output produced so far, and the total is capped at *expected_len*,
    so a malformed stream raises ``ValueError`` rather than looping or over-reading.

    Literal runs are copied by slice; only back-references iterate in Python, so a
    very large highly-compressible cloud decompresses slowly — acceptable for the
    import path, and bounded by ``MAX_FILE_BYTES``."""
    out = bytearray()
    ip, n = 0, len(data)
    while ip < n:
        ctrl = data[ip]
        ip += 1
        if ctrl < 32:                                   # literal run
            run = ctrl + 1
            if ip + run > n:
                raise ValueError("%s: LZF literal run runs past the compressed data" % src)
            out += data[ip:ip + run]
            ip += run
        else:                                           # back reference
            length = ctrl >> 5
            if length == 7:
                if ip >= n:
                    raise ValueError("%s: LZF stream truncated in an extended length" % src)
                length += data[ip]
                ip += 1
            if ip >= n:
                raise ValueError("%s: LZF stream truncated in a back-reference" % src)
            ref = len(out) - ((ctrl & 0x1f) << 8) - 1 - data[ip]
            ip += 1
            if ref < 0:
                raise ValueError("%s: LZF back-reference points before the output start" % src)
            for _ in range(length + 2):                 # min match length is 3
                out.append(out[ref])
                ref += 1
        if len(out) > expected_len:
            raise ValueError("%s: LZF output exceeds the declared uncompressed size (%d)"
                             % (src, expected_len))
    if len(out) != expected_len:
        raise ValueError("%s: LZF decompressed to %d bytes, header declared %d"
                         % (src, len(out), expected_len))
    return bytes(out)


# ---- NPY / NPZ (points only) ------------------------------------------------ #
def _points_from_array(A, src: str, what: str = "array"):
    """An in-memory array -> ``(P, C)``: an ``(N, 3)`` cloud, or ``(N, 6)`` as
    ``xyz`` + ``rgb`` (a colour column whose maximum exceeds 1 is read as 0..255,
    matching the ``.xyz`` convention; values already in ``[0, 1]`` are kept exactly
    so a ``write_points`` round-trip is lossless)."""
    A = np.asarray(A)
    if A.ndim != 2 or A.shape[1] not in (3, 6):
        raise ValueError("%s: %s must be (N, 3) xyz or (N, 6) xyz+rgb, got shape %r"
                         % (src, what, (A.shape,)))
    _check_count(A.shape[0], "points", src)
    P = A[:, :3].astype(np.float64)
    C = None
    if A.shape[1] == 6:
        C = A[:, 3:6].astype(np.float64)
        if C.size and np.isfinite(C).all() and C.max() > 1.0:
            C = C / 255.0
        C = np.clip(C, 0.0, 1.0)
    return P, C


def _read_npy(raw: bytes, src: str):
    """A ``.npy`` array (NumPy's public NPY format). Loaded with
    ``allow_pickle=False`` so an untrusted file cannot smuggle a pickle."""
    try:
        A = np.load(io.BytesIO(raw), allow_pickle=False)
    except Exception as e:                              # noqa: BLE001 — untrusted input
        raise ValueError("%s: not a readable .npy array (%s)" % (src, e)) from None
    return _points_from_array(A, src, ".npy array")


def _read_npz(raw: bytes, src: str):
    """A ``.npz`` archive. The primary cloud is the ``xyz`` key, else ``points``,
    else the sole array; an optional ``colors`` (or ``rgb``) key supplies separate
    colours when the primary array is ``(N, 3)``. ``allow_pickle=False`` throughout."""
    try:
        z = np.load(io.BytesIO(raw), allow_pickle=False)
    except Exception as e:                              # noqa: BLE001 — untrusted input
        raise ValueError("%s: not a readable .npz archive (%s)" % (src, e)) from None
    try:
        keys = list(z.keys())

        def _pick(names):
            for k in names:
                if k in keys:
                    return np.asarray(z[k])
            return None

        A = _pick(("xyz", "points"))
        if A is None:
            if len(keys) == 1:
                A = np.asarray(z[keys[0]])
            else:
                raise ValueError("%s: .npz holds %d arrays %r — need a sole array or an "
                                 "'xyz'/'points' key" % (src, len(keys), keys))
        Csep = _pick(("colors", "rgb"))
    finally:
        z.close()
    P, C = _points_from_array(A, src, ".npz array")
    if Csep is not None and C is None:
        Csep = np.asarray(Csep, np.float64)
        if Csep.ndim != 2 or Csep.shape != (P.shape[0], 3):
            raise ValueError("%s: .npz colours have shape %r, need (%d, 3)"
                             % (src, (Csep.shape,), P.shape[0]))
        if Csep.size and np.isfinite(Csep).all() and Csep.max() > 1.0:
            Csep = Csep / 255.0
        C = np.clip(Csep, 0.0, 1.0)
    return P, C


# ---- public readers --------------------------------------------------------- #
def read_mesh(path: str):
    """Read a triangle mesh -> ``(V, F)``: vertices (nv, 3) float64 and triangle
    indices (nf, 3) int64.

    The format comes from the extension (``.obj``, ``.stl``, ``.ply``, ``.off``);
    STL and PLY additionally sniff **binary vs ASCII** from the header/content and
    honour the declared endianness. Polygons with more than 3 corners are
    fan-triangulated. STL has no vertex sharing, so its per-triangle corners are
    welded on exact coordinate equality (8 vertices for a cube, not 36).

    Raises ``ValueError`` on a malformed header, a declared count that does not
    fit the file, an out-of-range face index, or a NaN/Inf coordinate — never a
    partially parsed mesh.
    """
    src = str(path)
    ext = _ext(src)
    if ext not in MESH_FORMATS:
        raise ValueError("unsupported mesh format %r for %s — read_mesh handles %s"
                         % (ext, src, ", ".join(MESH_FORMATS)))
    raw = _read_bytes(src)
    if ext == ".obj":
        return _read_obj(raw, src)
    if ext == ".off":
        return _read_off(raw, src)
    if ext == ".stl":
        return _read_stl(raw, src)
    return _read_ply_mesh(raw, src)


def read_points(path: str, with_colors: bool = False):
    """Read a point cloud -> ``P`` (n, 3) float64, or ``(P, C)`` when
    *with_colors* (``C`` is (n, 3) in [0, 1], or ``None`` when the file carries
    no colours).

    Supported: ``.ply`` (the ``vertex`` element, with ``red/green/blue``,
    ``r/g/b`` or ``diffuse_*`` colours), ``.xyz`` / ``.txt`` / ``.pts`` / ``.asc``
    (whitespace ``x y z [r g b]``; a colour column whose maximum exceeds 1 is read
    as 0..255), ``.obj`` (``v`` records only — faces ignored), ``.pcd`` (``ascii``,
    ``binary`` and ``binary_compressed``; fields ``x y z`` plus ``r g b`` or a
    packed ``rgb``), ``.npy`` / ``.npz`` (an ``(N, 3)`` or ``(N, 6=xyz+rgb)`` array;
    ``.npz`` takes the ``xyz``/``points`` key or the sole array), and ``.stl`` /
    ``.off`` via their mesh vertices. ``.npy`` / ``.npz`` load with
    ``allow_pickle=False`` so an untrusted archive cannot execute code.
    """
    src = str(path)
    ext = _ext(src)
    if ext not in POINT_FORMATS:
        raise ValueError("unsupported point format %r for %s — read_points handles %s"
                         % (ext, src, ", ".join(POINT_FORMATS)))
    raw = _read_bytes(src)
    if ext == ".ply":
        P, C = _read_ply_points(raw, src)
    elif ext == ".pcd":
        P, C = _read_pcd(raw, src)
    elif ext == ".obj":
        P, C = _read_obj_vertices(raw, src)
    elif ext == ".stl":
        P, C = _read_stl(raw, src)[0], None
    elif ext == ".off":
        P, C = _read_off(raw, src)[0], None
    elif ext == ".npy":
        P, C = _read_npy(raw, src)
    elif ext == ".npz":
        P, C = _read_npz(raw, src)
    else:
        P, C = _read_xyz(raw, src)
    P = _finite_points(P, "points", src)
    if C is not None:
        C = np.asarray(C, np.float64)
        if C.shape != P.shape:
            raise ValueError("%s: %d colours for %d points" % (src, C.shape[0], P.shape[0]))
        if not np.isfinite(C).all():
            raise ValueError("%s: colours contain non-finite values" % src)
    return (P, C) if with_colors else P


# ---- mesh writer ------------------------------------------------------------ #
def write_mesh(path: str, vertices, faces, binary: bool = False) -> None:
    """Write a triangle mesh to any format :func:`read_mesh` reads — ``.obj``,
    ``.ply``, ``.stl`` or ``.off`` — so import and export are symmetric.

      * ``.obj`` / ``.off`` — ASCII, 17 significant digits: **exact** float64.
      * ``.ply`` — ASCII by default (17 digits, ``double`` properties: exact
        float64); ``binary=True`` writes ``binary_little_endian`` with ``double``
        vertices (also exact) and a ``uchar/int`` ``vertex_indices`` face list.
      * ``.stl`` — binary STL only (3D Systems' *StereoLithography* spec): 80-byte
        header, ``uint32`` count, 50 bytes/triangle with a computed facet normal.
        STL is **float32**, so coordinates round-trip at single precision.

    Geometry only — no materials, textures or per-vertex colours (see
    :func:`write_points` for coloured clouds). Raises ``ValueError`` on a bad
    extension, a non-``(M, 3)`` face array, an out-of-range index or a NaN/Inf.
    """
    src = str(path)
    ext = _ext(src)
    if ext not in WRITE_MESH_FORMATS:
        raise ValueError("unsupported mesh write format %r for %s — write_mesh handles %s"
                         % (ext, src, ", ".join(WRITE_MESH_FORMATS)))
    V = _finite_points(vertices, "vertices", src)
    F = np.asarray(faces, np.int64)
    if F.size == 0:
        F = np.zeros((0, 3), np.int64)
    if F.ndim != 2 or F.shape[1] != 3:
        raise ValueError("%s: faces must be (M, 3) triangles, got %r" % (src, (F.shape,)))
    if F.size and (int(F.min()) < 0 or int(F.max()) >= V.shape[0]):
        raise ValueError("%s: face index out of range for %d vertices" % (src, V.shape[0]))
    if ext == ".obj":
        _write_obj(src, V, F)
    elif ext == ".off":
        _write_off(src, V, F)
    elif ext == ".stl":
        _write_stl_binary(src, V, F)
    elif binary:
        _write_ply_mesh_binary(src, V, F)
    else:
        _write_ply_mesh_ascii(src, V, F)


def _write_obj(src: str, V: np.ndarray, F: np.ndarray) -> None:
    out = ["# Wavefront OBJ written by fullseye.mesh", "o mesh"]
    out += ["v %.17g %.17g %.17g" % (x, y, z) for x, y, z in V]
    out += ["f %d %d %d" % (i + 1, j + 1, k + 1) for i, j, k in F]         # OBJ is 1-based
    with open(src, "w", encoding="ascii") as f:
        f.write("\n".join(out) + "\n")


def _write_off(src: str, V: np.ndarray, F: np.ndarray) -> None:
    out = ["OFF", "%d %d 0" % (V.shape[0], F.shape[0])]
    out += ["%.17g %.17g %.17g" % (x, y, z) for x, y, z in V]
    out += ["3 %d %d %d" % (i, j, k) for i, j, k in F]
    with open(src, "w", encoding="ascii") as f:
        f.write("\n".join(out) + "\n")


def _write_ply_mesh_ascii(src: str, V: np.ndarray, F: np.ndarray) -> None:
    out = ["ply", "format ascii 1.0", "comment written by fullseye.mesh",
           "element vertex %d" % V.shape[0],
           "property double x", "property double y", "property double z",
           "element face %d" % F.shape[0],
           "property list uchar int vertex_indices", "end_header"]
    out += ["%.17g %.17g %.17g" % (x, y, z) for x, y, z in V]
    out += ["3 %d %d %d" % (i, j, k) for i, j, k in F]
    with open(src, "w", encoding="ascii") as f:
        f.write("\n".join(out) + "\n")


def _write_ply_mesh_binary(src: str, V: np.ndarray, F: np.ndarray) -> None:
    header = ("ply\nformat binary_little_endian 1.0\ncomment written by fullseye.mesh\n"
              "element vertex %d\nproperty double x\nproperty double y\nproperty double z\n"
              "element face %d\nproperty list uchar int vertex_indices\n"
              "end_header\n" % (V.shape[0], F.shape[0])).encode("ascii")
    faces = np.zeros(F.shape[0], np.dtype([("n", "u1"), ("v", "<i4", (3,))]))
    faces["n"] = 3
    faces["v"] = F.astype("<i4")
    with open(src, "wb") as f:
        f.write(header)
        f.write(np.ascontiguousarray(V, "<f8").tobytes())
        f.write(faces.tobytes())


def _write_stl_binary(src: str, V: np.ndarray, F: np.ndarray) -> None:
    tri = V[F] if F.shape[0] else np.zeros((0, 3, 3), np.float64)          # (nf, 3, 3)
    nrm = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    ln = np.linalg.norm(nrm, axis=1, keepdims=True)
    nrm = np.divide(nrm, ln, out=np.zeros_like(nrm), where=ln > 0)         # 0 for degenerate
    rec = np.zeros(F.shape[0], _STL_DTYPE)
    rec["normal"] = nrm.astype("<f4")
    rec["v"] = tri.astype("<f4")
    head = b"binary STL written by fullseye.mesh".ljust(80, b"\0")
    with open(src, "wb") as f:
        f.write(head)
        f.write(np.array([F.shape[0]], "<u4").tobytes())
        f.write(rec.tobytes())


# ---- point-cloud writer ----------------------------------------------------- #
def write_points(path: str, points, colors=None, binary: bool = True) -> None:
    """Write a point cloud to ``.ply``, ``.xyz`` (``.txt`` / ``.pts`` / ``.asc``),
    ``.npy`` or ``.npz`` — the numpy-native export side of :func:`read_points`.

    *points* is ``(N, 3)``; optional *colors* is ``(N, 3)`` in ``[0, 1]``.

      * ``.npy`` / ``.npz`` — one array, ``(N, 3)`` or ``(N, 6=xyz+rgb)`` when
        coloured. Coordinates **and** colours round-trip **exactly** (colours stay
        float in ``[0, 1]``). ``.npz`` stores it under the ``points`` key.
      * ``.xyz`` — text ``x y z [r g b]``, 17 digits; colours written as floats in
        ``[0, 1]`` (exact round-trip through :func:`read_points`). An empty cloud is
        written as one ``# 0 points`` comment line and reads back as ``(0, 3)``.
      * ``.ply`` — ``binary_little_endian`` by default (``binary=False`` for
        ASCII), ``double`` xyz (exact) and, when coloured, ``uchar`` red/green/blue
        **quantised to 8 bits** (use ``.npy``/``.npz`` for exact colour).

    This is the mesh module's own cloud writer (npy/xyz/binary-PLY); the ASCII-PLY
    convenience writer in :mod:`imgio` (``save_ply``) is separate and not
    duplicated here. Raises ``ValueError`` on a bad extension, a shape mismatch or
    a NaN/Inf coordinate/colour.
    """
    src = str(path)
    ext = _ext(src)
    if ext not in WRITE_POINT_FORMATS:
        raise ValueError("unsupported point write format %r for %s — write_points handles %s"
                         % (ext, src, ", ".join(WRITE_POINT_FORMATS)))
    P = _finite_points(points, "points", src)
    C = None
    if colors is not None:
        C = np.asarray(colors, np.float64)
        if C.ndim != 2 or C.shape != P.shape:
            raise ValueError("%s: colours must be (N, 3) matching %d points, got %r"
                             % (src, P.shape[0], (C.shape,)))
        if not np.isfinite(C).all():
            raise ValueError("%s: colours contain non-finite values" % src)
        C = np.clip(C, 0.0, 1.0)
    if ext == ".ply":
        _write_ply_points(src, P, C, binary)
    elif ext in (".npy", ".npz"):
        _write_npy_points(src, P, C, ext == ".npz")
    else:
        _write_xyz_points(src, P, C)


def _points_array(P: np.ndarray, C):
    """Fold optional colours into a single ``(N, 3)`` or ``(N, 6)`` float64 array."""
    return P if C is None else np.column_stack([P, C]).astype(np.float64)


def _write_npy_points(src: str, P: np.ndarray, C, as_npz: bool) -> None:
    arr = _points_array(P, C)
    if as_npz:
        np.savez(src, points=arr)
    else:
        np.save(src, arr)


def _write_xyz_points(src: str, P: np.ndarray, C) -> None:
    if C is None:
        rows = ["%.17g %.17g %.17g" % (x, y, z) for x, y, z in P]
    else:
        rows = ["%.17g %.17g %.17g %.17g %.17g %.17g" % (x, y, z, r, g, b)
                for (x, y, z), (r, g, b) in zip(P, C)]
    if not rows:
        # an empty file cannot be told from a truncated one; say what it is (I26)
        rows = ["# 0 points (x y z%s)" % ("" if C is None else " r g b")]
    with open(src, "w", encoding="ascii") as f:
        f.write("\n".join(rows) + "\n")


def _write_ply_points(src: str, P: np.ndarray, C, binary: bool) -> None:
    n = P.shape[0]
    lines = ["ply",
             "format %s 1.0" % ("binary_little_endian" if binary else "ascii"),
             "comment written by fullseye.mesh",
             "element vertex %d" % n,
             "property double x", "property double y", "property double z"]
    if C is not None:
        lines += ["property uchar red", "property uchar green", "property uchar blue"]
    lines.append("end_header")
    header = "\n".join(lines) + "\n"
    q = None if C is None else np.clip(np.rint(C * 255.0), 0, 255).astype(np.uint8)
    if binary:
        if C is None:
            dt = np.dtype([("x", "<f8"), ("y", "<f8"), ("z", "<f8")])
            rec = np.zeros(n, dt)
        else:
            dt = np.dtype([("x", "<f8"), ("y", "<f8"), ("z", "<f8"),
                           ("red", "u1"), ("green", "u1"), ("blue", "u1")])
            rec = np.zeros(n, dt)
            rec["red"], rec["green"], rec["blue"] = q[:, 0], q[:, 1], q[:, 2]
        rec["x"], rec["y"], rec["z"] = P[:, 0], P[:, 1], P[:, 2]
        with open(src, "wb") as f:
            f.write(header.encode("ascii"))
            f.write(rec.tobytes())
    else:
        if C is None:
            body = ["%.17g %.17g %.17g" % (x, y, z) for x, y, z in P]
        else:
            body = ["%.17g %.17g %.17g %d %d %d" % (x, y, z, r, g, b)
                    for (x, y, z), (r, g, b) in zip(P, q)]
        with open(src, "w", encoding="ascii") as f:
            f.write(header + "\n".join(body) + ("\n" if body else ""))


# ---- geometry helpers -------------------------------------------------------- #
def _tri_corners(V, F, src: str = "mesh"):
    """(V, F) -> the three corner arrays A, B, C, each (nf, 3), after validation."""
    V = _finite_points(V, "vertices", src)
    F = np.asarray(F, np.int64)
    if F.size == 0:
        raise ValueError("mesh has no faces")
    if F.ndim != 2 or F.shape[1] != 3:
        raise ValueError("faces must be (M, 3) triangles, got %r" % (F.shape,))
    if int(F.min()) < 0 or int(F.max()) >= V.shape[0]:
        raise ValueError("face index out of range for %d vertices" % V.shape[0])
    return V[F[:, 0]], V[F[:, 1]], V[F[:, 2]]


def sample_surface(V, F, n: int, seed: int = 0) -> np.ndarray:
    """Uniformly sample *n* points over the mesh **surface** -> (n, 3) float64.

    Area-weighted: a triangle is drawn with probability proportional to its area,
    then a point is drawn uniformly inside it with the reflected-barycentric trick
    (``u+v>1 -> (1-u, 1-v)``), so density is uniform per unit area rather than per
    triangle. Deterministic for a given *seed* (``np.random.default_rng(seed)``).

    This is the bridge from an imported CAD/scan mesh to the (N, 3) cloud
    :mod:`pointcloud` and :mod:`registration` work on.
    """
    A, B, C = _tri_corners(V, F)
    n = int(n)
    if n < 0:
        raise ValueError("n must be >= 0, got %r" % (n,))
    if n == 0:
        return np.zeros((0, 3), np.float64)
    area = 0.5 * np.linalg.norm(np.cross(B - A, C - A), axis=1)
    total = float(area.sum())
    if not np.isfinite(total) or total <= 0.0:
        raise ValueError("mesh has zero total surface area — nothing to sample")
    rng = np.random.default_rng(seed)
    cum = np.cumsum(area) / total
    cum[-1] = 1.0
    idx = np.searchsorted(cum, rng.random(n), side="right")
    idx = np.clip(idx, 0, area.shape[0] - 1)
    u, v = rng.random(n), rng.random(n)
    fold = (u + v) > 1.0
    u[fold], v[fold] = 1.0 - u[fold], 1.0 - v[fold]
    a, ab, ac = A[idx], B[idx] - A[idx], C[idx] - A[idx]
    return a + u[:, None] * ab + v[:, None] * ac


def mesh_to_points(V, F, n: int, seed: int = 0) -> np.ndarray:
    """Alias of :func:`sample_surface` — mesh in, point cloud out."""
    return sample_surface(V, F, n, seed=seed)


def voxelize(V, F, pitch: float):
    """Rasterise the mesh onto a regular grid -> ``(occ, origin)``.

    *occ* is a bool (nx, ny, nz) array (the ``volume`` sort, indexed x, y, z) and
    *origin* is the float64 (3,) world coordinate of the **corner** of cell
    ``occ[0, 0, 0]`` — i.e. that cell covers ``[origin, origin + pitch)`` on each
    axis, so a world point maps to ``floor((p - origin) / pitch)``. *origin* is
    the mesh's bounding-box minimum.

    This is **surface** voxelization: every cell a triangle passes through is
    marked and the interior is left empty (a hollow shell). Solid/interior fill
    needs an inside-outside test, which this module does not do — do not read an
    occupied cell as "material here", only as "surface here".

    Triangles are covered by a barycentric lattice with spacing <= ``pitch/2``,
    which marks every cell the triangle meets for the meshes tested; it is a
    dense-sampling rasteriser, not an exact triangle-box intersection test, so a
    sliver triangle crossing a cell corner can in principle be missed.
    """
    A, B, C = _tri_corners(V, F)
    pitch = float(pitch)
    if not np.isfinite(pitch) or pitch <= 0.0:
        raise ValueError("pitch must be > 0, got %r" % (pitch,))
    lo = np.minimum(np.minimum(A.min(0), B.min(0)), C.min(0))
    hi = np.maximum(np.maximum(A.max(0), B.max(0)), C.max(0))
    span = np.maximum(np.floor((hi - lo) / pitch) + 1.0, 1.0)      # float: no int overflow
    cells = float(np.prod(span))
    if not np.isfinite(cells) or cells > MAX_VOXELS:
        raise ValueError("pitch %g gives a %s grid (%.3g cells), over the %d cap "
                         "(mesh.MAX_VOXELS) — use a larger pitch"
                         % (pitch, tuple(span.tolist()), cells, MAX_VOXELS))
    shape = span.astype(np.int64)
    edge = np.maximum(np.maximum(np.linalg.norm(B - A, axis=1),
                                 np.linalg.norm(C - A, axis=1)),
                      np.linalg.norm(C - B, axis=1))
    sub = np.clip(np.ceil(edge / (0.5 * pitch)), 1.0, _MAX_SUBDIV).astype(np.int64)
    est = float(np.sum((sub + 1.0) * (sub + 2.0) / 2.0))
    if est > _MAX_VOXEL_SAMPLES:
        raise ValueError("pitch %g needs ~%d surface samples, over the %d cap — use a larger "
                         "pitch or a coarser mesh" % (pitch, int(est), _MAX_VOXEL_SAMPLES))
    occ = np.zeros(tuple(int(s) for s in shape), bool)
    hi_idx = shape - 1
    for nsub in np.unique(sub):
        sel = np.flatnonzero(sub == nsub)
        gi, gj = np.meshgrid(np.arange(nsub + 1), np.arange(nsub + 1), indexing="ij")
        keep = (gi + gj) <= nsub
        u = (gi[keep] / float(nsub))[None, :, None]
        v = (gj[keep] / float(nsub))[None, :, None]
        k = int(u.shape[1])
        step = max(1, _CHUNK // max(k, 1))
        for s0 in range(0, sel.shape[0], step):
            t = sel[s0:s0 + step]
            a, ab, ac = A[t][:, None, :], (B - A)[t][:, None, :], (C - A)[t][:, None, :]
            pts = (a + u * ab + v * ac).reshape(-1, 3)
            ijk = np.floor((pts - lo) / pitch).astype(np.int64)
            np.clip(ijk, 0, hi_idx, out=ijk)
            occ[ijk[:, 0], ijk[:, 1], ijk[:, 2]] = True
    return occ, lo.astype(np.float64)


def bounds(V):
    """Axis-aligned bounding box -> ``(min, max)``, each float64 (3,)."""
    P = _finite_points(V, "vertices", "bounds")
    if P.shape[0] == 0:
        raise ValueError("bounds needs at least one vertex")
    return P.min(axis=0), P.max(axis=0)


def recenter(V) -> np.ndarray:
    """Translate so the vertex centroid sits at the origin. Returns a new array."""
    P = _finite_points(V, "vertices", "recenter")
    if P.shape[0] == 0:
        return P
    return P - P.mean(axis=0)


def normalize_scale(V, size: float = 1.0) -> np.ndarray:
    """Scale about the origin so the largest bounding-box extent equals *size*.

    Pure scaling — combine with :func:`recenter` for the usual "centred unit
    model" normalisation (``normalize_scale(recenter(V))``). A degenerate mesh
    (all vertices coincident) has no extent to normalise and raises ``ValueError``.
    """
    P = _finite_points(V, "vertices", "normalize_scale")
    size = float(size)
    if size <= 0.0:
        raise ValueError("size must be > 0, got %r" % (size,))
    if P.shape[0] == 0:
        return P
    extent = float((P.max(axis=0) - P.min(axis=0)).max())
    if extent <= 0.0:
        raise ValueError("degenerate mesh: bounding-box extent is 0, nothing to scale")
    return P * (size / extent)
