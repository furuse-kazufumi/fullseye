"""Point-cloud segmentation, model fitting and spatial filtering (numpy + scipy).

The analysis layer above :mod:`pointcloud` (normals / downsample) and
:mod:`camera` (which builds the cloud from depth). Where :mod:`registration`
aligns a whole cloud to a known model, this module *carves a raw cloud up*: fit
the dominant plane and drop it (ground removal for locomotion), cluster what
remains into separate objects (the "which blob is a graspable thing" step),
bound each cluster with an oriented box, and fit primitive shapes (plane / sphere
/ cylinder) that stand in for pipes, balls and table-tops. These are the classic
robot-perception front-end operations a manipulator runs before it decides what
to pick up or where to step.

References (public literature — reimplemented, not derived from any product):
- Fischler & Bolles, "Random Sample Consensus", CACM 1981 (RANSAC).
- Rusu, "Semantic 3D Object Maps for Everyday Manipulation", PhD 2009 (Euclidean
  cluster extraction; cylinder model from point+normal samples).
- Rabbani et al., "Segmentation of point clouds using smoothness constraint",
  ISPRS 2006 (normal/curvature region growing).
- Pauly et al., "Efficient Simplification of Point-Sampled Surfaces", VIS 2002
  (surface variation as a curvature estimate).
- Eldar et al., "The farthest point strategy for progressive image sampling",
  ICPR 1994 (farthest-point sampling).
"""
from __future__ import annotations

import numpy as np

__all__ = [
    "fit_plane", "fit_plane_ransac", "fit_sphere_ransac", "fit_cylinder_ransac",
    "plane_distance", "height_above_plane", "remove_ground",
    "euclidean_clusters", "region_growing",
    "aabb", "obb", "crop_box", "crop_sphere", "farthest_point_sampling",
    "curvature", "centroid", "principal_axes",
]


def _pts3(a) -> np.ndarray:
    a = np.asarray(a, np.float64)
    if a.ndim != 2 or a.shape[1] != 3:
        raise ValueError("expected (N, 3) points, got shape %r" % (a.shape,))
    return a


#: Default minimum fraction of the cloud a RANSAC hypothesis must explain. This is a
#: WEAK, honest heuristic — NOT a proof of primitiveness. The inlier fraction a
#: non-primitive blob produces scales with cloud_extent / thresh, so this gate
#: reliably rejects a blob only when the cloud is LARGE relative to *thresh*
#: (empirically extent >= ~20-30x thresh). A COMPACT blob (extent ~10-15x thresh) can
#: still clear 10% with a plausible small radius — a scale-independent fraction cannot
#: separate it from a real small primitive (verified: a std-0.10 gaussian blob at
#: thresh=0.01 keeps ~16% of its points and fits a radius-~0.08 "sphere"). Callers who
#: may see compact non-primitive clouds must pass a stricter *min_inlier_frac* AND
#: validate the returned model's geometry (radius vs the known scene scale). A
#: fail-closed default that helps for well-scaled clouds, no more.
_DEFAULT_CONSENSUS_FRAC = 0.10


def _consensus_floor(n: int, k: int, min_inliers, min_inlier_frac) -> int:
    """Smallest inlier count a RANSAC hypothesis may have and still be called a model.

    The *k* samples that generate a hypothesis always fit it, so self-support is not
    consensus. The floor is the STRICTEST of: ``k + 1`` (more than self-support), a
    default fraction :data:`_DEFAULT_CONSENSUS_FRAC` of the cloud (a WEAK, scale-
    dependent blob reject — see that constant's note; it is not a guarantee), and any
    caller override via *min_inliers* (absolute) or *min_inlier_frac* (fraction). The
    gate can only ever tighten. A cloud of exactly ``k`` points can never clear the
    floor — ``k`` points are pure self-support, so the fit is ``None``. Non-finite
    overrides are rejected (fail-closed) rather than silently producing a broken gate."""
    floor = max(k + 1, int(np.ceil(_DEFAULT_CONSENSUS_FRAC * n)))
    if min_inliers is not None:
        if not np.isfinite(min_inliers):
            raise ValueError("min_inliers must be finite, got %r" % (min_inliers,))
        floor = max(floor, int(np.ceil(float(min_inliers))))      # ceil, so 10.9 -> 11, not 10
    if min_inlier_frac is not None:
        if not np.isfinite(min_inlier_frac):
            raise ValueError("min_inlier_frac must be finite, got %r" % (min_inlier_frac,))
        frac = min(max(float(min_inlier_frac), 0.0), 1.0)         # clamp: >1 would be unreachable
        floor = max(floor, int(np.ceil(frac * n)))
    return floor


# --- plane / primitive fitting ---------------------------------------------- #
def fit_plane(points) -> np.ndarray:
    """Total-least-squares plane through all points (PCA).

    Returns ``[a, b, c, d]`` with unit normal ``(a, b, c)`` and ``a*x+b*y+c*z+d=0``.
    Sensitive to outliers — use :func:`fit_plane_ransac` on real depth clouds."""
    P = _pts3(points)
    if P.shape[0] < 3:
        raise ValueError("need >= 3 points to fit a plane")
    c = P.mean(0)
    _, _, Vt = np.linalg.svd(P - c, full_matrices=False)  # full_matrices=False: U は捨てるのに (N,N) を確保していた(2026-09-06 実測 20000 点で 3.73 s / 3.2 GB → 0.88 ms、Vt はビット一致)
    n = Vt[-1]
    n = n / max(np.linalg.norm(n), 1e-12)
    return np.append(n, -n @ c)


def fit_plane_ransac(points, thresh: float = 0.01, iters: int = 200, seed: int = 0):
    """Robust dominant-plane fit by RANSAC (Fischler & Bolles 1981).

    Repeatedly fits a plane to 3 random points and counts inliers within
    *thresh* metric distance, then refits (TLS) to the best consensus set. Returns
    ``(plane [a,b,c,d], inliers boolean mask)``. The workhorse for table-top and
    ground-plane extraction."""
    P = _pts3(points)
    n = P.shape[0]
    if n < 3:
        raise ValueError("need >= 3 points")
    rng = np.random.default_rng(seed)
    best_inl, best_cnt = None, -1
    # ★2026-11-05(敵対的検証 G9): 縮退の床が単位²の絶対値だったので、座標が小さい点群(mm を m で渡す等)では全仮説を「縮退」として捨て、外れ値込みの当てはめに落ちていた。床は点群の尺度(重心からの二乗平均距離)に対する相対量にした。
    floor = 1e-12 * float(np.mean(np.sum((P - P.mean(0)) ** 2, axis=1)))
    for _ in range(int(iters)):
        i = rng.choice(n, 3, replace=False)
        nrm = np.cross(P[i[1]] - P[i[0]], P[i[2]] - P[i[0]])
        nn = np.linalg.norm(nrm)
        if nn <= floor:                            # 共線・一致(点群の尺度² に対する相対量)
            continue
        nrm = nrm / nn
        d = -nrm @ P[i[0]]
        inl = np.abs(P @ nrm + d) <= thresh
        cnt = int(inl.sum())
        if cnt > best_cnt:
            best_cnt, best_inl = cnt, inl
    if best_inl is None or best_cnt < 3:
        plane = fit_plane(P)                       # RANSAC found nothing -> plain TLS
        return plane, np.abs(P @ plane[:3] + plane[3]) <= thresh   # honest inlier mask
    plane = fit_plane(P[best_inl])
    inliers = np.abs(P @ plane[:3] + plane[3]) <= thresh
    return plane, inliers


def fit_sphere_ransac(points, thresh: float = 0.01, iters: int = 200, seed: int = 0,
                      min_inliers: int | None = None,
                      min_inlier_frac: float | None = None):
    """Robust sphere fit by RANSAC. Returns ``(center (3,), radius, inliers)``, or
    ``None`` when no hypothesis reaches the consensus gate.

    Each hypothesis solves the algebraic sphere through 4 random points (linear in
    ``[2x,2y,2z,1]`` against ``x^2+y^2+z^2``); the best consensus set is refit
    algebraically. Detects balls / spherical fittings for grasping.

    The 4 sampled points always lie on their own sphere, so *any* cloud would
    otherwise yield a confident-looking centre/radius backed by 4 points. A model is
    only returned once it clears :func:`_consensus_floor` — by default the larger of
    5 points and 10% of the cloud, tightened by *min_inliers* / *min_inlier_frac*.
    ``None`` is the single "no model" signal for BOTH no consensus and no valid
    hypothesis (coincident samples); only a precondition violation (``< 4`` points)
    raises. This REPLACES a prior ``ValueError`` (no-model paths now return ``None``).
    Honest limits (the default gate is WEAK, not a proof): (1) consensus does not
    bound the RADIUS — a near-flat patch fits as a huge-radius sphere; (2) the 10%
    default only rejects a blob when the cloud is large relative to *thresh* — a
    COMPACT non-primitive blob can still pass with a plausible small radius (see
    :data:`_DEFAULT_CONSENSUS_FRAC`). Sanity-check the returned radius against your
    scene scale, and pass a stricter *min_inlier_frac* for compact clouds."""
    P = _pts3(points)
    n = P.shape[0]
    if n < 4:
        raise ValueError("need >= 4 points")
    rng = np.random.default_rng(seed)

    def solve(Q):
        # ★2026-11-05(敵対的検証 G10): 重心に寄せずに代数球を解いていた(未中心化の |p|² は
        # 原点から遠い点群で桁落ちし、オフセット 1e7 で半径 0.70 → 0.68・内れ値 302 → 118)。
        # 2026-10-07 に ransac_fit._fit_sphere_ls で直した方法(重心へ寄せる+同一平面の
        # 4 点は球が定まらないので None)に揃えた。
        q0 = Q.mean(0)
        Q = Q - q0
        sv = np.linalg.svd(Q, compute_uv=False)
        if not np.all(np.isfinite(sv)) or sv[-1] <= 1e-9 * sv[0]:
            return None
        A = np.hstack([2 * Q, np.ones((Q.shape[0], 1))])
        b = (Q ** 2).sum(1)
        sol, *_ = np.linalg.lstsq(A, b, rcond=None)
        c = sol[:3]
        r2 = sol[3] + c @ c
        if not np.isfinite(r2) or r2 <= 0:
            return None
        return c + q0, np.sqrt(r2)

    best = None
    for _ in range(int(iters)):
        i = rng.choice(n, 4, replace=False)
        res = solve(P[i])
        if res is None:
            continue
        c, r = res
        inl = np.abs(np.linalg.norm(P - c, axis=1) - r) <= thresh
        cnt = int(inl.sum())
        if best is None or cnt > best[0]:
            best = (cnt, c, r, inl)
    floor = _consensus_floor(n, 4, min_inliers, min_inlier_frac)
    if best is None or best[0] < floor:
        return None                                # no consensus -> honest "no sphere"
    res = solve(P[best[3]])
    if res is not None:
        c, r = res
        inl = np.abs(np.linalg.norm(P - c, axis=1) - r) <= thresh
        if int(inl.sum()) >= floor:                # the refit must keep the consensus
            return c, float(r), inl
    return best[1], float(best[2]), best[3]


def fit_cylinder_ransac(points, normals=None, thresh: float = 0.01,
                        iters: int = 300, seed: int = 0,
                        min_inliers: int | None = None,
                        min_inlier_frac: float | None = None):
    """Robust cylinder fit by RANSAC from point+normal samples (Rusu 2009).

    Two surface points with their normals fix a candidate: the axis direction is
    ``n0 x n1`` and the radius/axis line follow from intersecting the two normals in
    the plane perpendicular to the axis. Returns
    ``(axis_point (3,), axis_dir (3, unit), radius, inliers)``, or ``None`` when no
    hypothesis reaches the consensus gate. Detects pipes, rods and (roughly) limbs —
    cylindrical things a gripper wraps around. If *normals* is None they are
    estimated from the cloud.

    A 2-sample hypothesis is self-supporting, so without a gate a random blob comes
    back as a confident axis/radius carried by ~2 points. A model is only returned
    once it clears :func:`_consensus_floor` — by default the larger of 3 points and
    10% of the cloud, tightened by *min_inliers* / *min_inlier_frac*. ``None`` is the
    single "no model" signal for BOTH no consensus and no valid hypothesis; only a
    precondition violation (``< 2`` points) raises (this REPLACES a prior
    ``ValueError``). Honest limits (the default gate is WEAK): (1) consensus does not
    bound the RADIUS — a flat sheet is a cylinder of near-infinite radius and clears
    the gate; (2) the 10% default only rejects a blob when the cloud is large relative
    to *thresh* — a COMPACT blob can still pass with a plausible radius (see
    :data:`_DEFAULT_CONSENSUS_FRAC`). Sanity-check the returned radius against your
    scene scale, and pass a stricter *min_inlier_frac* for compact clouds."""
    P = _pts3(points)
    n = P.shape[0]
    if n < 2:
        raise ValueError("need >= 2 points")
    if normals is None:
        from pointcloud import estimate_normals
        N = estimate_normals(P)
    else:
        N = np.asarray(normals, np.float64)
        if N.shape != P.shape:
            raise ValueError("normals must match points shape")
    rng = np.random.default_rng(seed)
    # 半径の床は点群の尺度に対する相対量(2026-11-05 敵対的検証 G9 の兄弟: 絶対値 1e-9 だった)
    r_floor = 1e-9 * float(np.sqrt(np.mean(np.sum((P - P.mean(0)) ** 2, axis=1))))

    def hypo(i, j):
        w = np.cross(N[i], N[j])
        wn = np.linalg.norm(w)
        if wn < 1e-9:
            return None
        w = w / wn
        # work in the plane perpendicular to the axis: drop the w-component
        def proj(v):
            return v - (v @ w) * w
        p0, p1 = proj(P[i]), proj(P[j])
        d0, d1 = proj(N[i]), proj(N[j])
        n0, n1 = np.linalg.norm(d0), np.linalg.norm(d1)
        if n0 < 1e-9 or n1 < 1e-9:
            return None
        d0, d1 = d0 / n0, d1 / n1
        # intersect lines p0 + s d0 and p1 + t d1 (least squares for skew safety)
        A = np.stack([d0, -d1], 1)
        st, *_ = np.linalg.lstsq(A, p1 - p0, rcond=None)
        c = p0 + st[0] * d0
        r = np.linalg.norm(p0 - c)
        if r <= r_floor:
            return None
        return c, w, r

    def axis_dist(c, w, r):
        rel = P - c
        perp = rel - (rel @ w)[:, None] * w
        return np.abs(np.linalg.norm(perp, axis=1) - r)

    best = None
    for _ in range(int(iters)):
        i, j = rng.choice(n, 2, replace=False)
        h = hypo(i, j)
        if h is None:
            continue
        c, w, r = h
        inl = axis_dist(c, w, r) <= thresh
        cnt = int(inl.sum())
        if best is None or cnt > best[0]:
            best = (cnt, c, w, r, inl)
    floor = _consensus_floor(n, 2, min_inliers, min_inlier_frac)
    if best is None or best[0] < floor:
        return None                                # no consensus -> honest "no cylinder"
    return best[1], best[2], float(best[3]), best[4]


# --- distances / ground removal --------------------------------------------- #
def plane_distance(points, plane) -> np.ndarray:
    """Signed distance of each point to a plane ``[a,b,c,d]`` (unit normal assumed)."""
    P = _pts3(points)
    pl = np.asarray(plane, np.float64).ravel()
    if pl.size != 4:
        raise ValueError("plane must be [a, b, c, d]")
    return P @ pl[:3] + pl[3]


def height_above_plane(points, plane) -> np.ndarray:
    """Height of each point above a plane = signed distance along the plane's own
    (given) normal. The **caller** controls which way is 'up' by the orientation of
    the plane normal — pass a plane whose normal points up (e.g. ``[0,0,1,d]`` for a
    floor) and clearance comes back positive. (This deliberately does *not* re-orient
    by a majority-of-points heuristic: that silently discarded the caller's chosen
    normal and flipped the sign depending on the sampling.) The cloud analogue of a
    terrain heightmap for foothold / clearance checks."""
    return plane_distance(points, plane)


def remove_ground(points, thresh: float = 0.02, iters: int = 200,
                  max_slope_deg: float = 45.0, seed: int = 0):
    """Split a cloud into ground and non-ground by RANSAC-fitting the dominant
    (near-horizontal) plane and dropping its inliers.

    Only accepts a plane whose normal is within *max_slope_deg* of vertical as
    "ground" (so a large wall is not mistaken for the floor). Returns
    ``(nonground_points, ground_mask)``. The first step of locomotion perception:
    what is walkable floor vs. what is an obstacle/object standing on it."""
    P = _pts3(points)
    plane, inl = fit_plane_ransac(P, thresh=thresh, iters=iters, seed=seed)
    vertical = abs(plane[2]) / max(np.linalg.norm(plane[:3]), 1e-12)
    if vertical < np.cos(np.radians(max_slope_deg)):
        # dominant plane is too steep to be ground -> nothing removed
        return P.copy(), np.zeros(P.shape[0], bool)
    return P[~inl], inl


# --- clustering / region growing -------------------------------------------- #
def euclidean_clusters(points, tol: float = 0.05, min_size: int = 10,
                       max_size: int | None = None, method: str = "exact"):
    """Euclidean cluster extraction (Rusu 2009): group points that are within
    *tol* of each other (transitively) into connected components.

    Returns a list of index arrays (largest first), each a candidate object once
    the ground/table has been removed. Clusters smaller than *min_size* (noise) or
    larger than *max_size* are dropped.

    ``method="exact"`` (the default) materializes all neighbour pairs and uses a
    sparse connected-components pass; this preserves the original implementation
    and its speed. ``method="low_memory"`` instead walks the same KD-tree graph by
    BFS, preserving cluster membership and ordering while avoiding the pair list.
    On a 200k-point random cloud, ``exact`` took 1.19 s with a 28.2 MiB tracemalloc
    peak, versus 5.33 s and 5.8 MiB for ``low_memory`` (4.5x slower, 20% of the
    peak). Choose ``low_memory`` when the pair list will not fit: for example,
    around 200k points under a sub-30 MiB temporary-memory budget, or at larger
    point counts / densities where the number of neighbour pairs grows rapidly.
    """
    from scipy.spatial import cKDTree

    P = _pts3(points)
    n = P.shape[0]
    if method not in ("exact", "low_memory"):
        raise ValueError("method must be 'exact' or 'low_memory'")
    if n == 0:
        return []
    tree = cKDTree(P)
    if method == "exact":
        from scipy.sparse import csr_matrix
        from scipy.sparse.csgraph import connected_components

        pairs = tree.query_pairs(r=float(tol), output_type="ndarray")
        if pairs.size == 0:
            rows = cols = np.zeros(0, int)
        else:
            rows = np.concatenate([pairs[:, 0], pairs[:, 1]])
            cols = np.concatenate([pairs[:, 1], pairs[:, 0]])
        graph = csr_matrix((np.ones(rows.size), (rows, cols)), shape=(n, n))
        ncomp, labels = connected_components(graph, directed=False)
        out = []
        for c in range(ncomp):
            idx = np.where(labels == c)[0]
            if idx.size < min_size:
                continue
            if max_size is not None and idx.size > max_size:
                continue
            out.append(idx)
        out.sort(key=lambda a: -a.size)
        return out

    from collections import deque

    labels = np.full(n, -1, dtype=int)
    component = 0
    radius = float(tol)
    for seed in range(n):
        if labels[seed] != -1:
            continue
        labels[seed] = component
        queue = deque([seed])
        while queue:
            point = queue.popleft()
            for neighbour in tree.query_ball_point(P[point], r=radius):
                if labels[neighbour] == -1:
                    labels[neighbour] = component
                    queue.append(neighbour)
        component += 1
    sizes = np.bincount(labels, minlength=component)
    keep = ((sizes >= int(min_size))
            & ((max_size is None) | (sizes <= (n if max_size is None else int(max_size)))))
    order = np.argsort(labels, kind="stable")
    starts = np.r_[0, np.cumsum(sizes)]
    components = [c for c in range(component) if keep[c]]
    components.sort(key=lambda c: -sizes[c])
    return [order[starts[c]:starts[c + 1]] for c in components]


def region_growing(points, normals=None, angle_deg: float = 15.0,
                   curv_thresh: float = 0.1, k: int = 16):
    """Smoothness-constraint region growing (Rabbani 2006).

    Grows regions from low-curvature seeds. A neighbour is labelled when its normal is
    within *angle_deg* of the current point's; it is expanded further only when its
    curvature is below *curv_thresh*. Segments a cloud into smooth surface patches — e.g. separating
    the several faces of a box, or floor vs. ramp. Returns integer labels (N,) in
    ``[0, n_regions)``; every point is assigned (a high-curvature/isolated point no
    region grows into becomes its own singleton region, so rough areas fragment —
    filter by region size downstream if that matters). If *normals* is None they are
    estimated."""
    from scipy.spatial import cKDTree

    P = _pts3(points)
    n = P.shape[0]
    if n == 0:
        return np.zeros(0, int)
    if normals is None:
        from pointcloud import estimate_normals
        N = estimate_normals(P, k=k)
    else:
        N = np.asarray(normals, np.float64)
    curv = curvature(P, k=k)
    cos_thr = np.cos(np.radians(angle_deg))
    kk = int(min(k + 1, n))
    _, idx = cKDTree(P).query(P, k=kk)
    if idx.ndim == 1:
        idx = idx.reshape(n, 1)
    labels = np.full(n, -1, int)
    order = np.argsort(curv)                       # grow from flattest points first
    cur = 0
    for seed in order:
        if labels[seed] != -1:
            continue
        labels[seed] = cur
        stack = [seed]
        while stack:
            p = stack.pop()
            for q in idx[p, 1:]:
                if labels[q] != -1:
                    continue
                if abs(N[p] @ N[q]) < cos_thr:
                    continue
                labels[q] = cur
                if curv[q] < curv_thresh:
                    stack.append(q)
        cur += 1
    return labels


# --- bounding volumes / sampling / filtering -------------------------------- #
def aabb(points):
    """Axis-aligned bounding box. Returns ``(min (3,), max (3,))``.

    点群の各軸の最小値と最大値をそのまま返す(``P.min(0)``, ``P.max(0)``)。返り値は 2 つの (3,)
    float64 配列で、順に ``(xmin, ymin, zmin)`` と ``(xmax, ymax, zmax)``(軸の並びは入力の列順)。
    箱の大きさは ``max - min``、中心は ``(min + max) / 2``。単位は座標の単位。

    - ``points``: (N,3) 以外の形状は ``ValueError``、空の点群も ``ValueError``(fail-closed)。
    - NaN を含む点があると ``min`` / ``max`` が NaN になる(非有限の検査はしない)。

    用途: voxel 化(``occupancy_grid`` / ``points_to_voxel`` の ``bounds``)の領域決め、
    ``obb``(PCA で向きを合わせた箱)との比較。軸に沿わない細長い物体では AABB は大きく余るので、
    把持幅の推定には ``obb`` の ``extents`` を使う。
    """
    P = _pts3(points)
    if P.shape[0] == 0:
        raise ValueError("empty cloud")
    return P.min(0), P.max(0)


def obb(points) -> dict:
    """Oriented bounding box by PCA.

    Returns ``{center, axes (3,3 columns = box axes), extents (3, half-widths),
    corners (8,3)}``. The tight-fitting box a manipulator uses to reason about an
    object's size and grasp width once it has been segmented out.

    手順: 重心 ``c`` を引いた点群の SVD(``full_matrices=False``)で主軸 ``axes``(列 = 特異値の降順、
    第 1 列が最も広がる方向)を取り、点を主軸座標に写して各軸の min/max から半幅 ``extents`` と
    箱中心 ``center``(重心とは一般に異なる)を求める。``corners`` は ``center + (±extents) @ axes.T``
    の 8 点で、符号の組合せは ``meshgrid([-1,1],[-1,1],[-1,1])`` の順。

    - ``points``: (N,3) 以外は ``ValueError``、2 点未満も ``ValueError``。
    - PCA の主軸は「最小体積の箱」を保証しない(点の分布に沿うだけ)。主軸の符号は SVD の任意性で
      決まり、点の分布が等方に近い(特異値が縮退する)と軸の向きは不安定になる。
    - ``extents`` は半幅なので辺長は ``2 * extents``。単位は座標の単位。
    """
    P = _pts3(points)
    if P.shape[0] < 2:
        raise ValueError("need >= 2 points")
    c = P.mean(0)
    # ★ ``full_matrices=True``(既定)は (N, N) の U を確保して**捨てる**。
    # 2026-09-06 実測: 20000 点で 3.73 s / 3.2 GB、``full_matrices=False`` なら
    # 0.876 ms(**4263 倍**)で Vt はビット一致。10 万点なら 80 GB で落ちる。
    # 同型が pcseg.fit_plane / measure / ops / camera / pnp3d にもあった
    # (すべて U を捨てている)。静的な門は tests/test_svd_full_matrices.py。
    _, _, Vt = np.linalg.svd(P - c, full_matrices=False)
    axes = Vt.T                                    # columns are principal directions
    local = (P - c) @ axes
    lo, hi = local.min(0), local.max(0)
    extents = (hi - lo) / 2.0
    center = c + axes @ ((hi + lo) / 2.0)
    signs = np.array(np.meshgrid([-1, 1], [-1, 1], [-1, 1])).T.reshape(-1, 3)
    corners = center + (signs * extents) @ axes.T
    return {"center": center, "axes": axes, "extents": extents, "corners": corners}


def crop_box(points, lo, hi):
    """Keep points inside the axis-aligned box ``[lo, hi]``. Returns
    ``(kept_points, mask)`` — a "passthrough"/region-of-interest crop of the cloud."""
    P = _pts3(points)
    lo = np.asarray(lo, np.float64).ravel()
    hi = np.asarray(hi, np.float64).ravel()
    if lo.size != 3 or hi.size != 3:
        raise ValueError("lo/hi must be length-3")
    mask = np.all((P >= lo) & (P <= hi), axis=1)
    return P[mask], mask


def crop_sphere(points, center, radius: float):
    """Keep points within *radius* of *center*. Returns ``(kept_points, mask)``."""
    P = _pts3(points)
    c = np.asarray(center, np.float64).ravel()
    if c.size != 3:
        raise ValueError("center must be length-3")
    mask = np.linalg.norm(P - c, axis=1) <= float(radius)
    return P[mask], mask


def farthest_point_sampling(points, k: int, seed: int = 0) -> np.ndarray:
    """Farthest-point sampling (Eldar 1994): pick *k* points that spread out to
    cover the cloud, each maximally far from those already chosen.

    Returns the chosen indices (k,). Gives an even, geometry-aware thinning (unlike
    voxel downsampling it keeps a fixed count and preserves extremes) — the standard
    front-end for point-based recognition."""
    P = _pts3(points)
    n = P.shape[0]
    k = int(k)
    if k <= 0:
        raise ValueError("k must be > 0")
    if k >= n:
        return np.arange(n)
    # Squaring a coordinate difference above this limit may overflow. Preserve
    # the former norm path (and therefore all of its tie rounding) in that case.
    finite = np.abs(P[np.isfinite(P)])
    if finite.size and finite.max() > np.sqrt(np.finfo(np.float64).max) / 2.0:
        return _farthest_point_sampling_norm(P, k, seed)
    rng = np.random.default_rng(seed)
    chosen = np.empty(k, int)
    chosen[0] = rng.integers(n)
    delta = P - P[chosen[0]]
    d = np.einsum("ij,ij->i", delta, delta)
    d = np.nan_to_num(d, nan=-1.0)
    d[chosen[0]] = -1.0
    for i in range(1, k):
        maximum = d.max()
        near = np.flatnonzero(d >= maximum - np.spacing(maximum))
        if near.size > 1:
            j = int(near[np.argmax(np.sqrt(d[near]))])
        else:
            j = int(np.argmax(d))
        chosen[i] = j
        delta = P - P[j]
        update = np.nan_to_num(np.einsum("ij,ij->i", delta, delta), nan=-1.0)
        np.minimum(d, update, out=d)
        d[j] = -1.0
    return chosen


def _farthest_point_sampling_norm(P, k, seed):
    """Overflow-safe preservation of the original norm-based implementation."""
    n = P.shape[0]
    rng = np.random.default_rng(seed)
    chosen = np.empty(k, int)
    chosen[0] = rng.integers(n)
    d = np.nan_to_num(np.linalg.norm(P - P[chosen[0]], axis=1), nan=-1.0)
    d[chosen[0]] = -1.0
    for i in range(1, k):
        j = int(np.argmax(d))
        chosen[i] = j
        update = np.nan_to_num(np.linalg.norm(P - P[j], axis=1), nan=-1.0)
        np.minimum(d, update, out=d)
        d[j] = -1.0
    return chosen


def curvature(points, k: int = 16) -> np.ndarray:
    """Per-point surface variation ``lambda0 / (lambda0+lambda1+lambda2)`` over the
    ``k`` nearest neighbours (Pauly 2002) — a curvature estimate in [0, 1/3].

    ~0 on a flat patch, larger on edges/corners/bumps. Feeds region growing and
    marks graspable rims / terrain steps. Returns (N,)."""
    from scipy.spatial import cKDTree

    P = _pts3(points)
    n = P.shape[0]
    if n == 0:
        return np.zeros(0)
    kk = int(min(max(3, k), n))
    _, idx = cKDTree(P).query(P, k=kk)
    if idx.ndim == 1:
        idx = idx.reshape(n, 1)
    nb = P[idx]
    c = nb - nb.mean(1, keepdims=True)
    cov = np.einsum("nki,nkj->nij", c, c)
    ev = np.linalg.eigvalsh(cov)                   # ascending
    tot = ev.sum(1)
    # ★1.0 前の修正 2026-11-05 abs-floor: 以前は ``tot > 1e-12`` の絶対の床。tot は長さ² なので、座標 1e-6 の点群では
    #   全点の曲率が 0 になった。床は点群の座標の大きさ² に対する相対量(丸め屑だけを落とす)。
    floor = (1e-12 * float(np.abs(P).max())) ** 2
    ok = tot > floor
    return np.where(ok, ev[:, 0] / np.where(ok, tot, 1.0), 0.0)


def centroid(points) -> np.ndarray:
    """Mean position of the cloud (3,)."""
    return _pts3(points).mean(0)


def principal_axes(points):
    """PCA of the cloud. Returns ``(eigvals (3, descending), eigvecs (3,3 columns))``
    — the object's principal directions and their spread, e.g. for coarse pose."""
    P = _pts3(points)
    if P.shape[0] < 2:
        raise ValueError("need >= 2 points")
    cov = np.cov((P - P.mean(0)).T)
    w, V = np.linalg.eigh(cov)
    order = np.argsort(w)[::-1]
    return w[order], V[:, order]
