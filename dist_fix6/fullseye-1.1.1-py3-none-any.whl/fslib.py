"""L1 — the Fullseye library the language calls (typed model + selectable backends).

This is the de-risking seed for the architecture decided in ``docs/FSCRIPT_DECISION.md``.
It exists to prove three claims *before* the rest of the plan is built on them:

1. **The sort and the value range are carried, not guessed.**  ``FImage`` holds its
   own ``value_range``, so a threshold means the same thing regardless of what
   else happens to be in the frame.  (The current ``fscript._norm01`` divides by
   the image maximum, so one specular highlight silently changes the judgement —
   measured in ``docs/FSCRIPT_MEASUREMENTS.md`` section 7, defect 2.)
2. **One operator, several backends.**  ``gauss`` is one operator whose numpy and
   OpenCV implementations are interchangeable, selected by *profile* — not two
   differently-named ops as the registry has today.
3. **The numpy implementation is the oracle.**  A native backend is only allowed
   into the ``industrial`` profile once a differential test shows it agrees with
   numpy on real inputs (``tests/test_fslib.py``).

Nothing here imports the 650-op registry: the industrial profile must stay small
and cheap to start (cold start is a measured requirement, not a preference).
"""
from __future__ import annotations

import contextlib
import threading
from dataclasses import dataclass, field, replace
from typing import Callable

import numpy as np
from scipy import ndimage as ndi

__all__ = [
    "FImage", "Region", "ObjectSet", "Seq", "Scalar", "SORTS", "sort_of",
    "FsValueError", "FsTypeError", "FsBackendError",
    "profile", "current_profile", "backends_for", "op",
    "unmet_ops", "readiness_report", "require_ready",
    "gauss", "threshold", "connection", "connection_opts", "region_features", "select_shape", "measure_all",
]


class FsValueError(ValueError):
    """`FS_E_INVALID_ARG` —— 引数が宣言された定義域の外。

    ★2026-09-14: これが無かった。`fullseye_abi.h` は status を **10 種**宣言して
    いるのに `fslib` の例外は 2 つ(`FsTypeError` → `FS_E_TYPE` /
    `FsBackendError` → `FS_E_NO_BACKEND`)しか無く、**種の違う失敗が同じ穴に
    落ちていた**。実際この日に直した `threshold(lo>hi)` と
    `select_shape(vmin>vmax)` は、契約では「引数が定義域の外」=
    `FS_E_INVALID_ARG` なのに `FsTypeError` を投げていた —— Rust 実装は 1 を返し
    Python は 2 相当を投げる、という**状態コードの食い違い**になる。
    差分テストが「どちらも拒否した」までしか見ていなかったので素通りしていた
    ([[feedback_observe_what_the_contract_declares]])。

    `TypeError` ではなく `ValueError` を継承するのは、Python 側の呼び手にとっても
    「型が違う」と「値が範囲外」は別の失敗だから。
    """


class FsTypeError(TypeError):
    """A value was used where the language's type model forbids it."""


class FsBackendError(RuntimeError):
    """No backend satisfies the active profile for this operator."""


# --------------------------------------------------------------------------- #
# Typed iconic model
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Region:
    """A binary point set.  Distinct from an image *by type*, never by content.

    **The storage is not part of the API** (`fullseye_abi.h` R-2).  Today it is a
    dense mask; HALCON stores regions as row runs, which makes region algebra
    O(runs) instead of O(pixels) and matters as soon as a recipe works on many
    small ROIs.  Keeping `_mask` private is what allows that swap later without
    touching a single caller — so callers get `area()` / `run_count()` /
    `runs()`, which are exactly the accessors the C ABI exposes.
    """

    _mask: np.ndarray

    def __post_init__(self):
        m = np.asarray(self._mask)
        if m.ndim != 2:
            raise FsTypeError("Region must be 2-D, got %dD" % m.ndim)
        if m.dtype != bool:
            object.__setattr__(self, "_mask", m.astype(bool))

    @property
    def shape(self):
        return self._mask.shape

    def area(self) -> int:
        """fs_region_area"""
        return int(np.count_nonzero(self._mask))

    def run_count(self) -> int:
        """fs_region_run_count — how many row runs this region encodes to."""
        return int(self.runs().shape[0])

    def runs(self) -> np.ndarray:
        """fs_region_runs — (N, 3) int32 array of (row, col_begin, col_end).

        The representation-independent view.  A native run-length region returns
        the same array without materialising anything.
        """
        m = self._mask
        rows, cols = np.nonzero(m)
        if rows.size == 0:
            return np.zeros((0, 3), dtype=np.int32)
        # a run breaks where the row changes or the column is not contiguous
        brk = np.empty(rows.size, dtype=bool)
        brk[0] = True
        brk[1:] = (rows[1:] != rows[:-1]) | (cols[1:] != cols[:-1] + 1)
        begin = np.flatnonzero(brk)
        end = np.append(begin[1:], rows.size) - 1
        return np.stack([rows[begin], cols[begin], cols[end] + 1], axis=1).astype(np.int32)

    @property
    def sort(self) -> str:
        return "region"

    def __bool__(self):
        # Defect 4: `if (Region)` silently meant `.any()`.  Iconic values are not
        # truthy — the language must force an explicit predicate.
        raise FsTypeError(
            "a Region has no truth value; write `|Objects| > 0` or `area(R) > 0`")


@dataclass(frozen=True)
class FImage:
    """Pixels + the declared value range + the processing domain (HALCON model).

    ``value_range`` is the contract that makes a threshold mean the same thing on
    every frame.  It is declared once at acquisition, never re-derived from the
    pixels.
    """

    pixels: np.ndarray
    value_range: tuple[float, float] = (0.0, 1.0)
    domain: Region | None = None          # None = full frame

    def __post_init__(self):
        p = np.asarray(self.pixels)
        if p.ndim != 2:
            raise FsTypeError("FImage must be 2-D (single channel), got %dD" % p.ndim)
        object.__setattr__(self, "pixels", p)
        lo, hi = self.value_range
        if not (hi > lo):
            raise FsTypeError("value_range must be increasing, got %r" % (self.value_range,))
        if self.domain is not None and self.domain.shape != p.shape:
            raise FsTypeError("domain shape %r does not match pixels %r"
                              % (self.domain.shape, p.shape))

    @property
    def shape(self):
        return self.pixels.shape

    @classmethod
    def from_u8(cls, a) -> "FImage":
        """8-bit acquisition — the range is 0..255 because the *sensor* says so."""
        return cls(np.asarray(a, dtype=np.uint8), value_range=(0.0, 255.0))

    @classmethod
    def from_unit_float(cls, a) -> "FImage":
        return cls(np.asarray(a, dtype=np.float32), value_range=(0.0, 1.0))

    def absolute(self, relative: float) -> float:
        """Map a 0..1 relative threshold onto this image's declared range."""
        lo, hi = self.value_range
        return lo + relative * (hi - lo)

    def with_pixels(self, pixels) -> "FImage":
        return replace(self, pixels=pixels)

    @property
    def sort(self) -> str:
        """The value's sort, carried by the type (never inferred)."""
        return "image"

    def __bool__(self):
        raise FsTypeError("an FImage has no truth value; compare a measurement instead")


@dataclass(frozen=True)
class ObjectSet:
    """A label image plus the ids that are live — masks are never materialised.

    Replaces ``connection`` returning one full-frame mask per blob, which was
    measured at 5.8x slower and 10.2x more peak memory
    (``docs/FSCRIPT_MEASUREMENTS.md`` section 0).

    **Features travel with the set.**  Measuring the whole label image is one
    pass; an API that recomputes it per query turns a 10 ms cycle into a 40 ms
    one (measured while building this PoC).  ``feats`` maps a feature name to a
    value per *label id* — indexed by id, so ``select`` is a pure id filter and
    costs nothing.
    """

    labels: np.ndarray                    # int32 label image, 0 = background
    ids: np.ndarray = field(default=None)  # 1-D int array of live labels
    feats: dict = field(default=None, compare=False)   # name -> value per id

    def __post_init__(self):
        if self.ids is None:
            object.__setattr__(self, "ids", np.unique(self.labels)[1:].astype(np.int32))
        if self.feats is None:
            object.__setattr__(self, "feats", {})

    def __len__(self):
        return int(self.ids.size)

    def feature(self, name: str) -> np.ndarray:
        """Values of ``name`` for the live ids, computing once if needed."""
        table = self.feats.get(name)
        if table is None:
            for k, v in _measure_all(self).items():
                self.feats.setdefault(k, v)
            table = self.feats[name]
        return table[self.ids]           # table is indexed by label id

    def region(self, i: int) -> Region:
        """Materialise one object on demand (the only place a mask is built)."""
        if not (0 <= i < len(self)):
            raise IndexError("object %d out of range 0..%d" % (i, len(self) - 1))
        return Region(self.labels == self.ids[i])

    def select(self, keep) -> "ObjectSet":
        """Filter ids — the label image and the measured features are shared."""
        return ObjectSet(self.labels, np.asarray(self.ids)[np.asarray(keep)], self.feats)

    @property
    def sort(self) -> str:
        return "objectset"

    def __bool__(self):
        raise FsTypeError("an ObjectSet has no truth value; write `|Objects| > 0`")


# --------------------------------------------------------------------------- #
# Typed control values — the general tier's sorts, carried by the type.
#
# These complete the type model: alongside the iconic FImage/Region/ObjectSet,
# ``Seq`` (a 1-D real sequence) and ``Scalar`` (one real) are the CONTROL values
# the general-algorithm tier (``algo.py``) and future numeric ops operate on. They
# follow the same discipline as the iconic types — the sort is carried by the type,
# the storage is private, values are immutable, and there is no implicit truth
# value — so "the sort is carried, not guessed" holds for every value in Fullseye.
#
# ABI mapping (fullseye_abi.h): ``Seq`` is the Python reflection of a homogeneous
# FS_ELEM_REAL ``fs_tuple`` (a typed real array crossing the boundary, R-4);
# ``Scalar`` is a single ``double``. No new ABI operator is introduced.
# --------------------------------------------------------------------------- #
@dataclass(frozen=True, eq=False)
class Seq:
    """A 1-D sequence of IEEE-754 float64 values (the ``seq`` sort).

    Storage is a private, **copied and write-protected** float64 array — building a
    Seq from a numpy array does not alias it, so the value is genuinely immutable
    even if the caller keeps and mutates the original. Has ``__len__``/iteration/
    indexing (all unambiguous) and value ``==``/``hash`` (by content), but NO boolean
    value — write ``len(seq) > 0``, never ``if seq`` — matching the iconic types'
    no-implicit-truthiness rule. Strings / non-numeric inputs are rejected with
    ``FsTypeError`` (a str is not a number; the sort is carried, not inferred).

    Values may be non-finite (NaN/inf) — a Seq is a general numeric container. The
    general-algorithm tier (``algo.py``) is the layer that assumes finite input and
    enforces it (its difftest is fail-closed on non-finite); the container does not
    silently drop or reject NaN so a legitimate inf is not lost.
    """

    _values: np.ndarray

    def __post_init__(self):
        arr = np.asarray(self._values)
        if arr.dtype.kind in ("U", "S", "O"):          # strings / python objects
            raise FsTypeError("Seq holds real numbers, not %s values" % arr.dtype)
        try:
            v = np.array(arr, dtype=np.float64)        # np.array COPIES (never aliases)
        except (TypeError, ValueError) as e:
            raise FsTypeError("Seq values must be real numbers: %s" % e) from e
        if v.ndim != 1:
            raise FsTypeError("Seq must be 1-D, got %dD" % v.ndim)
        v.setflags(write=False)                        # storage is truly immutable
        object.__setattr__(self, "_values", v)

    @classmethod
    def of(cls, values) -> "Seq":
        """Build a Seq from a 1-D iterable of numbers. A 2-D array or nested list is
        rejected (``FsTypeError``) rather than silently flattened; strings too."""
        return cls(values if isinstance(values, np.ndarray) else list(values))

    @property
    def sort(self) -> str:
        return "seq"

    def length(self) -> int:
        """fs_tuple_length"""
        return int(self._values.size)

    def values(self) -> np.ndarray:
        """A writable COPY of the underlying float64 array (storage stays private)."""
        return self._values.copy()

    def real(self, i: int) -> float:
        """fs_tuple_get_real — the i-th element as a double."""
        return float(self._values[i])

    def tolist(self) -> list:
        return self._values.tolist()

    def __len__(self) -> int:
        return int(self._values.size)

    def __iter__(self):
        return iter(self._values.tolist())

    def __getitem__(self, i):
        return float(self._values[i])

    def __eq__(self, other) -> bool:
        # content equality (a numpy field would make the dataclass __eq__ raise on
        # ambiguous array truth, hence eq=False + this explicit bool-returning form)
        if not isinstance(other, Seq):
            return NotImplemented
        return bool(np.array_equal(self._values, other._values))

    def __hash__(self) -> int:
        return hash(self._values.tobytes())            # valid: storage is write-protected

    def __bool__(self):
        raise FsTypeError("a Seq has no truth value; write `len(seq) > 0`")


@dataclass(frozen=True)
class Scalar:
    """A single float64 value (the ``scalar`` sort).

    ``float(scalar)`` converts explicitly and unambiguously and ``==``/``hash`` are
    by value; there is deliberately NO boolean value (write ``s.value() > 0``), so
    ``Scalar(0.0)`` can never be mistaken for "empty/false" the way a bare float
    would. May hold a non-finite value (NaN/inf); consumers that require finiteness
    enforce it (see ``algo.py``).
    """

    _value: float

    def __post_init__(self):
        object.__setattr__(self, "_value", float(self._value))

    @classmethod
    def of(cls, x) -> "Scalar":
        return cls(float(x))

    @property
    def sort(self) -> str:
        return "scalar"

    def value(self) -> float:
        return self._value

    def __float__(self) -> float:
        return self._value

    def __bool__(self):
        raise FsTypeError("a Scalar has no truth value; write `s.value() > 0` or `float(s) != 0`")


#: The full sort vocabulary of the Fullseye type model (iconic + control).
SORTS = ("image", "region", "objectset", "seq", "scalar")


def sort_of(value) -> str:
    """The sort of a Fullseye value, carried by its type (fail-closed on unknown).

    One place that knows every value's sort — so a caller never infers a sort from
    an array's shape/content. Raises ``FsTypeError`` for anything not a Fullseye
    typed value (e.g. a bare numpy array, whose sort is genuinely unknown).
    """
    if isinstance(value, FImage):
        return "image"
    if isinstance(value, Region):
        return "region"
    if isinstance(value, ObjectSet):
        return "objectset"
    if isinstance(value, Seq):
        return "seq"
    if isinstance(value, Scalar):
        return "scalar"
    raise FsTypeError(
        "value of type %s has no Fullseye sort — the sort is carried by the type, "
        "not inferred from a bare array" % type(value).__name__)


# --------------------------------------------------------------------------- #
# Profiles and backend selection
# --------------------------------------------------------------------------- #
#: Ordered backend preference per profile.
#:
#: **What the designer sees must be what ships.**  If the Studio ran the numpy
#: reference while the line ran the native kernel, a recipe tuned near a decision
#: boundary could flip on deployment — and manufacturing does not accept "we
#: shipped a migration tool", it asks for proof that the judgement is unchanged.
#: So "studio" prefers the *same* native backend the line will use, and falls back
#: to numpy only where no native kernel exists yet.
#:
#: The numpy implementation's job is to be the **oracle in tests** (profile
#: "reference"), not the designer's default.
PROFILES = {
    "studio": ("cv2", "numpy"),
    "industrial": ("cv2",),      # fail-closed: never degrade silently on the line
    "reference": ("numpy",),     # the oracle — differential tests only
}

_state = threading.local()


def current_profile() -> str:
    return getattr(_state, "profile", "studio")


@contextlib.contextmanager
def profile(name: str):
    if name not in PROFILES:
        raise FsBackendError("unknown profile %r (have: %s)" % (name, ", ".join(PROFILES)))
    prev = current_profile()
    _state.profile = name
    try:
        yield
    finally:
        _state.profile = prev


_REGISTRY: dict[str, dict[str, Callable]] = {}


def op(name: str, backend: str):
    """Register one implementation of one operator."""
    def deco(fn):
        _REGISTRY.setdefault(name, {})[backend] = fn
        return fn
    return deco


def backends_for(name: str) -> list[str]:
    """Which backends are registered *and* importable right now."""
    out = []
    for b in _REGISTRY.get(name, {}):
        if b == "cv2" and not _have_cv2():
            continue
        out.append(b)
    return out


def _have_cv2() -> bool:
    try:
        import cv2  # noqa: F401
        return True
    except Exception:
        return False


def _dispatch(name: str, *args, **kw):
    impls = _REGISTRY.get(name)
    if not impls:
        raise FsBackendError("no operator %r" % name)
    available = backends_for(name)
    for b in PROFILES[current_profile()]:
        if b in available:
            return impls[b](*args, **kw)
    raise FsBackendError(
        "operator %r has no backend for profile %r (registered: %s, available: %s). "
        "The industrial profile refuses to fall back silently — a recipe that needs "
        "this operator cannot be deployed until a native backend passes its "
        "differential test." % (name, current_profile(),
                                ", ".join(_REGISTRY[name]), ", ".join(available) or "none"))


# --------------------------------------------------------------------------- #
# Load-time self-check — the answer to the registry's fail-open hazard.
#
# The 650-op evolution registry (``backends._safe``) swallows an op failure and
# returns a benign value of the declared sort, so on a line a missing dependency
# would silently report "no defects" (docs/FSCRIPT_DECISION.md 1.6b).  fslib's
# dispatch already fails *closed at run time*; this adds the stronger guarantee
# the decision doc requires (R-1 / R-4): a runtime must verify, *before it
# becomes READY*, that every operator a recipe uses has a WORKING backend — not
# merely that the name is registered.  Name existence is not availability.
# --------------------------------------------------------------------------- #
def _profile_prefs(profile_name: str) -> tuple[str, ...]:
    if profile_name not in PROFILES:
        raise FsBackendError("unknown profile %r (have: %s)"
                             % (profile_name, ", ".join(PROFILES)))
    return PROFILES[profile_name]


def unmet_ops(op_names, profile_name: str = "industrial") -> list[str]:
    """Operators from ``op_names`` that have NO backend satisfying ``profile_name``.

    An operator is *unmet* if it is unregistered, or if none of its registered
    backends is importable under the profile's preference list.  An empty result
    means every operator would dispatch to a real implementation.
    """
    prefs = _profile_prefs(profile_name)
    missing = []
    for name in op_names:
        if name not in _REGISTRY:
            missing.append(name)
            continue
        available = backends_for(name)
        if not any(b in available for b in prefs):
            missing.append(name)
    return missing


def readiness_report(op_names, profile_name: str = "industrial") -> dict:
    """Per-operator readiness for diagnostics.

    Maps each operator name to the backend it *would* dispatch to under the
    profile, or ``None`` when nothing satisfies it (i.e. it is unmet).
    """
    prefs = _profile_prefs(profile_name)
    report = {}
    for name in op_names:
        available = backends_for(name) if name in _REGISTRY else []
        report[name] = next((b for b in prefs if b in available), None)
    return report


def require_ready(op_names, profile_name: str = "industrial") -> None:
    """Load-time gate: refuse READY unless every operator has a working backend.

    Raises ``FsBackendError`` (never degrades) listing every unmet operator, so a
    runtime started against a machine missing a dependency stops at load rather
    than silently judging every part OK.
    """
    missing = unmet_ops(op_names, profile_name)
    if missing:
        raise FsBackendError(
            "recipe is not ready under profile %r: %d operator(s) have no working "
            "backend: %s. The runtime refuses to start rather than run a pipeline "
            "that would silently degrade." % (profile_name, len(missing),
                                              ", ".join(sorted(missing))))


# --------------------------------------------------------------------------- #
# Operators — numpy is always the oracle, cv2 is the native backend
# --------------------------------------------------------------------------- #
@op("gauss", "numpy")
def _gauss_numpy(img: FImage, sigma: float) -> FImage:
    return img.with_pixels(
        ndi.gaussian_filter(img.pixels.astype(np.float32), float(sigma)))


@op("gauss", "cv2")
def _gauss_cv2(img: FImage, sigma: float) -> FImage:
    import cv2
    # ★2026-09-14: ここは長らく borderType 既定 = ``BORDER_REFLECT_101``
    #   (``d c b | a b c d`` — 境界の画素を重複させない折り返し)だった。numpy backend の
    #   ``ndi.gaussian_filter`` の既定は ``mode='reflect'`` = ``d c b a | a b c d``
    #   (境界の**上**で折り返す)で、**同じ「reflect」という語が別物を指す**。
    #   実測(512x512, sigma=1.0, 乱数): 内部は 4.6e-08 まで一致するのに、**端の画素だけ
    #   最大 0.13 = 値域の 13% ずれていた**。内部しか見ない検査では原理的に出ない。
    #   ``connection`` の 4/8 連結と同じクラスの欠陥(兄弟コードを一掃した 2 件目)。
    #   契約は numpy 側(既存の進化レシピのオラクル)に合わせて ``BORDER_REFLECT``。
    return img.with_pixels(cv2.GaussianBlur(img.pixels, (0, 0), float(sigma),
                                            borderType=cv2.BORDER_REFLECT))


@op("threshold", "numpy")
def _threshold_numpy(img: FImage, lo: float, hi: float) -> Region:
    a = img.pixels
    return Region((a >= img.absolute(lo)) & (a <= img.absolute(hi)))


@op("threshold", "cv2")
def _threshold_cv2(img: FImage, lo: float, hi: float) -> Region:
    a = img.pixels
    return Region((a >= img.absolute(lo)) & (a <= img.absolute(hi)))


def _order_ids(lbl: np.ndarray, k: int) -> np.ndarray:
    """ラベル id を**契約の並び**に置き換える: 最初の run の (row, col) 昇順。

    ★2026-09-14: ここが無かった。`ndi.label` も `cv2.connectedComponentsWithStats` も
    **自分の走査順でラベル番号を振る**のであって、`fullseye_abi.h` が
    `fs_connection` に定めた「最初の run の (row, col) 昇順」とは一致しない。
    実測の反例(2x5、値域 (-1,1)、しきい値 [-0.520, -0.139]):

        マスク  [[0 0 0 1 0]
                 [0 1 0 1 0]]

    物体は (row=0, col=3) 面積 2 と (row=1, col=1) 面積 1。契約の昇順なら前者が先だが、
    `fslib` は後者を 0 番目に返していた。**呼び手が添字で引く以上、並びが違えば
    指す物体が変わる** —— 「面積が最大の不良を 1 番目に」といったレシピが、
    実装を差し替えた途端に別の物体を指す。差分ファジングの観測に「並び」を足した
    瞬間に 3 シードすべてで出た(それまで 60,000 ケース撒いて 0 件だったのは、
    **並びを観測していなかった**から)。
    """
    if k <= 0:
        return np.zeros(0, dtype=np.int32)
    ids = np.arange(1, k + 1, dtype=np.int32)
    # 各ラベルの「最初の画素」= 行優先で最小の平坦添字。run の先頭と一致する。
    flat = lbl.reshape(-1)
    first = np.full(k + 1, flat.size, dtype=np.int64)
    nz = np.nonzero(flat)[0]
    # 後ろから代入すると、同じラベルについて最小の添字が最後に残る
    first[flat[nz[::-1]]] = nz[::-1]
    return ids[np.argsort(first[1:], kind="stable")]


@op("connection", "numpy")
def _connection_numpy(reg: Region, neighborhood: int = 8) -> ObjectSet:
    # ★2026-09-14: ここは長らく `ndi.label(mask)` = **4 連結の既定**だった。
    #   cv2 backend は `connectedComponentsWithStats(..., 8, ...)` で 8 連結なので、
    #   **同じ op が backend によって違う物体数を返していた** —— 8x8 の市松模様で
    #   numpy 32 個 / cv2 1 個。レシピの答えが「どちらの backend が選ばれたか」で
    #   変わるという、いちばん静かな壊れ方。C ABI を Rust で 2 度目に実装して
    #   突き合わせたときに見つかった(fullseye_abi.h の fs_connection に
    #   8 連結と明記した)。回帰は tests/test_fslib.py が backend 横断で見る。
    structure = (np.ones((3, 3), dtype=bool) if neighborhood == 8
                 else ndi.generate_binary_structure(2, 1))
    lbl, k = ndi.label(reg._mask, structure=structure)
    return ObjectSet(lbl.astype(np.int32), _order_ids(lbl, k))


@op("connection", "cv2")
def _connection_cv2(reg: Region, neighborhood: int = 8) -> ObjectSet:
    """One pass produces the labels *and* the stats — carry both."""
    import cv2
    # ★2026-09-14: ここは `(mask, 8, cv2.CV_32S)` と**位置引数**で書いてあった。
    #   読むと「8 連結を明示している」ように見えるが、cv2 5.0.0 で実測すると
    #   `connectedComponentsWithStats(a, 4, CV_32S)` も `(a, 8, CV_32S)` も**同じ答え**
    #   を返す —— 位置引数は connectivity として解釈されておらず、**既定の 8 に
    #   たまたま一致していただけ**。既定が変われば黙って 4 連結になる。
    #   コードが主張している意図を API が守っていない形なので、キーワードで固定する。
    #   (差分ファジングの変異解析で 4 連結を注入したのに一切検出されず、掘ったら
    #    注入のほうが効いていなかった、という経路で見つかった。)
    k, lbl, stats, cents = cv2.connectedComponentsWithStats(
        reg._mask.astype(np.uint8), connectivity=neighborhood, ltype=cv2.CV_32S)
    return ObjectSet(lbl, _order_ids(lbl, k - 1),
                     {"_cc_stats": stats, "_cc_centroids": cents})


def _tables_numpy(objs: ObjectSet) -> dict:
    """Measure every label once.  Returned tables are indexed by label id."""
    n = int(objs.labels.max())
    if n == 0:
        z = np.zeros(1)
        return {"area": z, "row": z.copy(), "column": z.copy()}
    idx = np.arange(1, n + 1)
    binary = objs.labels > 0
    areas = np.asarray(ndi.sum_labels(binary, objs.labels, index=idx), dtype=np.float64)
    cents = np.atleast_2d(np.asarray(
        ndi.center_of_mass(binary, objs.labels, idx), dtype=np.float64))
    return {"area": np.concatenate([[0.0], areas]),
            "row": np.concatenate([[0.0], cents[:, 0]]),
            "column": np.concatenate([[0.0], cents[:, 1]])}


def _tables_cv2(objs: ObjectSet) -> dict:
    import cv2
    stats = objs.feats.get("_cc_stats")
    cents = objs.feats.get("_cc_centroids")
    if stats is None:
        # No stats were carried from `connection` — measure now.
        # 連結性はキーワードで渡す(位置引数では効かない。`_connection_cv2` の註を参照)
        _n, _lbl, stats, cents = cv2.connectedComponentsWithStats(
            (objs.labels > 0).astype(np.uint8), connectivity=8, ltype=cv2.CV_32S)
    return {"area": stats[:, cv2.CC_STAT_AREA].astype(np.float64),
            "row": cents[:, 1].astype(np.float64),
            "column": cents[:, 0].astype(np.float64)}


@op("measure_all", "numpy")
def _measure_all_numpy(objs: ObjectSet):
    return _measure_with(objs, _tables_numpy)


@op("measure_all", "cv2")
def _measure_all_cv2(objs: ObjectSet):
    return _measure_with(objs, _tables_cv2)


def _measure_with(objs: ObjectSet, tables_fn):
    """fs_measure_all shape: three tuples for the LIVE objects.

    The label-indexed tables stay behind the boundary as a private cache so that
    `select` costs nothing; only the per-object values cross the API, which is
    what the C ABI declares (no dictionary crosses the boundary — ABI rule R-4).
    """
    if len(objs) == 0:
        z = np.zeros(0)
        return (z, z.copy(), z.copy())
    for k, v in tables_fn(objs).items():
        objs.feats.setdefault(k, v)
    ids = objs.ids
    return (objs.feats["area"][ids], objs.feats["row"][ids], objs.feats["column"][ids])


def _measure_all(objs: ObjectSet) -> dict:
    """Internal: fill the label-indexed cache using the active backend."""
    _dispatch("measure_all", objs)
    return objs.feats


def measure_all(objs: ObjectSet):
    """fs_measure_all — (area, row, column) for the live objects."""
    _require(objs, ObjectSet, "measure_all")
    return _dispatch("measure_all", objs)


#: `region_features` is the historical name; `measure_all` is the ABI one.
region_features = measure_all


def gauss(img: FImage, sigma: float) -> FImage:
    _require(img, FImage, "gauss")
    return _dispatch("gauss", img, sigma)


def threshold(img: FImage, lo: float, hi: float) -> Region:
    _require(img, FImage, "threshold")
    # ★契約 R-1(fullseye_abi.h): 失敗した演算子は「何も見つからなかった」演算子と
    #   区別できなければならない。逆さの区間は呼び手の間違いであって、「空を寄こせ」
    #   という正当な指定ではない —— 黙って空の Region を返すと、しきい値の計算を
    #   間違えたレシピが「不良ゼロ」として通る。2026-09-14、同じ契約の Rust 実装が
    #   FS_E_INVALID_ARG を返すのにこちらは空を返す、という差分で見つかった。
    if not (float(lo) <= float(hi)):
        # 契約では FS_E_INVALID_ARG(引数が定義域の外)。FS_E_TYPE ではない。
        raise FsValueError(
            "threshold: lo (%r) must not exceed hi (%r) — an inverted interval is "
            "a caller error, not a way to ask for an empty region (ABI R-1)" % (lo, hi))
    return _dispatch("threshold", img, lo, hi)


def _connection_core(reg: Region, neighborhood: int,
                     max_connection: int | None) -> ObjectSet:
    _require(reg, Region, "connection")
    if isinstance(neighborhood, (bool, np.bool_)) or neighborhood not in (4, 8):
        raise FsValueError("connection: neighborhood must be 4 or 8, got %r"
                           % (neighborhood,))
    if max_connection is not None:
        if (isinstance(max_connection, (bool, np.bool_)) or
                not isinstance(max_connection, (int, np.integer)) or
                max_connection < 0):
            raise FsValueError("connection: max_connection must be a non-negative int or None")
    result = _dispatch("connection", reg, neighborhood)
    count = len(result.ids)
    if max_connection is not None and count > max_connection:
        raise FsValueError("connection: component count %d exceeds max_connection limit %d"
                           % (count, max_connection))
    return result


def connection(reg: Region) -> ObjectSet:
    """Split a region into components using 8-neighborhood connectivity.

    Args:
        reg: Region to split.
    """
    return _connection_core(reg, 8, None)


def connection_opts(reg: Region, *, neighborhood: int = 8,
                    max_connection: int | None = None) -> ObjectSet:
    """Split a region with configurable connectivity and a fail-closed limit.

    Args:
        reg: Region to split.
        neighborhood: Pixel connectivity, either 4 or 8.
        max_connection: Maximum allowed component count. ``None`` has no limit.
    """
    return _connection_core(reg, neighborhood, max_connection)


def select_shape(objs: ObjectSet, feature: str, vmin: float, vmax: float) -> ObjectSet:
    """Filter by a measured feature — on ids, without materialising masks."""
    # ★契約 R-1: `threshold` で直したのと**同じ欠陥が兄弟に残っていた**。逆さの区間は
    #   呼び手の間違いであって「空を寄こせ」という指定ではない —— 黙って 0 個を返すと、
    #   面積の下限と上限を取り違えたレシピが「該当なし = 良品」として通る。
    #   2026-09-14、Rust 実装が FS_E_INVALID_ARG を返すのにこちらは 0 個を返す差分で発見。
    if not (float(vmin) <= float(vmax)):
        # 契約では FS_E_INVALID_ARG。逆区間は「型が違う」のではなく「値が範囲外」。
        raise FsValueError(
            "select_shape: vmin (%r) must not exceed vmax (%r) — an inverted interval is "
            "a caller error, not a way to ask for an empty set (ABI R-1)" % (vmin, vmax))
    areas, rows, cols = region_features(objs)
    values = {"area": areas, "row": rows, "column": cols}.get(feature)
    if values is None:
        # 名前が定義域の外 = FS_E_INVALID_ARG(`fs_select_shape` の註)
        raise FsValueError("unknown feature %r (have: area, row, column)" % feature)
    return objs.select((values >= float(vmin)) & (values <= float(vmax)))


def _require(v, cls, where):
    if not isinstance(v, cls):
        raise FsTypeError("%s expects %s, got %s — the sort is carried by the type, "
                          "not inferred from the pixels" % (where, cls.__name__, type(v).__name__))
