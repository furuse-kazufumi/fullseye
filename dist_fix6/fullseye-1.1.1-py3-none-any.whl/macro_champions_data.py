"""Generated DNA store for macro ("self-expanding registry") ops — DO NOT hand-edit.

Written by champion_to_macro.py alongside the human-readable data/macro_champions.json.
This is the RUNTIME source backends_macro.py reads: as a plain py-module it always
ships in the wheel (flat-layout data files under data/ do NOT), so macro ops register
on a pip-installed package, not only in the editable source tree.
"""
from __future__ import annotations

MACROS = [{'name': 'macro_denoise',
  'category': 'macro',
  'problem': 'denoise',
  'in_sort': 'image',
  'out_sort': 'image',
  'stages': [{'op': 'bilateral', 'a': 0.09583587098538462, 'b': 0.7620098191899134},
             {'op': 'bilateral', 'a': 0.12194888602848218, 'b': 0.2656968479954811},
             {'op': 'bilateral', 'a': 0.7345632984672005, 'b': 0.10773367102145374}],
  'pipeline': 'bilateral(a=0.10,b=0.76) -> bilateral(a=0.12,b=0.27) -> bilateral(a=0.73,b=0.11)',
  'provenance': {'source': 'evolve.py / robust.py, core-only search (IMGEVOLVE_NO_BACKENDS=1)',
                 'champion_file': 'out/macro_denoise2/champion_denoise.json',
                 'unit': 'dB PSNR',
                 'config': {'n_train': 14, 'n_holdout': 8, 'size': 64, 'seed': 0},
                 'seeds': 8,
                 'gens': 80,
                 'pop': 28,
                 'selected_seed': 7,
                 'captured': '2026-08-15',
                 'score': {'train': 26.0357, 'holdout': 26.0542, 'locked_holdout': 26.2769},
                 'recorded_evolution_score': {'train': 26.0357,
                                              'holdout': 26.0542,
                                              'locked_holdout': 26.2769},
                 'score_matches_evolution': True,
                 'overridden_ops': [],
                 'baselines': {'trivial': {'train': 14.9581,
                                           'holdout': 14.9979,
                                           'locked_holdout': 14.9287},
                               'hand': {'train': 22.5495,
                                        'holdout': 22.7185,
                                        'locked_holdout': 22.8316},
                               'reference': {'train': 22.6732,
                                             'holdout': 23.0185,
                                             'locked_holdout': 23.7173}},
                 'beats_hand_on_locked_holdout': True,
                 'honest_note': 'A macro op is the exact evolved pipeline, knobs frozen; its score '
                                'is recomputed here in the full registry. '
                                'beats_hand_on_locked_holdout states, without spin, whether it '
                                'beats the strongest hand baseline on the locked split (the one '
                                'honesty guard evolution never selected on).'}},
 {'name': 'macro_edge',
  'category': 'macro',
  'problem': 'edge',
  'in_sort': 'image',
  'out_sort': 'region',
  'stages': [{'op': 'gamma', 'a': 0.3862921309155467, 'b': 0.9363822065955621},
             {'op': 'bilateral', 'a': 0.2152938464607123, 'b': 0.08090318183045037},
             {'op': 'sobel_mag', 'a': 0.8055029707830818, 'b': 0.7976900427133748},
             {'op': 'scale_clip', 'a': 1.0, 'b': 0.900181490402993},
             {'op': 'otsu', 'a': 0.7790793603327741, 'b': 0.9307264503702687}],
  'pipeline': 'gamma(a=0.39,b=0.94) -> bilateral(a=0.22,b=0.08) -> sobel_mag(a=0.81,b=0.80) -> '
              'scale_clip(a=1.00,b=0.90) -> otsu(a=0.78,b=0.93)',
  'provenance': {'source': 'evolve.py / robust.py, core-only search (IMGEVOLVE_NO_BACKENDS=1)',
                 'champion_file': 'out/macro_edge/champion_edge.json',
                 'unit': 'F1',
                 'config': {'n_train': 14, 'n_holdout': 8, 'size': 64, 'seed': 0},
                 'seeds': 8,
                 'gens': 80,
                 'pop': 28,
                 'selected_seed': 7,
                 'captured': '2026-08-15',
                 'score': {'train': 0.9692, 'holdout': 0.9468, 'locked_holdout': 0.9057},
                 'recorded_evolution_score': {'train': 0.9697,
                                              'holdout': 0.9475,
                                              'locked_holdout': 0.9062},
                 'score_matches_evolution': False,
                 'overridden_ops': ['otsu'],
                 'baselines': {'trivial': {'train': 0.2505,
                                           'holdout': 0.2673,
                                           'locked_holdout': 0.2161},
                               'hand': {'train': 0.9325,
                                        'holdout': 0.8968,
                                        'locked_holdout': 0.7717},
                               'reference': {'train': 0.267,
                                             'holdout': 0.2677,
                                             'locked_holdout': 0.2897}},
                 'beats_hand_on_locked_holdout': True,
                 'honest_note': 'A macro op is the exact evolved pipeline, knobs frozen; its score '
                                'is recomputed here in the full registry. '
                                'beats_hand_on_locked_holdout states, without spin, whether it '
                                'beats the strongest hand baseline on the locked split (the one '
                                'honesty guard evolution never selected on). 2026-09-26: `otsu` '
                                'のしきい値をビンの中点からビンの上端へ直した(docs/hardening/otsu-threshold-at-the-bin-midpoint.md)。この '
                                'DNA は `otsu` を最終段に持つので、**進化した当時の値では測り直せない** —— '
                                '`recorded_evolution_score` は当時のまま残し、`score` '
                                'を今のレジストリで測り直した値に更新し、`overridden_ops` に `otsu` '
                                'を載せた。数字が動いたことを消さずに書くのが本来の用途。 2026-11-09: `otsu` が [0,1] '
                                'に収まる像も実データの範囲で 256 ビンを張るようになり(点検 g4_2d_stats)、`score` を '
                                'champion_to_macro.build_entry で測り直した(train 0.9694 → '
                                '0.9692、holdout 0.9468 → 0.9468、locked_holdout 0.9059 → '
                                '0.9057)。`recorded_evolution_score` は当時のまま。'}},
 {'name': 'macro_binarize',
  'category': 'macro',
  'problem': 'binarize',
  'in_sort': 'image',
  'out_sort': 'image',
  'stages': [{'op': 'bilateral', 'a': 0.06099253952944164, 'b': 0.891531397738003},
             {'op': 'unsharp', 'a': 0.5068518736223502, 'b': 0.3425965636950455},
             {'op': 'bilateral', 'a': 0.039336483471460244, 'b': 0.235214981336033},
             {'op': 'lowpass', 'a': 0.753333646329263, 'b': 0.5947708589548446},
             {'op': 'gopen', 'a': 0.3774757893995089, 'b': 0.0},
             {'op': 'unsharp', 'a': 0.7779043057358495, 'b': 0.6808532667629071}],
  'pipeline': 'bilateral(a=0.06,b=0.89) -> unsharp(a=0.51,b=0.34) -> bilateral(a=0.04,b=0.24) -> '
              'lowpass(a=0.75,b=0.59) -> gopen(a=0.38,b=0.00) -> unsharp(a=0.78,b=0.68)',
  'provenance': {'source': 'evolve.py / robust.py, core-only search (IMGEVOLVE_NO_BACKENDS=1)',
                 'champion_file': 'out/macro_binarize/champion_binarize.json',
                 'unit': 'IoU',
                 'config': {'n_train': 14, 'n_holdout': 8, 'size': 64, 'seed': 0},
                 'seeds': 8,
                 'gens': 80,
                 'pop': 28,
                 'selected_seed': 5,
                 'captured': '2026-08-15',
                 'score': {'train': 0.9068, 'holdout': 0.9534, 'locked_holdout': 0.7496},
                 'recorded_evolution_score': {'train': 0.9068,
                                              'holdout': 0.9534,
                                              'locked_holdout': 0.7496},
                 'score_matches_evolution': True,
                 'overridden_ops': [],
                 'baselines': {'trivial': {'train': 0.6324,
                                           'holdout': 0.6976,
                                           'locked_holdout': 0.5165},
                               'hand': {'train': 0.7731,
                                        'holdout': 0.8776,
                                        'locked_holdout': 0.6194}},
                 'beats_hand_on_locked_holdout': True,
                 'honest_note': 'A macro op is the exact evolved pipeline, knobs frozen; its score '
                                'is recomputed here in the full registry. '
                                'beats_hand_on_locked_holdout states, without spin, whether it '
                                'beats the strongest hand baseline on the locked split (the one '
                                'honesty guard evolution never selected on).'}},
 {'name': 'macro_vol_denoise',
  'category': 'macro',
  'problem': 'vol_denoise',
  'in_sort': 'volume',
  'out_sort': 'volume',
  'stages': [{'op': 'vol_threshold', 'a': 0.5232292799734952, 'b': 0.761768170285529},
             {'op': 'vol_gaussian', 'a': 0.0760881116165437, 'b': 0.0}],
  'pipeline': 'vol_threshold(a=0.52,b=0.76) -> vol_gaussian(a=0.08,b=0.00)',
  'provenance': {'source': 'evolve.py / robust.py, core-only search (IMGEVOLVE_NO_BACKENDS=1)',
                 'champion_file': 'out/macro_voldenoise/champion_vol_denoise.json',
                 'unit': 'dB PSNR',
                 'config': {'n_train': 14, 'n_holdout': 8, 'size': 64, 'seed': 0},
                 'seeds': 8,
                 'gens': 80,
                 'pop': 28,
                 'selected_seed': 7,
                 'captured': '2026-08-15',
                 'score': {'train': 26.2351, 'holdout': 25.7124, 'locked_holdout': 25.7364},
                 'recorded_evolution_score': {'train': 26.2351,
                                              'holdout': 25.7124,
                                              'locked_holdout': 25.7364},
                 'score_matches_evolution': True,
                 'overridden_ops': [],
                 'baselines': {'trivial': {'train': 19.3839,
                                           'holdout': 19.3364,
                                           'locked_holdout': 19.3047},
                               'hand': {'train': 20.6998,
                                        'holdout': 21.1637,
                                        'locked_holdout': 20.9354}},
                 'beats_hand_on_locked_holdout': True,
                 'honest_note': 'A macro op is the exact evolved pipeline, knobs frozen; its score '
                                'is recomputed here in the full registry. '
                                'beats_hand_on_locked_holdout states, without spin, whether it '
                                'beats the strongest hand baseline on the locked split (the one '
                                'honesty guard evolution never selected on).'}}]
