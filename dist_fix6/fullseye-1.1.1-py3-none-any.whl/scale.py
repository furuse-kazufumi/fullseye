"""Large-image (HALCON-XL-style) execution helpers.

Some operators need an *algorithm change* at XL scale (measured in
docs/AUDIT_2026_08_12.md): cv2 warps fail past ~32767 px, FFT ops are O(N^2)
memory, and iterative filters are compute-bound. But **local** operators
(pointwise + separable filters + morphology) give bit-interior-identical results
when run on **haloed tiles** — that is the algorithm change for those: bounded
memory at any image size. (Bit-identical holds for **all-finite** input; a NaN/Inf
poisons scipy's running-sum separable filters unboundedly, so its effective
receptive field exceeds the halo and the tiled result then differs from — and is
usually more local/correct than — the whole-image one.)

    import scale, ops
    big = ...                                   # e.g. 20000 x 20000 gray [0,1]
    out = scale.process_tiled(ops.RT["gaussian"], big, a=0.6)   # any size, bounded RAM

`scale_class(op)` tells you whether an operator is tile-safe, and if not, why.
"""
from __future__ import annotations

import os

import numpy as np

# --- scale classification --------------------------------------------------- #
# Local (receptive field <= halo): correct under haloed tiling.
_TILE_SAFE_CATS = {"smoothing", "rank", "morphology", "edges", "gray", "texture", "region"}
# Need GLOBAL statistics (histogram / whole-image threshold) -> not tileable as-is.
_GLOBAL_CATS = {"segmentation", "features", "classification", "barcode", "matching"}
_COMPUTE_BOUND = {"bilateral", "median"}      # local but slow at XL (sk_tv/xsp_wiener are non-local: see _NOT_TILE_SAFE)
_MEMORY_BOUND_CATS = {"frequency"}                                   # FFT: O(N^2) memory
_CV2_LIMITED_HINTS = ("polar", "warp", "logpolar")                   # cv2 SHRT_MAX (~32767)

# Category is only a *hint*. Many ops in the "tile-safe" categories are in fact NOT
# tileable under the standard haloed tiler (:func:`process_tiled`): region shape /
# topology ops need the whole connected component (skeleton, distance, bounding
# shapes), gray histogram/contrast ops need whole-image statistics, edge magnitude /
# corner / DoG / LoG ops end in a *whole-image* normalization that the tiler would
# redo per tile (piecewise scale jumps at tile seams — not a single global scale, so
# "normalize once at the end" is the only correct route and the standard tiler does
# not do it), texture ridge filters are multiscale, and TV / diffusion / wavelet /
# DCT smoothers are iterative or transform-domain (effective receptive field = the
# whole image). This set was **measured** (3 structured probes x 2 param settings,
# tiling_error > 1e-6) and is locked by tests/test_scale_tiling.py, which fails if
# any op marked tile_safe measurably breaks under tiling, or if a listed op has
# become genuinely tileable (stale). A category-only classifier said 141 of these
# were safe; they are not.
_NOT_TILE_SAFE = frozenset({
    # 2026-11-05(敵対的検証 第 2 巡 P7): anisotropic_diffusion / coherence_enhancing_diff / monotony は
    #   np.roll の周期境界をやめてタイル可能になったので外した(test_not_tile_safe_list_is_not_stale で実測 0.0)。
    'bothat', 'clahe', 'closest_point_transform', 'corner_response',
    'cv_blackhat', 'cv_clahe', 'cv_corner_harris', 'cv_dist', 'cv_gradient', 'cv_laplacian',
    'cv_min_eigen', 'cv_precorner', 'cv_scharr', 'cv_tophat', 'derivate_gauss', 'deviation_image',
    'diff_of_gauss', 'dist_transform', 'dist_transform_abs', 'distance_transform', 'dl_aniso_diffusion', 'dog', 'dots_image',
    'edges_color', 'em_skeleton', 'entropy_image', 'equ_histo_image', 'equ_histo_image_rect', 'equalize',
    'image_standardize',
    # ★2026-09-17: 検査のタイル幅を 64/16 だけから 60/12 も見るように広げたら、
    #   tile_safe と宣言されていた 168 本のうち 16 本が割れた。64 も 16 も 8 の
    #   倍数なので、周期 8 の処理と、たまたま境界が穴に掛からない領域処理が
    #   すり抜けていた。以下はそのとき測って落ちたもの(誤差は 60/12 での実測)。
    'fill_holes', 'sk_remove_holes', 'fill_up', 'select_shape',           # 1.0 = 全く別の結果
    'xsk2_isotropic_close', 'r3_background_seg',                          # 1.0
    'sk_lbp', 'sk_wavelet', 'xwt_lf_reconstruct', 'sk_nlm',               # 0.88 / 0.27 / 0.17 / 0.015
    'xsk2_diameter_opening', 'xsk3_diameter_closing', 'xsk_struct_coherence',  # 0.076 / 0.073 / 0.061
    'dither_ordered', 'dither_floyd_steinberg', 'quantize_lloyd_max',     # 0.14 / 0.14 / 0.13
    'cv_nlmeans', 'xpil_unsharp_mask',    # ハロー 8 では支持長が足りない(0.0078)
    'xdog',    # 0.0205(2026-10-18 実測): ガウシアンの支持が最大 4.8 sigma(sigma 3 で 15 画素)
    'persistence_map', 'f2_shock_diffuse',    # 1.0 / 0.064(2026-09-17 実測)
    'f2_gauss_pyramid', 'f2_gray_inside', 'f2_gray_skeleton', 'f2_symmetry', 'f2_topographic', 'fill_up_shape',
    'structure_tensor_orientation', 'structure_tensor_coherence',
    'frei_amp', 'get_region_convex', 'gray_bothat', 'gray_range_rect', 'gray_tophat', 'illuminate',
    'junctions_skeleton', 'kirsch_amp', 'laplace', 'laplace_of_gauss', 'log',
    'morph_grad', 'morph_skeleton', 'points_foerstner', 'points_harris_binomial', 'prewitt_amp', 'prewitt_mag',
    'pruning', 'r2_inner_circle', 'r2_inner_rectangle1', 'r2_partition_rectangle', 'r2_smallest_circle', 'r2_smallest_rectangle1',
    'r2_smallest_rectangle2', 'r2_sort_region', 'r2_split_skeleton_lines', 'r3_clip_region', 'r3_label_to_region', 'r3_partition_dynamic',
    'r3_select_region_point', 'remove_small', 'roberts', 'roberts_mag', 'robinson_amp', 'scale_image_max',
    'select_largest', 'select_shape_std', 'shape_trans', 'sk_adapthist', 'sk_area_opening', 'sk_clear_border',
    'sk_convex', 'sk_corner_harris', 'sk_dog', 'sk_entropy', 'sk_farid', 'sk_frangi',
    'sk_gabor', 'sk_hessian', 'sk_hessian_det', 'sk_medial', 'sk_meijering', 'sk_scharr',
    'sk_shape_index', 'sk_skeleton', 'sk_thin', 'sk_tv', 'sk_tv_bregman', 'skeleton',
    'smallest_rectangle1', 'sobel_amp', 'sobel_mag', 'std_filter', 'texture_laws', 'tf_phase_congruency',
    'tf_steerable_filter', 'thinning', 'thinning_golay', 'thinning_seq', 'tophat', 'xcv3_denoise_tvl1',
    'xcv_detail_enhance', 'xcv_edge_preserving', 'xkor_clahe', 'xkor_dog', 'xkor_gftt', 'xkor_harris',
    'xkor_hessian', 'xkor_laplacian', 'xpil_autocontrast', 'xpil_contrast', 'xsk2_corner_kr', 'xsk2_hog',
    'xsk2_inv_gauss_grad', 'xsk2_reconstruction', 'xsk3_area_closing', 'xsk3_corner_fast', 'xsk3_corner_moravec', 'xsk3_integral_image',
    'xsk_hessian_eig', 'xsk_meijering', 'xsk_sato', 'xsp_chamfer_dist', 'xsp_cspline_smooth', 'xsp_dct_denoise',
    'xsp_detrend_flatten', 'xsp_gauss_grad_mag', 'xsp_hilbert_env', 'xsp_morph_laplace', 'xsp_wiener', 'xwt_directional_detail',
    'xwt_firm_denoise', 'xwt_hf_reconstruct', 'xwt_visushrink',
    # ★2026-09-17: 走査長平滑化は隙間を最大 65 画素まで埋めるので、
    #   標準タイラーの halo より広い。60/12 のタイルで 0.2613 ずれた(実測)。
    'runlength_smear',
    # ★2026-09-17: 局所の二峰性は窓が最大 41 画素、傾き補正は角度を画像全体から
    #   1 つ決める。どちらもタイルごとに測ると別の答えになる(実測 1.0000)。
    'local_bimodality', 'deskew',
})

# class + reason for a measured non-tileable op, from its (optimistic) category.
#: カテゴリの理由では言い当てられない op だけ、ここで上書きする。
#: 理由が違うと「どう直せばよいか」まで違ってしまう —— 構造テンソルの 2 本は
#: 「テクスチャの支持長がハローを超える」のではなく、**全画像の最大値を床に使う**
#: から割れる。床は一様面で arctan2 が丸め屑を増幅するのを止めるためのもので、
#: タイルごとに取り直すと、真っ平らなタイルでは屑そのものが最大値になって床が効かない。
_NOT_TILE_SAFE_OP_REASON = {
    "image_standardize": (
        "global_reduce",
        "the centre and scale are estimated once from the whole image; per-tile statistics "
        "give every tile a different zero and sigma (measured drift 7.26). Run it once on "
        "the full image before tiling downstream local operators."),
    "deskew": (
        "global",
        "the skew angle is estimated ONCE from the whole image (the projection-profile "
        "criterion needs the full text block); per-tile estimation gives every tile its "
        "own angle and the page tears at the seams. Measured drift 1.0000. Not a halo "
        "problem - no halo fixes it. Deskew the full image, then tile the result."),
    "local_bimodality": (
        "halo",
        "the bimodality window is up to 41 px across, so the receptive field is wider "
        "than the standard tiler's halo and the contrast floor is taken from the whole "
        "image's range. Measured drift 1.0000. Run it on the full image, or tile with a "
        "halo wider than the window."),
    "runlength_smear": (
        "halo",
        "run-length smoothing closes gaps up to 65 px along a line, so the receptive "
        "field is far wider than the standard tiler's halo; a tile boundary inside a "
        "text line leaves the line broken there. Measured drift 0.2613 at 60/12 tiles. "
        "Run it on the full image, or tile with a halo wider than the gap threshold."),
    "structure_tensor_orientation": (
        "global_reduce",
        "local derivatives, but the 'is there a direction at all' floor is relative to the "
        "whole-image tensor maximum; a per-tile floor lets rounding dust pass on a flat tile. "
        "Run it once on the full image."),
    "structure_tensor_coherence": (
        "global_reduce",
        "same whole-image floor as structure_tensor_orientation; run once on the full image."),
    "xsk_struct_coherence": (
        "global_reduce",
        "structure-tensor coherence: local derivatives followed by a whole-image "
        "normalisation; run once on the full image."),
    "dither_ordered": (
        "global",
        "the Bayer threshold is chosen by ABSOLUTE pixel position, so a tile that does "
        "not start on a multiple of the matrix size gets a different phase. Not a halo "
        "problem - no halo fixes it. Dither the whole image, or tile on multiples of 8."),
    "dither_floyd_steinberg": (
        "global",
        "error diffusion carries each pixel's error to its neighbours in scan order, so "
        "the result depends on where the scan starts. Use dither_ordered when you must tile."),
    "quantize_lloyd_max": (
        "global",
        "the codebook is fitted to the WHOLE image's histogram; per-tile fitting gives "
        "each tile its own levels. Fit once, then apply."),
    "persistence_map": (
        "global",
        "0-dimensional persistence: a peak's prominence is set by where it merges with a "
        "HIGHER peak, which may be anywhere in the image. Cutting the image cuts the "
        "merge tree, so every tile invents its own global maximum (measured error 1.0). "
        "No halo fixes this - run it once on the full image."),
    "xdog": (
        "halo",
        "the second Gaussian reaches 4 x 1.6 sigma (up to 19 px at sigma 3), past the default tile halo; "
        "measured tile error 0.0205. Use a halo of at least 7 sigma, or run it whole."),
    "f2_shock_diffuse": (
        "global_reduce",
        "each diffuse/shock pair widens the receptive field by about sigma, so 10 "
        "iterations reach far past any fixed halo. Either run it whole, or use a halo "
        "of at least iterations x sigma."),
}

_NOT_TILE_SAFE_REASON = {
    "region":     ("global", "region shape/topology (skeleton, distance, connectivity, bounding shapes) needs the whole connected region"),
    "gray":       ("global", "needs whole-image statistics (histogram / contrast normalization); compute globally"),
    "edges":      ("global_reduce", "local derivative but ends in a whole-image normalization; the haloed tiler renormalizes each tile (piecewise scale) — normalize once on the full image instead"),
    "morphology": ("global_reduce", "morphological reconstruction or a structuring element larger than the tile halo"),
    "texture":    ("global", "multiscale or large-window texture support exceeds any fixed halo"),
    "smoothing":  ("global", "iterative or transform-domain (TV, diffusion, wavelet, DCT): effective receptive field is the whole image"),
    "rank":       ("compute_bound", "window (rect) can exceed the tile halo; enlarge halo or process globally"),
}


def scale_class(op) -> dict:
    """Classify an Op (or a name+category) for large-image behaviour.

    Returns {class, tile_safe, reason}. class in
    {tile_safe, global, global_reduce, compute_bound, memory_bound, cv2_limited}.
    ``global_reduce`` = spatially local but ends in a whole-image normalization, so
    the standard haloed tiler is wrong (normalize once on the full image instead).
    Membership of the non-tileable set is measured (see ``_NOT_TILE_SAFE``), not
    guessed from the category alone — a category-only rule marked 141 non-tileable
    ops as safe.
    """
    name = getattr(op, "name", op if isinstance(op, str) else "")
    cat = getattr(op, "category", "")
    # ★名前つきの理由は**カテゴリの分岐より先に**引く。category が先に返してしまうと、
    #   幾何カテゴリの op はすべて「cv2 の座標上限」と説明されてしまい、実際の理由
    #   (deskew なら「角度は画像全体から 1 つ決まる」)に辿り着けない。この辞書に
    #   載っているのは実測で非タイル可と分かった op だけなので、載せた op 以外の
    #   分類は 1 件も変わらない(2026-09-17 に 925 op 全数で確認)。
    named = _NOT_TILE_SAFE_OP_REASON.get(name)
    if named is not None:
        return {"class": named[0], "tile_safe": False, "reason": named[1]}
    if any(h in name for h in _CV2_LIMITED_HINTS) or "geometry" in cat:
        return {"class": "cv2_limited", "tile_safe": False,
                "reason": "cv2 warp/geometry: coordinate limit ~32767 px; downscale or use skimage"}
    if cat in _MEMORY_BOUND_CATS:
        return {"class": "memory_bound", "tile_safe": False,
                "reason": "FFT-based: O(N^2) complex memory; use overlap-add or downscale"}
    if name in _COMPUTE_BOUND:
        return {"class": "compute_bound", "tile_safe": True,
                "reason": "local but slow; tiling bounds memory, use cv2/GPU for speed"}
    if cat in _GLOBAL_CATS:
        return {"class": "global", "tile_safe": False,
                "reason": "needs global statistics (histogram/threshold); compute stats globally, then apply"}
    if name in _NOT_TILE_SAFE:
        cls, reason = _NOT_TILE_SAFE_OP_REASON.get(name) or _NOT_TILE_SAFE_REASON.get(
            cat, ("global", "measured non-tileable under haloed tiling"))
        return {"class": cls, "tile_safe": False, "reason": reason}
    if cat in _TILE_SAFE_CATS:
        return {"class": "tile_safe", "tile_safe": True, "reason": "local filter/morphology"}
    return {"class": "global", "tile_safe": False, "reason": "unclassified; treat as non-tileable"}


# --- haloed tiling ---------------------------------------------------------- #
def process_tiled(fn, img, a=0.5, b=0.5, tile=1024, halo=16):
    """Apply a LOCAL image->image op over haloed tiles; bounded memory at any size.

    Each tile is extended by `halo` px on every side, the op runs on the extended
    patch, and only the core is written back — so the result matches whole-image
    processing wherever the op's receptive field <= halo. Use for tile-safe ops
    (gaussian, mean/median, morphology, rank). NOT for global ops (otsu/FFT); check
    scale_class first.

    Caveat: ops that end in a GLOBAL normalization (`_norm`/`signed01`, e.g.
    `sobel_mag`, `laplace`) tile *spatially* correctly, but the [0,1] scale is a
    whole-image reduction — each tile would normalize by its own max, giving
    piecewise scale jumps at tile seams. For those, tile the raw filter and
    normalize once at the end. `scale_class(op)["tile_safe"]` already returns False
    for them (class `global_reduce`) and for every other measured non-local op
    (`_NOT_TILE_SAFE`); check it before tiling.
    """
    src = np.asarray(img, np.float64)
    H, W = src.shape[:2]
    out = np.empty(src.shape, np.float64)           # preserve trailing channel dims, if any
    for y0 in range(0, H, tile):
        for x0 in range(0, W, tile):
            y1, x1 = min(y0 + tile, H), min(x0 + tile, W)
            ey0, ex0 = max(0, y0 - halo), max(0, x0 - halo)
            ey1, ex1 = min(H, y1 + halo), min(W, x1 + halo)
            res = np.asarray(fn(src[ey0:ey1, ex0:ex1], a, b), np.float64)
            out[y0:y1, x0:x1] = res[y0 - ey0:y0 - ey0 + (y1 - y0),
                                    x0 - ex0:x0 - ex0 + (x1 - x0)]
    return out


def tiling_error(fn, img, a=0.5, b=0.5, tile=64, halo=16):
    """Max abs diff between whole-image and tiled results (0 for local ops)."""
    whole = np.asarray(fn(np.asarray(img, np.float64), a, b), np.float64)
    tiled = process_tiled(fn, img, a, b, tile=tile, halo=halo)
    return float(np.max(np.abs(whole - tiled)))


# --- multithreaded + out-of-core tiling (HALCON-XL scale) ------------------- #
def _tile_specs(H, W, tile, halo):
    """Geometry of every haloed tile: (core y0,y1,x0,x1 ; extended ey0,ey1,ex0,ex1)."""
    t, h = int(tile), int(halo)
    specs = []
    for y0 in range(0, H, t):
        for x0 in range(0, W, t):
            y1, x1 = min(y0 + t, H), min(x0 + t, W)
            ey0, ex0 = max(0, y0 - h), max(0, x0 - h)
            ey1, ex1 = min(H, y1 + h), min(W, x1 + h)
            specs.append((y0, y1, x0, x1, ey0, ey1, ex0, ex1))
    return specs


def _run_tile(fn, src, dst, spec, a, b):
    """Process one haloed tile from ``src`` and write its core into ``dst``.

    Threads own disjoint core regions of ``dst`` and only read ``src``, so this is
    safe to run concurrently."""
    y0, y1, x0, x1, ey0, ey1, ex0, ex1 = spec
    patch = np.asarray(src[ey0:ey1, ex0:ex1], np.float64)
    res = np.asarray(fn(patch, a, b), np.float64)
    dst[y0:y1, x0:x1] = res[y0 - ey0:y0 - ey0 + (y1 - y0),
                            x0 - ex0:x0 - ex0 + (x1 - x0)]


def process_tiled_mt(fn, img, a=0.5, b=0.5, tile=1024, halo=16, workers=None):
    """Multithreaded :func:`process_tiled` — identical result, tiles in parallel.

    Each haloed tile is an independent unit writing a disjoint core region, so they
    run on a :class:`ThreadPoolExecutor`. numpy/scipy release the GIL inside their C
    kernels (filters, morphology, FFT), so this gives a real wall-clock speed-up for
    compute-bound tile-safe ops at XL sizes — with a bit-identical result to the
    serial version. ``workers`` defaults to the CPU count. Use for tile-safe ops
    (check :func:`scale_class`); NOT for global ops."""
    src = np.asarray(img, np.float64)
    H, W = src.shape[:2]
    out = np.empty(src.shape, np.float64)           # preserve trailing channel dims, if any
    specs = _tile_specs(H, W, tile, halo)
    n = len(specs) if workers is None else int(workers)
    n = max(1, min(n, len(specs), (os.cpu_count() or 1)))
    if n <= 1:
        for s in specs:
            _run_tile(fn, src, out, s, a, b)
    else:
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=n) as ex:
            list(ex.map(lambda s: _run_tile(fn, src, out, s, a, b), specs))
    return out


def open_memmap(path, shape=None, dtype=np.float64, mode="r+"):
    """Open (or create) an on-disk ``.npy`` array as a memory-map — the array is
    read/written in pages from disk, never fully resident in RAM.

    ``mode='w+'`` creates a new file (give ``shape`` + ``dtype``); ``'r'``/``'r+'``
    open an existing one (the ``.npy`` header supplies shape/dtype). The storage
    backing :func:`process_tiled_memmap` for images larger than memory."""
    from numpy.lib.format import open_memmap as _om
    if mode == "w+":
        if shape is None:
            raise ValueError("mode 'w+' needs a shape")
        return _om(path, mode="w+", dtype=np.dtype(dtype), shape=tuple(shape))
    return _om(path, mode=mode)


def process_tiled_memmap(fn, src, dst, a=0.5, b=0.5, tile=1024, halo=16, workers=1):
    """Out-of-core :func:`process_tiled`: process an on-disk image tile-by-tile into
    an on-disk output, at bounded RAM for **any** image size.

    ``src``/``dst`` are memmap arrays or paths to ``.npy`` files; only one extended
    tile and its result are ever resident, so a 100k x 100k image processes in a few
    MB of RAM. ``dst`` (path) is created to match ``src``'s 2-D shape. ``workers>1``
    processes tiles concurrently (each reads/writes disjoint disk regions). Result
    matches whole-image processing wherever the op's receptive field <= halo.
    Returns the ``dst`` memmap (flushed)."""
    S = open_memmap(src, mode="r") if isinstance(src, str) else src
    H, W = S.shape[:2]
    if isinstance(dst, str):
        D = open_memmap(dst, shape=(H, W), dtype=np.float64, mode="w+")
    else:
        D = dst
    specs = _tile_specs(H, W, tile, halo)
    if workers and int(workers) > 1:
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=int(workers)) as ex:
            list(ex.map(lambda s: _run_tile(fn, S, D, s, a, b), specs))
    else:
        for s in specs:
            _run_tile(fn, S, D, s, a, b)
    if hasattr(D, "flush"):
        D.flush()
    return D
