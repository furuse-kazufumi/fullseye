"""Per-operator knob PRESENTATION specs for Fullseye Studio (additive, optional).

Every 2-D op takes two knobs ``a, b`` in [0, 1]; the op maps each knob to its real
parameter internally (``gaussian``: ``sigma = 0.3 + 2.7*a``; ``median``: kernel
``(3, 5, 7, 9)[min(3, int(a*4))]``; ``reg_erode``: ``iterations = 1 + int(a*3)``).
The registry carries no metadata about those mappings, so a UI can only offer the
same two anonymous 0..1 sliders for every op.

This module is the missing metadata layer. A spec describes how a knob is SHOWN
(label, displayed range / unit, integer snapping, choice names) — the value that
reaches the op stays the 0..1 float, so nothing else in the system changes.

Spec dict keys::

    label    str    short name of the parameter ("blur σ")
    kind     "float" | "int" | "choice" | "bool" | "unused"
    min/max  displayed range (float / int kinds)
    step     display step (float); decimals are derived from it
    choices  list of display names (choice kind)
    unit     str | None  ("px", "°", "×", "cyc/px" …)
    map      how the 0..1 knob maps to the display value:
               "linear"  d = min + knob*(max-min)                (float; int -> round)
               "log"     d = min * (max/min)**knob               (float)
               "floor"   d = min + int(knob*(max-min))           (int: op uses int(a*N))
               "bucket"  i = min(n-1, int(knob*n))               (choice / int: equal buckets)
    true_if  ">=0.5" | ">0.5"  (bool kind: which comparison the op source uses)
    doc      one-line explanation (unit / meaning)
    source   the op-source expression the spec was transcribed from (provenance)

Two tables feed :func:`spec_for`:

* :data:`PARAM_SPECS` — HAND-WRITTEN from the op source (``ops.py`` and a few
  backends). Each entry names the source formula; ``tests/test_studio_params.py``
  re-derives the op's own mapping (importing the private helpers ``ops._k`` /
  ``ops._it`` and the literal formulas) and asserts :func:`knob_to_display`
  reproduces it, so the table cannot silently drift from the implementation.
* :func:`seed_from_docs` — LABEL-ONLY seeds mined from op docstrings and the per-op
  notes under ``docs/ops/**/<op>.md``. A seeded spec keeps the generic 0..1 float
  presentation and only contributes the label/doc text (an honest "what does a do"
  without inventing a range). At the time of writing the generated per-op notes
  carry no "Parameters" section, so in practice the docstrings are the source.
"""
from __future__ import annotations

import functools
import inspect
import math
import os
import re
from typing import Any, Optional

# --------------------------------------------------------------------------- #
# generic / unused
# --------------------------------------------------------------------------- #
GENERIC_FLOAT: dict[str, Any] = {
    "label": "", "kind": "float", "min": 0.0, "max": 1.0, "step": 0.001,
    "choices": None, "unit": None, "map": "linear", "doc": "raw knob (0..1)",
    "source": None,
}
UNUSED: dict[str, Any] = {
    "label": "(unused)", "kind": "unused", "min": 0.0, "max": 1.0, "step": 0.001,
    "choices": None, "unit": None, "map": "linear",
    "doc": "this op does not read this knob", "source": None,
}


def _spec(label, kind="float", lo=0.0, hi=1.0, step=0.01, unit=None, map_="linear",
          choices=None, doc="", source=None, true_if=">=0.5"):
    """Build a complete spec dict (every key present, so consumers need no .get())."""
    d = {"label": label, "kind": kind, "min": lo, "max": hi, "step": step,
         "choices": list(choices) if choices else None, "unit": unit, "map": map_,
         "doc": doc, "source": source}
    if kind == "bool":
        d["true_if"] = true_if
    if kind == "choice":
        d["min"], d["max"] = 0, len(d["choices"]) - 1
        d["map"] = "bucket"
    return d


def _lin(label, lo, hi, step=0.01, unit=None, doc="", source=None):
    return _spec(label, "float", float(lo), float(hi), step, unit, "linear", doc=doc, source=source)


def _int_floor(label, lo, hi, unit=None, doc="", source=None):
    # op source: lo + int(knob * (hi - lo))  — the top value only at knob == 1.0
    return _spec(label, "int", int(lo), int(hi), 1, unit, "floor", doc=doc, source=source)


def _kernel(doc="odd kernel size (3, 5, 7 or 9 px) — ops._k(a)"):
    # ops._k(a) = (3, 5, 7, 9)[min(3, int(a * 4))]: four equal-width buckets
    return _spec("kernel", "choice", choices=["3", "5", "7", "9"], unit="px", doc=doc,
                 source="(3, 5, 7, 9)[min(3, int(a * 4))]")


def _iters(doc="morphology iterations 1..4 — ops._it(a)"):
    # ops._it(a) = 1 + int(a * 3)
    return _int_floor("iterations", 1, 4, doc=doc, source="1 + int(a * 3)")


_SIGMA = "σ"
_DEG = "°"

#: ``ops._border(b)``: b ≤ 0.5 は reflect(既定)、その先を 3 等分して nearest / constant / wrap。
#: ★2026-11-12: gaussian / mean_box / median の b は 2026-09-17 から端の扱いを選ぶのに、ここは UNUSED のままで、
#: Studio は「b (–) · この op では使いません」と出してつまみを無効にしていた。区切りが等間隔でない
#: (0.5 までが 1 つ目)ので、等幅のバケツ("bucket")でなく専用の写し方 "half_then_thirds" を使う。
def _half_then_thirds(label, choices, doc, source):
    d = _spec(label, "choice", choices=choices, doc=doc, source=source)
    d["map"] = "half_then_thirds"
    return d


def half_then_thirds_index(knob: float) -> int:
    """``ops._border`` / ``ops._se`` と同じ区切り: 0.5 以下は 0、その先を 3 等分して 1, 2, 3。"""
    x = _clamp01(knob)
    return 0 if x <= 0.5 else 1 + min(2, int((x - 0.5) / (0.5 / 3.0)))


#: 各選択肢を表すつまみの値。0 番は**既定値の 0.5**(まん中に置くと保存済みのプログラムの値と揃う)。
_HALF_THEN_THIRDS_KNOB = (0.5, 0.5 + 0.5 / 6.0, 0.75, 0.5 + 2.5 / 6.0)

BORDER: dict[str, Any] = _half_then_thirds(
    "border handling", ["reflect", "nearest", "constant", "wrap"],
    "border handling: b ≤ 0.5 reflect (default), then nearest, constant (0), wrap in equal thirds of 0.5..1",
    "_border(b)")
#: ``ops._se(b, k)``: b ≤ 0.5 は正方形(既定)、その先を 3 等分して十字 / 円板 / 水平線。
SE_SHAPE: dict[str, Any] = _half_then_thirds(
    "element shape", ["square", "cross", "disc", "line"],
    "structuring element: b ≤ 0.5 square (default), then cross, disc, horizontal line in equal thirds of 0.5..1",
    "_se(b, k)")

# --------------------------------------------------------------------------- #
# HAND-WRITTEN specs (each verified against the op source; see the tests)
# --------------------------------------------------------------------------- #
PARAM_SPECS: dict[str, dict[str, dict[str, Any]]] = {
    # ---- smoothing / rank / grey morphology (ops.py) ----
    "gaussian": {"a": _lin("blur " + _SIGMA, 0.3, 3.0, 0.01, "px",
                           "Gaussian σ = 0.3 + 2.7·a", "0.3 + 2.7 * a"),
                 "b": BORDER},
    "mean_box": {"a": _kernel("box (uniform) filter size"), "b": BORDER},
    "mean_box_wh": {
        "a": _spec("window width", "choice", choices=[str(x) for x in range(1, 16, 2)],
                   unit="px", doc="odd horizontal window 1..15 px",
                   source="1 + 2 * min(7, int(8 * a))"),
        "b": _spec("window height", "choice", choices=[str(x) for x in range(1, 16, 2)],
                   unit="px", doc="odd vertical window 1..15 px",
                   source="1 + 2 * min(7, int(8 * b))"),
    },
    "median": {"a": _kernel("median filter size"), "b": BORDER},
    "min_filter": {"a": _kernel("minimum filter size"), "b": UNUSED},
    "max_filter": {"a": _kernel("maximum filter size"), "b": UNUSED},
    "percentile": {"a": _kernel("percentile filter size"),
                   "b": _int_floor("percentile", 5, 95, "%", "rank percentile 5..95",
                                   "int(5 + 90 * b)")},
    "gerode": {"a": _kernel("grey erosion size"), "b": SE_SHAPE},
    "gdilate": {"a": _kernel("grey dilation size"), "b": SE_SHAPE},
    "gopen": {"a": _kernel("grey opening size"), "b": SE_SHAPE},
    "gclose": {"a": _kernel("grey closing size"), "b": SE_SHAPE},
    "tophat": {"a": _kernel("white top-hat size"), "b": UNUSED},
    "bothat": {"a": _kernel("black top-hat size"), "b": UNUSED},
    "morph_grad": {"a": _kernel("morphological gradient size"), "b": UNUSED},
    "std_filter": {"a": _kernel("local std-dev window"), "b": UNUSED},
    "bilateral": {"a": _lin("spatial " + _SIGMA, 1.0, 4.0, 0.01, "px",
                            "spatial σ = 1 + 3·a", "1.0 + 3.0 * a"),
                  "b": _lin("range " + _SIGMA, 0.05, 0.45, 0.001, None,
                            "range (intensity) σ = 0.05 + 0.4·b", "0.05 + 0.4 * b")},
    "unsharp": {"a": _lin("amount", 0.0, 1.5, 0.01, "×", "sharpen gain k = 1.5·a", "1.5 * a"),
                "b": _lin("radius " + _SIGMA, 0.5, 2.0, 0.01, "px",
                          "blur σ of the mask = 0.5 + 1.5·b", "0.5 + 1.5 * b")},
    # ---- edges ----
    "sobel_mag": {"a": UNUSED, "b": UNUSED},
    "laplace": {"a": UNUSED, "b": UNUSED},
    "prewitt_mag": {"a": UNUSED, "b": UNUSED},
    "roberts_mag": {"a": UNUSED, "b": UNUSED},
    "grad_dir": {"a": UNUSED, "b": UNUSED},
    "dog": {"a": _lin(_SIGMA + "1 (fine)", 0.5, 2.5, 0.01, "px", "inner σ = 0.5 + 2·a", "0.5 + 2.0 * a"),
            "b": _lin(_SIGMA + "2 (coarse)", 1.0, 5.0, 0.01, "px", "outer σ = 1 + 4·b", "1.0 + 4.0 * b")},
    "log": {"a": _lin(_SIGMA, 0.5, 3.0, 0.01, "px", "Laplacian-of-Gaussian σ = 0.5 + 2.5·a",
                      "0.5 + 2.5 * a"), "b": UNUSED},
    "corner_response": {"a": _lin("window " + _SIGMA, 0.5, 2.5, 0.01, "px",
                                  "Harris integration σ = 0.5 + 2·a", "0.5 + 2.0 * a"),
                        "b": UNUSED},
    # ---- grey-value transforms ----
    "gamma": {"a": _lin("gamma", 0.5, 2.0, 0.01, None, "γ = 0.5 + 1.5·a (γ<1 brightens)",
                        "0.5 + 1.5 * a"), "b": UNUSED},
    "invert": {"a": UNUSED, "b": UNUSED},
    "scale_clip": {"a": _lin("contrast", 0.5, 2.0, 0.01, "×", "gain = 0.5 + 1.5·a", "0.5 + 1.5 * a"),
                   "b": _lin("brightness", -0.5, 0.5, 0.01, None, "offset = b − 0.5", "b - 0.5")},
    "equalize": {"a": UNUSED, "b": UNUSED},
    "sigmoid": {"a": _lin("gain", 4.0, 16.0, 0.1, None, "slope = 4 + 12·a", "4.0 + 12.0 * a"),
                "b": _lin("centre", 0.2, 0.8, 0.01, None, "midpoint = 0.2 + 0.6·b", "0.2 + 0.6 * b")},
    "lowpass": {"a": _lin("cutoff", 0.05, 0.45, 0.001, "cyc/px", "FFT cutoff = 0.05 + 0.4·a",
                          "0.05 + 0.4 * a"), "b": UNUSED},
    "highpass": {"a": _lin("cutoff", 0.02, 0.32, 0.001, "cyc/px", "FFT cutoff = 0.02 + 0.3·a",
                           "0.02 + 0.3 * a"), "b": UNUSED},
    "clahe": {"a": _int_floor("tiles", 2, 5, "×", "tile grid nb×nb, nb = 2 + int(3·a)", "2 + int(a * 3)"),
              "b": _spec("clip limit", "float", 1.0, 256.0, 0.5, "×", "log",
                         doc="clip limit as a multiple of the mean bin count = 256^b "
                             "(1 = flat, 256 = plain AHE)", source="256.0 ** b")},
    "gabor": {"a": _lin("orientation", 0.0, 180.0, 0.5, _DEG, "θ = π·a (rad) = 180°·a", "180.0 * a"),
              "b": _lin("frequency", 0.1, 0.4, 0.001, "cyc/px", "f = 0.1 + 0.3·b", "0.1 + 0.3 * b")},
    # ---- segmentation ----
    "threshold": {"a": _lin("level", 0.0, 1.0, 0.001, None, "keep v > a", "a"), "b": UNUSED},
    "otsu": {"a": UNUSED, "b": UNUSED},
    "dyn_threshold": {"a": _kernel("local-mean window"),
                      "b": _lin("offset", -0.2, 0.2, 0.001, None, "v > mean + (b−0.5)·0.4",
                                "(b - 0.5) * 0.4")},
    "adaptive_gauss_thresh": {"a": _lin("local " + _SIGMA, 1.0, 4.0, 0.01, "px",
                                        "Gaussian window σ = 1 + 3·a", "1.0 + 3.0 * a"),
                              "b": _lin("offset", -0.15, 0.15, 0.001, None,
                                        "v > blur + (b−0.5)·0.3", "(b - 0.5) * 0.3")},
    "canny": {"a": _lin("smooth " + _SIGMA, 0.5, 2.0, 0.01, "px", "pre-blur σ = 0.5 + 1.5·a",
                        "0.5 + 1.5 * a"),
              "b": _lin("edge threshold", 0.1, 0.6, 0.001, None, "gradient > 0.1 + 0.5·b",
                        "0.1 + 0.5 * b")},
    "local_max": {"a": _kernel("maximum-filter window"),
                  "b": _lin("min value", 0.3, 0.7, 0.001, None, "peak must exceed 0.3 + 0.4·b",
                            "0.3 + 0.4 * b")},
    "edges_sub_pix": {"a": _lin("gradient threshold", 0.15, 0.65, 0.001, None,
                                "edge band = gradient > 0.15 + 0.5·a", "0.15 + 0.5 * a"),
                      "b": UNUSED},
    "decode_barcode": {"a": _lin("dark level", 0.3, 0.7, 0.001, None, "bar = v < 0.3 + 0.4·a",
                                 "0.3 + 0.4 * a"), "b": UNUSED},
    # ---- binary region morphology ----
    "reg_erode": {"a": _iters("binary erosion iterations"), "b": UNUSED},
    "reg_dilate": {"a": _iters("binary dilation iterations"), "b": UNUSED},
    "reg_open": {"a": _iters("binary opening iterations"), "b": UNUSED},
    "reg_close": {"a": _iters("binary closing iterations"), "b": UNUSED},
    "convex_fill": {"a": _int_floor("iterations", 3, 6, doc="closing iterations = _it(a) + 2",
                                    source="1 + int(a * 3) + 2"), "b": UNUSED},
    "fill_holes": {"a": UNUSED, "b": UNUSED},
    "select_largest": {"a": UNUSED, "b": UNUSED},
    "remove_small": {"a": _lin("min area", 0.01, 0.16, 0.001, "of image",
                               "keep components ≥ (0.01 + 0.15·a)·pixels", "0.01 + 0.15 * a"),
                     "b": UNUSED},
    "invert_region": {"a": UNUSED, "b": UNUSED},
    "dist_transform": {"a": UNUSED, "b": UNUSED},
    "region_boundary": {"a": UNUSED, "b": UNUSED},
    "blob_count": {"a": UNUSED, "b": UNUSED},
    "area_frac": {"a": UNUSED, "b": UNUSED},
    "classify_shape": {"a": UNUSED, "b": UNUSED},
    # ---- contours ----
    "select_contours": {"a": _int_floor("min points", 3, 43, "pts", "keep contours with ≥ 3 + int(40·a) points",
                                        "3 + int(a * 40)"), "b": UNUSED},
    "smooth_contours": {"a": _int_floor("half-width", 1, 4, "pts", "moving-average half-width 1 + int(3·a)",
                                        "1 + int(a * 3)"), "b": UNUSED},
    "contours_to_region": {"a": _int_floor("dilation", 1, 3, "px", "rasterised contour dilated 1 + int(2·a)",
                                           "1 + int(a * 2)"), "b": UNUSED},
    "fit_line_contours": {"a": UNUSED, "b": UNUSED},
    "count_contours": {"a": UNUSED, "b": UNUSED},
    "total_length": {"a": UNUSED, "b": UNUSED},
    # ---- geometry ----
    "rotate_img": {"a": _lin("angle", -45.0, 45.0, 0.5, _DEG, "rotation = −45° + 90°·a (a=0.5 → 0°)",
                             "-45 + 90 * a"), "b": UNUSED},
    "rescale_img": {"a": _lin("scale", 0.7, 1.3, 0.01, "×", "isotropic factor s = 0.7 + 0.6·a",
                              "0.7 + 0.6 * a"),
                    "b": _spec("interpolation", "choice",
                               choices=["nearest (0)", "bilinear (1)", "cubic (3)", "cubic (3)"],
                               doc="spline order (0, 1, 3, 3)[min(3, int(4·b))]",
                               source="(0, 1, 3, 3)[min(3, int(b * 4))]")},
    "affine_warp": {"a": _lin("angle", -20.0, 20.0, 0.5, _DEG, "rotation = −20° + 40°·a", "-20 + 40 * a"),
                    "b": _lin("shear", -0.2, 0.2, 0.001, None, "shear = (b − 0.5)·0.4", "(b - 0.5) * 0.4")},
    # ---- misc / matching ----
    "identity": {"a": UNUSED, "b": UNUSED},
    "ncc_locate": {"a": UNUSED, "b": UNUSED},
    "shape_locate": {"a": UNUSED, "b": UNUSED},
    # ---- MCP physical-size entries (backend/alias ops) ----
    # These are source-derived just like the core entries above.  Keeping them in
    # this ledger lets every UI boundary enumerate the affected ops mechanically.
    "sk_rolling_ball": {
        "a": _int_floor("ball radius", 5, 25, "px",
                        "rolling-ball background radius = 5 + int(20*a)",
                        "5 + int(a * 20)"),
        "b": UNUSED,
    },
    "cv_tophat": {"a": _spec("structuring window", "choice",
                                choices=["3", "5", "7", "9"], unit="px",
                                doc="elliptic top-hat window, 3/5/7/9 px",
                                source="3 + 2 * int(a * 3)"), "b": UNUSED},
    "cv_blackhat": {"a": _spec("structuring window", "choice",
                                  choices=["3", "5", "7", "9"], unit="px",
                                  doc="elliptic black-hat window, 3/5/7/9 px",
                                  source="3 + 2 * int(a * 3)"), "b": UNUSED},
    "gray_tophat": {"a": _kernel("rectangular white top-hat window"), "b": UNUSED},
    "gray_bothat": {"a": _kernel("rectangular black top-hat window"), "b": UNUSED},
    # ---- volumes ----
    "vol_gaussian": {"a": _lin("blur " + _SIGMA, 0.3, 3.0, 0.01, "vx", "σ = 0.3 + 2.7·a", "0.3 + 2.7 * a"),
                     "b": BORDER},
    "vol_median": {"a": UNUSED, "b": UNUSED},
    "vol_threshold": {"a": _lin("level", 0.0, 1.0, 0.001, None, "keep v > a", "a"), "b": UNUSED},
    "vol_reg_dilate": {"a": _int_floor("iterations", 1, 4, doc="6-neighbour dilation iterations",
                                       source="max(1, 1 + int(a * 3))"), "b": UNUSED},
    "vol_reg_erode": {"a": _int_floor("iterations", 1, 4, doc="6-neighbour erosion iterations",
                                      source="max(1, 1 + int(a * 3))"), "b": UNUSED},
    "vol_dilation_ball": {"a": _int_floor("radius", 1, 4, "vx", "ball radius 1 + int(3·a)", "1 + int(a * 3)"),
                          "b": UNUSED},
    "vol_erosion_ball": {"a": _int_floor("radius", 1, 4, "vx", "ball radius 1 + int(3·a)", "1 + int(a * 3)"),
                         "b": UNUSED},
    "vol_opening_ball": {"a": _int_floor("radius", 1, 4, "vx", "ball radius 1 + int(3·a)", "1 + int(a * 3)"),
                         "b": UNUSED},
    "vol_mip": {"a": UNUSED, "b": UNUSED},
    "vol_count": {"a": UNUSED, "b": UNUSED},
    # ---- bool knobs (backends) ----
    "aug_barrel": {"a": _lin("distortion k", 0.0, 0.6, 0.001, None, "|k| = 0.6·a (0 = none)", "0.6 * a"),
                   "b": _spec("pincushion", "bool", doc="off = barrel (b < 0.5), on = pincushion (b ≥ 0.5)",
                              source="1.0 if b < 0.5 else -1.0", true_if=">=0.5")},
    "aug_rolling_shutter": {"a": _lin("peak shift", 0.0, 0.25, 0.001, "×W", "max row shift = 0.25·W·a",
                                      "0.25 * a"),
                            "b": _spec("pan left", "bool", doc="off = shift right (b < 0.5), on = left",
                                       source="1.0 if b < 0.5 else -1.0", true_if=">=0.5")},
    "tm_fbp_reconstruct": {"a": UNUSED,
                           "b": _spec("Shepp-Logan filter", "bool",
                                      doc="off = Ram-Lak ramp (b < 0.5), on = Shepp-Logan (b ≥ 0.5)",
                                      source='"ramp" if b < 0.5 else "shepp-logan"', true_if=">=0.5")},
    "sg_region_growing_seeded": {"a": _lin("tolerance", 0.0, 1.0, 0.001, None, "|v − seed| ≤ a", "a"),
                                 "b": _spec("8-connected", "bool", doc="off = 4-connected, on = 8 (b > 0.5)",
                                            source="2 if b > 0.5 else 1", true_if=">0.5")},
}


# Public MCP names for physical image-scale controls.  This is deliberately a
# ledger, not a name-pattern heuristic: aliases and backend ops are included only
# after their source formula and range have been entered in PARAM_SPECS above.
# Consumers enumerate this table and obtain ranges/units from PARAM_SPECS.
MCP_PHYSICAL_PARAMS: dict[str, dict[str, str]] = {
    "gaussian": {"sigma_px": "a"},
    "mean_box": {"window_px": "a"},
    "mean_box_wh": {"window_width_px": "a", "window_height_px": "b"},
    "gopen": {"window_px": "a"},
    "gclose": {"window_px": "a"},
    "tophat": {"window_px": "a"},
    "bothat": {"window_px": "a"},
    "gray_tophat": {"window_px": "a"},
    "gray_bothat": {"window_px": "a"},
    "cv_tophat": {"window_px": "a"},
    "cv_blackhat": {"window_px": "a"},
    "dyn_threshold": {"window_px": "a"},
    "adaptive_gauss_thresh": {"sigma_px": "a"},
    "sk_rolling_ball": {"radius_px": "a"},
}


def _mcp_physical_param_specs() -> dict[str, dict[str, dict[str, Any]]]:
    """Return the named MCP physical controls, enumerated from the op ledger."""
    return {
        op: {name: dict(PARAM_SPECS[op][knob], knob=knob)
             for name, knob in names.items()}
        for op, names in MCP_PHYSICAL_PARAMS.items()
    }


def hand_written_ops() -> list[str]:
    """Names of ops with a hand-written (source-verified) spec."""
    return sorted(PARAM_SPECS)


# --------------------------------------------------------------------------- #
# mapping helpers (pure functions; round-trip tested)
# --------------------------------------------------------------------------- #
def _clamp01(x) -> float:
    x = float(x)
    if not math.isfinite(x):
        return 0.0
    return 0.0 if x < 0.0 else 1.0 if x > 1.0 else x


def decimals_for(step) -> int:
    """Display decimals implied by a step (0.01 -> 2, 0.5 -> 1, 1 -> 0)."""
    try:
        s = float(step)
    except (TypeError, ValueError):
        return 3
    if s <= 0 or not math.isfinite(s):
        return 3
    d = 0
    while d < 6 and abs(round(s * 10 ** d) - s * 10 ** d) > 1e-9:
        d += 1
    return d


def knob_to_display(spec: dict, knob: float):
    """Map a 0..1 knob to the value the user sees (float / int / choice index / bool).

    Reproduces the op's own mapping for hand-written specs (asserted by the tests):
    ``"floor"`` ints are ``min + int(knob*(max-min))`` exactly as ``1 + int(a*3)``;
    ``"bucket"`` choices are ``min(n-1, int(knob*n))`` exactly as ``ops._k``."""
    k = _clamp01(knob)
    kind = spec.get("kind", "float")
    lo, hi = spec.get("min", 0.0), spec.get("max", 1.0)
    m = spec.get("map", "linear")
    if kind == "bool":
        return (k > 0.5) if spec.get("true_if") == ">0.5" else (k >= 0.5)
    if kind == "choice":
        n = len(spec.get("choices") or [])
        if n == 0:
            return 0
        if m == "half_then_thirds":
            return min(n - 1, half_then_thirds_index(k))
        return min(n - 1, int(k * n))
    if kind == "int":
        lo, hi = int(lo), int(hi)
        if m == "floor":
            return lo + int(k * (hi - lo))
        if m == "bucket":
            n = hi - lo + 1
            return lo + min(n - 1, int(k * n))
        return lo + int(round(k * (hi - lo)))
    # float / unused
    lo, hi = float(lo), float(hi)
    if m == "log" and lo > 0 and hi > 0:
        return lo * (hi / lo) ** k
    return lo + k * (hi - lo)


def display_to_knob(spec: dict, shown) -> float:
    """Inverse of :func:`knob_to_display`: the 0..1 knob that shows as *shown*.

    For quantised kinds (int floor / bucket, choice) the knob returned is the CENTRE
    of the interval that displays as *shown* (and exactly 1.0 for the floor-map top
    value, which the op only reaches at ``a == 1``), so
    ``knob_to_display(spec, display_to_knob(spec, d)) == d`` always holds."""
    kind = spec.get("kind", "float")
    lo, hi = spec.get("min", 0.0), spec.get("max", 1.0)
    m = spec.get("map", "linear")
    if kind == "bool":
        return 1.0 if bool(shown) else 0.0
    if kind == "choice":
        n = len(spec.get("choices") or [])
        if n <= 1:
            return 0.0
        i = min(n - 1, max(0, int(shown)))
        if m == "half_then_thirds":
            return _HALF_THEN_THIRDS_KNOB[min(i, len(_HALF_THEN_THIRDS_KNOB) - 1)]
        return _clamp01((i + 0.5) / n)
    if kind == "int":
        lo, hi = int(lo), int(hi)
        d = min(hi, max(lo, int(round(float(shown)))))
        if hi == lo:
            return 0.0
        if m == "floor":
            n = hi - lo
            return 1.0 if d == hi else _clamp01((d - lo + 0.5) / n)
        if m == "bucket":
            n = hi - lo + 1
            return _clamp01((d - lo + 0.5) / n)
        return _clamp01((d - lo) / (hi - lo))
    lo, hi = float(lo), float(hi)
    v = float(shown)
    if not math.isfinite(v):
        return 0.0
    v = min(max(v, min(lo, hi)), max(lo, hi))
    if hi == lo:
        return 0.0
    if m == "log" and lo > 0 and hi > 0:
        return _clamp01(math.log(v / lo) / math.log(hi / lo))
    return _clamp01((v - lo) / (hi - lo))


def format_display(spec: dict, knob: float) -> str:
    """Human string of the displayed value, rounded to the spec's step, with unit."""
    kind = spec.get("kind", "float")
    unit = spec.get("unit") or ""
    d = knob_to_display(spec, knob)
    if kind == "unused":
        return "–"
    if kind == "bool":
        return "on" if d else "off"
    if kind == "choice":
        ch = spec.get("choices") or []
        s = ch[d] if 0 <= d < len(ch) else str(d)
        return (s + " " + unit).strip()
    if kind == "int":
        return ("%d %s" % (d, unit)).strip()
    dec = decimals_for(spec.get("step", 0.001))
    return ("%.*f %s" % (dec, d, unit)).strip()


def spec_label(spec: dict, letter: str) -> str:
    """'a · blur σ' / 'a (–)' / 'a' for a knob letter and its spec."""
    lab = spec.get("label") or ""
    if spec.get("kind") == "unused":
        return "%s (–)" % letter
    return "%s · %s" % (letter, lab) if lab else letter


# --------------------------------------------------------------------------- #
# docs / docstring seeding (label-only, honest)
# --------------------------------------------------------------------------- #
_DOC_PATTERNS = [
    # - ``a`` — text  /  ``a`` = text  /  ``b`` — **name** text  (line-anchored)
    re.compile(r"^\s*[-*]?\s*``([ab])``\s*(?:—|-|=|:|–|->)\s*(.+?)\s*$"),
    # - **a**: text
    re.compile(r"^\s*[-*]?\s*\*\*([ab])\*\*\s*(?:—|-|=|:|–)\s*(.+?)\s*$"),
]
#: prose inside a docstring: "``a`` sets the number of steps", "``b`` selects the
#: rule", "``a`` = few photons" — the object phrase becomes the label
_PROSE_VERBS = ("sets", "selects", "picks", "controls", "scales", "chooses", "adds",
                "shifts", "mixes", "blends", "drops", "defaults", "gives", "drives",
                "steers", "tunes", "weights", "=", "->", "—", "–", ":")
_PROSE_RE = re.compile(
    r"``([ab])``\s*(?:" + "|".join(re.escape(v) for v in _PROSE_VERBS) + r")\s+(?:the\s+|a\s+|an\s+)?"
    r"([^.;,()`\n]{2,60})")
_UNUSED_RE = re.compile(r"``([ab])``\s*(?:is\s+)?(?:ignored|unused|not\s+used|不使用|未使用)")


_STOP_LABELS = {"the", "a", "an", "it", "it in", "in", "of", "to", "and", "which", "this"}


def _clean_label(text: str) -> str:
    """Trim a docstring phrase to a short label: stop at a formula / parenthesis /
    sentence end / stray number, cap at five words; '' when nothing usable remains."""
    t = re.sub(r"[`*]", "", text)
    t = re.split(r"\(|。|\s=\s|--|->|\s-\s|:\s|;", t)[0]
    t = re.split(r"(?<=[a-zA-Z])\.\s|\.$", t)[0]
    t = re.sub(r"\s+\d[\d.]*\s*[+\-*/·×]?.*$", "", t)     # "steps 1 + int(..." -> "steps"
    t = re.sub(r"\s+", " ", t).strip(" -—:=,")
    words = t.split(" ")
    if len(words) > 5:                                 # a prose object phrase: keep it short
        t = " ".join(words[:5])
    t = t.strip()
    if t.lower() in _STOP_LABELS or len(t) < 3:
        return ""
    return t[:40]


def _labels_from_text(text: str) -> dict[str, dict[str, str]]:
    """Extract ``{'a': {'label', 'doc'}, 'b': ...}`` from a docstring / markdown body.

    Structured bullet lines win; otherwise the first prose sentence that assigns a
    role to the knob; "``b`` is unused / ignored" yields ``{'label': '(unused)'}``."""
    out: dict[str, dict[str, str]] = {}
    text = text or ""
    for line in text.splitlines():
        for pat in _DOC_PATTERNS:
            mm = pat.match(line)
            if mm:
                letter, body = mm.group(1), mm.group(2)
                if letter in out or not body:
                    break
                if re.match(r"^\W*(?:is\s+)?(?:unused|ignored|not\s+used|不使用|未使用)", body, re.I):
                    out[letter] = {"label": "(unused)", "doc": re.sub(r"[`*]", "", body)[:200]}
                elif _clean_label(body):
                    out[letter] = {"label": _clean_label(body), "doc": re.sub(r"[`*]", "", body)[:200]}
                break
    flat = re.sub(r"\s+", " ", text)
    for mm in _UNUSED_RE.finditer(flat):
        out.setdefault(mm.group(1), {"label": "(unused)", "doc": mm.group(0).replace("`", "")})
    for mm in _PROSE_RE.finditer(flat):
        letter, body = mm.group(1), mm.group(2)
        if letter not in out and _clean_label(body):
            out[letter] = {"label": _clean_label(body), "doc": mm.group(0).replace("`", "")[:200]}
    return out


def _docs_root() -> str:
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "docs", "ops")


def _find_op_note(name: str, root: Optional[str] = None) -> Optional[str]:
    root = root or _docs_root()
    if not os.path.isdir(root):
        return None
    target = name + ".md"
    for dirpath, _dirs, files in os.walk(root):
        if target in files:
            return os.path.join(dirpath, target)
    return None


def _parameters_section(md: str) -> str:
    """The body of a '## Parameters' / '## パラメータ' section, or '' if absent."""
    m = re.search(r"^##+\s*(Parameters|パラメータ|引数)\s*$(.*?)(?=^##\s|\Z)", md, re.S | re.M | re.I)
    return m.group(2) if m else ""


def seed_from_docs(names=None, docs_root: Optional[str] = None) -> dict[str, dict[str, dict]]:
    """Mine LABEL-ONLY specs from op docstrings and ``docs/ops/**/<op>.md``.

    Returns ``{op: {"a": spec, "b": spec}}`` for every op where at least one knob got
    a label. Each spec is the generic 0..1 float presentation (no invented range)
    carrying the extracted label/doc and ``source="docstring"`` / ``"docs/ops"``.
    Never raises: an op whose source or note cannot be read is simply skipped."""
    try:
        import api
    except Exception:                                   # pragma: no cover - import guard
        return {}
    if names is None:
        try:
            names = [r["name"] for r in api.list_ops()]
        except Exception:
            return {}
    seeded: dict[str, dict[str, dict]] = {}
    for name in names:
        found: dict[str, dict[str, str]] = {}
        src = None
        try:
            op = api.find_op(name)
            fn = getattr(op, "fn", None)
            if fn is not None:
                fn = inspect.unwrap(fn)              # backends wrap ops in a _safe() guard
            doc = getattr(fn, "__doc__", None) or ""
        except Exception:
            doc = ""
        if doc:
            found = _labels_from_text(doc)
            src = "docstring" if found else None
        if not found:
            path = _find_op_note(name, docs_root)
            if path:
                try:
                    with open(path, encoding="utf-8") as fh:
                        sec = _parameters_section(fh.read())
                except OSError:
                    sec = ""
                if sec:
                    found = _labels_from_text(sec)
                    src = "docs/ops" if found else None
        if not found:
            continue
        entry = {}
        for letter in ("a", "b"):
            if letter in found:
                if found[letter]["label"] == "(unused)":
                    s = dict(UNUSED)
                else:
                    s = dict(GENERIC_FLOAT)
                    s["label"] = found[letter]["label"]
                s["doc"] = found[letter]["doc"]
                s["source"] = src
                entry[letter] = s
            else:
                entry[letter] = dict(GENERIC_FLOAT)
        seeded[name] = entry
    return seeded


@functools.lru_cache(maxsize=1)
def _seeded_cache() -> dict[str, dict[str, dict]]:
    try:
        return seed_from_docs()
    except Exception:                                   # never let seeding break the UI
        return {}


def spec_for(op_name: str, seeded: bool = True) -> dict[str, dict[str, Any]]:
    """``{"a": spec, "b": spec}`` for an op: hand-written table first, then the
    docs/docstring seeds (label only), then the generic 0..1 float pair."""
    hand = PARAM_SPECS.get(op_name)
    if hand is not None:
        return {"a": dict(hand["a"]), "b": dict(hand["b"])}
    if seeded:
        s = _seeded_cache().get(op_name)
        if s is not None:
            return {"a": dict(s["a"]), "b": dict(s["b"])}
    return {"a": dict(GENERIC_FLOAT), "b": dict(GENERIC_FLOAT)}


def is_generic(spec: dict) -> bool:
    """True for the plain 0..1 float presentation (hand-written or seeded label aside)."""
    return (spec.get("kind") == "float" and float(spec.get("min", 0)) == 0.0
            and float(spec.get("max", 1)) == 1.0 and spec.get("map", "linear") == "linear"
            and not spec.get("unit"))


def seeded_ops() -> list[str]:
    """Ops that received a label from docs/docstrings (and have no hand-written spec)."""
    return sorted(n for n in _seeded_cache() if n not in PARAM_SPECS)
