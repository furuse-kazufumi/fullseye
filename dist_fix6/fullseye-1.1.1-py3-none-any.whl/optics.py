# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""Optics operators for imaging systems and photonics (numpy + scipy only).

The layer *above* the lens and *below* the pixel. Industrial inspection and
Physical-AI perception both start with a decision nobody photographs — which
focal length, which f-number, how deep is the focus, how small can a defect be
before diffraction erases it, will the polariser kill the specular glare. Those
are closed-form calculations, and this module makes them first-class operators
in four families:

  * **geometric** — ``thin_lens`` / ``abcd_matrix`` / ``abcd_trace`` /
    ``depth_of_field`` / ``relative_illumination``: Gaussian imaging, paraxial
    ray transfer (the 2x2 ABCD algebra that composes a whole system), the
    photographic depth-of-field triple (near / far / hyperfocal) and the
    cos^4 natural-vignetting falloff.
  * **wave** — ``airy_pattern`` / ``angular_spectrum_propagate`` /
    ``fraunhofer_pattern`` / ``gaussian_beam`` / ``defocus_from_shift`` /
    ``pupil_psf`` / ``pupil_blur``: the diffraction-limited PSF of
    a circular pupil, exact scalar free-space propagation by the angular
    spectrum, the far-field pattern of an aperture, Gaussian-beam
    ``q``-parameter propagation (waist / wavefront radius / Gouy phase), and
    — added 2026-09-15 for the animal-eye series — the PSF of an **arbitrary
    pupil shape** (a W, a slit, an off-axis hole) with Seidel defocus, binned
    to a detector pitch, the axial-shift-to-waves conversion that feeds it,
    and the per-band image blur that composes the two into a chromatic
    imaging model.
  * **imaging** — ``psf_to_mtf`` / ``mtf_diffraction`` / ``wavefront_stats``:
    the PSF -> OTF -> MTF chain that turns a measured spot into a resolution
    curve, the closed-form diffraction MTF to compare it against, and the
    wavefront statistics (RMS / PV / Strehl by Marechal) of a Zernike fit.
  * **polarisation** — ``jones_element`` / ``jones_apply`` /
    ``stokes_from_jones`` / ``mueller_element`` / ``mueller_apply`` /
    ``stokes_analyze``: the Jones calculus for fully-polarised light and the
    Stokes/Mueller calculus that also carries *partially* polarised light,
    which is what a real polarisation camera measures.

Deliberately **not** here (already owned elsewhere — imported and composed, never
re-implemented):

  * **Ray-surface interaction** lives in :mod:`match3d`: ``reflect`` (specular
    reflection), ``refract`` (vector Snell), ``snell_angle``,
    ``fresnel_reflectance`` (unpolarised s/p average) and
    ``normal_from_reflection`` (deflectometry). This module is paraxial and
    scalar; when you need a real ray bent at a real surface, call those.
  * **Zernike *fitting*** is :func:`match3d.fit_zernike` (disk image ->
    ``{(n, m): coefficient}``). :func:`wavefront_stats` consumes exactly that
    dict and reports the statistics — it re-uses ``match3d``'s own basis
    builder, so the two cannot drift apart in convention.
  * **PSF deconvolution** is :mod:`volrestore` (``vol_gaussian_psf``,
    ``vol_richardson_lucy``) and :mod:`complexops` (``cx_wiener_deconvolve``).
    :func:`psf_to_mtf` only *characterises* a PSF; it does not deblur. The
    one *forward* blur that lives here, :func:`pupil_blur`, is here because
    its trap is optical, not numerical: the PSF's sample spacing is
    ``lambda N / oversample`` and must be binned to the detector pitch before
    it touches an image — that bookkeeping belongs next to the PSF maker.
    A generic image-times-kernel convolution it is not (that is
    ``filters_freq.convol_fft``).
  * **FFT and complex-image plumbing** is :mod:`complexops` (``cx_fft`` and
    friends, ``phase_unwrap``). :func:`angular_spectrum_propagate` uses numpy's
    FFT internally but its input/output are *fields*, not spectra.
  * **Phase-shifting interferometry / fringe projection** is :mod:`fringe`
    (``wrapped_phase`` is the general N-step algorithm, ``unwrap_phase_2d``,
    ``phase_to_height``). A 4-step PSI op here would be a duplicate.

Units are encoded in every parameter name — ``_mm``, ``_um``, ``_deg``,
``_mrad``, ``_per_mm`` — because a silent millimetre/micrometre swap is a
plausible-wrong answer, not a crash. Nothing is normalised behind your back and
nothing guesses a unit from magnitude.

Sign conventions, stated once (the traps):

  * **Imaging (:func:`thin_lens`)**: the real-is-positive convention. Object
    distance ``s_o > 0`` is measured from the lens toward the object, image
    distance ``s_i > 0`` on the far side. ``1/f = 1/s_o + 1/s_i``.
    Magnification ``m = -s_i / s_o`` — *negative m means the image is
    inverted*, which is the normal case for a real image. A diverging lens
    (``f < 0``) yields ``s_i < 0`` = a virtual image on the object side.
  * **Paraxial rays (:func:`abcd_matrix`)**: state ``[y, theta]`` with ``y`` in
    mm and ``theta`` in **radians** internally (the API takes and returns
    milliradians). Elements are listed **in the order light meets them**, and
    the product is formed right-to-left accordingly. ``det(M) = n_in / n_out``,
    so ``det = 1`` exactly when the system starts and ends in the same medium —
    that identity is the cheapest self-check there is.
  * **Wave propagation (:func:`angular_spectrum_propagate`)**: the
    ``exp(-i*omega*t)`` time convention, so forward propagation multiplies by
    ``exp(+i*k_z*z)``. Evanescent components are **attenuated**, not zeroed,
    with ``exp(-2*pi*|z|*sqrt(-arg))`` — that keeps ``z = 0`` an exact identity
    and makes a forward/backward round trip exact for a band-limited field.
  * **Polarisation**: ``S2 = 2*Re(Ex*conj(Ey))``, ``S3 = 2*Im(Ex*conj(Ey))``,
    so ``S3 > 0`` is right-circular in this (``exp(-i*omega*t)``) convention.
    A retarder is symmetric: ``diag(exp(-i*d/2), exp(+i*d/2))`` with the fast
    axis along x before rotation. The Jones and Mueller families are pinned
    against *each other* in the tests, which is the only way a sign slip in one
    of them gets caught.

Honest disclosure (what these ops cannot do):

  * **Every geometric op here is paraxial and thin.** No aberrations, no
    thickness, no pupil aberration, no vignetting from mechanical stops. A real
    lens departs from ``1/f = 1/s + 1/s'`` and from ``cos^4`` — treat these as
    the *design starting point*, not as a lens model. ``relative_illumination``
    in particular is the ideal cosine-fourth law; real wide-angle lenses are
    deliberately designed away from it.
  * **The Marechal Strehl approximation is only valid for small aberration.**
    ``exp(-(2*pi*sigma)^2)`` is a series truncation; past roughly 0.1 waves RMS
    it overestimates. :func:`wavefront_stats` returns ``marechal_valid`` saying
    whether you are inside that range instead of quietly handing you a number.
  * **The scalar diffraction model ignores polarisation and high NA.** The
    angular spectrum is exact for a scalar field, but a real high-NA system
    needs a vector treatment; ``mtf_diffraction`` and ``airy_pattern`` assume a
    circular, unobstructed, aberration-free pupil.
  * **Two ops return a documented infinity** (never a silent one):
    :func:`depth_of_field` returns ``far_mm = inf`` at or beyond the hyperfocal
    distance, and :func:`gaussian_beam` returns ``wavefront_radius_mm = inf``
    at the waist, because a plane wavefront *is* infinite radius. Both also
    report a finite reciprocal so downstream arithmetic has a safe path.

Fail-closed on untrusted input, like every Fullseye module: units and shapes are
exact, NaN/Inf are rejected on the way in, a zero focal length / zero radius /
non-positive refractive index / opaque aperture / unphysical Stokes vector all
raise an explicit ``ValueError`` naming the problem — never a silent NaN, a
silent clamp, or a silent zero-division. Grid sizes are capped
(:data:`MAX_GRID`, :data:`MAX_FIELD_ELEMENTS`) so a mistyped exponent fails
instead of allocating the machine's memory.
"""
from __future__ import annotations

import warnings

import numpy as np

__all__ = [
    "thin_lens", "abcd_matrix", "abcd_trace", "depth_of_field",
    "relative_illumination",
    "airy_pattern", "angular_spectrum_propagate", "fraunhofer_pattern",
    "gaussian_beam", "defocus_from_shift", "pupil_psf", "pupil_blur",
    "fourier_plane_filter", "four_f_filter",
    "psf_to_mtf", "mtf_diffraction", "wavefront_stats",
    "encircled_energy", "ensquared_energy", "energy_radii", "mtf_tangential_sagittal",
    "jones_element", "jones_apply", "stokes_from_jones",
    "mueller_element", "mueller_apply", "stokes_analyze", "mueller_partial_polarizer",
    "polarization_demosaic", "polarization_demosaic_color", "mueller_from_intensities", "mueller_checks",
    "POLARIZATION_MOSAIC_LAYOUT", "POLARIZATION_SWEEP_ANGLES",
    "OPTICS", "MAX_GRID", "MAX_FIELD_ELEMENTS", "MAX_SYSTEM_ELEMENTS",
    "MAX_ZERNIKE_TERMS", "MAX_ZERNIKE_ORDER", "MAX_ZERNIKE_BASIS",
    "MAX_PUPIL_FFT", "MAX_WAVES_PER_SAMPLE",
    "JONES_KINDS", "MUELLER_KINDS", "FOURIER_PLANE_KINDS",
]

#: The public optics operators, by name (introspection / facade wiring).
OPTICS = [
    "thin_lens", "abcd_matrix", "abcd_trace", "depth_of_field",
    "relative_illumination",
    "airy_pattern", "angular_spectrum_propagate", "fraunhofer_pattern",
    "gaussian_beam", "defocus_from_shift", "pupil_psf", "pupil_blur",
    "fourier_plane_filter", "four_f_filter",
    "psf_to_mtf", "mtf_diffraction", "wavefront_stats",
    "encircled_energy", "ensquared_energy", "energy_radii", "mtf_tangential_sagittal",
    "jones_element", "jones_apply", "stokes_from_jones",
    "mueller_element", "mueller_apply", "stokes_analyze", "mueller_partial_polarizer",
    "polarization_demosaic", "polarization_demosaic_color", "mueller_from_intensities", "mueller_checks",
]

#: Largest side length for a *generated* grid (Airy pattern, sampled curves).
#: 4096^2 float64 = 128 MB, which is already past useful for a design aid.
MAX_GRID = 4096

#: Largest element count for a *supplied* field / PSF / aperture (2^24 elements
#: = 128 MB complex128 per FFT temporary, and the angular spectrum needs three).
MAX_FIELD_ELEMENTS = 1 << 24

#: Largest number of elements in one ABCD system description.
MAX_SYSTEM_ELEMENTS = 1024

#: Largest number of Zernike terms :func:`wavefront_stats` will accept.
MAX_ZERNIKE_TERMS = 512

#: Largest radial order ``n`` :func:`wavefront_stats` will accept. The shared
#: basis builder (``match3d._zernike_basis``) evaluates the radial polynomial
#: from its factorial definition, which cancels catastrophically at high order:
#: measured 2026-09-01, ``max|Z_n^m|`` over the unit disk is exactly 1.0 (the
#: analytic bound) through ``n = 44``, then 1.41 at ``n = 46``, 71.5 at
#: ``n = 50`` and 2.8e5 at ``n = 60``. Past the cap the numbers are garbage that
#: looks like a wavefront, so they are refused rather than returned.
MAX_ZERNIKE_ORDER = 40

#: Largest working set (float64 elements) for the Zernike basis
#: :func:`wavefront_stats` builds. The builder evaluates *every* ``(n, m)`` up to
#: ``n_max`` on the whole polar grid, so the allocation is
#: ``(n_max+1)(n_max+2)/2 * radial * angular`` — quadratic in an argument that
#: looks innocent. 2^25 elements = 268 MB, which admits ``n_max = 40`` on the
#: default grid (21 M) and refuses ``n_max = 40`` at 4096x4096 (1.4e10 = 108 GB).
MAX_ZERNIKE_BASIS = 1 << 25

#: Jones element kinds accepted by :func:`jones_element`.
JONES_KINDS = ("polarizer", "retarder", "quarter_wave", "half_wave", "rotator")

#: Mueller element kinds accepted by :func:`mueller_element`. Note the extra
#: ``depolarizer``: it has **no** Jones counterpart, which is precisely why the
#: Mueller calculus exists (Jones can only describe fully polarised light).
MUELLER_KINDS = ("polarizer", "retarder", "quarter_wave", "half_wave",
                 "rotator", "depolarizer")

#: Marechal's approximation is a truncated series; past this RMS (in waves) the
#: Strehl it predicts is optimistic. Reported as ``marechal_valid``, not hidden.
MARECHAL_RMS_LIMIT = 0.1


# --------------------------------------------------------------------------- #
# fail-closed input helpers                                                    #
# --------------------------------------------------------------------------- #
def _finite_scalar(v, name: str) -> float:
    """A real, finite Python float — or ``ValueError`` naming the problem."""
    if np.ma.is_masked(v):
        raise ValueError("%s is a masked value — fill or drop it explicitly" % (name,))
    if isinstance(v, (complex, np.complexfloating)):
        raise ValueError("%s is complex — an optical length/angle is a real "
                         "quantity; coercion would silently drop the imaginary "
                         "part" % (name,))
    if isinstance(v, (bool, np.bool_)):
        raise ValueError("%s is a bool — refusing the silent True==1 promotion"
                         % (name,))
    if isinstance(v, (str, bytes, np.str_, np.bytes_)):
        # float("50") succeeds, so without this a *string* passes as a length
        # and the caller never learns their config was never parsed. Confirmed
        # by the 2026-09-01 adversarial pass: thin_lens("50", "200") returned a
        # perfectly plausible 66.667 mm.
        raise ValueError("%s is a string (%r) — a length/angle must be a number; "
                         "float('50') would silently succeed and hide an "
                         "unparsed configuration value" % (name, v))
    try:
        f = float(v)
    except (TypeError, ValueError):
        raise ValueError("%s must be a real scalar, got %r"
                         % (name, type(v).__name__)) from None
    if not np.isfinite(f):
        raise ValueError("%s must be finite, got %r (NaN/Inf would propagate "
                         "through every result)" % (name, v))
    return f


def _positive(v, name: str) -> float:
    f = _finite_scalar(v, name)
    if f <= 0.0:
        raise ValueError("%s must be > 0, got %g" % (name, f))
    return f


def _nonzero(v, name: str, why: str) -> float:
    f = _finite_scalar(v, name)
    if f == 0.0:
        raise ValueError("%s must not be 0 — %s" % (name, why))
    return f


def _count(v, name: str, lo: int, hi: int) -> int:
    if isinstance(v, (bool, np.bool_)) or not isinstance(v, (int, np.integer)):
        raise ValueError("%s must be an int, got %r" % (name, type(v).__name__))
    n = int(v)
    if n < lo or n > hi:
        raise ValueError("%s must be in [%d, %d], got %d (the cap is there so a "
                         "mistyped exponent fails instead of allocating "
                         "gigabytes)" % (name, lo, hi, n))
    return n


def _as_float_array(a, name: str) -> np.ndarray:
    """Coerce to float64, refusing the two silent-truncation traps."""
    if np.ma.is_masked(a):
        raise ValueError("%s is a masked array with masked (invalid) entries — "
                         "coercion would strip the mask and use the raw values "
                         "underneath; fill or drop them explicitly" % (name,))
    if np.iscomplexobj(a):
        raise ValueError("%s is complex — coercion to float64 would silently "
                         "discard the imaginary part; take .real/.imag/abs() "
                         "explicitly" % (name,))
    arr = np.ascontiguousarray(a, dtype=np.float64)
    if not np.isfinite(arr).all():
        n = int((~np.isfinite(arr)).sum())
        raise ValueError("%s has %d non-finite value(s) (NaN/Inf) — refusing"
                         % (name, n))
    return arr


def _as_complex_array(a, name: str) -> np.ndarray:
    """Coerce to complex128 (real input is promoted, which loses nothing)."""
    if np.ma.is_masked(a):
        raise ValueError("%s is a masked array with masked (invalid) entries — "
                         "fill or drop them explicitly" % (name,))
    arr = np.ascontiguousarray(a, dtype=np.complex128)
    if not np.isfinite(arr).all():
        n = int((~np.isfinite(arr)).sum())
        raise ValueError("%s has %d non-finite value(s) (NaN/Inf) — refusing"
                         % (name, n))
    return arr


def _require_image(a, name: str, op: str, complex_ok: bool = False) -> np.ndarray:
    """A strictly 2-D, at-least-2x2, finite, size-capped array."""
    arr = _as_complex_array(a, name) if complex_ok else _as_float_array(a, name)
    if arr.ndim != 2:
        raise ValueError("%s: %s must be a 2-D array, got a %d-D array of shape "
                         "%r — nothing is reshaped silently"
                         % (op, name, arr.ndim, tuple(np.shape(a))))
    if arr.shape[0] < 2 or arr.shape[1] < 2:
        raise ValueError("%s: %s must be at least 2x2, got %dx%d (a 1-pixel-wide "
                         "grid has no sampled spatial frequency)"
                         % (op, name, arr.shape[0], arr.shape[1]))
    if arr.size > MAX_FIELD_ELEMENTS:
        raise ValueError("%s: %s has %d elements (shape %r), over the %d cap "
                         "(optics.MAX_FIELD_ELEMENTS)"
                         % (op, name, arr.size, arr.shape, MAX_FIELD_ELEMENTS))
    return arr


def _require_vec(a, name: str, op: str, length: int,
                 complex_ok: bool = False) -> np.ndarray:
    """A strictly 1-D vector of exactly *length* components."""
    arr = _as_complex_array(a, name) if complex_ok else _as_float_array(a, name)
    if arr.ndim != 1:
        raise ValueError("%s: %s must be a 1-D vector, got a %d-D array of shape "
                         "%r" % (op, name, arr.ndim, tuple(np.shape(a))))
    if arr.size != length:
        raise ValueError("%s: %s must have exactly %d component(s), got %d"
                         % (op, name, length, arr.size))
    return arr


# --------------------------------------------------------------------------- #
# geometric optics                                                             #
# --------------------------------------------------------------------------- #
def thin_lens(focal_mm=50.0, object_mm=200.0):
    """Gaussian thin-lens imaging: where the image lands and how big it is.

    Solves ``1/f = 1/s_o + 1/s_i`` in the **real-is-positive** convention:
    *object_mm* (``s_o``) is the lens-to-object distance and must be positive;
    the returned ``image_mm`` (``s_i``) is positive for a real image on the far
    side of the lens and **negative for a virtual image** on the object side
    (which is what a diverging lens, ``focal_mm < 0``, always produces).

    Returns a dict: ``image_mm`` · ``magnification`` ``m = -s_i/s_o``
    (*negative = inverted*, the normal case for a real image; ``|m| < 1`` is a
    demagnified, i.e. machine-vision, geometry) · ``object_mm`` and
    ``focal_mm`` echoed back so a table of results is self-describing ·
    ``working_distance_mm`` ``= s_o + s_i`` for a real image, the
    object-to-sensor span a machine builder actually has to fit.

    Ground truth it reproduces exactly (verified in ``tests/test_optics.py``):
    ``f = 50, s_o = 200`` gives ``s_i = 200/3 = 66.6667`` and ``m = -1/3``; at
    ``s_o = 2f`` the image is at ``2f`` with ``m = -1`` (the 1:1 conjugate);
    the reciprocal identity ``1/f - 1/s_o - 1/s_i`` is 0 to machine precision
    over the whole tested range.

    **Raises** ``ValueError``: ``focal_mm == 0`` (not a lens), non-positive or
    non-finite *object_mm*, and — explicitly, instead of returning ``inf`` —
    ``object_mm == focal_mm``, where the object sits at the front focal point
    and images at infinity (a collimator, not an imaging conjugate).

    Paraxial and thin: no aberration, no principal-plane separation. HALCON has
    no equivalent (its camera model starts after the lens, at the projection).
    """
    f = _nonzero(focal_mm, "focal_mm",
                 "a zero focal length is not a lens (infinite power)")
    s_o = _positive(object_mm, "object_mm")
    denom = s_o - f
    if denom == 0.0:
        raise ValueError("thin_lens: object_mm == focal_mm (%g) — the object is "
                         "at the front focal point and images at infinity; that "
                         "is a collimator, not an imaging conjugate (refusing to "
                         "return inf)" % (f,))
    s_i = f * s_o / denom
    m = -s_i / s_o
    return {"image_mm": float(s_i), "magnification": float(m),
            "object_mm": float(s_o), "focal_mm": float(f),
            "working_distance_mm": float(s_o + s_i)}


def _element_matrix(el, index: int) -> tuple:
    """One ABCD element -> (2x2 matrix, n_in, n_out). Fail-closed on anything else."""
    if isinstance(el, str) or not isinstance(el, (list, tuple, np.ndarray)):
        raise ValueError("abcd_matrix: element %d must be a sequence like "
                         "('free', 100.0), got %r" % (index, type(el).__name__))
    seq = list(el)
    if not seq:
        raise ValueError("abcd_matrix: element %d is empty" % (index,))
    kind = seq[0]
    if not isinstance(kind, str):
        raise ValueError("abcd_matrix: element %d must start with a kind string "
                         "(one of free/lens/mirror/interface/curved), got %r"
                         % (index, type(kind).__name__))
    kind = kind.strip().lower()
    name = "abcd_matrix element %d (%s)" % (index, kind)

    def _need(n):
        if len(seq) != n + 1:
            raise ValueError("abcd_matrix: element %d kind %r takes %d "
                             "parameter(s), got %d" % (index, kind, n, len(seq) - 1))

    if kind == "free":
        _need(1)
        d = _finite_scalar(seq[1], name + " distance_mm")
        if d < 0.0:
            raise ValueError("abcd_matrix: element %d free-space distance must "
                             "be >= 0, got %g (light does not run backwards; "
                             "reverse the element order instead)" % (index, d))
        return np.array([[1.0, d], [0.0, 1.0]]), 1.0, 1.0
    if kind == "lens":
        _need(1)
        f = _nonzero(seq[1], name + " focal_mm",
                     "a zero focal length is infinite power")
        return np.array([[1.0, 0.0], [-1.0 / f, 1.0]]), 1.0, 1.0
    if kind == "mirror":
        _need(1)
        r = _nonzero(seq[1], name + " radius_mm",
                     "a zero radius of curvature is a point, not a mirror "
                     "(use ('free', 0.0) for a flat mirror in the unfolded system)")
        return np.array([[1.0, 0.0], [-2.0 / r, 1.0]]), 1.0, 1.0
    if kind == "interface":
        _need(2)
        n1 = _positive(seq[1], name + " n1")
        n2 = _positive(seq[2], name + " n2")
        return np.array([[1.0, 0.0], [0.0, n1 / n2]]), n1, n2
    if kind == "curved":
        _need(3)
        n1 = _positive(seq[1], name + " n1")
        n2 = _positive(seq[2], name + " n2")
        r = _nonzero(seq[3], name + " radius_mm",
                     "a zero radius is a point; use kind 'interface' for a flat "
                     "surface")
        return (np.array([[1.0, 0.0], [(n1 - n2) / (n2 * r), n1 / n2]]), n1, n2)
    raise ValueError("abcd_matrix: element %d has unknown kind %r — expected one "
                     "of free/lens/mirror/interface/curved" % (index, kind))


def abcd_matrix(elements):
    """Compose a paraxial system into one 2x2 ray-transfer (ABCD) matrix.

    *elements* is a sequence of ``(kind, *params)`` **in the order light meets
    them** (the matrix product is formed right-to-left accordingly, so the list
    reads like the optical layout, not like the algebra):

    ``("free", d_mm)`` free-space / homogeneous medium of length ``d >= 0`` ·
    ``("lens", f_mm)`` thin lens of focal length ``f != 0`` (negative =
    diverging) · ``("mirror", r_mm)`` curved mirror of radius ``r`` in the
    unfolded system (power ``-2/r``) · ``("interface", n1, n2)`` flat refracting
    surface · ``("curved", n1, n2, r_mm)`` curved refracting surface.

    Returns a ``(2, 2)`` float64 matrix acting on the ray state
    ``[y_mm, theta_rad]`` — feed it to :func:`abcd_trace`, which handles the
    milliradian conversion at the API boundary.

    Ground truth it reproduces exactly: a single free-space section is
    ``[[1, d], [0, 1]]``; ``det(M) = n_in / n_out``, hence **exactly 1** for any
    system that starts and ends in the same medium (checked to ~1e-16 in the
    tests, and the cheapest correctness self-check you have); two thin lenses
    separated by ``d`` compose to the classical combined power
    ``1/f = 1/f1 + 1/f2 - d/(f1*f2)``; a lens sandwiched between two
    free-space sections of length ``f`` gives the ``[[0, f], [-1/f, 0]]``
    Fourier-transform geometry.

    **Raises** ``ValueError``: an empty system, more than
    :data:`MAX_SYSTEM_ELEMENTS` elements, an element that is not a sequence, an
    unknown kind, the wrong parameter count for a kind, a negative free-space
    distance (reverse the list instead of running light backwards), a zero
    focal length or radius, a non-positive refractive index, or any non-finite
    parameter.

    HALCON: no equivalent (its optics stop at the pinhole camera model).
    """
    if isinstance(elements, (str, bytes)) or not isinstance(
            elements, (list, tuple, np.ndarray)):
        raise ValueError("abcd_matrix: elements must be a sequence of "
                         "(kind, *params) tuples, got %r"
                         % (type(elements).__name__,))
    seq = list(elements)
    if not seq:
        raise ValueError("abcd_matrix: the system is empty — an optical system "
                         "with no elements has no ray-transfer matrix (pass "
                         "[('free', 0.0)] if you want the identity)")
    if len(seq) > MAX_SYSTEM_ELEMENTS:
        raise ValueError("abcd_matrix: %d elements exceeds the %d cap "
                         "(optics.MAX_SYSTEM_ELEMENTS)"
                         % (len(seq), MAX_SYSTEM_ELEMENTS))
    total = np.eye(2, dtype=np.float64)
    for i, el in enumerate(seq):
        m, _n1, _n2 = _element_matrix(el, i)
        total = m @ total                      # light meets seq[0] first
    if not np.isfinite(total).all():
        raise ValueError("abcd_matrix: the composed matrix overflowed float64 — "
                         "the system mixes lengths and powers many orders of "
                         "magnitude apart; rescale to consistent millimetres")
    return np.ascontiguousarray(total, dtype=np.float64)


def abcd_trace(matrix, height_mm=1.0, angle_mrad=0.0):
    """Propagate one paraxial ray through an ABCD matrix.

    Applies ``[y', theta'] = M @ [y, theta]`` with ``y`` in millimetres and
    ``theta`` in radians internally; the API speaks **milliradians** because a
    paraxial angle is small by definition and mrad keeps the numbers readable.

    Returns a dict: ``height_mm`` and ``angle_mrad`` of the outgoing ray ·
    ``determinant`` of *M* (``= n_in/n_out``; a value that is not 1 for a
    same-medium system means the matrix is wrong, so it is reported rather than
    assumed) · ``imaging`` — True when ``|B| <= 1e-12 * (1 + |A| + |B| + |C| + |D|)``,
    i.e. the output height does not depend on the input angle, which is the
    definition of a conjugate (image) plane.

    Ground truth it reproduces exactly: free space of length ``d`` gives
    ``y' = y + d*theta`` and ``theta' = theta``; a thin lens leaves ``y``
    untouched and bends the ray by ``-y/f``; a ray parallel to the axis
    (``angle_mrad = 0``) entering a lens crosses the axis exactly one focal
    length behind it.

    **Raises** ``ValueError``: *matrix* is not ``(2, 2)``, is complex or masked,
    holds NaN/Inf, or has a determinant of 0 (a system that collapses every ray
    to a point is not a ray-transfer matrix); non-finite *height_mm* /
    *angle_mrad*; a result that overflowed float64.
    """
    m = _as_float_array(matrix, "matrix")
    if m.shape != (2, 2):
        raise ValueError("abcd_trace: matrix must be (2, 2), got shape %r — an "
                         "ABCD matrix is 2x2 by construction (build one with "
                         "abcd_matrix)" % (m.shape,))
    y = _finite_scalar(height_mm, "height_mm")
    th = _finite_scalar(angle_mrad, "angle_mrad") * 1e-3
    with np.errstate(over="ignore", invalid="ignore"):
        det = float(m[0, 0] * m[1, 1] - m[0, 1] * m[1, 0])
    if not np.isfinite(det):
        # Confirmed 2026-09-01: diag(1e200, 1e200) traced a *finite* ray while
        # handing back determinant = inf in the dict — a silent non-finite that
        # every downstream check would have believed.
        raise ValueError("abcd_trace: the determinant overflowed float64 "
                         "(matrix entries up to %g) — this is not a physically "
                         "scaled ray-transfer matrix; work in millimetres"
                         % (float(np.abs(m).max()),))
    if det == 0.0:
        raise ValueError("abcd_trace: matrix is singular (det = 0) — a "
                         "ray-transfer matrix has det = n_in/n_out > 0; this "
                         "one maps every ray onto a single state")
    out = m @ np.array([y, th], dtype=np.float64)
    if not np.isfinite(out).all():
        raise ValueError("abcd_trace: the traced ray overflowed float64 "
                         "(y=%g mm, theta=%g mrad through a matrix of norm %g)"
                         % (y, th * 1e3, float(np.abs(m).max())))
    scale = 1.0 + float(np.abs(m).sum())
    return {"height_mm": float(out[0]), "angle_mrad": float(out[1] * 1e3),
            "determinant": det, "imaging": bool(abs(m[0, 1]) <= 1e-12 * scale)}


def depth_of_field(focal_mm=50.0, f_number=8.0, subject_mm=2000.0, coc_mm=0.03):
    """Photographic depth of field: near limit, far limit and hyperfocal distance.

    The classical circle-of-confusion model. With ``H = f^2/(N*c) + f`` the
    hyperfocal distance and ``s`` the focused subject distance:

    ``near = s*(H - f) / (H + s - 2f)`` and ``far = s*(H - f) / (H - s)``.

    Returns a dict: ``near_mm`` · ``far_mm`` · ``depth_mm`` (``far - near``) ·
    ``hyperfocal_mm`` · ``far_is_infinite`` (a bool, so a caller never has to
    test for ``inf`` by accident).

    **``far_mm`` is ``inf`` at or beyond the hyperfocal distance, by contract,
    not by accident** — focus at ``H`` and everything from ``H/2`` to infinity
    is acceptably sharp, which is the whole point of the hyperfocal distance.
    ``depth_mm`` is then ``inf`` too. ``far_is_infinite`` says so explicitly,
    and the identity ``near(H) == H/2`` is exact (verified in the tests).

    *coc_mm* is the acceptable circle of confusion **in the image plane**: the
    35 mm convention is 0.03 mm, a machine-vision rule of thumb is 1-2 pixel
    pitches. It is a *choice*, not a property of the lens — halve it and the
    depth of field halves with it, which is why two depth-of-field calculators
    disagree.

    Ground truth: ``f = 50, N = 8, c = 0.03`` gives ``H = 10466.67 mm``; at
    ``s = H`` the near limit is exactly ``H/2 = 5233.33 mm`` and the far limit
    is ``inf``; the near/far limits bracket the subject for every ``s < H``.

    **Raises** ``ValueError``: non-positive or non-finite *focal_mm*,
    *f_number*, *subject_mm*, *coc_mm*; ``subject_mm <= focal_mm`` (an object
    inside the front focal length cannot be imaged by this lens — see
    :func:`thin_lens`); a hyperfocal distance that is not greater than the
    focal length (a degenerate combination of ``N`` and ``c``).

    Paraxial, thin, and blur-circle based: it ignores diffraction, which for
    small apertures becomes the real resolution limit — compare with
    :func:`mtf_diffraction` before trusting an ``N = 22`` calculation.
    """
    f = _positive(focal_mm, "focal_mm")
    n = _positive(f_number, "f_number")
    s = _positive(subject_mm, "subject_mm")
    c = _positive(coc_mm, "coc_mm")
    if s <= f:
        raise ValueError("depth_of_field: subject_mm (%g) must be greater than "
                         "focal_mm (%g) — an object at or inside the front focal "
                         "length has no real image (see thin_lens)" % (s, f))
    h = f * f / (n * c) + f
    if h <= f:
        raise ValueError("depth_of_field: the hyperfocal distance (%g mm) is not "
                         "greater than the focal length — f_number*coc_mm is far "
                         "too large for this lens" % (h,))
    near = s * (h - f) / (h + s - 2.0 * f)
    if s >= h:
        far = float("inf")
        depth = float("inf")
    else:
        far = s * (h - f) / (h - s)
        depth = far - near
    return {"near_mm": float(near), "far_mm": float(far), "depth_mm": float(depth),
            "hyperfocal_mm": float(h), "far_is_infinite": bool(s >= h)}


def relative_illumination(half_angle_deg=20.0, samples=64, exponent=4.0):
    """Natural vignetting: relative image-plane illuminance versus field angle.

    The cosine-fourth law ``E(theta)/E(0) = cos(theta)^4`` — one cosine from the
    inverse-square increase in distance to the off-axis point (twice), one from
    the tilt of the exit pupil as seen from there, one from the tilt of the
    image plane. Sampled uniformly in angle from 0 to *half_angle_deg*.

    Returns an ``(samples, 2)`` float64 ``pairs`` array: column 0 the field
    angle in degrees, column 1 the relative illuminance in [0, 1].

    *exponent* exists because the fourth power is the *ideal symmetric* case:
    a lens with pupil aberration, or a telecentric design, or one with a tilted
    entrance pupil, falls off closer to ``cos^3`` (or is deliberately corrected
    flatter still). Setting the exponent is how you say which lens you have —
    it is not a fudge factor to be tuned after the fact.

    Ground truth it reproduces exactly: ``cos^4(45 deg) = 1/4`` and
    ``cos^4(60 deg) = 1/16``, both to machine precision; the curve is 1.0 on
    axis and monotonically decreasing.

    **Raises** ``ValueError``: *half_angle_deg* outside ``(0, 90)`` — at 90
    degrees the illuminance is exactly 0 and the "relative" curve carries no
    information; *samples* outside ``[2, MAX_GRID]``; a negative or non-finite
    *exponent*.

    This is the *natural* falloff only. Mechanical vignetting (a stop clipping
    the oblique beam) is a separate, lens-specific effect that no closed form
    covers — measure it with a flat field.
    """
    a = _finite_scalar(half_angle_deg, "half_angle_deg")
    if not (0.0 < a < 90.0):
        raise ValueError("relative_illumination: half_angle_deg must be in "
                         "(0, 90), got %g (at 90 deg the illuminance is exactly "
                         "0 and the relative curve is meaningless)" % (a,))
    n = _count(samples, "samples", 2, MAX_GRID)
    p = _finite_scalar(exponent, "exponent")
    if p < 0.0:
        raise ValueError("relative_illumination: exponent must be >= 0, got %g "
                         "(a negative exponent would brighten the corners)" % (p,))
    ang = np.linspace(0.0, a, n)
    rel = np.cos(np.radians(ang)) ** p
    return np.ascontiguousarray(np.column_stack([ang, rel]), dtype=np.float64)


# --------------------------------------------------------------------------- #
# wave optics                                                                  #
# --------------------------------------------------------------------------- #
def airy_pattern(size=64, wavelength_um=0.55, f_number=5.6, pixel_pitch_um=0.5):
    """The diffraction-limited PSF of a circular pupil (Airy pattern).

    ``I(r) = [2*J1(v)/v]^2`` with ``v = pi*r/(lambda*N)``, ``r`` the radial
    distance in the image plane, ``N`` the working f-number. Sampled on a
    ``size x size`` grid centred between pixels for even *size* and on a pixel
    for odd *size*. The normalisation is **analytic** (``I(0) = 1`` by the
    ``v -> 0`` limit), not a division by the sampled maximum: for odd *size*
    the centre pixel is therefore exactly 1.0, and for even *size* the true
    peak falls between pixels so the largest *sample* is below it (0.9679 at
    ``size = 8`` with the defaults, measured). Rescaling to the sampled maximum
    instead would quietly change the physics with the parity of the grid.

    Returns a ``(size, size)`` float64 intensity image.

    Ground truth it reproduces (measured, ``tests/test_optics.py``): the first
    dark ring sits at the first zero of ``J1``, ``r = 1.2197*lambda*N`` — at
    ``lambda = 0.55 um``, ``N = 5.6`` that is ``3.7567 um``, and the sampled
    radial minimum lands at ``3.760 um`` on a 0.01 um grid (0.3 of a sample
    away, which is the sampling, not an error); the peak is exactly 1.0 at the
    centre and the pattern is symmetric to 1e-16.

    The encircled energy inside that ring is the textbook 83.8% of the *whole
    infinite* pattern — which a finite grid cannot measure: the Airy tails fall
    off only as ``1/r^3``, so a 25.6 um half-width grid reports 0.857 and a
    51.2 um one 0.847 (both measured). The number is quoted here as physics,
    not as something this op returns.

    The ``v -> 0`` limit is evaluated **explicitly** as 1.0 rather than left to
    ``0/0``: that division is the classic silent-NaN in every hand-rolled Airy
    routine, and the centre pixel is exactly where it bites.

    **Raises** ``ValueError``: *size* outside ``[2, MAX_GRID]``; non-positive or
    non-finite *wavelength_um*, *f_number*, *pixel_pitch_um*.

    Scalar, aberration-free, unobstructed circular pupil, low NA. A central
    obscuration (a mirror telescope) changes the ring structure; high NA needs a
    vector treatment. For the *measured* PSF of a real system use
    :func:`psf_to_mtf` on an image of a point source instead.
    """
    from scipy.special import j1                      # scipy is a hard dependency

    n = _count(size, "size", 2, MAX_GRID)
    lam = _positive(wavelength_um, "wavelength_um")
    fn = _positive(f_number, "f_number")
    pitch = _positive(pixel_pitch_um, "pixel_pitch_um")
    c = (n - 1) / 2.0
    ax = (np.arange(n, dtype=np.float64) - c) * pitch
    r = np.hypot(ax[:, None], ax[None, :])
    v = np.pi * r / (lam * fn)
    out = np.ones_like(v)
    nz = v != 0.0                                     # the 0/0 limit is 1, not NaN
    out[nz] = (2.0 * j1(v[nz]) / v[nz]) ** 2
    return np.ascontiguousarray(out, dtype=np.float64)


def angular_spectrum_propagate(field, wavelength_um=0.55, distance_um=100.0,
                               pixel_pitch_um=1.0):
    """Exact scalar free-space propagation of a complex field (angular spectrum).

    ``U(z) = IFFT{ FFT{U(0)} * exp(i*2*pi*z*sqrt(1/lambda^2 - fx^2 - fy^2)) }``
    in the ``exp(-i*omega*t)`` convention, so a positive *distance_um*
    propagates forward. Components beyond the propagating cone
    (``fx^2 + fy^2 > 1/lambda^2``) are **attenuated** by
    ``exp(-2*pi*|z|*sqrt(fx^2 + fy^2 - 1/lambda^2))``, which is the physical
    evanescent decay — not zeroed, so ``distance_um = 0`` is an *exact*
    identity and the transfer function is continuous through it.

    Unlike Fresnel propagation this makes no paraxial approximation: it is the
    exact solution of the Helmholtz equation for a band-limited field, valid
    from a fraction of a wavelength outward.

    Returns a complex128 array with the same shape as *field*.

    Ground truth it reproduces (measured): ``distance_um = 0`` returns the field
    bit-identically (it short-circuits the transform pair); propagating ``+z``
    then ``-z`` returns the original to a relative L2 error of 4.3e-16 to
    5.3e-16 for a band-limited field (measured on three: 64x64 random at
    +/-50 um, a 64x64 Gaussian at +/-250 um, a 128x128 random at +/-500 um);
    total power is conserved to between 0 and 3.5e-16 relative on the same
    three. A field *with*
    evanescent content does **not** round-trip — those components are gone by
    construction, in both directions, because that is what physically happens.

    *field* is a field in the **space** domain, not a spectrum: do not hand it
    the fftshifted output of :func:`complexops.cx_fft`. Real input is promoted
    to complex, which loses nothing.

    Aliasing: the discrete transfer function is periodic, so a field that
    diffracts past the array edge wraps around. The practical guard is the
    usual one — pad the field so the propagated support stays inside, and keep
    ``pixel_pitch_um`` below ``lambda/(2*NA)``. No warning can detect this
    reliably from the array alone, so none is invented.

    **Raises** ``ValueError``: *field* is not 2-D, smaller than 2x2, larger than
    :data:`MAX_FIELD_ELEMENTS`, masked, or non-finite; non-positive or
    non-finite *wavelength_um* / *pixel_pitch_um*; non-finite *distance_um*.
    """
    u = _require_image(field, "field", "angular_spectrum_propagate",
                       complex_ok=True)
    lam = _positive(wavelength_um, "wavelength_um")
    z = _finite_scalar(distance_um, "distance_um")
    pitch = _positive(pixel_pitch_um, "pixel_pitch_um")
    if z == 0.0:
        # Zero distance is the identity operator. Taking the FFT round trip
        # anyway would return the field with ~1e-16 of numerical dirt on it and
        # cost two transforms for nothing; a copy is both exact and cheaper.
        return np.ascontiguousarray(u, dtype=np.complex128).copy()
    h, w = u.shape
    fy = np.fft.fftfreq(h, d=pitch)[:, None]
    fx = np.fft.fftfreq(w, d=pitch)[None, :]
    arg = 1.0 / (lam * lam) - fx * fx - fy * fy
    prop = arg >= 0.0
    kz = np.zeros_like(arg)
    np.sqrt(arg, out=kz, where=prop)
    tf = np.empty(arg.shape, dtype=np.complex128)
    tf[prop] = np.exp(2j * np.pi * z * kz[prop])
    if (~prop).any():                       # evanescent: decay away from the source
        decay = np.sqrt(-arg[~prop])
        tf[~prop] = np.exp(-2.0 * np.pi * abs(z) * decay)
    out = np.fft.ifft2(np.fft.fft2(u) * tf)
    if not np.isfinite(out).all():
        raise ValueError("angular_spectrum_propagate: the propagated field "
                         "overflowed float64 — the input field's dynamic range "
                         "is beyond what an FFT of this size can carry")
    return np.ascontiguousarray(out, dtype=np.complex128)



#: フーリエ面に置ける透過関数の種類(:func:`fourier_plane_filter`)。
FOURIER_PLANE_KINDS = ("identity", "block", "derivative_x", "derivative_y",
                       "laplacian", "lowpass", "highpass", "hilbert_x", "vortex")


def fourier_plane_filter(size=64, kind="derivative_x", order=1, charge=1,
                         radius_frac=0.25, pixel_pitch_um=1.0):
    """4f 系のフーリエ面に置く複素透過関数 ``H(fx, fy)``。

    返るのは ``numpy.fft.fftfreq`` の並び(**fftshift しない**)の complex128
    ``(size, size)`` で、:func:`four_f_filter` にそのまま渡せる。空間周波数の
    単位は cycles/um(``fftfreq(size, d=pixel_pitch_um)``)。

    *kind*:

    ``identity``
        ``H = 1``。4f 系は結像するだけ —— 出力は入力の **180 度回転**になる。
    ``block``
        ``H = 0``。出力は厳密にゼロ(フーリエ面を塞いだ状態)。
    ``derivative_x`` / ``derivative_y``
        ``H = (i*2*pi*f)**order``。出力は *order* 階の空間微分。**レンズが
        微分を計算する**のがこの 1 行で、光コンピューティングの核である。
    ``laplacian``
        ``H = -(2*pi)**2 * (fx**2 + fy**2)``。等方な 2 階微分。
    ``lowpass`` / ``highpass``
        ``|f| <= radius_frac * f_nyquist`` の円形開口(と、その補集合)。
        ``f_nyquist = 1/(2*pixel_pitch_um)``。空間フィルタリングの教科書例。
    ``hilbert_x``
        ``H = -i*sign(fx)``(``fx = 0`` と、偶数長のナイキストのビンは 0)。
        片側位相で縁が立つ —— シュリーレン法の数値版。★ナイキストを 0 に
        するのは、``fftfreq`` が偶数長で ``-1/2`` だけを返し対になる ``+1/2``
        が無いためで、残すと実数偶関数の出力が**奇対称を厳密に満たさない**
        (実測 1.6e-09 → 0 にして 2.3e-16)。離散ヒルベルト変換の標準的な扱い。
    ``vortex``
        ``H = exp(i*charge*phi)`` の渦位相板。*charge* は**位相の巻き数**で、
        フーリエ面の閉路を 1 周すると位相が厳密に ``2*pi*charge`` 進む
        —— 整数の不変量なので門にできる。★DC 項は 0 にする(``phi`` が
        原点で定義されないため)。結果として平均が落ちるので、この板は
        **等方な縁強調**(半径方向ヒルベルト変換)として働く。

    真値(この op が再現するもの):

    * ``identity`` は ``four_f_filter`` を通すと入力の 180 度回転に一致 —— 実測で
      最大絶対差 3.4e-16(64x64 のガウシアン、``pixel_pitch_um=1``)。**ビット一致
      ではない**: FFT の往復が 1e-16 の屑を乗せる。ゼロ距離伝搬のように
      短絡すれば厳密にできるが、それは ``identity`` だけの特別扱いになる。
    * ``derivative_x`` order=1 をガウシアン ``exp(-x**2/w**2)`` に当てると
      ``-2x/w**2 * exp(-x**2/w**2)`` に一致(帯域制限の範囲で)。
    * ``vortex`` の巻き数は閉路上の位相差の和を ``2*pi`` で割って厳密に *charge*。
    * ``lowpass`` + ``highpass`` = ``identity``(同じ *radius_frac* で厳密に 1)。

    **Raises** ``ValueError``: *kind* が上の一覧に無い / *size* が 2 未満または
    :data:`MAX_GRID` 超 / *order* が 0..8 の外 / *charge* が -32..32 の外 /
    *radius_frac* が 0 以下または 1 超 / *pixel_pitch_um* が非正・非有限。
    """
    n = _count(size, "size", 2, MAX_GRID)
    if kind not in FOURIER_PLANE_KINDS:
        raise ValueError(
            "fourier_plane_filter: kind %r is not one of %s"
            % (kind, ", ".join(FOURIER_PLANE_KINDS)))
    k = _count(order, "order", 0, 8)
    m = _count(charge, "charge", -32, 32)
    frac = _finite_scalar(radius_frac, "radius_frac")
    if not 0.0 < frac <= 1.0:
        raise ValueError("fourier_plane_filter: radius_frac must be in (0, 1], "
                         "got %r" % (radius_frac,))
    pitch = _positive(pixel_pitch_um, "pixel_pitch_um")

    fy = np.fft.fftfreq(n, d=pitch)[:, None]
    fx = np.fft.fftfreq(n, d=pitch)[None, :]
    two_pi_i = 2j * np.pi

    if kind == "identity":
        return np.ones((n, n), dtype=np.complex128)
    if kind == "block":
        return np.zeros((n, n), dtype=np.complex128)
    if kind in ("derivative_x", "derivative_y"):
        if kind == "derivative_x":
            h = np.asarray((two_pi_i * fx) ** k * np.ones((n, 1)), dtype=np.complex128)
        else:
            h = np.asarray((two_pi_i * fy) ** k * np.ones((1, n)), dtype=np.complex128)
        # ★奇数次の微分は奇関数。偶数長の ``fftfreq`` はナイキストの ``-1/2`` だけを
        #   持ち対の ``+1/2`` が無いので、そこを残すと実の場の「微分」に虚部が出た
        #   (実測 max|Im| 0.34)。hilbert_x と同じくそのビンを 0 にする。
        if k % 2 == 1 and n % 2 == 0:
            if kind == "derivative_x":
                h[:, n // 2] = 0.0
            else:
                h[n // 2, :] = 0.0
        return h
    if kind == "laplacian":
        return np.asarray(-(2.0 * np.pi) ** 2 * (fx * fx + fy * fy),
                          dtype=np.complex128)
    if kind in ("lowpass", "highpass"):
        f_nyq = 0.5 / pitch
        inside = (fx * fx + fy * fy) <= (frac * f_nyq) ** 2
        h = inside.astype(np.complex128)
        # ★補集合はここで作る。`1 - lowpass` を呼び出し側に作らせると、
        #   境界の扱いが 2 通りに分かれて lowpass + highpass = 1 が崩れる。
        return h if kind == "lowpass" else (1.0 - h).astype(np.complex128)
    if kind == "hilbert_x":
        h = np.asarray(-1j * np.sign(fx) * np.ones((n, 1)), dtype=np.complex128)
        # ★ナイキストのビンを 0 にする。``fftfreq`` は偶数長で ``-1/2`` だけを
        #   返し、対になる ``+1/2`` が無いので、そこを残すと片側位相が**奇対称を
        #   厳密に満たさない**(実測: 残差 1.6e-09 → 0 にすると 2.3e-16)。
        #   離散ヒルベルト変換で標準的な扱いで、`scipy.signal.hilbert` も同じ。
        if n % 2 == 0:
            h[:, n // 2] = 0.0
        return h
    # vortex
    phi = np.arctan2(fy * np.ones((1, n)), fx * np.ones((n, 1)))
    h = np.exp(1j * m * phi)
    h[0, 0] = 0.0                  # phi が原点で定義されない(平均が落ちる)
    return np.ascontiguousarray(h, dtype=np.complex128)


def four_f_filter(field, transfer, invert=True):
    """4f 光学プロセッサ: 2 枚のレンズとフーリエ面のフィルタを通した出力。

    入力面 → レンズ 1 → **フーリエ面**(``transfer`` を掛ける)→ レンズ 2 →
    出力面。スカラ回折の理想 4f 系では出力は

        ``out(x, y) = (u * h)(-x, -y)``

    —— 畳み込みに**座標反転**が付く。2 枚のレンズがそれぞれ*前向きの*フーリエ
    変換を行い、``F{F{u}}(x) = u(-x)`` だからである。「フーリエ面で掛けるだけ」
    の計算と実物の 4f 系はここが違うので、反転は既定で**する**。

    離散でもこの反転は厳密で、添字の写像 ``n -> (-n) mod N`` になる
    (``np.roll(a[::-1], 1)``)。反転そのものは添字の入れ替えなので誤差を持たない
    —— 残る誤差は FFT の往復が乗せる 1e-16 台だけである(``transfer`` を 1 に
    した実測で最大絶対差 3.4e-16)。

    *invert* を ``False`` にすると反転を省く(フィルタ後の場を**入力座標のまま**
    見たいとき。物理の 4f 系ではないので、既定にはしない)。

    真値(この op が再現するもの):

    * ``identity`` フィルタ → 入力の 180 度回転に一致(実測 3.4e-16)。
    * ``block`` フィルタ → 厳密にゼロ。
    * ``derivative_x`` order=n → *n* 階の空間微分。ガウシアン(w=8, 64x64)で
      1 階 5.8e-08 / 2 階 5.4e-08 の相対誤差 —— **1e-16 にならない**のは
      ガウシアンが厳密に帯域制限されていないから(打ち切りの分)。
    * 線形性 ``4f(a*u1 + b*u2) = a*4f(u1) + b*4f(u2)``。
    * 合成 ``4f(4f(u, H1), H2)`` = ``4f(u, H1*H2)``(反転を 2 回かけた分だけずれる
      ので、合成を試すときは *invert* を ``False`` にする)。
    * ``|H| = 1`` のフィルタは総パワーを保つ(Parseval)。

    **Raises** ``ValueError``: *field* / *transfer* が 2-D でない、形が違う、
    2x2 未満、:data:`MAX_FIELD_ELEMENTS` 超、非有限、マスク付き。
    """
    u = _require_image(field, "field", "four_f_filter", complex_ok=True)
    h = _require_image(transfer, "transfer", "four_f_filter", complex_ok=True)
    if u.shape != h.shape:
        raise ValueError(
            "four_f_filter: field %s and transfer %s must have the same shape "
            "— the transfer function lives on the same sampling grid as the "
            "field's spectrum" % (u.shape, h.shape))
    out = np.fft.ifft2(np.fft.fft2(u) * h)
    if invert:
        # 添字の反転 n -> (-n) mod N。DC 標本(添字 0)は動かない。
        out = np.roll(out[::-1, ::-1], 1, axis=(0, 1))
    if not np.isfinite(out).all():
        raise ValueError("four_f_filter: the filtered field overflowed float64 "
                         "— the transfer function's dynamic range is beyond "
                         "what an FFT of this size can carry")
    return np.ascontiguousarray(out, dtype=np.complex128)


def fraunhofer_pattern(aperture, wavelength_um=0.55, distance_mm=100.0,
                       pixel_pitch_um=10.0):
    """Far-field (Fraunhofer) diffraction intensity of an aperture.

    In the far field the diffracted amplitude is the Fourier transform of the
    aperture transmittance, so the intensity is
    ``|FFT{aperture}|^2`` (fftshifted, DC at the centre) normalised to a peak of
    exactly 1.0.

    Returns a float64 image with the same shape as *aperture*.

    **The output plane is sampled differently from the input plane** — this is
    the trap in every FFT diffraction routine. The observation-plane pitch is
    ``lambda*z/(N_pixels*input_pitch)``; with the defaults
    (``0.55 um``, ``100 mm``, ``10 um``) and a 64-pixel aperture that is
    ``0.55*100000/(64*10) = 85.9 um`` per pixel. The value is not returned as
    an image cannot carry it; compute it from the formula when you need
    absolute positions.

    A ``RuntimeWarning`` is emitted when the Fresnel number
    ``N_F = a^2/(lambda*z)`` (with ``a`` the aperture's support radius) is not
    below 1 — i.e. when you are asking for a far-field pattern at a distance
    where the near field still dominates. The result is still returned, because
    the Fourier relation is exactly what was asked for; the warning says the
    *physics*, not the arithmetic, is out of range.

    Ground truth it reproduces (measured): a rectangular slit ``w`` pixels wide
    in an ``N``-pixel array puts its diffraction zeros exactly on the DFT bins
    ``k*N/w``; a 4-pixel-wide slit in a 64-pixel array has **exactly** 0.0 at
    bins +/-16 and +/-32 from DC (the DFT of a boxcar vanishes there to the
    last bit, not merely to rounding); the pattern of a centred symmetric
    aperture is symmetric to 2.2e-16.

    **Raises** ``ValueError``: *aperture* is not 2-D / smaller than 2x2 / over
    the size cap / complex / masked / non-finite; a negative transmittance
    (that is not an aperture); an **opaque** aperture (everything zero — an
    opaque screen diffracts nothing and the normalisation would be 0/0);
    non-positive or non-finite *wavelength_um* / *distance_mm* /
    *pixel_pitch_um*.
    """
    a = _require_image(aperture, "aperture", "fraunhofer_pattern")
    lam = _positive(wavelength_um, "wavelength_um")
    z_um = _positive(distance_mm, "distance_mm") * 1e3
    pitch = _positive(pixel_pitch_um, "pixel_pitch_um")
    if (a < 0.0).any():
        raise ValueError("fraunhofer_pattern: aperture has %d negative value(s) "
                         "— a transmittance is >= 0 (an amplitude mask with a "
                         "sign is a complex field; use "
                         "angular_spectrum_propagate)" % (int((a < 0.0).sum()),))
    if not a.any():
        raise ValueError("fraunhofer_pattern: the aperture is entirely opaque "
                         "(all zeros) — an opaque screen diffracts nothing and "
                         "the peak normalisation would be 0/0")
    spec = np.fft.fftshift(np.fft.fft2(a))
    inten = np.abs(spec) ** 2
    peak = float(inten.max())
    if not np.isfinite(peak) or peak <= 0.0:
        raise ValueError("fraunhofer_pattern: the diffracted intensity peak is "
                         "%r — the transform overflowed float64" % (peak,))
    # far-field sanity: support radius of the aperture, in micrometres
    yy, xx = np.nonzero(a)
    h, w = a.shape
    rad = float(np.max(np.hypot(yy - (h - 1) / 2.0, xx - (w - 1) / 2.0)) * pitch)
    nf = rad * rad / (lam * z_um)
    if nf >= 1.0:
        warnings.warn("fraunhofer_pattern: Fresnel number %.3g >= 1 (aperture "
                      "radius %.3g um, distance %.3g mm) — the far-field "
                      "condition is not met; the returned pattern is the exact "
                      "Fourier transform but not the field at that distance "
                      "(use angular_spectrum_propagate)"
                      % (nf, rad, z_um * 1e-3), RuntimeWarning, stacklevel=2)
    return np.ascontiguousarray(inten / peak, dtype=np.float64)


# --------------------------------------------------------------------------- #
# pupil-shape PSF: any aperture, with defocus, on a detector pitch             #
# --------------------------------------------------------------------------- #
#: Largest FFT side (``n * oversample``) :func:`pupil_psf` will allocate. A
#: 8192^2 complex128 grid is 1 GB per temporary — already past a design aid.
MAX_PUPIL_FFT = 8192

#: Largest optical-path step (waves) between neighbouring pupil samples that
#: :func:`pupil_psf` accepts. Past half a wave per sample the phase is aliased
#: and the FFT returns a PSF that looks plausible and is wrong (same limit as
#: ``lensimage.psf_from_opd``).
MAX_WAVES_PER_SAMPLE = 0.5


def defocus_from_shift(shift_um=10.0, wavelength_um=0.55, f_number=5.6):
    """Defocus wavefront error (waves at the pupil edge) of an axial focus shift.

    Moving the detector (or, equivalently, the focus) by ``shift_um`` along the
    axis of an ``f/N`` beam adds the quadratic wavefront error
    ``W(rho) = W20 * rho^2`` with

        ``W20 = shift / (8 * lambda * N^2)``  [waves]

    — the paraxial Seidel defocus term, ``rho`` the normalised pupil radius
    (1 at the edge). This is the number :func:`pupil_psf` takes as
    ``defocus_waves``, so the two compose: a longitudinal chromatic aberration
    (focal shift versus wavelength, e.g. from ``raytrace.chromatic_shift`` or a
    published ``df/f(lambda)``) becomes a per-band ``defocus_waves`` here and a
    per-band PSF there.

    Returns a float (a ``measurement``). The sign is the sign of *shift_um*:
    **positive = the detector sits beyond the focus** (the beam has converged
    and is diverging again). For a symmetric pupil the PSF does not depend on
    the sign; for an asymmetric one (a slit, a W, an off-axis hole) the sign
    **flips the PSF through the centre** — that is exactly the handle a
    one-photoreceptor eye can read the direction of defocus from.

    Ground truth (closed form, ``tests/test_optics.py``): ``shift = 8 lambda N^2``
    is exactly one wave; the function is linear in *shift_um* and inverse in
    *wavelength_um* and in ``N^2`` (checked at two of each). At ``N = 1.5``,
    ``lambda = 0.55 um`` (a cephalopod-scale ``f/1.5`` eye) a 250 um focus shift
    is 25.3 waves.

    **Raises** ``ValueError``: non-finite *shift_um*; non-positive or non-finite
    *wavelength_um* / *f_number*.

    Paraxial: ``W20 = shift/(8 N^2)`` is the small-angle expansion of the exact
    ``shift * (1 - cos theta)`` sag; at ``f/1.5`` (``sin theta = 1/3``) the exact
    edge value is about 2.9 % above the paraxial one — the number is a *defocus
    convention*, not a high-NA wavefront.
    """
    dz = _finite_scalar(shift_um, "shift_um")
    lam = _positive(wavelength_um, "wavelength_um")
    fn = _positive(f_number, "f_number")
    return float(dz / (8.0 * lam * fn * fn))


def _pupil_phase_step(inside, W):
    """Largest |dW| (waves) between neighbouring samples that are both inside."""
    both_x = inside[:, 1:] & inside[:, :-1]
    both_y = inside[1:, :] & inside[:-1, :]
    dx = np.abs(W[:, 1:] - W[:, :-1])[both_x]
    dy = np.abs(W[1:, :] - W[:-1, :])[both_y]
    return float(max(dx.max() if dx.size else 0.0, dy.max() if dy.size else 0.0))


def _bin_to_pixels(psf, dx_um, pitch_um):
    """Area-integrate a fine, centred (DC at ``M//2``) PSF onto detector pixels.

    Each fine sample stands for the interval ``[x - dx/2, x + dx/2]`` and its
    energy is split between the (at most two, since ``dx <= pitch``) pixels
    that interval overlaps, in proportion to the overlap. ★ Nearest-pixel
    binning (``floor(x/pitch + 0.5)``) is *not* symmetric when samples land on
    pixel boundaries — at 2 samples per pixel every second sample does, pixel
    0 got the samples at ``-pitch/2`` and ``0`` and the whole PSF slid by a
    quarter pixel (measured 2026-09-15: correlation with the closed-form Airy
    0.968 instead of > 0.999). The overlap split is exact and symmetric for
    any ratio, and separable, so it is two sparse matrix products.
    """
    from scipy.sparse import csr_matrix                   # scipy is a hard dependency
    m = psf.shape[0]
    x = (np.arange(m, dtype=np.float64) - m // 2) * dx_um
    lo = x - 0.5 * dx_um
    hi = x + 0.5 * dx_um
    # An interval that starts exactly on a pixel boundary belongs to the upper
    # pixel and one that ends on it to the lower; the 1e-9 (in pixels) keeps
    # the rounding of x/pitch from pushing it across (at pitch == dx it did,
    # and one sample in two spilled into the neighbour).
    k_lo = np.floor(lo / pitch_um + 0.5 + 1e-9).astype(int)       # pixel holding the interval start
    k_hi = np.ceil(hi / pitch_um + 0.5 - 1e-9).astype(int) - 1    # pixel holding the interval end
    edge = (k_lo + 0.5) * pitch_um                        # boundary between k_lo and k_lo + 1
    w_hi = np.where(k_hi > k_lo, (hi - edge) / dx_um, 0.0)
    w_hi = np.clip(w_hi, 0.0, 1.0)
    w_lo = 1.0 - w_hi
    half = int(max(abs(int(k_lo.min())), abs(int(k_hi.max()))))
    size = 2 * half + 1
    rows = np.concatenate([k_lo + half, k_hi + half])
    cols = np.concatenate([np.arange(m), np.arange(m)])
    vals = np.concatenate([w_lo, w_hi])
    b = csr_matrix((vals, (rows, cols)), shape=(size, m))
    out = np.ascontiguousarray((b @ (b @ psf).T).T, dtype=np.float64)   # rows, then columns
    return out / out.sum()


def pupil_psf(pupil, defocus_waves=0.0, wavelength_um=0.55, f_number=5.6,
              oversample=4, pixel_pitch_um=None, opd_waves=None):
    """Diffraction PSF of an **arbitrary pupil shape** with defocus (sums to 1).

    *pupil* is a square ``(n, n)`` amplitude transmittance (0 = opaque, 1 =
    clear; a binary mask is the usual case) drawn on a grid whose **full width
    is the pupil's clear diameter** ``D`` — so a circle filling the grid is a
    conventional round stop, a W-shaped band or an off-axis hole inside the
    grid is just a different mask, and ``f_number = f / D`` refers to that
    full width in every case. (A map from ``raytrace.opd_samples``, whose
    ``linspace(-1, 1, n)`` grid puts the outer sample *centres* on the pupil
    edge, spans ``n − 1`` cells instead: pass ``f_number = N·(n−1)/n`` for the
    same PSF scale, or use ``lensimage.psf_from_opd``, which does this.) The wavefront over the grid is
    ``W(rho) = defocus_waves * rho^2 (+ opd_waves)`` with ``rho`` the radius
    from the grid centre normalised to ``1`` at the grid half-width (the Seidel
    defocus ``W20``; :func:`defocus_from_shift` converts an axial shift to it),
    and the PSF is the Fraunhofer intensity of the pupil function

        ``PSF = | FFT{ pupil * exp(i 2 pi W) } |^2``

    on a zero-padded ``M x M`` grid, ``M = n * oversample`` (rounded up to
    even), centred on sample ``M//2`` and normalised to unit sum. The image
    plane sample spacing is

        ``dx = lambda * N * n / M  ~= lambda * N / oversample``  [um]

    — with *pixel_pitch_um* the fine PSF is **area-integrated** onto detector
    pixels of that pitch (odd ``(K, K)``, centred on a pixel, unit sum), which
    is what an image convolution needs; the pitch must not be finer than
    ``dx``. Without it the fine PSF is returned and ``dx`` is yours to compute
    from the formula (an image cannot carry it).

    Returns a float64 ``image2d``.

    Ground truth it reproduces (measured, ``tests/test_optics.py``):

      * a circle filling a 64-sample grid, ``oversample = 16``: the first dark
        ring at ``1.2197 lambda N`` within 0.5 % of the Airy value (three
        wavelength / f-number pairs), and the same ring at the same
        *micrometre* radius within 5 % after binning to a pixel pitch of
        ``lambda N / 8`` (2.1 % measured — the parabolic minimum on a 9.8-pixel
        ring, not the binning) — so the pitch bookkeeping is right in physical
        units, not only in samples; the binned spot is centro-symmetric to
        1e-17 and correlates with :func:`airy_pattern` sampled at the same
        pitch at 0.99999 (0.9999 at ``lambda N / 4``, 0.9997 at ``lambda N / 3``);
      * pure defocus of a circular pupil: the on-axis intensity relative to the
        unaberrated peak is the closed-form ``[sin(pi W20)/(pi W20)]^2``
        (``0.405`` at half a wave, ``0`` at one wave — the dark centre of the
        one-wave defocused Airy spot), within 1 %;
      * ``defocus_waves = 0`` and a clear circular pupil is the Airy pattern of
        :func:`airy_pattern` to the sampling of the disc edge;
      * **the sign identity**: for a real pupil, ``-W`` is the complex
        conjugate of ``+W``, so ``PSF(-W)(x) = PSF(+W)(-x)`` exactly. The test
        pins it on a W-shaped band: the two PSFs are mirror images through the
        centre to 1e-12, and they are *not* equal to each other (the W pupil
        is asymmetric, so the direction of defocus is visible in the blur),
        while for the circle they are equal (a symmetric pupil cannot tell
        the sign). Rotating the W pupil by 90/180/270 degrees rotates the PSF
        the same way (checked, so the asymmetry is the pupil's, not the grid's).

    **Raises** ``ValueError``: *pupil* is not 2-D, not square, smaller than 2x2,
    over the size cap, complex, masked or non-finite; negative transmittance;
    an all-opaque pupil (nothing to diffract, the normalisation would be
    0/0); *opd_waves* not the same shape as *pupil*; non-finite
    *defocus_waves*; non-positive or non-finite *wavelength_um* /
    *f_number* / *pixel_pitch_um*; *oversample* outside ``[1, 64]``; an FFT
    side over :data:`MAX_PUPIL_FFT`; **an aliased phase** — more than
    :data:`MAX_WAVES_PER_SAMPLE` waves between neighbouring pupil samples (the
    message says how many samples the grid needs); a pixel pitch finer than
    the fine sample spacing (raise *oversample*).

    Scalar Fraunhofer optics: no polarisation, no high-NA obliquity, no
    pupil apodisation by the lens itself. The defocus term is the paraxial
    ``rho^2`` (see :func:`defocus_from_shift`). A pupil that reaches the grid
    edge is fine (the zero padding is the field stop); a pupil *larger* than
    the grid cannot be expressed — widen the grid and lower ``f_number``.
    """
    p = _require_image(pupil, "pupil", "pupil_psf")
    n = int(p.shape[0])
    if p.shape[0] != p.shape[1]:
        raise ValueError("pupil_psf: pupil must be square (its full width is the "
                         "pupil diameter D that f_number refers to), got %dx%d"
                         % (p.shape[0], p.shape[1]))
    if (p < 0.0).any():
        raise ValueError("pupil_psf: pupil has %d negative value(s) — an amplitude "
                         "transmittance is >= 0 (a signed mask is a phase, use "
                         "opd_waves)" % (int((p < 0.0).sum()),))
    if not p.any():
        raise ValueError("pupil_psf: the pupil is entirely opaque (all zeros) — "
                         "nothing diffracts and the unit-sum normalisation would "
                         "be 0/0")
    d = _finite_scalar(defocus_waves, "defocus_waves")
    lam = _positive(wavelength_um, "wavelength_um")
    fn = _positive(f_number, "f_number")
    ov = _count(oversample, "oversample", 1, 64)
    m = n * ov
    if m % 2:
        m += 1
    if m > MAX_PUPIL_FFT:
        raise ValueError("pupil_psf: FFT side %d (= %d samples x oversample %d) is "
                         "over the %d cap (optics.MAX_PUPIL_FFT) — reduce the pupil "
                         "grid or the oversample" % (m, n, ov, MAX_PUPIL_FFT))
    c = (n - 1) / 2.0
    ax = (np.arange(n, dtype=np.float64) - c) * (2.0 / n)   # rho = 1 at half-width
    W = d * (ax[:, None] ** 2 + ax[None, :] ** 2)
    if opd_waves is not None:
        o = _require_image(opd_waves, "opd_waves", "pupil_psf")
        if o.shape != p.shape:
            raise ValueError("pupil_psf: opd_waves must have the pupil's shape %r, "
                             "got %r" % (tuple(p.shape), tuple(o.shape)))
        W = W + o
    inside = p > 0.0
    step = _pupil_phase_step(inside, W)
    if step > MAX_WAVES_PER_SAMPLE:
        need = int(np.ceil(n * step / (0.4))) + 1
        raise ValueError("pupil_psf: the wavefront changes %.2f waves between "
                         "neighbouring pupil samples (aliased; the cap is %.1f) — "
                         "sample the pupil on a grid of about %d samples or more "
                         "(or reduce defocus_waves)" % (step, MAX_WAVES_PER_SAMPLE, need))
    pad = np.zeros((m, m), dtype=np.complex128)
    pad[:n, :n] = p * np.exp(2j * np.pi * W)
    with np.errstate(over="ignore", invalid="ignore"):
        psf = np.abs(np.fft.fftshift(np.fft.fft2(pad))) ** 2
        total = float(psf.sum())
    if not np.isfinite(total) or total <= 0.0 or not np.isfinite(psf).all():
        raise ValueError("pupil_psf: the transform overflowed float64 (sum %r) — "
                         "the pupil's dynamic range is beyond what an FFT of this "
                         "size can carry; rescale the transmittance" % (total,))
    psf /= total
    if pixel_pitch_um is None:
        return np.ascontiguousarray(psf, dtype=np.float64)
    pitch = _positive(pixel_pitch_um, "pixel_pitch_um")
    dx = lam * fn * n / m
    if dx > pitch * (1.0 + 1e-9):
        raise ValueError("pupil_psf: the PSF sample spacing %.4g um (lambda N n/M) "
                         "is coarser than the pixel pitch %.4g um — raise "
                         "oversample to at least %d" % (dx, pitch, int(np.ceil(lam * fn / pitch))))
    return _bin_to_pixels(psf, dx, pitch)


def pupil_blur(image, pupil, defocus_waves=0.0, wavelength_um=0.55, f_number=5.6,
               pixel_pitch_um=5.0, oversample=4, opd_waves=None):
    """Blur an image with the PSF of a pupil shape at one wavelength band.

    The forward imaging model of *one* spectral band: the PSF of
    :func:`pupil_psf` (same pupil / defocus / wavelength / f-number
    arguments), **binned to the image's pixel pitch** so the blur is in the
    image's own units, convolved with the image (FFT, reflect-padded borders so
    a flat field stays flat and nothing wraps around). Call it once per band
    with that band's ``defocus_waves`` (from :func:`defocus_from_shift` and a
    focal shift versus wavelength) and you have the polychromatic image of a
    lens with longitudinal chromatic aberration seen through any pupil — the
    ingredient of the "colour from chromatic blur" hypothesis for
    single-photoreceptor eyes (Stubbs & Stubbs, *PNAS* 113:8206, 2016).

    Returns a float64 ``image2d`` of the image's shape. Linear: no clipping,
    no re-normalisation of the image (the PSF sums to 1, so a constant image
    is returned unchanged to rounding).

    Ground truth it reproduces (measured, ``tests/test_optics.py``): a constant
    image is unchanged to 1e-12; a delta image returns the binned PSF itself
    (the impulse response, to 1e-12 where the kernel fits); with
    ``defocus_waves = 0`` and a diffraction spot much smaller than the pixel
    (``lambda N = 0.8 um`` on a 5 um pitch) a sharp edge is unchanged to
    within 1 % — the *identity at focus*; the blurred image's total is the
    input's total to 1e-9 (flux is conserved by the reflect padding).

    **Raises** ``ValueError``: everything :func:`pupil_psf` raises, plus
    *image* not 2-D / smaller than 2x2 / over the size cap / complex / masked
    / non-finite, and a non-finite result (an FFT overflow).

    Shift-invariant: one PSF for the whole field. Field-dependent blur
    (vignetting, off-axis aberration) is ``lensimage.render_through_lens``.
    """
    img = _require_image(image, "image", "pupil_blur")
    pitch = _positive(pixel_pitch_um, "pixel_pitch_um")
    psf = pupil_psf(pupil, defocus_waves, wavelength_um, f_number, oversample,
                    pitch, opd_waves)
    from scipy.signal import fftconvolve                  # scipy is a hard dependency
    half = psf.shape[0] // 2
    h, w = img.shape
    padded = np.pad(img, half, mode="reflect") if half > 0 else img
    with np.errstate(over="ignore", invalid="ignore"):
        out = fftconvolve(padded, psf, mode="same")[half:half + h, half:half + w]
    if not np.isfinite(out).all():
        raise ValueError("pupil_blur: the convolution overflowed float64 — the "
                         "image's dynamic range is beyond what an FFT of this size "
                         "can carry; rescale it")
    return np.ascontiguousarray(out, dtype=np.float64)


def gaussian_beam(waist_um=100.0, wavelength_um=1.064, distance_mm=0.0,
                  n_medium=1.0):
    """Gaussian-beam propagation: spot size, wavefront curvature and Gouy phase.

    The ``q``-parameter solution of the paraxial wave equation, evaluated at
    *distance_mm* from the waist. With ``zR = pi*w0^2*n/lambda``:

    ``w(z) = w0*sqrt(1 + (z/zR)^2)`` · ``R(z) = z*(1 + (zR/z)^2)`` ·
    ``psi(z) = arctan(z/zR)`` (Gouy) · far-field half-divergence
    ``theta = lambda/(pi*n*w0)``.

    Returns a dict: ``radius_um`` the 1/e^2 field radius ``w(z)`` ·
    ``rayleigh_mm`` ``zR`` · ``wavefront_radius_mm`` ``R(z)`` ·
    ``curvature_per_mm`` ``1/R(z)`` · ``gouy_deg`` · ``divergence_mrad`` the
    far-field half angle · ``waist_um`` and ``distance_mm`` echoed back.

    **``wavefront_radius_mm`` is ``inf`` exactly at the waist, by contract**:
    the wavefront there is planar and a plane has infinite radius. That is why
    ``curvature_per_mm`` is also returned — it is 0 at the waist and finite
    everywhere, so downstream arithmetic never has to divide by an infinity.
    A negative ``R`` (before the waist, ``z < 0``) means a converging wavefront.

    Ground truth it reproduces exactly (verified at machine precision): at
    ``z = zR`` the spot is ``sqrt(2)*w0``, the wavefront radius is ``2*zR`` (its
    minimum over all z) and the Gouy phase is exactly 45 degrees; the
    beam-parameter product ``w0*theta = lambda/(pi*n)`` holds for every input.

    **Raises** ``ValueError``: non-positive or non-finite *waist_um*,
    *wavelength_um*, *n_medium*; non-finite *distance_mm*.

    Paraxial and fundamental-mode (TEM00) only: a real multimode beam needs an
    ``M^2`` factor, which this op deliberately does not fake by accepting one
    silently.
    """
    w0 = _positive(waist_um, "waist_um")
    lam = _positive(wavelength_um, "wavelength_um")
    n = _positive(n_medium, "n_medium")
    z_mm = _finite_scalar(distance_mm, "distance_mm")
    zr_um = np.pi * w0 * w0 * n / lam
    z_um = z_mm * 1e3
    t = z_um / zr_um
    w = w0 * np.sqrt(1.0 + t * t)
    if z_um == 0.0:
        r_mm = float("inf")
        curv = 0.0
    else:
        r_um = z_um * (1.0 + 1.0 / (t * t))
        r_mm = r_um * 1e-3
        curv = 1.0 / r_mm
    return {"radius_um": float(w), "rayleigh_mm": float(zr_um * 1e-3),
            "wavefront_radius_mm": float(r_mm), "curvature_per_mm": float(curv),
            "gouy_deg": float(np.degrees(np.arctan(t))),
            "divergence_mrad": float(lam / (np.pi * n * w0) * 1e3),
            "waist_um": float(w0), "distance_mm": float(z_mm)}


# --------------------------------------------------------------------------- #
# imaging quality                                                              #
# --------------------------------------------------------------------------- #
def psf_to_mtf(psf, pixel_pitch_um=1.0):
    """Radially-averaged MTF of a measured point-spread function.

    ``OTF = FFT{PSF}``, ``MTF = |OTF| / |OTF(0)|``, then averaged over annuli of
    constant spatial frequency out to the Nyquist limit ``1/(2*pitch)``. This
    is the measurement side of resolution: image a point source (or a slit, or
    differentiate a knife edge), hand the spot here, and compare the curve with
    the diffraction limit from :func:`mtf_diffraction`.

    Returns an ``(n, 2)`` float64 ``pairs`` array: column 0 the spatial
    frequency in **cycles per millimetre**, column 1 the MTF in [0, 1]. One row
    per non-empty radial bin (a very anisotropic array can leave a bin empty;
    those rows are dropped rather than filled with a NaN).

    Ground truth it reproduces (measured): a delta PSF gives MTF == 1 at every
    frequency **exactly** (max deviation 0.0); a Gaussian PSF of sigma pixels
    gives the closed form ``exp(-2*pi^2*sigma^2*f^2)`` — the maximum absolute
    deviation over the whole curve is 4.1e-4 at sigma = 2 px on 128x128,
    8.3e-4 at sigma = 1.5 px on 64x64 and 2.4e-4 at sigma = 3 px on 256x256
    (the residual is the radial average over a square grid, not an error in the
    transform). Doubling *pixel_pitch_um* halves every reported frequency and
    leaves the MTF column bit-identical.

    The PSF is **not** re-normalised or re-centred: a PSF whose energy is not
    centred carries a linear phase, which the modulus discards, so the MTF is
    unaffected — but the *phase* transfer function, which is where a
    decentred/asymmetric PSF shows up, is deliberately not summarised here.

    **Raises** ``ValueError``: *psf* is not 2-D / smaller than 2x2 / over the
    size cap / complex / masked / non-finite; a PSF that sums to zero or less
    (the DC normalisation would be 0/0 — an all-zero "PSF" is not a PSF);
    non-positive or non-finite *pixel_pitch_um*.
    """
    p = _require_image(psf, "psf", "psf_to_mtf")
    pitch = _positive(pixel_pitch_um, "pixel_pitch_um")
    with np.errstate(over="ignore", invalid="ignore"):
        total = float(p.sum())
    if not (total > 0.0):
        raise ValueError("psf_to_mtf: the PSF sums to %g — the DC normalisation "
                         "|OTF(0)| would be 0/0. An all-zero or net-negative "
                         "array is not a point-spread function" % (total,))
    with np.errstate(over="ignore", invalid="ignore"):
        otf = np.fft.fft2(p)
    dc = abs(complex(otf[0, 0]))
    if not np.isfinite(dc) or dc == 0.0 or not np.isfinite(otf).all():
        # Confirmed 2026-09-01: a PSF of 1e308 overflows the transform, so
        # |OTF| and |OTF(0)| are both inf and the MTF came back as a column of
        # silent NaN. The sum test above does not catch it — the sum overflows
        # to +inf too, which is > 0.
        raise ValueError("psf_to_mtf: the transform overflowed float64 "
                         "(|OTF(0)| = %r) — the PSF's dynamic range is beyond "
                         "what an FFT of this size can carry; rescale it (the "
                         "MTF is scale-invariant, so dividing the PSF by its "
                         "sum costs nothing)" % (dc,))
    mtf = np.abs(otf) / dc
    h, w = p.shape
    fy = np.fft.fftfreq(h, d=pitch)[:, None]
    fx = np.fft.fftfreq(w, d=pitch)[None, :]
    rho = np.hypot(fy, fx)                       # cycles / um
    nyq = 0.5 / pitch
    nbins = max(2, min(h, w) // 2)
    edges = np.linspace(0.0, nyq, nbins + 1)
    idx = np.digitize(rho.ravel(), edges) - 1
    keep = (idx >= 0) & (idx < nbins)
    counts = np.bincount(idx[keep], minlength=nbins)
    sums = np.bincount(idx[keep], weights=mtf.ravel()[keep], minlength=nbins)
    # Report each bin at the *mean frequency of the pixels in it*, not at the
    # geometric bin centre: the pixels are not uniformly distributed inside an
    # annulus, and pinning the curve to the bin centre put the Gaussian
    # reference 1.0e-2 off where the mean puts it 4.1e-4 off (measured).
    fsum = np.bincount(idx[keep], weights=rho.ravel()[keep], minlength=nbins)
    ok = counts > 0
    out = np.column_stack([fsum[ok] / counts[ok] * 1e3, sums[ok] / counts[ok]])
    return np.ascontiguousarray(out, dtype=np.float64)


def mtf_diffraction(f_number=5.6, wavelength_um=0.55, samples=64):
    """The diffraction-limited MTF of a circular pupil (closed form).

    ``MTF(x) = (2/pi)*(arccos(x) - x*sqrt(1 - x^2))`` with ``x = nu/nu_c`` the
    frequency normalised to the cutoff ``nu_c = 1/(lambda*N)``. This is the
    ceiling: no aberration-free lens at this f-number can do better, and a
    measured :func:`psf_to_mtf` curve above it means the measurement is wrong.

    Returns a ``(samples, 2)`` float64 ``pairs`` array: column 0 the spatial
    frequency in **cycles per millimetre** from 0 to the cutoff, column 1 the
    MTF in [0, 1].

    Ground truth it reproduces exactly (machine precision): ``MTF(0) = 1``,
    ``MTF(nu_c) = 0``, and at half the cutoff the textbook ``0.391``
    (``(2/pi)*(pi/3 - sqrt(3)/4) = 0.3910022...``). The cutoff itself at
    ``lambda = 0.55 um``, ``N = 5.6`` is ``324.7 cycles/mm`` — which is why
    stopping a machine-vision lens past f/8 stops buying depth of field and
    starts buying blur (compare :func:`depth_of_field`).

    **Raises** ``ValueError``: non-positive or non-finite *f_number* /
    *wavelength_um*; *samples* outside ``[2, MAX_GRID]``.

    Incoherent illumination, circular unobstructed pupil, no aberration, no
    defocus, and no detector: the pixel aperture and the sensor's own MTF
    multiply on top of this and are not included.
    """
    n = _positive(f_number, "f_number")
    lam = _positive(wavelength_um, "wavelength_um")
    k = _count(samples, "samples", 2, MAX_GRID)
    cutoff_per_um = 1.0 / (lam * n)
    x = np.linspace(0.0, 1.0, k)
    m = (2.0 / np.pi) * (np.arccos(x) - x * np.sqrt(np.clip(1.0 - x * x, 0.0, None)))
    out = np.column_stack([x * cutoff_per_um * 1e3, m])
    return np.ascontiguousarray(out, dtype=np.float64)


# --------------------------------------------------------------------------- #
# energy concentration and directional MTF of a point-spread function          #
# --------------------------------------------------------------------------- #
_MAX_SAMPLES = 4096


def _psf_array(psf, op: str) -> np.ndarray:
    """A validated, non-negative PSF with energy (float64, 2-D, at least 3x3)."""
    p = _require_image(psf, "psf", op)
    if p.ndim != 2 or min(p.shape) < 3:
        raise ValueError("%s: psf must be a 2-D array of at least 3x3 samples, got shape %s" % (op, p.shape))
    with np.errstate(over="ignore", invalid="ignore"):
        total = float(p.sum())
        pmax = float(p.max())
    if float(p.min()) < -1e-9 * max(pmax, 0.0):
        raise ValueError("%s: the PSF has negative samples (min %g) -- energy cannot be negative" % (op, float(p.min())))
    if not (np.isfinite(total) and total > 0.0 and np.isfinite(pmax)):
        raise ValueError("%s: the PSF has no finite positive energy (sum %g) -- an all-zero or overflowing "
                         "array is not a point-spread function" % (op, total))
    return np.clip(p, 0.0, None)


def _psf_centre(p: np.ndarray, centre, op: str) -> tuple:
    """Pixel coordinates ``(row, col)`` of the circle / square centre."""
    h, w = p.shape
    if isinstance(centre, str):
        if centre == "centroid":
            tot = float(p.sum())
            return (float((p.sum(axis=1) * np.arange(h)).sum() / tot),
                    float((p.sum(axis=0) * np.arange(w)).sum() / tot))
        if centre == "peak":
            i = int(np.argmax(np.round(p / p.max(), 12)))      # ties: the first, in raster order
            return float(i // w), float(i % w)
        if centre == "fft":
            return float(h // 2), float(w // 2)                  # the fftshift origin psf_from_opd uses
        raise ValueError("%s: centre must be 'centroid', 'peak', 'fft' or a (row, col) pair, got %r" % (op, centre))
    try:
        cy, cx = (_finite_scalar(v, "centre") for v in centre)
    except (TypeError, ValueError):
        raise ValueError("%s: centre must be 'centroid', 'peak', 'fft' or a (row, col) pair, got %r" % (op, centre)) from None
    if not (-0.5 <= cy <= h - 0.5 and -0.5 <= cx <= w - 0.5):
        raise ValueError("%s: centre (%g, %g) lies outside the %dx%d array" % (op, cy, cx, h, w))
    return cy, cx


def _fit_radius_px(p: np.ndarray, cy: float, cx: float) -> float:
    """Largest radius (pixels) of a circle / half-width of a square that stays inside the array."""
    h, w = p.shape
    return float(min(cy + 0.5, cx + 0.5, h - 0.5 - cy, w - 0.5 - cx))


def _half_plane_cover(u, a, b):
    """Area of a unit pixel on the side ``n . x <= u`` of a straight cut with ``|n| = 1``.

    *a* >= *b* >= 0 are the absolute components of the unit normal. The cut offset *u* is measured from
    the pixel centre. Exact for a straight edge (the density of ``aX + bY`` for X, Y uniform on a unit
    square is a trapezoid); a circle of radius many pixels is straight across one pixel.
    """
    a = np.asarray(a, float)
    b = np.maximum(np.asarray(b, float), 1e-12)
    u = np.asarray(u, float)
    h = 0.5 * (a + b)
    m = 0.5 * (a - b)
    out = np.where(u <= -h, 0.0, 1.0)
    inner = (u > -h) & (u < h)
    lo = inner & (u < -m)
    mid = inner & (np.abs(u) <= m)
    hi = inner & (u > m)
    out = np.where(lo, (u + h) ** 2 / (2.0 * a * b), out)
    out = np.where(mid, 0.5 + u / a, out)
    out = np.where(hi, 1.0 - (h - u) ** 2 / (2.0 * a * b), out)
    return out


class _CircleEnergy:
    """Energy inside circles of any radius about one centre (pixel-exact edge pixels)."""

    _REACH = 0.7072          # half the pixel diagonal

    def __init__(self, p, cy, cx):
        h, w = p.shape
        yy, xx = np.mgrid[0:h, 0:w]
        dy, dx = (yy - cy).ravel(), (xx - cx).ravel()
        d = np.hypot(dy, dx)
        order = np.argsort(d, kind="stable")
        self.d = d[order]
        self.I = p.ravel()[order]
        with np.errstate(divide="ignore", invalid="ignore"):
            ca = np.where(d[order] > 0, np.abs(dx[order]) / np.where(d[order] > 0, d[order], 1.0), 1.0)
            sa = np.where(d[order] > 0, np.abs(dy[order]) / np.where(d[order] > 0, d[order], 1.0), 0.0)
        self.a = np.maximum(ca, sa)
        self.b = np.minimum(ca, sa)
        self.ax = ca >= sa                                # True when |dx| is the larger component
        self.sx = np.where(dx[order] < 0, -1.0, 1.0)
        self.sy = np.where(dy[order] < 0, -1.0, 1.0)
        self.prefix = np.concatenate([[0.0], np.cumsum(self.I)])
        self.total = float(self.prefix[-1])

    _NEAR = 2.5              # pixels this close to the centre are supersampled (a straight cut is wrong there)
    _SUB = 16

    def __call__(self, r):
        lo = int(np.searchsorted(self.d, r - self._REACH, side="left"))
        hi = int(np.searchsorted(self.d, r + self._REACH, side="right"))
        e = self.prefix[lo]
        if hi > lo:
            d = self.d[lo:hi]
            cov = _half_plane_cover(r - d, self.a[lo:hi], self.b[lo:hi])
            near = d < self._NEAR
            if np.any(near):
                cov = np.where(near, self._supersampled(lo, hi, r), cov)
            e += float(np.sum(self.I[lo:hi] * cov))
        return e / self.total

    def _supersampled(self, lo, hi, r):
        """Fraction of each pixel inside the circle by a 16x16 sub-grid (only the near-centre pixels matter)."""
        out = np.zeros(hi - lo)
        sub = (np.arange(self._SUB) + 0.5) / self._SUB - 0.5
        for k in np.nonzero(self.d[lo:hi] < self._NEAR)[0]:
            i = lo + k
            # the pixel's offset from the centre, rebuilt from its distance and direction cosines
            dx = self.d[i] * (self.a[i] if self.ax[i] else self.b[i]) * self.sx[i]
            dy = self.d[i] * (self.b[i] if self.ax[i] else self.a[i]) * self.sy[i]
            gx = dx + sub[None, :]
            gy = dy + sub[:, None]
            out[k] = float(np.mean(gx * gx + gy * gy <= r * r))
        return out


class _SquareEnergy:
    """Energy inside axis-aligned squares about one centre (separable, exact for pixels)."""

    def __init__(self, p, cy, cx):
        self.p = p / float(p.sum())
        self.y = np.arange(p.shape[0]) - cy
        self.x = np.arange(p.shape[1]) - cx

    @staticmethod
    def _cover(pos, w):
        lo = np.maximum(pos[None, :] - 0.5, -w[:, None])
        hi = np.minimum(pos[None, :] + 0.5, w[:, None])
        return np.clip(hi - lo, 0.0, 1.0)

    def __call__(self, w):
        w = np.atleast_1d(np.asarray(w, float))
        cy, cx = self._cover(self.y, w), self._cover(self.x, w)
        return np.sum((cy @ self.p) * cx, axis=1)


def _energy_curve(psf, pixel_pitch_um, samples, max_radius_um, centre, op, square):
    p = _psf_array(psf, op)
    pitch = _positive(pixel_pitch_um, "pixel_pitch_um")
    n = _count(samples, "samples", 2, _MAX_SAMPLES)
    cy, cx = _psf_centre(p, centre, op)
    fit = _fit_radius_px(p, cy, cx)
    if fit <= 0.5:
        raise ValueError("%s: the centre (%.2f, %.2f) is on the array edge -- no circle fits" % (op, cy, cx))
    if max_radius_um is None:
        rmax = fit
    else:
        rmax = _positive(max_radius_um, "max_radius_um" if not square else "max_half_width_um") / pitch
        if rmax > fit * (1.0 + 1e-12):
            raise ValueError("%s: radius %.6g um leaves the array (the largest that fits about the centre is %.6g um) "
                             "-- the energy outside the array is unknown" % (op, rmax * pitch, fit * pitch))
    r = np.linspace(0.0, rmax, n)
    if square:
        e = _SquareEnergy(p, cy, cx)(r)
    else:
        ce = _CircleEnergy(p, cy, cx)
        e = np.array([ce(float(v)) for v in r])
    return np.ascontiguousarray(np.column_stack([r * pitch, np.clip(e, 0.0, 1.0)]), dtype=np.float64)


def encircled_energy(psf, pixel_pitch_um=1.0, samples=64, max_radius_um=None, centre="centroid"):
    """Encircled energy of a point-spread function: the fraction of the energy inside a circle of radius r.

    The standard spot-quality curve of lens design (how much light lands inside a given pixel or fibre
    core). *psf* is an ``image2d`` of non-negative samples on a grid of *pixel_pitch_um* (use the
    ``pixel_pitch_um`` argument of ``lensimage.psf_from_opd``, or the fine-grid spacing of
    ``pupil_psf``); the circle is centred on the energy centroid by default (*centre* = ``'centroid'``,
    ``'peak'``, ``'fft'`` for the fftshift origin, or a ``(row, col)`` pair in pixels). Edge pixels are
    weighted by the exact area inside the circle, so the curve is smooth in r; a radius under about two
    pixels is resolved only coarsely.

    Returns a ``(samples, 2)`` float64 ``pairs`` array: column 0 the radius in micrometres from 0 to
    *max_radius_um* (default the largest circle that fits in the array about the centre), column 1 the
    fraction of the **array's** energy inside, in [0, 1], non-decreasing. Energy outside the array is
    not known, so a PSF window that cuts the wings off reads high; keep the window several times the
    spot.

    Ground truth it reproduces: an unaberrated circular pupil gives the Airy pattern, whose encircled
    energy is ``1 - J0(v)^2 - J1(v)^2`` with ``v = 2 pi r / (lambda N)``: 83.8 % at the first dark ring
    (``r = 1.2197 lambda N``, Born and Wolf), 91.0 % at the second, 93.8 % at the third (measured in
    ``tests/test_optdesign_psf_metrics.py``).

    **Raises** ``ValueError``: *psf* not 2-D / smaller than 3x3 / negative / zero energy / non-finite;
    non-positive *pixel_pitch_um* or *max_radius_um*; *samples* outside ``[2, 4096]``; a radius that
    leaves the array; a bad *centre*.
    """
    return _energy_curve(psf, pixel_pitch_um, samples, max_radius_um, centre, "encircled_energy", False)


def ensquared_energy(psf, pixel_pitch_um=1.0, samples=64, max_half_width_um=None, centre="centroid"):
    """Ensquared energy of a point-spread function: the fraction of the energy inside a square of half-width w.

    The detector-pixel version of encircled energy: how much of the spot falls inside a square pixel
    (side ``2 w``) centred on it. The square is axis-aligned with the array and centred like
    :func:`encircled_energy` (same *centre* options). The edge pixels are weighted by the exact
    overlap, so the curve is exact for a PSF that is constant across each pixel.

    Returns a ``(samples, 2)`` float64 ``pairs`` array: column 0 the **half-width** in micrometres
    (the pixel side is twice that), column 1 the fraction of the array's energy inside, non-decreasing
    in [0, 1].

    Ground truth it reproduces: a square pupil of side D has the separable PSF
    ``sinc^2(D x / (lambda z)) sinc^2(D y / (lambda z))``, whose ensquared energy is
    ``S(a)^2`` with ``S(a) = (2/pi) (Si(2 pi a) - sin^2(pi a) / (pi a))`` and ``a = w / (lambda N)``
    (checked in ``tests/test_optdesign_psf_metrics.py``).

    **Raises** ``ValueError``: as :func:`encircled_energy` (with *max_half_width_um*).
    """
    return _energy_curve(psf, pixel_pitch_um, samples, max_half_width_um, centre, "ensquared_energy", True)


def energy_radii(psf, pixel_pitch_um=1.0, fractions=(0.5, 0.8, 0.9), kind="circle", centre="centroid"):
    """The radius that holds a given fraction of a point-spread function's energy (``table``).

    Solves the encircled (``kind='circle'``) or ensquared (``kind='square'``) energy curve for each
    fraction in *fractions* (strictly between 0 and 1, at most 16, ascending or not) by bisection on the
    exact edge-weighted curve of :func:`encircled_energy` / :func:`ensquared_energy`: the usual "radius
    at 50 / 80 / 90 %" figures of merit, in micrometres.

    Returns ``{"kind", "fractions", "radius_um", "diameter_um", "centre_px"}``: for a circle the
    radius, for a square the half-width (``diameter_um`` is twice that, the pixel side); ``centre_px``
    is ``(row, col)``. A fraction that the array never reaches (the window cuts the wings off) raises
    rather than returning the array edge.

    Ground truth: the Airy pattern's radii at 50 / 80 / 90 % are the roots of
    ``1 - J0(v)^2 - J1(v)^2 = fraction`` with ``v = 2 pi r / (lambda N)`` (tested against an independent root find).

    **Raises** ``ValueError``: bad *psf* / *pixel_pitch_um* / *centre* (see :func:`encircled_energy`);
    *kind* not ``'circle'`` or ``'square'``; a fraction outside (0, 1) or non-finite; a fraction the
    array's energy does not reach inside the largest circle / square that fits.
    """
    op = "energy_radii"
    if kind not in ("circle", "square"):
        raise ValueError("%s: kind must be 'circle' or 'square', got %r" % (op, kind))
    if isinstance(fractions, (str, bytes)) or not hasattr(fractions, "__len__"):
        fractions = (fractions,)
    fr = [_finite_scalar(f, "fractions[%d]" % i) for i, f in enumerate(fractions)]
    if not 1 <= len(fr) <= 16 or any(not 0.0 < f < 1.0 for f in fr):
        raise ValueError("%s: give 1..16 fractions strictly between 0 and 1, got %r" % (op, list(fractions)))
    p = _psf_array(psf, op)
    pitch = _positive(pixel_pitch_um, "pixel_pitch_um")
    cy, cx = _psf_centre(p, centre, op)
    fit = _fit_radius_px(p, cy, cx)
    if fit <= 0.5:
        raise ValueError("%s: the centre (%.2f, %.2f) is on the array edge -- no circle fits" % (op, cy, cx))
    if kind == "square":
        sq = _SquareEnergy(p, cy, cx)

        def ee(r):
            return float(sq(r)[0])
    else:
        ee = _CircleEnergy(p, cy, cx)
    top = ee(fit)
    out = []
    for f in fr:
        if top < f:
            raise ValueError("%s: the array holds only %.4g of the energy inside the largest %s that fits "
                             "(%.6g um) -- %.4g is not reached; use a larger PSF window"
                             % (op, top, kind, fit * pitch, f))
        lo, hi = 0.0, fit
        for _ in range(60):
            mid = 0.5 * (lo + hi)
            if ee(mid) < f:
                lo = mid
            else:
                hi = mid
        out.append(0.5 * (lo + hi) * pitch)
    return {"kind": kind, "fractions": [float(f) for f in fr], "radius_um": [float(v) for v in out],
            "diameter_um": [float(2.0 * v) for v in out], "centre_px": (float(cy), float(cx))}


def _otf_slices(p: np.ndarray, pitch_um: float, op: str):
    """Axis slices of the modulus of the OTF of a PSF: ``(f_rows, mtf_rows, f_cols, mtf_cols)`` (cycles/mm).

    ``f_rows`` / ``mtf_rows`` is the transfer along the row axis (the OTF at ``fx = 0``, the Fourier
    transform of the line spread function collected across the columns); the columns likewise.
    """
    total = float(p.sum())
    if not (total > 0.0):
        raise ValueError("%s: the PSF sums to %g -- the DC normalisation would be 0/0" % (op, total))
    with np.errstate(over="ignore", invalid="ignore"):
        otf = np.fft.fft2(p)
    dc = abs(complex(otf[0, 0]))
    if not np.isfinite(dc) or dc == 0.0 or not np.isfinite(otf).all():
        raise ValueError("%s: the transform overflowed float64 -- rescale the PSF (the MTF is scale-invariant)" % op)
    h, w = p.shape
    fr = np.arange(h // 2 + 1) / (h * pitch_um) * 1e3
    fc = np.arange(w // 2 + 1) / (w * pitch_um) * 1e3
    return fr, np.abs(otf[:h // 2 + 1, 0]) / dc, fc, np.abs(otf[0, :w // 2 + 1]) / dc


def mtf_tangential_sagittal(psf, pixel_pitch_um=1.0, tangential_axis="y"):
    """Tangential and sagittal MTF from the 2-D transform of a point-spread function (``table``).

    The radial average of :func:`psf_to_mtf` hides astigmatism and coma; a lens designer reads the two
    meridians separately. For a field point displaced along +y (the convention of ``raytrace``) the
    **tangential** (meridional) MTF is the transform along y, the line through the OTF at ``fx = 0``, and
    the **sagittal** MTF is the one along x. Each is a slice of ``|FFT2(PSF)| / |OTF(0)|`` at the exact
    grid frequencies ``k / (n * pitch)`` up to the Nyquist limit, with no radial binning. (By the
    projection-slice theorem the y slice is the transform of the line spread function that integrates the
    PSF across x.) *tangential_axis* = ``'x'`` swaps the roles for a field along x.

    Returns ``{"tangential": (n, 2) pairs, "sagittal": (m, 2) pairs, "nyquist_cpmm", "tangential_axis"}``
    with frequencies in cycles per millimetre and the MTF in [0, 1]. A PSF binned onto detector pixels
    (``psf_from_opd(pixel_pitch_um=...)``) carries the pixel aperture in its MTF; a fine-grid PSF does not.

    Ground truth it reproduces: the diffraction-limited circular pupil
    ``(2/pi)(arccos x - x sqrt(1 - x^2))`` on both curves (:func:`mtf_diffraction`); the two curves are
    identical for a rotationally symmetric PSF on axis and separate for an astigmatic one (measured in
    ``tests/test_optdesign_psf_metrics.py``).

    **Raises** ``ValueError``: bad *psf* (see :func:`encircled_energy`) or *pixel_pitch_um*;
    *tangential_axis* not ``'x'`` or ``'y'``.
    """
    op = "mtf_tangential_sagittal"
    if tangential_axis not in ("x", "y"):
        raise ValueError("%s: tangential_axis must be 'x' or 'y', got %r" % (op, tangential_axis))
    p = _psf_array(psf, op)
    pitch = _positive(pixel_pitch_um, "pixel_pitch_um")
    fr, mr, fc, mc = _otf_slices(p, pitch, op)
    y = np.ascontiguousarray(np.column_stack([fr, mr]), dtype=np.float64)
    x = np.ascontiguousarray(np.column_stack([fc, mc]), dtype=np.float64)
    tan, sag = (y, x) if tangential_axis == "y" else (x, y)
    return {"tangential": tan, "sagittal": sag, "nyquist_cpmm": float(0.5 / pitch * 1e3),
            "tangential_axis": tangential_axis}


def _zernike_terms(coeffs, op: str):
    """Validate a ``{(n, m): coefficient}`` Zernike dict (fit_zernike's format)."""
    if not isinstance(coeffs, dict):
        raise ValueError("%s: coeffs must be a dict {(n, m): coefficient} — the "
                         "format match3d.fit_zernike returns — got %r"
                         % (op, type(coeffs).__name__))
    if not coeffs:
        raise ValueError("%s: coeffs is empty — an empty Zernike expansion has "
                         "no wavefront to characterise" % (op,))
    if len(coeffs) > MAX_ZERNIKE_TERMS:
        raise ValueError("%s: %d terms exceeds the %d cap "
                         "(optics.MAX_ZERNIKE_TERMS)"
                         % (op, len(coeffs), MAX_ZERNIKE_TERMS))
    out = {}
    for key, val in coeffs.items():
        if (not isinstance(key, tuple) or len(key) != 2
                or not all(isinstance(k, (int, np.integer))
                           and not isinstance(k, (bool, np.bool_)) for k in key)):
            raise ValueError("%s: coeffs key %r is not an (n, m) pair of ints — "
                             "use the dict match3d.fit_zernike returns"
                             % (op, key))
        n, m = int(key[0]), int(key[1])
        if n < 0 or abs(m) > n or (n - abs(m)) % 2 != 0:
            raise ValueError("%s: (%d, %d) is not a valid Zernike index — need "
                             "n >= 0, |m| <= n and n-|m| even" % (op, n, m))
        if n > MAX_ZERNIKE_ORDER:
            raise ValueError("%s: radial order n=%d exceeds the %d cap "
                             "(optics.MAX_ZERNIKE_ORDER) — the shared basis "
                             "builder's factorial recurrence loses all accuracy "
                             "above n~44 (measured max|Z| = 71.5 at n=50 against "
                             "the analytic bound of 1)" % (op, n, MAX_ZERNIKE_ORDER))
        out[(n, m)] = _finite_scalar(val, "%s: coefficient (%d, %d)" % (op, n, m))
    return out


def wavefront_stats(coeffs, radial=128, angular=192):
    """Wavefront error statistics from a Zernike expansion: RMS, PV and Strehl.

    *coeffs* is exactly the dict :func:`match3d.fit_zernike` returns —
    ``{(n, m): coefficient}``, coefficients **in waves** — and this op re-uses
    ``match3d``'s own basis builder, so the two cannot drift apart in
    normalisation or in the ``(n, m)`` convention. Fit with ``fit_zernike``,
    characterise here.

    The wavefront is reconstructed on a polar grid (*radial* x *angular*) over
    the unit pupil and reduced with the **area element** ``rho d(rho) d(theta)``
    — an unweighted mean over a uniform-in-rho grid over-counts the centre and
    is a real, silent, ~10% error.

    Returns a dict: ``rms_waves`` (piston removed — piston is not an
    aberration) · ``pv_waves`` peak-to-valley over the pupil · ``strehl`` the
    Marechal estimate ``exp(-(2*pi*rms)^2)`` · ``marechal_valid`` whether
    ``rms_waves <= MARECHAL_RMS_LIMIT`` (0.1), because past that the estimate is
    optimistic and reporting the number without the caveat is the dishonest
    option · ``terms`` and ``n_max`` of the expansion.

    Ground truth it reproduces (measured at the defaults): pure defocus
    ``{(2, 0): 0.1}`` — for which ``Z = 2*rho^2 - 1`` has an exact pupil RMS of
    ``1/sqrt(3)`` — gives ``rms_waves = 0.0577422`` against the exact
    ``0.0577350``, a relative error of 1.2e-4 from the discrete quadrature
    (3.1e-5 at ``radial=256``), and ``pv_waves = 0.2`` exactly; the Strehl is
    0.8766676 against the exact 0.8766962. Pure astigmatism ``{(2, 2): 0.1}``
    (exact RMS ``1/sqrt(6)``) gives 0.0408280 against 0.0408248. Piston alone
    (``{(0, 0): c}``) gives rms 0 and Strehl 1 for any ``c``, and RMS scales
    exactly linearly in the coefficients (doubling them doubles the RMS to
    machine precision).

    **Raises** ``ValueError``: *coeffs* is not a dict, is empty, holds more than
    :data:`MAX_ZERNIKE_TERMS` terms, has a key that is not an ``(n, m)`` int
    pair or is not a valid Zernike index (``n >= 0``, ``|m| <= n``, ``n-|m|``
    even), or a non-finite coefficient; a radial order above
    :data:`MAX_ZERNIKE_ORDER` (40 — the shared basis builder's factorial
    recurrence breaks its own ``|Z| <= 1`` bound at ``n = 46``, measured, and
    the same bound is re-checked at runtime); *radial* / *angular* outside
    ``[8, MAX_GRID]``.

    The radial quadrature is discrete, so its error grows with the order being
    integrated: measured, the relative RMS error tracks ``(n_max/radial)^2``
    within a factor 2 — 1.2e-4 at ``n_max=2``, 1.7e-3 at ``n_max=6`` and 4.3e-2
    at ``n_max=20``, all at the default ``radial=128``. Below
    ``radial >= 16*n_max`` a ``RuntimeWarning`` says so rather than letting a
    12%-wrong Strehl look authoritative. Raising *radial* fixes it at
    ``O(1/radial^2)``, but note the basis is built for *all* orders up to
    ``n_max``, so the working set grows as ``n_max^2 * radial * angular`` and is
    capped by :data:`MAX_ZERNIKE_BASIS`.

    Marechal is a small-aberration approximation and the RMS is over the *fitted*
    expansion, so it says nothing about wavefront structure finer than ``n_max``
    — and ``fit_zernike`` itself discloses ~10% inter-mode crosstalk at its
    default sampling. Both limits compound; treat the Strehl as an indicator,
    not a measurement.
    """
    terms = _zernike_terms(coeffs, "wavefront_stats")
    nr = _count(radial, "radial", 8, MAX_GRID)
    nt = _count(angular, "angular", 8, MAX_GRID)
    n_max = max(n for n, _m in terms)
    # The shared basis builder evaluates *every* (n, m) up to n_max on the whole
    # polar grid, so the working set is (n_max+1)(n_max+2)/2 * nr * nt float64 —
    # quadratic in an argument that looks innocent. Measured: n_max=40 with
    # radial=angular=4096 asks for 1.4e10 elements = 108 GB from a call whose
    # inputs are one dict and two ints. Refuse it up front.
    rows = (n_max + 1) * (n_max + 2) // 2
    need = rows * nr * nt
    if need > MAX_ZERNIKE_BASIS:
        raise ValueError("wavefront_stats: the Zernike basis for n_max=%d on a "
                         "%dx%d grid needs %d elements (%.1f GB), over the %d "
                         "cap (optics.MAX_ZERNIKE_BASIS) — lower radial/angular "
                         "or fit fewer orders"
                         % (n_max, nr, nt, need, need * 8 / 2 ** 30,
                            MAX_ZERNIKE_BASIS))
    if nr < 16 * n_max:
        # Measured 2026-09-01: the relative RMS error of the radial quadrature
        # tracks (n_max/radial)^2 to within a factor 2 — 1.7e-3 at n=6/nr=128,
        # 4.3e-2 at n=20/nr=128, 1.2e-1 at n=40/nr=128. Silence there would be
        # a quietly wrong Strehl.
        warnings.warn("wavefront_stats: radial=%d is under-sampled for n_max=%d "
                      "— the radial quadrature error grows as (n_max/radial)^2 "
                      "(measured ~%.1e relative here); raise radial to >= %d"
                      % (nr, n_max, (n_max / nr) ** 2, 16 * n_max),
                      RuntimeWarning, stacklevel=2)
    # match3d owns the Zernike basis (fit_zernike uses the same builder), so the
    # fitting and the statistics cannot disagree about normalisation. It is pure
    # numpy; the import is lazy only to keep this module's import cheap.
    from match3d import _zernike_basis
    basis, idx, rho = _zernike_basis(nr, nt, n_max)
    peak = float(np.abs(basis).max())
    if not np.isfinite(peak) or peak > 1.0 + 1e-6:
        # Belt and braces over MAX_ZERNIKE_ORDER: every Zernike polynomial is
        # bounded by 1 on the unit disk, so a basis that is not says the
        # evaluation lost precision — checked rather than assumed.
        raise ValueError("wavefront_stats: the Zernike basis up to n_max=%d "
                         "violates its own |Z| <= 1 bound (max %g) — the "
                         "polynomial evaluation lost precision at this order; "
                         "fit fewer terms" % (n_max, peak))
    lookup = {k: i for i, k in enumerate(idx)}
    w = np.zeros(basis.shape[1], dtype=np.float64)
    for key, c in terms.items():
        row = lookup.get(key)
        if row is None:                       # unreachable for a valid index
            raise ValueError("wavefront_stats: (%d, %d) is not in the Zernike "
                             "basis up to n_max=%d" % (key[0], key[1], n_max))
        w += c * basis[row]
    # Area element rho d(rho) d(theta), integrated with the trapezoidal rule in
    # rho. The basis grid is uniform in rho *including both endpoints*, so a
    # plain sum is the rectangle rule and converges only as O(1/nr): measured,
    # it put the pure-defocus RMS 0.79% high at nr=128. Halving the two endpoint
    # weights makes it O(1/nr^2): the same error becomes 1.2e-4 at nr=128 and
    # 3.1e-5 at nr=256, a clean factor-4 per doubling (measured).
    tw = np.ones(nr, dtype=np.float64)
    tw[0] = tw[-1] = 0.5
    weight = rho * np.repeat(tw, nt)
    wsum = float(weight.sum())
    mean = float((weight * w).sum() / wsum)
    var = float((weight * (w - mean) ** 2).sum() / wsum)
    rms = float(np.sqrt(max(var, 0.0)))
    pv = float(w.max() - w.min())
    strehl = float(np.exp(-((2.0 * np.pi * rms) ** 2)))
    return {"rms_waves": rms, "pv_waves": pv, "strehl": strehl,
            "marechal_valid": bool(rms <= MARECHAL_RMS_LIMIT),
            "terms": int(len(terms)), "n_max": int(n_max)}


# --------------------------------------------------------------------------- #
# polarisation                                                                 #
# --------------------------------------------------------------------------- #
# Conventions (pinned 2026-10-23 by tests/test_polarization_per_pixel_2026_10_23.py).
#
# * **Angles.** Every polarisation angle in this library (``angle_deg`` of the
#   element builders, analyser angles of a sweep, AoLP, ``stokes_analyze``'s
#   ``azimuth_deg``) is measured in the image plane from +x (along a row, to the
#   right) toward +y (down the rows). On an image displayed with row 0 at the
#   top that is **clockwise**. This was not chosen here; it is what the existing
#   code already did, measured before writing it down: the Jones vector is
#   ``[Ex, Ey]`` with ``Ey`` along the rows, ``sfpolar`` renders a diffuse
#   normal at ``atan2(ny, nx) = 30`` degrees as AoLP 30, and the photoelasticity
#   PoC feeds ``0.5 * atan2(2 txy, sxx - syy)`` of image-coordinate stresses
#   straight into ``mueller_element``. A sensor or paper that counts
#   counter-clockwise on a y-up display must negate its angles first (45 <-> 135);
#   mixing the two mirrors every axis about x (21.5 reads as 158.5, 45 as 135)
#   and raises nothing.
# * **Handedness.** ``S3 > 0`` is the Jones vector ``[1, -i]/sqrt(2)`` under the
#   ``exp(-i w t)`` time dependence. Its field ``E(t) = (cos wt, -sin wt)`` turns
#   from +x toward -y, i.e. **counter-clockwise on the displayed image** (the
#   view of the camera receiving the beam). ``stokes_analyze`` calls this
#   ``"right"``: that is the name the same vector gets in a y-up frame, where it
#   turns clockwise as seen by the receiver. The label is kept for
#   compatibility; the sign of ``S3`` and this sentence are the contract.
def _rot2(a: float) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, -s], [s, c]], dtype=np.float64)


def jones_element(kind="polarizer", angle_deg=0.0, retardance_deg=90.0):
    """A 2x2 complex Jones matrix for one polarisation element.

    *kind* is one of :data:`JONES_KINDS`:

    ``"polarizer"`` ideal linear polariser, transmission axis at *angle_deg*
    from x · ``"retarder"`` linear retarder, fast axis at *angle_deg*,
    retardance *retardance_deg* · ``"quarter_wave"`` / ``"half_wave"``
    retarders with the retardance fixed at 90 / 180 degrees (*retardance_deg*
    is then **ignored** — stated here so a caller who passes one is not left
    wondering) · ``"rotator"`` optical rotator turning the polarisation by
    *angle_deg*.

    The retarder is written symmetrically, ``diag(exp(-i*d/2), exp(+i*d/2))``
    before rotation, so it introduces no common phase — the fast axis leads.
    (Cross-checked 2026-09-18: Jones phase and handedness conventions differ
    per library — pypolar carries two and this matches neither away from
    0 degrees — so the comparison is made in the Mueller domain: every kind,
    pushed through :func:`stokes_from_jones`, equals pypolar's Mueller element
    to 1e-15. The rotator turns the **state** by +angle, so pypolar
    ``op_rotation`` / polanalyser ``rotator`` — coordinate rotations — equal
    ours at ``-angle``. See ``tests/test_polarization_external_diff.py``.)
    Elements are built as ``R(+a) @ J0 @ R(-a)``.

    Returns a ``(2, 2)`` complex128 matrix acting on a Jones vector
    ``[Ex, Ey]``; compose a train with ``J_total = J_last @ ... @ J_first`` and
    apply it with :func:`jones_apply`.

    Ground truth it reproduces exactly (machine precision): two crossed ideal
    polarisers multiply to the zero matrix; a polariser is idempotent
    (``P @ P == P``); a half-wave plate is an involution up to a global phase
    (``H @ H == -I`` in this symmetric convention); a quarter-wave plate at 45
    degrees turns horizontal linear light into circular (``|S3| == 1``); the
    Malus law ``cos^2(theta)`` falls out of two polarisers at relative angle
    theta.

    **Raises** ``ValueError``: an unknown *kind* (the message lists the valid
    ones); non-finite *angle_deg* or *retardance_deg*.

    Ideal, lossless, normal-incidence elements. A real polariser has a finite
    extinction ratio and a real waveplate is chromatic; the waveplate's
    chromatism is not modelled and not silently approximated, and the finite
    extinction ratio exists only in the Mueller family
    (:func:`mueller_partial_polarizer`). Jones algebra can only carry **fully
    polarised** light — for partial polarisation use :func:`mueller_element`.

    **Per-pixel fields (2026-10-23).** An array *angle_deg* (or, for
    ``kind="retarder"``, an array *retardance_deg*) builds one element per
    entry: the result is ``(*shape, 2, 2)`` where *shape* is the broadcast of
    the array arguments — a fast-axis or retardance map of a photoelastic part,
    one matrix per pixel. Scalars take the original code path untouched, so a
    scalar call returns exactly what it always did. The output is capped at
    :data:`MAX_FIELD_ELEMENTS` numbers.

    **Angle convention.** *angle_deg* is measured from +x (along a row) toward
    +y (**down** the rows): clockwise on a displayed image. See the comment at
    the top of the polarisation section of this module for how that was
    established and what a counter-clockwise sensor must do.
    """
    if not isinstance(kind, str):
        raise ValueError("jones_element: kind must be a string, got %r"
                         % (type(kind).__name__,))
    k = kind.strip().lower()
    if _is_field(angle_deg) or (k == "retarder" and _is_field(retardance_deg)):
        return _jones_field(k, kind, angle_deg, retardance_deg)
    a = np.radians(_finite_scalar(angle_deg, "angle_deg"))
    if k == "rotator":
        return np.ascontiguousarray(_rot2(a), dtype=np.complex128)
    if k == "polarizer":
        j0 = np.array([[1.0, 0.0], [0.0, 0.0]], dtype=np.complex128)
    elif k in ("retarder", "quarter_wave", "half_wave"):
        d = {"quarter_wave": 90.0, "half_wave": 180.0}.get(
            k, None)
        if d is None:
            d = _finite_scalar(retardance_deg, "retardance_deg")
        d = np.radians(d)
        j0 = np.array([[np.exp(-0.5j * d), 0.0], [0.0, np.exp(0.5j * d)]],
                      dtype=np.complex128)
    else:
        raise ValueError("jones_element: unknown kind %r — expected one of %s"
                         % (kind, "/".join(JONES_KINDS)))
    r = _rot2(a).astype(np.complex128)
    return np.ascontiguousarray(r @ j0 @ r.T, dtype=np.complex128)


def _is_field(v) -> bool:
    """True when *v* is array-like with at least one axis (a per-pixel field).

    0-d arrays and numpy scalars are **not** fields: they keep the scalar code
    path, which is what makes the scalar behaviour bit-for-bit unchanged.
    """
    if isinstance(v, (str, bytes, np.str_, np.bytes_)):
        return False
    try:
        return np.ndim(v) > 0
    except (TypeError, ValueError):       # ragged nesting: let the coercion name it
        return True


def _field_arg(v, name: str, op: str) -> np.ndarray:
    """A float64 field of degrees, refusing the traps ``_finite_scalar`` refuses."""
    if np.ma.is_masked(v):
        raise ValueError("%s: %s is a masked array with masked entries — fill or "
                         "drop them explicitly" % (op, name))
    try:
        raw = np.asarray(v)
    except (TypeError, ValueError):
        raise ValueError("%s: %s is a ragged nested sequence, not a field of "
                         "angles" % (op, name)) from None
    if raw.dtype.kind == "b":
        raise ValueError("%s: %s is a bool array — refusing the silent True==1 "
                         "promotion" % (op, name))
    if raw.dtype.kind == "c":
        raise ValueError("%s: %s is complex — an angle is a real quantity"
                         % (op, name))
    if raw.dtype.kind not in "iuf":
        raise ValueError("%s: %s must be numeric degrees, got dtype %s (strings "
                         "would convert silently and hide an unparsed value)"
                         % (op, name, raw.dtype))
    if raw.size == 0:
        raise ValueError("%s: %s is empty — no element to build" % (op, name))
    return _as_float_array(raw, "%s: %s" % (op, name))


def _element_field_args(op, k, angle_deg, retardance_deg, per_entry):
    """Broadcast angle (and, for a free retarder, retardance) to one shape."""
    a = (_field_arg(angle_deg, "angle_deg", op) if _is_field(angle_deg)
         else np.float64(_finite_scalar(angle_deg, "angle_deg")))
    d = None
    if k == "retarder":
        d = (_field_arg(retardance_deg, "retardance_deg", op)
             if _is_field(retardance_deg)
             else np.float64(_finite_scalar(retardance_deg, "retardance_deg")))
    try:
        shape = np.broadcast_shapes(np.shape(a), np.shape(d) if d is not None else ())
    except ValueError:
        raise ValueError("%s: angle_deg %r and retardance_deg %r do not broadcast"
                         % (op, tuple(np.shape(a)), tuple(np.shape(d)))) from None
    n = int(np.prod(shape, dtype=np.int64)) * per_entry
    if n > MAX_FIELD_ELEMENTS:
        raise ValueError("%s: a field of shape %r gives %d output numbers, over the "
                         "%d cap (optics.MAX_FIELD_ELEMENTS)"
                         % (op, tuple(shape), n, MAX_FIELD_ELEMENTS))
    a = np.broadcast_to(a, shape)
    if d is not None:
        d = np.broadcast_to(d, shape)
    return a, d, shape


def _jones_field(k, kind, angle_deg, retardance_deg):
    """``jones_element`` for array arguments → ``(*shape, 2, 2)`` complex128."""
    op = "jones_element"
    if k not in JONES_KINDS:
        raise ValueError("jones_element: unknown kind %r — expected one of %s"
                         % (kind, "/".join(JONES_KINDS)))
    a_deg, d_deg, shape = _element_field_args(op, k, angle_deg, retardance_deg, 4)
    a = np.radians(a_deg)
    c, s = np.cos(a), np.sin(a)
    r = np.zeros(shape + (2, 2), dtype=np.complex128)
    r[..., 0, 0] = c
    r[..., 0, 1] = -s
    r[..., 1, 0] = s
    r[..., 1, 1] = c
    if k == "rotator":
        return np.ascontiguousarray(r)
    j0 = np.zeros(shape + (2, 2), dtype=np.complex128)
    if k == "polarizer":
        j0[..., 0, 0] = 1.0
    else:
        if k == "retarder":
            d = np.radians(d_deg)
        else:
            d = np.full(shape, np.radians({"quarter_wave": 90.0,
                                           "half_wave": 180.0}[k]))
        j0[..., 0, 0] = np.exp(-0.5j * d)
        j0[..., 1, 1] = np.exp(0.5j * d)
    out = r @ j0 @ np.swapaxes(r, -1, -2)
    return np.ascontiguousarray(out, dtype=np.complex128)


def _mueller_field(k, kind, angle_deg, retardance_deg):
    """``mueller_element`` for array arguments → ``(*shape, 4, 4)`` float64.

    Same expressions, in the same order, as the scalar path; only the
    container differs.
    """
    op = "mueller_element"
    if k not in MUELLER_KINDS:
        raise ValueError("mueller_element: unknown kind %r — expected one of %s"
                         % (kind, "/".join(MUELLER_KINDS)))
    a_deg, d_deg, shape = _element_field_args(op, k, angle_deg, retardance_deg, 16)
    a = np.radians(a_deg)
    c, s = np.cos(2.0 * a), np.sin(2.0 * a)
    m = np.zeros(shape + (4, 4), dtype=np.float64)
    if k == "depolarizer":
        m[..., 0, 0] = 1.0
    elif k == "polarizer":
        m[..., 0, 0] = 0.5 * 1.0
        m[..., 0, 1] = m[..., 1, 0] = 0.5 * c
        m[..., 0, 2] = m[..., 2, 0] = 0.5 * s
        m[..., 1, 1] = 0.5 * (c * c)
        m[..., 1, 2] = m[..., 2, 1] = 0.5 * (c * s)
        m[..., 2, 2] = 0.5 * (s * s)
    elif k == "rotator":
        m[..., 0, 0] = 1.0
        m[..., 1, 1] = c
        m[..., 1, 2] = -s
        m[..., 2, 1] = s
        m[..., 2, 2] = c
        m[..., 3, 3] = 1.0
    else:
        if k == "retarder":
            d = np.radians(d_deg)
        else:
            d = np.full(shape, np.radians({"quarter_wave": 90.0,
                                           "half_wave": 180.0}[k]))
        cd, sd = np.cos(d), np.sin(d)
        m[..., 0, 0] = 1.0
        m[..., 1, 1] = c * c + s * s * cd
        m[..., 1, 2] = m[..., 2, 1] = c * s * (1.0 - cd)
        m[..., 1, 3] = -s * sd
        m[..., 2, 2] = s * s + c * c * cd
        m[..., 2, 3] = c * sd
        m[..., 3, 1] = s * sd
        m[..., 3, 2] = -c * sd
        m[..., 3, 3] = cd
    return np.ascontiguousarray(m, dtype=np.float64)


def jones_apply(jones, state):
    """Push a Jones vector through a Jones matrix: ``[Ex', Ey'] = J @ [Ex, Ey]``.

    *jones* is a ``(2, 2)`` matrix (complex, or real which is promoted) and
    *state* a 2-component complex Jones vector ``[Ex, Ey]`` of field
    amplitudes. Returns a ``(2,)`` complex128 vector — chain it through further
    elements, or hand it to :func:`stokes_from_jones` to get the observables.

    Ground truth it reproduces exactly: Malus's law — a linear polariser at
    *theta* on horizontal linear input returns amplitude ``cos(theta)``, hence
    intensity ``cos^2(theta)``, matching to 1e-15 over the full angle sweep;
    crossed polarisers return exactly ``[0, 0]``; the identity matrix returns
    the input bit-identically.

    **Note the zero vector is a legal result**, not an error: light blocked by
    crossed polarisers has zero amplitude. Downstream, :func:`stokes_analyze`
    is the op that refuses a zero-intensity Stokes vector, because *there* the
    degree of polarisation would be 0/0.

    **Raises** ``ValueError``: *jones* is not ``(2, 2)``, *state* is not a
    1-D 2-vector, either is masked or non-finite, or the product overflows.
    """
    j = _as_complex_array(jones, "jones")
    if j.ndim != 2 or j.shape != (2, 2):
        raise ValueError("jones_apply: jones must be a (2, 2) matrix, got shape "
                         "%r — build one with jones_element"
                         % (tuple(np.shape(jones)),))
    v = _require_vec(state, "state", "jones_apply", 2, complex_ok=True)
    out = j @ v
    if not np.isfinite(out).all():
        raise ValueError("jones_apply: the result overflowed float64 (matrix "
                         "norm %g, state norm %g)"
                         % (float(np.abs(j).max()), float(np.abs(v).max())))
    return np.ascontiguousarray(out, dtype=np.complex128)


def stokes_from_jones(state):
    """Jones vector -> Stokes vector (the four measurable intensities).

    ``S0 = |Ex|^2 + |Ey|^2`` · ``S1 = |Ex|^2 - |Ey|^2`` ·
    ``S2 = 2*Re(Ex*conj(Ey))`` · ``S3 = 2*Im(Ex*conj(Ey))``.

    In this convention (``exp(-i*omega*t)`` time dependence) ``S3 > 0`` is
    **right-circular**: the Jones vector ``[1, -i]/sqrt(2)`` maps to
    ``[1, 0, 0, +1]``. (Cross-checked 2026-09-18: pypolar's ``jones_to_stokes``
    gives the opposite S3 sign for the same vector — the other textbook
    convention — while the Mueller matrices of every element agree with
    pypolar, py-pol and polanalyser to 1e-16. See
    ``tests/test_polarization_external_diff.py``.) The convention is pinned by a test rather than left to
    the reader, because every textbook picks a different one and a sign slip
    here is invisible in intensity measurements.

    **What the sign means on an image (2026-10-23).** ``Ex`` is along the rows
    (+x right) and ``Ey`` down the rows (+y down), as for every camera op. The
    ``S3 > 0`` vector ``[1, -i]/sqrt(2)`` has field ``(cos wt, -sin wt)``: it
    turns from +x toward -y, **counter-clockwise on the displayed image**,
    i.e. as seen by the camera receiving the beam. The word ``"right"`` that
    :func:`stokes_analyze` attaches to ``S3 > 0`` is the name of the same
    vector in a y-up frame (where it turns clockwise as seen by the receiver);
    it is kept for compatibility, and ``tests/test_polarization_per_pixel_2026_10_23.py``
    pins the on-screen sense by sampling ``E(t)``.

    Returns a ``(4,)`` float64 vector. A Jones vector always describes fully
    polarised light, so the result always satisfies ``S0^2 = S1^2+S2^2+S3^2``
    exactly (degree of polarisation 1) — verified to 1e-15 in the tests. That
    identity is also the reason Jones cannot represent a partially polarised
    beam: for that, start from :func:`mueller_element` instead.

    **Raises** ``ValueError``: *state* is not a 1-D 2-vector, is masked, or is
    non-finite.
    """
    v = _require_vec(state, "state", "stokes_from_jones", 2, complex_ok=True)
    ex, ey = complex(v[0]), complex(v[1])
    cross = ex * np.conj(ey)
    s = np.array([abs(ex) ** 2 + abs(ey) ** 2,
                  abs(ex) ** 2 - abs(ey) ** 2,
                  2.0 * cross.real,
                  2.0 * cross.imag], dtype=np.float64)
    if not np.isfinite(s).all():
        raise ValueError("stokes_from_jones: the intensities overflowed float64 "
                         "(|E| = %g)" % (float(np.abs(v).max()),))
    return np.ascontiguousarray(s, dtype=np.float64)


def mueller_element(kind="polarizer", angle_deg=0.0, retardance_deg=90.0):
    """A 4x4 real Mueller matrix for one polarisation element.

    *kind* is one of :data:`MUELLER_KINDS` — the same five as
    :func:`jones_element` plus ``"depolarizer"`` (ideal, ``diag(1, 0, 0, 0)``),
    which has **no Jones counterpart at all**. That extra kind is the reason
    this family exists: Jones algebra can only carry fully polarised light,
    Mueller algebra carries partial polarisation, scattering and depolarisation
    — which is what a real polarisation camera sees.

    Angles are doubled inside (``c = cos(2a)``, ``s = sin(2a)``) because the
    Stokes parameters live on the Poincare sphere, where a physical rotation by
    ``a`` is a rotation by ``2a``.

    Returns a ``(4, 4)`` float64 matrix acting on ``[S0, S1, S2, S3]``; apply it
    with :func:`mueller_apply` and compose a train as
    ``M_last @ ... @ M_first``.

    Ground truth it reproduces exactly: an ideal polariser transmits exactly
    half of unpolarised light (``[1,0,0,0] -> S0 = 0.5``) and fully polarises
    it; two polarisers at relative angle theta transmit ``0.5*cos^2(theta)``
    (Malus); a rotator by 45 degrees turns horizontal into 45-degree linear;
    the depolariser leaves ``S0`` and kills ``S1..S3``. Cross-checked against
    the Jones family in the tests — for every kind and a sweep of angles, the
    Jones path and the Mueller path return the **same Stokes vector to 1e-14**,
    which is the only construction that catches a sign slip in either one.

    **Raises** ``ValueError``: an unknown *kind*; non-finite *angle_deg*; or,
    for ``kind="retarder"``, non-finite *retardance_deg*.

    Ideal, lossless (except the polariser's physical loss), normal-incidence
    elements; no diattenuation-plus-retardance combinations, no depolarisation
    other than the ideal case. A polariser with a **finite extinction ratio**
    is :func:`mueller_partial_polarizer`.

    **Per-pixel fields (2026-10-23).** An array *angle_deg* (or, for
    ``kind="retarder"``, an array *retardance_deg*) returns
    ``(*shape, 4, 4)``, one matrix per entry of the broadcast shape — an
    isoclinic angle map and a retardance map of a photoelastic part give the
    whole field in one call, ready for :func:`mueller_apply`'s field form.
    Before this the call raised ``ValueError`` and the photoelasticity PoC had
    to assemble ``(H, W, 4, 4)`` by hand. Scalars take the original code path
    untouched (scalar results are bit-for-bit what they were; pinned by a test
    against a verbatim copy of the old code). Output capped at
    :data:`MAX_FIELD_ELEMENTS` numbers.

    **Angle convention.** *angle_deg* is measured from +x (along a row) toward
    +y (**down** the rows): clockwise on a displayed image — the sense of
    ``atan2(ny, nx)`` of a normal map and of ``0.5 * atan2(2 txy, sxx - syy)``
    for image-coordinate stresses. See the polarisation section comment of this
    module.
    """
    if not isinstance(kind, str):
        raise ValueError("mueller_element: kind must be a string, got %r"
                         % (type(kind).__name__,))
    k = kind.strip().lower()
    if _is_field(angle_deg) or (k == "retarder" and _is_field(retardance_deg)):
        return _mueller_field(k, kind, angle_deg, retardance_deg)
    a = np.radians(_finite_scalar(angle_deg, "angle_deg"))
    c, s = np.cos(2.0 * a), np.sin(2.0 * a)
    if k == "depolarizer":
        m = np.diag([1.0, 0.0, 0.0, 0.0])
    elif k == "polarizer":
        m = 0.5 * np.array([[1.0, c, s, 0.0],
                            [c, c * c, c * s, 0.0],
                            [s, c * s, s * s, 0.0],
                            [0.0, 0.0, 0.0, 0.0]], dtype=np.float64)
    elif k == "rotator":
        m = np.array([[1.0, 0.0, 0.0, 0.0],
                      [0.0, c, -s, 0.0],
                      [0.0, s, c, 0.0],
                      [0.0, 0.0, 0.0, 1.0]], dtype=np.float64)
    elif k in ("retarder", "quarter_wave", "half_wave"):
        d = {"quarter_wave": 90.0, "half_wave": 180.0}.get(k, None)
        if d is None:
            d = _finite_scalar(retardance_deg, "retardance_deg")
        d = np.radians(d)
        cd, sd = np.cos(d), np.sin(d)
        m = np.array([[1.0, 0.0, 0.0, 0.0],
                      [0.0, c * c + s * s * cd, c * s * (1.0 - cd), -s * sd],
                      [0.0, c * s * (1.0 - cd), s * s + c * c * cd, c * sd],
                      [0.0, s * sd, -c * sd, cd]], dtype=np.float64)
    else:
        raise ValueError("mueller_element: unknown kind %r — expected one of %s"
                         % (kind, "/".join(MUELLER_KINDS)))
    return np.ascontiguousarray(m, dtype=np.float64)


def mueller_partial_polarizer(angle_deg=0.0, extinction_ratio=1000.0, transmission=1.0):
    """Mueller matrix of a linear polariser with a finite extinction ratio (a linear diattenuator). → (4, 4), or (*shape, 4, 4) for an angle field.

    A real polariser passes intensity transmittance ``T1 = transmission`` for
    light polarised along its axis and ``T2 = T1 / extinction_ratio`` for light
    across it. Writing ``P = T1 + T2``, ``D = T1 - T2``, ``Q = 2 sqrt(T1 T2)``
    and ``c = cos 2a``, ``s = sin 2a`` (the axis at *angle_deg*), the matrix is

        ``0.5 * [[P,   D c,             D s,             0],``
        ``       [D c, P c^2 + Q s^2,   (P - Q) c s,     0],``
        ``       [D s, (P - Q) c s,     P s^2 + Q c^2,   0],``
        ``       [0,   0,               0,               Q]]``

    — the textbook diattenuator ``diag``-block form rotated to *angle_deg*.
    It is also exactly the Mueller matrix of the Jones matrix
    ``R(a) diag(sqrt T1, sqrt T2) R(-a)`` (a pure diattenuator has no
    retardance and no depolarisation), and the tests check that equality
    through the generic Jones → Mueller conversion, a separate code path.

    Ground truth (closed form, checked in the tests): unpolarised light comes
    out with intensity ``(T1 + T2)/2`` and degree of polarisation
    ``(ER - 1)/(ER + 1)``; the intensity transmitted through two such
    polarisers, parallel vs crossed, is ``(T1^2 + T2^2)/2`` vs ``T1 T2`` —
    the measured extinction ratio of the pair is ``(ER^2 + 1)/(2 ER)``, not
    ``ER``; Malus's law becomes ``T2 + (T1 - T2) cos^2(theta)`` for fully
    polarised input at angle theta to the axis; ``ER -> infinity`` tends to
    ``T1 *`` :func:`mueller_element` ``("polarizer")``; ``ER = 1`` is a
    neutral-density filter ``T1 * I``.

    *angle_deg* may be an array (one matrix per entry, as
    :func:`mueller_element`); *extinction_ratio* and *transmission* are
    scalars. Angles follow the module convention (from +x toward +y = down the
    rows, clockwise on a displayed image).

    **Raises** ``ValueError``: non-finite / non-real / bool / string arguments;
    *extinction_ratio* < 1 (an "extinction ratio" below 1 means the axis is the
    other one — rotate by 90 degrees instead of passing the reciprocal) or
    infinite (use :func:`mueller_element` for the ideal polariser);
    *transmission* outside ``(0, 1]`` (a passive element cannot amplify, and a
    zero-transmission element has no axis); an angle field over
    :data:`MAX_FIELD_ELEMENTS` / 16 entries.
    """
    op = "mueller_partial_polarizer"
    er = _finite_scalar(extinction_ratio, "extinction_ratio")
    if er < 1.0:
        raise ValueError("%s: extinction_ratio must be >= 1, got %r — a ratio "
                         "below 1 says the transmission axis is the other one; "
                         "pass angle_deg + 90 and the reciprocal instead"
                         % (op, er))
    t1 = _finite_scalar(transmission, "transmission")
    if not (0.0 < t1 <= 1.0):
        # %r, not %g: %g printed 1.0000001 as "got 1" (2026-10-24 review).
        raise ValueError("%s: transmission (intensity transmittance along the "
                         "axis) must be in (0, 1], got %r" % (op, t1))
    t2 = t1 / er
    if _is_field(angle_deg):
        a_deg, _d, shape = _element_field_args(op, "polarizer", angle_deg, None, 16)
    else:
        a_deg, shape = np.float64(_finite_scalar(angle_deg, "angle_deg")), ()
    a = np.radians(a_deg)
    c, s = np.cos(2.0 * a), np.sin(2.0 * a)
    p, d, q = t1 + t2, t1 - t2, 2.0 * np.sqrt(t1 * t2)
    m = np.zeros(shape + (4, 4), dtype=np.float64)
    m[..., 0, 0] = 0.5 * p
    m[..., 0, 1] = m[..., 1, 0] = 0.5 * d * c
    m[..., 0, 2] = m[..., 2, 0] = 0.5 * d * s
    m[..., 1, 1] = 0.5 * (p * c * c + q * s * s)
    m[..., 1, 2] = m[..., 2, 1] = 0.5 * (p - q) * c * s
    m[..., 2, 2] = 0.5 * (p * s * s + q * c * c)
    m[..., 3, 3] = 0.5 * q
    return np.ascontiguousarray(m, dtype=np.float64)


def _stokes_pol_norm(s1, s2, s3):
    """``sqrt(S1^2+S2^2+S3^2)`` を桁に依らず正しく(2026-11-05 敵対的検証 第 2 巡 K3 の兄弟)。

    2 乗の和は ``|S| < 1e-154`` で 0 に下溢れ(DoP = 0 と出る)、``|S| > 1e154`` で inf に
    溢れる(物理的な状態が「DoP > 1」で拒否される)。その桁だけ ``hypot`` で測り直す
    (通常の桁の値は従来の式とビット単位で同じ)。スカラーにも配列にも使える。
    """
    s1, s2, s3 = (np.asarray(c, dtype=np.float64) for c in (s1, s2, s3))
    with np.errstate(over="ignore", under="ignore"):
        pol = np.sqrt(s1 ** 2 + s2 ** 2 + s3 ** 2)
    nz = (s1 != 0) | (s2 != 0) | (s3 != 0)
    off = nz & ~((pol >= 1e-150) & (pol <= 1e150))
    if np.any(off):
        pol = np.where(off, np.hypot(np.hypot(s1, s2), s3), pol)
    return pol


def _require_stokes(s, op: str, name: str = "stokes") -> np.ndarray:
    v = _require_vec(s, name, op, 4)
    pol = float(_stokes_pol_norm(v[1], v[2], v[3]))
    if v[0] < 0.0:
        raise ValueError("%s: %s[0] (total intensity S0) is %g — a negative "
                         "intensity is not a physical state" % (op, name, v[0]))
    # ★2026-11-05(敵対的検証 第 2 巡 K3): 許容に絶対の +1e-12 が入っていて、DoP = 2 の
    # 状態でも S0 <= 1e-12 の桁なら受理され dop = 1.0 にクリップされていた。許容は S0 に
    # 対する相対量だけにする(強度の単位・桁に依らず同じ意味)。
    if pol > v[0] * (1.0 + 1e-9):
        raise ValueError("%s: %s is not physically realisable — the polarised "
                         "part sqrt(S1^2+S2^2+S3^2) = %g exceeds the total "
                         "intensity S0 = %g (degree of polarisation > 1)"
                         % (op, name, pol, v[0]))
    return v


def mueller_apply(mueller, stokes):
    """Push a Stokes vector through a Mueller matrix: ``S' = M @ S``.

    *mueller* is a ``(4, 4)`` real matrix (build one with
    :func:`mueller_element`, or multiply several together) and *stokes* a
    4-component Stokes vector ``[S0, S1, S2, S3]``.

    The **input** is checked for physical realisability: ``S0 >= 0`` and
    ``sqrt(S1^2+S2^2+S3^2) <= S0`` (degree of polarisation at most 1). Handing
    an impossible state to a Mueller matrix returns a plausible-looking result
    that means nothing, so it is refused instead. The **output** is not
    re-checked, deliberately: an unphysical output is real evidence that
    *mueller* is not a physical Mueller matrix, and swallowing it would hide
    the bug — inspect it with :func:`stokes_analyze`, which will say so.

    Returns a ``(4,)`` float64 Stokes vector.

    ## 画像として通す(2026-09-06 追加)

    ``mueller`` を ``(..., 4, 4)``、``stokes`` を ``(..., 4)`` にすると
    **画素ごとに違う行列**を通せる。両者は numpy の規則で broadcast するので、
    ``(H, W, 4, 4)`` と ``(4,)`` の組(素子だけが場所で変わる)や、
    ``(4, 4)`` と ``(H, W, 4)`` の組(光だけが場所で変わる)も書ける。

    足した理由は実測。``examples/poc_photoelasticity.py`` は画素ごとに
    位相差の変わる位相子を通す必要があり、**この口が無いために (H,W,4,4) を
    自分で組む羽目になっていた**。行列そのものは正しい(暗視野円偏光系を
    組んで教科書の ``I = sin²(δ/2)`` と 125 通りで最大差 2.2e-16)ので、
    足りなかったのは形だけだった。

    実現可能性の検査は**画素ごとに**行い、破っている画素があれば
    その数と最悪値を挙げて拒否する(1 点でも通さない = fail-closed)。

    Ground truth it reproduces exactly: unpolarised ``[1,0,0,0]`` through an
    ideal polariser gives ``S0 = 0.5`` with degree of polarisation 1; through
    two polarisers at relative angle theta, ``0.5*cos^2(theta)`` (Malus, to
    1e-16 over a full sweep); the identity matrix returns the input unchanged.

    **Raises** ``ValueError``: *mueller* is not ``(4, 4)``, *stokes* is not a
    1-D 4-vector, either is complex / masked / non-finite, the input Stokes
    vector is unphysical, or the product overflows float64.
    """
    m = _as_float_array(mueller, "mueller")
    s_raw = _as_float_array(stokes, "stokes")
    if m.ndim > 2 or s_raw.ndim > 1:
        return _mueller_apply_field(m, s_raw)
    if m.ndim != 2 or m.shape != (4, 4):
        raise ValueError("mueller_apply: mueller must be a (4, 4) matrix, got "
                         "shape %r — build one with mueller_element"
                         % (tuple(np.shape(mueller)),))
    s = _require_stokes(stokes, "mueller_apply")
    out = m @ s
    if not np.isfinite(out).all():
        raise ValueError("mueller_apply: the result overflowed float64 (matrix "
                         "norm %g, S0 %g)" % (float(np.abs(m).max()), float(s[0])))
    return np.ascontiguousarray(out, dtype=np.float64)


def _mueller_apply_field(m, s):
    """``mueller_apply`` の場版 —— ``(...,4,4) x (...,4) -> (...,4)``。"""
    if m.ndim < 2 or m.shape[-2:] != (4, 4):
        raise ValueError("mueller_apply: mueller must end in (4, 4), got shape %r"
                         % (tuple(m.shape),))
    if s.ndim < 1 or s.shape[-1] != 4:
        raise ValueError("mueller_apply: stokes must end in (4,), got shape %r"
                         % (tuple(s.shape),))
    try:
        np.broadcast_shapes(m.shape[:-2], s.shape[:-1])
    except ValueError:
        raise ValueError(
            "mueller_apply: the leading shapes do not broadcast — mueller %r vs "
            "stokes %r" % (tuple(m.shape[:-2]), tuple(s.shape[:-1]))) from None
    s0 = s[..., 0]
    pol = _stokes_pol_norm(s[..., 1], s[..., 2], s[..., 3])
    # ★2026-11-05(敵対的検証 第 2 巡 K3): 絶対の +1e-12 をやめ、場の明るさ(最大 S0)に
    # 対する相対の丸め屑だけを許す(暗い画素の屑は通し、場全体の桁を下げても DoP > 1 は通さない)。
    s0_scale = float(np.max(s0)) if s0.size else 0.0
    bad = (s0 < 0) | (pol > s0 * (1.0 + 1e-9) + 1e-12 * max(s0_scale, 0.0))
    n_bad = int(np.count_nonzero(bad))
    if n_bad:
        worst = float(np.max(np.where(bad, pol - s0, -np.inf)))
        raise ValueError(
            "mueller_apply: %d of %d Stokes vectors are unphysical "
            "(S0 < 0, or degree of polarisation > 1 by up to %.3g). A Mueller "
            "matrix applied to an impossible state returns a plausible-looking "
            "number that means nothing, so the whole field is refused."
            % (n_bad, int(s0.size), worst))
    out = np.einsum("...ij,...j->...i", m, s)
    if not np.isfinite(out).all():
        raise ValueError("mueller_apply: the result overflowed float64 "
                         "(matrix norm %g)" % float(np.abs(m).max()))
    return np.ascontiguousarray(out, dtype=np.float64)


def stokes_analyze(stokes):
    """Read a Stokes vector: degree of polarisation, azimuth, ellipticity.

    Returns a dict: ``intensity`` ``S0`` · ``dop`` degree of polarisation
    ``sqrt(S1^2+S2^2+S3^2)/S0`` · ``dolp`` linear part ``sqrt(S1^2+S2^2)/S0`` ·
    ``docp`` circular part ``|S3|/S0`` · ``azimuth_deg`` orientation of the
    polarisation ellipse ``0.5*atan2(S2, S1)`` mapped into ``[0, 180)`` ·
    ``ellipticity_deg`` ``0.5*asin(S3/|S|)`` in ``[-45, +45]`` ·
    ``handedness`` one of ``"right"`` / ``"left"`` / ``"linear"``.
    ``azimuth_deg`` is measured from +x (along a row) toward +y (down the
    rows) — clockwise on a displayed image; ``"right"`` means ``S3 > 0``,
    which on a displayed image (y down) is a **counter-clockwise** field
    rotation as seen by the camera (see :func:`stokes_from_jones`).
    The ellipticity is that of the **polarised part** (``S3`` over
    ``sqrt(S1^2+S2^2+S3^2)``); pypolar divides by ``S0`` instead, which for
    partially polarised light mixes the unpolarised part into the ellipse —
    the two agree only for fully polarised light (measured 2026-09-18).

    **``azimuth_deg`` and ``ellipticity_deg`` are ``None`` when they are
    undefined** — azimuth when the linear part is zero (circular or
    unpolarised light has no orientation), ellipticity when the polarised part
    is zero (unpolarised light has no ellipse). Returning 0.0 there would be a
    fabricated angle; ``None`` says the truth and forces the caller to handle
    it.

    **"Zero" is relative: ``<= 1e-12 * S0`` (2026-10-24).** Mueller products
    leave rounding dust: ``mueller_element("half_wave", 22.5)`` applied to
    ``[1, 1, 0, 0]`` gives ``S3 = 8.7e-17``, which an exact ``S3 == 0`` test
    reported as ``"right"``-handed, and a quarter-wave plate at 45 on the same
    beam leaves a linear part of 8.7e-17 that came back as an azimuth of 22.5.
    The same floor decides ``handedness`` (``"linear"`` when
    ``|S3| <= 1e-12 * S0``), ``azimuth_deg`` and ``ellipticity_deg``; it is
    relative to ``S0`` so that it means the same at every intensity scale.
    ``dop`` / ``dolp`` / ``docp`` are returned as computed (the dust is an
    honest number there, as in :func:`specularity.polarization_stokes_map`).

    Ground truth it reproduces exactly: ``[1,1,0,0]`` -> dop 1, azimuth 0,
    ellipticity 0, linear; ``[1,-1,0,0]`` -> azimuth 90; ``[1,0,1,0]`` ->
    azimuth 45; ``[1,0,0,1]`` -> docp 1, ellipticity +45, right-handed;
    ``[1,0,0,0]`` -> dop 0 with both angles ``None``;
    ``[2,1,0,0]`` -> dop 0.5 (a partially polarised beam, which is exactly the
    case Jones algebra cannot express).

    **Raises** ``ValueError``: *stokes* is not a 1-D 4-vector, is complex /
    masked / non-finite, is unphysical (``S0 < 0`` or degree of polarisation
    above 1 — which is how you find out a Mueller matrix was not physical), or
    has ``S0 == 0`` (no light at all: every ratio would be 0/0, and "the
    polarisation of darkness" is not a question with an answer).
    """
    s = _require_stokes(stokes, "stokes_analyze")
    s0 = float(s[0])
    if s0 == 0.0:
        raise ValueError("stokes_analyze: S0 (total intensity) is 0 — there is "
                         "no light, so every ratio would be 0/0; check for a "
                         "blocked beam (crossed polarisers) before analysing")
    lin = float(np.hypot(s[1], s[2]))
    pol = float(_stokes_pol_norm(s[1], s[2], s[3]))
    # Rounding-dust floor, relative to S0 (see the docstring): an exact-zero
    # test turned S3 = 8.7e-17 into "right" and a 8.7e-17 linear part into an
    # azimuth.
    dust = 1e-12 * s0
    az = None
    if lin > dust:
        az = float(np.degrees(0.5 * np.arctan2(s[2], s[1])) % 180.0)
        if az >= 180.0:                      # -tiny % 180 rounds to 180.0
            az = 0.0
    ell = None
    if pol > dust:
        ell = float(np.degrees(0.5 * np.arcsin(np.clip(s[3] / pol, -1.0, 1.0))))
    if abs(float(s[3])) <= dust:
        hand = "linear"
    else:
        hand = "right" if s[3] > 0.0 else "left"
    return {"intensity": s0, "dop": float(min(pol / s0, 1.0)),
            "dolp": float(min(lin / s0, 1.0)),
            "docp": float(min(abs(s[3]) / s0, 1.0)),
            "azimuth_deg": az, "ellipticity_deg": ell, "handedness": hand}


# --------------------------------------------------------------------------- #
# Polarisation camera: mosaic -> sweep, images -> Mueller, Mueller -> physics   #
# --------------------------------------------------------------------------- #
#: Angle at each position of the 2x2 super-pixel of a monochrome polarisation
#: sensor (Sony IMX250MZR and the cameras built on it: FLIR BFS-U3-51S5P,
#: LUCID TRI050S-P). ``[[90, 45], [135, 0]]`` = row 0 is 90 then 45, row 1 is
#: 135 then 0 — the convention Polanalyser documents for that sensor and the
#: one this module treats as the default. A different sensor is a different
#: ``layout`` argument, not a different function.
POLARIZATION_MOSAIC_LAYOUT = ((90.0, 45.0), (135.0, 0.0))

#: Order of the images returned by :func:`polarization_demosaic` — the order
#: :func:`specularity.polarization_stokes` / ``polarization_dolp_map`` expect
#: by default, so the two chain without an argument.
POLARIZATION_SWEEP_ANGLES = (0.0, 45.0, 90.0, 135.0)


def polarization_demosaic(raw, layout=POLARIZATION_MOSAIC_LAYOUT):
    """Split a polarisation-sensor mosaic into the four analyser images.

    A polarisation camera puts four micro-polarisers on each 2x2 block of
    pixels; the raw frame is one (H, W) array in which neighbouring pixels saw
    the scene through different analysers. This returns a ``(4, H, W)`` array
    of images ``[I_0, I_45, I_90, I_135]`` (the ``polsweep`` sort, in
    :data:`POLARIZATION_SWEEP_ANGLES` order, so the result feeds
    :func:`specularity.polarization_stokes` and ``polarization_dolp_map``
    directly), each interpolated to full resolution.

    Interpolation is **bilinear**, the same estimate a Bayer demosaic makes for
    a colour plane that occupies one pixel in four: a missing pixel is the mean
    of its measured 4-neighbours (edge-adjacent) or 4-neighbours (diagonal),
    which is exactly the ``[[1, 2, 1], [2, 4, 2], [1, 2, 1]] / 4`` kernel applied
    to the masked plane. Ground truth: on a plane that is **linear** in x and y
    the interpolation is exact (a bilinear estimate of an affine field is the
    field), so the test plants four affine fields, mosaics them, and demands
    every returned image equal its field to 1e-12 away from the border. The
    border is handled by mirroring the **mosaic** two pixels outward before
    interpolating (an even, non-duplicating reflection keeps the 2x2 phase), so
    a uniform field is exact up to the edge and a gradient is mirrored there —
    a symmetric bias on the outermost row and column, and said so. Against
    Polanalyser's OpenCV bilinear path the interior agrees to the 16-bit
    quantisation (1.8e-5) and only the outer two pixels differ (2026-09-18).

    *layout* is the angle at each 2x2 position, ``((a00, a01), (a10, a11))`` in
    degrees; the default is the Sony IMX250MZR block. Every angle in
    :data:`POLARIZATION_SWEEP_ANGLES` must appear exactly once.

    **Raises** ``ValueError``: *raw* is not a 2-D array, has an odd height or
    width (the block would be cut), contains non-finite values, or *layout* is
    not a permutation of the four sweep angles.

    Provenance: the layout convention and the "four Bayer planes" reading of
    the mosaic follow Polanalyser (Maeda, MIT); the interpolation is the
    classic bilinear Bayer demosaic. This is a re-implementation from that
    description, not copied code, and it does not depend on OpenCV. Colour
    polarisation sensors (IMX250MYR, a 4x4 block) are handled by
    :func:`polarization_demosaic_color`.
    """
    a = np.asarray(raw, dtype=np.float64)
    if a.ndim != 2:
        raise ValueError("polarization_demosaic: raw must be a 2-D mosaic, got shape %r"
                         % (a.shape,))
    if a.shape[0] % 2 or a.shape[1] % 2:
        raise ValueError("polarization_demosaic: the mosaic has a 2x2 block, so height and "
                         "width must be even (got %dx%d)" % a.shape)
    if not np.isfinite(a).all():
        raise ValueError("polarization_demosaic: raw contains non-finite values")
    try:
        lay = [[float(layout[r][c]) for c in range(2)] for r in range(2)]
    except (TypeError, IndexError, ValueError):
        raise ValueError("polarization_demosaic: layout must be ((a00, a01), (a10, a11)) in "
                         "degrees, got %r" % (layout,)) from None
    flat = sorted(v % 180.0 for row in lay for v in row)
    if flat != sorted(POLARIZATION_SWEEP_ANGLES):
        raise ValueError("polarization_demosaic: layout %r must contain each of %s exactly once"
                         % (layout, POLARIZATION_SWEEP_ANGLES))
    from scipy import ndimage as _ndi
    kernel = np.array([[1.0, 2.0, 1.0], [2.0, 4.0, 2.0], [1.0, 2.0, 1.0]]) / 4.0
    # ★縁は**モザイクのまま**鏡映で 2 画素広げてから抜く。広げ幅が偶数で ``reflect``
    #   (縁の画素を重ねない鏡映)なら 2x2 の位相が保たれる。マスク後の面を伸ばすと
    #   未計測の 0 が縁に写り、一様な場でも縁が暗くなった(実測 16 画素)。
    pad = np.pad(a, 2, mode="reflect")
    out = []
    for ang in POLARIZATION_SWEEP_ANGLES:
        r, c = next((r, c) for r in range(2) for c in range(2) if lay[r][c] % 180.0 == ang)
        plane = np.zeros_like(pad)
        plane[r::2, c::2] = pad[r::2, c::2]
        out.append(_ndi.convolve(plane, kernel, mode="nearest")[2:-2, 2:-2])
    return np.ascontiguousarray(np.stack(out), dtype=np.float64)


def mueller_from_intensities(intensities, psg, psa, rank_tol=1e-9):
    """Recover a Mueller matrix from intensities measured through known
    generator / analyser states (polarimetric least squares).

    Model: the detector behind a polarisation-state analyser sees
    ``I_i = (A_i @ M @ G_i)[0, 0] = a_i^T M g_i`` where ``g_i = G_i[:, 0]`` is
    the Stokes vector the generator emits from unpolarised light and
    ``a_i = A_i[0, :]`` is the analyser's first row. That is **linear in the 16
    entries of M**: ``I_i = w_i . vec(M)`` with ``w_i = outer(a_i, g_i).ravel()``.
    Stacking the N measurements gives ``W (N x 16)``, solved by least squares.

    *intensities* is ``(N,)`` (one detector) or ``(N, ...)`` (an image per
    state: the same system solved per pixel, so the result is ``(4, 4, ...)``).
    *psg* and *psa* are sequences of N Mueller matrices (4x4) — build them with
    :func:`mueller_element` and matrix products.

    **Fail-closed on an under-determined design**: if ``W`` has rank < 16 the
    design cannot see every entry (the classic case — linear polarisers only,
    no retarder — leaves the S3 row and column unobservable, rank 9) and the
    function raises with the rank instead of returning a pseudo-inverse answer
    that would look plausible and be wrong in the unobserved entries.

    Ground truth in the tests: a known ``M`` (retarder then polariser),
    36 generator/analyser pairs with quarter-wave plates, intensities computed
    by the forward model → ``M`` recovered to 1e-10; the same with polarisers
    only → rank 9, refused.

    **Raises** ``ValueError``: shapes disagree, fewer than 16 measurements,
    non-finite input, or rank < 16.

    Provenance: the observation matrix ``outer(a, g)`` is the standard
    formulation (Chipman, "Polarimetry", *Handbook of Optics* ch. 15); the
    ``pinv`` variant is what Polanalyser's ``calcMueller`` does. Re-implemented
    with an explicit rank check.
    """
    I = np.asarray(intensities, dtype=np.float64)
    G = np.asarray(psg, dtype=np.float64)
    A = np.asarray(psa, dtype=np.float64)
    if I.ndim < 1 or G.shape != (I.shape[0], 4, 4) or A.shape != (I.shape[0], 4, 4):
        raise ValueError("mueller_from_intensities: intensities (N, ...), psg (N, 4, 4) and "
                         "psa (N, 4, 4) must agree on N; got %r / %r / %r"
                         % (I.shape, G.shape, A.shape))
    n = I.shape[0]
    if n < 16:
        raise ValueError("mueller_from_intensities: 16 unknowns need at least 16 measurements "
                         "(got %d)" % n)
    if not (np.isfinite(I).all() and np.isfinite(G).all() and np.isfinite(A).all()):
        raise ValueError("mueller_from_intensities: non-finite input")
    W = np.einsum("nj,nk->njk", A[:, 0, :], G[:, :, 0]).reshape(n, 16)
    rank = int(np.linalg.matrix_rank(W, tol=rank_tol * max(1.0, float(np.abs(W).max()))))
    if rank < 16:
        raise ValueError("mueller_from_intensities: the generator/analyser design has rank %d "
                         "< 16 — some entries of M are unobservable (linear polarisers only "
                         "cannot see the S3 row/column: rank 9). Add a retarder to the design"
                         % rank)
    rhs = I.reshape(n, -1)
    sol, *_ = np.linalg.lstsq(W, rhs, rcond=None)
    m = sol.reshape((4, 4) + I.shape[1:])
    return np.ascontiguousarray(m, dtype=np.float64)


#: The four Pauli-like matrices that turn a Mueller matrix into its coherency
#: (Cloude) matrix, in the order (identity, sigma_1, sigma_2, sigma_3).
_PAULI = (np.eye(2, dtype=complex),
          np.array([[1.0, 0.0], [0.0, -1.0]], dtype=complex),
          np.array([[0.0, 1.0], [1.0, 0.0]], dtype=complex),
          np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=complex))


def mueller_checks(mueller, tol=1e-9):
    """Say whether a 4x4 matrix is a physically realisable Mueller matrix, and
    how depolarising it is.

    Returns a dict:

    ``physical``
        ``True`` iff the coherency matrix ``H = 1/4 sum_ij M_ij (sigma_i (x) sigma_j^*)``
        is positive semidefinite — Cloude's criterion (1986), the necessary and
        sufficient condition for M to be a convex sum of pure (Mueller–Jones)
        matrices (Gil, 2007). ``coherency_eigenvalues`` carries the four real
        eigenvalues (descending) so the caller sees *how* far from physical.
    ``pure``
        one non-zero eigenvalue: M comes from a single Jones matrix (no
        depolarisation). Every element from :func:`mueller_element` except the
        depolariser is pure.
    ``depolarization_index``
        Gil–Bernabeu ``P_Delta = sqrt((sum_ij M_ij^2 - M_00^2) / (3 M_00^2))``:
        1 for a pure matrix, 0 for the ideal depolariser.
    ``passive``
        the largest transmittance ``M_00 + sqrt(M_01^2 + M_02^2 + M_03^2)`` is
        ``<= 1`` — a passive element cannot amplify.
    ``transmittance_max`` / ``transmittance_min``
        those two bounds of the transmitted intensity over all input states.

    Ground truth in the tests: every :func:`mueller_element` kind is physical
    and passive; the pure ones have eigenvalues ``(M_00, 0, 0, 0)`` to 1e-12 and
    ``P_Delta = 1``; the ideal depolariser has ``P_Delta = 0``; a matrix with
    ``M_11 > M_00`` (more polarised output than input) is refused as
    non-physical; a gain matrix (``2 I``) is physical but not passive.

    **Raises** ``ValueError``: not a real 4x4 matrix, non-finite, or
    ``M_00 <= 0`` (no transmitted intensity — every ratio would be 0/0).

    Provenance: Cloude, S. R. (1986), *Optik* 75, 26; Gil, J. J. & Bernabeu, E.
    (1986), *Optica Acta* 33, 185 (depolarisation index); the check set mirrors
    what py-pol (del Hoyo & Sánchez Brea, MIT) exposes as ``is_physical`` /
    ``is_pure`` / ``is_transmissive``, re-implemented from the definitions.
    """
    if np.ma.isMaskedArray(mueller) or np.iscomplexobj(mueller):
        raise ValueError("mueller_checks: the matrix must be real and unmasked")
    m = np.asarray(mueller, dtype=np.float64)
    if m.shape != (4, 4):
        raise ValueError("mueller_checks: expected a (4, 4) matrix, got shape %r" % (m.shape,))
    if not np.isfinite(m).all():
        raise ValueError("mueller_checks: the matrix contains non-finite values")
    m00 = float(m[0, 0])
    if m00 <= 0.0:
        raise ValueError("mueller_checks: M[0, 0] = %g — no transmitted intensity, the "
                         "checks are 0/0" % m00)
    h = np.zeros((4, 4), dtype=complex)
    for i in range(4):
        for j in range(4):
            h += m[i, j] * np.kron(_PAULI[i], np.conj(_PAULI[j]))
    h *= 0.25
    ev = np.sort(np.linalg.eigvalsh(h))[::-1]
    scale = max(m00, 1e-300)
    physical = bool(ev[-1] >= -tol * scale)
    pure = bool(physical and np.all(np.abs(ev[1:]) <= tol * scale))
    pdelta = float(np.sqrt(max(0.0, (np.sum(m * m) - m00 * m00) / (3.0 * m00 * m00))))
    d = float(np.sqrt(m[0, 1] ** 2 + m[0, 2] ** 2 + m[0, 3] ** 2))
    return {"physical": physical, "pure": pure,
            "coherency_eigenvalues": [float(v) for v in ev],
            "depolarization_index": min(pdelta, 1.0) if pdelta <= 1.0 + 1e-9 else pdelta,
            "transmittance_max": m00 + d, "transmittance_min": max(0.0, m00 - d),
            "passive": bool(m00 + d <= 1.0 + tol)}


def polarization_demosaic_color(raw, layout=POLARIZATION_MOSAIC_LAYOUT, bayer="RGGB"):
    """Split a **colour** polarisation-sensor mosaic (Sony IMX250MYR family, a
    4x4 block = a 2x2 Bayer block whose every colour site is itself a 2x2 block
    of polarisers) into four RGB images: ``(4, H, W, 3)`` in
    :data:`POLARIZATION_SWEEP_ANGLES` order, each channel interpolated to full
    resolution. The ``rgbvolume`` sort carries it (four "slices" of RGB).

    Two closed forms composed, no new estimate: (1) the pixels at each of the
    four polariser positions form a plain Bayer mosaic at half resolution, so
    each is demosaicked with :func:`gfx2d.raw_demosaic_bilinear` and written
    back to its positions — after which every pixel has RGB and the
    polarisation mosaic is still interleaved; (2) each RGB channel is then a
    monochrome polarisation mosaic, handled by :func:`polarization_demosaic`.
    This is the decomposition Polanalyser documents for that sensor; *bayer*
    is the pattern of the half-resolution Bayer grid (``RGGB`` for the
    IMX250MYR as read row-major from the top-left site) and *layout* the
    polariser angles inside a site.

    Ground truth: twelve affine planes (4 angles x RGB) mosaicked and split come
    back to 1e-12 away from the border (bilinear is exact on affine fields, and
    the composition of two exact steps is exact).

    **Raises** ``ValueError``: *raw* is not 2-D, has a height or width that is
    not a multiple of 4, is non-finite, or *layout* / *bayer* is invalid.
    """
    a = np.asarray(raw, dtype=np.float64)
    if a.ndim != 2:
        raise ValueError("polarization_demosaic_color: raw must be a 2-D mosaic, got shape %r"
                         % (a.shape,))
    if a.shape[0] % 4 or a.shape[1] % 4 or a.shape[0] < 4 or a.shape[1] < 4:
        raise ValueError("polarization_demosaic_color: the colour-polarisation block is 4x4, so "
                         "height and width must be multiples of 4 (got %dx%d)" % a.shape)
    if not np.isfinite(a).all():
        raise ValueError("polarization_demosaic_color: raw contains non-finite values")
    import gfx2d as _g
    rgb_mosaic = np.zeros(a.shape + (3,), dtype=np.float64)
    for j in range(2):
        for i in range(2):
            rgb_mosaic[j::2, i::2] = _g.raw_demosaic_bilinear(a[j::2, i::2], bayer)
    return np.ascontiguousarray(np.stack(
        [polarization_demosaic(rgb_mosaic[..., c], layout) for c in range(3)], axis=-1))
