"""対応点からの変換推定(HALCON "Transformations" chapter の genuine 実装, numpy).

点対応から アフィン/剛体/相似 の 2D 同次変換行列を最小二乗で求める。点は (row, col)。
純粋な線形代数 / Umeyama 法=曖昧さのない genuine 実装。
"""
from __future__ import annotations

import numpy as np


def _pts(a):
    return np.asarray(a, dtype=np.float64).reshape(-1, 2)


def _pairs(src, dst, op, minimum):
    """有限な対応点 ``(N, 2)`` 2 組(同数・``minimum`` 組以上)を返す(2026-10-23 の fail-closed)。"""
    out = []
    for name, a in (("src", src), ("dst", dst)):
        if isinstance(a, (str, bytes)):
            raise ValueError("%s: %s is a string — expected (N, 2) points" % (op, name))
        try:
            arr = np.asarray(a, dtype=np.float64)
        except (TypeError, ValueError) as e:
            raise ValueError("%s: %s is not numeric (%s)" % (op, name, e)) from None
        if arr.size % 2:
            raise ValueError("%s: %s has %d values — expected (N, 2) points" % (op, name, arr.size))
        arr = arr.reshape(-1, 2)
        if not np.isfinite(arr).all():
            raise ValueError("%s: %s has non-finite coordinates — refused rather than propagated"
                             % (op, name))
        out.append(arr)
    s, d = out
    if len(s) != len(d) or len(s) < minimum:
        raise ValueError("%s: needs >= %d matching (row, col) pairs, got %d src / %d dst"
                         % (op, minimum, len(s), len(d)))
    return s, d


def vector_to_hom_mat2d(src, dst) -> np.ndarray:
    """対応点から 2D アフィン変換行列(3x3)を最小二乗で求める(vector_to_hom_mat2d)。"""
    s, d = _pts(src), _pts(dst)
    A = np.column_stack([s, np.ones(len(s))])            # [row, col, 1]
    # row', col' を別々に回帰
    cr, *_ = np.linalg.lstsq(A, d[:, 0], rcond=None)
    cc, *_ = np.linalg.lstsq(A, d[:, 1], rcond=None)
    H = np.eye(3)
    H[0] = [cr[0], cr[1], cr[2]]                          # row' = a*row + b*col + c
    H[1] = [cc[0], cc[1], cc[2]]
    return H


def vector_to_rigid(src, dst) -> np.ndarray:
    """対応点から 2D 剛体変換(回転+並進、Kabsch)を求める(vector_to_rigid)。

    fail-closed: 対応が 2 組未満・数が合わない・非有限・src の点が全部 1 点に重なる
    (回転が決まらない)ときは ``ValueError``。
    """
    s, d = _pairs(src, dst, "vector_to_rigid", 2)
    if float(np.ptp(s, axis=0).max()) == 0.0:
        raise ValueError("vector_to_rigid: all src points coincide — the rotation is not determined")
    sc, dc = s.mean(0), d.mean(0)
    H_ = (s - sc).T @ (d - dc)
    U, _, Vt = np.linalg.svd(H_)
    R = Vt.T @ U.T
    if np.linalg.det(R) < 0:
        Vt[-1] *= -1
        R = Vt.T @ U.T
    t = dc - R @ sc
    M = np.eye(3)
    M[:2, :2] = R
    M[:2, 2] = t
    return M


def vector_to_similarity(src, dst) -> np.ndarray:
    """対応点から 2D 相似変換(回転+スケール+並進、Umeyama)を求める(vector_to_similarity)。

    fail-closed: 対応が 2 組未満・数が合わない・非有限・src の点が全部 1 点に重なる
    (尺度が 0 割りになる)ときは ``ValueError``。
    """
    s, d = _pairs(src, dst, "vector_to_similarity", 2)
    if float(np.ptp(s, axis=0).max()) == 0.0:
        raise ValueError("vector_to_similarity: all src points coincide — scale and rotation "
                         "are not determined")
    sc, dc = s.mean(0), d.mean(0)
    # ★2026-11-04(外部監査 v0.9.0 F3): 以前は ``scale = D.sum() / (var + 1e-12)`` で、床 1e-12 [座標²] が座標の単位に
    #   依存していた(座標 1 で倍率 1.999999999996、座標 1e-6 で 0.667、真値はどちらも 2)。倍率は
    #   座標の単位に依らない量なので、両方の点群を src の広がり ``ref`` で割ってから比を取る
    #   (割った後の分散は >= 1/N、床は要らない)。``ref > 0`` は上の「全部 1 点」の検査が保証する。
    ref = float(np.abs(s - sc).max())
    sd, dd = (s - sc) / ref, (d - dc) / ref
    H_ = sd.T @ dd / len(s)
    U, D, Vt = np.linalg.svd(H_)
    R = Vt.T @ U.T
    if np.linalg.det(R) < 0:
        Vt[-1] *= -1
        R = Vt.T @ U.T
        D = D.copy(); D[-1] *= -1
    var = (sd ** 2).sum() / len(s)
    scale = D.sum() / var
    t = dc - scale * R @ sc
    M = np.eye(3)
    M[:2, :2] = scale * R
    M[:2, 2] = t
    return M


def vector_angle_to_rigid(row1, col1, angle1, row2, col2, angle2) -> np.ndarray:
    """1 組の (点, 角度) から 2D 剛体変換を求める(vector_angle_to_rigid)。

    fail-closed: 6 つの引数のどれかが実数でない・非有限なら ``ValueError``。
    """
    vals = []
    for name, v in (("row1", row1), ("col1", col1), ("angle1", angle1),
                    ("row2", row2), ("col2", col2), ("angle2", angle2)):
        if isinstance(v, (bool, np.bool_, str, bytes)) or np.ndim(v) != 0:
            raise ValueError("vector_angle_to_rigid: %s must be a real number, got %r" % (name, v))
        f = float(v)
        if not np.isfinite(f):
            raise ValueError("vector_angle_to_rigid: %s must be finite, got %r" % (name, v))
        vals.append(f)
    row1, col1, angle1, row2, col2, angle2 = vals
    dphi = angle2 - angle1
    c, s = np.cos(dphi), np.sin(dphi)
    R = np.array([[c, -s], [s, c]])
    t = np.array([row2, col2]) - R @ np.array([row1, col1])
    M = np.eye(3)
    M[:2, :2] = R
    M[:2, 2] = t
    return M


def _hartley_norm(p: np.ndarray):
    """Hartley 等方正規化: 重心を原点へ、原点からの平均距離を sqrt(2) へ。→ (T (3x3), p_n)。"""
    c = p.mean(0)
    md = float(np.mean(np.linalg.norm(p - c, axis=1)))
    # ★2026-11-04(外部監査 v0.9.0 F3): 床 ``md > 1e-12`` は座標の単位に依存した(1e-13 の尺度の点は正規化されずに DLT へ)。
    #   正規化は尺度を消すための操作なので、全部が 1 点に重なる(md == 0)ときだけ外す。
    s = np.sqrt(2.0) / md if md > 0.0 else 1.0
    T = np.array([[s, 0.0, -s * c[0]], [0.0, s, -s * c[1]], [0.0, 0.0, 1.0]])
    return T, (p - c) * s


def hom_vector_to_proj_hom_mat2d(src, dst) -> np.ndarray:
    """4 点以上の対応から射影変換(homography, DLT)3x3 を求める(hom_vector_to_proj_hom_mat2d)。

    本モジュールの契約どおり点は ``(row, col)``: 返る ``H`` は ``(row, col, 1)`` の同次ベクトルに
    左から掛けて ``(row', col', w)`` を与える(``transforms.projective_trans_point_2d(H, row, col)``
    と整合)。数値安定化のため両点集合を Hartley 正規化してから DLT を解き
    ``H = T_dst⁻¹ · H_n · T_src`` で戻す。

    (旧実装は DLT 行を ``(col, row)`` 順で組んでいたため、``(row, col, 1)`` に適用すると
    2 座標を取り違えた行列を返していた — 2026-09-02 実測 max err 27 px。)
    """
    s, d = _pairs(src, dst, "hom_vector_to_proj_hom_mat2d", 4)
    Ts, sn = _hartley_norm(s)
    Td, dn = _hartley_norm(d)
    A = []
    for (r, c), (r2, c2) in zip(sn, dn):
        A.append([r, c, 1, 0, 0, 0, -r2 * r, -r2 * c, -r2])
        A.append([0, 0, 0, r, c, 1, -c2 * r, -c2 * c, -c2])
    A = np.asarray(A, float)
    _, _, Vt = np.linalg.svd(A, full_matrices=A.shape[0] < A.shape[1])
    Hn = Vt[-1].reshape(3, 3)
    H = np.linalg.inv(Td) @ Hn @ Ts
    # ★2026-11-04(外部監査 v0.9.0 F3): H[2,2] の床は単位の無い量で比べる。H[2,2] = Hn[2] · Ts[:, 2] で、どちらも正規化後の
    #   (単位の無い)ベクトルなので、その大きさの積に対する相対値が「原点が無限遠へ写る」の判定になる。
    if abs(H[2, 2]) > 1e-12 * float(np.linalg.norm(Hn[2]) * np.linalg.norm(Ts[:, 2])):
        H = H / H[2, 2]
    return H
