# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""fourierdesc — 閉輪郭の楕円フーリエ記述子(EFD)と複素フーリエ平滑化。

閉じた輪郭(目・部品・細胞など)を **フーリエ級数** で表す。各高調波は 1 つの
楕円軌道で、低次=大まかな形、高次=細部。使い道:

    - 形状の圧縮表現 / マッチング(正規化で回転・スケール・始点に不変)
    - 高調波を打ち切ると輪郭が平滑化される(ノイズ除去・簡約化)
    - 形状分類・検索(HALCON の shape-based と相補的な、パラメトリック記述)

楕円フーリエ記述子は Kuhl & Giardina, "Elliptic Fourier Features of a Closed
Contour" (CGIP 18, 1982) の閉形式(区分線形輪郭に対する厳密式)で実装。

輪郭の受け取り方:
    points: (N,2) 配列。順序づいた閉輪郭の頂点。座標系は問わない(EFD は 2D 形状に
    対して座標軸に依らず定義される)。既存 XLD 輪郭 dict の ``contour["cs"][i]``
    ((row,col) の Nx2)をそのまま渡せる(:func:`from_xld` を用意)。

★★ 座標順の落とし穴(2026-09-02 に明文化)★★
    ここが返す/受け取る点は XLD と同じ **(row, col) = (行, 列)**。
    いっぽう ``imagemorph``(``morph`` / ``warp_piecewise_affine`` /
    ``warp_tps_image``)の点は **(x, y) = (列, 行)** で **順序が逆**。
    どちらも (N,2) float なので取り違えても **例外は出ず**、「それらしく間違った」
    ワープになる。実測(96x96、円盤 A(30,30) -> B(62,66)、12 点の対応点、alpha=0.5):
    同じ対応点で affine と TPS を掛けたときの平均差が、(row,col) を渡すと **0.00488**、
    正しく (x,y) に直すと **0.00260** —— 座標順を間違えると 2 つの補間法が別々の
    場所へワープするので食い違いが約 1.9 倍に開く。
    橋渡しは必ず列の入れ替えで::

        pts_xy = np.asarray(from_xld(contour))[:, ::-1]    # (row,col) -> (x,y)
"""
from __future__ import annotations

import numpy as np

__all__ = [
    "elliptic_fourier",
    "reconstruct",
    "normalize",
    "invariants",
    "descriptor_distance",
    "fourier_smooth",
    "from_xld",
    "fit_circle_xld",
    "contour_fourier_complex",
    "contour_epicycle_chain",
    "contour_fourier_truncation_energy",
]


def _as_contour(points, name="points"):
    p = np.asarray(points, dtype=np.float64)
    if p.ndim != 2 or p.shape[1] != 2:
        raise ValueError(f"{name} must be a sequence of (N,2) points (received: {p.shape})")
    if p.shape[0] < 3:
        raise ValueError(f"{name} needs a closed contour with at least 3 points (received: {p.shape[0]})")
    if not np.all(np.isfinite(p)):
        raise ValueError(f"{name} contains non-finite values")
    return p


def _closing_point_repeated(p):
    """末尾の点が先頭の点の繰り返しか(輪郭の広がりに対する相対の判定、abs-floor2)。

    以前の ``np.allclose(p[0], p[-1])`` は絶対の許容 1e-8 を含み、広がり 1e-8 以下の
    輪郭(m 単位の微小形状)では**どの 2 点も「同じ」**になった。
    """
    ext = float(np.max(np.ptp(p, axis=0)))
    return bool(np.all(np.abs(p[0] - p[-1]) <= 1e-9 * ext))


def from_xld(contour, i=0):
    """XLD 輪郭 dict(``{"shape", "cs":[Nx2,...]}``)から i 番目の輪郭を取り出す。

    返るのは XLD と同じ **(row, col)** 順の (N,2)。``imagemorph`` へ渡すときは
    ``[:, ::-1]`` で (x, y) に入れ替えること(モジュール冒頭の「座標順の落とし穴」)。
    """
    if not isinstance(contour, dict) or "cs" not in contour:
        raise ValueError("from_xld: contour must be an XLD contour dict with key "
                         f"'cs', got {type(contour).__name__} (a list-of-rows table is not a contour)")
    if isinstance(i, bool) or not isinstance(i, (int, np.integer)) or not (0 <= int(i) < len(contour["cs"])):
        raise ValueError(f"from_xld: i must be an int in [0, {len(contour['cs'])}), got {i!r}")
    return np.asarray(contour["cs"][i], dtype=np.float64).reshape(-1, 2)


#: :func:`fit_circle_xld` が受ける当てはめ方(HALCON ``fit_circle_contour_xld`` の
#: ``Algorithm`` のうち、外れ値の重みを使わない 2 つ)。
FIT_CIRCLE_XLD_METHODS = ("geometric", "algebraic")


def fit_circle_xld(contour, method="geometric"):
    """XLD 輪郭 1 本ごとに円を当てはめ、中心の行・列と半径を返す(``table``)。

    HALCON ``fit_circle_contour_xld`` の Row / Column / Radius にあたる。進化 op の
    ``hx_fit_circle_contour`` は残差(正規化 feature)しか返さないので、輪郭から
    **位置と大きさ**を読むのはこちら。座標は XLD と同じ **(row, col)**、単位は画素。

    ``method`` は ``"geometric"``(既定。点から円までの距離の二乗和を
    Levenberg--Marquardt で最小化、Chernov & Lesort 2005 = ``measure.fit_circle_geometric``)
    か ``"algebraic"``(Kåsa / Coope の代数的最小二乗 = ``measure.fit_circle``。
    短い円弧では半径が小さく偏る)。返す dict の ``row``・``col``・``radius``・``rms``
    (点の動径残差の二乗平均平方根)・``n_points`` は輪郭の並び順の list で、
    ``n_contours`` が当てた本数、``n_skipped`` が点が 3 個未満で飛ばした本数、
    ``method`` が使った方法。

    空の入力(``contour`` が 0 要素 = 輪郭が 1 本も無い)は ``ValueError``。
    拒否(``ValueError``): XLD の dict(``{"shape", "cs"}``)でない、未知の ``method``、
    点が 3 個以上ある輪郭が 1 本も無い、非有限の座標、点が一直線に並ぶ(円が決まらない)。
    """
    op = "fit_circle_xld"
    if not isinstance(contour, dict) or "cs" not in contour:
        raise ValueError(f"{op}: contour must be an XLD contour dict with key 'cs', "
                         f"got {type(contour).__name__}")
    if method not in FIT_CIRCLE_XLD_METHODS:
        raise ValueError(f"{op}: method must be one of {FIT_CIRCLE_XLD_METHODS}, got {method!r}")
    cs = list(contour["cs"])
    if not cs:
        raise ValueError(f"{op}: contour is empty — pass at least one contour")
    import measure                                      # 当てはめ本体は measure の 2 関数を共用する
    fit = measure.fit_circle_geometric if method == "geometric" else measure.fit_circle
    rows, cols, radii, rms, npts = [], [], [], [], []
    skipped = 0
    for c in cs:
        p = np.asarray(c, dtype=np.float64).reshape(-1, 2)
        if p.shape[0] < 3:
            skipped += 1
            continue
        if not np.all(np.isfinite(p)):
            raise ValueError(f"{op}: contour contains non-finite coordinates")
        try:
            r = fit(p)
        except ValueError as exc:
            raise ValueError(f"{op}: {exc}") from exc
        rows.append(float(r["cy"]))
        cols.append(float(r["cx"]))
        radii.append(float(r["r"]))
        rms.append(float(r["rms"]))
        npts.append(int(p.shape[0]))
    if not radii:
        raise ValueError(f"{op}: no contour has at least 3 points ({skipped} skipped)")
    return {"row": rows, "col": cols, "radius": radii, "rms": rms, "n_points": npts,
            "n_contours": len(radii), "n_skipped": int(skipped), "method": method}


# --------------------------------------------------------------------------- #
# 楕円フーリエ記述子(EFD)                                                     #
# --------------------------------------------------------------------------- #
def elliptic_fourier(points, n_harmonics=10):
    """閉輪郭の楕円フーリエ係数を Kuhl–Giardina 閉形式で求める。

    引数:
        points: (N,2) の閉輪郭頂点。閉じていなければ内部で先頭点を末尾に補う。
        n_harmonics: 高調波数 N(多いほど細部まで表現)。

    返り値: dict
        "coeffs": (N,4) 配列。行 n が [a_n, b_n, c_n, d_n]。
        "a0", "c0": DC 成分(輪郭の中心オフセット)。
        "n_harmonics": N。

    再構成 :func:`reconstruct` は
        x(t)=a0+Σ a_n cos(2πnt)+b_n sin(2πnt),  y(t)=c0+Σ c_n cos+d_n sin  (t∈[0,1))。
    """
    p = _as_contour(points)
    if n_harmonics < 1:
        raise ValueError(f"n_harmonics must be at least 1 (received: {n_harmonics})")
    # 閉輪郭にする(末尾==先頭)
    if not _closing_point_repeated(p):
        p = np.vstack([p, p[0]])
    d = np.diff(p, axis=0)                    # (K,2) 各セグメントの変位
    dt = np.hypot(d[:, 0], d[:, 1])           # (K,) セグメント長
    t = np.concatenate([[0.0], np.cumsum(dt)])  # (K+1,) 累積弧長
    T = t[-1]
    # abs-floor2: 以前は長さ 0 の線分を 1e-12 に持ち上げ、周長 < 1e-9 を拒否していた。
    # どちらも長さの絶対の床で、座標 1e-13 の輪郭を拒否し、座標 1e-6 の輪郭では重複点が
    # 係数を動かし、一点に重なる 1000 点以上の輪郭は周長 1e-9 として通っていた。
    # 長さ 0 の線分は d = 0・位相差 0 なので、どの項にも寄与しない —— 割る側だけ 1 に置く。
    if not T > 0.0:
        raise ValueError("contour perimeter is 0 (all points coincide)")
    dt = np.where(dt > 0.0, dt, 1.0)          # 長さ 0 の線分(d = 0)は分子が 0
    phi = 2.0 * np.pi * t / T                  # (K+1,)

    K = d.shape[0]
    coeffs = np.zeros((n_harmonics, 4), dtype=np.float64)
    for n in range(1, n_harmonics + 1):
        c = 2.0 * (n ** 2) * (np.pi ** 2)
        const = T / c
        cos_d = np.cos(n * phi[1:]) - np.cos(n * phi[:-1])   # (K,)
        sin_d = np.sin(n * phi[1:]) - np.sin(n * phi[:-1])
        coeffs[n - 1, 0] = const * np.sum(d[:, 0] / dt * cos_d)  # a_n
        coeffs[n - 1, 1] = const * np.sum(d[:, 0] / dt * sin_d)  # b_n
        coeffs[n - 1, 2] = const * np.sum(d[:, 1] / dt * cos_d)  # c_n
        coeffs[n - 1, 3] = const * np.sum(d[:, 1] / dt * sin_d)  # d_n

    # DC 成分(Kuhl–Giardina)。ξ は包含累積和 − (dx/dt)·t_end、最後に先頭点座標を加える
    # (KG の A0/C0 は先頭点を原点とした相対量なので絶対位置へ戻す)。
    xi = np.cumsum(d[:, 0]) - (d[:, 0] / dt) * t[1:]
    delta = np.cumsum(d[:, 1]) - (d[:, 1] / dt) * t[1:]
    a0 = p[0, 0] + (1.0 / T) * np.sum(d[:, 0] / (2.0 * dt) * (t[1:] ** 2 - t[:-1] ** 2) + xi * dt)
    c0 = p[0, 1] + (1.0 / T) * np.sum(d[:, 1] / (2.0 * dt) * (t[1:] ** 2 - t[:-1] ** 2) + delta * dt)
    return {"coeffs": coeffs, "a0": float(a0), "c0": float(c0), "n_harmonics": int(n_harmonics)}


def reconstruct(model, n_points=300, n_harmonics=None):
    """EFD 係数から輪郭を再構成する((M,2))。

    n_harmonics を係数数より小さくすると **高調波を打ち切って平滑化** される
    (低次だけ残すほど丸くなる)。

    式: ``t = linspace(0, 1, n_points, endpoint=False)`` について
    ``x(t) = a0 + Σ a_n cos(2πnt) + b_n sin(2πnt)``、
    ``y(t) = c0 + Σ c_n cos(2πnt) + d_n sin(2πnt)``(``n = 1..N``)。

    - ``model``: ``elliptic_fourier`` の返り値(``coeffs`` ``(N, 4)``、``a0``、``c0``)。
      ``normalize`` を通した係数を渡せば正準ポーズ(第 1 高調波で整列)の輪郭が
      出る。dict の検証はしない(キー欠落は ``KeyError``)。
    - ``n_points``: 出力点数 ``M``(``int`` に切る)。等**パラメータ**間隔で、弧長
      等間隔ではない。``endpoint=False`` なので**末尾点は先頭点と一致しない**
      (閉じた多角形にするなら先頭点を末尾に足す)。0 なら空の ``(0, 2)``。
    - ``n_harmonics``: 使う高調波数。``None`` で全部、``N`` より大きい値は ``N`` に
      切り詰め、0 以下なら DC だけ(全点が中心 ``(a0, c0)``)。
    - 返り値: ``(M, 2)`` float64。座標の並び(``(x, y)`` か ``(row, col)``)は
      ``elliptic_fourier`` に渡した並びをそのまま引き継ぐ。``t = 0`` は元輪郭の
      始点に対応する。

    輪郭を係数化せずに滑らかにするだけなら ``fourier_smooth``。係数どうしの
    比較は ``invariants`` / ``descriptor_distance``。

    空の入力(``model`` が空の dict)は ValueError。
    """
    if isinstance(model, dict) and len(model) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("reconstruct: model is empty — pass a non-empty dict")
    coeffs = np.asarray(model["coeffs"], dtype=np.float64)
    N = coeffs.shape[0] if n_harmonics is None else min(int(n_harmonics), coeffs.shape[0])
    t = np.linspace(0.0, 1.0, int(n_points), endpoint=False)
    x = np.full_like(t, model["a0"])
    y = np.full_like(t, model["c0"])
    for n in range(1, N + 1):
        a, b, c, d = coeffs[n - 1]
        ang = 2.0 * np.pi * n * t
        x += a * np.cos(ang) + b * np.sin(ang)
        y += c * np.cos(ang) + d * np.sin(ang)
    return np.column_stack([x, y])


def _amplitudes(coeffs):
    """各高調波の 2×2 係数行列の特異値 (長軸 L, 短軸 W) を返す((N,2), L≥W≥0)。

    第 n 高調波が描く楕円 (a cosφ+b sinφ, c cosφ+d sinφ) の半長軸・半短軸は行列
    [[a,b],[c,d]] の特異値に一致する。特異値は **空間回転(左からの直交変換)** と
    **始点シフト(右からの位相回転)** の両方で不変なので、KG 正規化(第1高調波の
    位相合わせ)が第1高調波が円形のとき悪条件になる問題を避けられる。
    """
    coeffs = np.asarray(coeffs, dtype=np.float64)
    if coeffs.shape[0] == 0:
        return np.empty((0, 2), dtype=np.float64)
    return np.linalg.svd(coeffs.reshape(-1, 2, 2), compute_uv=False)  # 降順


def invariants(model, scale_invariant=True):
    """回転・平行移動・始点・(任意で)スケールに不変な形状記述子((N,2))。

    各高調波の楕円の (長軸, 短軸) = 特異値を並べたもの。DC を含まないので平行移動に
    不変、特異値なので空間回転と始点シフトに不変、第1高調波の長軸で割ればスケール
    不変。形状マッチング(:func:`descriptor_distance`)の土台。

    空の入力(``model`` が空の dict)は ValueError。
    """
    if isinstance(model, dict) and len(model) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("invariants: model is empty — pass a non-empty dict")
    amp = _amplitudes(model["coeffs"])
    if scale_invariant:
        L1 = amp[0, 0]
        # 第 1 高調波が他に比べて潰れていなければ割る(相対の判定。abs-floor2)
        if L1 > 1e-12 * float(amp.max()):
            amp = amp / L1
    return amp


def normalize(model, size_invariant=True):
    """EFD 係数を「正準ポーズ」の係数へ変換する(第1高調波を基準に整列)。

    Kuhl–Giardina の正準化: (1) 第1高調波の位相で **始点** の任意性を除去、(2) 第1
    楕円の長軸を基準軸へ回して **向き** を揃え、(3) 第1高調波の長軸長で割って **大きさ**
    を揃える。複数形状を重ねる/平均する等の「正準ポーズ再構成」向け。

    注意(honest): 第1高調波がほぼ **円形**(長軸≈短軸)の形状では位相 (theta/psi) が
    悪条件で不安定になる。**不変マッチングには本関数でなく** :func:`invariants` /
    :func:`descriptor_distance`(特異値ベース)を使うこと。

    空の入力(``model`` が空の dict)は ValueError。
    """
    if isinstance(model, dict) and len(model) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("normalize: model is empty — pass a non-empty dict")
    coeffs = np.array(model["coeffs"], dtype=np.float64, copy=True)
    a1, b1, c1, d1 = coeffs[0]
    # (1) 始点位相 theta1
    denom = a1 ** 2 - b1 ** 2 + c1 ** 2 - d1 ** 2
    theta1 = 0.5 * np.arctan2(2.0 * (a1 * b1 + c1 * d1), denom)
    for n in range(coeffs.shape[0]):
        m = n + 1
        mat = coeffs[n].reshape(2, 2)
        rot = np.array([[np.cos(m * theta1), -np.sin(m * theta1)],
                        [np.sin(m * theta1), np.cos(m * theta1)]])
        coeffs[n] = (mat @ rot).ravel()
    # (2) 回転 psi1(更新後の第1高調波で)
    a1, c1 = coeffs[0, 0], coeffs[0, 2]
    psi1 = np.arctan2(c1, a1)
    rot_psi = np.array([[np.cos(psi1), np.sin(psi1)],
                        [-np.sin(psi1), np.cos(psi1)]])
    for n in range(coeffs.shape[0]):
        mat = coeffs[n].reshape(2, 2)
        coeffs[n] = (rot_psi @ mat).ravel()
    # (3) スケール(第1高調波の長軸長 E で割る)
    if size_invariant:
        E = np.hypot(coeffs[0, 0], coeffs[0, 2])
        if E > 1e-12 * float(np.abs(coeffs).max()):   # 相対の判定(abs-floor2)
            coeffs = coeffs / E
    return coeffs


def descriptor_distance(m1, m2, n_harmonics=None, scale_invariant=True):
    """2 つの形状間の距離(小さいほど似た形)。回転/平行移動/始点/(任意で)スケール不変。

    各高調波の楕円 (長軸, 短軸) 特異値不変量(:func:`invariants`)の L2 距離。
    m1, m2 は :func:`elliptic_fourier` の出力 dict。

    空の入力(``m1`` が空の dict)は ValueError。
    """
    if isinstance(m1, dict) and len(m1) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("descriptor_distance: m1 is empty — pass a non-empty dict")
    a = invariants(m1, scale_invariant=scale_invariant)
    b = invariants(m2, scale_invariant=scale_invariant)
    N = min(a.shape[0], b.shape[0])
    if n_harmonics is not None:
        N = min(N, int(n_harmonics))
    if N < 1:
        raise ValueError("comparison requires at least 1 harmonic")
    return float(np.linalg.norm(a[:N] - b[:N]))


# --------------------------------------------------------------------------- #
# 複素フーリエ平滑化(輪郭の帯域制限)                                          #
# --------------------------------------------------------------------------- #
def fourier_smooth(points, keep):
    """輪郭を複素 FFT で帯域制限して平滑化する。

    輪郭を複素信号 z(t)=x(t)+i·y(t) と見て FFT し、低周波 ``keep`` 本(と対称成分)
    だけ残して逆変換する。keep が小さいほど滑らか(高周波=細部/ノイズを落とす)。
    keep が全周波数以上なら恒等。返り値は入力と同点数の (N,2)。
    """
    p = _as_contour(points)
    z = p[:, 0] + 1j * p[:, 1]
    N = z.shape[0]
    Z = np.fft.fft(z)
    k = int(keep)
    if k < 1:
        raise ValueError("keep must be at least 1")
    if k >= (N + 1) // 2:
        return p.copy()
    mask = np.zeros(N, dtype=bool)
    mask[0] = True                      # DC(重心)
    mask[1:k + 1] = True                # 低周波(正)
    mask[N - k:] = True                 # 低周波(負, 対称)
    Zf = np.where(mask, Z, 0.0)
    zf = np.fft.ifft(Zf)
    return np.column_stack([zf.real, zf.imag])


# --------------------------------------------------------------------------- #
# 回る振り子の連鎖(2026-09-22)—— 複素フーリエ級数として輪郭を描き直す          #
#   ★この族の既存 op(elliptic_fourier)は Kuhl-Giardina の**実**係数(a,b,c,d)  #
#   で、楕円 1 つ 1 つを表す。こちらは同じ輪郭を**複素**係数 c_k で見る ——       #
#   z(t) = Σ c_k exp(2πikt) と書けるので、各項が「回る腕」そのものになり、        #
#   パーセバルで**打ち切り誤差を描く前に予言できる**。用途が違うので両方置く。    #
# --------------------------------------------------------------------------- #
PARAMETRISATIONS: tuple[str, ...] = ("index", "arclength")

#: 連鎖の並べ方。"frequency" = 低い周波数から(教科書の絵)、
#: "amplitude" = 大きい振幅から(少ない項で似せたいとき)。
CHAIN_ORDERS: tuple[str, ...] = ("frequency", "amplitude")


def _as_closed_contour(points, name="points"):
    p = np.asarray(points, dtype=np.float64)
    if p.ndim != 2 or p.shape[1] != 2:
        raise ValueError(f"{name} must be a sequence of (N,2) points (received: {p.shape})")
    if p.shape[0] < 3:
        raise ValueError(f"{name} needs a closed contour with at least 3 points "
                         f"(received: {p.shape[0]})")
    if not np.all(np.isfinite(p)):
        raise ValueError(f"{name} contains non-finite values")
    return p


def _as_spectrum(spectrum, op):
    s = np.asarray(spectrum, dtype=np.float64)
    if s.ndim != 2 or s.shape[1] != 3:
        raise ValueError(f"{op}: spectrum must be the (2K+1, 3) matrix returned by "
                         f"contour_fourier_complex — columns are [k, Re c_k, Im c_k] "
                         f"(received: {s.shape})")
    if not np.all(np.isfinite(s)):
        raise ValueError(f"{op}: spectrum contains non-finite values")
    k = s[:, 0]
    if np.abs(k - np.round(k)).max() > 0:
        raise ValueError(f"{op}: the first column must be integer frequencies k")
    return np.round(k).astype(np.int64), s[:, 1] + 1j * s[:, 2]


def contour_fourier_complex(points, n_harmonics=None, parametrisation="index"):
    """閉輪郭を複素フーリエ級数の係数にする —— ``z(t) = Σ c_k exp(2πi k t)``。

    引数:
        points: (N,2) の閉輪郭頂点。**(row, col) 順**(``fourierdesc`` と同じ)。
        n_harmonics: 残す次数 ``K``(``|k| <= K``)。``None`` なら表せる上限まで。
        parametrisation: ``"index"`` = 点の添字を等間隔の媒介変数にする /
            ``"arclength"`` = **弧長**で等間隔に打ち直してから変換する。

    返り値: 通常 ``(2K+1, 3)``、偶数点で Nyquist 次数まで残すときは ``(2K, 3)`` の実配列(``matrix``)。行は ``[k, Re c_k, Im c_k]`` で
    ``k`` は ``0, 1, -1, 2, -2, …``(低い周波数から)。

    ★**媒介変数の取り方を既定で黙って決めない**のがこの op の肝。不均一に標本化された
    輪郭を ``"index"`` で読むと、点が密なところに余分な時間が割り当てられ、
    **絵は似ているのに係数が別物**になる(実測で ``k=3`` の係数が 47 倍ちがった)。
    既定は ``"index"``(FFT の素の意味)だが、形の記述として使うなら
    ``"arclength"`` を選ぶこと。

    ★★``"arclength"`` を選ぶと **op の内部で輪郭を打ち直す**ので、返る係数は
    渡した配列ではなく**打ち直した輪郭**を記述する。だから
    :func:`contour_fourier_truncation_energy` の予言は「打ち直した輪郭に対して」
    厳密で、呼び手が手元の配列で誤差を測ると合わない(実測: 512 点で 1.15 ずれた)。
    手元の配列に対して厳密な予言が欲しいときは、**先に弧長で打ち直してから**
    ``"index"`` で呼ぶこと。

    ★**弧長の打ち直しは冪等ではない**: 標本を弦で結ぶので、すでに等弧長の輪郭に
    もう 1 度かけると点が最大 3.73 px 動き(平均 0.84 px)、長さがさらに 3.25 %
    縮む。二度かけないこと。
    """
    op = "contour_fourier_complex"
    if parametrisation not in PARAMETRISATIONS:
        raise ValueError(f"{op}: parametrisation must be one of {PARAMETRISATIONS} "
                         f"(received: {parametrisation!r})")
    p = _as_closed_contour(points)
    # 末尾が先頭と同じなら閉じ点を落とす(標本を二重に数えない)
    if _closing_point_repeated(p):
        p = p[:-1]
        if p.shape[0] < 3:
            raise ValueError(f"{op}: after dropping the repeated closing point the contour "
                             f"has {p.shape[0]} points; at least 3 are needed")
    if parametrisation == "arclength":
        p = _resample_by_arclength(p, op)
    z = p[:, 1] + 1j * p[:, 0]                    # 複素平面: 実軸 = col, 虚軸 = row
    n = z.shape[0]
    kmax = n // 2
    if n_harmonics is None:
        K = kmax
    else:
        if isinstance(n_harmonics, bool) or not isinstance(n_harmonics, (int, np.integer)):
            raise ValueError(f"{op}: n_harmonics must be an int or None "
                             f"(received: {n_harmonics!r})")
        K = int(n_harmonics)
        if K < 1:
            raise ValueError(f"{op}: n_harmonics must be at least 1 (received: {K})")
        if K > kmax:
            raise ValueError(
                f"{op}: n_harmonics={K} asks for more detail than {n} samples carry — "
                f"the highest frequency a closed contour of {n} points determines is "
                f"{kmax} (Nyquist). Resample the contour first, or ask for {kmax} or fewer; "
                f"inventing the missing coefficients as zero would report an error floor "
                f"that the data cannot support.")
    c = np.fft.fft(z) / n                          # c[k] for k = 0..n-1 (負は折り返し)
    # ★偶数点では添字 n/2 が **k = +n/2 と k = -n/2 の同じ 1 つの係数**である。
    #   両方を並べるとエネルギーを 1 本ぶん多く数えて**パーセバルが破れる**
    #   (実測: n=8 で 1.17e-01、n=512 で 7.5e-03 ずれた)。numpy の
    #   ``fft.fftfreq`` に合わせて **k = -n/2 の側だけ**を出す。
    #   最初の検査(正方形の輪郭)はこの係数がたまたま 0 に近くて通っていた ——
    #   探針 1 枚では足りない、の実例。
    nyquist = (n % 2 == 0)
    ks, rows = [], []
    for k in range(0, K + 1):
        if nyquist and k == n // 2:
            continue                               # 下で -n/2 として 1 度だけ出す
        ks.append(k)
        rows.append(c[k])
        if k > 0:
            ks.append(-k)
            rows.append(c[-k])
    if nyquist and K >= n // 2:
        ks.append(-(n // 2))
        rows.append(c[n // 2])
    out = np.empty((len(ks), 3), dtype=np.float64)
    out[:, 0] = np.asarray(ks, dtype=np.float64)
    out[:, 1] = np.real(rows)
    out[:, 2] = np.imag(rows)
    return np.ascontiguousarray(out)


def _resample_by_arclength(p, op):
    """閉輪郭を弧長で等間隔に打ち直す(点数は変えない)。"""
    q = np.vstack([p, p[0]])
    seg = np.hypot(np.diff(q[:, 0]), np.diff(q[:, 1]))
    t = np.concatenate([[0.0], np.cumsum(seg)])
    total = float(t[-1])
    if total <= 0.0:
        raise ValueError(f"{op}: the contour perimeter is 0 (all points coincide)")
    want = np.linspace(0.0, total, p.shape[0], endpoint=False)
    r = np.interp(want, t, q[:, 0])
    cc = np.interp(want, t, q[:, 1])
    return np.stack([r, cc], axis=1)


def contour_epicycle_chain(spectrum, phase, order="frequency"):
    """位相 ``t`` における**回る振り子の連鎖**を返す(``pairs``)。

    引数:
        spectrum: :func:`contour_fourier_complex` の ``(2K+1, 3)``。
        phase: ``t``(1 周 = 1.0)。
        order: ``"frequency"`` = 低い周波数から積む(教科書の絵)/
            ``"amplitude"`` = 振幅の大きい順(少ない項で似せる)。

    返り値: ``(M+1, 2)`` の ``pairs``((row, col) 順)。行 0 が最初の腕の中心、
    行 ``m`` が ``m`` 番目の腕の先(= 次の腕の中心)、**最後の行が筆先**で、
    これが再構成された輪郭の点そのものになる。腕 ``m`` の長さは
    ``|c_k|``、角度は ``2π k t + arg c_k``。
    """
    op = "contour_epicycle_chain"
    if order not in CHAIN_ORDERS:
        raise ValueError(f"{op}: order must be one of {CHAIN_ORDERS} (received: {order!r})")
    k, c = _as_spectrum(spectrum, op)
    t = float(phase)
    if not np.isfinite(t):
        raise ValueError(f"{op}: phase must be finite (received: {phase!r})")
    if order == "amplitude":
        idx = np.argsort(-np.abs(c), kind="stable")
    else:
        idx = np.argsort(np.abs(k) * 2 + (k < 0), kind="stable")
    terms = c[idx] * np.exp(2j * np.pi * k[idx] * t)
    tip = np.concatenate([[0.0 + 0.0j], np.cumsum(terms)])
    out = np.stack([np.imag(tip), np.real(tip)], axis=1)      # (row, col)
    return np.ascontiguousarray(out)


def contour_fourier_truncation_energy(spectrum, orders=None):
    """打ち切り次数ごとの**予言される**誤差(``table``)—— パーセバルの厳密式。

    次数 ``K`` で打ち切った再構成 ``z^K`` について、標本上の二乗平均誤差は
    ``mean|z - z^K|^2 = Σ_{|k| > K} |c_k|^2`` に**厳密に等しい**。だから
    再構成を 1 度もせずに「何項あれば何画素まで似るか」を先に言える。

    ★**予言が厳密なのは、係数列が完全なときだけ**である(``contour_fourier_complex``
    を ``n_harmonics=None`` で呼んだ場合)。打ち切った係数列を渡されると、
    捨てられた側のエネルギーは**知りようがない**ので、返る誤差は**下界**になる
    —— 過小に見える誤差を「厳密」と言わないために、ここに書いておく。

    返り値: dict(``table``)
        "order": 打ち切り次数 ``K`` の 1-D
        "rms_error": 予言される rms 誤差[入力の単位]
        "energy_fraction": 残した項が担うエネルギーの割合(``0..1``、単調増加)
        "total_energy": ``Σ_{k≠0} |c_k|^2``(位置 ``c_0`` を除いた形のエネルギー)
        "k_max": スペクトルが持つ最大次数
    """
    op = "contour_fourier_truncation_energy"
    k, c = _as_spectrum(spectrum, op)
    kmax = int(np.abs(k).max())
    power = np.abs(c) ** 2
    shape_total = float(power[k != 0].sum())
    if orders is None:
        ks = np.arange(0, kmax + 1, dtype=np.int64)
    else:
        ks = np.asarray(orders, dtype=np.int64).ravel()
        if ks.size == 0:
            raise ValueError(f"{op}: orders must not be empty")
        if ks.min() < 0 or ks.max() > kmax:
            raise ValueError(f"{op}: orders must lie in [0, {kmax}] "
                             f"(received {ks.min()}..{ks.max()})")
    rms, frac = [], []
    for K in ks:
        tail = float(power[np.abs(k) > K].sum())
        rms.append(np.sqrt(max(tail, 0.0)))
        frac.append(1.0 if shape_total <= 0.0
                    else float(power[(np.abs(k) <= K) & (k != 0)].sum() / shape_total))
    return {"order": np.asarray(ks, dtype=np.int64),
            "rms_error": np.asarray(rms, dtype=np.float64),
            "energy_fraction": np.asarray(frac, dtype=np.float64),
            "total_energy": shape_total,
            "k_max": kmax}
