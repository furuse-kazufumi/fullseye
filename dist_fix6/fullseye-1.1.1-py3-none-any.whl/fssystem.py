# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""fssystem —— **システムパラメータ**(``set_system`` / ``get_system`` の相互運用面)。

産業用の画像処理ライブラリには、ライブラリ全体のふるまいを一箇所で切り替える
パラメータ群があるのが普通で、``set_system`` / ``get_system`` / ``query_system``
という**実在の名前**を相互運用のためにそのまま借りている(``docs/PROVENANCE.md``
の命名規約: 相互運用のための識別子は可、自分たちの物に他社製品名を付けるのは不可)。

## 2 つの制約 —— ここが素朴な実装と違うところ

### (1) 可変グローバルにしない

実体は :mod:`contextvars`。``drawstyle`` が同じ判断をしていて、理由もそのまま:

* 展示画像は**再生成で SHA-256 一致**が要件。共有された可変既定があると
  「どの図を先に描いたか」が結果に混ざる。
* 生成器は**並行に走る**。共有既定はレースで入れ替わり、**例外にならず
  「もっともらしく間違った図」**として出てくる。

``contextvars`` ならスレッド/タスクごとに独立し、例外経路でも復帰する。

### (2) **緩められない** —— 厳しくするか、意図を記録するかだけ

これがこのモジュールの中心的な設計判断。素朴なシステムパラメータは
「検査を切って速くする」ために使われるが、この repo では**それが最も危ない**。
``data_range`` の既定を隠れたパラメータで供給できるようにすると、
``[0,1]`` の絵を 255 の設定で測った **PSNR が 48.13 dB ずれる**のに、
呼び出し側のコードは 1 文字も変わらない ―― 追跡不能な事故になる。

よって、登録できるパラメータは次のどちらかに限る:

* **厳しくする方向のみ** —— 既定が最も緩い側で、変更すると検査が増える。
  (:data:`SYSTEM_PARAMS` の ``tightens_only=True``)
* **意図の記録のみ** —— 数値には一切影響せず、報告に何が書かれるかだけが変わる。

``tightens_only`` の宣言はテストが機械で検査する(``tests/test_fssystem.py``)。
**「速くするために検査を切る」パラメータはこの表に載せられない。**

使い方::

    import fullseye as fs

    fs.get_system("metric_contract")             # -> 'strict'(既定)

    with fs.system(metric_contract="tolerant"):  # 範囲を限って切り替える
        ...                                       # (予約のみ: 今はまだ何も読まない)

    old = fs.set_system("extra_checks", "on")    # その文脈で切り替え、前の値が返る
    fs.reset_system()                            # 全部を既定へ

### (3) 読み手が居ないパラメータは「予約」と表に書く

``metric_contract`` / ``unmeasurable_policy`` は受理・記録されるが、**2026-09 時点で
読むコードが無い**(``applied_by=None``)。設定しても数値も経路も変わらない。
効いていない設定を「効く」と読ませないため、各項目の ``applied_by`` に実際に
``get_system`` を呼ぶファイルを列挙し、テストが grep で突き合わせる。
"""
from __future__ import annotations

import contextlib
import contextvars

__all__ = [
    "SYSTEM_PARAMS", "set_system", "get_system", "query_system",
    "system", "reset_system", "system_snapshot", "PROFILES", "save_profile", "resolve_profile",
    "PLAN_MAX_EXPANSIONS_DEFAULT", "PLAN_MAX_GENERATED_DEFAULT", "PLAN_WALL_SAFETY_MS",
]


# JA: 通常探索の決定的上限(展開節数)。2026-11-22 の業務6件、RAG 40件、優先度キュー試験での
# 最大は各36,389、45,971、17,395節で、全件が未打ち切り結果と一致したため50,000節とする。
# EN: Deterministic normal-search cap in expanded nodes; the measured maxima above all exhausted the heap.
PLAN_MAX_EXPANSIONS_DEFAULT = 50_000

# JA: 1探索でheapへ積む候補数の決定的上限(件)。2026-11-22に業務6件、RAG 40件、
# 優先度キュー試験40 wantの後方・前方再生を使い切るまで測った最大は45,971件だった。
# 100,000件ならk=20 registerもb8cd6e9c75と同じ2計画を返し、実測20--30 us/件から
# 2.0--3.0秒、CIを2.6倍としても5.2--7.8秒である。
# EN: Deterministic cap in generated heap candidates per search; the measured representative maximum
# was 45,971.  A 100k cap preserves b8cd6e9c75's two k=20 register plans and takes 2.0--3.0 s
# at 20--30 us/candidate, or 5.2--7.8 s at the 2.6x CI factor.
PLAN_MAX_GENERATED_DEFAULT = 100_000

# JA: 異常時だけの壁時計安全弁(ms)。上のpush上限から見積もるCI最悪値7.8秒の7倍超で、
# 通常探索は到達しない。決定的上限が働かない異常だけを60秒で止める。
# EN: Emergency wall-clock fuse in milliseconds, over 7x the 7.8 s CI worst-case estimate from
# the generated-candidate cap; normal searches stop at deterministic limits before reaching it.
PLAN_WALL_SAFETY_MS = 60_000


#: 登録済みシステムパラメータ。
#:
#: ``tightens_only`` が ``True`` のものは、既定から動かすと**検査が増える**だけ。
#: ``False`` のものは**数値に一切影響しない**(報告の記述が変わるだけ)。
#: 「検査を切って速くする」種類のパラメータはここに載せられない —— 載せると
#: ``tests/test_fssystem.py`` の宣言検査が落ちる。
#:
#: ``applied_by`` は**その値を実際に読むモジュール**(``get_system("<name>")`` を
#: 呼ぶファイル名のタプル)。``None`` は **予約のみ**: 値は受理・記録されるが
#: **まだ何も読まない**(設定しても挙動は 1 bit も変わらない)。「設定できるのに
#: 効いていない」を仕様書の文章でなく表で言い、``tests/test_fssystem.py`` が
#: grep で裏を取る(読み手を名乗るのに読んでいない/数値に影響するのに読み手が
#: 無い、はどちらも落ちる)。
SYSTEM_PARAMS = {
    "metric_contract": {
        "values": ("strict", "tolerant"),
        "default": "strict",
        "tightens_only": False,
        "affects_numbers": False,
        "applied_by": None,
        "doc": (
            "測定 op を人が呼んでいるのか(strict)、自動で回しているのか(tolerant)。"
            "**op 自身はこの値を読まない** —— 読むと隠れた状態で返り値の型が変わり、"
            "この repo がいちばん嫌う『例外でなく、もっともらしく間違う』になる。"
            "★予約のみ(applied_by=None): 現状 metriccontract の寛容な入口"
            "(attempt/rank_attempts)はこの値を読まず、明示的に呼び分ける。"
            "設定は system_snapshot() で報告に写るだけで、数値も経路も変えない。"
        ),
    },
    "extra_checks": {
        "values": ("off", "on"),
        "default": "off",
        "tightens_only": True,
        "affects_numbers": False,
        "applied_by": ("api.py", "colortransport.py", "imgmetrics.py", "reprconv.py"),
        "doc": (
            "★2026-09-08 に api.py と reprconv.py を追加。api.py は ``image``/``color`` の"
            "**値域 [0,1] 契約**を見る —— dtype は既定で fail-closed なのに値域は"
            "``ops.py`` の 1 行目に書いてあるだけで誰も検査しておらず、µm 単位の"
            "高さ場を渡すと Otsu が 0.5 µm で切って blob 387 個(正解 256)になった。"
            "reprconv.py は位置の点群を法線として渡す事故を捕まえる。"
            "既定でも fail-closed だが、**理屈の上では正しくないが実害が出るとは"
            "限らない**場面(同値を引き裂くヒストグラム整合、対称でない圧縮距離)を"
            "拒否に格上げする。既定を on にしていないのは、既存の呼び手が"
            "意図してその挙動を使っている場合があるため。"
        ),
    },
    "unmeasurable_policy": {
        "values": ("worst", "skip"),
        "default": "worst",
        "tightens_only": False,
        "affects_numbers": False,
        "applied_by": None,
        "doc": (
            "寛容な契約で『測れなかった』候補をどう扱うか。worst = 最悪値に倒して"
            "順位の最下位に置く / skip = 順位から外す。**strict の経路には無関係**。"
            "★予約のみ(applied_by=None): rank_attempts は常に worst(最下位)で、"
            "skip を設定しても順位は変わらない。"
        ),
    },
    "find_ops_k": {"values": (3, 5, 7), "default": 7, "tightens_only": True,
                   "affects_numbers": False, "applied_by": ("fullseye/opsearch.py", "fullseye/mcp/server.py"), "doc": "Default number of diverse operator proposals."},
    "find_ops_recipe_max": {"values": (0, 1, 2), "default": 2, "tightens_only": True,
                            "affects_numbers": False, "applied_by": ("fullseye/mcp/server.py",), "doc": "Maximum recipe-derived proposals within the find_ops total."},
    "plan_k": {"values": (1, 3, 5, 7), "default": 7, "tightens_only": True,
               "affects_numbers": False, "applied_by": ("fullseye/opsearch.py",), "doc": "Maximum returned plans."},
    "plan_max_depth": {"values": (2, 4), "default": 4, "tightens_only": True,
                       "affects_numbers": False, "applied_by": ("fullseye/opsearch.py",), "doc": "Maximum hypergraph depth."},
    "plan_max_expansions": {"values": (1000, 10000, PLAN_MAX_EXPANSIONS_DEFAULT),
                            "default": PLAN_MAX_EXPANSIONS_DEFAULT, "tightens_only": True,
                            "affects_numbers": False, "applied_by": ("fullseye/opsearch.py",),
                            "doc": "Deterministic planner expansion cap."},
    "plan_timeout_ms": {"values": (10000, 30000, PLAN_WALL_SAFETY_MS),
                        "default": PLAN_WALL_SAFETY_MS, "tightens_only": True,
                        "affects_numbers": False, "applied_by": ("fullseye/opsearch.py",),
                        "doc": "Emergency planner wall-time safety fuse in milliseconds."},
    "mcp_response_budget": {"values": (16000, 128000, 256000, 512000), "default": 512000, "tightens_only": True,
                            "affects_numbers": False, "applied_by": ("fullseye/mcp/server.py",), "doc": "Structured response byte cap."},
    "mcp_body_mode": {"values": ("compact", "duplicate"), "default": "compact", "tightens_only": False,
                      "affects_numbers": False, "applied_by": ("fullseye/mcp/server.py",), "doc": "Avoid duplicating structured JSON in text."},
    "mcp_handle_max_bytes": {"values": (67108864, 134217728), "default": 134217728, "tightens_only": True,
                              "affects_numbers": False, "applied_by": ("fullseye/mcp/handles.py",), "doc": "LRU byte cap for live MCP handles."},
    "mcp_pipeline_max_intermediate_bytes": {"values": (67108864, 134217728), "default": 134217728, "tightens_only": True,
                              "affects_numbers": False, "applied_by": ("fullseye/mcp/server.py",), "doc": "Cumulative byte cap for outputs produced by one MCP pipeline request."},
    "mcp_stack_max_pixels": {"values": (16777216, 33554432), "default": 33554432, "tightens_only": True,
                              "affects_numbers": False, "applied_by": ("fullseye/mcp/server.py", "fullseye/mcp/handles.py"),
                              "doc": "Pixel cap for MCP image loads, stacks, and operation outputs (image headers are checked before decoding)."},
    "mcp_op_time_limit_s": {"values": (5, 10, 30), "default": 30, "tightens_only": True,
                            "affects_numbers": False, "applied_by": ("fullseye/mcp/server.py",),
                            "doc": "Wall-time cap for one ledger op run in the isolated MCP worker; the worker is killed when it is exceeded."},
    "mcp_op_memory_limit_bytes": {"values": (268435456, 1073741824, 2147483648), "default": 2147483648, "tightens_only": True,
                                  "affects_numbers": False, "applied_by": ("fullseye/mcp/server.py",),
                                  "doc": "Memory-growth cap for one ledger op run in the isolated MCP worker; the worker stops itself when it is exceeded."},
    "pipeline_max_stages": {"values": (16, 32, 64), "default": 64, "tightens_only": True,
                            "affects_numbers": False, "applied_by": ("fullseye/mcp/server.py",), "doc": "Pipeline stage cap."},
    "random_seed": {"values": (0, 1, 42), "default": 0, "tightens_only": False,
                    "affects_numbers": True, "applied_by": None, "doc": "Reserved default seed; stochastic ops receive profile seeds explicitly."},
    "tile_size": {"values": (256, 512, 1024), "default": 512, "tightens_only": False,
                  "affects_numbers": False, "applied_by": None, "doc": "Reserved large-image tile edge."},
    "border_policy": {"values": ("reflect", "nearest", "constant"), "default": "reflect", "tightens_only": False,
                      "affects_numbers": True, "applied_by": None, "doc": "Reserved neighborhood border policy."},
    "numeric_floor": {"values": (1e-15, 1e-12, 1e-9), "default": 1e-12, "tightens_only": False,
                      "affects_numbers": True, "applied_by": None, "doc": "Reserved numerical denominator floor."},
    "iteration_limit": {"values": (50, 100), "default": 100, "tightens_only": True,
                        "affects_numbers": False, "applied_by": None, "doc": "Reserved iterative solver cap."},
    "gpu_idle_policy": {"values": ("strict", "disabled"), "default": "strict", "tightens_only": True,
                        "affects_numbers": False, "applied_by": ("tools/measure_device_crossover.py",), "doc": "GPU measurement admission policy."},
}

# ★2026-11-05(敵対的検証 第 2 巡 T5): tightens_only=True の数値の上限 10 項目が、既定より**大きい**値
#   (find_ops_k=10、mcp_stack_max_pixels=64 Mpx、plan_max_depth=16 …)を受け付け、上の docstring の
#   「緩められない」を破っていた。既定より緩い値を表から外し、ここで機械的に止める(足し直すと import で落ちる)。
for _name, _spec in SYSTEM_PARAMS.items():
    if _spec["tightens_only"] and all(isinstance(v, (int, float)) and not isinstance(v, bool)
                                      for v in _spec["values"]):
        if max(_spec["values"]) != _spec["default"]:
            raise AssertionError("fssystem: %r is tightens_only but allows %r above its default %r"
                                 % (_name, [v for v in _spec["values"] if v > _spec["default"]], _spec["default"]))
del _name, _spec

PROFILES = {
    "deflectometry_rig": {"width_mm":300.0,"height_mm":200.0,"period_mm":10.0,
                           "phase_steps":4,"orientation":"xy","decode_k":1.0},
    "camera_default": {"K":[[1000.0,0.0,512.0],[0.0,1000.0,384.0],[0.0,0.0,1.0]]},
    "product_default": {"material":"generic_glass","refractive_index":1.5,
                         "detection_threshold":0.5,"tolerance_mm":0.1},
    "simulation_default": {"noise_sigma":0.0,"bits":12,"seed":0},
}

def save_profile(name, values):
    if not isinstance(name,str) or not name or "." in name or not isinstance(values,dict):
        raise ValueError("profile requires a simple name and object values")
    PROFILES[name]=dict(values)

def resolve_profile(reference):
    if not isinstance(reference,str) or "." not in reference:
        raise ValueError("profile reference must be '<name>.<item>'")
    name,path=reference.split(".",1)
    if name not in PROFILES:
        raise ValueError("unknown profile %r; known: %s"%(name,sorted(PROFILES)))
    value=PROFILES[name]
    for part in path.split("."):
        if not isinstance(value,dict) or part not in value:
            raise ValueError("unknown profile item %r in %s"%(path,name))
        value=value[part]
    return value

_VARS = {
    name: contextvars.ContextVar(f"fssystem.{name}", default=spec["default"])
    for name, spec in SYSTEM_PARAMS.items()
}


def _check(param, value):
    if param not in SYSTEM_PARAMS:
        raise ValueError(
            f"unknown system parameter {param!r}; known: {sorted(SYSTEM_PARAMS)} "
            "(silently accepting an unknown name would let a typo look like it took effect)"
        )
    allowed = SYSTEM_PARAMS[param]["values"]
    if value not in allowed:
        raise ValueError(f"system parameter {param!r} takes one of {allowed}, got {value!r}")
    return value


def get_system(param):
    """システムパラメータ(``set_system`` で設定する値)の現在値を返す。

    **Raises** ``ValueError``: 知らないパラメータ名(既知の名前の一覧を添える)。
    """
    if param not in _VARS:
        raise ValueError(f"unknown system parameter {param!r}; known: {sorted(SYSTEM_PARAMS)}")
    return _VARS[param].get()


def set_system(param, value):
    """システムパラメータを**現在の文脈で**切り替え、**前の値を返す**。

    プロセス全体の可変グローバルではない(:mod:`contextvars` なのでスレッド/
    タスクごとに独立)。前の値を返すのは、呼び手が明示的に戻せるようにするため
    —— 範囲を限るなら :func:`system` の方が安全。
    """
    _check(param, value)
    old = _VARS[param].get()
    _VARS[param].set(value)
    return old


@contextlib.contextmanager
def system(**params):
    """範囲を限ってシステムパラメータを切り替える文脈。

    ``with system(metric_contract="tolerant"): ...``。
    例外で抜けても必ず元へ戻る(トークンで復帰する)。
    """
    for k, v in params.items():
        _check(k, v)
    tokens = {k: _VARS[k].set(v) for k, v in params.items()}
    try:
        yield
    finally:
        for k, tok in tokens.items():
            _VARS[k].reset(tok)


def reset_system():
    """すべてのシステムパラメータを既定へ戻す。"""
    for name, spec in SYSTEM_PARAMS.items():
        _VARS[name].set(spec["default"])


def query_system(param=None):
    """パラメータの一覧、または 1 つの仕様(取りうる値・既定・説明)。"""
    if param is None:
        return sorted(SYSTEM_PARAMS)
    if param not in SYSTEM_PARAMS:
        raise ValueError(f"unknown system parameter {param!r}; known: {sorted(SYSTEM_PARAMS)}")
    return dict(SYSTEM_PARAMS[param])


def system_snapshot():
    """現在値をまとめて返す。**報告に何の設定で測ったかを書くため**。

    数値だけを図注に写して条件が消える事故を防ぐのが、この repo の一貫した
    方針なので、システムパラメータも同じように持ち回れる形にしておく。
    """
    return {name: var.get() for name, var in sorted(_VARS.items())}


if __name__ == "__main__":     # pragma: no cover - 手元確認用
    print(f"fssystem: {len(SYSTEM_PARAMS)} params")
    for name, spec in sorted(SYSTEM_PARAMS.items()):
        kind = "厳しくする方向のみ" if spec["tightens_only"] else "数値に影響しない"
        print(f"  {name:22s} {spec['values']}  既定={spec['default']!r}  ({kind})")
