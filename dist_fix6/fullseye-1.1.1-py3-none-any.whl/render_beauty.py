# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""render_beauty — 「映える静止 3D」の総仕上げ(hero レンダラ)。

これまで個別に実装してきたレンダリング品質層 —— ラスタライズ(``render3d``)/ 鏡面陰影
(``render_shade``)/ アンビエントオクルージョン(``render_ao``)/ 接地影(``render_shadow``)/
スーパーサンプリング(``render_ssaa``)/ トーンマッピング(``render_tonemap``)—— を **1 本の
パイプラインに合成**し、メッシュを渡すだけで「科学館の台座に載った作品写真」のような 1 枚を
返す capstone op。各層は既に単体で検証済みなので、本モジュールは **再発明せず合成するだけ**。

パイプライン(``size*ss`` の高解像度でレンダ → 最後に ``antialias`` で ``size`` へ area 縮小):

  1. ``pose``/``intrinsics`` 未指定なら ``render3d.auto_view`` がメッシュを枠に収める。
  2. ``ground_shadow`` のとき、メッシュ真下に地面平面(quad 2 三角形)を足して同一シーンに合成
     (z バッファがオクルージョンとシルエットを解決 —— これで「台座に載る」見えになる)。
  3. ``render3d.render_mesh`` で depth / silhouette / 面法線を得る(高解像度)。
  4. 陰影: ``material='matcap'`` は ``render_shade.matcap_shade``、それ以外は ``render_shade.phong_shade``
     を ``clip=False``(HDR)で拡散ローブ・鏡面ローブに分けて評価し、素材ごとの反射色で合成。
     ``metal`` は鏡面を強く / 反射色を albedo 寄りに、``plastic`` は白いハイライト。
  5. ``ao=True``: ``render_ao.ambient_occlusion`` を環境光 + 拡散項へ乗算(凹部・接触が落ちる)。
  6. ``ground_shadow=True``: ``render_shadow.cast_shadow`` の可視性を直接光(拡散 + 鏡面)へ乗算
     (地面のメッシュ直下が暗くなる接地影)。環境光は影に残す(空光は遮蔽されない物理に合わせる)。
  7. シルエット外は ``background`` で合成、``tonemap``(none 以外)で HDR→[0,1]。
  8. ``render_ssaa.antialias`` で ``size`` へ area-downsample。

**決定的**: 乱数を使わない(``vertex_occlusion`` はフィボナッチ半球、``cast_shadow`` は
フィボナッチディスク、いずれも決定的)。同一入力は同一画素を返す。

honest な前提(証明していない能力は主張しない):
  * 面法線は ``render_mesh`` 由来の **フラット(面ごと)** —— 曲面はファセットが出る(SSAA と
    トーンマップで緩和されるが除去はしない)。鏡面ローブは経験的 ``cos^n``(GGX 等の物理ベース
    ではない)。AO・影は各下位 op の限界(モンテカルロ分散 / shadow map 解像度)をそのまま継ぐ。
  * 地面は水平パッチで、接地影と接地 AO を担う簡易ステージ。大域照明(相互反射)は無い。

numpy + scipy のみ(下位 op 経由)。fail-closed: メッシュ形状 / 非有限 / 空 / ``ss<1`` /
不正 ``material`` / 不正 ``tonemap`` / 不正な色・光・露出は ``ValueError``。
"""
from __future__ import annotations

from typing import Optional, Sequence

import numpy as np

import matappear
import render3d
import render_ao
import render_shade
import render_shadow
import render_ssaa
import render_tonemap

__all__ = ["render_beauty", "render_regolith"]

#: 対応マテリアルのプリセット(拡散 / 鏡面 / 光沢 / 金属フラグ)。
_MATERIALS: dict[str, dict] = {
    # 誘電体(プラスチック): 拡散が主・ハイライトは白・中程度の光沢。
    "plastic": {"diffuse": 0.85, "specular": 0.45, "shininess": 32.0, "metal": False},
    # 金属: 拡散を抑え・鏡面を強く・ハイライトは素材色(albedo)で色付く・鋭い光沢。
    "metal": {"diffuse": 0.22, "specular": 0.95, "shininess": 90.0, "metal": True},
}
_TONEMAPS = ("reinhard", "aces", "none", "linear")   # linear = none(露出 × クリップ、AMICA 風)
_BRDFS = ("phong", "lambert", "lommel_seeliger", "hapke")
#: 微細構造の見え方(matappear)。"none" 以外は物体画素の鏡面項を置き換える。
_SURFACES = ("none", "brushed", "grating", "thinfilm")

#: 地面(pedestal)の反射率と質感(ややマットな中間グレー)。
_GROUND_ALBEDO = np.array([0.55, 0.56, 0.58], np.float64)
_GROUND_SPECULAR = 0.06
_GROUND_SHININESS = 16.0


# --------------------------------------------------------------------------- #
# fail-closed 入力検証                                                          #
# --------------------------------------------------------------------------- #
def _validate_mesh(V, F) -> tuple[np.ndarray, np.ndarray]:
    """``(V, F)`` を float64 (N,3) 頂点 + int64 (M,3) 面へ検証。fail-closed。"""
    Vv = np.asarray(V, np.float64)
    if Vv.ndim != 2 or Vv.shape[1] != 3:
        raise ValueError(f"V must be (N, 3), got shape {Vv.shape}")
    if Vv.shape[0] == 0:
        raise ValueError("mesh has no vertices")
    if not np.isfinite(Vv).all():
        raise ValueError("V contains non-finite values")
    Ff = np.asarray(F)
    if Ff.ndim != 2 or Ff.shape[1] != 3:
        raise ValueError(f"F must be (M, 3) triangles, got shape {Ff.shape}")
    Ff = Ff.astype(np.int64)
    if Ff.shape[0] == 0:
        raise ValueError("mesh has no faces")
    lo, hi = int(Ff.min()), int(Ff.max())
    if lo < 0 or hi >= Vv.shape[0]:
        raise ValueError(f"face index {hi if hi >= Vv.shape[0] else lo} "
                         f"out of range for {Vv.shape[0]} vertices")
    return Vv, Ff


def _as_color(x, name: str) -> np.ndarray:
    """長さ 3 の色/反射率を [0, ∞) の float64 (3,) へ検証(有限・非負)。fail-closed。"""
    c = np.asarray(x, np.float64).reshape(-1)
    if c.shape != (3,):
        raise ValueError(f"{name} must be a length-3 RGB triple, got shape {c.shape}")
    if not np.isfinite(c).all():
        raise ValueError(f"{name} contains non-finite values")
    if np.any(c < 0.0):
        raise ValueError(f"{name} must be non-negative, got {x!r}")
    return c


def _as_light(x) -> np.ndarray:
    """光源方向(シーン→光源)を単位化した float64 (3,) へ検証。fail-closed。"""
    d = np.asarray(x, np.float64).reshape(-1)
    if d.shape != (3,):
        raise ValueError(f"light must be a length-3 vector, got shape {d.shape}")
    if not np.isfinite(d).all():
        raise ValueError("light contains non-finite values")
    n = float(np.linalg.norm(d))
    if n < 1e-12:
        raise ValueError("light is a zero-length vector (undefined direction)")
    return d / n


# --------------------------------------------------------------------------- #
# 地面(pedestal)ステージ                                                       #
# --------------------------------------------------------------------------- #
def _ground_quad(Vmesh: np.ndarray, light_world: np.ndarray, drop: float,
                 span_scale: float, subdiv: int = 12
                 ) -> tuple[np.ndarray, np.ndarray, float, float]:
    """メッシュ真下の水平地面 grid(``subdiv``×``subdiv`` セル, +Z 法線)を作る。

    地面の高さはメッシュ最下点のわずか下、広さはメッシュ XY 半径 × ``span_scale``。影が落ちる
    側(光と反対の XY 方向)へ中心をずらして、接地影が枠内の地面に確実に載るようにする。細分割
    することで AO(接地の柔らかい暗化リング)が頂点間で滑らかに補間され、2 三角形のときの
    まだら模様を避ける。返り値 ``(Vg, Fg, ground_z, eps_ground)``。"""
    lo = Vmesh.min(axis=0)
    hi = Vmesh.max(axis=0)
    center_xy = 0.5 * (lo[:2] + hi[:2])
    radius_xy = float(np.linalg.norm(hi[:2] - lo[:2])) * 0.5 + 1e-6
    ext = float(hi[2] - lo[2])
    scene = max(float(np.linalg.norm(hi - lo)), 1e-6)
    ground_z = float(lo[2]) - drop * max(ext, radius_xy)
    half = radius_xy * span_scale
    # 影方向(光の XY 逆)へ中心をオフセット(片側に伸ばして影を受ける)。
    lxy = light_world[:2]
    ln = float(np.linalg.norm(lxy))
    shift = (-lxy / ln) * half * 0.45 if ln > 1e-9 else np.zeros(2)
    cx, cy = center_xy + shift
    n = max(int(subdiv), 1) + 1                          # 頂点数 = セル数 + 1
    xs = np.linspace(cx - half, cx + half, n)
    ys = np.linspace(cy - half, cy + half, n)
    X, Y = np.meshgrid(xs, ys, indexing="ij")
    Vg = np.column_stack([X.ravel(), Y.ravel(),
                          np.full(X.size, ground_z, np.float64)])
    faces = []
    for i in range(n - 1):
        for j in range(n - 1):
            a = i * n + j
            b = i * n + (j + 1)
            c = (i + 1) * n + (j + 1)
            d = (i + 1) * n + j
            faces.append([a, c, b])                     # +Z 外向き法線(上向き)
            faces.append([a, d, c])
    Fg = np.asarray(faces, np.int64)
    eps_ground = 1e-4 * scene
    return Vg, Fg, ground_z, eps_ground


# --------------------------------------------------------------------------- #
# 陰影ヘルパー                                                                  #
# --------------------------------------------------------------------------- #
def _lobes(normals: np.ndarray, view_cam: np.ndarray, light_cam: np.ndarray,
           shininess: float) -> tuple[np.ndarray, np.ndarray]:
    """法線マップから拡散ローブ ``max(N·L,0)`` と鏡面ローブ ``max(R·V,0)^n`` を HDR で得る。

    ``render_shade.phong_shade`` を係数を分離して 2 回呼ぶ(``clip=False``)。背景(長さ0法線)は 0。
    """
    diff = render_shade.phong_shade(normals, view=view_cam, light=light_cam,
                                    ambient=0.0, diffuse=1.0, specular=0.0,
                                    shininess=shininess, clip=False)
    spec = render_shade.phong_shade(normals, view=view_cam, light=light_cam,
                                    ambient=0.0, diffuse=0.0, specular=1.0,
                                    shininess=shininess, clip=False)
    return diff, spec


# --------------------------------------------------------------------------- #
# hero レンダラ                                                                 #
# --------------------------------------------------------------------------- #
def render_beauty(V, F, *, pose=None, intrinsics=None, size: int = 512, ss: int = 2,
                  light: Sequence[float] = (0.3, 0.4, 1.0),
                  albedo: Sequence[float] = (0.8, 0.8, 0.85),
                  material: str = "plastic", matcap=None, ambient: float = 0.12,
                  ao: bool = True, ground_shadow: bool = True,
                  tonemap: str = "reinhard",
                  background: Sequence[float] = (0.10, 0.11, 0.13),
                  exposure: float = 1.0, shininess: Optional[float] = None,
                  ao_samples: int = 32, shadow_res: int = 512,
                  penumbra: float = 2.5, shadow_samples: int = 12,
                  shadow_pcf: int = 1, brdf: str = "phong", brdf_params=None,
                  shadow_method: str = "map", sun_angular_diameter_deg: float = 0.0,
                  self_illumination: float = 0.0, albedo_variation: float = 0.0,
                  albedo_scale=None, seed: int = 0,
                  smooth_normals: bool = False, bump=None,
                  vertex_normals=None, vertex_albedo=None,
                  surface: str = "none", surface_params=None) -> np.ndarray:
    """メッシュを全品質層合成で「映える静止 3D」1 枚に描く → RGB ``(size, size, 3)`` float [0,1]。

    引数:
      * ``V, F``        頂点 (N,3) と三角形 (M,3)。
      * ``pose``        4x4 object->camera(``render3d.look_at``)。None で ``auto_view``。
      * ``intrinsics``  3x3 ピンホール ``K``(**目標 ``size`` 用**、内部で ``ss`` 倍にスケール)。
      * ``size``        出力の一辺(正方)。``ss``  スーパーサンプリング倍率(整数 >= 1)。
      * ``light``       **ワールド座標**の光源方向(シーン→光源)。陰影と接地影で共有。
      * ``albedo``      物体の反射色 RGB。``material``  ``'plastic'`` | ``'metal'`` | ``'matcap'``。
      * ``albedo_variation`` アルベドに加える決定的な空間むらの比率(0 以上 1 未満)。
      * ``matcap``      ``material='matcap'`` のとき必須の lit-sphere テクスチャ ``(h,w[,C])``。
      * ``ambient``     環境光係数。``ao``  アンビエントオクルージョンを掛けるか。
      * ``ground_shadow`` 地面平面 + 接地影を焼き込むか。
      * ``tonemap``     ``'reinhard'`` | ``'aces'`` | ``'none'``。``background``  背景色 RGB。
      * ``exposure``    トーンマップ前の露出。``shininess``  光沢(None でマテリアル既定)。
      * ``ao_samples`` / ``shadow_res`` / ``penumbra`` / ``shadow_samples``
                        品質・速度のチューニング(接地影のソフトさ等)。
                        **``penumbra`` は光源の角半径 [度]** で、半影の幅はおよそ
                        「遮蔽物の高さ × tan(penumbra)」。既定の 2.5 度は、地面から
                        1 単位の高さの物体で半影が **1〜2 画素**にしかならない
                        (2026-09-02 実測: 320px の絵で半影は 283/102400 画素、
                        値の種類は ``shadow_samples+1`` 段、既定では 13 段だけ)。柔らかい影が
                        欲しいなら 10 度前後まで上げ、段が見えないよう
                        ``shadow_samples`` も一緒に増やす。
      * ``shadow_pcf``  shadow map を引くときに混ぜる近傍半径 [texel](既定 1 = 3x3)。
                        1 点参照だと影の境目が texel に量子化されて階段になる。
                        実測(地面の上だけで測った隣接画素の最大変化):
                        既定 2.5 度・12 本・pcf=0 相当で **0.667**、
                        12 度・24 本・pcf=1 で **0.176**(1/6 を超える段は 123→2)。

      * ``brdf``        物体の反射則。``'phong'``(既定 = 従来どおり Lambert 拡散 + cos^n 鏡面)/
                        ``'lambert'`` / ``'lommel_seeliger'`` / ``'hapke'``(惑星測光、
                        ``render_shade.brdf_shade``)。phong 以外では鏡面を切り、``albedo`` は
                        平均 1 に正規化した**色味**として掛ける(明るさは ``brdf_params`` の
                        単一散乱アルベド ``w`` が決める。二重に掛けない)。
      * ``brdf_params`` ``dict``(``w, g, B0, h, roughness_deg, multiple_scattering``)。
      * ``shadow_method`` ``'map'``(既定 = shadow map + PCF)/ ``'raycast'``
                        (``render_shadow.shadow_raycast``、階段・acne 無し)。
      * ``sun_angular_diameter_deg`` raycast 時の光源視直径(太陽 0.53°)。半影の幅は
                        「遮蔽物までの距離 × tan(視直径/2)」= 小惑星では数 cm(硬い影)。
      * ``self_illumination`` 地形からの一回反射の近似係数(既定 0)。
                        ``bounce = 係数 × albedo色 × (1 − AO) × 照らされた面の平均放射輝度``
                        ―― 遮蔽された半球の分だけ隣の地形が見えており、その地形が平均的な
                        明るさで光っているという近似(相互反射の厳密解ではない、要 ``ao=True``)。
                        宇宙では環境光が無いので ``ambient=0`` とこれで影の底が決まる。
      * ``surface`` / ``surface_params`` 表面反射モデル名とその追加パラメータ。
      * ``bump``        ``dict(wavelengths, amplitudes[, seed, nyquist, fade, complement_edges])``
                        → 物体画素の陰影法線を :func:`render3d.bump_normals_fbm`(値ノイズ高さ場の
                        勾配)で摂動する。幾何(depth/影/AO)は不変。``complement_edges=True``
                        なら画素直下のメッシュ局所辺長を重心補間して渡し、変位の帯域ゲートの
                        **補集合**だけを bump にする(同じ波長を二重に足さない)。

    fail-closed: 形状不正・非有限・空・``ss<1``・不正 ``material``/``tonemap``・不正な色/光/露出は
    ``ValueError``。決定的(乱数なし)。"""
    # --- 検証 ---------------------------------------------------------------
    Vv, Ff = _validate_mesh(V, F)
    if isinstance(ss, bool) or not isinstance(ss, (int, np.integer)) or int(ss) < 1:
        raise ValueError(f"ss must be an integer >= 1, got {ss!r}")
    ss = int(ss)
    sz = int(size)
    if sz <= 0:
        raise ValueError(f"size must be positive, got {size!r}")
    if float(sz * ss) * float(sz * ss) > render3d.MAX_PIXELS:
        raise ValueError(f"supersampled render {sz*ss}x{sz*ss} exceeds "
                         f"render3d.MAX_PIXELS ({render3d.MAX_PIXELS}) — lower size or ss")
    if material not in _MATERIALS and material != "matcap":
        raise ValueError(f"material must be one of plastic|metal|matcap, got {material!r}")
    if tonemap not in _TONEMAPS:
        raise ValueError(f"tonemap must be one of {_TONEMAPS}, got {tonemap!r}")
    albedo = _as_color(albedo, "albedo")
    background = _as_color(background, "background")
    light_world = _as_light(light)
    ka = float(ambient)
    if not np.isfinite(ka) or ka < 0.0:
        raise ValueError(f"ambient must be finite and >= 0, got {ambient!r}")
    exp = float(exposure)
    if not np.isfinite(exp) or exp <= 0.0:
        raise ValueError(f"exposure must be a positive finite scalar, got {exposure!r}")
    if material == "matcap" and matcap is None:
        raise ValueError("material='matcap' requires a matcap texture (got None)")
    if brdf not in _BRDFS:
        raise ValueError(f"brdf must be one of {_BRDFS}, got {brdf!r}")
    if surface not in _SURFACES:
        raise ValueError(f"surface must be one of {_SURFACES}, got {surface!r}")
    sp = dict(surface_params or {})
    if brdf != "phong" and material == "matcap":
        raise ValueError("brdf other than 'phong' cannot be combined with material='matcap'")
    bp = dict(brdf_params or {})
    if shadow_method not in ("map", "raycast"):
        raise ValueError(f"shadow_method must be 'map' or 'raycast', got {shadow_method!r}")
    sun_diam = float(sun_angular_diameter_deg)
    if not np.isfinite(sun_diam) or sun_diam < 0.0:
        raise ValueError(f"sun_angular_diameter_deg must be finite and >= 0, got {sun_angular_diameter_deg!r}")
    k_bounce = float(self_illumination)
    if not np.isfinite(k_bounce) or k_bounce < 0.0:
        raise ValueError(f"self_illumination must be finite and >= 0, got {self_illumination!r}")
    alb_var = float(albedo_variation)
    if not np.isfinite(alb_var) or alb_var < 0.0 or alb_var >= 1.0:
        raise ValueError(f"albedo_variation must be in [0, 1), got {albedo_variation!r}")

    hs = sz * ss                                         # 高解像度の一辺

    # --- カメラ(目標 size 用 K を ss 倍して高解像度で描く)-------------------
    if pose is None or intrinsics is None:
        dpose, dK = render3d.auto_view(Vv, margin=1.25, width=sz, height=sz)
    P = dpose if pose is None else render3d._check_pose(pose)
    Kt = dK if intrinsics is None else render3d._check_intrinsics(intrinsics)
    Khi = Kt.astype(np.float64).copy()
    Khi[:2, :] *= ss                                     # 目標基準 K を高解像度へ

    # --- シーン合成(必要なら地面を足す)------------------------------------
    if ground_shadow:
        Vg, Fg, ground_z, eps_ground = _ground_quad(
            Vv, light_world, drop=0.01, span_scale=2.4)
        n_mesh = Vv.shape[0]
        V_all = np.vstack([Vv, Vg])
        F_all = np.vstack([Ff, Fg + n_mesh])
    else:
        V_all, F_all = Vv, Ff
        ground_z, eps_ground = None, None

    # --- 幾何バッファ(depth / silhouette / 面法線)-------------------------
    bump_cfg = None
    if bump is not None:
        if not isinstance(bump, dict):
            raise ValueError("bump must be a dict(wavelengths, amplitudes, ...) or None")
        bump_cfg = dict(bump)
    if vertex_albedo is not None:
        vertex_albedo = np.asarray(vertex_albedo, dtype=np.float64)
        n_mesh_a = int(np.asarray(V).shape[0])
        if vertex_albedo.shape != (n_mesh_a, 3):
            raise ValueError("vertex_albedo must be (n_mesh, 3) RGB for the mesh vertices, "
                             f"got {vertex_albedo.shape} for {n_mesh_a} vertices")
        if not np.all(np.isfinite(vertex_albedo)) or vertex_albedo.min() < 0.0 or vertex_albedo.max() > 1.0:
            raise ValueError("vertex_albedo must be finite RGB in [0, 1]")
    want_attr = bool(smooth_normals) or bump_cfg is not None or vertex_albedo is not None
    view = render3d.render_mesh(V_all, F_all, pose=P, intrinsics=Khi,
                                width=hs, height=hs, attributes=want_attr)
    normals = view["normals"]                            # (hs, hs, 3) camera space
    if smooth_normals:
        # 面積重み付き頂点法線を透視補正重心座標で補間(Phong 補間)。フラット法線の
        # ファセット模様(10 m 面の Gaskell モデルが 1 m/px で「モザイク」に見える)を消す。
        # 幾何(depth/silhouette/影/AO)はそのまま —— 陰影だけを滑らかにする。
        vn_world = render3d._vertex_normals(V_all, F_all)
        if vertex_normals is not None:
            # Caller-supplied per-vertex normals for the MESH (rows [:n_mesh]; the
            # ground keeps its own). Use case: a marching-cubes mesh whose face-derived
            # vertex normals inherit the voxel grid as stair-step banding — the SDF
            # gradient sampled at the vertices is the true smooth normal.
            vn_user = np.asarray(vertex_normals, dtype=np.float64)
            n_mesh_v = int(np.asarray(V).shape[0])
            if vn_user.shape != (n_mesh_v, 3):
                raise ValueError("vertex_normals must be (n_mesh, 3) for the mesh vertices, "
                                 f"got {vn_user.shape} for {n_mesh_v} vertices")
            if not np.all(np.isfinite(vn_user)):
                raise ValueError("vertex_normals contains non-finite values")
            vn_user = vn_user / np.maximum(np.linalg.norm(vn_user, axis=1, keepdims=True), 1e-15)
            vn_world = vn_world.copy()
            vn_world[:n_mesh_v] = vn_user
        vn_cam = vn_world @ P[:3, :3].T
        cov = view["silhouette"] > 0
        ys_s, xs_s = np.nonzero(cov)
        fid = view["face"][ys_s, xs_s]
        bw = view["bary"][ys_s, xs_s]                    # (n,3) 和 = 1
        n_px = np.einsum("ij,ijk->ik", bw, vn_cam[F_all[fid]])
        n_px /= np.maximum(np.linalg.norm(n_px, axis=1, keepdims=True), 1e-15)
        normals = np.zeros_like(normals)
        normals[ys_s, xs_s] = n_px
    sil = view["silhouette"]                             # (hs, hs)
    depth = view["depth"]
    fg = sil > 0                                         # 前景(メッシュ or 地面)

    # 地面画素の判定(ワールド z が地面高さに一致)。
    Pw = None
    if ground_shadow or bump_cfg is not None or alb_var > 0.0:
        Pw = render_shadow.unproject_to_world(depth, P, Khi)     # (hs,hs,3), 背景 NaN
    if ground_shadow:
        with np.errstate(invalid="ignore"):
            is_ground = fg & np.isfinite(Pw[..., 2]) & \
                (np.abs(Pw[..., 2] - ground_z) < eps_ground)
    else:
        is_ground = np.zeros_like(fg)
    is_object = fg & ~is_ground

    if bump_cfg is not None and is_object.any():
        # サブファセットの起伏: 変位できなかった短波長オクターブを陰影法線に載せる。
        comp = bool(bump_cfg.pop("complement_edges", False))
        edge_map = None
        if comp:
            e_v = render3d.mesh_edge_lengths(V_all, F_all, per="vertex")
            ys_b, xs_b = np.nonzero(is_object)
            fid_b = view["face"][ys_b, xs_b]
            e_px = np.einsum("ij,ij->i", view["bary"][ys_b, xs_b], e_v[F_all[fid_b]])
            edge_map = np.full((hs, hs), np.nan)
            edge_map[ys_b, xs_b] = np.maximum(e_px, 1e-15)
        P_obj = np.where(is_object[..., None], Pw, np.nan)
        normals = render3d.bump_normals_fbm(normals, P_obj, rotation=P[:3, :3],
                                            local_edge=edge_map, **bump_cfg)

    # --- 光源をカメラ空間へ(法線はカメラ空間)------------------------------
    R = P[:3, :3]
    light_cam = R @ light_world
    view_cam = np.array([0.0, 0.0, 1.0], np.float64)     # カメラは -Z を見る → 視線は +Z

    # --- マテリアル -------------------------------------------------------
    if material == "matcap":
        mat = _MATERIALS["plastic"]                      # 光沢の既定値のみ流用(未使用)
    else:
        mat = _MATERIALS[material]
    sh = float(mat["shininess"]) if shininess is None else float(shininess)
    if not np.isfinite(sh) or sh <= 0.0:
        raise ValueError(f"shininess must be a finite positive number, got {shininess!r}")

    # --- AO / 影のマップ ---------------------------------------------------
    if ao:
        ao_map = render_ao.ambient_occlusion(V_all, F_all, pose=P, intrinsics=Khi,
                                             width=hs, height=hs, n_dirs=int(ao_samples),
                                             background=1.0)
    else:
        ao_map = np.ones((hs, hs), np.float64)
    if shadow_method == "raycast":
        # 地面の有無に関わらず自己影(self-shadow)を含む厳密な可視性。
        shadow_map = render_shadow.shadow_raycast(
            V_all, F_all, light_world, pose=P, intrinsics=Khi, width=hs, height=hs,
            angular_diameter_deg=sun_diam, samples=int(shadow_samples))
    elif ground_shadow:
        shadow_map = render_shadow.cast_shadow(
            V_all, F_all, light_world, pose=P, intrinsics=Khi, width=hs, height=hs,
            directional=True, penumbra=float(penumbra), samples=int(shadow_samples),
            shadow_res=int(shadow_res), pcf=int(shadow_pcf))
    else:
        shadow_map = np.ones((hs, hs), np.float64)

    # --- HDR 合成 ----------------------------------------------------------
    hdr = np.zeros((hs, hs, 3), np.float64)
    if material == "matcap":
        col = render_shade.matcap_shade(normals, matcap)         # (hs,hs) or (hs,hs,C)
        col = np.asarray(col, np.float64)
        if col.ndim == 2:
            col = np.repeat(col[..., None], 3, axis=2)
        elif col.shape[2] == 1:
            col = np.repeat(col, 3, axis=2)
        elif col.shape[2] >= 3:
            col = col[..., :3]
        # matcap は「素材の見え」を丸ごと持つ → AO で環境遮蔽、影は環境光の床を残して減光。
        shade_scale = ao_map * (ka + (1.0 - ka) * shadow_map)
        hdr = col * shade_scale[..., None]
        # 地面は matcap を貼らずマット拡散で(pedestal の質感)。
        if ground_shadow and is_ground.any():
            diff, _ = _lobes(normals, view_cam, light_cam, _GROUND_SHININESS)
            gcol = _GROUND_ALBEDO[None, None, :] * (
                ka * ao_map[..., None]
                + diff[..., None] * shadow_map[..., None] * ao_map[..., None])
            hdr = np.where(is_ground[..., None], gcol, hdr)
    else:
        diff, spec = _lobes(normals, view_cam, light_cam, sh)
        kd = float(mat["diffuse"])
        ks = float(mat["specular"])
        is_metal = bool(mat["metal"])

        # 物体の反射色・鏡面色(金属は鏡面が素材色、誘電体は白)。
        obj_albedo = albedo[None, None, :]
        obj_spec_tint = obj_albedo if is_metal else np.ones((1, 1, 3), np.float64)

        # per-画素で物体/地面のマテリアルを切替。
        alb_map = np.broadcast_to(obj_albedo, (hs, hs, 3)).copy()
        kd_map = np.full((hs, hs), kd, np.float64)
        ks_map = np.full((hs, hs), ks, np.float64)
        spec_tint = np.broadcast_to(obj_spec_tint, (hs, hs, 3)).copy()
        if ground_shadow and is_ground.any():
            alb_map[is_ground] = _GROUND_ALBEDO
            kd_map[is_ground] = 0.9
            ks_map[is_ground] = _GROUND_SPECULAR
            spec_tint[is_ground] = 1.0

        if brdf != "phong":
            # 惑星測光の反射則: 物体画素は I/F(放射輝度係数)そのもの。albedo は平均 1 の
            # 色味に正規化(明るさは w が決める)。鏡面は無し。地面は従来の Phong のまま。
            radf = render_shade.brdf_shade(normals, light=light_cam, view=view_cam,
                                           model=brdf, **bp)
            tint = albedo / max(float(albedo.mean()), 1e-12)
            alb_map[is_object] = tint
            kd_map[is_object] = 1.0
            ks_map[is_object] = 0.0
            diff = np.where(is_object, radf, diff)
        if alb_var > 0.0 and is_object.any():
            # アルベドの空間むら(1 ± albedo_variation の fBm、ワールド座標で決定的)。
            # イトカワは明るい/暗い地形が 1〜2 割の反射率差を持つ(Saito et al. 2006)。
            pts = Pw[is_object]
            diag = float(np.linalg.norm(Vv.max(axis=0) - Vv.min(axis=0)))
            sc = diag / 6.0 if albedo_scale is None else float(albedo_scale)
            fb = render3d.fbm_noise(pts, sc, octaves=3, seed=int(seed))
            alb_map[is_object] *= (1.0 + alb_var * fb)[:, None]

        if vertex_albedo is not None and is_object.any():
            # Per-vertex RGB albedo (vertex painting): interpolated to the mesh pixels
            # with the same perspective-correct barycentrics as the smooth normals.
            # Ground pixels keep the ground material. For a metal the specular tint
            # follows the local colour (a gold part highlights gold, a steel part white).
            # Use cases: several CSG parts in one scene with their own materials,
            # label / heatmap colouring of a mesh.
            va_all = np.ones((V_all.shape[0], 3), np.float64)
            va_all[:vertex_albedo.shape[0]] = vertex_albedo
            ys_a, xs_a = np.nonzero(is_object)
            fid_a = view["face"][ys_a, xs_a]
            bw_a = view["bary"][ys_a, xs_a]
            col = np.einsum("ij,ijk->ik", bw_a, va_all[F_all[fid_a]])
            alb_map[ys_a, xs_a] = np.clip(col, 0.0, 1.0)
            if is_metal:
                spec_tint[ys_a, xs_a] = alb_map[ys_a, xs_a]

        if surface != "none" and is_object.any():
            # 微細構造の見え方(matappear): 面の微細構造が**波長ごとに違う反射**を返す
            # 3 つ ―― 回折格子(CD)・薄膜干渉(シャボン/陽極酸化)・異方性微小面
            # (ヘアライン)。どれも光線追跡を要さないので、ラスタライザのままで出せる。
            # 物体画素の鏡面項をこの項で**置き換える**(拡散と環境光はそのまま残す)。
            if surface == "brushed":
                lobe = matappear.ward_anisotropic(
                    normals * is_object[..., None], light=light_cam, view=view_cam,
                    tangent=sp.get("tangent", (1.0, 0.0, 0.0)),
                    alpha_x=sp.get("alpha_x", 0.30), alpha_y=sp.get("alpha_y", 0.03))
                extra = (sp.get("strength", 0.6) * lobe)[..., None] * spec_tint
            elif surface == "grating":
                extra = matappear.grating_rgb(
                    normals * is_object[..., None], light=light_cam, view=view_cam,
                    tangent=sp.get("tangent", (1.0, 0.0, 0.0)),
                    pitch_um=sp.get("pitch_um", 1.6), orders=sp.get("orders", (1, 2)),
                    strength=sp.get("strength", 1.0), width_nm=sp.get("width_nm", 60.0))
            else:                                        # "thinfilm"
                extra = matappear.thin_film_rgb(
                    normals * is_object[..., None], view=view_cam,
                    thickness_nm=sp.get("thickness_nm", 350.0),
                    n_film=sp.get("n_film", 1.33), n_sub=sp.get("n_sub", 1.0),
                    strength=sp.get("strength", 1.0))
            # 色域外(負)はここで初めて落とす。分光側で丸めない方針(matappear 参照)。
            extra = np.clip(np.nan_to_num(extra), 0.0, None)
            ks_map = np.where(is_object, 0.0, ks_map)
            surface_rgb = np.where(is_object[..., None], extra, 0.0)
        else:
            surface_rgb = None

        # 環境光(AO で遮蔽・影には残す)+ 拡散(AO と影)+ 鏡面(影)。
        ambient_rgb = ka * alb_map * ao_map[..., None]
        diffuse_rgb = (kd_map * diff)[..., None] * alb_map \
            * ao_map[..., None] * shadow_map[..., None]
        specular_rgb = (ks_map * spec)[..., None] * spec_tint * shadow_map[..., None]
        hdr = ambient_rgb + diffuse_rgb + specular_rgb
        if surface_rgb is not None:
            hdr = hdr + surface_rgb * shadow_map[..., None] * ao_map[..., None]
        if k_bounce > 0.0 and ao:
            # 地形の一回反射の近似(docstring 参照): 遮蔽された半球の割合 (1−AO) だけ
            # 隣の地形が見え、その地形は照らされた面の平均放射輝度で光っているとする。
            lit_obj = is_object & (shadow_map > 0.5) & (diff > 0.0)
            mean_lit = float((kd_map * diff)[lit_obj].mean()) if lit_obj.any() else 0.0
            bounce = k_bounce * mean_lit * alb_map * (1.0 - ao_map)[..., None]
            hdr = hdr + np.where(is_object[..., None], bounce, 0.0)

    hdr = np.where(fg[..., None], hdr, 0.0)              # 背景は 0(後で背景色を合成)
    hdr = np.clip(hdr, 0.0, None)                        # 数値上の微小負値を除去

    # --- トーンマップ(前景のみ)------------------------------------------
    if tonemap == "reinhard":
        ldr = render_tonemap.tonemap_reinhard(hdr, exposure=exp)
    elif tonemap == "aces":
        ldr = render_tonemap.tonemap_aces(hdr, exposure=exp)
    else:                                                # none: 素朴クリップ
        ldr = np.clip(hdr * exp, 0.0, 1.0)

    # --- 背景合成(表示空間)→ SSAA 縮小 ----------------------------------
    out_hi = np.where(fg[..., None], ldr, background[None, None, :])
    out = render_ssaa.antialias(out_hi, ss, filter="box")
    return np.clip(out, 0.0, 1.0).astype(np.float64)


# --------------------------------------------------------------------------- #
# 宇宙のレゴリス(小惑星)プリセット                                            #
# --------------------------------------------------------------------------- #
def render_regolith(V, F, *, pose=None, intrinsics=None, size: int = 512, ss: int = 2,
                    sun: Sequence[float] = (0.3, 0.4, 1.0), w: float = 0.42, g: float = -0.35,
                    B0: float = 0.87, h: float = 0.01, roughness_deg: float = 26.0,
                    sun_angular_diameter_deg: float = 0.53, shadow_samples: int = 4,
                    ao_samples: int = 32, tint: Sequence[float] = (1.0, 0.97, 0.93),
                    self_illumination: float = 1.0, exposure="auto",
                    albedo_variation: float = 0.12, seed: int = 0,
                    smooth_normals: bool = True,
                    background: Sequence[float] = (0.0, 0.0, 0.0), bump=None,
                    vertex_normals=None, vertex_albedo=None,
                    exposure_target: float = 0.45) -> np.ndarray:
    """小惑星のレゴリスを物理ベース(Hapke + 太陽視直径のレイキャスト影 + 環境光ゼロ)で描く → RGB ``(size,size,3)``。

    :func:`render_beauty` の合成:
      * 反射則 = Hapke(``w, g, B0, h, roughness_deg``; 既定はイトカワの S 型典型値)。
      * 影 = ``render_shadow.shadow_raycast``(視直径 ``sun_angular_diameter_deg``、既定 0.53° =
        太陽。半影は幾何どおり数 cm なので事実上ハード影)。地面(台座)は置かない。
      * 環境光 0(宇宙に空光は無い)。影の底は地形の一回反射近似 ``self_illumination`` だけ。
      * トーン = 線形(AMICA の 8bit 画像に合わせ、露出 × クリップ)。``exposure='auto'`` は
        物体画素の 99.5 パーセンタイルが 0.95 に来る露出(決定的)。``exposure='median'`` は
        **照らされた面の中央値**(物体画素のうち 99.5 % 点の 30 % 以上の画素の中央値)が
        ``exposure_target``(既定 0.45)に来る露出 —— 2026-09-03 の hero が「露出過多で
        白いジャガイモ」になった対策(99.5 % 点合わせは縁まで明るい Lommel-Seeliger 面で
        中央値が 0.7 超まで上がる)。クリップ率は呼び手が測る(hero は < 0.5 % を要求)。
      * ``smooth_normals=True``: 頂点法線の Phong 補間で陰影を滑らかにする(幾何・影は不変)。
      * ``albedo_variation``: アルベドの空間むら(既定 12 %、Saito et al. 2006 の明暗地形)。
      * ``bump``: :func:`render_beauty` の ``bump``(サブファセット起伏の陰影法線摂動)。
    ``tint`` は平均 1 に正規化した色味。fail-closed: 引数は下位 op が検証、``exposure`` は
    ``'auto'`` / ``'median'`` か正の数。決定的(乱数なし)。"""
    mode = None
    if isinstance(exposure, str):
        if exposure not in ("auto", "median"):
            raise ValueError(f"exposure must be 'auto', 'median' or a positive number, got {exposure!r}")
        mode = exposure
        exp = None
    else:
        exp = float(exposure)
        if not np.isfinite(exp) or exp <= 0.0:
            raise ValueError(f"exposure must be 'auto' or a positive finite number, got {exposure!r}")
    tgt = float(exposure_target)
    if not np.isfinite(tgt) or tgt <= 0.0 or tgt >= 1.0:
        raise ValueError(f"exposure_target must be in (0, 1), got {exposure_target!r}")
    params = dict(w=float(w), g=float(g), B0=float(B0), h=float(h),
                  roughness_deg=float(roughness_deg))
    img = render_beauty(V, F, pose=pose, intrinsics=intrinsics, size=size, ss=ss, light=sun,
                        albedo=tint, material="plastic", ambient=0.0, ao=True,
                        ground_shadow=False, tonemap="linear", background=(0.0, 0.0, 0.0),
                        exposure=1.0, ao_samples=ao_samples, shadow_samples=shadow_samples,
                        brdf="hapke", brdf_params=params, shadow_method="raycast",
                        sun_angular_diameter_deg=sun_angular_diameter_deg,
                        self_illumination=self_illumination,
                        albedo_variation=albedo_variation, seed=seed,
                        smooth_normals=smooth_normals, bump=bump,
                        vertex_normals=vertex_normals, vertex_albedo=vertex_albedo)
    if exp is None:
        obj = img.max(axis=2)
        vals = obj[obj > 0.0]
        p = float(np.percentile(vals, 99.5)) if vals.size else 1.0
        if mode == "auto":
            exp = 0.95 / max(p, 1e-9)
        else:
            lit = vals[vals > 0.3 * p]
            med = float(np.median(lit)) if lit.size else p
            exp = tgt / max(med, 1e-9)
    bg = _as_color(background, "background")
    fgm = img.max(axis=2) > 0.0
    out = np.where(fgm[..., None], np.clip(img * exp, 0.0, 1.0), bg[None, None, :])
    return np.clip(out, 0.0, 1.0).astype(np.float64)
