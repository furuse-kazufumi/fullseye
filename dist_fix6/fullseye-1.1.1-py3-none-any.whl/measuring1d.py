"""1D 測定(エッジ抽出)(HALCON "1D Measuring" chapter genuine, numpy).

測定線/測定弧に沿ってグレープロファイルを取り、微分でエッジ・エッジ対を抽出。
キャリパー計測の中核。image = 2D float(グレー値の単位は入力のまま: [0,1] でも
0..255 でもよく、``amplitude``/``threshold`` はその単位)。measure = プロファイル取得の
設定 dict(``gen_measure_rectangle2`` / ``gen_measure_arc`` が作る)。

規約(2026-09-02 改訂):
  * プロファイルのサンプル間隔は **1 px**(矩形は厳密に 1、弧は弧長を整数分割した
    ≈1 px、``measure["spacing"]``)。``pos`` はサンプル index(= 測定開始点からの
    距離 / spacing)、``dist`` = 開始点からの距離 [px]、``row``/``col`` = 画像座標。
  * ``amplitude`` は **エッジ両側のグレー差**(符号つき: 測定方向に明るくなる
    立ち上がりが正)。HALCON の Amplitude と同じ意味で、平滑化 ``sigma`` に依存
    しない(以前は平滑化勾配のピーク値=グレー差の ~0.3 倍・sigma 依存だった)。
    ``threshold`` はこの |グレー差| に対する下限。
  * 測定矩形の端にかかるエッジも落とさない(内部で測定線を両端に延長して
    サンプルし、矩形内 [-0.5, n-0.5] のエッジだけ返す)。
"""
from __future__ import annotations

import numpy as np
from scipy.ndimage import map_coordinates, gaussian_filter1d


def gen_measure_rectangle2(row, col, phi, length1, length2, shape):
    """回転測定矩形(長軸 ``phi`` 方向に 1 px 間隔でプロファイルを取る)を定義
    (gen_measure_rectangle2)。サンプル数 n = max(2, round(2*length1)+1)、始点は
    中心から -(n-1)/2 px の位置。``length2`` は幅方向の平均化幅 [px]。

    ★長さの意味(2026-11-09 に実装へ合わせて明記。値は変えていない):
      * ``length1`` は**半長**(プロファイルは中心 ± length1)。HALCON の Length1 と同じ。
      * ``length2`` は**全幅**: ``measure_pos`` は法線方向の ``np.linspace(-w/2, w/2, max(2, w))``
        (``w = int(length2)``)の w 本を平均し、``w ≤ 1`` なら平均しない。HALCON の Length2 は
        **半高**(Half height of the rectangle、HALCON の reference)で、同じライブラリの
        ``gen_rectangle2_contour_xld`` も length2 を半幅(角が ±length2)として描く —— 同じ
        数字を渡すと、ここでは半分の幅しか平均しない。★HALCON の整数 offset −L2..+L2(2·L2+1 本)を
        そのまま作る length2 は無い: ``length2 = 2·L2 + 1`` を渡すと本数は 2·L2+1 だが、offset は
        ±(L2 + 0.5) の範囲に間隔 (2·L2+1)/(2·L2) で並ぶ(L2=2 → w=5 で −2.5, −1.25, 0, 1.25, 2.5)——
        整数でなく幅も 1 画素広い。辺が測定線に直交していれば平均の結果は近いが、幅方向に構造が
        あると別の矩形を測る。
      * w が偶数のとき標本は中心の行を通らない(w=2 は offset ±1 の 2 本だけ、w=4 は
        ±2, ±0.67)。中心を含めたいなら奇数の w。
    ★角の向き: プロファイルは ``(row + t·sin φ, col + t·cos φ)`` に進む。行が下向きの
    画像座標で φ を時計回りに数える(φ = +π/2 は画面の下向き)。HALCON の Phi は水平からの
    「数学的に正」の角(gen_rectangle2 の reference)で、行が下向きの画像では反時計回り
    (φ = π/2 は上向き)と読める —— 符号が逆。HALCON の Phi を移すなら ``phi = −Phi``
    (極性 positive/negative と並び順が HALCON と揃う)。★HALCON の実機での照合はしていない
    (reference の文言からの読み)。ライブラリ内では ``gen_rectangle2_contour_xld`` も同じ +sin
    で一貫している。
    """
    n = max(2, int(round(2.0 * float(length1))) + 1)
    t = np.arange(n, dtype=float) - (n - 1) / 2.0
    ca, sa = np.cos(phi), np.sin(phi)
    rows = row + t * sa
    cols = col + t * ca
    return {"type": "rect", "rows": rows, "cols": cols, "width": length2,
            "phi": phi, "shape": shape, "spacing": 1.0,
            "origin": (float(row), float(col)), "dir": (float(sa), float(ca)), "t": t}


def gen_measure_arc(center_row, center_col, radius, angle_start, angle_extent, width, shape):
    """測定弧(円周方向に ≈1 px 間隔でプロファイルを取る)を定義(gen_measure_arc)。
    サンプル数 n = round(|angle_extent|*radius)+1、``spacing`` = 弧長/(n-1)。

    弧上のサンプル点は ``row = center_row + radius sin(θ)``、
    ``col = center_col + radius cos(θ)``、``θ = angle_start + linspace(0, angle_extent, n)``。
    角度は **ラジアン**で、col 軸(x)から row 軸(画像下向き)へ回る向きが正。
    ``angle_extent`` が負なら逆回りに進み、``measure_pos`` の ``pos`` / ``dist`` は
    その進行方向に沿って数える。

    - ``radius``: [px]。``n = max(2, round(|angle_extent| * radius) + 1)`` なので、
      半径や角度幅が小さすぎるとサンプル 2 点・``spacing`` が弧長そのものになる。
      ``radius = 0`` は ``spacing = 0`` になり後段の微分で破綻する(ここでは検証しない)。
    - ``width``: 幅方向(法線)の平均化幅 [px]。``int`` に切られ、1 以下なら平均なし。
    - ``shape``: 画像の ``(H, W)``。dict に保存されるだけで、範囲外は
      ``measure_pos`` 側が最近傍で外挿する(例外は出ない)。
    - 返り値: ``{"type": "arc", "rows", "cols", "width", "shape", "spacing", "center",
      "radius", "angles"}`` の dict(``measurehandle`` 型)。

    ``measure_pos`` / ``measure_pairs`` / ``fuzzy_measure_pairing`` に渡す。直線なら
    ``gen_measure_rectangle2``。位置決め後は ``translate_measure`` で動かす。
    """
    arclen = abs(float(angle_extent)) * float(radius)
    n = max(2, int(round(arclen)) + 1)
    ang = angle_start + np.linspace(0.0, angle_extent, n)
    rows = center_row + radius * np.sin(ang)
    cols = center_col + radius * np.cos(ang)
    return {"type": "arc", "rows": rows, "cols": cols, "width": width, "shape": shape,
            "spacing": arclen / (n - 1), "center": (float(center_row), float(center_col)),
            "radius": float(radius), "angles": ang}


def _extended_coords(measure, k):
    """測定線を両端に k サンプル延長した (rows, cols)。矩形/弧は幾何定義から、
    それ以外は端点の接線で線形外挿。"""
    rows = np.asarray(measure["rows"], float); cols = np.asarray(measure["cols"], float)
    if k <= 0:
        return rows, cols
    if measure.get("type") == "rect" and "origin" in measure:
        t = np.asarray(measure["t"], float)
        te = np.concatenate([t[0] - np.arange(k, 0, -1), t, t[-1] + np.arange(1, k + 1)])
        r0, c0 = measure["origin"]; sa, ca = measure["dir"]
        return r0 + te * sa, c0 + te * ca
    if measure.get("type") == "arc" and "center" in measure:
        ang = np.asarray(measure["angles"], float)
        d = ang[1] - ang[0]
        ae = np.concatenate([ang[0] - d * np.arange(k, 0, -1), ang, ang[-1] + d * np.arange(1, k + 1)])
        r0, c0 = measure["center"]; rad = measure["radius"]
        return r0 + rad * np.sin(ae), c0 + rad * np.cos(ae)
    d0 = np.array([rows[1] - rows[0], cols[1] - cols[0]])
    d1 = np.array([rows[-1] - rows[-2], cols[-1] - cols[-2]])
    pre = np.array([[rows[0], cols[0]] - d0 * j for j in range(k, 0, -1)])
    post = np.array([[rows[-1], cols[-1]] + d1 * j for j in range(1, k + 1)])
    ext = np.vstack([pre, np.column_stack([rows, cols]), post])
    return ext[:, 0], ext[:, 1]


def _profile(image, measure, pad=0):
    """測定線(両端を ``pad`` サンプル延長)に沿った幅方向平均つきグレープロファイル。"""
    im = np.asarray(image, float)
    if im.ndim != 2:
        raise ValueError(f"image must be 2-D, got shape {im.shape}")
    rows, cols = _extended_coords(measure, int(pad))
    w = int(measure.get("width", 1))
    if w <= 1:
        return map_coordinates(im, [rows, cols], order=1, mode="nearest")
    # 幅方向(測定線の法線)に w サンプル平均
    dr = np.gradient(rows); dc = np.gradient(cols)
    norm = np.hypot(dr, dc) + 1e-12
    nr = -dc / norm; nc = dr / norm
    acc = np.zeros(len(rows))
    offs = np.linspace(-w / 2, w / 2, max(2, w))
    for o in offs:
        acc += map_coordinates(im, [rows + nr * o, cols + nc * o], order=1, mode="nearest")
    return acc / len(offs)


def _lobe_amplitude(sm, ag, i):
    """勾配ローブ(ピーク i から両側へ 1 % まで単調減少する範囲)の両端のグレー差。"""
    lo = i
    while lo > 0 and ag[lo - 1] < ag[lo] and ag[lo - 1] > 0.01 * ag[i]:
        lo -= 1
    hi = i
    while hi < len(ag) - 1 and ag[hi + 1] < ag[hi] and ag[hi + 1] > 0.01 * ag[i]:
        hi += 1
    return float(sm[hi] - sm[lo])


def _check_measure_input(image, measure, sigma, op):
    """measure_pos 族の入力の門: 非有限の画素・負の sigma は拒否、画像の外の測定線は警告/拒否。"""
    im = np.asarray(image)
    if im.dtype.kind in "fc" and not np.isfinite(im).all():
        raise ValueError("%s: image has %d non-finite value(s) (nan/inf) — an edge next to one "
                         "vanishes without a sign; fill or mask them first"
                         % (op, int(np.count_nonzero(~np.isfinite(im)))))
    s = float(sigma)
    if not np.isfinite(s) or s < 0:
        raise ValueError("%s: sigma must be a finite number >= 0 (0 = no smoothing), got %r" % (op, sigma))
    if im.ndim == 2:
        H, W = im.shape
        r = np.asarray(measure["rows"], float)
        c = np.asarray(measure["cols"], float)
        out = (r < -0.5) | (r > H - 0.5) | (c < -0.5) | (c > W - 0.5)
        if out.all():
            raise ValueError("%s: the whole measure line lies outside the %dx%d image — nothing to "
                             "measure (the profile would be extrapolated)" % (op, H, W))
        if out.any():
            import warnings  # noqa: PLC0415
            warnings.warn("%s: %d of %d measure point(s) lie outside the %dx%d image; the profile "
                          "there is extrapolated from the nearest pixel" % (op, int(out.sum()), out.size, H, W),
                          RuntimeWarning, stacklevel=3)


def measure_pos(image, measure, sigma=1.0, threshold=0.1, transition="all"):
    """測定線上のエッジ位置(サブピクセル)と振幅を抽出(measure_pos)。

    各エッジ: ``pos``(サンプル index、矩形は始点からの px)/ ``dist``(始点からの
    距離 [px])/ ``row``, ``col`` / ``amplitude``(符号つきグレー差)/ ``polarity``
    ("positive" = 測定方向に明るくなる)。``threshold`` は |amplitude| の下限、
    ``transition`` は "all" / "positive" / "negative"。

    空の入力(``image`` が 0 要素)は ValueError。
    ★入力の門(2026-11-09): 非有限の画素(NaN/inf)を含む画像は ValueError(エッジの 1 画素先の
    NaN でエッジが黙って消え、遠くなら黙って通っていた)。``sigma < 0`` も ValueError
    (``sigma = 0`` は平滑化なし、負の値は黙って 0 と同じになっていた)。測定線の点
    (``rows``/``cols``)が画像の外 ``[-0.5, H-0.5] × [-0.5, W-0.5]`` に出ると RuntimeWarning
    (外は最近傍の外挿で、見えていない所を測っている)、全部が外なら ValueError(戻り値が
    list なので印は返せない)。正しい入力の結果は変わらない。
    """
    if (len(image) if isinstance(image, (list, tuple)) else np.asarray(image).size) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("measure_pos: image is empty — pass at least one element")
    _check_measure_input(image, measure, sigma, "measure_pos")
    n = len(measure["rows"])
    spacing = float(measure.get("spacing", 1.0))
    k = int(np.ceil(3.0 * max(float(sigma), 0.0))) + 2
    prof = _profile(image, measure, pad=k)
    sm = gaussian_filter1d(prof, sigma, mode="nearest") if sigma > 0 else prof
    g = np.gradient(sm, spacing)
    ag = np.abs(g)
    rows_e, cols_e = _extended_coords(measure, k)
    idx_e = np.arange(len(rows_e), dtype=float)
    edges = []
    for i in range(1, len(ag) - 1):
        if not (ag[i] >= ag[i - 1] and ag[i] > ag[i + 1] and ag[i] > 1e-12):
            continue
        amp = _lobe_amplitude(sm, ag, i)
        if abs(amp) < threshold:
            continue
        pol = "positive" if g[i] > 0 else "negative"
        if transition != "all" and transition != pol:
            continue
        den = ag[i - 1] - 2.0 * ag[i] + ag[i + 1]
        delta = 0.5 * (ag[i - 1] - ag[i + 1]) / den if abs(den) > 1e-12 else 0.0
        delta = float(np.clip(delta, -1.0, 1.0))
        pe = i + delta                                  # 延長プロファイル上の index
        pos = pe - k
        if pos < -0.5 or pos > n - 0.5:                 # 測定範囲の外
            continue
        row = float(np.interp(pe, idx_e, rows_e)); col = float(np.interp(pe, idx_e, cols_e))
        edges.append({"pos": float(pos), "dist": float(pos * spacing), "row": row, "col": col,
                      "amplitude": amp, "polarity": pol})
    return edges


def measure_pairs(image, measure, sigma=1.0, threshold=0.1):
    """立ち上がり/立ち下がりエッジのペア(構造の幅)を抽出(measure_pairs)。
    ``first``/``second`` = 各エッジの ``pos``、``width`` = 幅 [px]、
    ``first_point``/``second_point`` = (row, col)。

    **失敗と信頼度は返さない**(対が無ければ空 list、危険域でも対を返す)。
    エッジ間距離 / PSF 幅が 3.09 を切ると幅は必ず大きい側へ偏り(2.06 で +2.43 px)、
    1.58 まで「対が見つかった」と答え続ける —— 実測と見張り方は
    ``docs/ops/measure1d/guides/subpixel_measuring.md`` の「落とし穴 2」。極性の
    順序も問わない(暗い構造の幅が返ることがある。同 §4)。単位は px なので、
    mm が要るときは ``table_px_to_mm`` / ``pixel_to_world`` に渡す。

    空の入力(``image`` が 0 要素)は ValueError。
    """
    if (len(image) if isinstance(image, (list, tuple)) else np.asarray(image).size) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("measure_pairs: image is empty — pass at least one element")
    edges = measure_pos(image, measure, sigma, threshold)
    spacing = float(measure.get("spacing", 1.0))
    pairs = []
    i = 0
    while i < len(edges) - 1:
        a = edges[i]; b = edges[i + 1]
        if a["polarity"] != b["polarity"]:
            pairs.append({"first": a["pos"], "second": b["pos"],
                          "width": (b["pos"] - a["pos"]) * spacing,
                          "first_point": (a["row"], a["col"]), "second_point": (b["row"], b["col"]),
                          "first_amplitude": a["amplitude"], "second_amplitude": b["amplitude"]})
            i += 2
        else:
            i += 1
    return pairs


def fuzzy_measure_pairing(image, measure, sigma=1.0, threshold=0.1, pair_size=None):
    """ファジィ基準(想定幅 pair_size)に最も合うエッジ対を選ぶ(fuzzy_measure_pairing)。

    手順: ``measure_pairs(image, measure, sigma, threshold)`` で極性の異なる隣接
    エッジの対を取り、各対に ``fuzzy_score = exp(-((width - pair_size) /
    (0.5 pair_size))^2)`` を付けて **スコア降順に並べ替える**。想定幅ちょうどで 1、
    幅が ``±0.5 pair_size`` ずれると ``e^-1`` ≈ 0.37。先頭要素が最も合う対。

    - ``image``: 2-D float(グレー値の単位は入力のまま)。
    - ``measure``: ``gen_measure_rectangle2`` / ``gen_measure_arc`` の dict。
    - ``sigma``: プロファイルの平滑化 σ [サンプル]。``threshold``: 採用するエッジの
      最小 |グレー差|(画像の単位)。
    - ``pair_size``: 想定幅 [px]。``None`` なら並べ替えもスコア付けもせず
      ``measure_pairs`` の結果(測定線に沿った順)をそのまま返す。0 や負は検証
      しない(0 だと分母が 1e-9 になり全対のスコアがほぼ 0 か 1 に潰れる)。
    - 返り値: 対の dict の list(``table`` 型)。各 dict は ``first`` / ``second``
      (サンプル index)、``width`` [px]、``first_point`` / ``second_point``
      (``(row, col)``)、``first_amplitude`` / ``second_amplitude``、``fuzzy_score``。
      対が 1 つも無ければ空 list(例外にはしない)。

    幅の下限・上限で切りたい場合はこの結果を ``width`` で自分でフィルタする
    (この op は順位付けだけで、閾での除外はしない)。

    空の入力(``image`` が 0 要素)は ValueError。
    """
    if (len(image) if isinstance(image, (list, tuple)) else np.asarray(image).size) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("fuzzy_measure_pairing: image is empty — pass at least one element")
    pairs = measure_pairs(image, measure, sigma, threshold)
    if pair_size is None or not pairs:
        return pairs
    for p in pairs:
        p["fuzzy_score"] = float(np.exp(-((p["width"] - pair_size) / (0.5 * pair_size + 1e-9)) ** 2))
    pairs.sort(key=lambda p: -p["fuzzy_score"])
    return pairs


def translate_measure(measure, drow, dcol):
    """測定オブジェクトを平行移動(translate_measure)。

    ``rows`` / ``cols`` に ``(drow, dcol)`` [px] を足した **浅い複製** を返す(入力の
    dict は変えない)。``gen_measure_rectangle2`` の ``origin`` と ``gen_measure_arc``
    の ``center`` も同じだけ動かすので、両端延長(``_extended_coords``)の幾何が
    ずれない。``phi`` / ``dir`` / ``angles`` / ``radius`` / ``width`` / ``spacing`` は
    そのまま ―― **回転や半径変更はしない**。

    - ``measure``: ``gen_measure_rectangle2`` / ``gen_measure_arc`` の dict。
      ``rows`` / ``cols`` を持つ任意の dict でも動く(他キーは素通し)。
    - ``drow``, ``dcol``: 変位 [px]。小数可。
    - ``shape``(画像サイズ)は再検査しないので、画像外へ出しても例外は出ず、
      ``measure_pos`` が端の値で外挿するだけになる。
    - 返り値: 同じ構造の dict(``measurehandle`` 型)。

    典型: 位置合わせで得たワークのずれを測定線に反映してから ``measure_pos`` /
    ``measure_pairs`` を掛ける。傾きが変わる場合は ``gen_measure_rectangle2`` を
    新しい ``phi`` で作り直す。

    空の入力(``measure`` が空の dict)は ValueError。
    """
    if isinstance(measure, dict) and len(measure) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("translate_measure: measure is empty — pass a non-empty dict")
    m = dict(measure)
    m["rows"] = np.asarray(measure["rows"], float) + drow
    m["cols"] = np.asarray(measure["cols"], float) + dcol
    if "origin" in m:
        m["origin"] = (m["origin"][0] + drow, m["origin"][1] + dcol)
    if "center" in m:
        m["center"] = (m["center"][0] + drow, m["center"][1] + dcol)
    return m


# --------------------------------------------------------------------------- #
# 画素 → 実寸(2026-09-15)                                                      #
# --------------------------------------------------------------------------- #
# なぜ要るか: 文書だけを渡した AI が内径を測る導線を辿ると、``measure_pairs`` /
# ``apply_metrology_model`` で **px のまま終わっていた**。``op_find`` で calib /
# pixel_size / mm を当たっても該当が無く、4 層(fs. / fs.ledger. / fs.op. / op_find)
# 全部で「画素を mm にする op」は 0 本だった(annotate_scale_bar は描くだけ、
# sensor_diagonal_mm はセンサの物理寸法)。換算は 1 行の掛け算だが、**校正の取り方
# (既知寸法の的から mm/px を出す)とセットで op にしておく**ことに意味がある ——
# 「mm/px は必ず実測で決める」(``poc_crack_width`` の注記)を型連鎖の中に置ける。

def _real_scalar(x, name, op):
    """有限 float に落とす。文字列・bool・配列は受けない(表の列を取り違えた印なので)。"""
    if isinstance(x, (str, bytes, bool)) or np.ndim(x) != 0:
        raise ValueError("%s: %s must be a real scalar, got %r" % (op, name, type(x).__name__))
    try:
        v = float(x)
    except (TypeError, ValueError):
        raise ValueError("%s: %s must be a real scalar, got %r" % (op, name, type(x).__name__)) from None
    if not np.isfinite(v):
        raise ValueError("%s: %s must be finite, got %r" % (op, name, x))
    return v


def _finite_positive(x, name, op):
    v = _real_scalar(x, name, op)
    if v <= 0.0:
        raise ValueError("%s: %s must be > 0, got %r" % (op, name, x))
    return v


def mm_per_px_from_reference(measured_px, known_mm):
    """既知寸法の的(スケールバー・基準穴・ゲージ)から画素ピッチ mm/px を出す(校正)。

    ``mm_per_px = known_mm / measured_px``。``measured_px`` は同じ光学系・同じ
    作動距離で **この族の op が実際に測った**値(``measure_pairs`` の ``width``、
    ``apply_metrology_model`` の ``radius`` の 2 倍など)を渡す。図面値や公称の
    倍率から置くと、作動距離が 10 % ずれれば全部の寸法が 10 % ずれる。

    - ``measured_px``, ``known_mm``: 有限で正のスカラ(それ以外は ``ValueError``)。
    - 返り値: mm/px(float、``measurement`` 型)。``pixel_to_world`` /
      ``table_px_to_mm`` に渡す。
    - 透視の効く斜め撮影では場所ごとに mm/px が変わる。この op は**平面視・一定
      倍率**の前提で 1 個の値を返すだけで、それを検証はしない。
    """
    op = "mm_per_px_from_reference"
    px = _finite_positive(measured_px, "measured_px", op)
    mm = _finite_positive(known_mm, "known_mm", op)
    return mm / px


def pixel_to_world(value_px, mm_per_px):
    """画素で測った長さ 1 個を実寸 mm にする(``value_px * mm_per_px``)。

    ``mm_per_px`` は ``mm_per_px_from_reference`` で**実測**したものを渡す。
    ``value_px`` は 0 や負でもよい(差分・偏りをそのまま換算できる)が、有限で
    あること。``mm_per_px`` は有限で正。どちらも違えば ``ValueError``。
    返り値は float(``measurement`` 型)。面積は mm/px を 2 乗して自分で掛ける
    (この op は長さだけ)。
    """
    op = "pixel_to_world"
    v = _real_scalar(value_px, "value_px", op)
    k = _finite_positive(mm_per_px, "mm_per_px", op)
    return v * k


#: ``table_px_to_mm`` が既定で換算する列。この族の結果表に現れる **長さ [px]** だけ
#: (位置 ``pos`` / ``row`` / ``col`` / 角度 ``phi`` は換算しない)。
PX_LENGTH_KEYS = ("width", "radius", "dist", "rms", "ra", "rb", "l1", "l2")


def table_px_to_mm(table, mm_per_px, keys=PX_LENGTH_KEYS):
    """計測結果の表(``measure_pairs`` / ``apply_metrology_model`` の返り)に mm 列を足す。

    ``keys`` にある数値の列 ``k`` ごとに ``k_mm = k * mm_per_px`` を **追加**する
    (px の列は残す。消すと来歴が切れる)。``apply_metrology_model`` の各行は
    ``params`` dict の中に ``radius`` / ``l1`` … を持つので、そこも見る。
    入力は list[dict] か dict 1 個。**浅い複製**を返し、入力は変えない。

    - 数値でない列・無い列は黙って飛ばす(換算できたかは ``k_mm`` の有無で分かる)。
    - ``mm_per_px`` は有限で正(``mm_per_px_from_reference`` の値)。
    - ``rms`` は当てはめ残差 [px] なので mm にしておくと公差と直接比べられる。
    - 空の表(``[]`` / ``{}``)は ``ValueError``(行が 1 件も無いことを換算の後ろへ隠さない)。
    """
    op = "table_px_to_mm"
    k = _finite_positive(mm_per_px, "mm_per_px", op)
    keys = tuple(keys)

    def _conv(d):
        if not isinstance(d, dict):
            raise ValueError("%s: each row must be a dict, got %r" % (op, type(d).__name__))
        out = dict(d)
        for key in keys:
            v = d.get(key)
            if isinstance(v, (int, float, np.integer, np.floating)) and not isinstance(v, bool):
                out[key + "_mm"] = float(v) * k
        p = d.get("params")
        if isinstance(p, dict):
            out["params"] = _conv(p)
        return out

    # ★空の表は名指しで拒否する(2026-10-12 の空入力の方針 A)。空 list を空 list で返すと、
    #   測定が 1 件も取れなかったことが mm 換算の後ろで見えなくなる。
    if isinstance(table, dict):
        if not table:
            raise ValueError("%s: table is empty — pass a non-empty dict or list of dicts" % op)
        return _conv(table)
    if isinstance(table, (list, tuple)):
        if len(table) == 0:
            raise ValueError("%s: table is empty — pass at least one row" % op)
        return [_conv(d) for d in table]
    raise ValueError("%s: table must be a dict or a list of dicts, got %r"
                     % (op, type(table).__name__))
