"""Fullseye 3DGS シーン(モデル)レジストリ ―― 散在するモデルを一元管理。

各シーンの XML パス・外部メッシュ dir・既定 framing(lookat/radius/elevation)・カテゴリ・
付随モーション軌道を 1 か所で持つ。外部メッシュが要るモデル(evis 等)は meshdir を注入
した自己完結 XML を `.scene_cache/` に生成して返すので、呼び手はパスを渡すだけでよい。

  scene_registry.entries()          -> [(name, spec, available)]
  scene_registry.resolve("evis")    -> {xml(ロード可能), lookat, radius, elevation_deg, ...}
  scene_registry.motion("evis","walk") -> qpos 軌道 .npy パス(無ければ None)

ユーザー定義は register(name, ...) か scenes.json(imgevolve 直下)で追加できる。
"""
from __future__ import annotations
import json
import os

ROOT = os.path.dirname(os.path.abspath(__file__))
_CACHE = os.path.join(ROOT, ".scene_cache")
# ★配布物にローカル絶対パスを焼き込まない。ここは**自分のマシンの作業物**を指していた
#   ので、他人が pip install した環境では黙って落ちる(しかも「場面が無い」ではなく
#   「その場面だけ静かに欠ける」形で)。環境変数で受け、未設定なら**その場面を登録しない**
#   = 在ると偽らない。`loco_mujoco` は入っていれば自分で在り処を知っているので探す。
_MENAGERIE = os.environ.get("MUJOCO_MENAGERIE", "")
_ONO = os.environ.get("ONOCOLLO_MUSCULO", "")


def _loco_humanoid_meshes() -> str:
    """`loco_mujoco` が入っていればその同梱メッシュの場所。無ければ空。"""
    env = os.environ.get("LOCO_MUJOCO_HUMANOID_MESHES", "")
    if env:
        return env
    try:
        import loco_mujoco
        p = os.path.join(os.path.dirname(os.path.abspath(loco_mujoco.__file__)),
                         "environments", "data", "humanoid")
        return p if os.path.isdir(p) else ""
    except Exception:
        return ""


_LOCO_MESHES = _loco_humanoid_meshes()

_DEMO_XML = (
    '<mujoco><worldbody><light pos="0 0 3" dir="0 0 -1"/>'
    '<geom name="floor" type="box" size="1 1 .02" pos="0 0 0" rgba=".4 .45 .5 1"/>'
    '<geom type="sphere" size=".18" pos=".25 0 .25" rgba=".85 .2 .2 1"/>'
    '<geom type="box" size=".12 .12 .12" pos="-.2 .2 .18" rgba=".2 .7 .3 1"/>'
    '<geom type="capsule" size=".08 .12" pos="-.15 -.2 .2" rgba=".25 .35 .85 1"/>'
    '</worldbody></mujoco>')


def _terrain_xml():
    """バンプ地形(連続面)。SuGaR でメッシュ化しやすく、上を歩かせる合成の土台。"""
    import math
    bumps = []
    rng = [(-1.4, -1.0, 0.28), (-0.6, 0.7, 0.34), (0.1, -0.5, 0.30), (0.8, 0.4, 0.38),
           (1.3, -0.9, 0.26), (-1.1, 0.3, 0.24), (0.5, 1.1, 0.30), (-0.2, -1.2, 0.28),
           (1.2, 1.0, 0.24), (-1.3, -0.2, 0.30)]
    for i, (x, y, r) in enumerate(rng):
        h = 0.08 + 0.05 * ((i % 3))
        c = 0.36 + 0.05 * ((i % 4)) / 3.0
        bumps.append(f'<geom type="ellipsoid" size="{r:.2f} {r*0.9:.2f} {h:.2f}" '
                     f'pos="{x:.2f} {y:.2f} {h*0.5:.2f}" rgba="{c:.2f} {c*0.86:.2f} {c*0.66:.2f} 1"/>')
    return ('<mujoco><worldbody><light pos="0 0 4" dir="0 0 -1" diffuse=".8 .8 .8"/>'
            '<geom name="ground" type="box" size="2 2 .05" pos="0 0 0" rgba=".45 .40 .32 1"/>'
            + "".join(bumps) + '</worldbody></mujoco>')

def _rolling_xml(n=18, half=1.5):
    """連続起伏地形(滑らかな height 関数の柱グリッド)。自己完結 XML(外部資産なし)。
    TSDF 融合で滑らかな歩行面になり、evis が起伏を歩く合成の土台に向く。"""
    import math
    cols = []
    step = 2 * half / n
    for i in range(n):
        for j in range(n):
            x = -half + (i + 0.5) * step
            y = -half + (j + 0.5) * step
            # 滑らかな多周波の起伏(振幅 ~0.32m)
            h = (0.13 * math.sin(1.6 * x) * math.cos(1.4 * y)
                 + 0.07 * math.sin(2.9 * x + 1.3) * math.sin(2.3 * y)
                 + 0.05 * math.cos(3.3 * y - 0.7))
            h = 0.18 + h                                  # 0 付近を避け正の柱高に
            h = max(0.04, h)
            t = min(1.0, h / 0.36)                        # 高さ→色(谷=緑、峰=タン)
            r = 0.30 + 0.34 * t; g = 0.42 - 0.06 * t; b = 0.26 - 0.10 * t
            cols.append(
                f'<geom type="box" size="{step*0.62:.3f} {step*0.62:.3f} {h/2:.3f}" '
                f'pos="{x:.3f} {y:.3f} {h/2:.3f}" rgba="{r:.2f} {max(g,0.05):.2f} {max(b,0.02):.2f} 1"/>')
    return ('<mujoco><worldbody><light pos="0 0 4" dir="0 0 -1" diffuse=".85 .85 .85"/>'
            '<geom name="ground" type="box" size="1.8 1.8 .03" pos="0 0 0" rgba=".33 .40 .28 1"/>'
            + "".join(cols) + '</worldbody></mujoco>')


# framing = lookat(xyz), radius, elevation_deg。category は表示・gait 適用の目安。
_CATALOG = {
    "demo":   {"synthetic": _DEMO_XML, "category": "synthetic",
               "lookat": [0, 0, 0.2], "radius": 1.3, "elevation_deg": 25},
    "terrain": {"synthetic": _terrain_xml(), "category": "terrain",
                "lookat": [0, 0, 0.1], "radius": 3.2, "elevation_deg": 28},
    "rolling": {"synthetic": _rolling_xml(n=26), "category": "terrain",
                "lookat": [0, 0, 0.15], "radius": 3.0, "elevation_deg": 30},
    "go2":    {"xml": f"{_MENAGERIE}/unitree_go2/scene.xml", "category": "quadruped",
               "lookat": [0, 0, 0.18], "radius": 1.3, "elevation_deg": 22, "gait": "trot"},
    "anymal": {"xml": f"{_MENAGERIE}/anybotics_anymal_c/scene.xml", "category": "quadruped",
               "lookat": [0, 0, 0.4], "radius": 1.8, "elevation_deg": 20, "gait": "trot"},
    "spot":   {"xml": f"{_MENAGERIE}/boston_dynamics_spot/scene.xml", "category": "quadruped",
               "lookat": [0, 0, 0.4], "radius": 1.8, "elevation_deg": 20, "gait": "trot"},
    "cassie": {"xml": f"{_MENAGERIE}/agility_cassie/scene.xml", "category": "biped",
               "lookat": [0, 0, 0.6], "radius": 2.2, "elevation_deg": 18},
    "apollo": {"xml": f"{_MENAGERIE}/apptronik_apollo/scene.xml", "category": "humanoid",
               "lookat": [0, 0, 0.8], "radius": 2.6, "elevation_deg": 15},
    "evis":   {"xml": f"{_ONO}/loco/humanoid_muscle_mjxfeet.xml", "meshdir": _LOCO_MESHES,
               "category": "musculo-skeleton", "lookat": [-0.3, 0.13, 0.85],
               "radius": 2.2, "elevation_deg": 12, "view_azimuth": 0.5,
               "motions": {"walk": f"{_ONO}/loco/mjx_loco_free2_view_qpos.npy", "getup": f"{_ONO}/loco/mjx_loco_cpg1_view_qpos.npy"}},
}


def _load_user_catalog():
    """imgevolve/scenes.json があればユーザー定義を統合(同名は上書き)。"""
    p = os.path.join(ROOT, "scenes.json")
    if os.path.isfile(p):
        try:
            with open(p, encoding="utf-8") as f:
                _CATALOG.update(json.load(f))
        except (OSError, ValueError):
            pass


_load_user_catalog()


def register(name, **spec):
    """実行時にシーンを追加/上書き。"""
    _CATALOG[name] = spec


def _available(spec):
    if "synthetic" in spec:
        return True
    xml = spec.get("xml")
    return bool(xml and os.path.isfile(xml))


def names():
    return list(_CATALOG)


def entries():
    """[(name, spec, available)] を返す。"""
    return [(n, s, _available(s)) for n, s in _CATALOG.items()]


def _cache_xml(name, content):
    os.makedirs(_CACHE, exist_ok=True)
    p = os.path.join(_CACHE, f"{name}.xml")
    if not os.path.isfile(p) or open(p, encoding="utf-8").read() != content:
        with open(p, "w", encoding="utf-8") as f:
            f.write(content)
    return p


def _patch_meshdir(xml_path, meshdir):
    """<compiler ...> に meshdir を注入した自己完結 XML をキャッシュに書き出す。"""
    src = open(xml_path, encoding="utf-8").read()
    if "meshdir" in src:
        return xml_path
    patched = src.replace("<compiler ", f'<compiler meshdir="{meshdir}" ', 1)
    if patched == src:                                  # <compiler> が無い場合は先頭に追加
        patched = src.replace("<mujoco>", f'<mujoco><compiler meshdir="{meshdir}"/>', 1)
    return _cache_xml(os.path.basename(xml_path)[:-4] + "_patched", patched)


def resolve(name):
    """名前 or .xml パスを framing 付き spec に解決。ロード可能な xml パスを返す。無ければ None。"""
    if name in _CATALOG:
        s = dict(_CATALOG[name])
        if "synthetic" in s:
            s["xml"] = _cache_xml(name, s.pop("synthetic"))
        elif s.get("meshdir"):
            if not os.path.isfile(s["xml"]):
                return None
            s["xml"] = _patch_meshdir(s["xml"], s["meshdir"])
        elif not os.path.isfile(s.get("xml", "")):
            return None
        s.setdefault("lookat", [0, 0, 0.3]); s.setdefault("radius", 2.0)
        s.setdefault("elevation_deg", 20); s.setdefault("category", "custom")
        s["name"] = name
        return s
    if name.endswith(".xml") and os.path.isfile(name):   # 任意 MJCF パス
        return {"name": name, "xml": name, "lookat": [0, 0, 0.3], "radius": 2.0,
                "elevation_deg": 20, "category": "custom"}
    return None


def motion(name, key=None):
    """シーンの付随モーション軌道 .npy パス。key 省略時は最初の1つ。無ければ None。"""
    s = _CATALOG.get(name)
    if not s or "motions" not in s:
        return None
    motions = s["motions"]
    if key is None:
        key = next(iter(motions))
    p = motions.get(key)
    return p if (p and os.path.isfile(p)) else None


def motions(name):
    """シーンの利用可能モーション名の一覧。"""
    s = _CATALOG.get(name)
    return [k for k, p in (s.get("motions", {}) if s else {}).items() if os.path.isfile(p)]
