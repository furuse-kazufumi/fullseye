# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""bundle3d — N 視点バンドル調整(全カメラ姿勢 + 3D 構造を再投影誤差最小で同時最適化)。

twoview が 2 視点の相対姿勢初期化なら、bundle3d はその N 視点版 = SfM/VO の仕上げ。
各カメラを回転ベクトル rvec(3) + 並進 t(3) の 6 パラメータで表し、観測(どのカメラがどの 3D 点を
どの画素で見たか)全体の再投影残差を Levenberg-Marquardt(scipy.optimize.least_squares)で最小化する。
gauge 自由度(相似変換 7-DOF)は **先頭カメラを固定**して回転+並進の 6 を除き、残る **scale は
「構造のカメラ 0 中心からの RMS 距離を初期値に保つ」残差**で固定する(2026-09-02 実測: scale を
放置すると LM は再投影 0 のまま scale を ×0.7〜×213 まで滑らせた — 再投影誤差は相似変換に
厳密に不変なので、拘束が無ければ解の scale は数値的偶然で決まる)。

規約: 射影 u = K (R X + t) の透視除算(match3d.project_points と一致)。K は全カメラ共有(単純化)。
GT 検証 = 合成 N カメラ+点群で観測生成 → 姿勢と点に摂動 → BA で再投影 RMSE ~0・回転誤差<0.5°に回復。

用途: 単眼/多眼 SfM の後段最適化、hand-eye 較正の精緻化、マルチカメラ計測の一括調整(Physical AI)。
"""
import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation


def rvec_to_R(rvec):
    """回転ベクトル(3,) → 回転行列(3,3)。"""
    return Rotation.from_rotvec(np.asarray(rvec, float)).as_matrix()


def R_to_rvec(R):
    """回転行列(3,3) → 回転ベクトル(3,)。"""
    return Rotation.from_matrix(np.asarray(R, float)).as_rotvec()


def project(points, rvec, t, K):
    """3D 点 (n,3) をカメラ (rvec,t,K) で 2D (n,2) に射影(透視除算)。

    ``X_cam = R(rvec) @ X + t``、``x = K @ X_cam``、``uv = x[:2] / x[2]`` を全点まとめて計算する
    (``project_points`` と同じ規約)。``rvec`` は回転ベクトル(軸 × 角 [rad]、scipy の
    ``Rotation.from_rotvec``)、``t`` は (3,) 並進、``K`` は (3,3) 内部行列。返り値は (n,2) float で
    列 0 が u(横・列方向)、列 1 が v(縦・行方向)、単位は K に従いピクセル。

    注意(検証なし): カメラ後方や像平面上の点(``Z_cam <= 0``)を弾かず、そのまま除算する。
    ``Z_cam = 0`` は 0 割で inf/NaN、負の Z は画像内に見える偽の座標になるので、可視性の判定は
    呼び出し側で行う。形状の検証もしない(``np.asarray`` で float 化するのみ)。
    ``bundle_adjust`` / ``mean_reprojection_error`` の再投影残差はこの関数で作られる。

    空の入力(``points`` が 0 要素)は ValueError。
    """
    if (len(points) if isinstance(points, (list, tuple)) else np.asarray(points).size) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("project: points is empty — pass at least one element")
    R = rvec_to_R(rvec)
    Xc = (R @ np.asarray(points, float).T).T + np.asarray(t, float)
    x = (np.asarray(K, float) @ Xc.T).T
    return x[:, :2] / x[:, 2:3]


def _pack(cameras, points, fix_first):
    """(cameras (nc,6), points (m,3)) → 最適化パラメータベクトル(fix_first なら cam0 除外)。"""
    cams = cameras[1:] if fix_first else cameras
    return np.concatenate([cams.ravel(), points.ravel()])


def _unpack(params, nc, m, cam0, fix_first):
    """パラメータベクトル → (cameras (nc,6), points (m,3))。"""
    if fix_first:
        cam_rest = params[: (nc - 1) * 6].reshape(nc - 1, 6)
        cameras = np.vstack([cam0[None, :], cam_rest])
        pts = params[(nc - 1) * 6:].reshape(m, 3)
    else:
        cameras = params[: nc * 6].reshape(nc, 6)
        pts = params[nc * 6:].reshape(m, 3)
    return cameras, pts


def reprojection_residuals(cameras, points, obs_cam, obs_pt, obs_uv, K):
    """全観測の再投影残差(2*K,)。cameras (nc,6)=[rvec|t]、obs_* は観測配列。"""
    cameras = np.asarray(cameras, float)
    points = np.asarray(points, float)
    obs_cam = np.asarray(obs_cam, int)
    obs_pt = np.asarray(obs_pt, int)
    obs_uv = np.asarray(obs_uv, float)
    res = np.empty((len(obs_cam), 2))
    for c in np.unique(obs_cam):
        m = obs_cam == c
        proj = project(points[obs_pt[m]], cameras[c, :3], cameras[c, 3:], K)
        res[m] = proj - obs_uv[m]
    return res.ravel()


def mean_reprojection_error(cameras, points, obs_cam, obs_pt, obs_uv, K):
    """バンドル調整の全観測について再投影誤差の RMS(ピクセル)を返す。

    全観測 k について ``project(points[obs_pt[k]], cameras[obs_cam[k]])`` と ``obs_uv[k]`` の差
    (du, dv) を取り、``sqrt(mean_k(du² + dv²))`` = 観測ごとの再投影距離の 2 乗平均平方根を float で
    返す(実装は ``r.reshape(-1,2)**2 * 2`` の平均の平方根で、同じ量)。単位は ``obs_uv`` と K に
    従うピクセル。

    - ``cameras``: (nc,6) の ``[rvec(3) | t(3)]``(``X_cam = R X + t``)。
    - ``points``: (m,3) の 3D 点。
    - ``obs_cam`` / ``obs_pt``: 各観測のカメラ添字・点添字(int)。``obs_uv``: (K,2) の観測画素。
    - ``K``: 全カメラ共通の (3,3) 内部行列。

    ``bundle_adjust`` の返り値 ``rmse`` と同じ計算で、最適化前後の比較に使う。観測が 0 件だと空の
    平均で NaN になる(長さの検証は ``bundle_adjust`` 側にあり、この関数単体では行わない)。
    カメラ後方の点も ``project`` がそのまま射影するので、可視性は呼び出し側で保証する。
    空の入力(``cameras`` が 0 要素)は ValueError。
    """
    if np.asarray(cameras).size == 0:   # ★2026-10-11 台帳の空入力の門: 生の例外でなく名指しで拒否
        raise ValueError("mean_reprojection_error: cameras is empty — pass at least one element")
    r = reprojection_residuals(cameras, points, obs_cam, obs_pt, obs_uv, K)
    return float(np.sqrt(np.mean(r.reshape(-1, 2) ** 2 * 2)))


def bundle_adjust(cameras, points, obs_cam, obs_pt, obs_uv, K,
                  fix_first=True, max_iter=200):
    """再投影誤差最小でカメラ姿勢と 3D 点を同時最適化。→ dict{cameras, points, rmse, cost}。

    cameras (nc,6)=[rvec(3)|t(3)] の初期値、points (m,3) の初期値、観測 obs_cam/obs_pt/obs_uv。
    fix_first=True で先頭カメラを [I|0] 相当(初期値のまま)に固定し gauge を除く。

    **scale gauge**: 再投影誤差は「カメラ 0 の中心を基準にシーン全体を相似拡大」しても
    厳密に変わらないので、それだけでは解の scale が定まらず LM が任意の倍率へ滑る
    (実測 ×0.7〜×213、rmse≈0 のまま)。本関数は **構造のカメラ 0 中心からの RMS 距離
    (``scale_anchor``)を初期値に保つ残差** ``w·(rms/rms0 − 1)`` を 1 本足して固定する。
    再投影コストは scale 方向に勾配ゼロなので、この残差は最適解で厳密に 0 になり、
    返る scale は初期構造のそれと一致する(基線長 ``‖t₁‖`` で固定するより、点数で
    平均される分だけ初期摂動の影響が小さい)。初期構造が退化(全点がカメラ 0 中心に
    一致)していれば拘束は掛けない。返り dict の ``scale_anchor`` に採用した RMS 距離を載せる。
    """
    cameras = np.asarray(cameras, float)
    points = np.asarray(points, float)
    obs_cam = np.asarray(obs_cam, int)
    obs_pt = np.asarray(obs_pt, int)
    obs_uv = np.asarray(obs_uv, float)
    nc, m = len(cameras), len(points)
    if nc < 2:
        raise ValueError("bundle adjustment requires at least 2 cameras")
    if len(obs_cam) == 0:
        raise ValueError("observations are empty (bundle adjustment requires reprojection observations)")
    if not (len(obs_cam) == len(obs_pt) == len(obs_uv)):
        raise ValueError("observation array lengths do not match")
    cam0 = cameras[0].copy()

    def _scale_of(cams, pts):
        # RMS distance of the structure from the camera-0 centre C0 = -R0^T t0:
        # invariant to the rotation/translation gauge, linear in the scale gauge.
        C0 = -rvec_to_R(cams[0, :3]).T @ cams[0, 3:]
        return float(np.sqrt(np.mean(np.sum((pts - C0) ** 2, axis=1))))

    scale0 = _scale_of(cameras, points)
    fix_scale = scale0 > 0.0
    w_scale = 1e4          # px per unit relative scale drift (soft, but exact at the optimum)

    def fun(p):
        cams, pts = _unpack(p, nc, m, cam0, fix_first)
        r = reprojection_residuals(cams, pts, obs_cam, obs_pt, obs_uv, K)
        if fix_scale:
            r = np.append(r, w_scale * (_scale_of(cams, pts) / scale0 - 1.0))
        return r

    p0 = _pack(cameras, points, fix_first)
    sol = least_squares(fun, p0, method="lm", max_nfev=max_iter * len(p0))
    cams, pts = _unpack(sol.x, nc, m, cam0, fix_first)
    rmse = mean_reprojection_error(cams, pts, obs_cam, obs_pt, obs_uv, K)
    return {"cameras": cams, "points": pts, "rmse": rmse, "cost": float(sol.cost),
            "scale_anchor": scale0 if fix_scale else None}
