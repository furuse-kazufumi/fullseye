# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""annotate3d — 3-D のアンカーを画像に射影して矢印・引き出し線・寸法を描く図注 op。

学術図では「メッシュのこの点がこれ」「この距離が 10 mm」を、**描いた絵の上に**
矢印や線で示す。3-D の点を持っている側(点群・メッシュ・姿勢推定の結果)が
2-D の画素座標を手で計算するのは間違いの元(軸の向き・主点・-Z 慣習)なので、
**射影を 1 か所に閉じ込め**、描くのは :mod:`annotate` の 2-D 部品に任せる。

## カメラの慣習(:mod:`render3d` と同一)

* ``pose`` は **4x4 の object→camera 行列**(:func:`render3d.look_at` の返り)。
  ``(R, t)`` の 2-tuple も受け、同じ意味(``X_c = R X + t``)に組み直す。
* カメラは **local -Z を見る**(OpenGL / gluLookAt)。前方距離 ``z = -X_c[2]``。
* ``K`` は 3x3 ピンホール。画素中心が整数座標(``cx = (W-1)/2``、
  :func:`render3d.intrinsics_from_fov`)。
* 射影(閉形式): ``u = fx * X_c[0] / z + cx``、``v = cy - fy * X_c[1] / z``。
  :mod:`tests.test_annotate3d` は既知カメラ・既知点でこの式との一致を 1e-9 で
  確かめる。

:func:`camera.project_points` は **+Z を見る**別慣習(OpenCV 流)なので、その
姿勢をここへ渡すと点が「カメラの後ろ」と判定される。:func:`render3d.render_mesh`
に渡した ``pose``/``intrinsics`` をそのまま渡すのが正しい使い方。

## 遮蔽(occlusion)

``depth=`` に :func:`render3d.render_mesh` の ``depth``(前方距離、背景は inf)を
渡すと、アンカーの前方距離 ``z`` と、その画素の深度 ``d`` を比べて
``d < z * (1 - occlusion_tol)`` なら **隠れている**と判定する。隠れたアンカーは
**破線 + 白抜き印**で描く(消さない ―― 「そこにある」ことは示す)。

## 規律

* fail-closed: カメラの後ろの点・非有限・退化した姿勢は ValueError。
* 全 op は :mod:`annotate` と同じく入力を破壊せず新しい配列を返す(float [0,1])。
* 決定的(乱数なし)。
"""
from __future__ import annotations

import math

import numpy as np

import annotate as A

__all__ = [
    "project_anchors", "annotate3d_project",
    "annotate3d_arrow", "annotate3d_label", "annotate3d_scale_bar",
    "annotate3d_axes", "annotate3d_bbox", "annotate3d_measure",
]

#: 前方距離がこれ以下の点は「カメラ面上/後ろ」として拒否する。
_NEAR_EPS = 1e-9


# ------------------------------------------------------------------ #
# 射影(1 か所)
# ------------------------------------------------------------------ #

def _pose44(pose):
    """``pose`` を 4x4 の object→camera 行列にする(``(R, t)`` も受ける)。"""
    if isinstance(pose, (tuple, list)) and len(pose) == 2:
        R = np.asarray(pose[0], dtype=np.float64)
        t = np.asarray(pose[1], dtype=np.float64).ravel()
        if R.shape != (3, 3) or t.size != 3:
            raise ValueError(f"pose as (R, t) needs R (3,3) and t (3,) (got {R.shape}, {t.shape})")
        P = np.eye(4, dtype=np.float64)
        P[:3, :3] = R
        P[:3, 3] = t
    else:
        P = np.asarray(pose, dtype=np.float64)
        if P.shape != (4, 4):
            raise ValueError(f"pose must be a 4x4 matrix or (R, t) (got shape {P.shape})")
    if not np.all(np.isfinite(P)):
        raise ValueError("pose contains non-finite values")
    if abs(float(np.linalg.det(P[:3, :3]))) < 1e-9:
        raise ValueError("pose rotation is degenerate (near-zero determinant)")
    return P


def _K33(K):
    M = np.asarray(K, dtype=np.float64)
    if M.shape != (3, 3):
        raise ValueError(f"K must be a 3x3 intrinsics matrix (got shape {M.shape})")
    if not np.all(np.isfinite(M)):
        raise ValueError("K contains non-finite values")
    if abs(M[0, 0]) < 1e-12 or abs(M[1, 1]) < 1e-12:
        raise ValueError("K has a zero focal length (fx or fy)")
    return M


def _points3(p, name="points", min_n=1):
    a = np.asarray(p, dtype=np.float64)
    if a.ndim == 1 and a.size == 3:
        a = a[None, :]
    if a.ndim != 2 or a.shape[1] != 3:
        raise ValueError(f"{name} must be (N, 3) or (3,) (got shape {a.shape})")
    if a.shape[0] < min_n:
        raise ValueError(f"{name} needs at least {min_n} point(s) (got {a.shape[0]})")
    if not np.all(np.isfinite(a)):
        raise ValueError(f"{name} contains non-finite values")
    return a


def _project(points, P, K):
    """object 座標 (N,3) → ``(uv (N,2), z (N,))``。z は前方距離(後ろは負)。"""
    Xc = points @ P[:3, :3].T + P[:3, 3]
    z = -Xc[:, 2]
    safe = np.where(np.abs(z) < _NEAR_EPS, np.nan, z)
    u = K[0, 0] * (Xc[:, 0] / safe) + K[0, 1] * (Xc[:, 1] / safe) + K[0, 2]
    v = K[1, 2] - K[1, 1] * (Xc[:, 1] / safe)
    return np.stack([u, v], axis=1), z


def _depth_image(depth, shape=None):
    if depth is None:
        return None
    d = np.asarray(depth, dtype=np.float64)
    if d.ndim != 2:
        raise ValueError(f"depth must be a 2-D (H,W) distance image (got shape {d.shape})")
    if shape is not None and tuple(d.shape) != tuple(shape):
        raise ValueError(f"depth shape {d.shape} does not match the image {tuple(shape)}")
    if np.any(np.isnan(d)):
        raise ValueError("depth holds NaN — use +inf for background (render_mesh does)")
    return d


def project_anchors(points, pose, K, depth=None, shape=None, occlusion_tol=0.01):
    """3-D の点を画素へ射影し、前方 / 画像内 / 遮蔽の判定を付ける(表を返す)。

    Parameters
    ----------
    points : (N, 3) or (3,)
        object 座標。
    pose : (4,4) or (R, t)
        object→camera(:func:`render3d.look_at` の慣習、-Z を見る)。
    K : (3,3)
        内部行列。
    depth : (H, W) or None
        :func:`render3d.render_mesh` の ``depth``(前方距離、背景 inf)。
        渡すと ``hidden`` を判定する。
    shape : (H, W) or None
        画像の大きさ(``depth`` があればそれから取る)。``in_image`` に使う。
    occlusion_tol : float
        ``d < z * (1 - tol)`` で隠れ判定(z-buffer の離散化ぶんの許容)。

    Returns
    -------
    dict
        ``{"uv": (N,2), "depth": (N,), "in_front": bool (N,), "in_image": bool (N,),
        "hidden": bool (N,), "visible": bool (N,)}``。``uv`` は後ろの点で NaN。
        ``hidden`` は depth が無ければ全て False、``in_image`` は shape も depth も
        無ければ全て True(判定していない)。

    Raises
    ------
    ValueError
        形・非有限・退化姿勢・depth の形の不一致・tol が [0,1) の外。
    """
    P = _pose44(pose)
    Km = _K33(K)
    pts = _points3(points)
    tol = A._num(occlusion_tol, "occlusion_tol", lo=0.0)
    if tol >= 1.0:
        raise ValueError(f"occlusion_tol must be < 1 (got {tol})")
    d = _depth_image(depth, shape)
    if d is not None:
        shape = d.shape
    uv, z = _project(pts, P, Km)
    in_front = z > _NEAR_EPS
    n = pts.shape[0]
    if shape is not None:
        H, W = A._shape2(shape)
        with np.errstate(invalid="ignore"):
            in_image = in_front & (uv[:, 0] >= 0) & (uv[:, 0] <= W - 1) & \
                (uv[:, 1] >= 0) & (uv[:, 1] <= H - 1)
    else:
        in_image = np.ones(n, dtype=bool)
    hidden = np.zeros(n, dtype=bool)
    if d is not None:
        for i in np.flatnonzero(in_front & in_image):
            c, r = int(round(uv[i, 0])), int(round(uv[i, 1]))
            dz = d[min(max(r, 0), d.shape[0] - 1), min(max(c, 0), d.shape[1] - 1)]
            hidden[i] = bool(np.isfinite(dz) and dz < z[i] * (1.0 - tol))
    return {"uv": uv, "depth": z, "in_front": in_front, "in_image": in_image,
            "hidden": hidden, "visible": in_front & in_image & ~hidden}


def annotate3d_project(points, pose, K, depth=None, shape=None, occlusion_tol=0.01):
    """table(dict)を返す: 3-D 点の画素座標・前方距離・画像内/遮蔽の判定(:func:`project_anchors`)。

    描画を伴わない「射影だけ」の op。annotate3d の全描画 op が内部で使う判定を
    そのまま表として返すので、自前のプロット・数値検証・「この点は見えるか」の
    分岐に使う。

    射影(閉形式、render3d と同一慣習): ``X_c = R X + t``(``pose`` は 4x4 の
    object→camera、または ``(R, t)`` の 2-tuple)。カメラは **local -Z を見る**ので
    前方距離は ``z = -X_c[2]``。画素は ``u = fx X_c[0]/z + skew X_c[1]/z + cx``、
    ``v = cy - fy X_c[1]/z``(``K`` は 3x3、``K[0,1]`` の skew も使う。画素中心は
    整数座標、``u`` = 列、``v`` = 行)。

    引数:
    - ``points``: ``(N, 3)`` または ``(3,)``(object 座標、有限)。
    - ``depth``: ``(H, W)`` の前方距離画像(``render3d.render_mesh`` の ``depth``、
      背景は ``+inf``)。渡すと ``shape`` はこれから取り、遮蔽を判定する。
    - ``shape``: ``(H, W)``。``depth`` が無いときの画像内判定に使う。
    - ``occlusion_tol``: ``[0, 1)``。画素の深度 ``d`` が ``d < z * (1 - tol)`` なら
      隠れ(z-buffer 離散化の許容)。

    返り値(dict、全て長さ ``N``):
    - ``uv`` ``(N, 2)`` float — ``(u, v)`` 画素座標。後ろの点は NaN。
    - ``depth`` ``(N,)`` — 前方距離 ``z``(後ろは負)。
    - ``in_front`` — ``z > 1e-9``。
    - ``in_image`` — ``0 <= u <= W-1`` かつ ``0 <= v <= H-1``(前方の点のみ)。
      ``shape`` も ``depth`` も無ければ全 True(未判定)。
    - ``hidden`` — ``depth`` があるときだけ判定(画素は最近傍丸め)。無ければ全 False。
    - ``visible`` = ``in_front & in_image & ~hidden``。

    検証(``ValueError``): ``pose`` が 4x4 でも ``(R, t)`` でもない・非有限・回転部の
    行列式がほぼ 0 / ``K`` が 3x3 でない・非有限・``fx`` か ``fy`` が 0 / ``points`` の
    形・非有限 / ``depth`` が 2-D でない・``shape`` と不一致・NaN を含む /
    ``occlusion_tol`` が ``[0, 1)`` の外。**後ろの点はここではエラーにしない**
    (``in_front=False`` で返す。描画 op はそこで ``ValueError`` にする)。

    注意: ``camera.project_points`` は +Z を見る別慣習(OpenCV 流)なので、その
    姿勢を渡すと全点が後ろ扱いになる。``render3d.render_mesh`` に渡した ``pose`` /
    ``intrinsics`` をそのまま渡す。"""
    return project_anchors(points, pose, K, depth=depth, shape=shape,
                           occlusion_tol=occlusion_tol)


# ------------------------------------------------------------------ #
# 描く
# ------------------------------------------------------------------ #

def _need_front(tab, names):
    for i, name in enumerate(names):
        if not tab["in_front"][i]:
            raise ValueError(
                f"{name} lies on or behind the camera plane (front distance "
                f"{tab['depth'][i]:.3g}) — it has no pixel; check that pose is the "
                "render3d (look down -Z) convention, not camera.project_points (+Z)")


def _uv(tab, i):
    return float(tab["uv"][i, 0]), float(tab["uv"][i, 1])


_HIDDEN_DASH = (5.0, 4.0)


def annotate3d_arrow(img, p0, p1, pose, K, depth=None, color="emphasis", width=2,
                     head_len=12.0, head_width=9.0, occlusion_tol=0.01, scheme="okabe_ito"):
    """画像(image2d)を返す: 3-D の ``p0`` から ``p1`` へ、射影した矢印を描く。

    ``depth`` を渡し**両端とも隠れている**なら破線で描く(矢じりは半透明)。

    Raises
    ------
    ValueError
        端点がカメラの後ろ / 2 点が同じ画素に射影される / 両端とも画像の外、姿勢・K の不正。

    手順: ``img`` を float64 ``[0, 1]`` の複製にし(``(H, W)`` / ``(H, W, C)``、C は
    1/3/4。非有限・空は ``ValueError``)、``p0``, ``p1`` を ``annotate3d_project`` と
    同じ射影で画素にして、``annotate.arrow`` で ``p0`` の画素から ``p1`` の画素へ
    矢印を描く。矢じりは ``p1`` 側。

    引数:
    - ``p0``, ``p1``: object 座標 ``(3,)``(有限)。``pose`` は 4x4 object→camera か
      ``(R, t)``、``K`` は 3x3(-Z を見る render3d 慣習)。
    - ``depth``: ``(H, W)`` 前方距離画像(``render3d.render_mesh`` の ``depth``)。
      画像と同じ形でなければ ``ValueError``。
    - ``color``: 役割名(``"emphasis"`` など、``scheme`` のパレットで解決)か RGB。
    - ``width``: 線幅 [px]、1 以上の整数(``1.5`` は拒否)。
    - ``head_len`` / ``head_width``: 矢じりの長さ・幅 [px]。隠れ描画では矢印長の
      80 % を超えないよう縮める。
    - ``occlusion_tol``: ``[0, 1)``。

    返り値: 描画済みの新しい画像(float64、入力と同じ形。入力は変更しない)。

    エラーになる条件(実装どおり): どちらかの端点が ``z <= 1e-9``(カメラ面上/後ろ)/
    2 点が同じ画素に射影される(視線上に並ぶ、長さ 1e-9 px 未満)/ **両端とも画像の外**
    (``annotate.arrow`` が拒否する。枠に貼り付いた誤った線を描かないため)/ 姿勢・``K`` の不正。
    片方だけ画像の外なら描く(線は枠外へ向かって引かれ、見た目は枠で切れる)。

    使いどころ: ``render3d.render_mesh`` の画像に「この頂点がこれ」を示す。長さを
    数値で示すなら ``annotate3d_measure``、文字を添えるなら ``annotate3d_label``。
    """
    a = A._prep(img)
    width = A._num(width, "width", lo=1, integer=True)
    tab = project_anchors(np.vstack([_points3(p0, "p0"), _points3(p1, "p1")]), pose, K,
                          depth=depth, shape=a.shape[:2], occlusion_tol=occlusion_tol)
    _need_front(tab, ("p0", "p1"))
    q0, q1 = _uv(tab, 0), _uv(tab, 1)
    if math.hypot(q1[0] - q0[0], q1[1] - q0[1]) < 1e-9:
        raise ValueError("p0 and p1 project to the same pixel — the arrow has no direction "
                         "(the two points lie on one ray through the camera)")
    if depth is not None and tab["hidden"].all():
        w = A._num(width, "width", lo=1)
        span = math.hypot(q1[0] - q0[0], q1[1] - q0[1])
        hl, hw = float(head_len), float(head_width)
        if hl > 0.8 * span:
            k = 0.8 * span / hl
            hl, hw = hl * k, hw * k
        tri, base = A._head_polygon(q0, q1, hl, hw)
        a = A._aa_polyline(a, [q0, base], color, width=w, dash=_HIDDEN_DASH, scheme=scheme)
        return A.filled_polygon(a, tri, color=color, alpha=0.5, scheme=scheme)
    return A.arrow(a, q0, q1, color=color, width=width, head_len=head_len,
                   head_width=head_width, scheme=scheme)


def annotate3d_label(img, text, anchor, pose, K, depth=None, offset=(26.0, -22.0),
                     color="emphasis", width=1.5, cap_size=3.0, font_size=12, pad=4,
                     box_alpha=0.72, text_color=None, occlusion_tol=0.01,
                     scheme="okabe_ito", font_path=None):
    """画像(image2d)を返す: 3-D のアンカーに引き出し線つきの文字を付ける。

    文字はアンカーの画素から ``offset`` [px] ずらした位置(``offset[0]`` の符号で
    左右のアンカーを選ぶ)。``depth`` で隠れていると分かれば**破線 + 白抜きの印**。

    Raises
    ------
    ValueError
        アンカーがカメラの後ろ / 画像の外、文字が収まらない、姿勢・K の不正。

    手順: ``anchor``(object 座標 ``(3,)``)を ``annotate3d_project`` と同じ射影で
    画素 ``(x, y)`` にし、``(x, y)`` から ``(x + offset[0], y + offset[1])`` へ
    引き出し線(``annotate._aa_polyline``、幅 ``width``)を引き、アンカー側に半径
    ``cap_size`` の点を打ち、線の先に ``annotate.text_box`` で文字を置く。
    文字箱の付け根(anchor)は ``offset[0] > 0`` なら左中、``< 0`` なら右中、
    ``== 0`` なら ``offset[1] < 0`` で下中央・それ以外で上中央。

    引数:
    - ``offset``: 画素単位 ``(dx, dy)``(``dy`` は下向き正 = 行方向)。既定
      ``(26, -22)`` は右上へ。
    - ``width``: 線幅 [px]、``>= 0.5`` の実数。``cap_size``: 点の半径 [px]、0 で
      打たない。``pad`` / ``font_size`` / ``box_alpha`` / ``text_color`` /
      ``font_path``: 文字箱の見た目(``font_size`` 未満 9 までは自動縮小)。
    - ``depth``: 前方距離画像。隠れていれば線を破線、点を白抜き(ring)にする。
    - ``color``: 役割名か RGB。``occlusion_tol``: ``[0, 1)``。

    返り値: 描画済みの新しい画像(float64 ``[0, 1]``、入力は変更しない)。

    エラーになる条件(実装どおり): アンカーが ``z <= 1e-9`` / アンカーの画素が
    ``[0, W-1] x [0, H-1]`` の外 / 姿勢・``K``・``depth`` の不正 / 文字箱が縮小しても
    画像に収まらない(``text_box`` 側)。``offset`` の先が枠外でも線は引く。

    使いどころ: 図中の部位名・番号付け。複数の点を一括でラベル付けするときは
    ``annotate3d_project`` で可視判定を先に取り、``visible`` の点だけ呼ぶ。
    """
    a = A._prep(img)
    tab = project_anchors(_points3(anchor, "anchor"), pose, K, depth=depth,
                          shape=a.shape[:2], occlusion_tol=occlusion_tol)
    _need_front(tab, ("anchor",))
    if not tab["in_image"][0]:
        raise ValueError(f"anchor projects to {tuple(round(v, 1) for v in _uv(tab, 0))}, outside "
                         f"the {a.shape[1]}x{a.shape[0]} image")
    ox, oy = A._pt(offset, "offset")
    x, y = _uv(tab, 0)
    txy = (x + ox, y + oy)
    hidden = bool(tab["hidden"][0])
    w = A._num(width, "width", lo=0.5)
    cap = A._num(cap_size, "cap_size", lo=0.0)
    a = A._aa_polyline(a, [(x, y), txy], color, width=w,
                       dash=_HIDDEN_DASH if hidden else None, scheme=scheme)
    if cap > 0:
        a = A._aa_disk(a, (x, y), cap, color, scheme=scheme, ring=(1.5 if hidden else 0.0))
    anch = "lm" if ox > 0 else ("rm" if ox < 0 else ("cb" if oy < 0 else "ct"))
    return A.text_box(a, str(text), txy, color=color, anchor=anch, pad=pad,
                      font_size=font_size, min_font_size=min(9, int(font_size)), box_alpha=box_alpha, text_color=text_color,
                      font_path=font_path, scheme=scheme)


def _bar_with_ticks(a, q0, q1, color, width, tick, scheme, dash=None):
    a = A._aa_polyline(a, [q0, q1], color, width=width, dash=dash, scheme=scheme)
    dx, dy = q1[0] - q0[0], q1[1] - q0[1]
    n = math.hypot(dx, dy)
    if tick > 0 and n > 1e-9:
        px, py = -dy / n * tick / 2.0, dx / n * tick / 2.0
        for q in (q0, q1):
            a = A._aa_polyline(a, [(q[0] - px, q[1] - py), (q[0] + px, q[1] + py)], color,
                               width=width, scheme=scheme)
    return a


def annotate3d_scale_bar(img, origin, direction, length, pose, K, unit="", depth=None,
                         color="neutral", width=2.0, tick=8.0, font_size=12,
                         label_fmt="{:g}", box_alpha=0.55, text_color=None,
                         occlusion_tol=0.01, scheme="okabe_ito", font_path=None):
    """画像(image2d)を返す: メッシュ単位で ``length`` のバーを面上に置いて射影する。

    バーは ``origin`` から ``direction``(正規化)に ``length`` 進む 3-D 線分で、
    **射影後の画素長は視線に対する傾きで縮む**(遠近と短縮を正直に見せる)。
    像面に平行なら画素長は ``f * length / z`` ―― tests が確かめる。

    Raises
    ------
    ValueError
        direction がゼロ、length が非正、端点がカメラの後ろ / 画像の外。

    手順: ``p1 = origin + direction / |direction| * length`` を作り、``origin`` と
    ``p1`` を射影(``annotate3d_project`` と同じ慣習)。両端の画素を結ぶ線と、
    両端に長さ ``tick`` [px] の垂直な目盛を描き(``_bar_with_ticks``)、線の中点から
    画面上側(row が小さい側)へ ``tick/2 + 4`` px 離した位置に
    ``label_fmt.format(length) + " " + unit`` の文字箱を置く。

    引数:
    - ``origin`` ``(3,)``、``direction`` ``(3,)``(向きだけ使う。長さは無視、ゼロは
      拒否)、``length``: メッシュ単位の長さ(``> 0``、``1e-300`` 以上)。
    - ``unit``: 文字列(空なら数値だけ)。``label_fmt``: ``str.format`` の書式
      (既定 ``"{:g}"``)。
    - ``width`` [px] ``>= 0.5``、``tick`` [px] ``>= 0``(0 で目盛なし)、``font_size`` /
      ``box_alpha`` / ``text_color`` / ``font_path``: 文字箱の見た目。
    - ``depth``: 前方距離画像。**両端とも**隠れていれば線を破線にする。
    - ``color``: 既定 ``"neutral"``(役割名)。``scheme``: 色名の配色。``occlusion_tol``: ``[0, 1)``。

    返り値: 描画済みの新しい画像(float64 ``[0, 1]``)。

    エラーになる条件: ``direction`` のノルムが 1e-12 未満 / ``length <= 0`` /
    どちらかの端点が ``z <= 1e-9`` / **どちらかの端点が画像の外**(この op は
    ``in_image`` を両端に要求する — 矢印と違い枠外は拒否) / 姿勢・``K``・``depth``
    の不正 / 文字箱が収まらない。

    注意: 画素上の長さは視線に対する傾きで短縮する(像面に平行なら
    ``f * length / z`` px)。奥行き方向に置くと短く見えるが、それが正直な射影。
    2 点間の実測値を示すなら ``annotate3d_measure``。
    """
    a = A._prep(img)
    o = _points3(origin, "origin")[0]
    dvec = _points3(direction, "direction")[0]
    n = float(np.linalg.norm(dvec))
    if n < 1e-12:
        raise ValueError("direction is a zero vector")
    L = A._num(length, "length", lo=1e-300)
    p1 = o + dvec / n * L
    tab = project_anchors(np.vstack([o, p1]), pose, K, depth=depth, shape=a.shape[:2],
                          occlusion_tol=occlusion_tol)
    _need_front(tab, ("origin", "bar end"))
    if not tab["in_image"].all():
        raise ValueError("the scale bar leaves the image — shorten it or move the origin")
    q0, q1 = _uv(tab, 0), _uv(tab, 1)
    w = A._num(width, "width", lo=0.5)
    t = A._num(tick, "tick", lo=0.0)
    hidden = depth is not None and bool(tab["hidden"].all())
    a = _bar_with_ticks(a, q0, q1, color, w, t, scheme, dash=_HIDDEN_DASH if hidden else None)
    dx, dy = q1[0] - q0[0], q1[1] - q0[1]
    nn = math.hypot(dx, dy)
    nx, ny = (-dy / nn, dx / nn) if nn > 1e-9 else (0.0, -1.0)
    if ny > 0:                                    # 文字は画面上側(row 小)へ
        nx, ny = -nx, -ny
    mid = ((q0[0] + q1[0]) / 2.0 + nx * (t / 2.0 + 4), (q0[1] + q1[1]) / 2.0 + ny * (t / 2.0 + 4))
    text = f"{label_fmt.format(L)} {unit}".rstrip()
    return A.text_box(a, text, mid, color=color, anchor=A._text_anchor_for_direction(nx, ny),
                      pad=3, font_size=font_size, min_font_size=min(9, int(font_size)), box_alpha=box_alpha, text_color=text_color,
                      font_path=font_path, scheme=scheme)


def annotate3d_axes(img, pose, K, origin=(0.0, 0.0, 0.0), length=1.0, depth=None,
                    labels=("X", "Y", "Z"), colors=("wrong", "right", "reference"), width=2,
                    font_size=11, occlusion_tol=0.01, scheme="okabe_ito", font_path=None):
    """画像(image2d)を返す: object 座標(``pose`` の入力側)の 3 軸(gnomon)を ``origin`` から射影して描く。

    Raises
    ------
    ValueError
        length が非正、原点や軸端がカメラの後ろ、labels/colors が 3 つでない、
        軸の文字が画像に収まらない、原点と軸端がともに画像の外。

    手順: ``origin`` と、そこから object 座標の +X / +Y / +Z 方向に ``length`` 進んだ
    3 点を射影(``annotate3d_project`` と同じ慣習)し、原点の画素から各軸端の画素へ
    ``annotate.arrow``(矢じり 8x6 px)を描く。軸端の先 ``0.7 * font_size`` px の
    位置に ``labels[i]`` を背景なし(``box_alpha=0``)の文字で置く。

    引数:
    - ``origin`` ``(3,)``(object 座標)、``length``: 軸の長さ(メッシュ単位、``> 0``)。
    - ``labels``: 3 つの文字列(既定 ``("X", "Y", "Z")``)。``colors``: 3 つの色
      (役割名か RGB。既定 ``("wrong", "right", "reference")`` はパレットの役割名)。
    - ``width``: 線幅 [px]、1 以上の整数。``font_size`` [px]。
    - ``depth`` / ``occlusion_tol``: 射影に渡すが、**この op は隠れ表示(破線)を
      しない**(判定は ``depth`` の形検査に使うだけ)。

    返り値: 描画済みの新しい画像(float64 ``[0, 1]``)。

    エラーになる条件: ``length <= 0`` / ``labels`` か ``colors`` の長さが 3 でない /
    原点または軸端のいずれかが ``z <= 1e-9`` / 姿勢・``K``・``depth`` の不正 / 軸の
    文字が画像に収まらない / 原点と軸端がともに画像の外(``annotate.arrow`` が拒否)。
    軸端だけが枠外なら描く(矢印は枠外へ向かって引く)。
    視線と一致して点に潰れた軸(画素長 1e-9 未満)は黙ってスキップする。

    使いどころ: 図の姿勢の説明(gnomon)。``render3d.look_at`` の ``pose`` を
    そのまま渡し、``origin`` にメッシュの重心や ``bounds`` の角を置く。
    座標系: ``origin`` も軸の向きも ``pose`` が写す元の座標系(object 座標)で解釈する。
    ``look_at`` の ``pose`` は world→camera なので、そのときは world の軸になる。物体の
    姿勢 ``M``(object→world)を含む ``pose @ M`` を渡すと物体の軸が描かれる。
    """
    a = A._prep(img)
    width = A._num(width, "width", lo=1, integer=True)
    o = _points3(origin, "origin")[0]
    L = A._num(length, "length", lo=1e-300)
    if len(labels) != 3 or len(colors) != 3:
        raise ValueError("labels and colors must each hold exactly 3 entries")
    ends = np.vstack([o, o + np.array([L, 0, 0]), o + np.array([0, L, 0]), o + np.array([0, 0, L])])
    tab = project_anchors(ends, pose, K, depth=depth, shape=a.shape[:2],
                          occlusion_tol=occlusion_tol)
    _need_front(tab, ("origin", "x end", "y end", "z end"))
    q0 = _uv(tab, 0)
    for i in range(3):
        q1 = _uv(tab, i + 1)
        if math.hypot(q1[0] - q0[0], q1[1] - q0[1]) < 1e-9:
            continue                                   # 軸が視線に一致(点に潰れる)
        a = A.arrow(a, q0, q1, color=colors[i], width=width, head_len=8.0, head_width=6.0,
                    scheme=scheme)
        ux, uy = q1[0] - q0[0], q1[1] - q0[1]
        nn = math.hypot(ux, uy)
        txy = (q1[0] + ux / nn * (font_size * 0.7), q1[1] + uy / nn * (font_size * 0.7))
        a = A.text_box(a, str(labels[i]), txy, color=colors[i], anchor="cm", pad=2,
                       font_size=font_size, min_font_size=min(9, int(font_size)), box_alpha=0.0, font_path=font_path, scheme=scheme)
    return a


_BOX_EDGES = ((0, 1), (1, 3), (3, 2), (2, 0), (4, 5), (5, 7), (7, 6), (6, 4),
              (0, 4), (1, 5), (2, 6), (3, 7))


def annotate3d_bbox(img, bounds, pose, K, depth=None, color="emphasis", width=1.5,
                    occlusion_tol=0.01, scheme="okabe_ito"):
    """画像(image2d)を返す: 軸平行の 3-D 箱 ``((xmin,ymin,zmin),(xmax,ymax,zmax))`` の 12 辺を射影して描く。

    ``depth`` を渡すと、**両端が隠れている辺**を破線にする。

    Raises
    ------
    ValueError
        bounds の形 / min > max、角がカメラの後ろ。

    手順: ``bounds`` から 8 つの角 ``(x_i, y_j, z_k)``(i, j, k ∈ {min, max})を作り、
    まとめて射影(``annotate3d_project`` と同じ慣習)。12 辺を
    ``annotate._aa_polyline`` で描く。辺の両端が ``hidden`` なら破線、片端だけなら
    実線。

    引数:
    - ``bounds``: ``((xmin, ymin, zmin), (xmax, ymax, zmax))`` の ``(2, 3)``(object
      座標、有限、各軸で ``max >= min``。``max == min`` の潰れた箱は許す)。点群なら
      ``points.min(0)`` / ``points.max(0)``、メッシュなら ``V`` から作る。
    - ``width``: 線幅 [px]、``>= 0.5`` の実数。``color``: 役割名か RGB。
    - ``depth``: 前方距離画像(``render3d.render_mesh`` の ``depth``)。
      ``occlusion_tol``: ``[0, 1)``。

    返り値: 描画済みの新しい画像(float64 ``[0, 1]``、入力は変更しない)。

    エラーになる条件: ``bounds`` が ``(2, 3)`` でない・非有限・``max < min`` の軸が
    ある / **8 角のいずれかが** ``z <= 1e-9``(カメラ面上か後ろ。箱が視点を囲む場合は
    描けない) / 姿勢・``K``・``depth`` の不正。角が画像の外に出るのはエラーに
    しない(線は枠外まで引かれ、見た目は切れる)。

    注意: 軸平行(object 座標の軸に沿った)箱のみ。回転した箱(``smallest_box3`` の
    ``corners``)を描くには、8 角を自分で射影(``annotate3d_project``)して 2-D の
    ``annotate`` 線描画で結ぶ。
    """
    a = A._prep(img)
    b = np.asarray(bounds, dtype=np.float64)
    if b.shape != (2, 3):
        raise ValueError(f"bounds must be ((xmin,ymin,zmin),(xmax,ymax,zmax)) (got shape {b.shape})")
    if not np.all(np.isfinite(b)):
        raise ValueError("bounds contain non-finite values")
    if np.any(b[1] < b[0]):
        raise ValueError(f"bounds max must be >= min on every axis (got {b.tolist()})")
    corners = np.array([[b[i, 0], b[j, 1], b[k, 2]] for i in (0, 1) for j in (0, 1) for k in (0, 1)])
    tab = project_anchors(corners, pose, K, depth=depth, shape=a.shape[:2],
                          occlusion_tol=occlusion_tol)
    _need_front(tab, tuple(f"corner {i}" for i in range(8)))
    w = A._num(width, "width", lo=0.5)
    for i, j in _BOX_EDGES:
        hid = depth is not None and bool(tab["hidden"][i] and tab["hidden"][j])
        a = A._aa_polyline(a, [_uv(tab, i), _uv(tab, j)], color, width=w,
                           dash=_HIDDEN_DASH if hid else None, scheme=scheme)
    return a


def annotate3d_measure(img, p0, p1, pose, K, unit="", depth=None, color="emphasis",
                       width=1.5, tick=8.0, font_size=12, label_fmt="{:.3g}", box_alpha=0.6,
                       text_color=None, occlusion_tol=0.01, scheme="okabe_ito", font_path=None):
    """画像(image2d)を返す: 3-D の 2 点間距離(メッシュ単位)を、射影した線と値で示す。

    値は ``|p1 - p0|``(3-D、閉形式)。画素上の長さは短縮しても値は変わらない。

    Raises
    ------
    ValueError
        2 点が一致、端点がカメラの後ろ / 画像の外。

    手順: ``dist = |p1 - p0|``(object 座標のユークリッド距離、単位はメッシュ単位)を
    計算し、``p0``, ``p1`` を射影(``annotate3d_project`` と同じ慣習)。両端の画素を
    結ぶ線と両端の垂直な目盛(長さ ``tick`` px)、両端に半径 3 px の点を描き、線の
    中点から画面上側へ ``tick/2 + 4`` px 離した位置に
    ``label_fmt.format(dist) + " " + unit`` の文字箱を置く。

    引数:
    - ``p0``, ``p1``: object 座標 ``(3,)``(有限、一致は拒否)。
    - ``unit``: 文字列(空なら数値だけ)。``label_fmt``: ``str.format`` 書式(既定
      ``"{:.3g}"``)。単位換算はしない — メッシュが mm ならそのまま mm。
    - ``width`` [px] ``>= 0.5``、``tick`` [px] ``>= 0``、``font_size`` / ``box_alpha`` /
      ``text_color`` / ``font_path``: 文字箱の見た目。
    - ``depth``: 前方距離画像。両端とも隠れていれば線を破線に、隠れた端点の点を
      白抜き(ring)にする。``occlusion_tol``: ``[0, 1)``。

    返り値: 描画済みの新しい画像(float64 ``[0, 1]``)。

    エラーになる条件: ``|p1 - p0| < 1e-12`` / どちらかの端点が ``z <= 1e-9`` /
    **どちらかの端点が画像の外**(``in_image`` を両端に要求) / 姿勢・``K``・
    ``depth`` の不正 / 文字箱が収まらない。

    使いどころ: ``fit_sphere3`` の直径、``smallest_box3`` の辺、2 つの特徴点間の
    距離を図の上に示す。値そのものは描画前に ``np.linalg.norm(p1 - p0)`` と同じ。
    """
    a = A._prep(img)
    a0, a1 = _points3(p0, "p0")[0], _points3(p1, "p1")[0]
    dist = float(np.linalg.norm(a1 - a0))
    if dist < 1e-12:
        raise ValueError("p0 and p1 coincide — nothing to measure")
    tab = project_anchors(np.vstack([a0, a1]), pose, K, depth=depth, shape=a.shape[:2],
                          occlusion_tol=occlusion_tol)
    _need_front(tab, ("p0", "p1"))
    if not tab["in_image"].all():
        raise ValueError("a measured point projects outside the image")
    q0, q1 = _uv(tab, 0), _uv(tab, 1)
    w = A._num(width, "width", lo=0.5)
    t = A._num(tick, "tick", lo=0.0)
    hidden = depth is not None and bool(tab["hidden"].all())
    a = _bar_with_ticks(a, q0, q1, color, w, t, scheme, dash=_HIDDEN_DASH if hidden else None)
    for q, h in zip((q0, q1), tab["hidden"]):
        a = A._aa_disk(a, q, 3.0, color, scheme=scheme, ring=(1.5 if (depth is not None and h) else 0.0))
    dx, dy = q1[0] - q0[0], q1[1] - q0[1]
    nn = math.hypot(dx, dy)
    nx, ny = (-dy / nn, dx / nn) if nn > 1e-9 else (0.0, -1.0)
    if ny > 0:
        nx, ny = -nx, -ny
    mid = ((q0[0] + q1[0]) / 2.0 + nx * (t / 2.0 + 4), (q0[1] + q1[1]) / 2.0 + ny * (t / 2.0 + 4))
    text = f"{label_fmt.format(dist)} {unit}".rstrip()
    return A.text_box(a, text, mid, color=color, anchor=A._text_anchor_for_direction(nx, ny),
                      pad=3, font_size=font_size, min_font_size=min(9, int(font_size)), box_alpha=box_alpha, text_color=text_color,
                      font_path=font_path, scheme=scheme)
