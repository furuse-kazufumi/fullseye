"""S2 — differential test across backends (the honest-correctness gate).

Verifies the emitted backends reproduce the typed-IR reference on holdout inputs:

  Python backend : ALWAYS run. import gen_<problem>.py, apply pipeline() to each
                   holdout image, compare to ops.apply_genome(champion) -> max abs
                   diff. PASS if < --tol.
  C backend      : run ONLY if a C compiler is found AND every op is in the C
                   runtime. Compile imgops.c + gen_<problem>.c + a generated driver,
                   run on the same inputs, compare to Python. PASS if < --c-tol
                   (looser than --tol by design: float32 + kernel rounding).
                   Compiler discovery is shared with the algo tier
                   (algo_difftest.find_c_compiler: gcc/cc/clang on PATH, else
                   `python -m ziglang cc`). Otherwise SKIP with an honest reason.
                   A compile/run FAILURE of a backend that codegen declared
                   c_fully_supported is a gate failure, not a skip. A NaN/inf in
                   either output is a FAILURE (never folds to diff 0.0).

Writes difftest_<problem>.json + report line. Deterministic.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

import numpy as np

import ops
import problems
from algo_difftest import compiler_label, find_c_compiler

_DRIVER_C = r"""
#include "imgops.h"
#include <stdio.h>
#include <stdlib.h>
void pipeline(float* buf, int w, int h);
int main(int argc, char** argv) {
    FILE* fi = fopen(argv[1], "rb"); FILE* fo = fopen(argv[2], "wb");
    int n, w, h; fread(&n, 4, 1, fi); fread(&w, 4, 1, fi); fread(&h, 4, 1, fi);
    float* img = (float*)malloc(sizeof(float) * w * h);
    for (int k = 0; k < n; k++) { fread(img, 4, w*h, fi); pipeline(img, w, h); fwrite(img, 4, w*h, fo); }
    free(img); fclose(fi); fclose(fo); return 0;
}
"""


def _import_gen(path: Path):
    spec = importlib.util.spec_from_file_location("gen_pipeline", str(path))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _finite_maxdiff(ref, got) -> float:
    """``max|ref - got|`` over two numeric arrays, **inf** if any element of either is
    non-finite — so a NaN can never fold to 0.0 (``max(0.0, nan)`` is 0.0 in Python
    and ``np.max`` of a NaN array is NaN, which ``<`` tol then treats as pass/skip).
    Same fail-closed rule as ``algo_difftest._diff01``."""
    ref = np.asarray(ref, np.float64)
    got = np.asarray(got, np.float64)
    if ref.shape != got.shape:
        return float("inf")
    if ref.size == 0:
        return 0.0
    if not (np.isfinite(ref).all() and np.isfinite(got).all()):
        return float("inf")
    return float(np.max(np.abs(ref - got)))


def _maxdiff(ref, got):
    """Max abs difference between two pipeline outputs. Handles array (image/
    region) and scalar (feature) finals; a non-finite value on either side is
    **inf** (a gate FAILURE, never a silent pass). Returns nan only for non-numeric
    finals (a contour dict), which are recorded as non-comparable."""
    if isinstance(ref, np.ndarray) and isinstance(got, np.ndarray):
        return _finite_maxdiff(ref, got)
    try:
        return _finite_maxdiff(np.array([float(ref)]), np.array([float(got)]))
    except (TypeError, ValueError):
        return float("nan")


def _c_gate_ok(cb: dict, c_fully_supported: bool) -> bool:
    """C half of the gate, fail-closed: an emitted C backend that codegen declared
    fully supported but that does not compile/run is a FAILURE, not a neutral skip.
    Only the not-attempted cases (unsupported ops, no toolchain) stay neutral."""
    status = cb.get("status")
    if status == "ran":
        return bool(cb.get("pass"))
    if status == "compile_error":
        return not c_fully_supported
    return True


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--problem", default="edge")
    ap.add_argument("--workdir", default="out/worklog/imgevolve")
    ap.add_argument("--tol", type=float, default=1e-6)
    ap.add_argument("--c-tol", type=float, default=1e-3,
                    help="C-vs-Python tolerance (float32 + kernel rounding); independent of --tol")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()

    wd = Path(a.workdir)
    champ = json.loads((wd / f"champion_{a.problem}.json").read_text(encoding="utf-8"))
    info = json.loads((wd / f"codegen_{a.problem}.json").read_text(encoding="utf-8"))
    cfg = champ["config"]
    prob = problems.PROBLEMS[a.problem]
    ho = prob.make(cfg["n_holdout"], cfg["size"], cfg["seed"] + 10_000)
    inp = ho["input"]
    genome = np.asarray(champ["genome"], np.float64)

    # --- Python backend vs IR reference ------------------------------------- #
    gen = _import_gen(wd / f"gen_{a.problem}.py")
    py_max, n_noncomparable = 0.0, 0
    for i in range(len(inp)):
        ref = ops.run_genome(genome, inp[i])            # raw runtime output (NOT the coercing apply_genome)
        got = gen.pipeline(inp[i].astype(np.float64))    # RAW — re-clipping here would hide a codegen clip bug
        d = _maxdiff(ref, got)
        if np.isnan(d):
            n_noncomparable += 1
        else:
            py_max = max(py_max, d)
    n_comparable = len(inp) - n_noncomparable
    py_pass = n_comparable > 0 and py_max < a.tol

    result = {"problem": a.problem, "python_max_abs_diff": py_max, "python_pass": py_pass,
              "tol": a.tol, "c_tol": a.c_tol, "n_noncomparable_final": n_noncomparable,
              "c_backend": None}

    # --- C backend (compile-gated) ------------------------------------------ #
    # Same discovery as the algo tier (gcc/cc/clang on PATH, else `python -m ziglang
    # cc`): the old gcc/cc/clang-only lookup made this gate silently "skipped" on every
    # machine whose only compiler is ziglang, so the image C backend was never run here.
    cc = find_c_compiler()
    if not info["c_fully_supported"]:
        result["c_backend"] = {"status": "skipped", "reason": "champion uses ops not yet in the C runtime"}
    elif not cc:
        result["c_backend"] = {"status": "skipped",
                               "reason": "no C toolchain (gcc/clang or 'pip install ziglang') in this environment"}
    else:
        try:
            (wd / "driver.c").write_text(_DRIVER_C, encoding="utf-8")
            here = Path(__file__).resolve().parent
            exe = wd / ("cbackend.exe" if sys.platform == "win32" else "cbackend")
            subprocess.run(list(cc) + ["-O2", "-I", str(here), "-I", str(wd),
                            str(here / "imgops.c"), str(wd / f"gen_{a.problem}.c"), str(wd / "driver.c"),
                            "-lm", "-o", str(exe)], check=True, capture_output=True, text=True)
            n, sz = len(inp), cfg["size"]
            fin, fout = wd / "in.bin", wd / "out.bin"
            with open(fin, "wb") as f:
                np.array([n, sz, sz], np.int32).tofile(f)
                inp.astype(np.float32).tofile(f)
            subprocess.run([str(exe), str(fin), str(fout)], check=True, capture_output=True)
            cout = np.fromfile(fout, np.float32).reshape(n, sz, sz)
            c_max = 0.0
            for i in range(n):
                got = np.asarray(gen.pipeline(inp[i].astype(np.float64)), np.float64)
                # fail-closed: a NaN/inf in either output is inf (the old
                # max(0.0, nan) fold silently kept 0.0 and PASSED a NaN C output)
                c_max = max(c_max, _finite_maxdiff(got, cout[i]))
            result["c_backend"] = {"status": "ran", "c_vs_python_max_abs_diff": c_max,
                                   "pass": c_max < a.c_tol,  # --c-tol: float32 + kernel rounding
                                   "compiler": compiler_label(cc)}
        except subprocess.CalledProcessError as e:
            result["c_backend"] = {"status": "compile_error", "detail": (e.stderr or str(e))[-400:]}

    (wd / f"difftest_{a.problem}.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    if a.out:
        p = a.out if a.out.endswith(".json") else a.out + ".json"
        Path(p).write_text(json.dumps(result, indent=2), encoding="utf-8")
    cb = result["c_backend"]
    print(f"[difftest:{a.problem}] python diff {py_max:.2e} (pass={py_pass}) | "
          f"C: {cb.get('status')}" + (f" reason={cb.get('reason')}" if cb.get("reason") else ""))
    # Fail the gate if the C backend ran and disagreed, or failed to build at all.
    c_ok = _c_gate_ok(cb, bool(info["c_fully_supported"]))
    return 0 if (py_pass and c_ok) else 1


if __name__ == "__main__":
    raise SystemExit(main())
