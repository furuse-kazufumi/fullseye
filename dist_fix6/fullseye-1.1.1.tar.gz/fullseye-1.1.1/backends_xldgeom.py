"""XLD contour geometry tier — point-set / polyline operators (registry shape).

Adds a batch of genuine HALCON *XLD* geometry operators that consume the typed
``contour`` sort and produce either a scalar ``feature`` (moments, area,
eccentricity, orientation, axis ratio, bbox ratio, regression residual) or a
transformed ``contour`` (length clipping, Douglas-Peucker polygon simplification,
central-window cropping).

Contour data model (as threaded by the registry)::

    {"shape": (H, W), "cs": [ Nx2 float64 arrays of (row, col) points, ... ]}

Every operator is a real numerical algorithm — the covariance / moment
computations follow the standard 2-D central-moment definitions, the polygon
area is the shoelace formula, the polyline simplification is genuine
Ramer-Douglas-Peucker recursion. `build()` returns the Op list; each op is a
module-level function so its semantics can be exercised directly by tests.

Honesty note: three ops (xg_clip_contours = length-band filter, xg_crop_contours
= central-window point crop, xg_regress_contours = TLS perpendicular-residual RMS)
are genuine algorithms but do NOT reproduce the real HALCON `clip_contours_xld` /
`crop_contours_xld` / `regress_contours_xld` semantics (rectangle-clip / region-crop
/ regression-polyline), so they carry NO `halcon` name — they add op capability, not
a coverage claim (feedback_no_false_reporting). The other seven (`gen_polygons_xld`,
`moments_points_xld`, `area_center_points_xld`, `eccentricity_points_xld`,
`orientation_points_xld`, `elliptic_axis_points_xld`, `height_width_ratio_xld`) are
faithful genuine analogs and keep their names. (`moments_points_xld` /
`area_center_points_xld` reduce their multi-value HALCON output to the single scalar
the feature sort allows — the same convention as the existing `moments_xld` /
`area_center_xld` core ops.)

    py -3.11 backends_xldgeom.py    # self-report: ops + functional gate

stdlib + numpy only. Deterministic. Fail-soft on empty/degenerate contours.
"""
from __future__ import annotations

import math

import numpy as np

CATEGORY = "xldgeom"


# --------------------------------------------------------------------------- #
# contour-dict access helpers (fail-soft: never raise on odd input)
# --------------------------------------------------------------------------- #
def _cs(v):
    """Return the list of valid Nx2 float64 point arrays in a contour dict."""
    if not isinstance(v, dict):
        return []
    raw = v.get("cs") or []
    out = []
    for c in raw:
        try:
            arr = np.asarray(c, np.float64)
        except (ValueError, TypeError):
            continue  # non-numeric element -> skip (fail-soft contract)
        if arr.ndim == 2 and arr.shape[0] > 0 and arr.shape[1] == 2 and np.all(np.isfinite(arr)):
            out.append(arr)
    return out


def _shape(v):
    """Return (H, W) from a contour dict, or (0, 0) if absent/malformed."""
    if isinstance(v, dict):
        s = v.get("shape")
        try:
            if s is not None and len(s) == 2:
                return int(s[0]), int(s[1])
        except (TypeError, ValueError):
            pass
    return 0, 0


def _allpts(cs):
    """Concatenate every contour's points into one (N, 2) array (or empty)."""
    if not cs:
        return np.zeros((0, 2), np.float64)
    return np.concatenate(cs, axis=0)


def _openpts(cs):
    """Like ``_allpts`` but drops the duplicated closing point of closed contours
    (first == last), so point statistics (moments / PCA / bbox) are not biased by a
    point counted twice.  The shoelace area does not use this (the closing point is
    harmless there), and contour->contour ops keep it."""
    out = []
    for c in cs:
        if len(c) > 2 and np.allclose(c[0], c[-1]):
            c = c[:-1]
        out.append(c)
    return _allpts(out)


def _var_floor(pts):
    """「全点が同一」とみなす分散(長さ²)の床: 座標の大きさ² の 1e-24 倍(丸め屑だけ)。

    ★1.0 前の修正 2026-11-05 abs-floor: 以前は固有値・幅・長さを固定の 1e-12 と比べていて、座標 1e-6 の輪郭では楕円の
    離心率が 0、軸比が 1e6 になった(固有値が 1e-12 の桁)。
    """
    if len(pts) == 0:
        return 0.0
    return (1e-12 * float(np.abs(pts).max())) ** 2


def _pca(pts):
    """Population covariance eigen-decomposition of an (N,2) (row,col) point set.

    Returns (w, V) with ``w`` ascending eigenvalues (w[0] <= w[1]) and ``V`` the
    matching eigenvector columns in (row, col) space, or ``None`` if < 2 points.
    """
    if len(pts) < 2:
        return None
    c = pts - pts.mean(axis=0)
    cov = (c.T @ c) / len(pts)
    w, vecs = np.linalg.eigh(cov)  # ascending eigenvalues
    return w, vecs


def _plen(c):
    """Open-polyline length of an (N,2) point array."""
    if len(c) < 2:
        return 0.0
    d = np.diff(c, axis=0)
    return float(np.sum(np.hypot(d[:, 0], d[:, 1])))


def _fin(x, default=0.0):
    """Coerce to a finite np.float64 scalar."""
    xf = float(x)
    return np.float64(xf if math.isfinite(xf) else default)


# --------------------------------------------------------------------------- #
# contour -> feature
# --------------------------------------------------------------------------- #
def xg_moments(v, a, b):
    """Normalized 2nd central moment of the point set: mu20 + mu02.

    Each ``mu`` is the per-point mean of the squared centred coordinate
    (HALCON's moments_points_xld normalizes central moments by point count).
    The trace mu20+mu02 is a single rotation-invariant scalar.
    """
    pts = _openpts(_cs(v))
    if len(pts) < 1:
        return np.float64(0.0)
    c = pts - pts.mean(axis=0)
    mu = np.mean(c ** 2, axis=0)  # [mu02 (rows), mu20 (cols)]
    return _fin(mu[0] + mu[1])


def xg_area_center(v, a, b):
    """Polygon area of the contour(s) via the shoelace formula (summed abs).

    輪郭辞書 ``{"shape": (H, W), "cs": [Nx2 の (row, col) 点列, ...]}`` の各輪郭を
    多角形とみなし、靴ひも公式 ``0.5*|Σ(x_i*y_{i+1} - x_{i+1}*y_i)|`` で面積を
    求めて全輪郭の合計を返す。点が 3 個未満の輪郭は 0 として無視。``a``, ``b`` は
    未使用。

    返り値は ``numpy.float64``(単位は画素²、正規化なし)。輪郭が無い・辞書で
    ない・非有限値を含む輪郭は読み飛ばされ、合計に寄与しない(空なら 0.0)。
    開いた輪郭でも「最後の点と最初の点を結んで閉じた多角形」の面積になる点に
    注意(直線状の開輪郭では 0、折れ線の開輪郭でも非零になる)。絶対値を取る
    ので点列の向き(時計回り/反時計回り)は結果に影響しない。自己交差する輪郭では
    交差で符号が打ち消しあい、真の面積より小さく出る。名前に反して重心は
    返さない(面積のみ)。同じ点集合の 2 次モーメントは ``xg_moments``、bbox の
    縦横比は ``xg_height_width_ratio``。
    """
    total = 0.0
    for c in _cs(v):
        if len(c) >= 3:
            y = c[:, 0]
            x = c[:, 1]
            total += 0.5 * abs(float(np.dot(x, np.roll(y, -1)) - np.dot(np.roll(x, -1), y)))
    return _fin(total)


def xg_eccentricity(v, a, b):
    """Eccentricity sqrt(1 - lambda_min/lambda_max) from the point covariance.

    輪郭辞書 ``{"shape", "cs"}`` の全輪郭の点を 1 つの点集合にまとめ、その
    (row, col) 座標の母共分散行列の固有値 ``λ_min <= λ_max`` から離心率
    ``e = sqrt(1 - λ_min/λ_max)`` を返す。閉輪郭の重複した終点(先頭と同じ点)は
    数えない。``a``, ``b`` は未使用。

    返り値は ``numpy.float64`` で [0, 1]。真円・正方形など等方な点配置で 0、
    一直線上の点(``λ_min = 0``)で 1。点が 2 個未満、または全点が同一(``λ_max`` が
    座標の大きさ² の 1e-24 倍以下 = 丸め屑)なら 0.0。輪郭が複数あればそれらをまとめた分布の離心率になり、
    個々の輪郭の形ではなく配置の広がりも混ざる(輪郭ごとに評価したいなら先に
    ``select_contours_xld`` などで 1 本に絞る)。輪郭点の密度に依存する(点が
    密な部分が重く効く)点は面積ベースの指標と異なる。軸比そのものは
    ``xg_elliptic_axis``、主軸の向きは ``xg_orientation``。
    """
    pts = _openpts(_cs(v))
    r = _pca(pts)
    if r is None:
        return np.float64(0.0)
    w, _ = r
    lo, hi = float(w[0]), float(w[1])
    if hi <= _var_floor(pts):
        return np.float64(0.0)
    e = math.sqrt(max(0.0, 1.0 - lo / hi))
    return _fin(min(1.0, e))


def xg_orientation(v, a, b):
    """Principal-axis orientation in degrees, folded to [0,180) and /180 scaled.

    Angle is measured from the +x (column) axis; multiply the result by 180 to
    recover degrees. Line orientation is defined mod 180, so a line at theta and
    theta+180 map to the same value.

    Direction (2026-11-03, stated explicitly): the angle is ``atan2(d_row, d_col)`` in
    image coordinates with rows pointing DOWN, i.e. it turns **clockwise on screen**.
    A line turned theta counter-clockwise on screen returns ``(180 - theta) / 180``
    (a line through (0, 0) and (10, 10) — down-right on screen — returns 0.25). This
    is the opposite sense to HALCON (``orientation_points_xld`` / ``orientation_xld``
    / ``orientation_region`` measure counter-clockwise on screen, "mathematically
    positive"); ``orientation_xld`` and ``orientation_region`` here follow HALCON, so
    ``xg_orientation = (1 - orientation_xld) mod 1`` on the same contour.

    Discontinuity (inherent, documented): a line orientation lives on a circle of
    180 degrees, and this op unrolls it to [0, 1), so the wrap sits at HORIZONTAL —
    a line tilted +0.001 deg returns ~0.0 while -0.001 deg returns ~0.9999. Any
    single-scalar unrolling has a seam somewhere; callers that need continuity
    across horizontal should compare orientations on the doubled angle
    (cos 2*theta, sin 2*theta) or take the difference mod 1. The closing point of a
    closed contour is not double-counted in the PCA.
    """
    r = _pca(_openpts(_cs(v)))
    if r is None:
        return np.float64(0.0)
    _, vecs = r
    vy, vx = float(vecs[0, 1]), float(vecs[1, 1])  # major-axis eigenvector (row,col)
    ang = math.degrees(math.atan2(vy, vx)) % 180.0
    return _fin(ang / 180.0)


def xg_elliptic_axis(v, a, b):
    """Major/minor axis ratio sqrt(lambda_max/lambda_min) of the point set.

    全輪郭の点(閉輪郭の重複終点は除く)の (row, col) 共分散行列の固有値から、
    等価楕円の長軸/短軸比 ``sqrt(λ_max/λ_min)`` を返す。``a``, ``b`` は未使用。

    返り値は ``numpy.float64`` で 1 以上。等方な点配置で 1、細長いほど大きい。
    ``λ_min <= 1e-12·λ_max``(全点が一直線。比が上限 1e6 に届く)では 1e6、全点が同一
    (``λ_max`` が座標の大きさ² の 1e-24 倍以下)なら 1.0。それ以外でも上限 1e6 で打ち切る。点が 2 個未満なら 1.0。
    非有限になった場合も 1.0 に落とす。[0,1] に正規化されていない量なので、
    他の特徴量と並べる際はスケールに注意(1e6 の外れ値が出うる)。
    ``xg_eccentricity`` は同じ固有値を [0,1] に写した版で、こちらは比を直接
    見たいときに使う。軸ではなく外接矩形の縦横比なら ``xg_height_width_ratio``
    (こちらは向きに依存する)。
    """
    pts = _openpts(_cs(v))
    r = _pca(pts)
    if r is None:
        return np.float64(1.0)
    w, _ = r
    lo, hi = float(w[0]), float(w[1])
    if hi <= _var_floor(pts):
        return np.float64(1.0)
    if lo <= 1e-12 * hi:
        return np.float64(1e6)
    return _fin(min(1e6, math.sqrt(hi / lo)), default=1.0)


def xg_height_width_ratio(v, a, b):
    """Axis-aligned bounding-box height/width ratio of the point set.

    全輪郭の点(閉輪郭の重複終点は除く)をまとめ、行方向の広がり
    ``h = max(row) - min(row)`` と列方向の広がり ``w = max(col) - min(col)`` の比
    ``h / w`` を返す。``a``, ``b`` は未使用。

    返り値は ``numpy.float64``。点が無ければ 0.0。``w`` が座標の大きさの 1e-12 倍以下
    (全点が同じ列=縦一直線)では ``h`` がそれより大きければ 1e6、そうでなければ 0.0。
    上限は 1e6。
    軸並行の bbox なので回転に不変ではない(45° 傾いた細長い輪郭は 1 に近づく)。
    回転不変な細長さは ``xg_elliptic_axis`` / ``xg_eccentricity`` を使う。
    ``h``, ``w`` は点座標の範囲(画素中心間の距離)で、画素数ベースの幅より 1 小さい。
    複数輪郭があれば全体を囲む 1 つの bbox の比になる。
    """
    pts = _openpts(_cs(v))
    if len(pts) < 1:
        return np.float64(0.0)
    h = float(np.ptp(pts[:, 0]))
    w = float(np.ptp(pts[:, 1]))
    tiny = 1e-12 * float(np.abs(pts).max())
    if w <= tiny:
        return np.float64(1e6 if h > tiny else 0.0)
    return _fin(min(1e6, h / w))


def xg_regress_contours(v, a, b):
    """Total-least-squares line residual RMS = sqrt(minor covariance eigenvalue).

    The perpendicular (orthogonal-regression) residual variance of a point set
    equals its smallest covariance eigenvalue; its square root is the RMS
    perpendicular distance to the best-fit line.
    """
    r = _pca(_openpts(_cs(v)))
    if r is None:
        return np.float64(0.0)
    w, _ = r
    return _fin(math.sqrt(max(0.0, float(w[0]))))


# --------------------------------------------------------------------------- #
# contour -> contour
# --------------------------------------------------------------------------- #
def xg_clip_contours(v, a, b):
    """Drop contours whose polyline length is below a * max-length (a in [0,1]).

    各輪郭の折れ線長(隣接点間のユークリッド距離の和)を求め、最長の輪郭の長さ
    ``L_max`` に対して ``length >= a * L_max`` を満たす輪郭だけ残す。``a`` は
    [0,1] に clip され、``a=0`` で全輪郭を残し、``a=1`` で最長の輪郭(同長なら
    複数)だけ残す。``b`` は未使用。

    返り値は入力と同じ ``{"shape", "cs"}`` 形式の輪郭辞書(点配列はコピー)。
    輪郭が無ければ ``cs`` は空。``L_max = 0``(全輪郭が 1 点)なら全輪郭を
    そのまま返す。しきい値が画像サイズでなく「最長輪郭に対する相対値」なので、
    最長の輪郭が変わると選別基準も動く(点数の絶対値で選ぶなら
    ``select_contours_xld``)。名前から想像される矩形での切り取りではなく、
    長さによる選別である(矩形で切るのは ``xg_crop_contours`` / ``hx_clip_contours``)。
    閉輪郭の重複終点も長さに含むが、0 長の辺なので影響しない。
    """
    cs = _cs(v)
    shape = _shape(v)
    if not cs:
        return {"shape": shape, "cs": []}
    lens = [_plen(c) for c in cs]
    lmax = max(lens)
    if not lmax > 0.0:
        return {"shape": shape, "cs": [c.copy() for c in cs]}
    lo = float(np.clip(a, 0.0, 1.0)) * lmax
    out = [c.copy() for c, length in zip(cs, lens) if length >= lo]
    return {"shape": shape, "cs": out}


def _max_perp(pts, i, j):
    """Farthest interior point index and its perpendicular distance to seg i-j."""
    if j <= i + 1:
        return -1.0, i
    p = pts[i]
    seg = pts[j] - p
    seg_len = math.hypot(seg[0], seg[1])
    w = pts[i + 1:j] - p
    if seg_len == 0.0:
        d = np.hypot(w[:, 0], w[:, 1])
    else:
        d = np.abs(seg[0] * w[:, 1] - seg[1] * w[:, 0]) / seg_len
    k = int(np.argmax(d))
    return float(d[k]), i + 1 + k


def _dp(pts, eps):
    """Ramer-Douglas-Peucker simplification of an (N,2) polyline."""
    n = len(pts)
    if n < 3:
        return pts.copy()
    keep = np.zeros(n, dtype=bool)
    keep[0] = keep[-1] = True
    stack = [(0, n - 1)]
    while stack:
        i, j = stack.pop()
        d, idx = _max_perp(pts, i, j)
        if d > eps:
            keep[idx] = True
            stack.append((i, idx))
            stack.append((idx, j))
    return pts[keep].copy()


def xg_gen_polygons(v, a, b):
    """Douglas-Peucker polyline simplification; eps = a * contour bbox diagonal.

    各輪郭を Ramer-Douglas-Peucker 法で間引いて頂点数の少ない折れ線(多角形)に
    する。始点と終点は必ず残し、区間の弦から最も離れた点の距離が ``eps`` を
    超えればその点を採用して再帰的に分割する。``eps`` は輪郭ごとに、その輪郭の
    bbox の対角長 ``hypot(Δrow, Δcol)`` に ``a``([0,1] に clip)を掛けた値。
    ``a=0`` で ``eps=0``(弦上に完全に乗る点だけ落ちる)、``a`` を上げるほど粗く
    なり、``a=1`` では両端の 2 点だけになる。``b`` は未使用。

    返り値は ``{"shape", "cs"}`` の輪郭辞書。点が 3 個未満の輪郭はコピーのまま。
    閉輪郭(先頭=末尾)は始点と終点が同じ点なので、``a`` が大きいと 2 点(同一点)に
    退化し、面積や向きの特徴量が 0 になる。閉輪郭の形を保ちたい場合は ``a`` を
    小さめにする(実測では半径 5〜8 の楕円 101 点が ``a=0.05`` で 9 点)。
    間引きは元の点の部分集合を返し、新しい点は作らない。後段の ``xg_area_center``
    や ``xg_regress_contours`` の計算量を減らす前処理、折れ線の角(頂点)検出に。
    """
    cs = _cs(v)
    shape = _shape(v)
    out = []
    for c in cs:
        if len(c) < 3:
            out.append(c.copy())
            continue
        diag = math.hypot(float(np.ptp(c[:, 0])), float(np.ptp(c[:, 1])))
        eps = float(np.clip(a, 0.0, 1.0)) * diag
        out.append(_dp(c, eps))
    return {"shape": shape, "cs": out}


def xg_crop_contours(v, a, b):
    """Keep only contour points inside the central a-fraction window of the shape.

    画像中心に置いた、高さ ``a*H``、幅 ``a*W`` の矩形窓の内側にある輪郭点だけを
    残す(``a`` は [0,1] に clip、``b`` は未使用)。窓は行 ``[(0.5-a/2)H, (0.5+a/2)H]``、
    列 ``[(0.5-a/2)W, (0.5+a/2)W]`` の閉区間。``H, W`` は辞書の ``shape`` から取り、
    無ければ全点の最大座標+1 で代用する。

    返り値は ``{"shape": (H, W), "cs": [...]}``。窓内に 1 点も残らない輪郭は捨て、
    ``a=0`` では中心線上に正確に乗る点しか残らないためほぼ空、``a=1`` で全点が
    残る。

    注意: 窓に切られた輪郭は分割されない。残った点をそのまま 1 本の折れ線として
    繋ぐので、輪郭が窓を出入りするたびに「窓の縁を飛び越える辺」が生まれ、
    ``xg_area_center`` の面積や折れ線長が実際より大きく出る。切り口を正しく
    扱いたいなら、領域の段階で ``r3_clip_region`` を掛けてから輪郭を取り直す。
    座標は (row, col)。長さで輪郭ごと選別するのは ``xg_clip_contours``。
    """
    cs = _cs(v)
    H, W = _shape(v)
    if H <= 0 or W <= 0:
        pts = _allpts(cs)
        if len(pts) == 0:
            return {"shape": (H, W), "cs": []}
        H = int(math.ceil(float(pts[:, 0].max()))) + 1
        W = int(math.ceil(float(pts[:, 1].max()))) + 1
    half = float(np.clip(a, 0.0, 1.0)) / 2.0
    r_lo, r_hi = (0.5 - half) * H, (0.5 + half) * H
    c_lo, c_hi = (0.5 - half) * W, (0.5 + half) * W
    out = []
    for c in cs:
        m = (c[:, 0] >= r_lo) & (c[:, 0] <= r_hi) & (c[:, 1] >= c_lo) & (c[:, 1] <= c_hi)
        if m.any():
            out.append(c[m].copy())
    return {"shape": (H, W), "cs": out}


# --------------------------------------------------------------------------- #
# registry wiring
# --------------------------------------------------------------------------- #
def build(Op, IMAGE, REGION, FEATURE, CONTOUR, norm, binm):
    """Return the XLD contour-geometry Op list (all in_sort=CONTOUR)."""
    defs = [
        ("xg_moments", "moments_points_xld", CONTOUR, FEATURE, xg_moments),
        ("xg_area_center", "area_center_points_xld", CONTOUR, FEATURE, xg_area_center),
        ("xg_eccentricity", "eccentricity_points_xld", CONTOUR, FEATURE, xg_eccentricity),
        ("xg_orientation", "orientation_points_xld", CONTOUR, FEATURE, xg_orientation),
        ("xg_elliptic_axis", "elliptic_axis_points_xld", CONTOUR, FEATURE, xg_elliptic_axis),
        ("xg_height_width_ratio", "height_width_ratio_xld", CONTOUR, FEATURE, xg_height_width_ratio),
        # These three reuse XLD-family NAMES but implement different semantics than
        # the real HALCON operators (length-band filter / central-window crop /
        # TLS residual RMS vs HALCON's rectangle-clip / region-crop /
        # regression-polyline). They are genuine ops but must NOT claim those
        # HALCON names as coverage (feedback_no_false_reporting) — halcon left "".
        ("xg_regress_contours", "", CONTOUR, FEATURE, xg_regress_contours),
        ("xg_clip_contours", "", CONTOUR, CONTOUR, xg_clip_contours),
        ("xg_gen_polygons", "gen_polygons_xld", CONTOUR, CONTOUR, xg_gen_polygons),
        ("xg_crop_contours", "", CONTOUR, CONTOUR, xg_crop_contours),
    ]
    return [Op(name, CATEGORY, halcon, isort, osort, fn) for (name, halcon, isort, osort, fn) in defs]


if __name__ == "__main__":
    class _Op:
        def __init__(self, *a):
            self.name, self.category, self.halcon = a[0], a[1], a[2]
            self.in_sort, self.out_sort, self.fn = a[3], a[4], a[5]

    ops = build(_Op, "image", "region", "feature", "contour", lambda x: x, lambda v: v > 0.5)
    print(f"xldgeom tier: {len(ops)} ops")
    for op in ops:
        print(f"  {op.name:<24} -> {op.out_sort:<7}  ({op.halcon})")
