"""device.py — device control: digital I/O and closing the vision loop to the line.

The control half HALCON leaves to a separate PLC/PC. A Fullseye pipeline decides
pass/fail (or a position); ``device.py`` turns that decision into an action on the
cell — set an output, pulse an ejector, wait for a trigger — over the transports in
:mod:`comm` (Modbus coils) or embedded-Linux GPIO.

    import fullseye
    io = fullseye.DigitalIO("modbus", host="127.0.0.1", port=1502)   # a PLC's coils
    ok = eng.run(frame).mean() > 0.5          # some inspection verdict
    fullseye.signal_result(io, ok)            # drive PASS / FAIL outputs
    fullseye.pulse(io, pin=3, ms=50)          # kick the reject ejector

Backends: ``"memory"`` (in-process, for tests/dev), ``"modbus"`` (PLC coils via the
built-in Modbus-TCP client), ``"gpio"`` (Raspberry Pi / Jetson / SBC — optional,
needs ``periphery`` or ``RPi.GPIO`` or ``gpiod``).

:func:`capabilities` is the menu of drivers (I-O, servos, robots, ROS) and
:func:`open_driver` is the door: it opens the ones this install can drive and,
for the rest, names the exact SDK to install — the same contract
:func:`comm.open_channel` gives the protocol catalogue.
"""
from __future__ import annotations

import time

__all__ = ["DigitalIO", "pulse", "signal_result", "signal_verdict", "wait_input",
           "capabilities", "drivers", "open_driver", "register_driver",
           "unregister_driver",
           "DeviceError"]

class DeviceError(RuntimeError):
    """A device / driver error (the twin of :class:`comm.CommError`).

    Subclasses :class:`RuntimeError`, so code that already caught ``RuntimeError``
    around :class:`DigitalIO` keeps working.
    """


#: Default one-hot coil map for the 4-state Verdict -> PLC handshake.
_VERDICT_COILS = {"ok": 0, "ng": 1, "error": 2, "timeout": 3}

# Device / actuator catalogue (native DigitalIO backends + optional Physical-AI
# & motion-control SDKs). (name, module-to-probe, pip, kind, family, one-line desc)
_DRIVERS = [
    ("io-memory", None, None, "native", "io", "in-process digital I/O (tests / dry-run)"),
    ("io-modbus", None, None, "native", "io", "digital I/O over Modbus coils (built-in)"),
    ("gpio", "periphery", "python-periphery", "optional", "io",
     "SBC GPIO — Raspberry Pi / Jetson (also RPi.GPIO / gpiod)"),
    ("dynamixel", "dynamixel_sdk", "dynamixel-sdk", "optional", "servo", "Robotis Dynamixel servos"),
    ("feetech", "scservo_sdk", "feetech-servo-sdk", "optional", "servo", "Feetech STS/SCS servos"),
    ("canopen", "canopen", "canopen", "optional", "motion", "CANopen CiA-402 motion drives"),
    ("ur-rtde", "rtde_control", "ur_rtde", "optional", "robot", "Universal Robots RTDE / URScript"),
    ("robotiq", "pyRobotiqGripper", "pyRobotiqGripper", "optional", "gripper", "Robotiq 2F / Hand-E grippers"),
    ("xarm", "xarm", "xArm-Python-SDK", "optional", "robot", "UFACTORY xArm / Lite6 / 850"),
    ("ros", "rclpy", "rclpy", "optional", "middleware", "ROS 2 node bridge (rclpy)"),
    ("franka", "panda_py", "panda-python", "scaffold", "robot", "Franka Panda / FR3 (libfranka + RT kernel)"),
    ("kinova", "kortex_api", None, "scaffold", "robot", "Kinova Gen3 (off-PyPI kortex wheel)"),
]


#: ★**``available`` は「SDK が入っている」であって「Fullseye から開ける」ではない。**
#: 2026-09-25 まで名簿はこの 2 つを 1 つの欄で答えていた —— `dynamixel_sdk` を入れた
#: 機械で ``available`` は True になるのに、`open_driver("dynamixel")` は「その SDK を
#: 直接使え」と断る。読んだ人は「対応済み」と受け取る。
#: ``implemented`` は**環境に依らない**(この版に一級のアダプタが在るか)ので、表にも
#: 書けるし、どの機械でも同じ門で見られる。「いま開けるか」は ``implemented and available``。
#: ★欄の名前は自分で決めていない —— **`acquire` は既にこの区別を持っていた**
#: (`implemented` = opener が在る / `available` = SDK が在る、「the two are
#: different questions」と註まで在る)。同じ問いに 3 層が別々の語で答えると、
#: 読む側は毎回学び直す。**先に正しかった層の語に合わせる。**
def capabilities() -> list:
    """Device drivers: ``{name, kind, family, implemented, available, pip, desc}``.

    ``implemented`` = Fullseye itself can open it (:func:`open_driver` returns a driver);
    ``available`` = the SDK is importable here. They are different questions: an
    installed SDK with no Fullseye adapter is reachable, but not *through* Fullseye.
    Native backends (memory / Modbus coils) are both. See :func:`open_driver`.
    """
    import importlib.util

    def _importable(mod):
        try:
            return mod is not None and importlib.util.find_spec(mod) is not None
        except Exception:
            return False

    out = []
    for name, module, pip, kind, family, desc in _DRIVERS:
        if name in _REGISTERED:      # 差し替えられた行は登録側の申告で答える
            continue
        avail = (kind == "native") or (_importable(module) if module else False)
        out.append({"name": name, "kind": kind, "family": family,
                    "implemented": name in _OPENABLE,
                    "available": bool(avail), "pip": pip, "desc": desc})
    for name in sorted(_REGISTERED):
        e = _REGISTERED[name]
        avail = True if e["native"] else (_importable(e["probe"]) if e["probe"] else False)
        out.append({"name": name, "kind": e["kind"], "family": e["family"],
                    "implemented": True,
                    "available": bool(avail), "pip": e["pip"], "desc": e["desc"]})
    return sorted(out, key=lambda r: r["name"])


#: ★**名簿の綴りと構築子の綴りが違っていた。** 名簿(``capabilities()``)は
#: ``io-modbus`` と名乗るのに、構築子は ``DigitalIO("modbus")`` を取る ——
#: つまり**表を読んでそのまま渡すと ``ValueError``** になっていた。名簿を
#: 印刷しておきながら、その綴りで呼べないのは名簿の側の不備である。
_OPENABLE = {"io-memory": "memory", "io-modbus": "modbus", "gpio": "gpio"}

_BY_NAME = {d[0]: d for d in _DRIVERS}

#: 利用者が :func:`register_driver` で足したアダプタ(name -> エントリ)。
#: 同名なら同梱の行より**こちらが勝つ**(自分の装置に合わせて差し替えられる)。
_REGISTERED: dict = {}


def register_driver(name: str, factory, native: bool = False, pip=None, desc: str = "",
                    kind=None, probe=None, family: str = "io") -> None:
    """Register your own device driver under *name*; ``factory(**opts)`` opens it.

    The twin of :func:`comm.register`, with the same words: *native* = no external
    dependency; *pip* = the package an optional adapter needs; *kind* ∈
    {"native","optional","scaffold"} (defaults from *native*); *probe* = the import
    name used to report availability; *family* groups the row in
    :func:`capabilities` (io / servo / motion / robot / gripper / middleware).

        fullseye.register_driver("my-plc", lambda **o: MyPlc(**o), native=True,
                                 desc="in-house PLC over its own protocol")
        io = fullseye.open_driver("my-plc")

    Registering a name the catalogue already carries **replaces** it — that is how
    you turn a cataloged-but-not-implemented driver (``dynamixel``, ``ur-rtde``, …)
    into one this install can open, without waiting for a first-class adapter.
    """
    if not callable(factory):
        raise TypeError("register_driver(%r): factory must be callable, got %r"
                        % (name, type(factory).__name__))
    if kind is None:
        kind = "native" if native else "optional"
    _REGISTERED[name] = {"factory": factory, "native": bool(native), "pip": pip,
                         "desc": desc, "kind": kind, "probe": probe, "family": family}


def unregister_driver(name: str) -> bool:
    """Remove a driver added by :func:`register_driver`; ``True`` if one was removed.

    The shipped catalogue cannot be removed this way — ``unregister_driver`` only
    undoes *your* registrations, so a stray call can never make a documented driver
    vanish. Unknown names return ``False`` rather than raising: undoing something
    that is not there is not an error.
    """
    return _REGISTERED.pop(name, None) is not None


def drivers() -> list:
    """All device driver names (see :func:`capabilities` for what each one needs)."""
    return sorted(set(_BY_NAME) | set(_REGISTERED))


#: ★**名簿に 12 載せて、扉が 3 つしか無かった**(2026-09-25)。``capabilities()``
#: は I-O・サーボ・ロボット・ROS を名乗るのに、開ける口が在ったのは
#: :class:`DigitalIO` の 3 backend だけで、残り 9 には入口が 1 つも無かった ——
#: 名簿を読んだ人が、そこから何かを始める方法が無い。隣の層(``comm``)は
#: 同じ問いに既に答えていたので、これは機能の不在ではなく**片側の入口だけが
#: 塞がれていた**型である。開けないものにも「何を入れればよいか」を返す。
def open_driver(name: str, **opts):
    """Open device driver *name*, or say exactly why this install cannot.

    ``open_driver("io-memory")`` / ``("io-modbus", host=..., port=...)`` /
    ``("gpio")`` return a :class:`DigitalIO`. Every other cataloged driver raises
    :class:`DeviceError` naming the SDK to install and how to reach it — never a
    bare ``KeyError``, because those drivers are on the menu :func:`capabilities`
    prints. An unknown *name* (not on the menu at all) raises ``KeyError``.

        io = fullseye.open_driver("io-memory")       # works out of the box
        fullseye.open_driver("ur-rtde")              # DeviceError: needs 'rtde_control'
    """
    if name in _REGISTERED:
        return _REGISTERED[name]["factory"](**opts)
    if name not in _BY_NAME:
        raise KeyError("unknown device driver %r; known: %s"
                       % (name, ", ".join(drivers())))
    backend = _OPENABLE.get(name)
    if backend is not None:
        return DigitalIO(backend, **opts)

    _n, module, pip, _kind, _family, desc = _BY_NAME[name]
    #: ★PyPI に無い SDK(ベンダ配布の wheel)は「pip install None」と言わせない。
    if not pip:
        raise DeviceError(
            "driver %r (%s) has no PyPI package: get the vendor %r SDK and drive it "
            "directly — see docs/CONNECTIVITY.md." % (name, desc, module))

    import importlib.util
    try:
        avail = module is not None and importlib.util.find_spec(module) is not None
    except Exception:
        avail = False
    if not avail:
        raise DeviceError("driver %r needs %r (pip install %s); or register your own "
                          "adapter with fullseye.register_driver(%r, factory)"
                          % (name, module, pip, name))
    raise DeviceError(
        "driver %r is cataloged and %r is installed — drive it with that SDK directly, "
        "or wrap it once and register it: fullseye.register_driver(%r, factory). "
        "See docs/CONNECTIVITY.md." % (name, module, name))


class DigitalIO:
    """A set of digital outputs/inputs addressed by integer *pin*.

    ``set(pin, on)`` / ``get(pin) -> bool`` / ``pulse(pin, ms)``. Backends:

    - ``"memory"`` — a dict, for tests and dry-runs (no hardware).
    - ``"modbus"`` — pins are Modbus coil addresses on a PLC (via :mod:`comm`).
    - ``"gpio"``   — GPIO lines on an SBC (optional: ``periphery`` / ``RPi.GPIO`` / ``gpiod``).
    """

    def __init__(self, backend="memory", **opts):
        self.backend = backend
        self.opts = opts
        self._state = {}                       # memory backend
        self._ch = None                        # modbus channel
        self._gpio = None                      # gpio handles {pin: line}
        self._open()

    def _open(self):
        if self.backend == "memory":
            self._state = dict(self.opts.get("initial", {}))
        elif self.backend == "modbus":
            import fullseye_comm as comm
            host = self.opts.get("host", "127.0.0.1")
            port = int(self.opts.get("port", 502))
            unit = int(self.opts.get("unit", 1))
            self._ch = comm.ModbusTcpChannel(host, port, unit=unit)
        elif self.backend == "gpio":
            self._open_gpio()
        else:
            raise ValueError("unknown DigitalIO backend %r" % (self.backend,))

    def _open_gpio(self):  # pragma: no cover - needs SBC hardware
        self._gpio = {}
        try:
            from periphery import GPIO  # noqa: F401
            self._gpio_kind = "periphery"
        except Exception:
            try:
                import RPi.GPIO as RG
                RG.setmode(RG.BCM)
                self._gpio_kind = "rpi"
                self._rpi = RG
            except Exception as e:
                raise DeviceError(
                    "driver 'gpio' needs one of: periphery / RPi.GPIO / gpiod "
                    "(pip install python-periphery): %s" % e)

    # ------------------------------------------------------------------- I/O --
    def set(self, pin: int, on: bool = True):
        """Drive output *pin* high/low. Returns self for chaining."""
        pin = int(pin)
        if self.backend == "memory":
            self._state[pin] = bool(on)
        elif self.backend == "modbus":
            self._ch.write("coil", pin, bool(on))
        elif self.backend == "gpio":  # pragma: no cover
            self._gpio_write(pin, on)
        return self

    def get(self, pin: int) -> bool:
        """Read input/output *pin*."""
        pin = int(pin)
        if self.backend == "memory":
            return bool(self._state.get(pin, False))
        if self.backend == "modbus":
            return bool(self._ch.read("coil", pin, 1)[0])
        if self.backend == "gpio":  # pragma: no cover
            return self._gpio_read(pin)
        return False

    def pulse(self, pin: int, ms: float = 50.0):
        """Set *pin* on, wait *ms*, set it off — a one-shot (eject / strobe / trigger)."""
        self.set(pin, True)
        time.sleep(max(0.0, float(ms)) / 1000.0)
        self.set(pin, False)
        return self

    def _gpio_write(self, pin, on):  # pragma: no cover
        if self._gpio_kind == "periphery":
            from periphery import GPIO
            line = self._gpio.get(pin) or self._gpio.setdefault(pin, GPIO(pin, "out"))
            line.write(bool(on))
        else:
            self._rpi.setup(pin, self._rpi.OUT)
            self._rpi.output(pin, bool(on))

    def _gpio_read(self, pin):  # pragma: no cover
        if self._gpio_kind == "periphery":
            from periphery import GPIO
            line = self._gpio.get(pin) or self._gpio.setdefault(pin, GPIO(pin, "in"))
            return bool(line.read())
        self._rpi.setup(pin, self._rpi.IN)
        return bool(self._rpi.input(pin))

    def close(self):
        if self.backend == "modbus" and self._ch is not None:
            self._ch.close(); self._ch = None
        elif self.backend == "gpio" and self._gpio:  # pragma: no cover
            for line in self._gpio.values():
                try:
                    line.close()
                except Exception:
                    pass
            self._gpio = {}

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


# --------------------------------------------------------------------------- #
# vision → line helpers
# --------------------------------------------------------------------------- #
def pulse(io: DigitalIO, pin: int, ms: float = 50.0):
    """One-shot an output (eject / strobe). Convenience over :meth:`DigitalIO.pulse`."""
    return io.pulse(pin, ms)


def signal_result(io: DigitalIO, ok: bool, pass_pin: int = 0, fail_pin: int = 1):
    """Drive PASS/FAIL outputs from an inspection verdict.

    Sets *pass_pin* = ok and *fail_pin* = not ok — the standard vision→PLC
    handshake (the PLC reads these to route the part). Returns *ok*."""
    io.set(pass_pin, bool(ok))
    io.set(fail_pin, not bool(ok))
    return bool(ok)


def signal_verdict(io: DigitalIO, verdict, coils=None) -> str:
    """Drive a 4-state inspection Verdict onto PLC coils, ONE-HOT.

    *verdict* is a :class:`fsruntime.Verdict` (or any object with a ``.status`` in
    ``{"ok","ng","error","timeout"}``, or the status string itself). Unlike
    :func:`signal_result`, which collapses everything to PASS/FAIL, this preserves
    the distinction the fail-closed Runtime exists to keep: a vision ``error`` or a
    deadline ``timeout`` must NOT read to the PLC as a good part. Exactly the coil
    for the verdict's status is set high and the other three low, so the PLC routes
    on an unambiguous one-hot signal — ``ok`` alone means "good part", and both a
    fault and a slow cycle are visibly distinct from a pass and from each other.

    *coils* overrides the address map (default ``ok=0, ng=1, error=2, timeout=3``).
    Returns the status string. Raises :class:`ValueError` on an unknown status
    (fail-closed — an unmapped verdict never silently clears every coil, which a
    PLC could misread as "no fault"). Register-based PLCs can map from these coils
    or write a status code via :mod:`comm` directly.
    """
    cmap = _VERDICT_COILS if coils is None else coils
    status = getattr(verdict, "status", verdict)
    if not isinstance(status, str):
        raise ValueError("verdict must be a Verdict, an object with .status, or a "
                         "status string, got %r" % (verdict,))
    status = status.lower()
    if status not in cmap:
        raise ValueError("unknown verdict status %r; expected one of %s"
                         % (status, sorted(cmap)))
    for st, pin in cmap.items():
        io.set(pin, st == status)                    # one-hot: exactly this coil high
    return status


def wait_input(io: DigitalIO, pin: int, state: bool = True,
               timeout: float = 5.0, poll: float = 0.01) -> bool:
    """Block until input *pin* reads *state* (a part-present / trigger signal).

    Returns True when the state is seen, False on *timeout* (seconds). *poll* is
    the polling interval."""
    deadline = timeout
    waited = 0.0
    while waited <= deadline:
        if io.get(pin) == bool(state):
            return True
        time.sleep(max(0.0, float(poll)))
        waited += max(1e-6, float(poll))
    return io.get(pin) == bool(state)
