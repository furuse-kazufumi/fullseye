"""dsp.py — 1-D signal / acoustic / vibration processing (beyond images).

HALCON is 2-D/3-D imaging only; Fullseye also handles **1-D signals** — audio,
acoustic emission, vibration — for NDT, predictive maintenance and audio anomaly
detection. A genuine differentiator: acquire a waveform, run the same
design→measure→decide→signal-the-line loop the image side uses.

Core is numpy + scipy (already required). WAV I/O uses the stdlib ``wave`` module
(native, no deps); other audio formats come through the optional ``soundfile``
extra. Signals are float64 in ``[-1, 1]`` and must be **finite** — a NaN / Inf
sample is refused with ``ValueError`` (fail-closed, as in volops / complexops /
specops) instead of quietly turning every downstream feature into NaN.

    import fullseye
    x, rate = fullseye.read_wav("knock.wav")
    f, mag = fullseye.spectrum(x, rate)          # where is the energy?
    amp = mag * (2.0 / len(x))                   # ...and how much: see spectrum()
    feats = fullseye.signal_features(x, rate)    # rms / zcr / centroid / peak_freq …
    ok = feats["peak_freq"] < 4000               # a simple acoustic verdict
"""
from __future__ import annotations

import math
import os
import wave
from functools import lru_cache

import numpy as np

__all__ = [
    "read_wav", "write_wav", "read_audio",
    "spectrum", "spectrogram", "bandpass", "lowpass", "highpass",
    "envelope", "rms", "zero_crossing_rate", "find_peaks", "peak_subbin",
    "resample", "signal_features", "point_spectrum",
    # 2-D で入れた族の 1 次元版(局所標準偏差・量子化・圧伸)。
    # mu 則はもともと 1 次元(G.711)の技術なので、次元を揃える意味が大きい。
    "local_std", "quantize", "companding_mu_law",
]


def _require_finite(x, name: str = "signal") -> np.ndarray:
    """Coerce to a float64 array and reject any NaN / Inf.

    One poisoned sample spreads across the whole spectrum through the FFT, so the
    1-D layer refuses it up front rather than emitting NaN/Inf features that look
    like measurements. Empty signals are allowed (they are the documented
    zero-feature case).

    Shape: a 1-D signal, or a column/row vector ``(N,1)`` / ``(1,N)`` (the usual
    shape from CSV loaders) which is flattened. Any other multi-dimensional input
    raises ``ValueError`` — before 2026-09-02 an ``(N,1)`` column went through
    ``rfft`` row by row and silently produced a "spectrum" of per-sample |x|."""
    if x is None:
        raise TypeError("%s is None — pass a 1-D array of samples" % name)
    a = np.asarray(x, np.float64)
    if a.ndim > 1:
        if sum(1 for s in a.shape if s != 1) > 1:
            raise ValueError("%s: expected a 1-D signal (or an (N,1)/(1,N) vector), got shape %s"
                             % (name, a.shape))
        a = a.ravel()
    elif a.ndim == 0:
        a = a.ravel()
    if a.size and not np.isfinite(a).all():
        n = int((~np.isfinite(a)).sum())
        raise ValueError("%s has %d non-finite sample(s) (NaN/Inf) — refusing" % (name, n))
    return a


# --------------------------------------------------------------------------- #
# I/O
# --------------------------------------------------------------------------- #
def _require_path(path, fn: str):
    """``path`` は str / os.PathLike。None や配列を ``str()`` してファイル名にしない。

    ★2026-09-20(GenSpark 第 15 報 N71): ``write_wav(<signal>, ...)`` と引数を取り違えると
    ``wave.open(str(array))`` が失敗し、stdlib の ``Wave_write.__del__`` が「Exception ignored …
    no attribute '_file'」を標準エラーに 1 呼び出しごとに吐いていた(本当の原因が裏に隠れる)。
    ``read_wav(None)`` も ``'None'`` というファイル名を探していた。
    """
    if path is None:
        raise TypeError("%s: path is None — pass a file path" % fn)
    if not isinstance(path, (str, os.PathLike)):
        raise TypeError("%s: path must be a str or os.PathLike, got %s%s"
                        % (fn, type(path).__name__,
                           " — the signal is the second argument: write_wav(path, x, rate)"
                           if fn == "write_wav" else ""))
    path = os.fspath(path)
    if fn.startswith("read") and not os.path.exists(path):
        raise FileNotFoundError("%s: no such file: %r" % (fn, path))
    if fn.startswith("read") and os.path.isdir(path):
        raise IsADirectoryError("%s: %r is a directory" % (fn, path))
    return path


def read_wav(path):
    """Read a WAV file (stdlib) -> ``(x float64 [-1,1], rate)``. Multi-channel is
    averaged to mono. Handles 8/16/32-bit PCM.

    Empty input (``path`` an empty string) raises ``ValueError``.
    """
    if isinstance(path, (str, bytes)) and len(path) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("read_wav: path is empty — pass a file path")
    path = _require_path(path, "read_wav")
    with wave.open(path, "rb") as w:
        rate = w.getframerate()
        n = w.getnframes()
        ch = w.getnchannels()
        width = w.getsampwidth()
        raw = w.readframes(n)
    if width == 1:                                   # 8-bit PCM is unsigned
        a = (np.frombuffer(raw, np.uint8).astype(np.float64) - 128.0) / 128.0
    elif width == 2:
        a = np.frombuffer(raw, np.int16).astype(np.float64) / 32768.0
    elif width == 4:
        a = np.frombuffer(raw, np.int32).astype(np.float64) / 2147483648.0
    else:
        raise ValueError("unsupported WAV sample width %d bytes" % width)
    if ch > 1:
        a = a.reshape(-1, ch).mean(axis=1)
    return a, rate


def write_wav(path, x, rate=44100):
    """Write a float ``[-1,1]`` mono signal to a 16-bit PCM WAV (stdlib).
    Non-finite samples raise (they would become garbage PCM).

    Returns the path written (``str``) -- the ledger declares this op's output as the
    ``file`` sort, which ``read_wav`` / ``read_audio`` consume (it used to return ``None``).

    Empty input (``path`` an empty string) raises ``ValueError``.
    """
    if isinstance(path, (str, bytes)) and len(path) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("write_wav: path is empty — pass a file path")
    path = _require_path(path, "write_wav")
    a = np.clip(_require_finite(x), -1.0, 1.0)
    pcm = np.round(a * 32767.0).astype(np.int16)
    # ファイルは自分で開く: wave.open(str) は open に失敗すると半端な Wave_write が残り、
    # その __del__ が「Exception ignored」を吐く。開けなければ OSError がそのまま出る。
    with open(path, "wb") as f, wave.open(f, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(int(rate))
        w.writeframes(pcm.tobytes())
    return os.fspath(path)


def read_audio(path):
    """Read any audio format -> ``(x, rate)``. Uses ``soundfile`` if available
    (mp3/flac/ogg/…), else falls back to the stdlib WAV reader.

    Empty input (``path`` an empty string) raises ``ValueError``.
    """
    if isinstance(path, (str, bytes)) and len(path) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("read_audio: path is empty — pass a file path")
    path = _require_path(path, "read_audio")
    try:
        import soundfile as sf
        x, rate = sf.read(path, always_2d=False)
        x = np.asarray(x, np.float64)
        if x.ndim > 1:
            x = x.mean(axis=1)
        return x, rate
    except Exception:
        return read_wav(path)


# --------------------------------------------------------------------------- #
# spectral
# --------------------------------------------------------------------------- #
def spectrum(x, rate=1.0):
    """Raw one-sided magnitude spectrum -> ``(freqs, magnitude)`` (``np.fft.rfft``).

    **Scaling convention — read this before comparing any number.** *One-sided*
    describes the frequency axis, not the amplitude axis. ``rfft`` keeps only the
    non-negative frequencies, so ``freqs`` runs from 0 to ``rate/2`` in
    ``len(x)//2 + 1`` bins — but ``magnitude`` is the **unnormalised**
    ``|rfft(x)|``. It is *not* an amplitude and it grows with ``len(x)``: the same
    tone recorded twice as long comes back twice as tall. Nothing here divides by
    ``N``; the caller does, and the exact factor depends on the bin::

        freqs, mag = spectrum(x, rate)
        amp = mag * (2.0 / len(x))       # one-sided amplitude, bins 1 .. N/2-1
        amp[0] /= 2.0                    # DC has no mirror twin -> no factor 2
        if len(x) % 2 == 0:
            amp[-1] /= 2.0               # nor does the Nyquist bin of an even N

    The factor is ``2/N`` and not ``1/N`` because a real sinusoid of amplitude
    ``A`` splits its energy over a positive and a negative frequency; ``rfft``
    discards the negative half, so the surviving bin holds ``A*N/2``. DC and (for
    even ``N``) Nyquist are their own mirror image and are *not* doubled —
    applying ``2/N`` to them reports twice the true level.

    Measured, so the convention can be checked rather than assumed. A unit sine
    at a bin centre (``rate = 25600`` Hz, ``N = 25600``, 3000 Hz, amplitude
    exactly 1.0): the returned ``mag`` at 3000 Hz is ``12799.999999999998``
    (= ``N/2``), and ``mag * 2/N`` is ``0.9999999999999999``. A constant signal
    of value 1.0 with ``N = 1024``: ``mag[0] = 1024.0``, so ``mag[0] * 1/N`` is
    exactly ``1.0`` while ``mag[0] * 2/N`` would claim ``2.0``. Likewise
    ``cos(pi n)`` (amplitude 1.0 at Nyquist, ``N = 1024``): ``mag[-1] = 1024.0``,
    ``* 1/N`` = ``1.0``, ``* 2/N`` = ``2.0``.

    Everything scale-*invariant* — where the peak is, the spectral centroid, the
    bandwidth, a ratio between two bins — is unaffected by the convention, which
    is why :func:`signal_features` can build on this directly. Everything
    absolute (an amplitude in the signal's own units, a dB level) needs the
    division above. :func:`acoustics.envelope_spectrum` and
    :func:`acoustics.order_spectrum` already return calibrated one-sided
    amplitudes (they apply their own ``2/N`` internally) — do **not** apply the
    factor twice when comparing their output with this one.
    """
    x = _require_finite(x)
    mag = np.abs(np.fft.rfft(x))
    freqs = np.fft.rfftfreq(len(x), d=1.0 / float(rate))
    return freqs, mag


def spectrogram(x, rate=1.0, win=256, hop=None):
    """STFT magnitude spectrogram -> ``(freqs, times, S)`` with ``S`` shape
    ``(n_freqs, n_frames)``. Hann-windowed; *hop* defaults to ``win//2``.

    **Same raw convention as :func:`spectrum`, but a different divisor.** Each
    column is the unnormalised ``|rfft(frame * hann(win))|``, so it is not an
    amplitude either — and dividing by ``2/win`` is *wrong* here, because the
    Hann window has already thrown away part of the signal. The correct one-sided
    amplitude conversion divides by the window's coherent gain::

        w = np.hanning(win)
        amp = S * (2.0 / w.sum())        # bins 1 .. win/2-1; DC / Nyquist: 1/w.sum()

    Measured on a unit sine at a bin centre (``rate = 16000`` Hz, 1000 Hz,
    amplitude exactly 1.0, ``win = 256``): the raw column peak is
    ``63.7497786196906``; ``* 2/win`` gives ``0.49804514546633283`` (too small by
    exactly the Hann coherent gain ``sum(w)/win = 0.498046875``), while
    ``* 2/sum(w)`` gives ``0.9999965273676957``. Only the second one is the
    amplitude that was actually in the signal.

    Peak *positions*, frame-to-frame ratios and any dB *difference* are unaffected
    by either factor. This function returns magnitudes only — the phase is
    discarded, so it cannot be inverted; use ``acoustics.stft`` / ``acoustics.istft``
    for a round-trip.

    Empty input (``x`` with 0 elements) raises ``ValueError``.
    """
    if (len(x) if isinstance(x, (list, tuple)) else np.asarray(x).size) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("spectrogram: x is empty — pass at least one element")
    x = _require_finite(x)
    win = int(win)
    hop = win // 2 if hop is None else int(hop)
    if len(x) < win:
        x = np.pad(x, (0, win - len(x)))
    window = np.hanning(win)
    starts = np.arange(0, len(x) - win + 1, hop, dtype=np.int64)
    S = np.empty((win // 2 + 1, starts.size), dtype=np.float64)
    frames = np.lib.stride_tricks.sliding_window_view(x, win)[::hop]
    for first in range(0, starts.size, 256):
        last = min(first + 256, starts.size)
        S[:, first:last] = np.abs(
            np.fft.rfft(frames[first:last] * window, axis=1)).T
    freqs = np.fft.rfftfreq(win, d=1.0 / float(rate))
    times = starts / float(rate)
    return freqs, times, S


# --------------------------------------------------------------------------- #
# filters
# --------------------------------------------------------------------------- #
@lru_cache(maxsize=64)
def _butter_coefficients(rate, cutoff, order, btype):
    from scipy.signal import butter
    cut = np.asarray(cutoff, np.float64)
    wn = cut / (0.5 * rate)
    return butter(order, wn if wn.size > 1 else wn[0], btype=btype)


def _butter(x, rate, cutoff, btype, order=4):
    from scipy.signal import filtfilt
    rate = float(rate)
    if not np.isfinite(rate) or rate <= 0.0:
        raise ValueError("rate must be a positive finite sample rate, got %r" % (rate,))
    nyq = 0.5 * rate
    cut = np.atleast_1d(np.asarray(cutoff, np.float64))
    if not np.isfinite(cut).all() or np.any(cut <= 0.0) or np.any(cut >= nyq):
        raise ValueError(                            # never clip to a near-allpass
            "cutoff %s Hz must lie inside (0, %g) Hz — the Nyquist limit for "
            "rate=%g Hz; an out-of-band cutoff cannot be filtered, it would only "
            "return the signal essentially unchanged" % (cut.tolist(), nyq, rate))
    key_cutoff = tuple(float(v) for v in cut)
    b, a = _butter_coefficients(rate, key_cutoff, int(order), str(btype))
    x = _require_finite(x)
    pad = 3 * max(len(a), len(b))                    # scipy filtfilt's default padlen
    if len(x) <= pad:                                # filtfilt needs enough samples
        raise ValueError(
            "signal has %d sample(s); zero-phase filtfilt needs more than %d for an "
            "order-%d filter — use a longer signal or a lower order"
            % (len(x), pad, int(order)))
    return filtfilt(b, a, x)


def lowpass(x, rate, cutoff, order=4):
    """Butterworth low-pass (scipy, zero-phase filtfilt). *cutoff* must be inside
    ``(0, rate/2)``; an out-of-Nyquist cutoff raises instead of passing the signal
    through. A signal too short for zero-phase filtfilt also raises (the message
    names the exact minimum) instead of silently coming back unfiltered."""
    return _butter(x, rate, cutoff, "low", order)


def highpass(x, rate, cutoff, order=4):
    """Butterworth high-pass. Same Nyquist / length contract as :func:`lowpass`."""
    return _butter(x, rate, cutoff, "high", order)


def bandpass(x, rate, low, high, order=4):
    """Butterworth band-pass between *low* and *high* Hz. Both edges must be inside
    ``(0, rate/2)``; same length contract as :func:`lowpass`."""
    return _butter(x, rate, [low, high], "band", order)


# --------------------------------------------------------------------------- #
# analysis
# --------------------------------------------------------------------------- #
def envelope(x):
    """Amplitude envelope via the analytic (Hilbert) signal — the shape of a
    knock / impact / acoustic-emission burst."""
    from scipy.signal import hilbert
    return np.abs(hilbert(_require_finite(x)))


def rms(x, frame=None, hop=None):
    """RMS level. Scalar for the whole signal, or a framewise array when *frame*
    is given (a vibration/energy envelope over time).

    Empty input (``x`` with 0 elements) raises ``ValueError``.
    """
    if (len(x) if isinstance(x, (list, tuple)) else np.asarray(x).size) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("rms: x is empty — pass at least one element")
    x = _require_finite(x)
    if frame is None:
        return float(np.sqrt(np.mean(x * x))) if x.size else 0.0
    frame = int(frame)
    hop = frame // 2 if hop is None else int(hop)
    if hop == frame:
        n = max(1, (len(x) - frame) // hop + 1)
        if len(x) >= frame:
            blocks = x[:n * frame].reshape(n, frame)
            return np.sqrt(np.mean(blocks * blocks, axis=1))
    return np.array([np.sqrt(np.mean(x[s:s + frame] ** 2))
                     for s in range(0, max(1, len(x) - frame + 1), hop)])


def zero_crossing_rate(x):
    """Fraction of adjacent samples that change sign — a cheap pitch/noisiness cue.

    Exact zeros are neither a crossing nor a sign: a crossing is counted only when
    the sign changes between consecutive *non-zero* samples, and the rate divides
    by the number of adjacent sample pairs ``len(x) - 1``. So ``[1, 0, 1, 0, 1]`` is
    ``0.0`` and ``[1, 0, -1]`` is ``0.5`` (before 2026-09-02 ``diff(sign(x))`` counted
    every touch of zero as a crossing: ``1.0`` for both).

    Empty input (``x`` with 0 elements) raises ``ValueError``.
    """
    if (len(x) if isinstance(x, (list, tuple)) else np.asarray(x).size) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("zero_crossing_rate: x is empty — pass at least one element")
    x = _require_finite(x)
    if x.size < 2:
        return 0.0
    nz = x[x != 0.0]
    if nz.size < 2:
        return 0.0
    return float(np.count_nonzero(np.signbit(nz[:-1]) != np.signbit(nz[1:]))) / float(x.size - 1)


def find_peaks(x, height=None, distance=None):
    """Peak indices (scipy.signal.find_peaks) — impacts / defect echoes.

    Empty input (``x`` with 0 elements) raises ``ValueError``.
    """
    if (len(x) if isinstance(x, (list, tuple)) else np.asarray(x).size) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("find_peaks: x is empty — pass at least one element")
    from scipy.signal import find_peaks as _fp
    idx, _ = _fp(_require_finite(x), height=height, distance=distance)
    return idx


def peak_subbin(x, idx=None, mode="parabola"):
    """Peak position **between** samples — the vertex of a fit through 3 points.

    :func:`find_peaks` returns integer indices, so the position of a spectral
    line or a correlation peak is quantised to the bin grid no matter how
    finely the peak itself is resolved. This refines each index to a float by
    fitting the sample and its two neighbours.

    *mode* picks what is fitted:

    ``"parabola"``
        ``a x^2 + b x + c`` through the three raw values. The classic estimator;
        exact for a genuinely parabolic top and cheap.
    ``"gauss"``
        the same parabola through ``log`` of the three values, which is exact for
        a Gaussian peak. **Requires all three values positive** — a magnitude
        spectrum qualifies, a signed correlation does not. Non-positive
        neighbourhoods raise ``ValueError`` rather than silently returning the
        integer index, because "the refinement quietly did nothing" is the
        failure this operator exists to remove.

    Measured on a Gaussian of width 1.7 bins centred at 40.37: the integer
    argmax gives 40 (error 0.37 bins), ``parabola`` gives 40.3553 (error
    **0.0147**) and ``gauss`` gives 40.3700 (error 0, to machine precision).
    **The parabola is biased on a Gaussian, and the bias grows as the peak gets
    narrower** — the same measurement at widths 6.0 / 3.0 / 1.7 / 1.0 bins errs
    by 0.0012 / 0.0047 / 0.0147 / 0.0434. That is the whole reason ``gauss``
    exists: for a spectral line the log-parabola is not an approximation, it is
    the exact model.

    The refinement is still an assumption about shape, not a measurement of it.
    On a triangular peak, whose top is not smooth, ``parabola`` errs by 0.0857
    bins where the integer index errs by 0.30 — better, but three times worse
    than on the Gaussian it was designed for.

    **The shift is not clamped.** A vertex more than half a sample away from the
    index means the index was not a local maximum in the first place, and that is
    information: clamping it to +/-0.5 would return a plausible number for a bin
    that has no peak in it. Run :func:`find_peaks` first, or clamp deliberately
    at the call site when evaluating bins that are not maxima (a harmonic comb,
    for instance).

    A peak sitting on the first or last sample has no neighbour on one side and
    keeps its integer position (there is nothing to interpolate against); the
    returned array says so by being exactly equal to the input index there.

    Parameters
    ----------
    x : array_like
        The 1-D signal the peaks were found in.
    idx : int, sequence of int, or None
        Peak indices. ``None`` means "the argmax", so ``peak_subbin(mag)`` is the
        one-liner for a single line.
    mode : {"parabola", "gauss"}

    Returns
    -------
    float or ndarray
        Refined position(s) in samples. Scalar in, scalar out.

    See also
    --------
    find_peaks : which indices to refine.
    """
    x = _require_finite(x)
    if x.size < 3:
        raise ValueError("peak_subbin needs at least 3 samples, got %d" % x.size)
    if mode not in ("parabola", "gauss"):
        raise ValueError("mode must be 'parabola' or 'gauss', got %r" % (mode,))
    scalar = np.ndim(idx) == 0 and idx is not None
    if idx is None:
        idx, scalar = np.array([int(np.argmax(x))]), True
    ii = np.atleast_1d(np.asarray(idx, np.int64))
    if ii.ndim != 1:
        raise ValueError("idx must be scalar or 1-D, got shape %r" % (ii.shape,))
    if ii.size and (ii.min() < 0 or ii.max() >= x.size):
        raise ValueError("peak index out of range for a signal of %d samples"
                         % x.size)
    out = ii.astype(np.float64)
    inner = (ii > 0) & (ii < x.size - 1)
    if inner.any():
        j = ii[inner]
        y0, y1, y2 = x[j - 1], x[j], x[j + 1]
        if mode == "gauss":
            if np.min([y0, y1, y2]) <= 0.0:
                raise ValueError(
                    "mode='gauss' needs all three samples positive around every "
                    "peak (log of a non-positive value); use mode='parabola' for "
                    "signed data")
            y0, y1, y2 = np.log(y0), np.log(y1), np.log(y2)
        denom = y0 - 2.0 * y1 + y2
        # denom == 0 -> the three points are collinear: no vertex exists, so the
        # honest answer is the sample itself, not a division by zero.
        shift = np.where(denom != 0.0, 0.5 * (y0 - y2) / np.where(denom == 0.0, 1.0, denom), 0.0)
        out[inner] = j + shift
    return float(out[0]) if scalar else out


def point_spectrum(positions, extent=None, n_freq=2048, f_max=None,
                   method="direct", weights=None, bins_per_period=8,
                   memory_budget=None):
    """Periodogram of **event positions** — defects, impacts, counts, arrivals.

    :func:`spectrum` needs an evenly sampled signal, but a great deal of
    industrial data arrives as a *list of positions*: where each defect was on
    the web, when each particle was counted, at what angle each dent sits. The
    usual workaround is to histogram the positions and FFT the histogram, which
    works but hides two choices — bin width and record length — that decide the
    answer. This operator makes both explicit and returns them.

    *method* picks the estimator:

    ``"direct"``
        the point-process (Bartlett) periodogram
        ``|sum_j w_j exp(-2 pi i f x_j) - rate * integral|^2 / sum_j w_j``,
        evaluated at each requested frequency. **No binning at all**, so no bin
        width to choose and no aliasing from one. The subtracted term is the
        contribution a *uniform* process of the same rate would make; without it
        every spectrum peaks at f -> 0 simply because events exist.
    ``"binned"``
        histogram the positions, then ``rfft``, with the bin width set so the
        finest frequency asked for still gets ``bins_per_period`` samples per
        cycle. Cheaper for very many events, and the result is what a
        histogram-and-FFT pipeline would have produced.

    **The frequency resolution is a property of the record, not of the method.**
    Two periods closer than ``1/extent`` apart cannot be told apart by either
    estimator, and the returned dict says so in ``resolution``: read it before
    reading a peak, not after.

    **A periodic train of events is a comb, not a line.** Its harmonics at
    ``k/period`` are as tall as the fundamental, so ``argmax`` of this spectrum
    routinely returns ``period/k`` rather than the period. Measured on 93 events
    (43 spaced 471.24 apart with 1.5 of jitter, plus 50 uniformly random) over a
    record of 20000: the global maximum lands on ``58.90`` with ``direct`` (the
    8th harmonic) and ``52.35`` with ``binned`` (the 9th), while the fundamental
    is present and prominent in both — ``direct`` puts 0.947 of the maximum
    power at ``1/471.24``, ``binned`` 0.379. Take the lowest frequency whose
    first few harmonics *all* stand, rather than the tallest line — see
    ``examples/poc_web_roll_periodicity.py``, which is what this operator was
    added for.

    Returns a dict: ``freq`` (cycles per unit of *positions*), ``power``,
    ``resolution`` (``1/extent``), ``extent``, ``n_events``, ``method``, and
    ``bin_width`` (``None`` for ``"direct"``).

    Fail-closed: fewer than two events raises ``ValueError`` — a periodogram of
    one point is not a weak measurement, it is not a measurement.
    """
    pos = _require_finite(positions, "positions")
    if pos.size < 2:
        raise ValueError("point_spectrum needs at least 2 events, got %d"
                         % pos.size)
    if extent is None:
        lo, hi = float(pos.min()), float(pos.max())
    else:
        lo, hi = 0.0, float(extent)
        # 2026-10-11: events outside the declared record [0, extent] were not checked --
        # "binned" silently dropped them (a flat zero spectrum) and "direct" kept them
        # (a plausible peak from a record that does not hold them). Positions on an
        # absolute axis (1000..1950 with extent=1000) are a caller error: refuse it.
        if np.isfinite(hi) and hi > 0.0:
            out = int(np.count_nonzero((pos < 0.0) | (pos > hi)))
            if out:
                raise ValueError(
                    "point_spectrum: %d of %d events lie outside [0, extent=%g] "
                    "(positions span %g..%g); shift the positions to start at 0 "
                    "or pass the extent that covers them"
                    % (out, pos.size, hi, float(pos.min()), float(pos.max())))
    span = hi - lo
    if not span > 0.0:
        raise ValueError("the events span zero length; pass extent= explicitly")
    if weights is not None:
        w = _require_finite(weights, "weights")
        if w.shape != pos.shape:
            raise ValueError("weights must match positions (%r vs %r)"
                             % (w.shape, pos.shape))
    else:
        w = np.ones_like(pos)
    fmax = float(f_max) if f_max is not None else 0.5 * pos.size / span
    if not fmax > 0.0:
        raise ValueError("f_max must be positive, got %r" % (f_max,))
    freq = np.linspace(1.0 / span, fmax, int(n_freq))
    x = pos - lo
    if method == "direct":
        wsum = float(w.sum())
        # exp(-2 pi i f x) summed over events, minus what a uniform process of
        # the same rate would give: that difference is the periodic structure.
        # Keep the temporary phase matrix bounded for large event lists.  The
        # arithmetic within each requested frequency is unchanged.
        if memory_budget is None:
            raw = np.exp(-2j * np.pi * np.outer(freq, x)) @ w
        else:
            budget = int(memory_budget)
            if budget < 16 * max(1, x.size):
                raise ValueError("memory_budget is too small for one frequency row")
            block = max(1, budget // (16 * max(1, x.size)))
            raw = np.empty(freq.size, dtype=np.complex128)
            for start in range(0, freq.size, block):
                fs = freq[start:start + block]
                raw[start:start + block] = np.exp(-2j * np.pi * fs[:, None] * x) @ w
        u = np.where(freq != 0.0,
                     (1.0 - np.exp(-2j * np.pi * freq * span))
                     / (2j * np.pi * np.where(freq == 0.0, 1.0, freq)),
                     span)
        power = np.abs(raw - (wsum / span) * u) ** 2 / max(wsum, 1e-12)
        bin_width = None
    elif method == "binned":
        nb = max(8, int(np.ceil(span * fmax * float(bins_per_period))))
        hist, _ = np.histogram(x, bins=nb, range=(0.0, span), weights=w)
        mag = np.abs(np.fft.rfft(hist - hist.mean()))
        fb = np.fft.rfftfreq(nb, d=span / nb)
        power = np.interp(freq, fb, mag ** 2, left=0.0, right=0.0)
        bin_width = span / nb
    else:
        raise ValueError("method must be 'direct' or 'binned', got %r"
                         % (method,))
    return {"freq": freq, "power": np.asarray(power, np.float64),
            "resolution": 1.0 / span, "extent": span, "n_events": int(pos.size),
            "method": method, "bin_width": bin_width}


def resample(x, rate, new_rate):
    """Resample a signal to *new_rate* (Fourier method)."""
    from scipy.signal import resample as _rs
    x = _require_finite(x)
    n = int(round(len(x) * float(new_rate) / float(rate)))
    return _rs(x, max(1, n)), new_rate


def _round_keep(v, decimals, sig):
    """``round(v, decimals)``、ただし小さい値でも有効数字 ``sig`` 桁は残す(abs-floor2)。

    小数点以下の桁数で丸めると、振幅 1e-9 の信号(m 単位の振動・ひずみ)の rms が 0 に潰れる。
    ``|v| >= 10**(sig - 1 - decimals)`` では従来の ``round(v, decimals)`` と同じ値。
    """
    v = float(v)
    if v == 0.0 or not math.isfinite(v):
        return v
    return round(v, max(int(decimals), int(sig) - 1 - int(math.floor(math.log10(abs(v))))))


def signal_features(x, rate=1.0):
    """A compact acoustic/vibration feature vector for anomaly detection:
    ``rms``, ``peak``, ``crest_factor``, ``zcr``, ``spectral_centroid`` (Hz),
    ``peak_freq`` (Hz), ``bandwidth`` (Hz). All finite — a NaN / Inf sample raises
    ``ValueError`` rather than producing NaN features (an empty signal too, since 2026-10-12;
    it used to give zeros).

    The three spectral entries are built on :func:`spectrum`, but every one of
    them is a *ratio* of magnitudes (``argmax``, a magnitude-weighted mean, a
    magnitude-weighted spread), so the raw ``|rfft|`` convention documented there
    cancels out and these numbers are unaffected by it. ``rms``, ``peak`` and
    ``crest_factor`` are computed in the time domain and never touch the FFT.

    Empty input (``x`` with 0 elements) raises ``ValueError``.
    """
    if (len(x) if isinstance(x, (list, tuple)) else np.asarray(x).size) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("signal_features: x is empty — pass at least one element")
    x = _require_finite(x)
    if x.size == 0:
        return {k: 0.0 for k in ("rms", "peak", "crest_factor", "zcr",
                                 "spectral_centroid", "peak_freq", "bandwidth")}
    r = rms(x)
    peak = float(np.max(np.abs(x)))
    freqs, mag = spectrum(x, rate)
    # 床を足さない(abs-floor2): 以前の ``mag.sum() + 1e-12`` は振幅 1e-9 以下の信号で
    # 重心・帯域を 0 側へ潰した(比なので振幅の尺度に依らないはずの量)。
    msum = float(mag.sum())
    if not msum > 0.0:
        msum = 1.0                      # 全部 0 の信号: 分子も 0 なので重心・帯域は 0
    centroid = float((freqs * mag).sum() / msum)
    peak_freq = float(freqs[int(np.argmax(mag))])
    bandwidth = float(np.sqrt(((freqs - centroid) ** 2 * mag).sum() / msum))
    return {
        "rms": _round_keep(r, 6, 6),
        "peak": _round_keep(peak, 6, 6),
        "crest_factor": round(peak / r, 4) if r > 0.0 else 0.0,
        "zcr": round(zero_crossing_rate(x), 6),
        "spectral_centroid": _round_keep(centroid, 3, 3),
        "peak_freq": _round_keep(peak_freq, 3, 3),
        "bandwidth": _round_keep(bandwidth, 3, 3),
    }


# ------------------------------------------------------------------------- #
# 2-D で入れた族の 1 次元版
# ------------------------------------------------------------------------- #
def local_std(x, window=9):
    """Rolling standard deviation with a stated error bound.

    The 1-D counterpart of the image operator ``local_std`` (HALCON's
    ``deviation_image``): the variance is taken after subtracting the mean
    (``E[x^2] - E[x]^2`` loses its significant digits on a signal that sits far
    from zero), unbiased by ``n/(n-1)``, and the residual bias of the square root
    removed by ``c4(n)``, so the estimate of ``sigma`` itself is unbiased.

    *window* is the number of samples in the sliding window, **rounded up to the
    next odd number** so the window can be centred (10 becomes 11). The error
    bound below is computed from the window actually used, so the number quoted
    stays true. The 2-D side does the same thing — ``_k(a)`` snaps the knob to
    3/5/7/9 — and the typed bridge that exposes this op as ``tb_local_std``
    scales the knob continuously, so an even value arrives whenever the knob
    lands between two odd ones.
    **The relative standard error of each estimate is ``1/sqrt(2(n-1))``** —
    35 % for a 5-sample window, 11 % for 41. Quote it next to any noise figure:
    a rolling sigma over 9 samples is +- 25 %, which is wider than most of the
    changes people try to read off it.

    Returns an array the same length as *x* (the ends are reflected).
    """
    x = _require_finite(x)
    n = int(window)
    if n < 3:
        raise ValueError("window must be >= 3 samples, got %r" % (window,))
    if n % 2 == 0:
        n += 1                                   # 中心を取れるよう次の奇数へ
    if x.size < n:
        raise ValueError("signal shorter than the window (%d < %d)" % (x.size, n))
    pad = n // 2
    xp = np.pad(np.asarray(x, np.float64) - float(np.mean(x)), pad, mode="reflect")
    win = np.lib.stride_tricks.sliding_window_view(xp, n)
    var = win.var(axis=-1, ddof=1)
    return np.sqrt(var) / _c4(n)


def _c4(n: int) -> float:
    """``sqrt(2/(n-1)) * Gamma(n/2)/Gamma((n-1)/2)`` ~ ``1 - 1/(4n)``."""
    from scipy.special import gammaln
    import math
    return math.sqrt(2.0 / (n - 1)) * math.exp(gammaln(n / 2.0) - gammaln((n - 1) / 2.0))


def quantize(x, bits=8, mode="round", dither=None, seed=0):
    """Scalar quantiser with the error model stated, plus optional dither.

    *bits* sets the number of levels ``L = 2**bits`` over the signal's own
    min..max range. *mode* is ``"round"`` (mid-tread, unbiased) or ``"truncate"``
    (floor, the convention PIL's posterize and most fixed-point casts use).

    **The two differ by more than a rounding convention.** With step
    ``Delta = range/(L-1)`` both have error variance ``Delta**2/12``, but
    truncation also carries a mean of ``-Delta/2``, so its mean square error is

        truncate:  Delta**2/12 + (Delta/2)**2 = Delta**2/3
        round:     Delta**2/12

    — a factor of **4**. Anything that measures a level (not just displays it)
    must round.

    *dither* adds noise **before** quantising so the error stops being a function
    of the signal: ``"tpdf"`` (triangular, the audio standard — two uniform draws
    summed, so the error's variance no longer depends on the sample value) or
    ``"rpdf"`` (one uniform draw). Dither raises the total error power but removes
    the correlation that makes quantisation audible as distortion rather than as
    hiss. ``seed`` fixes the draw so the op stays deterministic.

    **Applicability.** (1) The range is taken from *this* signal, so two signals
    quantised separately do not share a scale. (2) ``bits=1`` with no dither is a
    comparator, not a quantiser — the error model does not apply. (3) The error
    model assumes the signal moves by more than a step between samples; on a flat
    stretch the error is a constant offset, not noise.

    Empty input (``x`` with 0 elements) raises ``ValueError``.
    """
    if (len(x) if isinstance(x, (list, tuple)) else np.asarray(x).size) == 0:   # ★2026-10-12 空入力の方針 A: 黙って値を返さず、何が空かを名指しで拒否
        raise ValueError("quantize: x is empty — pass at least one element")
    x = _require_finite(x)
    if x.size == 0:
        return np.asarray(x, np.float64)
    bits = int(bits)
    if not 1 <= bits <= 24:
        raise ValueError("bits must be 1..24, got %r" % (bits,))
    lo, hi = float(np.min(x)), float(np.max(x))
    if hi <= lo:
        return np.asarray(x, np.float64)
    L = 1 << bits
    step = (hi - lo) / float(L - 1)
    u = (np.asarray(x, np.float64) - lo) / step
    if dither is not None:
        rng = np.random.default_rng(int(seed))
        if dither == "tpdf":
            u = u + rng.random(u.shape) + rng.random(u.shape) - 1.0
        elif dither == "rpdf":
            u = u + rng.random(u.shape) - 0.5
        else:
            raise ValueError("dither must be None, 'tpdf' or 'rpdf', got %r" % (dither,))
    if mode == "round":
        q = np.round(u)
    elif mode == "truncate":
        q = np.floor(u)
    else:
        raise ValueError("mode must be 'round' or 'truncate', got %r" % (mode,))
    return lo + np.clip(q, 0, L - 1) * step


def companding_mu_law(x, mu=255.0, bits=8):
    """mu-law companding — the G.711 curve, used here on any 1-D signal.

    Compress with ``F(v) = sign(v) * ln(1 + mu|v|) / ln(1 + mu)`` on the signal
    scaled to ``[-1, 1]``, quantise uniformly, expand back. The steps end up fine
    near zero and coarse near full scale, which is the right allocation when the
    interesting part of the signal is small compared with its peaks — speech,
    vibration, anything with a large crest factor.

    **This is where mu-law comes from**: the image operator
    ``companding_mu_law`` is the same curve applied to intensity. Reporting both
    keeps the family honest about which dimension the technique was designed for.

    **Applicability — it is the crest factor that decides.** Measured on a sine
    of amplitude *A* with one sample pinned at full scale, so the crest factor is
    exactly ``1/A`` (mean square error relative to a uniform quantiser):

        crest 50    4 bit 0.011   6 bit 0.014     (about 90x better)
        crest 20    4 bit 0.122   6 bit 0.101
        crest 6.7   4 bit 0.613   6 bit 0.616
        crest 2.0   4 bit 4.22    6 bit 6.03      (several times WORSE)

    So the rule is **crest factor above roughly 7** — speech, vibration, impact.
    Below that, a plain uniform quantiser wins and mu-law actively hurts.
    ★Note the peak is a **single sample**: on random signals of the same family
    the advantage swung between 0.55 and 0.87 purely with the seed, because the
    largest excursion sets the scale. Measure the crest factor of *your* signal,
    do not assume it from the distribution.

    Other limits: ``mu`` near 0 degenerates to uniform quantisation (that is how
    you check the curve is doing anything), and the curve is fixed — unlike a
    Lloyd-Max codebook fitted to the signal — which is the point when values must
    stay comparable across recordings.
    """
    x = _require_finite(x)
    if x.size == 0:
        return np.asarray(x, np.float64)
    mu = float(mu)
    if mu < 0.0:
        raise ValueError("mu must be >= 0, got %r" % (mu,))
    peak = float(np.max(np.abs(x)))
    if peak <= 0.0:
        return np.asarray(x, np.float64)
    v = np.asarray(x, np.float64) / peak
    if mu == 0.0:
        y = v
    else:
        y = np.sign(v) * np.log1p(mu * np.abs(v)) / np.log1p(mu)
    yq = quantize(y, bits=int(bits), mode="round")
    if mu == 0.0:
        out = yq
    else:
        out = np.sign(yq) * (np.expm1(np.abs(yq) * np.log1p(mu))) / mu
    return out * peak
