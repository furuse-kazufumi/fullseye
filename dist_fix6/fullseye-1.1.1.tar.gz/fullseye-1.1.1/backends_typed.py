# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""Typed bridge — 型付き op カタログ(ops3d / ops1d / opsmath / opsoptics)を
進化レジストリ(``ops.py``)の語彙に接続する。

**なぜ要るか(実測 2026-09-01)**: fullseye には op の宇宙が 2 つあった。

  * ``ops.py`` の ``REGISTRY`` — 742 op。進化(``evolve.py`` / ``robust.py``)が
    探索する空間。``fn(v, a, b)`` 規約、sort は image/region/feature/contour/…
  * 型付きカタログ — 382 op(3d 310 / 1d 34 / math 26 / 2d 12)。連鎖ファザーと
    facade が使う。宣言された入出力型を持つ多引数 API。

**この 2 つは名前が 3 個しか重なっていなかった**。つまり進化は点群 op も 1-D op も
数学 op も一度も組み合わせたことがなく、自己拡張レジストリ(``backends_macro``)も
狭い方の宇宙でしか育っていなかった。本モジュールはその橋を架ける。

**安全性の根拠**: ``ops._candidates(sort)`` は ``in_sort`` で絞るだけなので、
**既存 sort の候補リスト長を変えなければ**ゲノム→op の写像は不変
(``docs/WAVE0_STABLE_SLOTS.md``: 長さが変わると既存 champion を黙って書き換える)。
そこで既定では **入力 sort が新設のもの(points / signal / matrix / cimage)だけ**を
登録する。出力 sort は既存でも構わない — 候補リストの絞り込みは入力側でしか
行われないため。既存 sort を入力に取る op(voxel / image2d / …)は
``IMGEVOLVE_WIDE_VOCAB=1`` の **opt-in** でのみ加わる(黙って広げない)。

**引数の束縛**: カタログ op は多引数だが、進化は ``fn(v, a, b)`` しか渡せない。
必須の追加引数は連鎖ファザーが持つヒント表(``tools/chain_fuzz`` の
``PARAM_HINTS`` / ``OP_PARAM_HINTS``)で束縛する — ファザーが 2000 連鎖で実際に
通していた値なので、机上の既定値ではなく **実績のある束縛**である。束縛できない
必須引数が残る op は登録しない(推測の既定値を捏造しない)。

**a, b ノブ(実測に基づく設計変更 2026-09-01)**: 最初は ``backends_macro`` の DNA op
に倣って凍結したが、実際に 58 op を走らせると **ノブを凍結した op は進化にとって
調整余地ゼロ**で、既定値が恒等な op(``scale_y_funct_1d`` の ``mult=1.0``)は
文字どおり何もしない枠になっていた。かといって絶対範囲を勝手に決めるのは
「出所不明のパラメータ」の捏造である。

そこで **著者自身が書いた既定値を基準にした相対スケール**だけを許す:

    p = default * (0.25 + 1.75 * knob)      # knob ∈ [0,1] → 既定の 1/4 〜 2 倍

正の数値既定を持つ第 1 引数に ``a``、第 2 引数に ``b`` を割り当てる(整数既定は
整数へ丸め、1 未満にならないよう下限 1)。**根拠は「その op の作者が妥当と考えた
値の近傍」**であって、こちらが発明した範囲ではない。既定を持たない必須引数は
従来どおりファザーのヒント表で束縛し、ノブは繋がない。

*正直な限界*: この相対スケールは「既定値が意味のある中心である」ことを仮定する。
比率でなく加法的な意味を持つ引数(オフセット、しきい値の絶対値)には不適切で、
その場合は探索が無駄になるだけ(誤った結果は出さない — 各 op の入口検証が
不正な値を fail-closed で弾く)。専用の範囲が要る op は個別 wrapper を書くのが筋。

**fail-soft**: どの backend も守る契約どおり、実行時例外は入力の sort 妥当な値へ
落とす(進化の適応度計算を 1 op の失敗で止めない)。optional 依存の欠如も同様。
"""
from __future__ import annotations

import os
import sys

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))

#: カタログ型語彙 → ops.py の sort。値が None の型は「進化側に対応する sort が
#: 無い」= 橋を架けない(mesh / primitive / pose / descriptor など構造化された型)。
TYPE_TO_SORT = {
    "voxel": "volume",
    "sdf": "volume",
    "labels": "volume",
    "image2d": "image",
    "depth": "image",
    "measurement": "feature",
    "points": "points",
    "normals": "points",
    # keypoints は像面上の (N,2)。points((N,3))とは**別 sort**。
    # 2026-09-02 まで points へ写しており、_sort_ok が shape[1]==3 を要求する
    # ため (N,2) を返す/取る op が 4 件まるごと fail-soft に落ちていた。
    "keypoints": "keypoints",
    "signal": "signal",
    "indices": "signal",
    "matrix": "matrix",
    "cimage": "cimage",
    # 光子計数・ライトフィールド族(2026-09-01)。counts と countrate は
    # 進化側では 1 つの sort に畳む — voxel/sdf/labels を volume に、
    # points/normals を points に畳んでいるのと同じ粒度の判断で、
    # 「非負の 1-D」であることが進化にとって意味のある区別のすべてだから。
    # (keypoints も当初この列に入れていたが、**形が (N,2) で points の契約を
    #  満たさない**ため畳めなかった。畳めるかどうかは「意味が近いか」ではなく
    #  「同じ sort の形の契約を両方が満たすか」で決まる ―― 2026-09-02 の教訓。)
    # カタログ側で 2 語に分けてあるのは、型の嘘(ヒストグラムをレート op に
    # 渡す)をファザーに検出させるためで、そちらは別の目的。
    "lightfield": "lightfield",
    "counts": "counts",
    "countrate": "counts",
    "histcube": "histcube",
    # 2026-09-01 後半に足した族。いずれも**族の中に産出 op がある**ので、
    # 消費側だけの死んだ語彙にはならない(実測の消費/産出/自己ループ:
    # rgbimage 4/4/2 · video 9/2/1 · qimage 11/11/6 · beatcube 5/2/1)。
    # polsweep は消費 3・自己ループ 0 で「1 手で外へ出るだけ」に近く、
    # histcube と同じ理由で見送る(選択肢が 3 つある点だけ histcube より良い)。
    "rgbimage": "rgbimage",
    "video": "video",
    "qimage": "qimage",
    "beatcube": "beatcube",
}

#: 既定で登録する入力 sort(すべて新設 = 既存の候補リストに触れない)。
#:
#: **2026-09-01 に一度判断を誤り、実測で訂正した**ので経緯を残す。当初は
#: lightfield / counts / histcube を除外していた。理由は「その族の入口 op
#: (``lf_from_mla``: image2d → lightfield、``dtof_cube_simulate``: depth →
#: histcube)が既存の image sort を入力に取るので、既定に入れると image の
#: 候補リストが動いてゲノム → op の写像が変わる」というものだった。
#:
#: 前半は正しいが**結論が過剰だった**。``_candidates`` は **in_sort でしか
#: 絞らない**ので、除外すべきなのは入口 op(in_sort=image)だけであり、
#: それは in_sort=image が本集合に無いことで既に除外されている。消費側
#: (in_sort=lightfield/counts/histcube)を足しても**動くのは新設 sort の
#: 候補リストだけ**で、既存 sort は 1 件も変わらない。実測 2026-09-01:
#: image 523→523 / region 130→130 / points 33→33 /(全 sort 不変)、
#: レジストリ全体は 809 → 824。
#:
#: 「誰も産まないので死んだ語彙になる」という懸念も、**画像から始まる探索に
#: 限った話**だった。``Problem.in_sort`` がその sort なら入力は課題が供給する
#: ので、入口 op が無くても消費側は生きて動く。実際 counts / lightfield /
#: histcube の課題を足すために、この訂正が必要だった。
#:
#: 入口 op(既存 sort を入力に取るもの)は従来どおり ``IMGEVOLVE_WIDE_VOCAB=1``
#: の opt-in でのみ加わる。そこは変えていない。
#: **histcube は入れない**(2026-09-01 の実測判断)。この sort を消費する op は
#: ``dtof_cube_depth`` 1 つだけで、しかも出口が image なので、既定語彙に入れても
#: 「1 手で外へ出るだけ」= 進化する余地がゼロの死んだ枠になる。課題を足しても
#: 手の基準線と同じ 1 手しか組めない。**使える仕事が無い語彙は足さない**。
#: wide 語彙(IMGEVOLVE_WIDE_VOCAB=1)では従来どおり入る。
#: **2-D 橋渡しから外す op**。理由は「性能」でも「未対応」でもなく **定義域**:
#: これらは cos・光路長 [mm]・波長 [nm] のような物理量を取るのに、橋が渡すのは
#: sort `signal` の汎用 0..1 列である。domain の外なので op は ValueError を返し、
#: 橋のランナーは fail-soft で**入力をそのまま返す** —— つまり登録しても
#: 「恒等を返し続ける死んだ op」が 2-D 台帳に増えるだけになる
#: (2026-09-04、liveness テストが 6 件を pass-through として摘発)。
#: 単位に合う種を渡す仕組みができたら外してよい(その時は `opassist` の
#: 単位ベース種と同じ考え方で `chain_fuzz` 側に種を足すのが筋)。
_OP_BRIDGE_SKIP = {
    # 面を**作る**側の op は画像を 1 枚受け取らない(窓の指定だけで描く)
    "cplx_plane_grid",
    "cplx_rational_field",
    "cplx_escape_time",
    "potential_flow_joukowski",
    "joukowski_circulation",
    "fresnel_dielectric", "fresnel_conductor", "beer_lambert_transmittance",
    "slab_transmittance", "thin_film_reflectance", "prism_min_deviation_deg",
    "cie_xyz_from_wavelength", "spectrum_to_srgb",
    # 2026-09-08: 探針を 4 sort から全 sort に広げた初回に摘発。
    # `angle_3points(a, b, c)` は**3 本のベクトル**を取るので、点群 1 本を渡す橋の
    # 呼び方(a = (N,3) の雲まるごと)では毎回 ValueError になり、fail-soft が
    # もっともらしい float を返していた —— つまり登録されているのに**一度も
    # 走ったことがない**op。同じ族の `line_from_2points` / `plane_from_3points` は
    # out が `primitive`(sort 無し)なので初めから橋が架かっておらず、
    # 「out に sort がある」というだけの理由でこの 1 本だけが橋に載っていた。
    # 台帳(`fullseye.ledger.angle_3points`)からは今までどおり 3 点を渡して使える。
    "angle_3points",
    # 2026-09-21: videocube の 3 本。`video` は TYPE_TO_SORT で 3-D に畳まれるので橋が
    # 架かるが、橋が渡す「動画」は 2-D 画像 1 枚を積んだ**静止クリップ**であり、動き
    # の立方体は全面 0、スリットスキャンは縞、代表フレームは全部同じ —— 走るが意味の
    # ある出力が出ない(「走った」≠「意味のある出力」)。加えて探針の a/b が
    # percentile を 111.9 に押し上げて ValueError、vibration_map の既存最良も汚した。
    # 台帳(`fullseye.ledger.video_*`)からは本物の動画を渡して使える。
    "video_spacetime_cube", "video_cube_cut", "video_summary_keyframes",
    # 2026-09-21: live4d。同じ理由(橋の動画は静止クリップ、補間しても同じフレームが増えるだけ)。
    "video_interpolate_flow",
    # 2026-09-22: complex 第 2 陣の `cplx_domain_colour`。cimage を 1 枚取るので橋は
    # 架かるが、橋が振る自由な a/b ノブが **[0, 1] に閉じた引数**(saturation)に
    # 当たると必ず domain の外に出る(実測 [sincos a=0.5 b=0.5] で 1.125 → ValueError)。
    # op は正しく fail-closed している —— 欠陥は「範囲つきのノブに無制限の探針を
    # 当てる」側にある(videocube の percentile 111.9 と同じ型)。台帳
    # (`fullseye.ledger.cplx_domain_colour`)からは今までどおり saturation を指定して使える。
    "cplx_domain_colour",
    # 2026-09-23: 定理が門になる図の生成側。曲率の四つ組・ファレイの分母・
    # 葉序の角度・IFS の写像・曲線の位数だけで描くので、**画像を 1 枚受け取らない**。
    # 橋が渡す「画像 1 枚」に対応する引数が無いため、橋に載せても恒等を返す
    # 死んだ op が増えるだけになる(台帳からは今までどおり使える)。
    "circle_packing_apollonian", "ford_circles", "phyllotaxis_pattern",
    "ifs_fractal", "ifs_similarity_dimension", "space_filling_curve",
    "geodesic_dome",
    # 2026-09-21: conngraph の states_participation_ratio(matrix → measurement)。画像を行列として実効次数を
    # 出すのは特徴として意味はあるが、橋 1 本のために op 図の全数再描画(50 分)を回す価値が無い。台帳から使う。
    "states_participation_ratio",
    # 2026-09-21: geocam の 2 本(image2d → keypoints / signal)。橋の探針は模様であって空の写真ではない:
    #   太陽の円盤も空と地形の境界も無いので、どちらも ValueError か意味の無い線になる(「走った」≠「意味のある出力」)。
    #   台帳(`fullseye.ledger.sun_pixel_position` / `skyline_extract`)からは写真を渡して使う。
    "sun_pixel_position", "skyline_extract",
    # 2026-10-18 ロバストな断面フィルタ 2 本: 橋が a,b を最初の数値引数(次数 order・定数 c)へ振ると
    # order=2 などの範囲外になり、ガウスの次数は連続量でない(1 次元の断面を 2-D 画像の行から取る意味も無い)。
    # 台帳(`fullseye.ledger.robust_gaussian_profile` …)からは本物の断面を渡して使える。
    "robust_gaussian_profile", "robust_spline_profile",
    # 2026-09-21 実データ回の 2 本: 模様の探針には飽和塊も時刻つきの候補列も無い。
    "sun_bloom_fit", "camera_orientation_from_sun_candidates",
    # 2026-10-14 重力波の 12 本。cavityoptics の 5 本は引数だけで描く側(画像を受けない)。
    # gwsearch の 7 本は入口が「標本化周波数つきの時系列 + 雑音の PSD(pairs)」で、橋が渡す
    # 256 点の正弦 1 本と点の対では走っても意味が無い(「走った」≠「意味のある出力」)。
    # 台帳(`fullseye.ledger.psd_welch` …)からは本物の時系列を渡して使える。
    "fabry_perot_response", "cavity_strain_transfer", "michelson_dc_readout",
    "pdh_error_signal", "quantum_noise_budget",
    "psd_welch", "whiten_by_psd", "chirp_newtonian", "chirp_mass_from_track",
    "matched_filter_snr", "optimal_snr", "coincidence_delay",
    # 2026-10-18 フーリエ・タイコグラフィ 6 本(fourierptycho、fpm): 表(像の組・復元)を作り・受ける側で、画像 → 画像の
    # op ではない。fp_capture は振幅と位相の 2 枚 → 表、fp_element_contrast は画像と表 → 表。台帳(`fullseye.ledger.fp_*`)から使う。
    "fp_design",
    "fp_usaf_target",
    "fp_capture",
    "fp_stack_from_images",
    "fp_reconstruct",
    "fp_element_contrast",
    # 2026-10-15 光干渉断層 13 本(octscan、oct): 表(干渉スペクトル・A スキャン)を受けて表を返す側で、画像 → 画像の
    # op ではない。oct_bscan は表 → 断面像、oct_bscan_boundaries は断面像 → 表。台帳(`fullseye.ledger.oct_*`)から使う。
    "oct_design",
    "oct_dispersion_broadening",
    "oct_interferogram",
    "oct_bscan_simulate",
    "oct_from_spectra",
    "oct_k_linearize",
    "oct_dispersion_estimate",
    "oct_dispersion_compensate",
    "oct_ascan",
    "oct_bscan",
    "oct_layer_thickness",
    "oct_bscan_boundaries",
    "oct_bscan_flatten",
    # 2026-10-15 TDI ラインスキャン 6 本(linescan、linescan): 表を返す側(撮像の linescan_acquire も dict を返す)で、
    # 画像 → 画像の op ではない。台帳(`fullseye.ledger.tdi_snr` …)から使う。
    "tdi_snr",
    "tdi_sync_mtf",
    "linescan_acquire",
    "lens_field_profile",
    "linescan_lens_columns",
    "linescan_lens_example",
    # 2026-10-15 ピクセルシフト(pixelshift): 偽色の量は無彩色かどうかを測る表の op で、橋の汎用 rgbimage(0..1 の
    # 任意の色)に掛けても「入力の色の量」を返すだけ —— 進化の語彙として意味のある手にならない。台帳から使う。
    "false_color_metric",
    # 2026-10-18 光学設計ファイル(.zmx)の読み書き 4 本(lensfile、lensfile): 処方(table)を読む・書く・分類する側で、
    # 画像を受けない。
    "lens_file_read",
    "lens_file_system",
    "lens_file_write",
    "lens_file_report",
    # 2026-10-14 ステップ型ファイバとライトガイド 7 本(fiberoptics、fiber): 引数だけで表か曲線を返す側で、画像を受けない。
    "material_group_index",
    "material_gvd",
    "fiber_numerical_aperture",
    "fiber_v_number",
    "fiber_lp_modes",
    "fiber_mode_field_diameter",
    "fiber_bundle_coupling",
    # 2026-10-15 仮想の透過電子顕微鏡 11 本(temsim、tem): 引数だけで表・CTF・試料を作る側と、投影ポテンシャル / 顕微鏡写真
    # (V Å / 電子の数)を受ける側。一般の画像を投影ポテンシャルと読ませても意味が無いので、台帳から使う。
    "tem_wavelength", "tem_scherzer", "tem_ctf", "tem_ctf_profile", "tem_projected_potential", "tem_amorphous_film",
    "tem_image_weak_phase", "tem_multislice", "tem_power_spectrum", "tem_ctf_estimate", "tem_ctf_correct",
    # 2026-10-15 薄膜の分光反射率と膜厚 5 本(filmoptics、film): 曲線(pairs)か表を返す側。map は帯域画像の列を受けるが
    # 返すのは表(膜厚・残差・候補の数の地図の dict)で、単一画像の op ではない。
    "multilayer_reflectance",
    "film_color",
    "film_thickness_fft",
    "film_thickness_fit",
    "film_thickness_map",
    # 2026-10-15 モアレによる位置合わせ 8 本(moirealign、moire_align): 表を返す設計・換算の側と、位置合わせのマークの像を
    # 作る / 読む側。読む側(moire_phase)は縞の周期を前提にする —— 橋が渡す汎用の画像では縞が無く、意味の無い位相を返すだけ。
    "moire_magnification",
    "moire_talbot_gap",
    "moire_overlay_image",
    "moire_phase",
    "moire_phase_to_shift",
    "moire_differential_shift",
    "moire_mark_read",
    "moire_phase_crlb",
    # 2026-10-15 格子干渉 4 本(gratinginterf、grating_interf): 設計の表・位相ステップの画像列 (N, H, W) を作る側と、
    # 2 組の画像列から 3 像を分ける側。橋が渡す汎用の 1 枚の画像には位相ステップの縞が無い。
    "talbot_grating_design",
    "grating_stepping_simulate",
    "grating_three_image_retrieve",
    "darkfield_scatter_relation",
    # 2026-10-18 第 2 陣: 絨毯と線源は引数だけ、ステップ数の推定は縞の入った画像列、積分は幾何(画素・距離・周期・波長)が要る。
    "talbot_carpet",
    "talbot_source_visibility",
    "grating_step_period_estimate",
    "dpc_integrate",
    # 2026-10-15 クロマティック共焦点 6 本(chromconf、confocal): レンズの処方・較正表・スペクトル(pairs)を受ける側で、
    # 画像を受けない。台帳(`fullseye.ledger.chromatic_confocal_probe` …)から使う。
    "chromatic_confocal_probe",
    "confocal_axial_response",
    "chromatic_confocal_spectrum",
    "chromatic_confocal_peaks",
    "chromatic_confocal_readout",
    "chromatic_confocal_limits",
    # 2026-10-14 光源・フィルタ・センサの分光曲線 9 本(spectralrad、spectral): 曲線(pairs)を作るか掛けるか積む側で、
    # 画像を受けない。台帳(`fullseye.ledger.led_spectrum` …)から使う。
    "blackbody_spectrum",
    "cie_illuminant_a",
    "led_spectrum",
    "bandpass_spectrum",
    "silicon_photodiode_qe",
    "energy_to_photons",
    "spectral_product",
    "spectral_integral",
    "spectral_stats",
    # 2026-10-15 近赤外の分光撮像 8 本(materials 3 + spectralrad 5): 材料名・曲線・帯域の引数だけで曲線か表を返し、
    # 画像を受けない(キューブは spectralrad.hyperspectral_capture_cube)。
    "material_nir_absorption",
    "carbon_black_absorption",
    "nir_model_info",
    "ingaas_photodiode_qe",
    "kubelka_munk_reflectance",
    "spectral_reflectance_from_material",
    "hyperspectral_band_weights",
    "hyperspectral_capture",
    # 2026-10-14 材料の物性ライブラリ 16 本(materials、matprop): 全部が材料名と波長の引数だけで
    # 表か曲線(pairs)を返す側で、画像を受けない。台帳(`fullseye.ledger.material_transmittance` …)から使う。
    "material_table",
    "material_record",
    "material_acoustic",
    "acoustic_impedance_mismatch",
    "material_optical_constants",
    "material_dispersion",
    "material_extinction",
    "material_absorption",
    "material_transmittance",
    "material_reflectance",
    "abbe_number",
    "glass_map",
    "thermo_optic_coefficient",
    "plate_focus_shift",
    "silicon_free_carrier_absorption",
    "material_from_sellmeier",
    "material_from_curves",
    "read_glass_catalog_agf",
    # 2026-09-22 視覚後段と回路: 入口は「行が時刻の個眼動画」「方向別応答」
    # 「配線 + 駆動」で、2-D 画像を渡すと走りはするが意味が無い(探針の
    # 1 枚は時系列ではない)。橋は架けない。
    "fly_lamina_filter", "fly_onoff_split", "fly_t4t5_field",
    "fly_flow_from_directions", "fly_matched_filter",
    "fly_egomotion_from_flow", "fly_eye_merge",
    "graph_conductance_states",
    # 2026-09-22 測地の鎖: 入口は「ジオイド高の格子と緯度経度」「高さの列」で、
    # 2-D 画像を渡すと走りはするが意味が無い(探針の 1 枚は測地格子ではない)。
    "dem_geoid_height", "dem_height_frame_convert", "dem_height_frame_residual",
    "dem_datum_shift_3param", "dem_enu_from_geodetic", "dem_geodetic_from_enu",
    # 2026-09-08、同じ回に摘発。`indices_to_labels` は **1-D の選択マスク**
    # (長さ = 最大添字 + 1)を返すが、宣言型 `labels` は TYPE_TO_SORT で
    # `volume`(ndim == 3 の契約)に畳まれるので、橋は毎回
    # 「op returned (93,) but declared out_sort 'volume'」で fail-soft していた。
    # `labels` という 1 語が **1-D の選択マスク**(reprconv)と **3-D のラベル
    # volume**(vol_label / label_components)の 2 つを指しているのが元。
    # 逆向きの `labels_to_indices` は任意次元を受けるので橋に載ったままでよい。
    # 全 sort 掃引で同類は他に無かった(宣言 out と実際の形が食い違う橋 op は
    # レジストリ 901 本中この 1 件だけ)。
    "indices_to_labels",
    # 2026-09-20: conngraph の状態列 (T, n) → 潜時 (n,)。matrix→labels の写像で自動的に橋が架かり、
    #   画像を「状態列」と読んで (8,) を volume と宣言する退化した op(tb_graph_activation_latency)が
    #   生まれた(全体スイートで 4 門が赤)。状態列は画像ではないので橋を架けない。
    "graph_activation_latency",
    # 2026-09-20: 個眼信号(強度 >= 0)の量子化。signal→signal で自動的に橋が架かるが、橋の探針は正弦(負値)で
    #   拒否され、knob a/b は bits/mode に写らず「効かないノブ」、既定では素通し(pass-through)と判定された。
    #   画像の op ではないので橋を架けない。
    "fly_hex_quantize",
    # 2026-09-21: EM 断面の膜応答(image2d → image2d)。台帳(fullseye.ledger.seg_membrane_response)から
    #   sigma つきで使う op で、橋の knob a/b は sigma に写らず「効かないノブ」になる。橋は架けない。
    "seg_membrane_response",
    # 2026-10-03: Abel 変換は「軸対称な物体の動径分布 f(r)(r = 0 から外へ)」を受ける。signal→signal で
    #   自動的に橋が架かるが、橋が渡すのは画像を潰した 1 本の信号で、中心も半径の向きも持たない
    #   (意味のある出力にならない)。dr も knob a/b に写らない。台帳(fs.ledger.abel_*)から使う。
    "abel_transform", "abel_inverse",
    # 2026-10-03: 特殊関数は「数の列 → 数の列」で、画像の明るさに erf や Bessel を当てる意味が無い
    #   (order / kind も knob a/b に写らない)。台帳(fs.ledger.erf ほか)と fs.<名前> から使う。
    "erf", "erfc", "bessel",
    # 2026-10-05: tacdome の普遍形 κ = (1 − 10/9·d)⁻¹ は「無次元の押し込み d = δ/L の列 → 補正の列」。signal→signal で
    #   自動的に橋が架かるが、橋の探針(正弦・負値を含む)は d ∈ [0, 0.9) の外で fail-closed に拒否され、fallback が
    #   恒等の顔をする(test_no_new_bridge_op_is_a_pass_through が摘発)。画像の op ではない。台帳(fs.ledger)から使う。
    "largedef_universal_correction",
    # 2026-10-05: pegsym の polygon_coverage_image は「多角形の頂点列 (V, 2)(画素座標)→ 被覆率の画像」を描く生成側。matrix→image2d で
    #   自動的に橋が架かるが、橋が渡す行列は画像を行列と読んだもので頂点列ではない(意味のある出力にならない)。台帳から使う。
    "polygon_coverage_image",
    # 2026-10-03: アレイのスナップショットを「作る」生成器(到来角の列 → 複素行列)。画像を受けない。
    "ula_snapshots",
    # 2026-10-03: 行列の指数・対数と SE(3) の exp/log は「行列 ↔ 行列/ベクトル」の代数で、画像を受けない
    #   (画像に expm を当てても意味が無く、logm は負の固有値で拒否する)。
    "mat_expm", "mat_logm", "se3_exp", "se3_log",
    "nurbs_curve", "nurbs_revolve",
    "hilbert_analytic",
    "mat_lu", "mat_qr", "mat_cholesky", "mat_eig",  # 分解は dict を返す(行列 1 枚ではない)                             # 1-D の時系列(画像の行ではない)                 # 制御点の並び(画像でも信号でもない)
    # 2026-11-06: terrain.elevation_map は points → depth で自動的に橋が架かるが、返りはメートルの高さで、点の落ちない
    #   セルは nan(観測していない)。0..1 の画像に詰め直すと単位と「観測していない」が消え、穴が平らな地面に化ける。台帳から使う。
    "elevation_map",
}


#: **op 単位の sort 上書き**。台帳の型を型ごとに畳むのではなく、この op だけ別の sort で
#: 橋渡しする。2026-09-04: sphere_sdf / box_sdf の台帳 in を正しい `coordgrid`
#: (座標場)に直した結果、型ごとの写像 `coordgrid -> points` を入れると
#: **代表値((nx,ny,nz,3))が points の契約(ndim==2, shape[1]==3)を満たさない**
#: (liveness テストが 12/12 で摘発)。一方この 2 op には INPUT_ADAPTERS._points_to_grid
#: が付いていて**点群から座標場を実際に作って**から呼ぶので、2-D 橋での "points" は真。
#: 型ごとに畳むと嘘になり、落とすと points 候補の長さが変わって既存 champion を
#: 黙って書き換える(docs/WAVE0_STABLE_SLOTS.md)。op 単位の上書きが両方を避ける。
_OP_SORT_OVERRIDE = {
    "sphere_sdf": ("points", "volume"),
    "box_sdf": ("points", "volume"),
    "plane_sdf": ("points", "volume"),
    "cylinder_sdf": ("points", "volume"),
    "torus_sdf": ("points", "volume"),
    "capsule_sdf": ("points", "volume"),
}


_NEW_SORTS = frozenset({"points", "signal", "matrix", "cimage",
                        "lightfield", "counts",
                        "rgbimage", "video", "qimage", "beatcube",
                        "keypoints"})


def _coerce(value, sort):
    """カタログ op の返りを進化側が扱える形へ正規化する。

    torch backend を持つ op は Tensor を返す(実測: ``edt_jfa``)。進化の
    ``_apply`` は ndarray 前提なので numpy へ落とす。dict/tuple を返す op は
    宣言 out 型に応じてカタログ側の adapter が既に整えている前提で、ここでは
    残る入れ物だけをほどく。
    """
    if hasattr(value, "detach") and hasattr(value, "cpu"):     # torch.Tensor
        value = value.detach().cpu().numpy()
    if isinstance(value, tuple) and value:
        value = value[0]
    if sort == "feature":
        try:
            return float(np.asarray(value, np.float64).ravel()[0])
        except (TypeError, ValueError, IndexError):
            return 0.0
    return np.asarray(value)


#: sort ごとの**形の契約**。分岐を積むより表に置く —— sort を 1 つ足すたびに
#: ``_sort_ok`` / ``_fallback`` / ``TYPE_TO_SORT`` の 3 箇所へ ``if`` を書き足す形
#: だったので、どこか 1 つ書き忘れても**例外にならず fail-soft に落ちるだけ**で
#: 気づけなかった(keypoints がまさにそれで、4 op が黙って死んでいた)。
#: 表にしておけば「この sort の行が無い」が一目で分かり、テストからも回せる。
_SHAPE_OK = {
    "volume": lambda v: v.ndim == 3,
    "image": lambda v: v.ndim == 2,
    "points": lambda v: v.ndim == 2 and v.shape[1] == 3,
    "keypoints": lambda v: v.ndim == 2 and v.shape[1] == 2,
    "signal": lambda v: v.ndim == 1,
    "matrix": lambda v: v.ndim == 2,
    "cimage": lambda v: v.ndim == 2 and v.dtype.kind == "c",
    # rgbimage = (H,W,3)、qimage = (H,W,4)。2026-09-02 までどちらも行が無く、
    # ``tb_quaternion_to_rgb``(qimage → rgbimage)が失敗すると ``_fallback`` が
    # 表に無い out_sort の既定 ``np.asarray(v)`` = **4 チャンネルの入力をそのまま
    # rgbimage として返していた**(乱数の (H,W,4) は非純四元数なので quatimage 側の
    # 番人が必ず拒否する → 毎回この経路)。同 sort の恒等検査には掛からず、
    # 形の検査にも行が無いので 4 チャンネルがそのまま通った。行を足すと
    # 4 チャンネルの返りは契約違反として弾かれ、失敗時は下の空値へ落ちる。
    "rgbimage": lambda v: v.ndim == 3 and v.shape[2] == 3,
    "qimage": lambda v: v.ndim == 3 and v.shape[2] == 4,
}


def _sort_ok(value, sort):
    """*value* が *sort* の形の契約を満たすか。

    進化の ``_apply`` は sort を信じて次の op を選ぶので、ここで形まで保証しないと
    嘘が下流へ漏れて**無関係な op** で落ちる。ファザーの ``TYPE_CHECKS`` と同じ
    考え方(宣言と実際の一致を機械検証する)を橋の出口にも置く。
    表に無い sort は「形の制約なし」= 配列であれば通す。
    """
    if sort == "feature":
        return isinstance(value, float)
    if not isinstance(value, np.ndarray) or value.dtype.kind not in "fciub":
        return False
    check = _SHAPE_OK.get(sort)
    return True if check is None else bool(check(value))


def _fallback(v, in_sort, out_sort):
    """fail-soft の戻り値。**宣言した out_sort に合う値**でなければならない。

    最初は「入力をそのまま返す」実装だったが、これは **out_sort が in_sort と
    違う op で型の嘘になる**。実測 2026-09-01: points→volume の橋渡し op が
    失敗したとき (N,3) の点群が返り、パイプラインはそれを volume と信じて次の
    ``vol_slice`` が ``IndexError: tuple index out of range`` で落ちた
    (fail-soft のはずが、失敗を 1 段先へ運んで別の場所で壊す形になっていた)。

    同型なら入力を通す(情報を保つ)。型が変わる op では **その sort の最小限
    妥当な値**を返す — 内容は無いが、下流の型契約は満たす。
    """
    if out_sort == "feature":
        try:
            arr = np.asarray(v, np.float64)
        except (TypeError, ValueError):
            return 0.0
        if arr.size == 0:
            # ★2026-10-07: 空入力を op が**正しく拒否した後**、ここが空配列の平均 = NaN を返して
            #   いた(8 op。外側の guard が置き換えるので有限に見え、台帳にだけ source=output で
            #   残っていた)。拒否の後始末が 0/0 を作らないよう、空なら 0.0。
            return 0.0
        return float(np.mean(arr))
    if in_sort == out_sort:
        return np.asarray(v)
    return _EMPTY_OF.get(out_sort, lambda: np.asarray(v))()


#: 型が変わる op の失敗時に返す「中身は無いが sort として妥当な値」。
#: :data:`_SHAPE_OK` と**対**になる表で、片方に行を足したらもう片方にも要る
#: (両方に無いと fail-soft が sort 契約を破り、下流の無関係な op で落ちる)。
_EMPTY_OF = {
    "volume": lambda: np.zeros((2, 2, 2), np.float64),
    "image": lambda: np.zeros((2, 2), np.float64),
    "points": lambda: np.zeros((1, 3), np.float64),
    "keypoints": lambda: np.zeros((1, 2), np.float64),
    "signal": lambda: np.zeros(2, np.float64),
    "matrix": lambda: np.zeros((2, 2), np.float64),
    "cimage": lambda: np.zeros((2, 2), np.complex128),
    "rgbimage": lambda: np.zeros((2, 2, 3), np.float64),
    "qimage": lambda: np.zeros((2, 2, 4), np.float64),
}


def _points_to_grid(v, res=16, margin=0.15):
    """点群 (N,3) → その境界箱を覆う座標格子 (res,res,res,3)。

    ``box_sdf`` / ``sphere_sdf`` は「``(..., 3)`` の座標を受け、その形から最後の軸を
    落として距離を返す」**要素ごと**の op なので、点群 (N,3) を渡すと (N,) が返る。
    宣言している out_sort は ``volume`` なので形の検査に落ち、``_fallback`` が
    ``zeros((2,2,2))`` を返す —— つまりこの 2 op は **候補枠を 2 つ占めたまま、
    どんな入力でも定数ゼロしか返していなかった**(2026-09-02 実測: 40 通りの
    点群すべてで返りが ``zeros((2,2,2))``、非ゼロ 0 件)。

    宣言 ``points → volume`` を素直に読めば「その点群が収まる領域に、この原始形状の
    距離場を焼く」であり、それには**座標格子**が要る。ここで作る。
    ``margin`` は境界箱の外側に取る余白(比率)で、これが無いと形状の外側が
    切れて距離場の符号が片側しか出ない。
    """
    P = np.asarray(v, np.float64)
    if P.ndim != 2 or P.shape[1] != 3 or P.shape[0] < 1 or not np.isfinite(P).all():
        raise ValueError("points must be a finite (N, 3) cloud")
    lo, hi = P.min(axis=0), P.max(axis=0)
    span = np.maximum(hi - lo, 1e-9)
    lo = lo - margin * span
    hi = hi + margin * span
    axes = [np.linspace(lo[k], hi[k], int(res)) for k in range(3)]
    return np.stack(np.meshgrid(*axes, indexing="ij"), axis=-1)


#: 入口の値を op が実際に取れる形へ直す表(op 名 → 変換)。**ADAPTERS が返りを
#: 直すのに対し、こちらは入力を直す**。捏造ではなく、宣言した in_sort の値から
#: op の要求する表現へ写すだけのものに限る。
INPUT_ADAPTERS = {
    "box_sdf": _points_to_grid,
    "sphere_sdf": _points_to_grid,
    "plane_sdf": _points_to_grid,
    "cylinder_sdf": _points_to_grid,
    "torus_sdf": _points_to_grid,
    "capsule_sdf": _points_to_grid,
}


#: bridge の tunable 選定(既定 = 正の数値既定を持つ先頭 2 引数)を op ごとに
#: 上書きする。既定ヒューリスティックが「効きの薄い引数」を選び、判別軸になる
#: 引数を素通ししてしまう op のための逃げ道。値は tune したい引数名(最大 2、
#: a→[0], b→[1])。**公開 op の既定値は変えない**(進化ブリッジ内部だけの選択)。
#: running_gaussian_foreground: 検出感度は初期分散 var_init が支配し(既定 0.01 は
#: サブピクセル並進の合成クリップの信号 std^2≈1.8e-4 に対して過大で、k/alpha を
#: いくら振っても前景が出ない)、学習率 alpha はほぼ効かない。k と var_init を
#: 振ると弱信号でも到達できる(2026-09-03 実測)。
#: dynsys_correlation_dimension: 既定ヒューリスティックは正の数値既定を持つ先頭 2 つ
#: = (n_radii, max_points) を取るが、**max_points は探針では答えを 1 桁も動かさない**
#: (探針の点群がどの上限より小さいため。実測 2026-09-23: 1,000 / 4,000 / 8,000 で
#: 2.637035 のまま)。答えを動かすのは n_radii(6 → 42 で 2.678 → 2.632)と、
#: ★本当に効く r_lo / r_hi(半径の窓)だが、後者は既定が None で「データから決める」
#: 意味なので、正の数値既定を要求する橋の選定には載らない。嘘のノブを 1 本足すより
#: **a だけを配線して b を『未使用』と書く**ほうが正しい。
OP_TUNABLE_OVERRIDE = {
    "running_gaussian_foreground": ("k", "var_init"),
    "dynsys_correlation_dimension": ("n_radii",),
}

#: 相対スケール(既定の 1/4〜2 倍)が **定義域を突き抜ける** 引数の絶対範囲。
#: ``(op 名, 引数名) → (下限, 上限)``、ノブ ∈ [0,1] を線形に写す。
#: 実測 2026-09-07: ``wetness`` の ``wet`` は既定 1.0 で定義域 [0,1] なので、
#: 相対スケールだと a > 0.43 で ``wet = 1.125`` になり ValueError → fail-soft の
#: 空値。**つまみの半分以上で必ず失敗する op** が台帳に載っていた
#: (図の生成で発見。「どのノブでも死ぬ op」の親戚)。定義域が分かっている
#: 引数はここに書く —— 推測はしない(コードが拒否する範囲を写す)。
OP_KNOB_RANGE = {
    ("wetness", "wet"): (0.0, 1.0),
    ("wetness", "ior"): (1.01, 2.5),     # 水膜の屈折率。コードは ior > 1 を要求(既定 1.33)
    # ★2026-10-07: 相対スケールの端が定義域の外へ出ていた 2 本(契約電池で、端の knob が
    #   **全入力で**拒否されていた)。両端は a=0.5 の値が相対スケールと同じになるよう選んだ
    #   (window 10 / k 3)—— 既定の挙動と図の主図は動かない。整数の既定を持つ引数は
    #   ``_make_runner`` が整数に丸めて渡す。
    ("local_std", "window"): (3, 17),    # dsp.local_std は window >= 3(相対スケールだと a=0 で 2)
    ("fit_spline_curve", "k"): (1, 5),   # scipy splprep は 1 <= k <= 5(相対スケールだと a=1 で 6)
    # ★2026-10-18: points_render の不透明度は (0, 1] —— 既定 1.0 の相対スケールは a > 0.5 で 1 を超えて拒否。
    #   足跡の半径は 0.5〜4 画素(a=0.5 で 2.25)。
    ("points_render", "radius_px"): (0.5, 4.0),
    ("points_render", "opacity"): (0.1, 1.0),
}


#: 束縛を**呼び出しのたびに入力から作る**引数(op 名 → ``builder(v, a, b) -> dict``)。
#: ``typed_catalog.OP_PARAM_HINTS`` は登録時に 1 回だけ値を引くので、**入力の形に合わせる
#: 必要がある引数**(スペクトルと同じ形の伝達関数、動画の長さで決まる DFT ビン)は表せない。
#: builder が返した dict は knob の写しの後で ``kw`` に上書きされる。空 dict = 束縛済みの
#: 値のまま(形が不正な入力は op 本体の明示の拒否文に任せる)。
#:
#: ★2026-10-07 実測: ``tb_cx_apply_transfer_function`` は H を 32x32 固定で束縛していたので
#: 32x32 以外のスペクトルでは**全入力・全 knob で**拒否していた(契約電池 24x24、図 128x128)。
#: ``tb_temporal_band_power`` / ``tb_temporal_bandpass`` は帯域 [3, 5] Hz 固定で、12 フレーム /
#: 32 fps の探針(ビン間隔 2.67 Hz)には帯域内のビンが無く、契約電池で一度も計算されていなかった。
_TEMPORAL_FPS = 32.0      # typed_catalog.PARAM_HINTS["fps"] と同じ値(帯域はビンで決めるので値自体は効かない)


def _centred_gaussian_lowpass(v, a, b):
    """``cx_apply_transfer_function`` の H を**スペクトルと同じ形**で作る(中心化ガウス低域通過)。

    ``H = exp(-r^2 / (2 sigma^2))``、``r`` は中心化した周波数(cycles/pixel、``cx_fft`` の
    規約 = DC が中央)、``sigma = 0.02 + 0.48 a``。``b`` は使わない。
    """
    f = np.asarray(v)
    if f.ndim != 2 or 0 in f.shape:
        return {}
    h, w = f.shape
    sigma = 0.02 + 0.48 * float(np.clip(a, 0.0, 1.0))
    fy = np.fft.fftshift(np.fft.fftfreq(h))
    fx = np.fft.fftshift(np.fft.fftfreq(w))
    r2 = fy[:, None] ** 2 + fx[None, :] ** 2
    return {"H": np.exp(-0.5 * r2 / sigma ** 2)}


def _temporal_band_from_knobs(v, a, b):
    """時間帯域 ``[f_lo, f_hi]`` を**その動画自身の DFT ビン**から選ぶ。

    非 DC のビンは ``k = 1 .. K``(``K = T // 2``、``T`` = フレーム数)。``a`` が中心のビン
    ``kc = 1 + round(a (K - 1))``、``b`` が片側の幅 ``hw = round(b (K - 1) / 2)`` を決め、
    帯域の端を選んだビンの**半ビン外側**に置く(``f_lo = (k_lo - 0.5) df``、
    ``f_hi = min((k_hi + 0.5) df, fps/2)``、``df = fps / T``)。よって ``T >= 2`` なら
    帯域には必ず 1 本以上のビンが入り、``f_lo > 0``(DC を含まない)、``f_hi <= fps/2``
    (ナイキストを超えない)という op の 3 つの拒否条件にも触れない。
    ``T < 2`` は空 dict を返し、op 本体の明示の拒否(時間周波数が定義されない)に任せる。
    """
    t = int(np.shape(v)[0]) if np.ndim(v) >= 1 else 0
    k_max = t // 2
    if k_max < 1:
        return {}
    df = _TEMPORAL_FPS / t
    kc = 1 + int(np.floor(float(np.clip(a, 0.0, 1.0)) * (k_max - 1) + 0.5))
    hw = int(np.floor(float(np.clip(b, 0.0, 1.0)) * (k_max - 1) / 2.0 + 0.5))
    k_lo, k_hi = max(1, kc - hw), min(k_max, kc + hw)
    return {"f_lo": (k_lo - 0.5) * df,
            "f_hi": min((k_hi + 0.5) * df, 0.5 * _TEMPORAL_FPS),
            "fps": _TEMPORAL_FPS}


CALL_TIME_ARGS = {
    "cx_apply_transfer_function": _centred_gaussian_lowpass,
    "temporal_band_power": _temporal_band_from_knobs,
    "temporal_bandpass": _temporal_band_from_knobs,
}

_TEMPORAL_KNOB_JA = (
    "``a`` がその動画自身の非 DC の DFT ビンから通過帯域の中心を選び(0 = 最低のビン、"
    "1 = ナイキストのビン)、``b`` が片側の幅を決める(0 = 1 ビン、1 = 片側に半分)。帯域の端は"
    "選んだビンの半ビン外側に置く(フレームレートは 32 fps 固定)ので、2 フレーム以上の動画なら"
    "帯域には必ずビンが入る。(2026-10-07 まで帯域は 3〜5 Hz 固定で、12 フレームの動画では"
    "ビンが 1 本も入らず毎回拒否していた。)")
_TEMPORAL_KNOB_EN = (
    "``a`` picks the centre of the pass-band among the clip's own non-DC DFT bins "
    "(0 = the lowest bin, 1 = the Nyquist bin) and ``b`` its half-width (0 = one bin, "
    "1 = half the bins on each side). The band edges sit half a bin outside the chosen bins "
    "(frame rate fixed at 32 fps), so the band holds at least one bin for any clip of two or "
    "more frames. (Until 2026-10-07 the band was a fixed 3-5 Hz, which holds no bin for a "
    "12-frame clip, so every call was refused.)")

#: 橋の説明の「a / b が何を振るか」の文を差し替える表(op 名 → (日本語, 英語))。
#: 呼び出し時の束縛(``CALL_TIME_ARGS``)や返りの変換(``OUTPUT_ADAPTERS_WITH_INPUT``)で
#: 既定の文(「a も b も使われない」等)が嘘になる op のためのもの。中括弧は書かないこと
#: (``str.format`` を通る)。
BRIDGE_KNOB_DOC = {
    "cx_apply_transfer_function": (
        "``a`` が伝達関数 ``H`` の幅を振る。橋は H を**呼び出しのたびにスペクトルと同じ形で**作る: "
        "中心化ガウス低域通過 ``H = exp(-r^2 / (2 sigma^2))``、``sigma = 0.02 + 0.48 a`` "
        "cycles/pixel(a=0.5 で 0.26)。``b`` は未使用。(2026-10-07 まで H は登録時に 32x32 固定で"
        "束縛され、それ以外の大きさの画像では毎回拒否していた。)",
        "``a`` sets the width of the transfer function ``H``, which the bridge builds **per call "
        "at the spectrum's own shape**: a centred Gaussian low-pass ``H = exp(-r^2 / (2 sigma^2))`` "
        "with ``sigma = 0.02 + 0.48 a`` cycles/pixel (0.26 at a=0.5). ``b`` is unused. (Until "
        "2026-10-07 ``H`` was bound once as a fixed 32x32 array, so every other image size was "
        "refused.)"),
    "temporal_band_power": (_TEMPORAL_KNOB_JA, _TEMPORAL_KNOB_EN),
    "temporal_bandpass": (_TEMPORAL_KNOB_JA, _TEMPORAL_KNOB_EN),
    "normals_to_egi": (
        "``a`` が ``n_az``(既定 36)、``b`` が ``n_el``(既定 18)を振る。★橋の op は計数を"
        "総数で割った**割合**(各 bin に入った法線の比率、和 1、値域 [0,1])を返す —— 宣言 sort "
        "``image`` の [0,1] 契約に合わせるため(計数のままだと最大 48 などが出ていた、2026-10-07)。"
        "生の計数は ``reprconv.normals_to_egi`` / ``fullseye.ledger.normals_to_egi`` が返す。",
        "``a`` drives ``n_az`` (default 36) and ``b`` drives ``n_el`` (default 18). The bridged "
        "op returns the **fraction** of normals per bin (counts divided by the total; sums to 1, "
        "range [0, 1]) to honour the ``image`` sort's unit range. The raw counts are returned by "
        "``reprconv.normals_to_egi`` / ``fullseye.ledger.normals_to_egi``."),
}


def _point_labels_to_volume(points, labels, res=16):
    """点ごとのラベル ``(N,)`` を、その点群を覆う**ラベル体積** ``(res,res,res)`` にする。

    台帳が ``points → labels`` と宣言する点群セグメンテーション 3 op
    (``region_growing`` / ``euclidean_cluster`` / ``plane_segmentation``)は
    **点ごとの (N,) ラベル**を返す。ところが ``labels`` という型名は、この
    ライブラリでは 3-D のラベル体積も指しており(``TYPE_TO_SORT['labels'] =
    'volume'``)、進化側は 3 次元を要求する。結果、この 3 op は形の検査に落ちて
    ``_fallback`` の ``zeros((2,2,2))`` を返し続けていた —— 2026-09-02 実測で、
    40 通りの点群すべてで返りが定数ゼロ、非ゼロ 0 件。**候補枠を占めながら
    一度も仕事をしていなかった。**

    ファザー側の ``TYPE_CHECKS['labels']`` は 1/2/3 次元すべてを許す緩い述語なので、
    この食い違いは**ファザーからは見えない**。厳しい側(進化の sort 契約)だけが
    弾き、しかも fail-soft なので誰にも気づかれなかった。

    ここでは宣言を動かさずに真にする: 点を境界箱の格子へ落とし、各ボクセルに
    そこへ落ちた点の**最大ラベル**を入れる(空ボクセルは 0)。「点群を分割して
    その区分けを体積に焼く」は素直な読み方で、``points → labels(体積)`` が
    そのまま成り立つ。宣言を変えないので進化の decode(候補リストと out_sort)は
    1 ビットも動かない。
    """
    P = np.asarray(points, np.float64)
    lab = np.asarray(labels).reshape(-1)
    if P.ndim != 2 or P.shape[1] != 3 or lab.size != P.shape[0]:
        raise ValueError("expected (N,3) points and (N,) labels, got %r and %r"
                         % (P.shape, lab.shape))
    r = int(res)
    lo, hi = P.min(axis=0), P.max(axis=0)
    span = np.maximum(hi - lo, 1e-9)
    idx = np.clip(((P - lo) / span * (r - 1)).astype(np.int64), 0, r - 1)
    flat = (idx[:, 0] * r + idx[:, 1]) * r + idx[:, 2]
    # 未割当(負)は 0 に寄せる。ラベルは 1 起点に持ち上げて「空」と区別する。
    vals = np.where(lab < 0, 0, lab.astype(np.int64) + 1)
    vol = np.zeros(r ** 3, np.int64)
    np.maximum.at(vol, flat, vals)
    return vol.reshape(r, r, r).astype(np.float64)


def _egi_counts_to_fraction(normals, counts):
    """拡張ガウス像の**計数**を**割合**(和 1、[0,1])にする —— 宣言 sort ``image`` の値域契約。

    ``reprconv.normals_to_egi`` は bin ごとの計数を返す(公開関数の仕様。総和 = 法線の本数で、
    ``tests/test_type_alias_ledger.py`` がそれを使う)ので、公開関数は変えずに橋の出口でだけ
    割る。2026-10-07 実測: 探針 two_clusters で最大 48、plane_only で 17 —— ``image`` を名乗り
    ながら [0,1] を外れていた。
    """
    h = np.asarray(counts, np.float64)
    total = float(h.sum())
    if not (np.isfinite(total) and total > 0.0):
        raise ValueError("normals_to_egi: the histogram holds no normals — "
                         "the per-bin fraction is 0/0")
    return h / total


#: 返りを**入力と一緒に**見て直す表(op 名 → ``fn(入力, 返り)``)。
#: ``ADAPTERS`` は返りだけを見るので、入力が要る変換はこちらに置く。
OUTPUT_ADAPTERS_WITH_INPUT = {
    "region_growing": _point_labels_to_volume,
    "euclidean_cluster": _point_labels_to_volume,
    "plane_segmentation": _point_labels_to_volume,
    "normals_to_egi": _egi_counts_to_fraction,
}


def _scaled(default, knob):
    """著者の既定値を中心にした相対スケール(既定の 1/4 〜 2 倍)。

    整数既定は整数へ丸め、最低 1 を保証する(近傍数 k=0 のような無意味な値を
    作らない)。範囲の根拠はモジュール docstring を参照。
    """
    val = float(default) * (0.25 + 1.75 * float(knob))
    if isinstance(default, int):
        return max(1, int(round(val)))
    return val


#: 橋渡しした op の説明文。**原文の言語に合わせて**足す —— 英語の docstring に
#: 日本語の段落を継ぐと、``tools/opdocs.py`` の「訳が無い」判定(本文に日本語が
#: あるか)が誤って満たされ、未訳の英語本文に注意書きが出なくなる。
_BRIDGE_JA = ("2-D 進化レジストリへ橋渡しした {dim} の op ``{name}``。実装は同じで、"
              "呼び出し規約だけ ``op(v, a, b)`` に合わせてある。{knobs}")
_BRIDGE_EN = ("Typed bridge of the {dim} op ``{name}`` into the 2-D evolution registry: "
              "the same implementation, called under the ``op(v, a, b)`` convention. {knobs}")
_KNOB_JA = {0: "この op に調整点は無く、``a`` も ``b`` も使われない。",
            1: "``a`` が ``{p0}``(既定 {d0})を振る。``b`` は未使用。",
            2: "``a`` が ``{p0}``(既定 {d0})、``b`` が ``{p1}``(既定 {d1})を振る。"}
_KNOB_EN = {0: "This op has no tunable parameter; ``a`` and ``b`` are unused.",
            1: "``a`` drives ``{p0}`` (default {d0}); ``b`` is unused.",
            2: "``a`` drives ``{p0}`` (default {d0}) and ``b`` drives ``{p1}`` (default {d1})."}


def _bridge_doc(fn, name, dim, tunable, knob_note=None):
    """橋の op の説明 —— 元の docstring に、``a``/``b`` が何を振るかを継ぐ。

    元が無説明なら ``None``(嘘の説明を捏造するより「説明なし」の方が正しい)。
    """
    # ★cleandoc で共通の字下げを外してから継ぐ(2026-10-11)。.strip() だけだと 1 行目以外が 4 字下げのまま残り、
    # 字下げの無い橋渡し文を後ろに足すため後段の cleandoc も最小字下げ 0 と見て外さない →
    # docs/ops の Markdown で空行の後の本文がコードブロックとして表示されていた(tb_ 146 本)。
    import inspect                                        # noqa: PLC0415
    base = inspect.cleandoc(getattr(fn, "__doc__", None) or "").strip()
    if not base:
        return None
    ja = any("぀" <= ch <= "ヿ" or "一" <= ch <= "鿿" for ch in base)
    if knob_note is not None:                             # BRIDGE_KNOB_DOC の差し替え
        kn = knob_note[0] if ja else knob_note[1]
    else:
        kn = (_KNOB_JA if ja else _KNOB_EN)[len(tunable)]
    slot = {}
    for i, (pname, default) in enumerate(tunable):
        slot["p%d" % i] = pname
        slot["d%d" % i] = ("%g" % default) if isinstance(default, float) else str(default)
    note = (_BRIDGE_JA if ja else _BRIDGE_EN).format(
        dim=dim, name=name, knobs=kn.format(**slot))
    return "%s\n\n%s" % (base, note)


def _make_runner(fn, kwargs, tunable, in_sort, out_sort, doc=None, knob_ranges=None,
                 call_time=None):
    """``fn(v, a, b)`` 規約のランナー。

    *tunable* は ``[(param 名, 既定値), ...]`` を最大 2 個(a に第 1、b に第 2)。
    空なら a, b は未使用(その op には調整点が無い)。
    *knob_ranges* は ``{param 名: (lo, hi)}`` —— :data:`OP_KNOB_RANGE` に載る引数は
    相対スケールでなく ``lo + (hi - lo) * knob`` で写す(定義域を突き抜けない)。
    *doc* は橋渡し元の説明(:func:`_bridge_doc`)—— 渡さないと、カタログ側が
    ちゃんと書いた説明がラッパで消えて「説明なし」の op が 143 本できる。
    """
    # 記録名は `_run.__qualname__` を見る。`ops._label_guarded_functions_with_their_op_name`
    # が登録時に本名を書き込むので、ファサードを通さない直接呼び出しでも
    # 「どの op が劣化したか」が残る(素の None だと `?` に潰れる)。
    ranges = dict(knob_ranges or {})

    def _run(v, a, b):
        kw = dict(kwargs)
        for (pname, default), knob in zip(tunable, (a, b)):
            if pname in ranges:
                lo, hi = ranges[pname]
                val = lo + (hi - lo) * float(np.clip(knob, 0.0, 1.0))
                # 整数の既定を持つ引数(窓長・次数)は整数で渡す(四捨五入、決定的)
                kw[pname] = int(np.floor(val + 0.5)) if isinstance(default, int) else val
            else:
                kw[pname] = _scaled(default, knob)
        try:
            if call_time is not None:                     # CALL_TIME_ARGS: 入力の形に合わせる束縛
                kw.update(call_time(v, a, b))
            got = _coerce(fn(v, **kw), out_sort)
        except __import__("backend_safe").MissingDependencyError:   # fail-closed: no stand-in value
            raise
        except Exception as _e:                           # noqa: BLE001 - fail-soft, RECORDED
            from backend_safe import is_strict, record
            if is_strict():
                raise
            record(getattr(_run, "__qualname__", None), _e, out_sort)
            return _fallback(v, in_sort, out_sort)
        # 型の嘘も fail-soft と同じ扱い。**形まで検証する**のが要点で、
        # 「ndarray かどうか」では足りない: 宣言 volume の op が 2-D を返すと、
        # 下流の vol_* が「次元が合わない」と落ちて**無関係な場所で**失敗が
        # 顕在化する(実測 2026-09-01: scipy binary_dilation の
        # "structure and input must have same dimensionality")。
        if not _sort_ok(got, out_sort):
            # a "type lie" (declared out_sort, wrong shape/kind) is a bug in the bridged
            # op, not an absence: record it so the ledger can count it (strict re-raises)
            from backend_safe import is_strict, record
            err = TypeError("typed bridge: op returned %s but declared out_sort %r"
                            % (getattr(got, "shape", type(got).__name__), out_sort))
            if is_strict():
                raise err
            record(getattr(_run, "__qualname__", None), err, out_sort)
            return _fallback(v, in_sort, out_sort)
        return got
    _run.__doc__ = doc
    return _run


def _catalog_entries():
    """(name, dim, in_types, out_type, fn) をカタログから集める。

    ``tools/chain_fuzz`` の ``catalog()`` を単一の真実源として使う — カタログの
    定義が増えた(optics 等)ときに、こちらを直さなくても橋が伸びる。
    """
    # ★2026-09-05 まで ``tools/chain_fuzz``(非同梱)を sys.path 操作で読んでいた。
    # wheel では失敗し、下の build() が黙って [] を返すので tb_* 143 op が消えていた。
    import typed_catalog                                  # noqa: PLC0415
    return typed_catalog


def build(Op, IMAGE, REGION, FEATURE, CONTOUR, _norm, _bin):
    """進化レジストリへ足す Op のリストを返す(カタログが読めなければ例外)。"""
    # 失敗は**握らない**。ops.py の登録ループが例外を FAILED_BACKENDS に記録する ——
    # ここで [] を返すと「backend は生きているが op が 0 本」に見え、台帳が沈黙する。
    cf = _catalog_entries()
    wide = os.environ.get("IMGEVOLVE_WIDE_VOCAB", "") == "1"
    hint_names = set(cf.PARAM_HINTS)
    out = []
    try:
        entries = cf.catalog()
    except Exception:                                     # noqa: BLE001
        return []
    import inspect                                        # noqa: PLC0415
    rng = np.random.default_rng(0)                        # ヒントは決定的に引く
    for name, dim, ins, out_type, fn in entries:
        if len(ins) != 1:
            continue                                      # 多入力は別の合成モデル
        if name in _OP_BRIDGE_SKIP:
            continue                                      # 定義域が合わない(上の表)
        override = _OP_SORT_OVERRIDE.get(name)
        if override is not None:
            in_sort, out_sort = override
        else:
            in_sort = TYPE_TO_SORT.get(ins[0])
            out_sort = TYPE_TO_SORT.get(out_type)
        if in_sort is None or out_sort is None:
            continue
        if in_sort not in _NEW_SORTS and not wide:
            continue                                      # 既存 sort は opt-in のみ
        try:
            sig = inspect.signature(fn)
        except (TypeError, ValueError):
            continue
        params = [p for p in sig.parameters.values()
                  if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)]
        kwargs, ok, tunable = {}, True, []
        want = OP_TUNABLE_OVERRIDE.get(name)              # 指定があればその引数だけ振る
        for p in params[1:]:
            if p.default is not inspect.Parameter.empty:
                # 正の数値既定 = 進化が触れる調整点(最大 2 個を a, b に割り当て)
                numeric = (isinstance(p.default, (int, float))
                           and not isinstance(p.default, bool)
                           and p.default > 0)
                pick = (p.name in want) if want is not None else numeric
                if numeric and pick and len(tunable) < 2:
                    tunable.append((p.name, p.default))
                continue
            hint = cf.OP_PARAM_HINTS.get((name, p.name))
            if hint is None and p.name in hint_names:
                hint = cf.PARAM_HINTS[p.name]
            if hint is None:
                ok = False
                break                                     # 既定値を捏造しない
            val = hint(rng)
            if val is None:
                ok = False
                break
            kwargs[p.name] = val
        if not ok:
            continue
        adapter = cf.ADAPTERS.get(name)
        base = fn if adapter is None else (
            lambda *a, _f=fn, _ad=adapter, **k: _ad(_f(*a, **k)))
        pre = INPUT_ADAPTERS.get(name)
        if pre is not None:
            base = (lambda v, *a, _f=base, _pre=pre, **k: _f(_pre(v), *a, **k))
        post = OUTPUT_ADAPTERS_WITH_INPUT.get(name)
        if post is not None:
            base = (lambda v, *a, _f=base, _post=post, **k: _post(v, _f(v, *a, **k)))
        ranges = {pn: OP_KNOB_RANGE[(name, pn)] for pn, _d in tunable
                  if (name, pn) in OP_KNOB_RANGE}
        out.append(Op("tb_" + name, "typed", "", in_sort, out_sort,
                      _make_runner(base, kwargs, tunable, in_sort, out_sort,
                                   doc=_bridge_doc(fn, name, dim, tunable,
                                                   knob_note=BRIDGE_KNOB_DOC.get(name)),
                                   knob_ranges=ranges,
                                   call_time=CALL_TIME_ARGS.get(name))))
    return out
