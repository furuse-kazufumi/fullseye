"""カメラ校正の幾何(HALCON "Calibration" chapter の genuine core, numpy).

3D アフィン変換、放射歪みの画像適用、カメラ内部パラメータ+ポーズ→4x4 行列。純粋な幾何式。
"""
from __future__ import annotations

import numpy as np
from scipy import ndimage


def affine_trans_point_3d(points, H=None) -> np.ndarray:
    """3D 点に 4x4 同次アフィン変換を適用(affine_trans_point_3d)。"""
    p = np.asarray(points, dtype=np.float64).reshape(-1, 3)
    H = np.eye(4) if H is None else np.asarray(H, dtype=np.float64)
    # 従来どおり射影変換の最終行と w 除算は扱わない。
    out = np.empty((len(p), 3), dtype=np.result_type(p, H))
    np.matmul(p, H[:3, :3].T, out=out)
    out += H[:3, 3]
    return out


def cam_par_pose_to_hom_mat3d(pose) -> np.ndarray:
    """カメラポーズ [rx,ry,rz(rad), tx,ty,tz] を 4x4 同次変換行列に変換(cam_par_pose_to_hom_mat3d)。"""
    rx, ry, rz, tx, ty, tz = (float(x) for x in pose)
    cx, sx = np.cos(rx), np.sin(rx)
    cy, sy = np.cos(ry), np.sin(ry)
    cz, sz = np.cos(rz), np.sin(rz)
    Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
    Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    R = Rz @ Ry @ Rx
    H = np.eye(4)
    H[:3, :3] = R
    H[:3, 3] = [tx, ty, tz]
    return H



def change_radial_distortion_cam_par(cam_par, kappa_new: float = 0.0) -> np.ndarray:
    """カメラパラメータの放射歪み係数を kappa_new に置換(change_radial_distortion_cam_par)。"""
    cp = np.array(cam_par, dtype=np.float64).copy()
    if len(cp) >= 2:
        cp[1] = kappa_new                                 # 慣例: [focal, kappa, ...]
    return cp
