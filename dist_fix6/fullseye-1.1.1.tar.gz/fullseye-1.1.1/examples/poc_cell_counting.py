# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""重なった細胞をどう数えるか —— 個数・過分割・過統合を別々に測る。

EXTEND: 実際の顕微鏡画像に差し替えるなら ``make_scene()`` が返す辞書の
``img``(観測画像)と ``owner``(画素ごとの「どの細胞のものか」ラベル)の対を、
撮影画像と手作業ラベルに置き換える。**真値はラベル画像だけでは足りない** ——
この PoC のいちばん重要な軸(どれとどれが重なっているか、隠れた面積はどれだけか)は
ラベル画像には残らないので、``cells`` 表(中心・長短径・傾き)も一緒に持つこと。
手作業で作れないなら、重なりの軸は測れないと正直に書くほうがよい。

この PoC が示すこと(数字はいずれも実行時に印字される実測値):

1. **ゼロ点(大津の二値化 + 連結成分)を先に測る** —— 重なりを強めていくと
   単調に下振れし、いちばん密な条件で 78 個中 25 個を取りこぼす。失点の正体は
   全部「過統合」で、「取りこぼし(どの予測ラベルにも触れられていない細胞)」は
   ゼロのまま —— **この 2 つは別物**である。
2. ★**計数が合っていて分割が外れている点が実在する** —— 種を間引く量を振ると
   過分割と過統合が逆向きに動くので **どこかで打ち消し合う**。実測ではその点で
   個数の偏りが +0.3 個(真値の 0.4 %)になるのに、分割誤りは 13.3 件残り、
   1 対 1 に対応した細胞は 60/78 個(最良の設定なら 69 個)。**個数だけを
   報告していたら最良の設定として通る**。ゼロ点の疎な条件(偏り +2.0)も同じ形で、
   内訳は 過統合 8.0 件 と 偽物 11.7 件 の相殺だった。
3. **過分割と過統合は別々に数えないと見えない**。さらに実測では
   ★**過分割は重なりに反応しなかった** —— 重なりを 5 段階振っても過分割の列は
   ほぼ一定で、動くのは過統合だけ。**2 つの欠陥は原因が別**(過分割は種の撒き方、
   過統合は重なり)なので、密度を振る実験では過分割の良し悪しは測れない。
4. **最適な h は基準で変わり、基準によっては密度でも動く** —— 偏りを基準に取ると
   最適 h は密度で 1.1 → 0.75 → 0 と動くが、1 対 1 対応の数を基準にすると動かない。
   「最適な h は密度で動く」は **基準を書かないと真偽が決まらない**主張である。
5. ★**大きさが 3 倍違う集団についての予想は外れた** —— 「大型と小型で最適な h が
   分かれる」と踏んでいたが、実測ではどちらも h≈1.0 で分かれなかった。代わりに
   出たのは (a) 種を細かく撒いたときの過分割が **大型に集中する**(大きさ比 1 倍で
   8 個中 1.3、3 倍で 5.7)、(b) ★**道具の都合で指定できる h の下限が
   0.42 → 0.80 画素へ上がる**(``xsk2_h_maxima`` の h は正規化画像に対する比なので、
   画像に大きい細胞が 1 つ入るだけで小さい細胞の側の下限まで上がる)。
6. **雑音と背景ムラは壊し方が逆** —— 雑音は前景を粒々にして **偽物** を増やし
   (過分割ではない)、背景ムラは大津の閾値を動かして前景率を 3 倍にし **過統合**
   を増やす。前者は面積による棄却、後者は背景補正が要る。
7. **縁で切れた細胞をどう数えるか**で推定個数が 10 個(真値の 13 %)動く。ただし
   真値の側を同じ規約で数えれば偏りはどの規約でも小さい —— 危ないのは規約の選択
   ではなく、**推定と真値で違う規約を使う**ことのほう。
8. **面積は「見えている面積」までしか取れない** —— 隠れていない細胞では
   「見えている面積との差」と「真の面積との差」がほぼ一致するのに、隠れた帯では
   前者が当たったまま後者だけが外れる。分割の巧拙ではなく **誤差の床** である。
   さらに、よく隠れた細胞は **そもそも 1 対 1 に対応しない**ので形を測る対象に
   残らない = 床の存在自体が標本から消える。

★この PoC が出した fullseye の道具の穴は
末尾の「道具の穴」節と、親への報告に列挙してある。要点だけ:
(a) **2 次元の連結成分ラベリングと per-object の region props が facade に無い**
(3 次元の ``vol_label`` / ``vol_region_props`` はある)。(b) 進化 op の
``distance_transform`` は最大値で正規化するので **画素単位の距離が取れない**。
(c) ``xsk2_h_maxima`` は入力を ``[0,1]`` に切り詰めるうえ h を
``0.05 + 0.3a``(= 正規化画像に対する比)でしか振れず、**画素単位の h を
指定できない**。(d) ``circularity`` / ``eccentricity`` / ``area_center`` は
画像全体の 1 スカラーで、**物体ごとには取れない**。
"""
from __future__ import annotations

import time
import unicodedata

import numpy as np

import sys
from pathlib import Path

# ★2026-10-02: 他の PoC と同じく、リポジトリ直下を**自分で** sys.path に足してから fullseye を import する。
#   パスフック頼みだと、examples/ から PYTHONPATH 無しで走らせたとき(tests/test_poc_scripts_run.py の走らせ方)に
#   本線の editable install の fullseye が先に入り、この worktree で足した台帳(watersheds_marker)が無くて落ちた。
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import fullseye as fs          # noqa: E402  ★先に fullseye を import すること(パスフックが
import volops                  #   リポジトリ直下を sys.path に足すので順序が要る)
import segmentation as fsseg   # noqa: F401  (2D watershed の所在を示すために保持)

import examplefig as figs      # ★fullseye の後(上のパスフックに乗る)


# --------------------------------------------------------------------------- #
# 表示                                                                          #
# --------------------------------------------------------------------------- #
def _dw(s):
    """全角を 2 桁と数えた表示幅(str.format は文字数で数えるので桁が揃わない)。"""
    return sum(2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in str(s))


def pad(s, n, right=True):
    """表示幅 ``n`` に詰める。``right`` なら右寄せ。"""
    s = str(s)
    sp = " " * max(0, n - _dw(s))
    return sp + s if right else s + sp


def label_paint(lab):
    """ラベル画像を図に載せるための塗り分け(表示だけ。数字には触らない)。

    ラベル番号をそのまま塗ると **隣り合う細胞が似た色**になって境界が見えない。
    番号を固定の擬似乱数で入れ替えてから塗る。背景は 0 のまま。
    """
    lab = np.asarray(lab, np.int64)
    k = int(lab.max())
    lut = np.zeros(k + 1)
    if k:
        lut[1:] = 0.15 + 0.85 * np.random.default_rng(0).permutation(k) / max(k - 1, 1)
    return lut[lab]


# --------------------------------------------------------------------------- #
# 標本の合成 —— 真値は全部こちらが握っている                                     #
# --------------------------------------------------------------------------- #
#: 画素数(正方)。
IMG = 288
#: 副画素の細分数。細胞は副画素格子に描いてから面積平均で画素へ落とす。
SS = 3
#: 細胞の平均の長半径 [画素]。短半径はこの ``AXIS_RATIO`` 倍。
R_BASE = 6.4
AXIS_RATIO = 0.78

#: 細胞の種別。**乱数で散らしただけの配置に頼らない**ための構造。
KIND_COLONY, KIND_CHAIN, KIND_LARGE, KIND_SINGLE, KIND_EDGE = 0, 1, 2, 3, 4
KIND_NAME = ("コロニー", "分裂鎖", "大型", "孤立", "縁")

#: 点像分布関数(PSF)のシグマ [画素]。``gauss_filter`` は ``sigma = 0.3 + 2.7a``。
PSF_SIGMA = 1.2
PSF_A = (PSF_SIGMA - 0.3) / 2.7

#: 既定の背景ムラの振幅と、既定の光子数スケール(ショット雑音の強さを決める)。
BG_AMP = 0.10
PHOTONS = 260.0
READ_NOISE = 0.010


def _hex_points(k, step, rng):
    """六方最密に近い格子上の ``k`` 点(中心付近から順に)。コロニーの骨格。

    乱数で散らすと隣接距離が指数分布になり、「重なり」が密度と一緒に動いてしまう。
    格子に置いて ``step`` だけを振れば、**個数を変えずに重なりだけ**を変えられる。
    """
    pts = []
    ring = 0
    while len(pts) < k:
        if ring == 0:
            pts.append((0.0, 0.0))
        else:
            for i in range(6 * ring):
                th = 2.0 * np.pi * i / (6 * ring)
                pts.append((ring * step * np.sin(th), ring * step * np.cos(th)))
        ring += 1
    pts = np.asarray(pts[:k], float)
    return pts + rng.normal(0.0, 0.09 * step, pts.shape)


def layout(seed, *, pack=1.05, size_ratio=2.0, n_colony=3, k_colony=10,
           n_chain=4, k_chain=3, n_large=8, n_single=20, n_edge=8):
    """細胞の一覧 ``(cy, cx, ra, rb, theta, bright, kind)`` を作る。

    ``pack`` が **重なりの強さ**(コロニー内の中心間距離 / 2ra)。1.5 で明らかに
    離れ、1.0 で接し、0.65 で深く重なる。**個数は ``pack`` に依らない**ので、
    この 1 つのノブで「重なりだけ」を振れる。``size_ratio`` は大型集団の線寸法。

    集団(コロニー / 鎖 / 大型 / 孤立)はそれぞれ **縄張りの円**を予約してから
    置く。乱数で撒くと、疎に設定したつもりでも集団どうしが偶然重なり、
    「pack を大きくしても重なりが減らない」という測れない場面になってしまう。
    """
    rng = np.random.default_rng(20260906 + 977 * seed)
    cells = []
    discs = []                      # 予約済みの縄張り (cy, cx, 半径)

    def reserve(rad, lo=0.05, hi=0.95, gap=3.0, tries=400, near_edge=False):
        """半径 ``rad`` の縄張りが空いている場所を探す。見つからなければ None。"""
        for _ in range(tries):
            if near_edge:
                side = int(rng.integers(4))
                t = rng.uniform(0.08 * IMG, 0.92 * IMG)
                off = rng.uniform(-0.55 * rad, 0.75 * rad)
                p = np.array(((off, t), (IMG - 1.0 - off, t),
                              (t, off), (t, IMG - 1.0 - off))[side])
            else:
                p = rng.uniform(lo * IMG, hi * IMG, 2)
            if all(np.hypot(p[0] - d[0], p[1] - d[1]) > rad + d[2] + gap for d in discs):
                discs.append((p[0], p[1], rad))
                return p
        return None

    def add(cy, cx, ra, rb, th, kind):
        cells.append((cy, cx, ra, rb, th, float(rng.uniform(0.55, 0.70)), kind))

    # (1) コロニー —— 六方格子に密集。pack で重なりが決まる。
    step = 2.0 * R_BASE * pack
    for _ in range(n_colony):
        offs = _hex_points(k_colony, step, rng)
        radii = R_BASE * rng.uniform(0.88, 1.12, len(offs))
        rad = float(np.max(np.hypot(offs[:, 0], offs[:, 1]) + radii))
        p = reserve(rad)
        if p is None:
            continue
        for (dy, dx), r in zip(offs, radii):
            add(p[0] + dy, p[1] + dx, r, r * AXIS_RATIO,
                rng.uniform(0, np.pi), KIND_COLONY)

    # (2) 分裂中の鎖 —— 中心間 1.05ra の亜鈴形。pack に依らず **常に重なっている**
    #     構造を 1 つ残しておく(疎な条件でも「重なりのある場面」が消えないように)。
    for _ in range(n_chain):
        th = rng.uniform(0, 2 * np.pi)
        r = R_BASE * rng.uniform(0.85, 1.05)
        offs, bends = [], []
        for j in range(k_chain):
            bend = 0.18 * rng.normal() * j
            d = 1.05 * r * j
            offs.append((d * np.sin(th + bend), d * np.cos(th + bend)))
            bends.append(bend)
        offs = np.asarray(offs) - np.mean(offs, 0)
        rad = float(np.max(np.hypot(offs[:, 0], offs[:, 1])) + r)
        p = reserve(rad)
        if p is None:
            continue
        for (dy, dx), bend in zip(offs, bends):
            add(p[0] + dy, p[1] + dx, r, r * AXIS_RATIO,
                th + bend + np.pi / 2, KIND_CHAIN)

    # (3) 大型集団 —— 線寸法 size_ratio 倍(面積は 2 乗倍)。単一スケールの前提を壊す。
    for _ in range(n_large):
        r = R_BASE * size_ratio * rng.uniform(0.9, 1.1)
        p = reserve(r)
        if p is None:
            continue
        add(p[0], p[1], r, r * AXIS_RATIO, rng.uniform(0, np.pi), KIND_LARGE)

    # (4) 孤立細胞 —— 縄張りを取るので「易しい」対照が必ず残る。
    for _ in range(n_single):
        r = R_BASE * rng.uniform(0.85, 1.15)
        p = reserve(r)
        if p is None:
            continue
        add(p[0], p[1], r, r * AXIS_RATIO, rng.uniform(0, np.pi), KIND_SINGLE)

    # (5) 縁で切れる細胞 —— 中心を画像の外側寄りに置き、**わざと半分だけ写す**。
    for _ in range(n_edge):
        r = R_BASE * rng.uniform(0.85, 1.15)
        p = reserve(r, near_edge=True)
        if p is None:
            continue
        add(p[0], p[1], r, r * AXIS_RATIO, rng.uniform(0, np.pi), KIND_EDGE)

    return cells, rng


def _paint(acc, owner, best, cy, cx, ra, rb, th, bright, ident):
    """副画素格子に楕円を 1 つ描く。``ident<0`` はデブリ(``owner`` に入れない)。

    重なった画素の帰属は **中心までの正規化距離が小さいほう** に決める(楕円計量の
    ボロノイ分割)。この規約を先に決めておかないと「2 つを 1 つにまとめた」を
    数える基準が定義できない —— 真値の側があいまいだと過統合は測れない。
    強度は加算(半透明)。実際の蛍光像でも重なりは明るくなる。
    """
    n = acc.shape[0]
    r = int(np.ceil(max(ra, rb) * SS)) + 2
    y0, y1 = max(0, int(cy * SS) - r), min(n, int(cy * SS) + r + 1)
    x0, x1 = max(0, int(cx * SS) - r), min(n, int(cx * SS) + r + 1)
    if y1 <= y0 or x1 <= x0:
        return 0
    yy, xx = np.mgrid[y0:y1, x0:x1]
    dy = yy / SS - cy
    dx = xx / SS - cx
    ct, st = np.cos(th), np.sin(th)
    u = dx * ct + dy * st
    v = -dx * st + dy * ct
    f = (u / ra) ** 2 + (v / rb) ** 2
    inside = f <= 1.0
    if not inside.any():
        return 0
    acc[y0:y1, x0:x1] += np.where(inside, bright * (1.0 - 0.22 * f), 0.0)
    if ident >= 0:
        sub_o = owner[y0:y1, x0:x1]
        sub_b = best[y0:y1, x0:x1]
        take = inside & (f < sub_b)
        sub_o[take] = ident
        sub_b[take] = f[take]
    return int(inside.sum())          # 他の細胞が無ければ見えたはずの副画素数


def make_scene(seed, *, pack=0.88, size_ratio=2.0, bg_amp=BG_AMP, photons=PHOTONS,
               read_noise=READ_NOISE, n_debris=22, n_frag=6, **kw):
    """1 枚の場面を合成して真値つきで返す。

    返す辞書:
      ``img``    観測画像 (IMG, IMG) —— PSF・背景ムラ・ショット雑音・読出雑音つき。
      ``owner``  画素ごとの帰属ラベル (IMG, IMG) int32。0 = 背景 / デブリ。
      ``cells``  細胞の一覧(中心・長短径・傾き・種別)。
      ``area_true``    真の面積 πab [画素²](重なりで隠れていても変わらない)。
      ``area_alone``   **他の細胞が無ければ**見えたはずの面積(= 画像内に入る楕円)。
      ``area_vis``     実際に見えている面積 [画素²](``owner`` の画素数)。
      ``occ``          他の細胞に隠された割合 = 1 - area_vis / area_alone。
                       ★画像の縁で切れたぶんは ``area_alone`` 側に織り込み済みで、
                       **重なりと縁を混ぜない**(混ぜると縁の細胞が全部「重なって
                       いる」ことになり、重なりのノブが測れなくなる)。
      ``on_edge``      画像の縁に掛かっているか。
    """
    cells, rng = layout(seed, pack=pack, size_ratio=size_ratio, **kw)
    n = IMG * SS
    acc = np.zeros((n, n), np.float32)
    owner = np.zeros((n, n), np.int32)
    best = np.full((n, n), np.inf, np.float32)
    alone = np.zeros(len(cells))
    for i, (cy, cx, ra, rb, th, br, _k) in enumerate(cells):
        alone[i] = _paint(acc, owner, best, cy, cx, ra, rb, th, br, i + 1) / (SS * SS)

    # デブリ —— 細胞ではないので owner には入れない。明るい微粒子と、暗く細長い破片。
    for _ in range(n_debris):
        r = rng.uniform(0.7, 1.8)
        _paint(acc, owner, best, *rng.uniform(2, IMG - 2, 2), r, r,
               0.0, 0.95, -1)
    for _ in range(n_frag):
        _paint(acc, owner, best, *rng.uniform(4, IMG - 4, 2),
               rng.uniform(2.0, 3.5), rng.uniform(0.6, 1.2),
               rng.uniform(0, np.pi), 0.45, -1)

    sig = acc.reshape(IMG, SS, IMG, SS).mean(axis=(1, 3)).astype(np.float64)
    own_px = owner[SS // 2::SS, SS // 2::SS].copy()

    # 背景ムラ(照明の傾き + 緩い縞)。**PSF の前に足す** —— 照明も光学系を通る。
    gy, gx = np.mgrid[0:IMG, 0:IMG] / float(IMG)
    bg = 0.05 + bg_amp * (0.35 + 0.65 * gy) * (0.5 + 0.5 * np.cos(2 * np.pi * (0.8 * gx - 0.15)))
    clean = fs.apply(sig + bg, "gauss_filter", a=PSF_A)

    # ショット雑音(光子計数)+ 読出雑音。photons が 1 画素あたりの換算光子数。
    nrng = np.random.default_rng(70000 + seed)
    img = nrng.poisson(np.clip(clean, 0.0, None) * photons) / photons
    img = img + nrng.normal(0.0, read_noise, img.shape)

    ncell = len(cells)
    area_true = np.asarray([np.pi * c[2] * c[3] for c in cells])
    # 見えている面積は **副画素で** 数える。画素で数えると標本化の揺らぎが
    # ±数 % 乗って「隠れた割合」が負になり、重なりのノブが測れなくなる。
    area_vis = (np.bincount(owner.ravel(), minlength=ncell + 1)[1:].astype(float)
                / (SS * SS))
    on_edge = np.asarray([
        (c[0] - c[2] < 0) or (c[0] + c[2] > IMG - 1) or
        (c[1] - c[2] < 0) or (c[1] + c[2] > IMG - 1) for c in cells])
    occ = 1.0 - area_vis / np.maximum(alone, 1e-9)
    return {
        "img": img, "owner": own_px, "cells": cells, "n": ncell,
        "area_true": area_true, "area_alone": alone, "area_vis": area_vis,
        "occ": occ, "on_edge": on_edge,
        "kind": np.asarray([c[6] for c in cells]), "seed": seed,
    }


# --------------------------------------------------------------------------- #
# 道具の薄い包み —— fullseye 側に無い形のものはここで明示的に補う                 #
# --------------------------------------------------------------------------- #
def cc_label(mask):
    """2 次元の 8 連結ラベリング。

    ★道具の穴: fullseye の facade に **2 次元のラベリングが無い**。``fs.op`` 側の
    ``connect_and_holes`` / ``cv_cc_count`` / ``blob_count`` は **個数(1 スカラー)**
    しか返さず、``hx_region_to_label`` はラベル画像を返すが進化 op の規約で
    ``[0,1]`` に正規化されるので、ラベル番号が浮動小数の刻みになってしまう。
    ここでは 3 次元用の ``volops.vol_label`` に厚さ 1 のボリュームを渡している。
    26 近傍が面内では 8 連結に落ちるので結果は正しいが、**2 次元の道具ではない**。
    """
    lab, k = volops.vol_label(np.asarray(mask, bool)[None, :, :], connectivity=26)
    return lab[0], int(k)


def edt(mask):
    """画素単位のユークリッド距離変換。

    ★道具の穴: 進化 op の ``distance_transform`` / ``dist_transform`` / ``cv_dist``
    は **最大値で正規化して返す**ので、「中心まで何画素あるか」が取り出せない。
    h-maxima の h を画素で指定したい、面積から半径を推したい、といった用途では
    正規化された距離は使えない。ここも 3 次元用 ``vol_distance_transform`` を
    厚さ 1 で使っている。
    """
    return volops.vol_distance_transform(np.asarray(mask, bool)[None, :, :])[0]


def watershed(landscape, markers, mask):
    """マーカー制御分水嶺(2 次元)。

    ★道具の穴: 2 次元版 ``segmentation.watersheds_marker`` はモジュールには
    在るが ``fs.`` にも ``fs.ledger.`` にも **公開されていない**(``import
    segmentation`` で直に掴むしかない)。しかも mask 引数が無いので背景まで
    塗ってしまう。ここは mask を取れる ``volops.vol_watershed`` を厚さ 1 で使う。
    """
    return volops.vol_watershed(np.asarray(landscape, float)[None, :, :],
                                np.asarray(markers, np.int32)[None, :, :],
                                mask=np.asarray(mask, bool)[None, :, :])[0]


def h_maxima_seeds(d, h_px):
    """距離変換 ``d`` の h-maxima 種。``h_px`` は **画素単位**の間引き量。

    ★道具の穴: ``xsk2_h_maxima`` は (1) 入力を ``np.clip(v, 0, 1)`` で切り詰め、
    (2) h を ``0.05 + 0.3a`` = **正規化画像に対する比** でしか振れない。距離変換は
    画素単位なので、ここでは ``d / D0`` に割ってから渡し、``a`` を逆算している。
    ``D0`` は ``d.max()`` 以上かつ ``h_px / 0.35`` 以上でなければならず、
    **h_px が ``0.05 * d.max()`` より小さいと表現できない**(下限に張り付く)。
    """
    dmax = float(d.max())
    if dmax <= 0:
        return np.zeros_like(d, np.int32), 0, 0.0
    d0 = max(dmax * 1.001, h_px / 0.35)
    a = (h_px / d0 - 0.05) / 0.3
    a_clip = float(np.clip(a, 0.0, 1.0))
    m = fs.apply(np.clip(d / d0, 0.0, 1.0), "xsk2_h_maxima", a=a_clip)
    lab, k = cc_label(m > 0.5)
    return lab, k, (0.05 + 0.3 * a_clip) * d0        # 実際に効いた h [画素]


def moment_ellipse(ys, xs):
    """画素集合の 2 次中心モーメントから長短半径 ``(ra, rb)`` と傾きを出す。

    塗り潰した楕円なら ``ra = 2 sqrt(λ1)`` がちょうど長半径になる。
    ★道具の穴: fullseye の ``circularity`` / ``eccentricity`` / ``area_center`` /
    ``moments_region_2nd`` は **画像全体を 1 つの領域として 1 スカラー**を返す
    進化 op なので、**物体ごとの形状量が取れない**(3 次元の
    ``vol_region_props`` は per-object で返すのに、2 次元にはそれが無い)。
    """
    if ys.size < 3:
        return 0.5, 0.5, 0.0
    y = ys - ys.mean()
    x = xs - xs.mean()
    cov = np.array([[float((y * y).mean()), float((y * x).mean())],
                    [float((y * x).mean()), float((x * x).mean())]])
    w, v = np.linalg.eigh(cov)
    w = np.clip(w, 1e-9, None)
    ra, rb = 2.0 * np.sqrt(w[1]), 2.0 * np.sqrt(w[0])
    ang = float(np.arctan2(v[1, 1], v[0, 1]))
    return float(ra), float(rb), ang


def per_object(labels, k):
    """ラベル画像から物体ごとの (面積, 充填率, ra, rb, 縁接触) を返す。

    充填率 = 面積 / (π ra rb)。塗り潰した 1 個の楕円なら 1.0、亜鈴形(2 個が
    くっついたもの)なら 0.6〜0.8 に落ちる —— これが「形の事前知識」の中身。
    """
    if k == 0:
        return {}
    flat = labels.ravel()
    order = np.argsort(flat, kind="stable")
    sf = flat[order]
    starts = np.searchsorted(sf, np.arange(k + 2))
    H, W = labels.shape
    out = {}
    for i in range(1, k + 1):
        idx = order[starts[i]:starts[i + 1]]
        if idx.size == 0:
            continue
        ys, xs = np.divmod(idx, W)
        ra, rb, ang = moment_ellipse(ys.astype(float), xs.astype(float))
        a = float(idx.size)
        out[i] = {"area": a, "fill": a / max(np.pi * ra * rb, 1e-9),
                  "ra": ra, "rb": rb, "ang": ang,
                  "edge": bool(ys.min() == 0 or xs.min() == 0
                               or ys.max() == H - 1 or xs.max() == W - 1),
                  "cy": float(ys.mean()), "cx": float(xs.mean())}
    return out


# --------------------------------------------------------------------------- #
# 手法 —— どれも「ラベル画像」を返す                                             #
# --------------------------------------------------------------------------- #
def foreground(img, op="sk_otsu"):
    """全手法で共有する前景マスク(大津 + 穴埋め)。

    **わざと共有する** —— こうすると手法間の差が「分け方」だけになり、閾値の
    良し悪しと混ざらない。閾値そのものの崖は雑音・背景ムラの節で別に測る。
    """
    b = fs.apply(np.asarray(img, np.float64), op) > 0.5
    return fs.apply(b.astype(np.float64), "fill_holes") > 0.5


def m_cc(img, fg=None):
    """ゼロ点 —— 大津 + 連結成分。触れ合った細胞は 1 個になる。"""
    fg = foreground(img) if fg is None else fg
    return cc_label(fg)[0]


def m_ws_all(img, fg=None):
    """距離変換 + 分水嶺(局所極大を全部種にする)。間引きをしないので過分割側。"""
    fg = foreground(img) if fg is None else fg
    d = edt(fg)
    pk = volops.vol_local_maxima(d[None, :, :], 1)
    seed = np.zeros_like(fg, bool)
    if len(pk):
        seed[np.asarray(pk)[:, 1], np.asarray(pk)[:, 2]] = True
    mk, k = cc_label(seed)          # 平坦な尾根は 1 つの種にまとめる
    if k == 0:
        return cc_label(fg)[0]
    return watershed(-d, mk, fg)


def m_ws_md(img, fg=None, min_distance=1):
    """距離変換 + 分水嶺、種を **空間的な間隔** で間引く(``min_distance`` 画素)。

    h-maxima が「高さ」で間引くのに対し、こちらは「近すぎる極大をまとめる」。
    ★h-maxima の h には下限(``0.05 x max(EDT)``)があって細かく振れないので、
    h=0 と h=下限 の **あいだ** を埋めるノブとしてこちらを使う。
    """
    fg = foreground(img) if fg is None else fg
    d = edt(fg)
    pk = volops.vol_local_maxima(d[None, :, :], int(min_distance))
    seed = np.zeros_like(fg, bool)
    if len(pk):
        p = np.asarray(pk)
        seed[p[:, 1], p[:, 2]] = True
    mk, k = cc_label(seed)
    if k == 0:
        return cc_label(fg)[0]
    return watershed(-d, mk, fg)


def m_ws_h(img, fg=None, h_px=2.4):
    """h-maxima で種を間引いてから分水嶺。``h_px`` が過分割/過統合のノブ。"""
    fg = foreground(img) if fg is None else fg
    d = edt(fg)
    mk, k, _h = h_maxima_seeds(d, h_px)
    if k == 0:
        return cc_label(fg)[0]
    return watershed(-d, mk, fg)


#: 形の事前知識のしきい値。充填率がこれ以上なら「1 個の楕円」とみなして割らない。
FILL_KEEP = 0.86
#: デブリ棄却の面積下限 [画素²]。細胞の面積の 1/4 を目安にする。
AREA_MIN_FRAC = 0.25


def _ref_area(props):
    """場面から「細胞 1 個ぶんの面積」を自己校正する。

    充填率が高い(= 1 個に見える)連結成分の面積の中央値を使う。外から与えると
    「答えを教えている」ことになるので、**画像だけから推す**。
    """
    good = [p["area"] for p in props.values() if p["fill"] >= 0.92 and p["area"] > 12]
    return float(np.median(good)) if good else 100.0


def m_shape(img, fg=None, h_px=2.4):
    """形の事前知識を使う —— 充填率と面積で「割るべき連結成分」だけを割る。

    1. 連結成分を取り、モーメント楕円の充填率と面積を出す。
    2. 面積が細胞 1 個ぶんの 1/4 未満なら **デブリとして棄てる**。
    3. 充填率が高く、面積も 1 個ぶんなら **そのまま**(分水嶺に掛けない)。
    4. そうでないものは、面積から推した個数 ``k = round(面積 / 1 個ぶん)`` に
       届くまで h を下げながら分水嶺を掛ける。★この「期待した個数まで割る」が
       単一スケールの前提そのもので、大きさが 3 倍違う集団が混ざると **大型細胞を
       ``k`` 個に割ってしまう**(崖 (b))。
    """
    fg = foreground(img) if fg is None else fg
    lab, k = cc_label(fg)
    props = per_object(lab, k)
    aref = _ref_area(props)
    out = np.zeros_like(lab)
    nxt = 0
    for i, p in props.items():
        if p["area"] < AREA_MIN_FRAC * aref:
            continue                                    # デブリ
        sel = lab == i
        kest = max(1, int(round(p["area"] / aref)))
        if p["fill"] >= FILL_KEEP and kest == 1:
            nxt += 1
            out[sel] = nxt
            continue
        ys, xs = np.nonzero(sel)
        y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
        sub = sel[y0:y1, x0:x1]
        d = edt(sub)
        w = None
        for hh in (h_px, 0.6 * h_px, 0.35 * h_px):
            mk, kk, _h = h_maxima_seeds(d, hh)
            if kk == 0:
                continue
            w = watershed(-d, mk, sub)
            if kk >= kest:
                break
        if w is None:
            w = cc_label(sub)[0]
        for j in range(1, int(w.max()) + 1):
            m = w == j
            if m.any():
                nxt += 1
                out[y0:y1, x0:x1][m] = nxt
    return out


def count_by_area(img, fg=None):
    """分割せず面積割りで **個数だけ** を出す(ラベルは返さない)。

    分割の質を一切問わない対照。個数だけ見るなら分割は要らない、という主張を
    数字で置いておくためのもの。
    """
    fg = foreground(img) if fg is None else fg
    lab, k = cc_label(fg)
    props = per_object(lab, k)
    aref = _ref_area(props)
    tot = sum(p["area"] for p in props.values() if p["area"] >= AREA_MIN_FRAC * aref)
    return int(round(tot / max(aref, 1e-9)))


# --------------------------------------------------------------------------- #
# 指標 —— 個数 / 過分割 / 過統合を **別々に**                                    #
# --------------------------------------------------------------------------- #
#: 「有意に重なっている」の下限。真値細胞の見えている面積のこの割合以上を
#: 覆っていれば、その予測ラベルはその細胞に触れているとみなす。
TAU = 0.25


def evaluate(scene, pred, tau=TAU):
    """真値と予測のラベル画像を突き合わせて、欠陥を **向きごとに** 数える。

    重なり行列 ``O[g, p]`` を作り、``O[g,p] >= tau * (g の見えている面積)`` を
    「有意」とする。同じ有意行列から:
      過分割 = Σ_g max(0, (g に触れた予測ラベル数) - 1)
      過統合 = Σ_p max(0, (p が触れた真値細胞数) - 1)
    が出る。**1 つの数にまとめない** —— 向きが逆の 2 つの欠陥で、片方を減らすと
    もう片方が増えるため、合計を見ても種の間引き量をどちらへ動かせばよいか
    決まらない。
    """
    gt = scene["owner"]
    ng = scene["n"]
    pred = np.asarray(pred, np.int64)
    npred = int(pred.max())
    if npred == 0:
        z = np.zeros(ng, int)
        return {"n_pred": 0, "split": 0, "merge": 0, "missed": ng, "spurious": 0,
                "one2one": [], "n_gt": ng, "per_gt": z, "per_pred": np.zeros(0, int)}
    O = np.bincount((gt.ravel().astype(np.int64) * (npred + 1) + pred.ravel()),
                    minlength=(ng + 1) * (npred + 1)).reshape(ng + 1, npred + 1)
    core = O[1:, 1:].astype(float)                      # 真値細胞 x 予測ラベル
    avis = np.maximum(core.sum(1) + O[1:, 0], 1.0)      # 見えている面積
    sig = core >= tau * avis[:, None]
    per_gt = sig.sum(1)
    per_pred = sig.sum(0)
    one2one = [(g, int(np.argmax(sig[g])) + 1)
               for g in range(ng)
               if per_gt[g] == 1 and per_pred[int(np.argmax(sig[g]))] == 1]
    # 「この予測ラベルは主にどの真値細胞のものか」= 過統合を細胞の種別へ配りたいとき用
    owner_of_pred = np.where(sig.any(0), np.argmax(core, 0), -1)
    return {
        "n_pred": npred, "n_gt": ng,
        "split": int(np.maximum(per_gt - 1, 0).sum()),
        "merge": int(np.maximum(per_pred - 1, 0).sum()),
        "missed": int((per_gt == 0).sum()),
        "spurious": int((per_pred == 0).sum()),
        "one2one": one2one, "per_gt": per_gt, "per_pred": per_pred,
        "sig": sig, "owner_of_pred": owner_of_pred,
    }


def summarize(rows):
    """複数枚の結果を「偏り」と「散らばり」に分けてまとめる。**混ぜない**。"""
    err = np.asarray([r["n_pred"] - r["n_gt"] for r in rows], float)
    return {
        "bias": float(err.mean()), "scatter": float(err.std()),
        "split": float(np.mean([r["split"] for r in rows])),
        "merge": float(np.mean([r["merge"] for r in rows])),
        "missed": float(np.mean([r["missed"] for r in rows])),
        "spurious": float(np.mean([r["spurious"] for r in rows])),
        "n_gt": float(np.mean([r["n_gt"] for r in rows])),
        "one2one": float(np.mean([len(r["one2one"]) for r in rows])),
    }


# --------------------------------------------------------------------------- #
def main():
    t0 = time.perf_counter()
    SEEDS = (0, 1, 2)
    #: 重なりの強さ(コロニー内の中心間距離 / 2ra)。個数は変えずにこれだけ振る。
    PACKS = (1.50, 1.25, 1.05, 0.85, 0.65)
    BASE_PACK = 1.05
    SPARSE, MID, DENSE = PACKS[0], PACKS[2], PACKS[-1]

    print("=== 1. 何を作ったか(真値は全部こちらが握っている)===")
    base = {p: [make_scene(s, pack=p) for s in SEEDS] for p in PACKS}
    sc0 = base[BASE_PACK][0]
    print(f"  {IMG}x{IMG} 画素、副画素 {SS}x{SS} で描いてから面積平均。"
          f"PSF シグマ {PSF_SIGMA} 画素、")
    print(f"  背景ムラ振幅 {BG_AMP}、光子数 {PHOTONS:.0f}/画素(ショット雑音)、"
          f"読出雑音 {READ_NOISE}。")
    print("  " + pad("種別", 12, right=False) + pad("個数", 8) + pad("長半径 [px]", 14)
          + pad("真の面積", 12) + pad("見えている", 12) + pad("隠れた割合", 12))
    kd = sc0["kind"]
    for k in range(5):
        m = kd == k
        if not m.any():
            continue
        print("  " + pad(KIND_NAME[k], 12, right=False) + pad(f"{int(m.sum())}", 8)
              + pad(f"{np.mean([c[2] for c, t in zip(sc0['cells'], m) if t]):.1f}", 14)
              + pad(f"{sc0['area_true'][m].mean():.0f}", 12)
              + pad(f"{sc0['area_vis'][m].mean():.0f}", 12)
              + pad(f"{100 * sc0['occ'][m].mean():.1f} %", 12))
    print(f"  合計 {sc0['n']} 個 + デブリ(明るい微粒子 22 + 暗い破片 6、"
          f"**細胞ではない**)。")
    print("  " + pad("重なり pack", 14, right=False) + pad("細胞数", 9)
          + pad("重なった細胞の割合", 22) + pad("平均で隠れた割合", 20)
          + pad("前景の連結成分数", 20))
    occ_tab = {}
    for p in PACKS:
        occ = np.concatenate([s["occ"] for s in base[p]])
        ncc = np.mean([cc_label(foreground(s["img"]))[1] for s in base[p]])
        occ_tab[p] = (float(np.mean(occ > 0.02)), float(occ.mean()), float(ncc))
        print("  " + pad(f"{p:.2f}", 14, right=False)
              + pad(f"{base[p][0]['n']}", 9)
              + pad(f"{100 * occ_tab[p][0]:.1f} %", 22)
              + pad(f"{100 * occ_tab[p][1]:.1f} %", 20)
              + pad(f"{ncc:.0f}", 20))
    print("  → **細胞数は pack に依らず一定**なので、この 1 列で『重なりだけ』を")
    print("     振れている。前景の連結成分数(右端)は重なりとともに減る = 触れ合った")
    print("     細胞が 1 塊になっていく。ここがゼロ点の失点そのもの。")
    print("  → 左の 2 行はほぼ同じ値で止まっている。pack 1.25 以上ではコロニーが")
    print("     そもそも重ならないので、残っているのは **常に重なる分裂鎖のぶん**の底")
    print(f"     ({100 * 12 / 78:.0f} % 前後)。この底があるおかげで、疎な条件でも")
    print("     『重なりのある場面』が消えず、疎↔密の比較が同じ課題の上で行える。")

    print("\n=== 2. ゼロ点を先に測る —— 大津 + 連結成分 ===")
    print("  " + pad("重なり pack", 14, right=False) + pad("真の個数", 10)
          + pad("推定", 8) + pad("偏り", 9) + pad("散らばり", 11)
          + pad("過分割", 9) + pad("過統合", 9) + pad("取りこぼし", 12)
          + pad("偽物", 8))
    zero = {}
    for p in PACKS:
        rows = [evaluate(s, m_cc(s["img"])) for s in base[p]]
        zero[p] = summarize(rows)
        z = zero[p]
        print("  " + pad(f"{p:.2f}", 14, right=False) + pad(f"{z['n_gt']:.0f}", 10)
              + pad(f"{z['n_gt'] + z['bias']:.0f}", 8) + pad(f"{z['bias']:+.1f}", 9)
              + pad(f"{z['scatter']:.1f}", 11) + pad(f"{z['split']:.1f}", 9)
              + pad(f"{z['merge']:.1f}", 9) + pad(f"{z['missed']:.1f}", 12)
              + pad(f"{z['spurious']:.1f}", 8))
    print("  → ゼロ点の偏りは **重なりとともに単調に下振れ**する。散らばりは小さいので")
    print("     枚数を増やしても消えない。失点はほぼ全部が **過統合** で、過分割は")
    print("     ゼロに近い(切る仕掛けが無いので当然)。「偽物」はデブリを数えたぶん。")
    print(f"  → ★1 行目に **すでに打ち消し合いが出ている**。偏りは"
          f" {zero[SPARSE]['bias']:+.1f} 個とほぼ完璧に")
    print(f"     見えるが、内訳は 過統合 {zero[SPARSE]['merge']:.1f} 件(個数を減らす)と")
    print(f"     偽物 {zero[SPARSE]['spurious']:.1f} 件(デブリを細胞と数えた = 個数を増やす)"
          "で、たまたま近い。")
    print("     **偏りの絶対値が小さいことは、内訳が小さいことを意味しない**。")
    print("  → ★注意: **過統合 ≠ 取りこぼし** である。2 個を 1 個にまとめると個数は")
    print("     1 しか減らないが、過統合の件数は 1、取りこぼし(有意に触れた予測ラベルが")
    print("     1 つも無い細胞)は 0 のまま。この 2 つを分けないと、密なコロニーの")
    print("     中心で細胞が『消えている』のか『隣とくっついている』のか分からない。")

    print("\n=== 3. 手法の比較 —— 個数・過分割・過統合を分けて ===")
    H_DEF = 1.1          # 節 6 の掃引で偏りが小さかったあたり
    METHODS = (
        ("大津+連結成分(ゼロ点)", lambda im, fg: m_cc(im, fg)),
        ("距離変換+分水嶺(全極大)", lambda im, fg: m_ws_all(im, fg)),
        (f"h-maxima 分水嶺(h={H_DEF})", lambda im, fg: m_ws_h(im, fg, h_px=H_DEF)),
        ("形の事前知識(充填率+面積)", lambda im, fg: m_shape(im, fg, h_px=H_DEF)),
    )
    W = 26
    res3 = {}
    for p in (SPARSE, MID, DENSE):
        print(f"  — 重なり pack {p:.2f}(重なった細胞 "
              f"{100 * occ_tab[p][0]:.0f} %、真の個数 {base[p][0]['n']})—")
        print("  " + pad("手法", W, right=False) + pad("偏り", 9) + pad("散らばり", 11)
              + pad("過分割", 9) + pad("過統合", 9) + pad("取りこぼし", 12)
              + pad("偽物", 8) + pad("1対1", 8))
        fgs = [foreground(s["img"]) for s in base[p]]
        for name, fn in METHODS:
            rows = [evaluate(s, fn(s["img"], fg)) for s, fg in zip(base[p], fgs)]
            r = summarize(rows)
            res3[(p, name)] = r
            print("  " + pad(name, W, right=False) + pad(f"{r['bias']:+.1f}", 9)
                  + pad(f"{r['scatter']:.1f}", 11) + pad(f"{r['split']:.1f}", 9)
                  + pad(f"{r['merge']:.1f}", 9) + pad(f"{r['missed']:.1f}", 12)
                  + pad(f"{r['spurious']:.1f}", 8) + pad(f"{r['one2one']:.0f}", 8))
        cnt = [count_by_area(s["img"], fg) for s, fg in zip(base[p], fgs)]
        cb = float(np.mean([c - s["n"] for c, s in zip(cnt, base[p])]))
        cs = float(np.std([c - s["n"] for c, s in zip(cnt, base[p])]))
        res3[(p, "面積割り(個数のみ)")] = {"bias": cb, "scatter": cs}
        print("  " + pad("面積割り(個数のみ・分割しない)", W, right=False)
              + pad(f"{cb:+.1f}", 9) + pad(f"{cs:.1f}", 11) + pad("—", 9)
              + pad("—", 9) + pad("—", 12) + pad("—", 8) + pad("—", 8))
    print("  → 全極大を種にすると **過分割が跳ね上がる**(距離変換の尾根が雑音で")
    print("     割れる)。h で間引くと過分割は落ちるが過統合が増える。形の事前知識は")
    print("     『割らない』判断を先に入れるので、疎な条件での過分割を抑えられる。")
    print("  → 「偽物」の列も見ること。ゼロ点と全極大の分水嶺はデブリをそのまま")
    print("     細胞として数えているが、形の事前知識は面積の下限で落としている")
    print("     (0 件台)。**同じ偏りでも、内訳が違えば直し方が違う**。")
    print("  → 面積割りは **分割を一切しないのに個数の偏りが小さい**。個数だけが")
    print("     欲しいなら分割は要らない、という当たり前の事実がここに出る。逆に")
    print("     言えば **個数が合っていることは分割が合っている証拠にならない**。")
    if figs.enabled():
        # 過統合は「数字が減る」のではなく「塊になる」欠陥なので、絵にすると
        # どこで起きているかが 1 目で分かる。いちばん密な条件を 1 枚だけ。
        sd = base[DENSE][0]
        fgd = foreground(sd["img"])
        figs.save_grid("scene_dense",
                       [sd["img"], label_paint(sd["owner"]),
                        label_paint(m_cc(sd["img"], fgd)),
                        label_paint(m_ws_h(sd["img"], fgd, h_px=H_DEF))],
                       ["観測画像", "真値 %d 個" % sd["n"],
                        "ゼロ点 大津+連結成分", "h-maxima 分水嶺 h=%.1f" % H_DEF],
                       title="重なり pack %.2f —— 同じ場面を 4 通りに" % DENSE, ncols=4,
                       caption="ゼロ点はコロニーが 1 色の大きな塊になる(過統合)。"
                               "分水嶺はそこを割るが、代わりに過分割を出す。")

    print("\n=== 4. 崖 (a) 重なり —— 過分割と過統合のどちらが先に来るか ===")
    print("  " + pad("重なり pack", 12, right=False)
          + "".join(pad(n.split("(")[0][:10], 16) for n, _ in METHODS))
    print("  " + pad("", 12, right=False)
          + "".join(pad("偏り/過分割/過統合", 16) for _ in METHODS))
    dens = {}
    for p in PACKS:
        fgs = [foreground(s["img"]) for s in base[p]]
        cells = []
        for name, fn in METHODS:
            r = summarize([evaluate(s, fn(s["img"], fg)) for s, fg in zip(base[p], fgs)])
            dens[(p, name)] = r
            cells.append(pad(f"{r['bias']:+.0f}/{r['split']:.0f}/{r['merge']:.0f}", 16))
        print("  " + pad(f"{p:.2f}", 12, right=False) + "".join(cells))
    ws_name = f"h-maxima 分水嶺(h={H_DEF})"
    first = {}
    for name, _ in METHODS:
        sp = [dens[(p, name)]["split"] for p in PACKS]
        mg = [dens[(p, name)]["merge"] for p in PACKS]
        # 「先に来る」= pack を詰めていったとき、最初に基準線(疎な条件の値 + 3 件)を
        #  超えるのはどちらか。両方超えないなら None。
        def cross(v):
            for i, p in enumerate(PACKS):
                if v[i] > v[0] + 3.0:
                    return p
            return None
        first[name] = (cross(sp), cross(mg))
    print(f"  疎(pack {SPARSE:.2f})から +3 件を超えるのはどちらが先か:")
    for name, _ in METHODS:
        a, b = first[name]
        print("    " + pad(name, W, right=False)
              + f"過分割 {a if a else '越えず'} / 過統合 {b if b else '越えず'}")
    print("  → ★答えは **どの手法でも過統合が先**、というより **過分割は重なりに")
    print("     反応しない**。過分割の列はどの手法でも pack を通してほぼ一定である。")
    print("     過分割は『種の撒き方』が決めるもので、重なりが決めるものではない ——")
    print("     つまり **2 つの欠陥は原因が別**で、密度を上げる実験では過分割の良し")
    print("     悪しは測れない。合計 1 つの数字にしていたら、この切り分けは消える。")
    print("  → 全極大の分水嶺だけは pack 0.85 から過統合も急増する。種が細かすぎて")
    print("     境界が引けないのではなく、**深く重なると距離変換の尾根が繋がって")
    print("     極大が 1 つになる** ため。同じ『過統合』でも機序が違う。")

    print("\n=== 5. 崖 (b) 大きさのばらつき —— 単一スケールの前提はいつ壊れるか ===")
    RATIOS = (1.0, 1.5, 2.0, 2.5, 3.0)
    HS_SIZE = (0.0, 1.0, 1.6, 2.4, 3.4)
    print(f"  大型集団 8 個の線寸法だけを振る(他は同じ)。pack {BASE_PACK:.2f} 固定。")
    print("  ★**集団ごとに分けて数える** —— 全体に混ぜると、大型の過分割と小型の")
    print("     過統合が打ち消し合って『どちらも問題なし』に見えてしまう。")
    print("  " + pad("大きさ比", 8, right=False) + pad("面積比", 8)
          + pad("指定可能な最小 h", 18)
          + "".join(pad(f"h={h}", 23) for h in HS_SIZE) + pad("形の事前知識", 18))
    print("  " + pad("", 8, right=False) + pad("", 8) + pad("[px]", 18)
          + "".join(pad("大型割/小型割/統合", 23) for _ in HS_SIZE)
          + pad("大型割/小型割/統合", 18))
    size_tab = {}
    for r in RATIOS:
        scs = [make_scene(s, pack=BASE_PACK, size_ratio=r) for s in SEEDS]
        fgs = [foreground(s["img"]) for s in scs]
        # ★指定できる最小の h は 0.05 x max(距離変換)。画像の中に大きい細胞が
        #   1 つあるだけで、**画像全体の h の下限が上がる**(op の仕様による結合)。
        hmin = float(np.mean([0.05 * edt(fg).max() for fg in fgs]))
        size_tab[(r, "hmin")] = hmin

        def by_class(preds, scs=scs):
            """(大型の過分割, 小型の過分割, 小型に掛かった過統合) の平均件数。"""
            bs, ss, sm = [], [], []
            for s, pred in zip(scs, preds):
                ev = evaluate(s, pred)
                big = s["kind"] == KIND_LARGE
                bs.append(float(np.maximum(ev["per_gt"][big] - 1, 0).sum()))
                ss.append(float(np.maximum(ev["per_gt"][~big] - 1, 0).sum()))
                own = ev["owner_of_pred"]
                small_pred = (own >= 0) & ~big[np.clip(own, 0, None)]
                sm.append(float(np.maximum(ev["per_pred"][small_pred] - 1, 0).sum()))
            return (float(np.mean(bs)), float(np.mean(ss)), float(np.mean(sm)))

        cells = []
        for h in HS_SIZE:
            if h == 0.0:
                preds = [m_ws_all(s["img"], fg) for s, fg in zip(scs, fgs)]
            else:
                preds = [m_ws_h(s["img"], fg, h_px=h) for s, fg in zip(scs, fgs)]
            v = by_class(preds)
            size_tab[(r, h)] = v
            cells.append(pad("%.1f / %.1f / %.1f" % v, 23))
        v = by_class([m_shape(s["img"], fg, h_px=H_DEF) for s, fg in zip(scs, fgs)])
        size_tab[(r, "shape")] = v
        size_tab[(r, "n_big")] = int((scs[0]["kind"] == KIND_LARGE).sum())
        n_small = int((scs[0]["kind"] != KIND_LARGE).sum())
        size_tab[(r, "n_small")] = n_small
        print("  " + pad(f"{r:.1f}x", 8, right=False) + pad(f"{r * r:.1f}x", 8)
              + pad(f"{hmin:.2f}", 18) + "".join(cells) + pad("%.1f/%.1f/%.1f" % v, 18))
    print(f"  (大型 {size_tab[(1.0, 'n_big')]} 個 / 小型 {size_tab[(1.0, 'n_small')]} 個。"
          "「割」= 2 つ以上に割られた件数、「統合」= まとめられた件数)")
    print("  それぞれの集団に最適な h と、**その h を選んだときに他方が払う代償**:")
    print("  " + pad("大きさ比", 10, right=False) + pad("小型に最適な h", 18)
          + pad("そのとき大型が割れる", 24) + pad("大型に最適な h", 18)
          + pad("そのとき小型が統合", 22))
    for r in RATIOS:
        hs = min(HS_SIZE, key=lambda h: size_tab[(r, h)][1] + size_tab[(r, h)][2])
        hb = min(HS_SIZE, key=lambda h: size_tab[(r, h)][0])
        size_tab[(r, "argh")] = (hb, hs)
        print("  " + pad(f"{r:.1f}x", 10, right=False) + pad(f"{hs:.1f}", 18)
              + pad(f"{size_tab[(r, hs)][0]:.1f} / {size_tab[(r, 'n_big')]}", 24)
              + pad(f"{hb:.1f}", 18)
              + pad(f"{size_tab[(r, hb)][2]:.1f} 件", 22))
    print("  → ★**予想は外れた**。「大型と小型で最適な h が分かれる」と踏んでいたが、")
    print("     この場面ではどちらも h=1.0 前後で、**最適な h は分かれなかった**。")
    print("     壊れ方は別の形で出ている:")
    print(f"     (1) 種を細かく撒く(h=0)と **過分割が大型に集中する** —— 大きさ比 1 倍で")
    print(f"         大型 {size_tab[(1.0, 'n_big')]} 個中 {size_tab[(1.0, 0.0)][0]:.1f} 個、"
          f"3 倍で {size_tab[(3.0, 0.0)][0]:.1f} 個"
          f"({100 * size_tab[(3.0, 0.0)][0] / size_tab[(3.0, 'n_big')]:.0f} %)。")
    print("         大きい物体ほど距離変換の尾根が長く、尾根の上の凹凸を種に拾うため。")
    print("         小型の過分割は比によらずほぼ一定なので、これは **大きさの効果**。")
    print("     (2) 小型の過統合は h とともに単調に増えるが、**大きさ比には反応しない**。")
    print("         大型が混じっても小型どうしの分離は悪くならない = 干渉していない。")
    print("  → ★もっと厄介なのは 3 列目。**指定できる最小の h が大きさ比とともに上がる**")
    print(f"     ({size_tab[(1.0, 'hmin')]:.2f} → {size_tab[(3.0, 'hmin')]:.2f} 画素)。"
          "``xsk2_h_maxima`` の h は正規化画像に対する")
    print("     比なので、**画像の中に大きい細胞が 1 つ入っただけで、小さい細胞の側で")
    print("     使える h の下限まで上がってしまう**。スケールの結合が op の仕様に")
    print("     埋め込まれている = 手法の問題ではなく道具の問題。")
    print("  → 形の事前知識(面積から個数を推して、その数まで割る)は、大型細胞を")
    print("     『k 個ぶんの面積がある』と読んで割りにいく。実際には上の h の下限が")
    print("     効いて種が増えず、**割りたくても割れない**ので過分割は増えないが、")
    print("     『1 個ぶんの面積』が単峰であることを暗黙に前提している点は変わらない。")

    print("\n=== 6. 崖 (c) 種の間引き量 h —— 過分割と過統合のトレードオフ ===")
    HS = (0.0, 0.4, 0.75, 1.1, 1.5, 2.0, 2.7, 3.6, 5.0)
    print("  h=0 は間引きなし(全極大)。h は **画素単位**。")
    print("  ★『実効 h』の列に注目 —— 要求した h が小さいと **要求どおりに設定でき**")
    print("     **ない**。``xsk2_h_maxima`` は h を正規化画像に対する 0.05〜0.35 の比で")
    print("     しか受け取らないので、h < 0.05 x max(距離変換) は下限に張り付く。")
    hcurve = {}
    for p in (SPARSE, MID, DENSE):
        print(f"  — 重なり pack {p:.2f} —")
        print("  " + pad("h [px]", 10, right=False) + pad("実効 h", 10)
              + pad("偏り", 9) + pad("散らばり", 11) + pad("過分割", 9)
              + pad("過統合", 9) + pad("過分割+過統合", 16) + pad("1対1", 8))
        fgs = [foreground(s["img"]) for s in base[p]]
        for h in HS:
            if h == 0.0:
                preds = [m_ws_all(s["img"], fg) for s, fg in zip(base[p], fgs)]
                heff = 0.0
            else:
                preds = [m_ws_h(s["img"], fg, h_px=h) for s, fg in zip(base[p], fgs)]
                heff = h_maxima_seeds(edt(fgs[0]), h)[2]
            r = summarize([evaluate(s, pr) for s, pr in zip(base[p], preds)])
            hcurve[(p, h)] = r
            print("  " + pad(f"{h:.1f}", 10, right=False) + pad(f"{heff:.2f}", 10)
                  + pad(f"{r['bias']:+.1f}", 9) + pad(f"{r['scatter']:.1f}", 11)
                  + pad(f"{r['split']:.1f}", 9) + pad(f"{r['merge']:.1f}", 9)
                  + pad(f"{r['split'] + r['merge']:.1f}", 16)
                  + pad(f"{r['one2one']:.0f}", 8))
    print("  " + pad("重なり pack", 14, right=False) + pad("|偏り| 最小の h", 18)
          + pad("そのときの過分割/過統合", 26) + pad("1対1 最大の h", 18)
          + pad("その 1対1", 12))
    best_h = {}
    for p in (SPARSE, MID, DENSE):
        hb = min(HS, key=lambda h: abs(hcurve[(p, h)]["bias"]))
        ho = max(HS, key=lambda h: hcurve[(p, h)]["one2one"])
        best_h[p] = (hb, ho)
        print("  " + pad(f"{p:.2f}", 14, right=False) + pad(f"{hb:.1f}", 18)
              + pad(f"{hcurve[(p, hb)]['split']:.1f} / "
                    f"{hcurve[(p, hb)]['merge']:.1f}", 26)
              + pad(f"{ho:.1f}", 18) + pad(f"{hcurve[(p, ho)]['one2one']:.0f}", 12))
    print("  → 過分割は h とともに単調に減り、過統合は単調に増える —— **トレードオフ**。")
    print("     合計(右から 3 列目)には谷ができるが、その谷の位置と『偏りがゼロに")
    print("     なる h』は **一致しない**。どちらを最適と呼ぶかで答えが変わる。")
    hb_list = [best_h[p][0] for p in (SPARSE, MID, DENSE)]
    ho_list = [best_h[p][1] for p in (SPARSE, MID, DENSE)]
    print(f"  → **最適な h は基準によっても密度によっても動く**: 偏り基準で {hb_list}、"
          f"1対1 基準で {ho_list}。")
    if len(set(hb_list)) > 1:
        print("     偏り基準の最適 h は密度で動くので、疎な場面で決めた h をそのまま")
        print("     密な場面へ持っていくと壊れる。1 対 1 基準では **動かなかった** ——")
        print("     『最適な h は密度で動く』は基準を書かないと真偽が決まらない主張。")
    print("  → もう 1 つ: h=0(全極大)の行だけ **偏りが正**で、他は全部負。h の")
    print("     ノブは連続に見えて、実は「種を全部使う」か「間引く」かで挙動が")
    print("     切れている。下限(実効 h の列)より下は刻めないので、その境目の")
    print("     内側は **この op では覗けない**。節 7 で別のノブに切り替える理由。")
    # トレードオフは 2 本の線が逆向きに走ることそのものなので、図が言葉より速い。
    # 「誤り合計の谷」と「|偏り| の谷」が**別の場所にある**のが要点。
    _h = np.asarray(HS, float)
    figs.save_plot("h_tradeoff",
                   [("過分割", _h, np.array([hcurve[(MID, h)]["split"] for h in HS])),
                    ("過統合", _h, np.array([hcurve[(MID, h)]["merge"] for h in HS])),
                    ("誤り合計", _h, np.array([hcurve[(MID, h)]["split"]
                                               + hcurve[(MID, h)]["merge"] for h in HS])),
                    ("|偏り|", _h, np.array([abs(hcurve[(MID, h)]["bias"]) for h in HS]))],
                   xlabel="種の間引き量 h [px]", ylabel="件数(3 枚平均)",
                   title="h のトレードオフ(重なり pack %.2f)" % MID,
                   caption="誤り合計の谷と |偏り| の谷は同じ場所に来ない。"
                           "どちらを最適と呼ぶかで答えが変わる。")

    print("\n=== 7. ★計数が合っていて分割が全部外れている点を探す ===")
    print("  過分割と過統合は逆向きに動くので、**どこかで打ち消し合う**。h の下限に")
    print("  阻まれてその点を跨げないので、ここでは種を **空間的な間隔** で間引く")
    print("  ノブ(``vol_local_maxima`` の min_distance)を使って細かく刻む。")
    MDS = (1, 2, 3, 4, 5, 6, 8)
    cancel = {}
    for p in (MID, DENSE):
        print(f"  — 重なり pack {p:.2f}(真の個数 {base[p][0]['n']})—")
        print("  " + pad("種の最小間隔 [px]", 20, right=False) + pad("偏り", 9)
              + pad("散らばり", 11) + pad("過分割", 9) + pad("過統合", 9)
              + pad("誤り合計", 12) + pad("1対1", 8))
        fgs = [foreground(s["img"]) for s in base[p]]
        rows = {}
        for md in MDS:
            r = summarize([evaluate(s, m_ws_md(s["img"], fg, min_distance=md))
                           for s, fg in zip(base[p], fgs)])
            rows[md] = r
            print("  " + pad(f"{md}", 20, right=False) + pad(f"{r['bias']:+.1f}", 9)
                  + pad(f"{r['scatter']:.1f}", 11) + pad(f"{r['split']:.1f}", 9)
                  + pad(f"{r['merge']:.1f}", 9)
                  + pad(f"{r['split'] + r['merge']:.1f}", 12)
                  + pad(f"{r['one2one']:.0f}", 8))
        mdb = min(MDS, key=lambda m: abs(rows[m]["bias"]))
        tot_min = min(rows[m]["split"] + rows[m]["merge"] for m in MDS)
        o2o_max = max(rows[m]["one2one"] for m in MDS)
        cancel[p] = (mdb, rows[mdb], tot_min, o2o_max, rows)
        r = rows[mdb]
        print(f"    |偏り| が最小なのは間隔 {mdb}(偏り {r['bias']:+.1f} = "
              f"真値の {100 * abs(r['bias']) / r['n_gt']:.1f} %)。そのときの")
        print(f"    分割誤りは {r['split'] + r['merge']:.1f} 件で、"
              f"誤り合計の最小 {tot_min:.1f} 件より多く、")
        print(f"    1 対 1 対応は {r['one2one']:.0f} / {r['n_gt']:.0f} 個"
              f"(最大 {o2o_max:.0f} 個)。")
    # 「計数が合っている」= 偏りが真値の 3 % 未満の行だけを候補にする(そうしないと
    # 単に誤りが多いだけの行が選ばれ、この節の主張が成り立たない)。
    ok = [p for p in (MID, DENSE)
          if abs(cancel[p][1]["bias"]) < 0.03 * cancel[p][1]["n_gt"]]
    worst = max(ok or [MID, DENSE],
                key=lambda p: cancel[p][1]["split"] + cancel[p][1]["merge"])
    cw = cancel[worst][1]
    print(f"  → ★いちばん危ないのは pack {worst:.2f} / 間隔 {cancel[worst][0]} の行:")
    print(f"     **個数の偏りは {cw['bias']:+.1f} 個**(真値 {cw['n_gt']:.0f} 個の"
          f" {100 * abs(cw['bias']) / cw['n_gt']:.1f} %)= ほぼ完璧に見えるのに、")
    print(f"     過分割 {cw['split']:.1f} 件 + 過統合 {cw['merge']:.1f} 件 ="
          f" {cw['split'] + cw['merge']:.1f} 件の分割誤りが残り、")
    print(f"     1 対 1 に正しく対応した細胞は {cw['one2one']:.0f} / {cw['n_gt']:.0f} 個"
          f"({100 * cw['one2one'] / cw['n_gt']:.0f} %)しかない。")
    print("     **個数だけを報告していたら最良の設定として通る**。打ち消し合いの機序も")
    print("     はっきりしている: 過分割は個数を +1、過統合は -1 に動かすので、両者が")
    print("     同数なら **個数は元に戻る**。個数は分割の質の証拠にならない。")
    # ★この PoC の見出し。偏りの線が 0 を横切る場所で、分割誤りは谷になっていない。
    _rows = cancel[worst][4]
    _md = np.asarray(MDS, float)
    figs.save_plot("count_cancellation",
                   [("偏り(個数)", _md, np.array([_rows[m]["bias"] for m in MDS])),
                    ("過分割", _md, np.array([_rows[m]["split"] for m in MDS])),
                    ("過統合", _md, np.array([_rows[m]["merge"] for m in MDS])),
                    ("誤り合計", _md, np.array([_rows[m]["split"] + _rows[m]["merge"]
                                                for m in MDS]))],
                   xlabel="種の最小間隔 [px]", ylabel="件数 / 個数の偏り",
                   title="計数が合う点と、分割が合う点は別(pack %.2f)" % worst,
                   caption="偏りが 0 を横切る間隔 %d で分割誤りは %.1f 件残る。"
                           "個数だけ見ていると最良の設定として通る。"
                           % (cancel[worst][0], cw["split"] + cw["merge"]))

    print("\n=== 8. 崖 (d) 雑音と背景ムラ ===")
    print("  ★**偽物(細胞でないものを 1 個と数えた)を分けて出す** —— これを個数に")
    print("     混ぜると、雑音で前景が粒々になった場面が『過分割が増えた』に見える。")
    NOISE_METHODS = (METHODS[0], METHODS[2], METHODS[3])
    print("  " + pad("条件", 24, right=False) + pad("前景率", 9)
          + "".join(pad(n.split("(")[0][:12], 26) for n, _ in NOISE_METHODS))
    print("  " + pad("", 24, right=False) + pad("", 9)
          + "".join(pad("偏り/分割/統合/偽", 26) for _ in NOISE_METHODS))
    noise_tab = {}
    noise_rows = []                     # 図の材料(ゼロ点の列だけを抜き出す)
    truth_fg = None
    for label, kw in (("基準", {}),
                      ("光子 1/4(雑音 2 倍)", {"photons": PHOTONS / 4}),
                      ("光子 1/9(雑音 3 倍)", {"photons": PHOTONS / 9}),
                      ("背景ムラ 2.5 倍", {"bg_amp": 2.5 * BG_AMP}),
                      ("背景ムラ 5 倍", {"bg_amp": 5.0 * BG_AMP}),
                      ("両方(1/9 + 5 倍)", {"photons": PHOTONS / 9,
                                             "bg_amp": 5.0 * BG_AMP})):
        scs = [make_scene(s, pack=BASE_PACK, **kw) for s in SEEDS]
        fgs = [foreground(s["img"]) for s in scs]
        fgr = float(np.mean([f.mean() for f in fgs]))
        if truth_fg is None:
            truth_fg = float(np.mean([(s["owner"] > 0).mean() for s in scs]))
        cells = []
        for name, fn in NOISE_METHODS:
            r = summarize([evaluate(s, fn(s["img"], fg)) for s, fg in zip(scs, fgs)])
            noise_tab[(label, name)] = r
            cells.append(pad(f"{r['bias']:+.0f}/{r['split']:.0f}/"
                             f"{r['merge']:.0f}/{r['spurious']:.0f}", 26))
        noise_tab[(label, "fg")] = fgr
        _z = noise_tab[(label, METHODS[0][0])]
        noise_rows.append([label, "%.1f %%" % (100 * fgr), "%+.1f" % _z["bias"],
                           "%.1f" % _z["split"], "%.1f" % _z["merge"],
                           "%.1f" % _z["spurious"]])
        print("  " + pad(label, 24, right=False) + pad(f"{100 * fgr:.1f} %", 9)
              + "".join(cells))
    print(f"  (真値の前景率 = 細胞が占める画素の割合 {100 * truth_fg:.1f} %)")
    print("  → **雑音と背景ムラは効き方が違う**。雑音は前景を粒々にするので")
    print("     **偽物**が爆発する(過分割ではない —— 真値の細胞に触れていないので)。")
    print("     背景ムラは大津の閾値を動かして前景率そのものを 3 倍にずらし、")
    print("     細胞が膨らんでくっつくので **過統合**が増える。**同じ『画質が悪い』**")
    print("     **でも直し方が逆**で、前者は面積による棄却か平滑化、後者は背景補正")
    print("     (shading correction)が要る。")
    print("  → 分水嶺を通す 2 つは偽物が桁で少ない。形の事前知識は面積の下限で明示的に")
    print("     落としているが、h-maxima のほうは **意図せずそうなっている** ——")
    print("     デブリは距離変換が小さく h に届かないので種が立たず、マスク内でも")
    print("     どの流域にも属さないまま残る。**同じ『強い』でも、片方は設計、片方は")
    print("     副作用**。副作用のほうは細胞が小さい標本に移した途端に裏返る。")
    # 「同じ画質の悪さ」で壊れる列が違う、が一目で読める形にしておく
    # (雑音 → 偽物の列だけ跳ねる / 背景ムラ → 前景率と過統合が動く)。
    figs.save_table("noise_vs_shading",
                    ["条件", "前景率", "偏り", "過分割", "過統合", "偽物"],
                    noise_rows, col_w=120,
                    title="雑音と背景ムラは壊れる列が違う(ゼロ点で測る)",
                    caption="真値の前景率 %.1f %%。雑音は偽物を、背景ムラは前景率と"
                            "過統合を動かす —— 直し方が逆。" % (100 * truth_fg))

    print("\n=== 9. 崖 (e) 縁で切れた細胞をどう数えるか ===")
    print("  3 通りの規約: 全部数える / 縁に触れたものを捨てる / 半分に数える。")
    print("  分割は節 7 で偏りが最小だった設定(種の最小間隔 5 画素)を使う ——")
    print("  分割が大きく外れている設定だと、規約の差がその誤差に埋もれてしまう。")
    print("  " + pad("規約", 22, right=False) + pad("真値", 10) + pad("推定", 10)
          + pad("偏り", 9) + pad("散らばり", 11) + "  "
          + pad("真値との差の由来", 24, right=False))
    edge_tab = {}
    fgs = [foreground(s["img"]) for s in base[BASE_PACK]]
    preds = [m_ws_md(s["img"], fg, min_distance=5)
             for s, fg in zip(base[BASE_PACK], fgs)]
    for rule in ("全部数える", "縁を捨てる", "半分に数える"):
        gts, ests = [], []
        for s, pred in zip(base[BASE_PACK], preds):
            k = int(pred.max())
            pp = per_object(pred, k)
            pe = sum(1 for v in pp.values() if v["edge"])
            gt_e = int(s["on_edge"].sum())
            if rule == "全部数える":
                gts.append(s["n"]); ests.append(k)
            elif rule == "縁を捨てる":
                gts.append(s["n"] - gt_e); ests.append(k - pe)
            else:
                gts.append(s["n"] - 0.5 * gt_e); ests.append(k - 0.5 * pe)
        e = np.asarray(ests, float) - np.asarray(gts, float)
        edge_tab[rule] = (float(np.mean(gts)), float(np.mean(ests)),
                          float(e.mean()), float(e.std()))
        note = {"全部数える": "縁の半端な塊も 1 個と数える",
                "縁を捨てる": "真値側も同じ規約で捨てている",
                "半分に数える": "折衷(Gundersen 流)"}[rule]
        print("  " + pad(rule, 22, right=False) + pad(f"{edge_tab[rule][0]:.1f}", 10)
              + pad(f"{edge_tab[rule][1]:.1f}", 10)
              + pad(f"{edge_tab[rule][2]:+.1f}", 9)
              + pad(f"{edge_tab[rule][3]:.1f}", 11) + "  "
              + pad(note, 24, right=False))
    spread = max(v[1] for v in edge_tab.values()) - min(v[1] for v in edge_tab.values())
    print(f"  → **規約を変えるだけで推定個数が {spread:.1f} 個動く**"
          f"(真値 {edge_tab['全部数える'][0]:.0f} 個の"
          f" {100 * spread / edge_tab['全部数える'][0]:.0f} %)。規約を書かずに")
    print("     『細胞数 N 個』と報告してはいけない。")
    print("  → ★ただし、真値の側も同じ規約で数えれば **偏りはどの規約でも小さい**。")
    print("     危ないのは規約の選択そのものではなく、**推定と真値で違う規約を使う**")
    print("     ことのほう(例: 装置が縁を捨てて数え、参照は全部数えている)。")

    print("\n=== 10. 面積と長短径の推定誤差 —— 見えている面積までしか取れない ===")
    print("  1 対 1 に対応した細胞だけを見る。面積は画素数、長短径はモーメント楕円と")
    print("  ``fs.fit_ellipse``(境界点への直接最小二乗当てはめ)の両方で出す。")
    print("  ★**隠れた割合の帯で分ける** —— 混ぜると、隠れていない細胞が数で薄めて")
    print("     『面積はよく当たる』に見えてしまう。")
    print("  " + pad("隠れた割合", 14, right=False) + pad("細胞数", 9)
          + pad("面積 vs 見えている面積", 26) + pad("面積 vs 真の面積", 22)
          + pad("ra(モーメント)", 20) + pad("ra(当てはめ)", 20)
          + pad("rb(モーメント)", 20))
    OCC_EDGES = ((0.0, 0.02), (0.02, 0.08), (0.08, 1.01))
    OCC_LBL = ("~2 %", "2-8 %", "8 % 超")
    bins = {i: {"dv": [], "dt": [], "ra": [], "rf": [], "rb": []}
            for i in range(len(OCC_EDGES))}
    area_tab = {}
    for p in (SPARSE, MID, DENSE):
        fgs2 = [foreground(s["img"]) for s in base[p]]
        dv, dt = [], []
        for s, fg in zip(base[p], fgs2):
            pred = m_ws_h(s["img"], fg, h_px=H_DEF)
            ev = evaluate(s, pred)
            pp = per_object(pred, ev["n_pred"])
            # 境界点(4 近傍でラベルが違う画素)—— 楕円当てはめの入力
            bnd = np.zeros_like(pred, bool)
            bnd[:-1, :] |= pred[:-1, :] != pred[1:, :]
            bnd[1:, :] |= pred[:-1, :] != pred[1:, :]
            bnd[:, :-1] |= pred[:, :-1] != pred[:, 1:]
            bnd[:, 1:] |= pred[:, :-1] != pred[:, 1:]
            bnd &= pred > 0
            for g, q in ev["one2one"]:
                if s["on_edge"][g] or q not in pp:
                    continue
                a_pred = pp[q]["area"]
                e_vis = 100.0 * (a_pred / max(s["area_vis"][g], 1.0) - 1.0)
                e_true = 100.0 * (a_pred / max(s["area_true"][g], 1.0) - 1.0)
                dv.append(e_vis)
                dt.append(e_true)
                o = float(s["occ"][g])
                bi = next(i for i, (a, b) in enumerate(OCC_EDGES) if a <= o < b)
                ra_t, rb_t = s["cells"][g][2], s["cells"][g][3]
                bins[bi]["dv"].append(e_vis)
                bins[bi]["dt"].append(e_true)
                bins[bi]["ra"].append(100.0 * (pp[q]["ra"] / ra_t - 1.0))
                bins[bi]["rb"].append(100.0 * (pp[q]["rb"] / rb_t - 1.0))
                ys, xs = np.nonzero(bnd & (pred == q))
                if ys.size >= 6:
                    try:
                        e = fs.fit_ellipse(np.stack([ys, xs], 1).astype(float))
                        bins[bi]["rf"].append(100.0 * (e["ra"] / ra_t - 1.0))
                    except Exception:
                        pass
        area_tab[p] = (len(dv), float(np.mean(dv)), float(np.mean(dt)))
    f = lambda v: f"{np.mean(v):+.1f}±{np.std(v):.1f}" if len(v) else "—"
    for i, lbl in enumerate(OCC_LBL):
        b = bins[i]
        print("  " + pad(lbl, 14, right=False) + pad(f"{len(b['dv'])}", 9)
              + pad(f(b["dv"]), 26) + pad(f(b["dt"]), 22) + pad(f(b["ra"]), 20)
              + pad(f(b["rf"]), 20) + pad(f(b["rb"]), 20))
    print("  " + pad("(全部混ぜる)", 14, right=False)
          + pad(f"{sum(len(bins[i]['dv']) for i in bins)}", 9)
          + pad(f(sum((bins[i]["dv"] for i in bins), [])), 26)
          + pad(f(sum((bins[i]["dt"] for i in bins), [])), 22))
    #: いちばん隠れている帯のうち、細胞が 3 個以上入っているもの。**よく隠れた細胞は
    #: そもそも 1 対 1 に対応しない**(隣とまとめられる)ので、いちばん上の帯は
    #: 空になりうる —— それ自体が「重なった細胞の形は測れない」ことの現れである。
    occ_hi = max(i for i in bins if len(bins[i]["dv"]) >= 3)
    print(f"  (帯の分布は **両極に寄る** —— ほとんどが「{OCC_LBL[0]}」で、真ん中の帯は"
          "ほぼ空。少しだけ")
    print("   隠れる状況が少ないのではなく、**よく隠れた細胞は 1 対 1 に対応しない**")
    print("   (隣とまとめられる)ので、形を測る対象から先に落ちるためである。")
    print(f"   3 個以上残っているいちばん隠れた帯は「{OCC_LBL[occ_hi]}」)")
    print("  → 単位は %。**隠れていない細胞では 2 つの列がほぼ一致する**のに、")
    print("     隠れた細胞では『見えている面積』には当たったまま『真の面積』だけが")
    print("     大きく下振れする。この差は分割の巧拙ではなく、**隠れた部分は原理的に")
    print("     観測できない**ことの現れ = 誤差の床である。最下行のように混ぜると")
    print("     床が薄まって見えなくなる。")
    print("  → 長半径はモーメント楕円のほうが安定する。境界点への当てはめは、")
    print("     分水嶺が引いた **直線的な切断面** をそのまま楕円弧と読むので、")
    print("     切られた細胞で大きく外れる。切断面を除いて当てはめる仕掛けが要る。")

    print(f"\n=== 11. 速度(この機械での実測、{IMG}x{IMG} の 1 枚あたり)===")
    probe = base[BASE_PACK][0]["img"]
    fgp = foreground(probe)
    speed = {}
    for name, fn in (("大津 + 穴埋め(前処理)", lambda: foreground(probe)),
                     ("連結成分(ゼロ点)", lambda: m_cc(probe, fgp)),
                     ("距離変換+分水嶺(全極大)", lambda: m_ws_all(probe, fgp)),
                     (f"h-maxima 分水嶺", lambda: m_ws_h(probe, fgp, h_px=H_DEF)),
                     ("形の事前知識", lambda: m_shape(probe, fgp, h_px=H_DEF))):
        fn()
        t = time.perf_counter()
        for _ in range(3):
            fn()
        speed[name] = 1e3 * (time.perf_counter() - t) / 3
        print("  " + pad(name, 26, right=False) + pad(f"{speed[name]:.1f}", 9) + " ms")
    slowest = max(speed, key=lambda k: speed[k])
    print(f"  → いちばん遅いのは {slowest}({speed[slowest]:.1f} ms)で、"
          f"ゼロ点の {speed['連結成分(ゼロ点)']:.1f} ms の")
    print(f"     {speed[slowest] / max(speed['連結成分(ゼロ点)'], 1e-9):.0f} 倍。"
          "形の事前知識は連結成分ごとに Python の for を回して部分画像に")
    print("     分水嶺を掛けるので **塊の数に比例**し、密な場面では逆に速くなる。")
    print(f"     とはいえ全部が 1 枚 {max(speed.values()):.0f} ms 以内なので、"
          "この規模では速度は選択理由にならない。")

    print("\n=== 12. 道具の穴(この PoC で当たったもの)===")
    holes = (
        ("2 次元の連結成分ラベリングが facade に無い",
         "vol_label に厚さ 1 のボリュームを渡して代用。fs.op 側は個数スカラーのみ"),
        ("2 次元の per-object region props が無い",
         "3 次元の vol_region_props はあるのに 2 次元は image 全体の 1 スカラー"),
        ("distance_transform が最大値で正規化される",
         "画素単位の距離が取れない。vol_distance_transform で代用"),
        ("xsk2_h_maxima が [0,1] 切り詰め + h は比でしか振れない",
         "画素単位の h を指定できない。h < 0.05*max(EDT) は表現不能"),
        ("2 次元 watershed が公開されていない(→ 2026-10-02 に fs.ledger.watersheds_marker で解消)",
         "発見時は segmentation.watersheds_marker がモジュール直下のみ。mask 引数は今も無い"),
        ("circularity / eccentricity / area_center が物体ごとに取れない",
         "画像全体の 1 スカラー。分割判定に使えないので自前でモーメントを回した"),
    )
    for a, b in holes:
        print("  ・" + a)
        print("      → " + b)

    print("\n=== 13. まとめ ===")
    lines = (
        ("ゼロ点(大津+連結成分)で足りるか",
         f"疎なら足りる(偏り {zero[SPARSE]['bias']:+.1f})が、"
         f"密で {zero[DENSE]['bias']:+.1f} 個。失点は全部過統合"),
        ("分水嶺は何を直すか",
         f"中密度なら過統合を {zero[MID]['merge']:.0f} → "
         f"{dens[(MID, ws_name)]['merge']:.0f} 件へ。密では "
         f"{zero[DENSE]['merge']:.0f} → {dens[(DENSE, ws_name)]['merge']:.0f} で直らない"),
        ("h をどう選ぶか",
         f"選べない。偏り基準の最適 h が密度で {hb_list} と動く"),
        ("大きさが 3 倍違うと",
         f"小型に最適な h では大型 {size_tab[(3.0, 'n_big')]} 個中 "
         f"{size_tab[(3.0, size_tab[(3.0, 'argh')][1])][0]:.1f} 個が割れる。"
         f"指定可能な最小 h も {size_tab[(1.0, 'hmin')]:.2f}→"
         f"{size_tab[(3.0, 'hmin')]:.2f} px へ上がる"),
        ("★いちばん危ない読み違え",
         f"個数の偏り {cw['bias']:+.1f} 個で分割誤り {cw['split'] + cw['merge']:.0f} 件。"
         "過分割と過統合が打ち消し合う"),
        ("縁の規約",
         f"規約を変えるだけで推定が {spread:.1f} 個動く。推定と真値で規約を揃える"),
        ("面積の誤差の床",
         f"隠れ {OCC_LBL[occ_hi]} の帯では 見えている面積 "
         f"{np.mean(bins[occ_hi]['dv']):+.1f} % に対し"
         f" 真の面積 {np.mean(bins[occ_hi]['dt']):+.1f} %"),
    )
    for q, a in lines:
        print("  " + pad(q, 34, right=False) + a)
    print(f"\n  全体の所要 {time.perf_counter() - t0:.1f} 秒")

    # ---- 自己検査(速さは assert しない)------------------------------------- #
    # (1) 合成が要求どおり: 個数は pack に依らず一定で、重なりだけが単調に増える
    ns = [base[p][0]["n"] for p in PACKS]
    assert len(set(ns)) == 1, ns
    ovs = [occ_tab[p][0] for p in PACKS]
    # pack 1.25 以上ではコロニーがそもそも重ならないので、左端 2 列は
    # 鎖のぶんだけの底に張り付く(単調を要求しない)。底を越えたあとは単調。
    assert all(ovs[i] <= ovs[i + 1] + 1e-9 for i in range(2, len(ovs) - 1)), ovs
    assert ovs[0] > 0.10 and ovs[-1] > 2.5 * ovs[0], ovs
    # 構造が実在する: 大型集団は面積で 3 倍以上、デブリは owner に入っていない
    big = sc0["area_true"][sc0["kind"] == KIND_LARGE].mean()
    sml = sc0["area_true"][sc0["kind"] == KIND_SINGLE].mean()
    assert big > 3.0 * sml, (big, sml)
    assert int(sc0["owner"].max()) <= sc0["n"], sc0["owner"].max()

    # (2) ゼロ点は重なりとともに単調に下振れし、失点は過統合に偏る
    zb = [zero[p]["bias"] for p in PACKS]
    assert all(zb[i] > zb[i + 1] for i in range(len(zb) - 1)), zb
    assert zb[-1] < -0.25 * zero[PACKS[-1]]["n_gt"], zb          # 3 割超の取りこぼし
    assert zero[PACKS[-1]]["merge"] > 10.0 * max(zero[PACKS[-1]]["split"], 1.0), zero
    assert zero[PACKS[-1]]["scatter"] < 0.5 * abs(zb[-1]), zero  # 枚数では消えない
    # ★過統合と取りこぼしは別物 —— くっついても「消えて」はいない
    assert zero[PACKS[-1]]["merge"] > 5.0 * (zero[PACKS[-1]]["missed"] + 1.0), zero

    # (3) 分水嶺はゼロ点の過統合を減らす(が過分割を出す)。密では減り方が鈍る。
    for p in PACKS:
        assert dens[(p, ws_name)]["merge"] <= zero[p]["merge"] + 1.0, (p, dens[(p, ws_name)])
    assert dens[(MID, ws_name)]["merge"] < zero[MID]["merge"] - 3.0, dens[(MID, ws_name)]
    for p in (MID, DENSE):
        assert dens[(p, ws_name)]["split"] > zero[p]["split"], (p, dens[(p, ws_name)])
    # 全極大は最初から過分割が高い(疎な条件でも)
    assert dens[(SPARSE, "距離変換+分水嶺(全極大)")]["split"] \
        > dens[(SPARSE, ws_name)]["split"] + 3.0, dens[(SPARSE, "距離変換+分水嶺(全極大)")]
    # 形の事前知識は疎な条件で過分割を抑える
    assert res3[(SPARSE, "形の事前知識(充填率+面積)")]["split"] \
        <= res3[(SPARSE, "距離変換+分水嶺(全極大)")]["split"], res3
    # 面積割りは分割を一切しないのに個数の偏りは小さい = 個数は分割の証拠にならない
    assert abs(res3[(DENSE, "面積割り(個数のみ)")]["bias"]) < abs(zero[DENSE]["bias"]), res3

    # (4) 崖 (c) h のトレードオフ: 過分割は単調に減り、過統合は単調に増える
    for p in (SPARSE, MID, DENSE):
        sp = [hcurve[(p, h)]["split"] for h in HS]
        mg = [hcurve[(p, h)]["merge"] for h in HS]
        assert sp[0] > sp[-1] + 5.0, (p, sp)
        assert mg[-1] > mg[0] + 4.0, (p, mg)
        # 単調性は雑音で少し崩れてよい(3 枚平均なので 1 件 = 0.33 の粒)。
        # 相関係数は平坦な区間が長いと当てにならないので、隣どうしで見る。
        assert all(sp[i] >= sp[i + 1] - 0.8 for i in range(len(sp) - 1)), (p, sp)
        assert all(mg[i] <= mg[i + 1] + 0.8 for i in range(len(mg) - 1)), (p, mg)
    # ★最適な h は密度で動く(偏り基準か 1対1 基準のどちらかで必ず動く)
    assert len(set(hb_list)) > 1 or len(set(ho_list)) > 1, (hb_list, ho_list)

    # (5) ★計数が合っていて分割が全部外れている点が実在する
    #     偏りが 3 % 未満なのに、分割誤りが多く残り、1 対 1 対応も最良から離れている。
    found = False
    for p in (MID, DENSE):
        mdb, r, tot_min, o2o_max, rows = cancel[p]
        if abs(r["bias"]) < 0.03 * r["n_gt"]:
            found = True
            assert (r["split"] + r["merge"]) > tot_min, (p, r, tot_min)
            assert r["one2one"] < 0.85 * r["n_gt"], (p, r)
        # 間隔を広げると過分割は減り過統合は増える(こちらのノブでもトレードオフ)
        sp = [rows[m]["split"] for m in MDS]
        mg = [rows[m]["merge"] for m in MDS]
        assert sp[0] > sp[-1], (p, sp)
        assert mg[-1] > mg[0], (p, mg)
    assert found, {p: cancel[p][1]["bias"] for p in (MID, DENSE)}

    # (6) 崖 (b) 大きさ: 大型と小型で h への要求が逆を向く
    for r in RATIOS:
        bsp = [size_tab[(r, h)][0] for h in HS_SIZE]     # 大型の過分割
        smg = [size_tab[(r, h)][2] for h in HS_SIZE]     # 小型の過統合
        assert bsp[0] >= bsp[-1], (r, bsp)               # h を上げれば割れなくなる
        assert smg[-1] >= smg[0], (r, smg)               # h を上げればくっつく
    # 大きさ比が上がるほど、種を細かく撒いたときに大型が割れる
    bs = [size_tab[(r, 0.0)][0] for r in RATIOS]
    assert bs[-1] > bs[0] + 2.0, bs
    assert bs[-1] > 0.5 * size_tab[(3.0, "n_big")], (bs, size_tab[(3.0, "n_big")])
    # ★指定できる最小の h が大きさ比とともに上がる(道具の仕様によるスケール結合)
    hmins = [size_tab[(r, "hmin")] for r in RATIOS]
    assert all(hmins[i] <= hmins[i + 1] + 1e-9 for i in range(len(hmins) - 1)), hmins
    assert hmins[-1] > 1.6 * hmins[0], hmins

    # (7) 崖 (d) 雑音は「偽物」を、背景ムラは前景率と「過統合」を壊す —— 効き方が違う
    zname = METHODS[0][0]
    n_base = noise_tab[("基準", zname)]
    n_noisy = noise_tab[("光子 1/9(雑音 3 倍)", zname)]
    n_shade = noise_tab[("背景ムラ 5 倍", zname)]
    assert n_noisy["spurious"] > 3.0 * (n_base["spurious"] + 1.0), (n_base, n_noisy)
    assert n_shade["merge"] > n_base["merge"] + 5.0, (n_base, n_shade)
    # 雑音は前景率をほとんど動かさない / 背景ムラは大きく動かす = 別の壊れ方
    fg_base = noise_tab[("基準", "fg")]
    fg_shade = noise_tab[("背景ムラ 5 倍", "fg")]
    fg_noisy = noise_tab[("光子 1/9(雑音 3 倍)", "fg")]
    assert abs(fg_shade - truth_fg) > abs(fg_noisy - truth_fg) + 0.05, \
        (fg_base, fg_noisy, fg_shade, truth_fg)
    # 面積の下限を持つ手法だけが雑音の偽物を落とせる
    assert noise_tab[("光子 1/9(雑音 3 倍)", METHODS[3][0])]["spurious"] \
        < 0.2 * n_noisy["spurious"], noise_tab[("光子 1/9(雑音 3 倍)", METHODS[3][0])]

    # (8) 崖 (e) 縁: 規約を変えると推定が動くが、真値も同じ規約なら偏りは小さい
    assert spread > 2.0, spread
    for rule, v in edge_tab.items():
        assert abs(v[2]) < 0.12 * edge_tab["全部数える"][0], (rule, v)

    # (9) 面積: 見えている面積には当たるが、真の面積には重なりぶん届かない(床)
    #     隠れていない帯では 2 つの列が一致し、隠れた帯では真の面積だけが外れる。
    assert occ_hi >= 2 and len(bins[0]["dv"]) > 20, \
        (occ_hi, [len(bins[i]["dv"]) for i in bins])
    assert abs(np.mean(bins[0]["dv"]) - np.mean(bins[0]["dt"])) < 3.0, \
        (np.mean(bins[0]["dv"]), np.mean(bins[0]["dt"]))
    assert np.mean(bins[occ_hi]["dt"]) < np.mean(bins[occ_hi]["dv"]) - 5.0, \
        (np.mean(bins[occ_hi]["dv"]), np.mean(bins[occ_hi]["dt"]))
    # 混ぜると床が薄まる = 帯で分ける根拠
    all_dt = sum((bins[i]["dt"] for i in bins), [])
    assert np.mean(all_dt) > np.mean(bins[occ_hi]["dt"]) + 3.0, np.mean(all_dt)
    assert area_tab[DENSE][2] < area_tab[SPARSE][2], area_tab

    # (10) ★道具の穴が「まだ在る」ことを機械で確かめる(直ったら落ちる = 良い落ち方)
    #      (a) 進化 op の距離変換は最大値で正規化される
    m = np.zeros((32, 32), bool)
    m[8:24, 8:24] = True
    dn_op = fs.apply(m.astype(np.float64), "distance_transform")
    d_px = edt(m)
    assert abs(float(dn_op.max()) - 1.0) < 1e-9, float(dn_op.max())
    assert d_px.max() > 7.0, float(d_px.max())
    #      (b) xsk2_h_maxima は入力を [0,1] に切り詰める(生の距離を渡すと壊れる)
    raw = fs.apply(d_px, "xsk2_h_maxima", a=0.5)
    nrm = fs.apply(d_px / d_px.max(), "xsk2_h_maxima", a=0.5)
    assert float(raw.sum()) != float(nrm.sum()), (raw.sum(), nrm.sum())
    #      (c) 2 次元の per-object region props が無い(image 全体の 1 スカラー)
    two = np.zeros((40, 40), np.float64)
    two[5:15, 5:15] = 1.0
    two[25:35, 25:35] = 1.0
    c = np.asarray(fs.apply(two, "circularity"))
    assert c.size == 1 or float(c.min()) == float(c.max()), c.shape
    #      (d) 2 次元 watershed: 発見時は segmentation.py の中にだけ在った。2026-10-02 に
    #          台帳(fs.ledger.watersheds_marker、opssegmentation)へ載せた。fs 直下には出していない。
    assert hasattr(fsseg, "watersheds_marker"), "モジュール側から消えた"
    assert hasattr(fs.ledger, "watersheds_marker"), "台帳から消えた(2026-10-02 に載せたもの)"
    assert not hasattr(fs, "watersheds_marker"), "fs 直下にも出た(この節を書き換えること)"
    #      (e) 2 次元のラベリング / region props は 3 次元にしか無い
    assert hasattr(fs.ledger, "vol_label") and hasattr(fs.ledger, "vol_region_props")
    assert not hasattr(fs.ledger, "label"), "2 次元ラベリングが生えた(良い変化)"

    if figs.errors():
        print("図の書き出しで失敗:", "; ".join(figs.errors()))
    print("\nPASS")


if __name__ == "__main__":
    main()
