# -*- coding: utf-8 -*-
# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""gallery2d_morphology — モルフォロジー(形態学)op 一族を総なめで叩き、契約とGTで検証する (task: morphology-gallery)。

    py -3.11 examples/gallery2d_morphology.py

【平たく言うと】
モルフォロジー(数理形態学)は、画像の明るい/暗い塊の「形」を構造要素(SE, 近傍窓)で
削る・盛る操作の一族。基本は erosion(収縮=局所min)/ dilation(膨張=局所max)、その
合成が opening(小さな明点を消す)/ closing(小さな暗穴を埋める)。差分をとると
top-hat(SEより小さい明ディテール抽出)/ black-hat(暗ディテール抽出)/ morphological
gradient(境界応答=エッジ)になる。粒径解析・欠陥検出・照明ムラ補正・文字/血管抽出など
「特定サイズの構造だけ残す/消す」用途の土台。この op 一族(erode/dilate/open/close/
tophat/blackhat/gradient と、その skimage / OpenCV / scipy / 面積・直径・再構成・骨格
派生)を **全て** 実行し、数値で検証する。

【グラウンドトゥルース(数値で嘘を弾く)】
一族の全 op に対して普遍契約(有限・宣言 out_sort 一致・[0,1] 値域・決定性=同一入力で
ビット一致)を課す。加えて効果が理論的に既知の代表 op には強い GT + beat-the-null:
1. erosion は anti-extensive: 出力 <= 入力(全画素)かつ 平均が真に減る(平坦画像との差)。
2. dilation は extensive: 出力 >= 入力(全画素)かつ 平均が真に増える。
3. 順序律(同一 SE): erosion <= opening <= 入力 <= closing <= dilation(全画素)。
4. top-hat は SE より小さい明点を強く拾う: 小明点領域の応答 >> 平坦背景(beat-the-null)。
5. morphological gradient は境界で応答: エッジ帯の応答 >> 平坦内部(beat-the-null)。
6. black-hat は SE より小さい暗点を強く拾う: 小暗点領域の応答 >> 平坦背景(beat-the-null)。

全 op が in_sort='image'/out_sort='image'。SE サイズは knob a→(3,5,7,9) で最小 3 なので
どの knob でも必ず効果が出る(恒等ではない)。真値は SE と単調・順序律から決まる閉形式的性質。
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # repo root first

import numpy as np  # noqa: E402
import ops  # noqa: E402

BY = {o.name: o for o in ops.REGISTRY}
EPS = 1e-9


# --------------------------------------------------------------------------- #
# per-sort 入力ファクトリ（tests/conftest.py の bank 構築を複製。examples は     #
# tests/ から import 禁止のため、必要な sort の生成をここに写経する）。          #
# --------------------------------------------------------------------------- #
def _rng():
    return np.random.default_rng(20260812)


def input_for(sort: str):
    """in_sort に対応する妥当な入力を返す(conftest の canonical variant を複製)。"""
    n = 48
    if sort in ("image", "any"):
        yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
        grad = xx / (n - 1)
        disk = ((yy - n * 0.35) ** 2 + (xx - n * 0.4) ** 2) < (n * 0.18) ** 2
        checker = ((xx.astype(int) // 6 + yy.astype(int) // 6) % 2) * 0.15
        return np.clip(0.35 * grad + 0.45 * disk + checker
                       + 0.03 * _rng().standard_normal((n, n)), 0, 1)
    if sort == "region":
        yy, xx = np.mgrid[0:n, 0:n]
        return (((yy - n // 2) ** 2 + (xx - n // 2) ** 2) < (n * 0.25) ** 2).astype(np.float64)
    if sort == "color":
        g = input_for("image")
        return np.clip(np.stack([g, 0.7 * g + 0.1, 1 - g], -1), 0, 1)
    if sort == "contour":
        sq = np.array([[6.0, 6.0], [6.0, 20.0], [20.0, 20.0], [20.0, 6.0], [6.0, 6.0]])
        return {"shape": (32, 32), "cs": [sq]}
    if sort == "volume":
        zz, vy, vx = np.mgrid[0:8, 0:24, 0:24]
        return np.clip(0.5 + 0.3 * np.sin(vx / 3.0) * np.cos(vy / 4.0) * (zz / 8.0), 0, 1)
    raise ValueError(f"input_for: 未対応の sort {sort!r}")


def _gt_image():
    """GT 用の決定的画像: 平坦 + 縦エッジ + 小さな明点 + 小さな暗点(ノイズ無し)。"""
    g = np.full((48, 48), 0.3)
    g[:, 24:] = 0.7               # 列24に縦エッジ(0.3 -> 0.7)
    g[8:11, 8:11] = 0.95          # 左の平坦域に小さな明点(3x3, SE7 より小)
    g[38:41, 38:41] = 0.05        # 右の平坦域に小さな暗点(3x3)
    return g


# --------------------------------------------------------------------------- #
# TARGET: category=='morphology' の全 op（string literal で明示 = op→example 索引用）。
# --------------------------------------------------------------------------- #
OPS = [
    "gerode", "gdilate", "gopen", "gclose", "runlength_smear",
    "tophat", "bothat", "morph_grad",
    "sk_area_opening", "cv_open", "cv_close", "cv_tophat", "cv_gradient",
    "cv_blackhat", "cv_erode", "cv_dilate", "gray_erosion", "gray_dilation",
    "gray_opening", "gray_closing", "gray_opening_shape", "gray_closing_shape",
    "gray_tophat", "gray_bothat", "gray_erosion_shape", "gray_dilation_shape",
    "gray_opening_rect", "gray_closing_rect", "xsk2_reconstruction",
    "xsk2_diameter_opening", "xsk3_area_closing", "xsk3_diameter_closing",
    "f2_gray_skeleton", "f2_gray_inside", "local_thickness", "persistence_map",
]


def _assert_out_sort(name: str, out, out_sort: str) -> None:
    """宣言された out_sort に出力が一致することを検証(この一族は全て image)。"""
    if out_sort in ("image", "region"):
        a = np.asarray(out, float)
        assert a.ndim == 2, f"{name}: out_sort={out_sort} だが ndim={a.ndim}(2-D 期待)"
        assert np.isfinite(a).all(), f"{name}: 非有限値(NaN/Inf)を含む"
        assert a.min() >= -EPS and a.max() <= 1 + EPS, \
            f"{name}: 値域外 [{a.min():.4g},{a.max():.4g}](image/region は [0,1] 期待)"
    elif out_sort == "contour":
        assert isinstance(out, dict) and "cs" in out, f"{name}: contour は 'cs' 付き dict 期待"
    elif out_sort == "feature":
        a = np.asarray(out, float)
        assert np.isfinite(a).all(), f"{name}: feature が非有限"
    else:
        raise AssertionError(f"{name}: 未知の out_sort {out_sort!r}")


def main() -> int:
    # --- 事前健全性: OPS が TARGET(registry の morphology 全 op)と厳密一致 ---
    target = [o.name for o in ops.REGISTRY if o.category == "morphology"]
    assert set(OPS) == set(target), \
        f"OPS が morphology カテゴリと不一致: 欠={set(target)-set(OPS)} 余={set(OPS)-set(target)}"
    assert len(OPS) == len(set(OPS)) == len(target), "OPS に重複、または TARGET と件数不一致"

    # --- 全 op 普遍契約: 有限 / out_sort 一致 / [0,1] / 決定性(ビット一致) ---
    for name in OPS:
        op = BY[name]
        x = input_for(op.in_sort)
        try:
            o1 = op.fn(input_for(op.in_sort), 0.5, 0.5)
            o2 = op.fn(input_for(op.in_sort), 0.5, 0.5)
        except Exception as e:  # 落ちた op は握りつぶさず大声で失敗
            raise AssertionError(f"op {name!r} が例外を送出: {type(e).__name__}: {e}") from e
        _assert_out_sort(name, o1, op.out_sort)
        a1, a2 = np.asarray(o1, float), np.asarray(o2, float)
        assert a1.shape == a2.shape and np.array_equal(a1, a2), \
            f"{name}: 非決定的(同一入力で出力がビット不一致)"
    print(f"契約OK: {len(OPS)} op すべて 有限 / out_sort 一致 / [0,1] / 決定的。")

    # --- 強い GT + beat-the-null(効果が理論的に既知の代表 op)---
    gt = _gt_image()
    gt_checks = 0

    # 1. erosion は anti-extensive(出力 <= 入力)かつ平均が真に減る
    er = np.asarray(BY["gerode"].fn(gt.copy(), 0.0, 0.0))   # SE 3x3
    assert (er <= gt + EPS).all(), "gerode: anti-extensive 違反(出力 > 入力の画素あり)"
    assert er.mean() < gt.mean() - 1e-4, "gerode: 平均が減っていない(効果なし=null)"
    gt_checks += 1

    # 2. dilation は extensive(出力 >= 入力)かつ平均が真に増える
    di = np.asarray(BY["gdilate"].fn(gt.copy(), 0.0, 0.0))
    assert (di >= gt - EPS).all(), "gdilate: extensive 違反(出力 < 入力の画素あり)"
    assert di.mean() > gt.mean() + 1e-4, "gdilate: 平均が増えていない(効果なし=null)"
    gt_checks += 1

    # 3. 順序律(同一 SE): erosion <= opening <= 入力 <= closing <= dilation
    op_ = np.asarray(BY["gopen"].fn(gt.copy(), 0.0, 0.0))
    cl = np.asarray(BY["gclose"].fn(gt.copy(), 0.0, 0.0))
    assert (er <= op_ + EPS).all() and (op_ <= gt + EPS).all() \
        and (gt <= cl + EPS).all() and (cl <= di + EPS).all(), \
        "morphology 順序律違反: erosion<=opening<=in<=closing<=dilation が破れた"
    gt_checks += 1

    # 3b. 走査長平滑化(RLSA): **行内の字の隙間が埋まって 1 つの塊になる**。
    #     真値が作れるので強い GT になる —— 4 字を 14 画素間隔で並べた行は、
    #     隙間の閾値がその間隔を超えた時点で塊が 4 -> 1 に落ちる。
    #     null を破る 3 つ: (a) 閾値が小さいうちは 4 のまま、(b) 閉じ演算なので
    #     extensive(出力 >= 入力)、(c) AND 合成は片方向より必ず小さいか等しい。
    rl = BY["runlength_smear"].fn
    tx = np.zeros((64, 64))
    for _row in (12, 40):
        for _i in range(4):
            tx[_row:_row + 10, 6 + _i * 14: 6 + _i * 14 + 8] = 1.0

    def _runs(o, row):
        m = np.asarray(o)[row] > 0.5
        return int(np.sum(m[1:] & ~m[:-1]) + (1 if m[0] else 0))

    assert _runs(tx, 16) == 4, "GT runlength_smear: 入力の前提(4 塊)が崩れている"
    assert _runs(rl(tx.copy(), 0.0, 0.0), 16) == 4,         "GT runlength_smear: 隙間 3 画素で字がつながってしまった(閾値が効いていない)"
    assert _runs(rl(tx.copy(), 0.5, 0.0), 16) == 1,         "GT runlength_smear: 隙間 15 画素でも行がつながらない(平滑化が効いていない)"
    _h = np.asarray(rl(tx.copy(), 0.5, 0.0))
    _v = np.asarray(rl(tx.copy(), 0.5, 0.6))
    _and = np.asarray(rl(tx.copy(), 0.5, 0.9))
    assert (_h >= tx - EPS).all() and (_v >= tx - EPS).all(),         "GT runlength_smear: 閉じ演算なのに extensive でない(出力 < 入力)"
    assert (_and <= _h + EPS).all() and (_and <= _v + EPS).all(),         "GT runlength_smear: AND 合成が片方向より大きい(min になっていない)"
    assert np.allclose(rl(np.full((32, 32), 0.4), 0.5, 0.9), 0.4),         "GT runlength_smear: 空フレームを変えている(埋める隙間は無いはず)"
    gt_checks += 1

    # 4. top-hat: SE より小さい明点を強く拾う(小明点領域 >> 平坦背景)
    th = np.asarray(BY["tophat"].fn(gt.copy(), 0.5, 0.0))    # SE 7x7 > 3x3 明点
    th_spot = th[8:11, 8:11].mean()
    th_flat = th[18:30, 30:40].mean()                        # 特徴の無い平坦域
    assert th_spot > th_flat + 0.1, \
        f"tophat: 小明点応答が平坦背景を上回らない(spot={th_spot:.3f} flat={th_flat:.3f})"
    gt_checks += 1

    # 5. morphological gradient: 境界で応答(エッジ帯 >> 平坦内部)
    mg = np.asarray(BY["morph_grad"].fn(gt.copy(), 0.0, 0.0))  # SE 3x3
    mg_edge = mg[15:35, 22:27].mean()                        # 列24 エッジ周辺(明暗点を避けた行)
    mg_interior = mg[18:30, 30:40].mean()                    # 平坦内部
    assert mg_edge > mg_interior + 0.1, \
        f"morph_grad: エッジ応答が平坦内部を上回らない(edge={mg_edge:.3f} interior={mg_interior:.3f})"
    gt_checks += 1

    # 6. black-hat: SE より小さい暗点を強く拾う(小暗点領域 >> 平坦背景)
    bh = np.asarray(BY["bothat"].fn(gt.copy(), 0.5, 0.0))
    bh_spot = bh[38:41, 38:41].mean()
    bh_flat = bh[18:28, 30:37].mean()
    assert bh_spot > bh_flat + 0.1, \
        f"bothat: 小暗点応答が平坦背景を上回らない(spot={bh_spot:.3f} flat={bh_flat:.3f})"
    gt_checks += 1

    # 7. local_thickness: **既知の直径**をそのまま返すこと(近似でなく厳密に合う)。
    #    円の中心では「内接円の直径」がそのまま太さなので、真値が分かる。
    #    null を破る 2 つ: (a) 背景は 0、(b) 上限を下げると太い円は頭打ちになる
    #    —— 頭打ちが起きなければ、上限が効いていないということ。
    lt_img = np.zeros((128, 128))
    ly, lx = np.mgrid[0:128, 0:128]
    for cy, cx, r in ((30, 30, 4), (30, 90, 8), (90, 30, 11)):
        lt_img[(ly - cy) ** 2 + (lx - cx) ** 2 <= r * r] = 1.0
    r_max = 12
    lt = np.asarray(BY["local_thickness"].fn(lt_img.copy(), 1.0, 0.5)) * (2 * r_max)
    for cy, cx, r in ((30, 30, 4), (30, 90, 8), (90, 30, 11)):
        assert abs(lt[cy, cx] - 2 * r) < 1e-9,             f"local_thickness: 直径が合わない(真={2 * r} 推定={lt[cy, cx]:.4g})"
    assert lt[0, 0] == 0.0, "local_thickness: 背景が 0 でない"
    # ★背景の 1 点だけでは足りない —— **前景の外に 1 画素も漏れていない**ことを
    #   全数で見る。離散の円板で膨らませると境界の外まで塗ってしまい、最初の実装は
    #   前景 197 画素の円に対して外へ 48 画素(24%)漏らしていた。中心の値は正しい
    #   ままなので、中心だけ見る検査では捕まらない。
    leaked = int(((lt > 0.0) & (lt_img == 0.0)).sum())
    assert leaked == 0, f"local_thickness: 前景の外に {leaked} 画素漏れている"
    # (b) 上限 a を下げる -> 直径 22 の円は頭打ちになり、出力の最大が 1.0 に貼りつく
    lt_small = np.asarray(BY["local_thickness"].fn(lt_img.copy(), 0.3, 0.5))
    assert lt_small.max() >= 0.999,         "local_thickness: 上限を下げても飽和しない(上限が効いていない)"
    gt_checks += 1

    # 8. persistence_map: 山の**目立ち具合**が高さの差と一致すること。
    #    ★閾値を選ばない op なので、検証も「閾値を選ばずに 3 つの山を同時に当てる」
    #      形にする。高さ 1.0 / 0.6 / 0.3 の山を置いて、そのまま返るかを見る。
    py_, px_ = np.mgrid[0:96, 0:96]
    peaks = ((24, 24, 1.0), (24, 72, 0.6), (72, 24, 0.3))
    hills = np.zeros((96, 96))
    for cy, cx, amp in peaks:
        hills = np.maximum(hills, amp * np.exp(-((py_ - cy) ** 2 + (px_ - cx) ** 2) / 60.0))
    pm = np.asarray(BY["persistence_map"].fn(hills.copy(), 0.0, 1.0))
    for cy, cx, amp in peaks:
        # 許容 1e-3 —— 山どうしが併合する鞍点は厳密に 0 ではない(ガウスの裾が
        # 残るので ~1e-8)。persistence = 誕生 - 消滅 なのでその分だけ低く出る。
        # 厳密一致を要求すると「正しい実装が落ちる」ことを実測して緩めた(0.5999)。
        assert abs(pm[cy, cx] - amp) < 1e-3,             f"persistence_map: 山の目立ち具合が高さと合わない(真={amp} 推定={pm[cy, cx]:.4g})"
    # null を破る: 下限 a を上げると**低い山だけ**が消える(閾値を後から選べる)
    pm_hi = np.asarray(BY["persistence_map"].fn(hills.copy(), 0.45, 1.0))
    assert pm_hi[72, 24] == 0.0, "下限 0.45 で高さ 0.3 の山が消えていない"
    assert pm_hi[24, 24] > 0.9 and pm_hi[24, 72] > 0.5, "下限 0.45 で高い山まで消えた"
    gt_checks += 1

    print(f"PASS: {len(OPS)} ops exercised, all finite/typed/deterministic; {gt_checks} GT checks")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
