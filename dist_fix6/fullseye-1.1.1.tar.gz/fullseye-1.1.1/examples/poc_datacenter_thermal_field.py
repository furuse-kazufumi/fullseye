# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""データセンターの温度場を疎なセンサから復元する —— 格子の死角が、ラック 1 本を消す。

サーバ室の熱管理は、ラック前面・背面に散らした温度センサを **3-D の温度場に補間して**
見ます(ASHRAE の熱環境ガイドラインが定める吸気温度の判定も、PUE を上げないための
冷気配分も、この場の上の量です)。ところが**センサの置き方**で、過負荷のラック 1 本が
場から消えます。この PoC は温度場を式で仕込んで、「消える量」を幾何から**先に予測して
から**測ります。

EXTEND: 実センサに差し替えるなら :func:`read` を BMS/DCIM の読み値に、
:func:`lattice` をフロアプランから起こしたセンサ座標に置き換えます。
**真値 (:func:`field`) は実データでは手に入りません** —— 実室では場の全点を知る手段が
無く(CFD も熱画像も、それ自体が別の誤差を持つ代替物です)、この PoC の「回復率」
「ピーク誤差」「位置誤差」は原理的に測れなくなります。さらに厄介なのは、崖の式
``exp(-3d²/8σ²)`` を評価するには**プルームの幅 σ が要る**のに、**その σ こそ疎な格子が
壊すもの**だという点です。現場でできるのは「σ をこれ以上細いとは仮定しない」という
上からの押さえだけで、必要間隔は σ から逆算する(``d ≤ 1.36 σ`` で半分)しかありません。

この PoC が示すこと(数字はいずれも実行時に印字される実測値):

1. **ゼロ点(全センサの平均を場全体に置く = 場は平らとみなす)は RMSE 2.192 °C で、
   過負荷ラックを 1 台も見つけない(見失い 3 台)**。いちばん良い RBF は 0.214 °C で
   **10.2 倍**良く、3 台とも見つける。以降の話はすべてこのゼロ点の上での話。
2. ★**崖は測る前に言える**。間隔 d の 3-D 格子では、ピークからいちばん遠い点は
   セルの中心 = ``d√3/2``。σ の等方ガウスなら見えるピークは
   ``exp(-(d√3/2)²/2σ²) = exp(-3d²/8σ²)`` 倍で、**半分に落ちる間隔は
   ``d* = σ√(8ln2/3) = 1.3596 σ``**(σ=0.55 / 0.35 / 0.22 m のラックで
   0.748 / 0.476 / 0.299 m)。この閉形式を先に印字してから測った ——
   **幾何だけを取り出した実測との差は 1.2e-15**。ここは検算であって発見ではない。
3. ★★**外れたのは閉形式ではなく「測り方」**。現場で測れるのは「復元した場のピーク」
   であって「そのラックの寄与」ではないので、**背景の復元誤差が同じ場所に載る**。
   素朴なピーク測定は予測を最大 **+0.2598** 超過し、その超過は「ラックを消した場」で
   測った床 0.2664 とほぼ同じ。σ=0.22 m のラックは d=1.20 m で幾何の回復
   **0.000014**(消滅)なのに素朴に測ると **0.1609** 残って見える ——
   **残っているのは背景の誤差**で、崖は実際より浅く見える。
4. ★**閉形式は曲線ではなく床**。ラックが格子のどこに落ちるかは設計で決められない。
   d=0.60 m で σ=0.35 m のラックの回復は、最悪位相(セル中心)0.3322 /
   現場の位相 0.8938 / 最良位相(センサ直上)1.0000 と 3 倍に跳ぶ。
   設計に使えるのは最悪位相の値だけで、「平均すればこれくらい見える」は
   **そのラックには通じない**。
5. **対照群 a: 乱数配置は死角を消さない**。同じ 1400 本を一様乱数で置くと、最近傍距離の
   中央値は 0.3222 m(Poisson の予測 0.3294 m)で、**格子の最悪距離 0.5196 m を
   6.17 % が超える**(予測 exp(-4πλr³/3) = 6.58 %、差 0.41 ポイント)。違うのは
   平均ではなく**言い切れるかどうか**: 12 通りの位相を振っても格子は幾何の下限を
   1 度も割らず(σ=0.22 m のラックで最悪 0.19977 ≥ 下限 0.06147)、乱数は 2 台で
   割った(0.03497)。★偶然だが、σ=0.55 m のラックでいちばん悪かった乱数の
   最近傍距離 0.51963 m は、格子の保証最悪 0.51962 m とほぼ同値だった。
6. **対照群 b: 崖の急さは補間法で動かない。動くのは持ち上がりのほう**。
   ``log(回復)`` を ``d²`` に当てた傾きは 最近傍 -3.0612 / 線形 -3.0612 /
   RBF -2.9679 /m² で、予測 ``-3/(8σ²) = -3.0612`` との差は最大 3.05 %。
   ★**ただし「崖の位置は手法で動かない」という予測は外した**: 半減間隔は
   最近傍 0.4777 / 線形 0.4777 / **RBF 0.6015 m** で 26 % ずれる。原因は係数
   **1.372 倍** —— 薄板スプラインは**内挿でありながら節点の値を超える**ので、山を
   一律に高く戻す。最近傍と線形が小数点以下まで一致するのは偶然ではなく、
   どちらも節点を超えないから(最悪位相の最大値はどちらも「いちばん近いセンサの読み」)。
7. ★★**「上向きに外れる手法は偽の峰も同じだけ立てる」——これも外した**。
   d=0.60 m での床(何も無いところに立つ旗)は 最近傍 0.975 °C / 線形 0.132 °C /
   RBF 0.164 °C で、**持ち上がる側のほうが低い**。信号 / 偽物の比は 3.07 → 22.63 →
   27.49。最近傍の床は雑音 0.15 °C の **6.5 倍**で、これは雑音ではなく
   **滑らかな背景勾配を階段で近似した段差**。この場面では上向きの外れに代償が無かった。
8. **物差しを 3 つ置くと、全部を同時に勝つ手法は無い**。RMSE は RBF(0.176 / 0.328 /
   0.742 °C)、ピーク誤差も RBF、**位置誤差は最近傍**(d=0.80 m で 0.150 m 対
   線形 0.660 m / RBF 0.187 m)。★RBF がピーク誤差で勝つのは原理的に正しいからでは
   なく、§6 の **1.37 倍の持ち上がり**がサンプリングの減衰を逆向きに打ち消しただけ
   (d=0.80 m で 最近傍 -5.43 °C → RBF -5.11 °C。どちらも真値に届いていない)。
9. **線形補間は端で必ず別の手法に化ける**。センサは部屋の内側にしか置けないので、
   評価点の 21.2 %(d=0.50 m)/ 39.7 %(0.80)/ 71.2 %(1.20)が Delaunay の凸包の
   外に出て最近傍にフォールバックする。「線形の結果」と呼んでいるものの 7 割が
   最近傍、ということが起こる。
10. **「偽の峰 0」は数え忘れではない**。しきい値を 32.0 → 28.0 °C に下げると同じ体積
    から偽の峰が 1 個出る(ホットアイルの帯そのものが峰になる)—— 門を壊して確かめた。

【グラウンドトゥルース】温度場を ``T(x,y,z) = 室温 24 °C + ホットアイルの帯
(y=4.2 m、幅 σ=0.9 m、+5 °C、上ほど熱い) - コールドアイルの床吹き出し
(y=1.4/7.0 m、幅 σ=0.7 m、-5.5 °C、``exp(-z/0.9)``) + Σ 過負荷ラックの等方ガウス``
で置いた(:func:`field`)。ラックは σ=0.55 m/+7 °C、σ=0.35 m/+9 °C、σ=0.22 m/+11 °C
の 3 台で、真のピークは 35.46 / 37.15 / 39.36 °C。プルームを**等方**にしたのは崖の
閉形式がちょうど成り立つようにするためで、実際のプルームは上へ伸びた異方形
(その場合 ``exp(-(d²/8)(1/σx²+1/σy²+1/σz²))`` に置き換わる)。センサは
真値 + ガウス雑音 σ=0.15 °C。回復率は**補間がセンサ値に線形**であることを使い、
「全部の場の復元」と「そのラックだけ消した場の復元」の差の最大として取り出した ——
こうすると背景の寄与が厳密に消え、閉形式が予言する量そのものになる。

来歴(公開文献のみ): ASHRAE TC 9.9 *Thermal Guidelines for Data Processing
Environments* —— 吸気温度の recommended 18-27 °C / class A1 allowable 15-32 °C
(この PoC の検出しきい値 32 °C はこの上限を取った)/ ISO/IEC 30134-2
*Information technology — Data centres — Key performance indicators — Part 2:
Power usage effectiveness (PUE)*。
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
from scipy.spatial import cKDTree

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import examplefig as figs                                        # noqa: E402
import fullseye as fs                                            # noqa: E402

_L = fs.ledger

# --- 部屋(長さ m、温度 °C)-------------------------------------------------- #
LX, LY, LZ = 12.0, 8.4, 3.0     # x = アイル方向 / y = アイルを横切る / z = 高さ
T_AMB = 24.0                    # 室の基準温度

# ホットアイル(2 列のラック排気が集まる帯)。上ほど熱い。
HOT_Y, HOT_S, HOT_A = 4.2, 0.9, 5.0
# コールドアイル(床のパンチングタイルからの吹き出し)。床際だけ冷たい。
COLD_Y, COLD_S, COLD_A, COLD_H = (1.4, 7.0), 0.7, 5.5, 0.9

#: 過負荷ラック(名前, x, y, z [m], σ [m], 振幅 [°C])。**これが探すもの**。
HOTSPOTS = [
    ("R-A07 広いプルーム", 2.60, 4.20, 2.35, 0.55, 7.0),
    ("R-B14 中位",         6.35, 4.05, 2.05, 0.35, 9.0),
    ("R-C21 排気閉塞",     9.85, 4.35, 2.30, 0.22, 11.0),
]

NOISE = 0.15        # センサ雑音 σ [°C](DC 用温湿度センサの実力 ±0.5 °C 相当)
SEED = 11
DETECT = 32.0       # 「熱い」と呼ぶしきい値 [°C](ASHRAE class A1 allowable の上限)

EV = 0.25           # 評価格子の刻み [m]
GX = np.arange(0.0, LX + 1e-9, EV)
GY = np.arange(0.0, LY + 1e-9, EV)
GZ = np.arange(0.0, LZ + 1e-9, EV)
#: 評価点 (nz*ny*nx, 3)。体積 op に渡すため **(z, y, x) 順の volume** にも組み直す。
GRID = np.stack(np.meshgrid(GX, GY, GZ, indexing="ij"), -1).reshape(-1, 3)
VOL_SHAPE = (GZ.size, GY.size, GX.size)

METHODS = ("null", "nearest", "linear", "rbf")
MET_LABEL = {"null": "ゼロ点(全センサの平均)", "nearest": "最近傍",
             "linear": "線形(Delaunay)", "rbf": "RBF(薄板スプライン)"}


# --------------------------------------------------------------------------- #
# 真値 —— 温度場 T(x, y, z) を式で置く                                          #
# --------------------------------------------------------------------------- #
def field(p, drop=None):
    """温度 [°C]。``drop`` はその番号のホットスポットだけ止める(対照群用)。

    ``T = 室温 + ホットアイルの帯 - コールドアイルの吹き出し + Σ ラックのプルーム``。
    帯は上ほど熱く(排気が天井へ上がる)、吹き出しは床際だけ効く(``exp(-z/h)``)。
    ラックのプルームは等方ガウス —— ここだけ**等方**にしてあるのは、崖の閉形式
    ``exp(-3d²/8σ²)`` が等方のときちょうど成り立つからで、実際のプルームは
    上へ伸びた異方形。異方なら ``exp(-(d²/8)(1/σx²+1/σy²+1/σz²))`` に置き換わる。
    """
    p = np.asarray(p, float)
    x, y, z = p[..., 0], p[..., 1], p[..., 2]
    t = T_AMB + HOT_A * np.exp(-(y - HOT_Y) ** 2 / (2 * HOT_S ** 2)) * (0.5 + 0.5 * z / LZ)
    for cy in COLD_Y:
        t = t - COLD_A * np.exp(-(y - cy) ** 2 / (2 * COLD_S ** 2)) * np.exp(-z / COLD_H)
    for i, (_, cx, cy2, cz, s, a) in enumerate(HOTSPOTS):
        if drop is not None and i == drop:
            continue
        r2 = (x - cx) ** 2 + (y - cy2) ** 2 + (z - cz) ** 2
        t = t + a * np.exp(-r2 / (2.0 * s * s))
    return t


def true_peak(hi: int) -> float:
    """ホットスポット ``hi`` の中心の真の温度 [°C]。"""
    _, cx, cy, cz, _, _ = HOTSPOTS[hi]
    return float(field(np.array([[cx, cy, cz]]))[0])


def centre(hi: int) -> np.ndarray:
    return np.array(HOTSPOTS[hi][1:4], float)


# --------------------------------------------------------------------------- #
# センサの置き方                                                                #
# --------------------------------------------------------------------------- #
def lattice(d: float, origin=None):
    """間隔 ``d`` の 3-D 格子。``origin`` は各軸の位相 [m](既定 = セル中心)。"""
    o = (0.5 * d,) * 3 if origin is None else tuple(float(v) for v in origin)
    ax = [np.arange(oo, L - 1e-12, d) for oo, L in zip(o, (LX, LY, LZ))]
    if min(a.size for a in ax) == 0:
        raise ValueError("格子が空: d=%.3f origin=%s" % (d, o))
    pts = np.stack(np.meshgrid(*ax, indexing="ij"), -1).reshape(-1, 3)
    return pts, [int(a.size) for a in ax]


def cloud(n: int, seed: int):
    """同じ本数を一様乱数で置く(系統的な死角を持たない対照群)。"""
    rng = np.random.default_rng(seed)
    return rng.uniform(0.0, 1.0, (n, 3)) * np.array([LX, LY, LZ])


def read(pts, drop=None, noise=0.0, seed=SEED):
    """センサが読む値 [°C]。``noise`` は同じ配置なら同じ実現になる。"""
    v = field(pts, drop)
    if noise > 0.0:
        v = v + np.random.default_rng(seed).normal(0.0, noise, v.shape)
    return v


# --------------------------------------------------------------------------- #
# 復元 —— 3 種の補間 + ゼロ点                                                   #
# --------------------------------------------------------------------------- #
def fit(pts, vals, method: str):
    """散らばったセンサ値から場を返す callable を作る。

    ``linear`` は Delaunay の凸包の外で NaN になるので**最近傍で埋める**
    (壁・床・天井際は必ず外に出る。埋めた割合は :func:`hull_miss` で数える)。
    """
    pts = np.asarray(pts, float)
    vals = np.asarray(vals, float)
    if method == "null":
        m = float(vals.mean())
        return lambda q: np.full(np.asarray(q, float).shape[0], m)
    if method == "nearest":
        tree = cKDTree(pts)
        return lambda q: vals[tree.query(np.asarray(q, float))[1]]
    if method == "linear":
        tree = cKDTree(pts)

        def f(q):
            # ★2026-09-08: この PoC が「散らばった点から場を作る口が無い」と
            #   記録したので `fs.interp_scattered` を足した。凸包の外に出た点は
            #   op が **マスクで返す** ので、isfinite で当てずに済む
            #   (fill_value を有限値にしても壊れない)。
            q = np.asarray(q, float)
            r = fs.interp_scattered(pts, vals, q, method="linear")
            a = np.asarray(r["value"], float)
            out = np.asarray(r["outside"], bool)
            if out.any():
                a[out] = vals[tree.query(q[out])[1]]
            return a
        return f
    if method == "rbf":
        return lambda q: np.asarray(
            fs.interp_scattered(pts, vals, np.asarray(q, float), method="rbf",
                                neighbors=min(48, len(pts)))["value"], float)
    raise ValueError(method)


def hull_miss(pts, q) -> float:
    """線形補間が凸包の外に出て最近傍に落ちた割合。

    ★これは `fs.interp_scattered` の返り値 ``outside_fraction`` そのもの ——
    「答えのうちどれだけが補間ではなかったか」を op に持たせたのは、この
    PoC が 71.2 % という数字を測ったからで、黙って NaN や別手法に化ける量が
    それだけ大きいなら**返り値に居るべき**だった。
    """
    return float(fs.interp_scattered(np.asarray(pts, float), np.zeros(len(pts)),
                                     np.asarray(q, float),
                                     method="linear")["outside_fraction"])


# --------------------------------------------------------------------------- #
# 崖の閉形式 —— 測る前に幾何から出す                                            #
# --------------------------------------------------------------------------- #
def visible(d: float, sigma: float) -> float:
    """間隔 ``d`` の格子で見えるピークの割合(等方ガウス σ)。

    ピークからいちばん遠い点は 3-D セルの中心 = ``d√3/2`` 離れる。そこでの
    ガウスの値は ``exp(-(d√3/2)²/(2σ²)) = exp(-3d²/(8σ²))``。
    """
    return float(np.exp(-(d * np.sqrt(3.0) / 2.0) ** 2 / (2.0 * sigma * sigma)))


def half_spacing(sigma: float) -> float:
    """ピークが半分に落ちる間隔 ``d* = σ√(8 ln2 / 3) = 1.3596 σ``。"""
    return float(sigma * np.sqrt(8.0 * np.log(2.0) / 3.0))


def local_grid(c, half, n=21):
    ax = [np.linspace(cc - half, cc + half, n) for cc in np.asarray(c, float)]
    return np.stack(np.meshgrid(*ax, indexing="ij"), -1).reshape(-1, 3)


def recover(hi: int, d: float, phase="worst", method="nearest", noise=0.0,
            seed=SEED) -> dict:
    """ホットスポット ``hi`` の近傍だけで復元し、回復したピーク超過 [°C] を返す。

    ``phase`` = ``"worst"`` はホットスポットをセルの中心に置く(最悪位相 =
    閉形式が当たるはずの場所)、``"node"`` はセンサの真上(最良)、``"room"``
    は部屋の格子をそのまま使う(現場の位相 = 制御できない)。

    3 つの量を別々に返す(1 つに畳むと何が効いているか言えなくなる):

    ``geo``
        **幾何だけ**の回復 ``max(T̂[全部] - T̂[そのラックだけ消した])``。3 手法とも
        補間はセンサ値に**線形**なので、この差は「そのラックのガウスだけを
        センサで拾って補間したもの」に厳密に等しい。閉形式が予言するのはこれ。
    ``naive``
        現場で測れる量 ``max(T̂[全部] - 真の背景)``。背景の復元誤差が同じ場所に
        載るので **``geo`` より必ず大きく出る**。
    ``floor``
        ラックを消したセンサ読みから測った ``max(T̂[背景] - 真の背景)``
        = 背景モデルの誤差 + 雑音。**何も無いところに立つ旗の高さ**。
    """
    c = centre(hi)
    a = HOTSPOTS[hi][5]
    s = HOTSPOTS[hi][4]
    if phase == "worst":
        o = (c - 0.5 * d) % d
    elif phase == "node":
        o = c % d
    else:
        o = np.full(3, 0.5 * d)
    pts, ns = lattice(d, o)
    half = max(1.6 * s, 0.9 * d)
    keep = np.all(np.abs(pts - c) <= half + 2.6 * d, axis=1)
    pts = pts[keep]
    q = local_grid(c, half)
    bg = field(q, drop=hi)
    v_full = fit(pts, read(pts, None, 0.0), method)(q)
    v_bg = fit(pts, read(pts, hi, 0.0), method)(q)
    v_bgn = fit(pts, read(pts, hi, noise, seed), method)(q)
    geo = float(np.max(v_full - v_bg))
    naive = float(np.max(v_full - bg))
    flo = float(np.max(v_bgn - bg))
    return {"geo": geo / a, "naive": naive / a, "floor": flo / a,
            "n_local": int(pts.shape[0]), "nz": ns[2], "origin": o,
            "bracketed": bool(c[2] + 0.5 * d <= LZ + 1e-9)}


def nearest_dist(hi: int, pts) -> float:
    """ホットスポット中心からいちばん近いセンサまでの距離 [m]。"""
    return float(cKDTree(np.asarray(pts, float)).query(centre(hi))[0])


# --------------------------------------------------------------------------- #
# 物差し 3 つ                                                                   #
# --------------------------------------------------------------------------- #
def peak_error(f, hi: int) -> float:
    """復元したピーク温度の誤差 [°C](真値のピークとの差、符号つき)。"""
    c = centre(hi)
    q = local_grid(c, 0.5, n=17)
    return float(np.max(f(q)) - true_peak(hi))


def locate(vol) -> np.ndarray:
    """体積から局所最大を拾って **[m] の座標**にする(``vol_local_maxima``)。"""
    pk = np.asarray(_L.vol_local_maxima(np.asarray(vol, float),
                                        min_distance=3, threshold=DETECT))
    if pk.size == 0:
        return np.zeros((0, 3))
    return np.stack([GX[pk[:, 2]], GY[pk[:, 1]], GZ[pk[:, 0]]], axis=1)


def loc_error(peaks) -> tuple:
    """各ホットスポットに最も近い検出ピークまでの距離 [m]。1.5 m 超は見失い。

    3 つ目を返す ``spur`` は**どのラックからも 1.5 m 以上離れた峰**の数
    = 偽の熱源。見失いと偽物は別の失敗なので、1 つの数字に畳まない。
    """
    peaks = np.asarray(peaks, float).reshape(-1, 3)
    out, miss = [], 0
    for hi in range(len(HOTSPOTS)):
        if len(peaks) == 0:
            miss += 1
            continue
        dd = float(np.min(np.linalg.norm(peaks - centre(hi), axis=1)))
        if dd > 1.5:
            miss += 1
        else:
            out.append(dd)
    spur = 0
    for p in peaks:
        if min(float(np.linalg.norm(p - centre(hi)))
               for hi in range(len(HOTSPOTS))) > 1.5:
            spur += 1
    return (float(np.mean(out)) if out else float("nan")), miss, spur


# --------------------------------------------------------------------------- #
# 1. 場面と真値                                                                 #
# --------------------------------------------------------------------------- #
def section_scene() -> dict:
    print("\n" + "=" * 78)
    print("1) 場面と真値 —— %.0f x %.1f x %.1f m のサーバ室、式で置いた温度場"
          % (LX, LY, LZ))
    print("=" * 78)
    t = field(GRID)
    print("   室温 %.1f °C / ホットアイル y=%.1f m(帯の幅 σ=%.1f m、+%.1f °C、"
          "上ほど熱い)" % (T_AMB, HOT_Y, HOT_S, HOT_A))
    print("   コールドアイル y=%.1f, %.1f m(床吹き出し -%.1f °C、高さ %.1f m で減衰)"
          % (COLD_Y[0], COLD_Y[1], COLD_A, COLD_H))
    print("   場の範囲 %.2f .. %.2f °C(評価格子 %d x %d x %d、刻み %.2f m)"
          % (t.min(), t.max(), GX.size, GY.size, GZ.size, EV))
    print("\n   過負荷ラック(探すもの)  σ [m]  振幅 [°C]  中心 (x, y, z) [m]  "
          "真のピーク [°C]  半減間隔 d*=1.36σ")
    for hi, (nm, cx, cy, cz, s, a) in enumerate(HOTSPOTS):
        print("     %-18s %5.2f %8.1f    (%.2f, %.2f, %.2f)      %6.2f  "
              "%12.3f m" % (nm, s, a, cx, cy, cz, true_peak(hi), half_spacing(s)))

    vol = t.reshape(GX.size, GY.size, GZ.size).transpose(2, 1, 0)
    assert vol.shape == VOL_SHAPE, vol.shape
    pk = locate(vol)
    d_loc, miss, spur = loc_error(pk)
    print("\n   真値の体積に vol_local_maxima(しきい値 %.1f °C)をかけると "
          "%d 個の峰、位置誤差 %.3f m、見失い %d 個"
          % (DETECT, len(pk), d_loc, miss))
    print("   —— 評価格子の刻みが %.2f m なので、これが**測れる位置精度の下限**。"
          % EV)

    iz = int(round(2.30 / EV))
    iy = int(round(HOT_Y / EV))
    lo, hi_ = 17.0, 40.0
    pan = [np.asarray(fs.apply_cmap(vol[iz], "turbo", vmin=lo, vmax=hi_)),
           np.asarray(fs.apply_cmap(vol[:, iy, :][::-1], "turbo", vmin=lo, vmax=hi_)),
           np.asarray(fs.apply_cmap(
               np.asarray(_L.render_volume_projection(vol, azimuth=0.0, mode="mip")),
               "turbo", vmin=lo, vmax=hi_))]
    figs.save_grid(
        "scene_truth", pan,
        ["水平断面 z=2.30 m", "垂直断面 y=%.1f m(上が天井)" % HOT_Y,
         "最大値投影(真上から)"],
        ncols=3,
        title="真の温度場 [%.0f-%.0f °C、turbo](過負荷ラック 3 台をアイルに仕込んだ)"
              % (lo, hi_),
        caption="横=x 0..%.0f m、縦=y 0..%.1f m(左端)/ z 0..%.1f m(中央)。"
                "中央のパネルは室高 %.1f m ぶんしか無いので上下の白は余白。"
                % (LX, LY, LZ, LZ))
    return {"tmin": float(t.min()), "tmax": float(t.max()), "n_peak": len(pk),
            "loc": d_loc, "miss": miss}


# --------------------------------------------------------------------------- #
# 2. ゼロ点                                                                     #
# --------------------------------------------------------------------------- #
def section_zero_point(d=0.6) -> dict:
    print("\n" + "=" * 78)
    print("2) ゼロ点 —— 「全センサの平均を場全体に置く(場は平らとみなす)」")
    print("=" * 78)
    pts, ns = lattice(d)
    vals = read(pts, noise=NOISE)
    truth = field(GRID)
    print("   センサ格子 間隔 %.2f m = %d x %d x %d = %d 本(雑音 σ=%.2f °C)"
          % (d, ns[0], ns[1], ns[2], len(pts), NOISE))
    out = {}
    print("\n   手法                       場の RMSE   ピーク温度の誤差(3 台の平均)"
          "  位置誤差   見失い")
    for m in METHODS:
        f = fit(pts, vals, m)
        rec = f(GRID)
        rmse = float(np.sqrt(np.mean((rec - truth) ** 2)))
        pe = [peak_error(f, hi) for hi in range(len(HOTSPOTS))]
        vol = rec.reshape(GX.size, GY.size, GZ.size).transpose(2, 1, 0)
        dl, ms, sp = loc_error(locate(vol))
        out[m] = {"rmse": rmse, "peak": pe, "loc": dl, "miss": ms, "spur": sp}
        print("   %-26s %7.3f °C %12.2f °C %14s %8d"
              % (MET_LABEL[m], rmse, float(np.mean(pe)),
                 ("%.3f m" % dl) if np.isfinite(dl) else "—", ms))
    print("\n  ★ゼロ点の RMSE は %.3f °C。最良の手法は %.3f °C で、**%.1f 倍**良い。"
          % (out["null"]["rmse"],
             min(out[m]["rmse"] for m in METHODS if m != "null"),
             out["null"]["rmse"] / min(out[m]["rmse"] for m in METHODS if m != "null")))
    print("     ゼロ点はホットスポットを 1 台も見つけない(見失い %d 個)—— "
          "以降の手法はこれを\n     上回らなければ意味がない。"
          % out["null"]["miss"])
    return {"d": d, "n": len(pts), "res": out}


# --------------------------------------------------------------------------- #
# 3. 崖 —— 幾何から予測してから測る                                             #
# --------------------------------------------------------------------------- #
DS = [0.30, 0.45, 0.60, 0.80, 1.00, 1.20]


def section_cliff() -> dict:
    print("\n" + "=" * 78)
    print("3) ★崖 —— **測る前に**幾何から予測する")
    print("=" * 78)
    print("   間隔 d の 3-D 格子でサンプルすると、ピークからいちばん遠い点は")
    print("   セルの中心 = d√3/2 = %.4f d。σ のガウスなら見えるピークは"
          % (np.sqrt(3) / 2))
    print("       visible(d, σ) = exp(-(d√3/2)² / 2σ²) = exp(-3d²/8σ²)")
    print("   倍に落ちる。半分になるのは d* = σ√(8ln2/3) = %.4f σ。\n"
          % np.sqrt(8 * np.log(2) / 3))
    print("   ---- 予測(ここまで実測は 1 つも使っていない)----")
    print("   間隔 d [m] " + "".join("   σ=%.2f m" % h[4] for h in HOTSPOTS))
    pred = {}
    for d in DS:
        row = [visible(d, h[4]) for h in HOTSPOTS]
        pred[d] = row
        print("     %5.2f    " % d + "".join("  %8.4f" % v for v in row))
    print("   半減間隔 d*  " + "".join("  %6.3f m " % half_spacing(h[4])
                                       for h in HOTSPOTS))

    print("\n   ---- 実測(最悪位相 = ホットスポットをセルの中心に置く、最近傍補間)----")
    print("   間隔 d   ラック     予測   幾何の実測    差    素朴な実測  超過   "
          "床(背景+雑音)")
    geo, naive, floors, diffs, excess = {}, {}, {}, [], []
    for d in DS:
        for hi, h in enumerate(HOTSPOTS):
            r = recover(hi, d, "worst", "nearest", NOISE)
            assert r["bracketed"], (d, hi)
            geo[(d, hi)] = r["geo"]
            naive[(d, hi)] = r["naive"]
            floors[(d, hi)] = r["floor"]
            diffs.append(abs(r["geo"] - pred[d][hi]))
            excess.append(r["naive"] - pred[d][hi])
            print("    %5.2f   σ=%.2f  %8.4f %9.4f %+9.6f %9.4f %+7.4f %10.4f"
                  % (d, h[4], pred[d][hi], r["geo"], r["geo"] - pred[d][hi],
                     r["naive"], r["naive"] - pred[d][hi], r["floor"]))
    err = max(diffs)
    print("\n  ★閉形式と「幾何だけの実測」の差は最大 %.2e —— **一致する**。"
          "最近傍補間は最悪位相で\n     セルの角の値を返し、その角はちょうど"
          " d√3/2 の点だから。ここは幾何の検算であって発見ではない。" % err)
    print("  ★★**外れるのは閉形式ではなく「測り方」**。現場で測れるのは"
          "「復元した場のピーク」\n     であって「そのラックの寄与」ではないので、"
          "**背景の復元誤差が同じ場所に載る**。\n     素朴な実測は予測を最大 "
          "%+.4f 超過し(d=%.2f m、σ=%.2f m)、その超過は床 %.4f と\n     ほぼ同じ"
          " —— つまり**崖は実際より浅く見える**。"
          % (max(excess), DS[-1], HOTSPOTS[0][4], floors[(DS[-1], 0)]))
    print("     σ=%.2f m のラックは d=%.2f m で幾何の回復 %.6f(ほぼ消滅)なのに、"
          "素朴に測ると\n     %.4f 残って見える。**残っているのは背景の誤差**。"
          % (HOTSPOTS[2][4], DS[-1], geo[(DS[-1], 2)], naive[(DS[-1], 2)]))

    print("\n   ---- 位相を変えると何が起きるか(d = %.2f m、幾何の回復)----" % 0.60)
    d0 = 0.60
    print("   ラック    最悪位相(セル中心)  現場の位相(部屋の格子)  最良位相"
          "(センサ直上)")
    phase_rows = []
    for hi, h in enumerate(HOTSPOTS):
        a = recover(hi, d0, "worst", "nearest", 0.0)["geo"]
        b = recover(hi, d0, "room", "nearest", 0.0)["geo"]
        c = recover(hi, d0, "node", "nearest", 0.0)["geo"]
        phase_rows.append((h[0], a, b, c))
        print("   σ=%.2f  %14.4f %20.4f %18.4f" % (h[4], a, b, c))
    print("  ★★**閉形式は曲線ではなく床**。ラックが格子のどこに落ちるかは"
          "設計で決まらないので、\n     同じ d でも回復は最悪位相の値から 1.0 "
          "(センサ直上)まで跳ぶ。設計に使えるのは\n     最悪位相の値だけ —— "
          "「うちは平均すればこれくらい見える」は、そのラックには通じない。")

    figs.save_plot(
        "cliff_prediction",
        [("予測 σ=%.2f m" % HOTSPOTS[0][4], DS, [pred[d][0] for d in DS]),
         ("幾何の実測 σ=%.2f m" % HOTSPOTS[0][4], DS, [geo[(d, 0)] for d in DS]),
         ("素朴な実測 σ=%.2f m" % HOTSPOTS[0][4], DS, [naive[(d, 0)] for d in DS]),
         ("予測 σ=%.2f m" % HOTSPOTS[2][4], DS, [pred[d][2] for d in DS]),
         ("素朴な実測 σ=%.2f m" % HOTSPOTS[2][4], DS, [naive[(d, 2)] for d in DS])],
        xlabel="センサ格子の間隔 d [m]", ylabel="回復したピークの割合",
        title="崖 —— 閉形式は当たる。外れるのは「ピークがどれだけ残ったか」の測り方",
        caption="幾何の実測は予測と最大 %.1e しか違わない。素朴な実測が上に"
                "浮くぶんが背景の復元誤差。" % err)
    figs.save_table(
        "cliff_table",
        ["間隔 d [m]"] + ["σ=%.2f 予測" % h[4] for h in HOTSPOTS]
        + ["σ=%.2f 素朴な実測" % h[4] for h in HOTSPOTS],
        [["%.2f" % d] + ["%.4f" % pred[d][i] for i in range(3)]
         + ["%.4f" % naive[(d, i)] for i in range(3)] for d in DS],
        title="幾何の予測と、現場で測れる量(最悪位相)", col_w=130)
    return {"pred": pred, "geo": geo, "naive": naive, "floors": floors,
            "err": err, "excess": max(excess), "phase": phase_rows}


# --------------------------------------------------------------------------- #
# 4. 対照群 a —— 格子 vs 乱数(同じ本数)                                        #
# --------------------------------------------------------------------------- #
def section_grid_vs_random(d=0.60, ntrial=12) -> dict:
    print("\n" + "=" * 78)
    print("4) 対照群 a —— 格子 vs 乱数(同じセンサ本数、d = %.2f m)" % d)
    print("=" * 78)
    pts0, ns = lattice(d)
    n = len(pts0)
    lam = n / (LX * LY * LZ)
    r_grid = d * np.sqrt(3) / 2.0
    p_worse = float(np.exp(-(4 * np.pi / 3) * lam * r_grid ** 3))
    r_med = float((3 * np.log(2) / (4 * np.pi * lam)) ** (1 / 3.0))
    print("   センサ %d 本(密度 λ = %.4f 本/m³)。**予測を先に置く**:" % (n, lam))
    print("     * 格子の最悪距離は d√3/2 = %.4f m(設計で決まる、必ず起きる)"
          % r_grid)
    print("     * 一様乱数(Poisson)の最近傍距離は P(R>r) = exp(-4πλr³/3)。")
    print("       中央値 %.4f m、格子の最悪距離を**超える確率は %.3f**"
          " = %.1f %%。" % (r_med, p_worse, 100 * p_worse))
    print("       つまり乱数は死角を**消さない。どのラックが死角に落ちるかを"
          "振るだけ**。")

    # --- 距離の分布は安く大量に取れる(復元は要らない)--- #
    rng = np.random.default_rng(SEED)
    nq = 20000
    marg = 0.8
    qq = (rng.uniform(0.0, 1.0, (nq, 3)) * np.array([LX - 2 * marg, LY - 2 * marg,
                                                     LZ - 2 * marg]) + marg)
    dg = cKDTree(pts0).query(qq)[0]
    dr = np.concatenate([cKDTree(cloud(n, 3000 + k)).query(qq[k::4])[0]
                         for k in range(4)])
    frac = float(np.mean(dr > r_grid))
    print("\n   ---- 実測(壁から %.1f m 内側の一様な %d 点で距離を数えた)----"
          % (marg, nq))
    print("   格子   最近傍距離 中央値 %.4f m / 最大 %.4f m(幾何の上限 %.4f m)"
          % (np.median(dg), dg.max(), r_grid))
    print("   乱数   最近傍距離 中央値 %.4f m(予測 %.4f m) / 最大 %.4f m"
          % (np.median(dr), r_med, dr.max()))
    print("   ★乱数配置の **%.2f %%** が格子の最悪距離 %.4f m を超えた"
          "(予測 %.2f %%、差 %.2f ポイント)。"
          % (100 * frac, r_grid, 100 * p_worse, 100 * abs(frac - p_worse)))

    print("\n   ---- 回復の実測(位相/種を %d 通り × ラック 3 台 = %d 例、幾何の回復)"
          "----" % (ntrial, ntrial * len(HOTSPOTS)))
    res = {}
    for kind in ("格子(位相を振る)", "一様乱数(同じ本数)"):
        atts, dists = [], []
        per = {hi: [] for hi in range(len(HOTSPOTS))}
        for k in range(ntrial):
            if kind.startswith("格子"):
                pts, _ = lattice(d, rng.uniform(0.0, d, 3))
            else:
                pts = cloud(n, 1000 + k)
            for hi in range(len(HOTSPOTS)):
                c = centre(hi)
                s = HOTSPOTS[hi][4]
                q = local_grid(c, max(1.6 * s, 0.9 * d))
                near = np.all(np.abs(pts - c) <= max(1.6 * s, 0.9 * d) + 2.6 * d,
                              axis=1)
                sub = pts[near]
                f1 = fit(sub, read(sub, None, 0.0), "nearest")
                f0 = fit(sub, read(sub, hi, 0.0), "nearest")
                v = float(np.max(f1(q) - f0(q))) / HOTSPOTS[hi][5]
                atts.append(v)
                per[hi].append(v)
                dists.append(nearest_dist(hi, pts))
        res[kind] = {"att": np.array(atts), "dist": np.array(dists),
                     "per": {hi: np.array(v) for hi, v in per.items()}}
        print("   %-20s 最近傍距離 中央値 %.4f m / 最悪 %.4f m   "
              "回復 中央値 %.4f / 最悪 %.4f"
              % (kind, np.median(res[kind]["dist"]), res[kind]["dist"].max(),
                 np.median(res[kind]["att"]), res[kind]["att"].min()))

    print("\n   ---- ラック別の最悪回復(%d 例中)と、格子の幾何下限 ----" % ntrial)
    print("   ラック     格子の最悪   幾何の下限 exp(-3d²/8σ²)   乱数の最悪")
    below = 0
    for hi, h in enumerate(HOTSPOTS):
        gmin = float(res["格子(位相を振る)"]["per"][hi].min())
        rmin = float(res["一様乱数(同じ本数)"]["per"][hi].min())
        bound = visible(d, h[4])
        below += int(rmin < bound - 1e-4)
        print("   σ=%.2f  %11.5f %20.5f %14.5f%s"
              % (h[4], gmin, bound, rmin,
                 "  ← 下限を割った" if rmin < bound - 1e-4 else ""))
    print("  ★★**違うのは平均ではなく「言い切れるかどうか」**。格子の回復は"
          "幾何の下限を 1 度も\n     割らない(位相をどう振っても割れない)。"
          "乱数は %d 台で下限を割った —— 最近傍距離に\n     上限が無いので、"
          "運が悪ければいくらでも見えなくなる(この %d 例の最悪は %.4f m 離れた)。"
          % (below, ntrial * len(HOTSPOTS),
             res["一様乱数(同じ本数)"]["dist"].max()))
    print("     同じ本数でも、格子は「最悪でもここまで見える」と設計時に"
          "言える。乱数は言えない。")
    print("     (σ=%.2f m の行で乱数の最悪が下限とほぼ同値なのは偶然 —— "
          "この種のいちばん悪い\n     引きが %.5f m で、格子の保証最悪 %.5f m に"
          "たまたま近かっただけ。)"
          % (HOTSPOTS[0][4], np.sqrt(-2 * HOTSPOTS[0][4] ** 2
                                     * np.log(max(res["一様乱数(同じ本数)"]
                                                  ["per"][0].min(), 1e-12))),
             r_grid))

    rr = np.linspace(0.0, 1.0, 80)
    figs.save_plot(
        "grid_vs_random",
        [("格子(%d 本)" % n, np.sort(dg), np.linspace(0, 1, dg.size)),
         ("一様乱数(%d 本)" % n, np.sort(dr), np.linspace(0, 1, dr.size)),
         ("Poisson の予測 1-exp(-4πλr³/3)", rr,
          1.0 - np.exp(-(4 * np.pi / 3) * lam * rr ** 3)),
         ("格子の幾何上限 d√3/2", [r_grid, r_grid], [0.0, 1.0])],
        xlabel="最も近いセンサまでの距離 [m](間隔 %.2f m 相当)" % d,
        ylabel="累積割合", title="格子は死角を決め打ち、乱数は死角を振る",
        caption="格子の最悪距離 %.3f m を乱数の %.2f %% が超えた(予測 %.2f %%)。"
                % (r_grid, 100 * frac, 100 * p_worse))
    return {"n": n, "p_worse": p_worse, "frac": frac, "r_grid": r_grid,
            "dg_max": float(dg.max()), "dr_max": float(dr.max()),
            "below": below,
            "grid_min": {hi: float(res["格子(位相を振る)"]["per"][hi].min())
                         for hi in range(len(HOTSPOTS))},
            "rand_min": {hi: float(res["一様乱数(同じ本数)"]["per"][hi].min())
                         for hi in range(len(HOTSPOTS))},
            "res": {k: {"att": v["att"].tolist(), "dist": v["dist"].tolist()}
                    for k, v in res.items()}}


# --------------------------------------------------------------------------- #
# 5. 対照群 b —— 補間 3 種で崖は動くか                                          #
# --------------------------------------------------------------------------- #
def section_methods_cliff(hi=1) -> dict:
    print("\n" + "=" * 78)
    print("5) 対照群 b —— 補間法を 3 つ入れ替える(ラック %s、σ=%.2f m、最悪位相)"
          % (HOTSPOTS[hi][0], HOTSPOTS[hi][4]))
    print("=" * 78)
    s = HOTSPOTS[hi][4]
    print("   予測: 崖の位置は補間法で決まらない。半減間隔は d* = 1.3596 σ = "
          "%.4f m のはず。" % half_spacing(s))
    print("\n   間隔 d [m]      予測    最近傍     線形     RBF")
    curves = {m: [] for m in ("nearest", "linear", "rbf")}
    for d in DS:
        row = [visible(d, s)]
        for m in curves:
            v = recover(hi, d, "worst", m, 0.0)["geo"]
            curves[m].append(v)
            row.append(v)
        print("     %5.2f    %8.4f %8.4f %8.4f %8.4f" % tuple([d] + row))

    def crossing(ys):
        """回復が 0.5 を切る d を線形に補間して返す。"""
        for i in range(1, len(DS)):
            if ys[i - 1] >= 0.5 > ys[i]:
                t = (0.5 - ys[i - 1]) / (ys[i] - ys[i - 1])
                return DS[i - 1] + t * (DS[i] - DS[i - 1])
        return float("nan")

    cross = {m: crossing(curves[m]) for m in curves}
    cross_pred = crossing([visible(d, s) for d in DS])
    spread = max(cross.values()) - min(cross.values())

    # --- 減り方(指数)と持ち上がり(係数)を分けて数える --- #
    d2 = np.array(DS) ** 2
    slope_pred = -3.0 / (8.0 * s * s)
    print("\n   ---- 崖を「指数」と「係数」に分ける ----")
    print("   log(回復) を d² に対して直線で当てると、傾きが崖の急さ、"
          "切片が持ち上がり。")
    print("   予測の傾きは -3/(8σ²) = %+.4f /m²。" % slope_pred)
    print("   手法       傾き        予測との差   係数 exp(切片)   半減間隔 d*")
    slopes, gains = {}, {}
    for m in ("nearest", "linear", "rbf"):
        k, b = np.polyfit(d2, np.log(np.array(curves[m])), 1)
        slopes[m], gains[m] = float(k), float(np.exp(b))
        print("   %-9s %+9.4f /m²  %+9.4f    %8.4f      %8.4f m"
              % (MET_LABEL[m].split("(")[0], k, k - slope_pred,
                 np.exp(b), cross[m]))
    print("   %-9s %+9.4f /m²  %9s    %8.4f      %8.4f m"
          % ("閉形式", slope_pred, "—", 1.0, half_spacing(s)))

    sl_spread = max(abs(v - slope_pred) for v in slopes.values())
    print("\n  ★**動かないのは指数、動くのは係数**。3 手法の傾きは予測と"
          "最大 %.4f /m² しか違わない\n     (%.2f %%)—— 崖の急さは"
          "サンプリングだけで決まる。補間はセンサが取らなかった値を作れない。"
          % (sl_spread, 100 * sl_spread / abs(slope_pred)))
    print("  ★★**「崖の位置は手法で動かない」という予測は外した**。"
          "半減間隔は 最近傍 %.4f / 線形 %.4f /\n     RBF %.4f m で、"
          "RBF だけ %.4f m(%.0f %%)ずれる。原因は係数 %.3f —— "
          "**薄板スプラインは\n     節点の値を超える**(内挿でありながら"
          "上に行き過ぎる)ので、山を一律 %.0f %% 高く戻す。"
          % (cross["nearest"], cross["linear"], cross["rbf"], spread,
             100 * spread / cross["nearest"], gains["rbf"],
             100 * (gains["rbf"] - 1)))
    print("     最近傍と線形が**小数点以下まで一致する**のは偶然ではない: "
          "どちらも節点の値を\n     超えないので、最悪位相での最大値は"
          "どちらも「いちばん近いセンサの読み」になる。")

    # 上向きの外れは無料か —— 何も無いところに立つ旗の高さを測る
    a = HOTSPOTS[hi][5]
    print("\n   ---- その持ち上がりは無料か(背景だけの場に立つ旗の高さ)----")
    print("   予想: 節点を超える手法は**背景の誤差も同じだけ持ち上げる**はずで、"
          "信号 / 偽物の比は\n   変わらない。以下は実測(d=%.2f m、雑音 σ=%.2f °C)。"
          % (0.60, NOISE))
    print("   手法       回復        床         床 [°C]   雑音との比   信号/偽物")
    ratio, floor_c = {}, {}
    for m in ("nearest", "linear", "rbf"):
        r = recover(hi, 0.60, "worst", m, NOISE)
        ratio[m] = r["geo"] / r["floor"]
        floor_c[m] = r["floor"] * a
        print("   %-9s %8.4f %10.4f %10.3f °C %10.1f x %10.2f"
              % (MET_LABEL[m].split("(")[0], r["geo"], r["floor"],
                 floor_c[m], floor_c[m] / NOISE, ratio[m]))
    print("  ★★**この予想は外した**。RBF の床は %.4f で、最近傍の床 %.4f より"
          "**低い**。\n     信号 / 偽物の比は 最近傍 %.2f → 線形 %.2f → RBF %.2f "
          "と、持ち上がる側のほうが良い。"
          % (recover(hi, 0.60, "worst", "rbf", NOISE)["floor"],
             recover(hi, 0.60, "worst", "nearest", NOISE)["floor"],
             ratio["nearest"], ratio["linear"], ratio["rbf"]))
    print("     理由は測れば分かる: 最近傍の床は %.3f °C = 雑音 %.2f °C の "
          "%.1f 倍で、**雑音ではなく\n     背景勾配を階段で近似した段差**。"
          "線形と RBF は滑らかな背景を追えるので床は雑音並み"
          "(%.3f / %.3f °C)。\n     **この場面では上向きの外れに代償が無かった**"
          " —— 代償が出るのは背景がもっと荒れているとき。"
          % (floor_c["nearest"], NOISE, floor_c["nearest"] / NOISE,
             floor_c["linear"], floor_c["rbf"]))

    figs.save_plot(
        "cliff_by_method",
        [("予測 exp(-3d²/8σ²)", DS, [visible(d, s) for d in DS]),
         ("最近傍", DS, curves["nearest"]),
         ("線形(Delaunay)", DS, curves["linear"]),
         ("RBF(薄板スプライン)", DS, curves["rbf"])],
        xlabel="センサ格子の間隔 d [m]", ylabel="回復したピークの割合",
        title="崖の急さは手法で動かない(σ=%.2f m のラック)" % s,
        caption="最近傍と線形は予測に重なる。RBF は %.2f 倍持ち上がるだけで、"
                "傾きは同じ。" % gains["rbf"])
    return {"curves": curves, "cross": cross, "spread": spread,
            "cross_pred": cross_pred, "slopes": slopes, "gains": gains,
            "slope_pred": slope_pred, "sl_spread": sl_spread, "ratio": ratio,
            "floor_c": floor_c}


# --------------------------------------------------------------------------- #
# 6. 物差し 3 つ —— 勝者は入れ替わるか                                          #
# --------------------------------------------------------------------------- #
def section_metrics(mc_gain: float, ds=(0.50, 0.80, 1.20)) -> dict:
    print("\n" + "=" * 78)
    print("6) 物差しを 3 つ置く —— 場の RMSE / ピーク温度の誤差 / 位置の誤差")
    print("=" * 78)
    truth = field(GRID)
    rows, out, hulls = [], {}, {}
    print("   間隔  手法                      場の RMSE   ピーク誤差(平均)  "
          "位置誤差   見失い  偽の峰")
    for d in ds:
        pts, ns = lattice(d)
        vals = read(pts, noise=NOISE)
        hulls[d] = hull_miss(pts, GRID)
        for m in METHODS:
            f = fit(pts, vals, m)
            rec = f(GRID)
            rmse = float(np.sqrt(np.mean((rec - truth) ** 2)))
            pe = [peak_error(f, hi) for hi in range(len(HOTSPOTS))]
            vol = rec.reshape(GX.size, GY.size, GZ.size).transpose(2, 1, 0)
            dl, ms, sp = loc_error(locate(vol))
            out[(d, m)] = {"rmse": rmse, "peak": float(np.mean(np.abs(pe))),
                           "loc": dl, "miss": ms, "spur": sp, "n": len(pts)}
            rows.append(["%.2f (%d 本)" % (d, len(pts)), MET_LABEL[m],
                         "%.3f" % rmse, "%+.2f" % float(np.mean(pe)),
                         ("%.3f" % dl) if np.isfinite(dl) else "—",
                         str(ms), str(sp)])
            print("   %.2f  %-26s %7.3f °C %10.2f °C %11s %6d %7d"
                  % (d, MET_LABEL[m], rmse, float(np.mean(pe)),
                     ("%.3f m" % dl) if np.isfinite(dl) else "—", ms, sp))
    print("\n   線形補間が凸包の外へ出て最近傍に落ちた割合: "
          + " / ".join("d=%.2f → %.1f %%" % (d, 100 * hulls[d]) for d in ds))
    print("   —— 壁・床・天井際は**必ず**外に出る。センサを部屋の内側にしか"
          "置けない以上、\n      外挿しない手法は端で必ず別の手法に化ける。")

    print("\n   ---- 物差しごとの勝者(ゼロ点を除く。同率は「同率」と書く)----")
    cand = [m for m in METHODS if m != "null"]

    def short(m):
        return MET_LABEL.get(m, m).split("(")[0]

    def best(d, key, tol):
        """``key`` が最小の手法。差が ``tol`` 未満なら同率として並べる。"""
        v = {m: key(out[(d, m)]) for m in cand if np.isfinite(key(out[(d, m)]))}
        if not v:
            return ["—"]
        lo = min(v.values())
        return [m for m in cand if m in v and v[m] - lo < tol]

    winners = {}
    for d in ds:
        w_rmse = best(d, lambda r: r["rmse"], 0.005)
        w_peak = best(d, lambda r: r["peak"], 0.05)
        w_loc = best(d, lambda r: r["miss"] * 10.0 + r["loc"], 0.01)
        winners[d] = (tuple(w_rmse), tuple(w_peak), tuple(w_loc))
        print("     d=%.2f m   RMSE: %-14s ピーク誤差: %-14s 位置誤差: %s"
              % (d, "/".join(short(m) for m in w_rmse),
                 "/".join(short(m) for m in w_peak),
                 "/".join(short(m) for m in w_loc)))
    swapped = any(not (set(a) & set(b) & set(c)) for a, b, c in winners.values())
    print("\n  ★3 つの物差しを**同時に勝つ手法は%s**。"
          % ("無い" if swapped else "在る"))
    print("     RMSE とピーク誤差は RBF、位置誤差は最近傍。"
          "1 つの数字に畳めば、どちらか一方の\n     失敗が見えなくなる。")
    print("  ★RBF がピーク誤差で勝つのは**原理的に正しいからではない**: "
          "§5 で測った %.2f 倍の\n     持ち上がりが、サンプリングによる減衰を"
          "たまたま逆向きに打ち消しているだけ\n     "
          "(d=%.2f m で 最近傍 %.2f °C 低く出る → RBF %.2f °C。どちらも真値に届かない)。"
          % (mc_gain, ds[1], out[(ds[1], "nearest")]["peak"],
             out[(ds[1], "rbf")]["peak"]))

    # ★「偽の峰 0」が本当に数えているのか、門を壊して確かめる
    global DETECT
    keep_thr, DETECT = DETECT, T_AMB + 4.0
    try:
        pts, _ = lattice(ds[0])
        rec = fit(pts, read(pts, noise=NOISE), "rbf")(GRID)
        vol = rec.reshape(GX.size, GY.size, GZ.size).transpose(2, 1, 0)
        _, _, sp_low = loc_error(locate(vol))
    finally:
        DETECT = keep_thr
    print("\n  ★「偽の峰 0」は数え忘れではない: しきい値を %.1f → %.1f °C へ"
          "下げると、同じ体積から\n     偽の峰が %d 個出る"
          "(ホットアイルの帯そのものが峰になる)。門を壊して確かめた。"
          % (DETECT, T_AMB + 4.0, sp_low))
    assert sp_low > 0, sp_low
    figs.save_table(
        "metric_table",
        ["間隔 d", "手法", "RMSE [°C]", "ピーク誤差 [°C]", "位置誤差 [m]",
         "見失い", "偽の峰"], rows,
        title="物差し 3 つ(1 つの数字に畳まない)", col_w=130)
    return {"out": {("%.2f|%s" % k): v for k, v in out.items()},
            "winners": {("%.2f" % k): v for k, v in winners.items()},
            "swapped": swapped, "spur_low": sp_low, "hulls": hulls, "raw": out}


# --------------------------------------------------------------------------- #
# 7. 図 —— 同じ測定を 4 通りに復元した断面                                       #
# --------------------------------------------------------------------------- #
def section_maps(d=0.80) -> None:
    print("\n" + "=" * 78)
    print("7) 図 —— 同じ測定を 4 通りに復元した断面(間隔 %.2f m)" % d)
    print("=" * 78)
    truth = field(GRID)
    pts, _ = lattice(d)
    vals = read(pts, noise=NOISE)
    iz = int(round(2.30 / EV))
    lo, hi_ = 17.0, 40.0

    def slab(v):
        return np.asarray(v).reshape(GX.size, GY.size, GZ.size).transpose(2, 1, 0)[iz]

    pans = [np.asarray(fs.apply_cmap(slab(truth), "turbo", vmin=lo, vmax=hi_))]
    caps = ["真値 z=2.30 m"]
    for m in METHODS:
        pans.append(np.asarray(fs.apply_cmap(slab(fit(pts, vals, m)(GRID)),
                                             "turbo", vmin=lo, vmax=hi_)))
        caps.append(MET_LABEL[m].split("(")[0])
    figs.save_grid("map_reconstruction", pans, caps, ncols=3,
                   title="間隔 %.2f m・%d 本のセンサから復元した z=2.30 m 断面"
                         "(%.0f-%.0f °C 共通尺度)" % (d, len(pts), lo, hi_),
                   caption="横=x 0..%.0f m、縦=y 0..%.1f m。"
                           "3 台の過負荷ラックのうち何台が残るか。" % (LX, LY))

    res = slab(fit(pts, vals, "rbf")(GRID)) - slab(truth)
    figs.save("map_residual", res,
              "RBF 復元の残差 [°C](正 = 高く出た。z=2.30 m)", signed=True)


# --------------------------------------------------------------------------- #
# 8. 道具の穴                                                                   #
# --------------------------------------------------------------------------- #
def section_tool_gaps() -> None:
    print("\n" + "=" * 78)
    print("8) 道具の穴 —— この PoC が炙り出して、その場で埋めた 1 本")
    print("=" * 78)
    assert hasattr(fs, "interp_scattered"), "interp_scattered が公開経路に無い"
    pp, _ = lattice(1.20)
    pv = read(pp, noise=NOISE)
    probe = fs.interp_scattered(pp, pv, GRID, method="linear")
    print("  (a) **補間の op が 1-D だけだった**(interp_linear / interp_cubic)。"
          "散らばった 3-D の点から\n      場を作る口が無く、scipy を直に呼んで"
          "いた —— センサ網・地質・気象はどれもこの形。")
    print("      ★`fs.interp_scattered` を足した(2026-09-08)。この PoC の "
          "linear / rbf / hull_miss は\n      いまその op を通る。"
          "★設計で効いたのは**凸包の外に出た割合を返り値に入れた**こと ——"
          "\n      いまの %d 本のセンサとこの評価格子で %.1f %% が外に出ており、"
          "黙って NaN か\n      別手法に化ける量がそれだけ大きいなら、"
          "戻り値に居るべきだった(6 節の 71.2 %% はこの量)。"
          % (len(pp), 100.0 * probe["outside_fraction"]))
    print("      ★使ってみて分かって足した引数が 1 つある: `neighbors`"
          "(RBF を近傍だけで解く)。\n      全体解は O(n³) で、5000 点を"
          "問い合わせると 1400 / 4000 / 8000 本で 0.55 / 1.76 / 7.53 秒。"
          "\n      **op は使って初めて足りない引数が分かる**。")

    assert hasattr(fs.ledger, "vol_local_maxima")
    pk = np.asarray(_L.vol_local_maxima(np.zeros((8, 8, 8)), min_distance=1))
    assert pk.shape[0] == 0, pk.shape
    print("  (b) vol_local_maxima は平らな体積で 0 個を返す(fail-closed)。"
          "**整数ボクセル**を\n      返すので、位置精度は評価格子の刻み"
          " %.2f m で頭打ち。サブボクセル化は\n      refine_peak_newton に"
          "在るが torch が要る —— CI(torch 無し)では使えない。" % EV)

    z = np.zeros((4, 4))
    z[1, 1] = 1.0
    a = np.asarray(fs.apply_cmap(z, "turbo"))
    b = np.asarray(fs.apply_cmap(z * 100.0, "turbo"))
    assert np.allclose(a, b), "vmin/vmax 無しの正規化は配列ごと"
    print("  (c) apply_cmap は vmin/vmax を省くと**渡した配列の中だけ**で"
          "正規化する。温度場を\n      1 枚ずつ塗ると色尺度が揃わない"
          "(1 °C の差も 20 °C の差も同じ絵になる)。\n      "
          "この PoC は全パネルに vmin/vmax を明示した。")


# --------------------------------------------------------------------------- #
def main() -> int:
    t0 = time.perf_counter()
    print("=" * 78)
    print("データセンターの温度場を疎なセンサから復元する —— "
          "格子の死角がラックを消す")
    print("室 %.0f x %.1f x %.1f m / 過負荷ラック %d 台(σ = %s m) / "
          "センサ雑音 σ=%.2f °C"
          % (LX, LY, LZ, len(HOTSPOTS),
             ", ".join("%.2f" % h[4] for h in HOTSPOTS), NOISE))
    print("=" * 78)

    sc = section_scene()
    zp = section_zero_point()
    cl = section_cliff()
    gr = section_grid_vs_random()
    mc = section_methods_cliff()
    mt = section_metrics(mc["gains"]["rbf"])
    section_maps()
    section_tool_gaps()

    print("\n" + "=" * 78)
    print("まとめ")
    print("=" * 78)
    print("  * 閉形式 exp(-3d²/8σ²) と幾何だけの実測は %.1e で一致する。"
          "崖は**測る前に言える**。" % cl["err"])
    print("  * ★外れたのは「現場で測れる量」のほう: 素朴なピーク測定は予測を"
          "最大 %+.4f 超過する\n    —— 超過ぶんは背景の復元誤差で、"
          "**崖は実際より浅く見える**。" % cl["excess"])
    print("  * ★もう 1 つ外した: 「崖の位置は手法で動かない」は言い過ぎで、"
          "RBF は半減間隔を %.4f m\n    ずらす(係数 %.2f 倍の持ち上がり)。"
          "動かないのは**指数**のほう(予測との差 %.4f /m²)。"
          % (mc["spread"], mc["gains"]["rbf"], mc["sl_spread"]))
    print("  * ★3 つ目の外し: 「持ち上がる手法は偽の峰も同じだけ持ち上げる」も"
          "外れた。最近傍の床は\n    %.3f °C(雑音の %.1f 倍)で、"
          "**滑らかな背景を階段で近似した段差**のほうが大きい。"
          % (mc["floor_c"]["nearest"], mc["floor_c"]["nearest"] / NOISE))
    print("  * 乱数配置は死角を消さない: %.2f %% が格子の最悪距離を超えた"
          "(Poisson の予測 %.2f %%)。格子は\n    幾何の下限を 1 度も割らず、"
          "乱数は %d 台で割った —— 同じ本数でも「言い切れるか」が違う。"
          % (100 * gr["frac"], 100 * gr["p_worse"], gr["below"]))
    print("  * 3 つの物差しを同時に勝つ手法は%s。"
          % ("無い" if mt["swapped"] else "在る"))
    print("\n  所要 %.1f 秒" % (time.perf_counter() - t0))

    # --- 所見を固定する(穴が塞がったら鳴る)--- #
    # (1) 閉形式は幾何そのもの。ずれたら field / lattice / recover のどれかが壊れた。
    assert cl["err"] < 1e-6, cl["err"]
    # (2) 崖は本当に落ちる(σ=0.22 m のラックは d=0.80 m でほぼ消える)。
    assert cl["geo"][(0.30, 2)] > 0.4 and cl["geo"][(0.80, 2)] < 0.02, cl["geo"]
    # (3) 現場で測れる量は予測より必ず上に出る(背景の誤差が同じ場所に載る)。
    assert cl["excess"] > 0.15, cl["excess"]
    assert cl["naive"][(1.20, 2)] > 10 * cl["geo"][(1.20, 2)], cl["naive"]
    # (4) 指数は手法で動かない / 係数は動く(RBF は節点を超える)。
    assert mc["sl_spread"] < 0.05 * abs(mc["slope_pred"]), mc["slopes"]
    assert mc["gains"]["rbf"] > 1.2 and mc["spread"] > 0.05, mc["gains"]
    assert abs(mc["curves"]["nearest"][2] - mc["curves"]["linear"][2]) < 1e-9
    # (5) 乱数は死角を消さない(Poisson の予測に載る)。格子は幾何の下限を割らない。
    assert abs(gr["frac"] - gr["p_worse"]) < 0.02, (gr["frac"], gr["p_worse"])
    assert gr["dr_max"] > gr["r_grid"] and gr["dg_max"] <= gr["r_grid"] + 1e-9
    for _hi, _h in enumerate(HOTSPOTS):
        assert gr["grid_min"][_hi] >= visible(0.60, _h[4]) - 1e-9, gr["grid_min"]
    assert gr["below"] >= 1, gr["below"]
    # (5b) 上向きに外れる手法が偽の峰を増やす、という予想は外れた(床で確認)。
    assert mc["floor_c"]["nearest"] > 3 * NOISE, mc["floor_c"]
    assert mc["floor_c"]["rbf"] < mc["floor_c"]["nearest"], mc["floor_c"]
    assert mc["ratio"]["rbf"] > 3 * mc["ratio"]["nearest"], mc["ratio"]
    # (6) ゼロ点は 1 台も見つけない / 手法はゼロ点を大きく上回る。
    assert zp["res"]["null"]["miss"] == len(HOTSPOTS), zp["res"]["null"]
    assert zp["res"]["rbf"]["rmse"] < 0.5 * zp["res"]["null"]["rmse"]
    # (7) 真値そのものは評価格子の刻みの範囲で正しく見つかる(測定系の検算)。
    assert sc["miss"] == 0 and sc["loc"] <= EV * np.sqrt(3) + 1e-9, sc
    # (8) 物差しで勝者が入れ替わる。
    assert mt["swapped"], mt["winners"]

    if figs.errors():
        print("図の書き出しで失敗:", "; ".join(figs.errors()))
    print("\nPASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
