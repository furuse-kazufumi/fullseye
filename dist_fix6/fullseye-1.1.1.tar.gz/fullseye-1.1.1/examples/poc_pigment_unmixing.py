# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""多波長で層を剥がす —— 下絵・地塗り・上塗り・褪色を、真値を握ったまま分離する。

彩色された層は 1 枚ではない。地塗りの上に線で下絵が引かれ、その上に不透明度の違う
絵具が重なり、一部は剥落し、有機の色材は褪せる。可視の写真 1 枚からこの重なりを
解こうとすると何が起きるのか、真値を自分で作って測る。

EXTEND: 実測の分光反射率に差し替えるなら ``PIGMENTS`` の masstone(R∞)配列だけを
置き換える。層の合成 (``render_spectra``) も評価も、そこから下は触らなくてよい。
実機の多波長・近赤外反射画像に差し替えるなら ``make_cube`` を読み込みに替える。
留意点が 4 つある。(1) **反射率に直してから渡す** —— 本 PoC の op はどれも反射率
(0–1)を前提にしていて、生の DN のまま渡しても例外は出ず、端成分との当てはめが
静かに崩れるだけである。白色標準板と暗電流の 2 枚が要る。(2) **バンドの中心波長を
自分で持ち回る** —— ``fs.spec_nearest_band`` は ``BandMeta`` を要求するが、キューブと
波長軸を組にして作る入口の op が無いので、結局呼び手が中心波長の配列を保持する
ことになる(本 PoC もそうしている)。(3) **近赤外の上限で結論が変わる** —— 下の
6 節のとおり、銅系の青の下は 1000 nm では見えない。実際の赤外反射法が 1.5–2.0 µm を
使うのはこのためで、センサの上限波長は「バンド数」よりはるかに効く。(4) **層は
線形に混ざらない** —— 反射率をそのまま線形アンミキシングに掛けると、8 節のとおり
推定が単体の頂点に張り付く。

この PoC が示すこと:

1. **ゼロ点を先に置く** —— 可視 RGB の主成分分析。しかも符号と成分を真値を見て
   選ぶ下駄を履かせ、さらに面ごとに主成分分析からやり直した版も測る。
2. **「多波長だから勝つ」ではない** —— 可視だけを 16 バンドに割っても RGB と同じ
   (再現率 0.118 対 0.119)。勝ったのは **近赤外を入れたこと**であって、バンドを
   増やしたことではない。
3. **1 つの数字にまとめない** —— 同じ検出器が、群青の面で AUC 1.000、アズライトの
   面で 0.630、剥落部で 0.013 になる。平均すると全部消える。
4. **崖を 5 本引く** —— 上層の厚み / バンド数 / 2 つの青の分光の似方 / 褪色 / 雑音。
5. **勝てなかったことを書く** —— 褪色前の色の復元は、ゼロ点(何もしない)に
   ほとんど勝てなかった(ΔE00 16.79 → 16.46、改善 2 %)。

主な実測(80x120 画素、400–1000 nm を 121 点で合成、16 バンド、上層の厚み倍率
tau=0.6、雑音は光量一定モデル sigma = 0.001*sqrt(B) = 0.0040)。閾値は「下絵の
無い画素の 1 % だけが超える」ところに **全体で 1 本**:

  ==================== ===== ============ ============ ======= ======= ======= ======
  手法                  AUC  再現率@FPR1% 適合率@FPR1%  群青※  アズ※  朱茜※  剥落※
  ==================== ===== ============ ============ ======= ======= ======= ======
  RGB の PCA(ゼロ点)  0.723        0.119        0.558   0.771   0.685   0.942  1.000
  可視のみ 16 バンド    0.728        0.118        0.556   0.708   0.565   0.782  1.000
  可視+近赤外 PCA      0.704        0.382        0.802   1.000   0.499   0.953  1.000
  可視+近赤外 MNF      0.677        0.000        0.000   0.997   0.225   0.891  0.893
  線形アンミキシング    0.722        0.444        1.000   0.500   0.500   1.000  1.000
  K/S アンミキシング    0.792        0.287        0.752   0.846   0.582   0.926  1.000
  近赤外の単純差分      0.845        0.402        0.810   1.000   0.630   1.000  0.013
  近赤外 1 枚(反転)    0.740        0.000        0.000   1.000   0.437   1.000  1.000
  分光角マッパ          0.476        0.209        0.689   0.973   0.635   0.520  0.520
  ==================== ===== ============ ============ ======= ======= ======= ======

  ※ = その面だけで求めた AUC。全体で 1 本の閾値とは別の問い。

読み方が 4 つある。

* **近赤外 1 枚は「面ごとには完璧、全体では 1 本も引けない」** —— 群青の面でも
  朱の面でも AUC 1.000 なのに、全体の再現率は 0.000。面ごとに絵具の近赤外反射率が
  0.16 から 0.86 まで違うので、下絵の信号(0.19 くらいの落ち込み)より **面の間の
  ばらつきのほうが大きい**。一枚の閾値で運用する装置は、この検出器では作れない。
* **近赤外の「差分」は剥落部で盲目になる**(0.013)。差分は分光が平坦な材料で
  打ち消し合うので、上層が失われて地(白亜)と炭素黒だけになった場所 —— つまり
  いちばん簡単なはずの場所 —— で消える。近赤外 1 枚のほうは同じ場所で 1.000。
  **同じ「近赤外を使う」でも、読み出しを変えると得意な場所が入れ替わる。**
* **線形アンミキシングは適合率 1.000 だが、動作点が飛び飛び**。負例の存在量が
  厳密に 0 に張り付くので、偽陽性率 1 % の動作点が存在しない(実測 0.0000)。
  分位点をそのまま閾値にして ``>=`` で数えた最初の版は「再現率 1.000 / 適合率
  0.095」を出した。**同値の多い検出器では、動作点があると思い込むと嘘になる。**
* **MNF は PCA に負けた**(AUC 0.677 対 0.704)。``spec_mnf`` の雑音共分散は横隣との
  差から見積もられるが、下絵は 1–2 画素幅の線なので、その横差分のエネルギーは
  下絵の上で **3.9 倍**(5.264e-03 対 1.343e-03)。**本命の信号を雑音として
  白色化している。**

崖(数値はすべて上と同じ条件から 1 つだけ振ったもの):

  (a) **上層の光学的厚み**。近赤外差分の全体再現率は tau = 0.15 / 0.30 / 0.60 /
      1.00 / 1.60 / 2.50 で 0.851 / 0.653 / 0.407 / 0.195 / 0.063 / 0.022。
      **半分を割るのは tau = 0.30 と 0.60 の間**(下絵の反射率の落ち込みが近赤外で
      0.30 → 0.19、可視では 0.070 → 0.015 に痩せるあたり)。
      アズライトの面だけを見ると崖はもっと手前にあり、tau = 0.15 で 1.000 だったのが
      0.30 で 0.278、0.60 で 0.018。**同じ絵の中で崖の位置が 4 倍違う。**
  (b) **バンド数**。3 → 8 → 16 → 31 で、アンミキシングの AUC は
      0.503 → 0.722 → 0.721 → 0.721。**8 本で頭打ち**で、そこから先はただ増えない。
      光量が足りている限り悪化もしない(31 本でも 0.721)。ところが露光を 225 分の 1
      に切り詰めると、群青の存在量の散らばりが 3 本 0.0576 → 8 本 0.1223 → 31 本
      0.1321 と **増やすほど悪くなる**。同じ低照度でも近赤外差分の再現率のほうは
      0.014 → 0.058 → 0.087 と改善する。**「バンドを増やすと良いか」に単一の答えは
      無い。何を推定するかで符号が変わる。**
  (c) **2 つの青の分光の似方**。16 バンドでの相関 r に対して配合比の散らばりは
      r = -0.107 / 0.428 / 0.853 / 0.972 / 0.994 / 0.999 / 0.9997 で
      0.005 / 0.010 / 0.021 / 0.044 / 0.088 / 0.170 / 0.290。**分けられなくなる境界は
      r ≈ 0.994–0.999**(1 割の精度を要求した場合)。偏りはどこでも 0.003 以下で、
      **壊れ方は偏りではなく散らばり** —— つまり補正では直らない。
  (d) **褪色**。茜レーキの吸収 K を 1 → 0.15 に落とすと、端成分を未褪色のまま
      使った場合の復元 ΔE00 は 3.28 → 19.08。存在量のほうは **褪色に一切反応しない**
      (偏り -0.833 で完全に一定)—— 薄く透明な層は自分の masstone と似ていないので、
      アンミキシングは最初から茜を 0 と読み、朱と誤認している(茜の面の 100 %)。
  (e) **雑音**。sigma = 0 / 0.001 / 0.004 / 0.010 / 0.030 / 0.100 で近赤外差分の
      再現率は 0.464 / 0.443 / 0.420 / 0.364 / 0.201 / 0.053。存在量の散らばりは
      0.0228 / 0.0228 / 0.0228 / 0.0233 / 0.0582 / 0.1651。**sigma = 0 でも散らばりが
      0.0228 残る** —— これは雑音ではなく層のモデル不整合が作っている床である。

顔料の存在量(偏りと散らばりを分ける。真値は上層の濃度、和 1):

  ================ ========== ======== ======== ========== ==========
  端成分 / 解く空間 顔料       真の濃度   偏り     散らばり  偏り/散らばり
  ================ ========== ======== ======== ========== ==========
  masstone / R      アズライト    0.526   +0.474      0.061        7.8
  masstone / R      朱            0.541   +0.344      0.038        9.1
  masstone / R      茜レーキ      0.833   -0.833      0.020       41.7
  masstone / K,S    茜レーキ      0.833   -0.583      0.211        2.8
  現場採取 / R      茜レーキ      0.833   +0.093      0.094        1.0
  ================ ========== ======== ======== ========== ==========

**壊れ方は散らばりではなく偏り**である(反射率空間では偏りが散らばりの 8–42 倍)。
偏りが支配的ということは、推定が単体の頂点に張り付いていて雑音にすら反応していない
ということで、実際 (e) の表のとおり sigma を 0 から 0.01 まで振っても存在量が動かない。
K/S 空間で解くと茜の偏りは -0.833 → -0.583、朱は +0.344 → -0.047 に縮むが、
散らばりは 0.020 → 0.211 に増える。**片方だけ見れば「良くなった」とも「悪くなった」
とも書けてしまう。**

そして **褪色前の色の復元はゼロ点に勝てなかった**:

  ======= =============== ============= ============= =============
  褪色 f  何もしない ΔE00 端成分固定    K/S 固定      現場端成分
  ======= =============== ============= ============= =============
  1.00               0.16          3.28          2.71         16.36
  0.50               6.60          9.10          6.35         15.95
  0.15              16.79         19.08         16.46         15.77
  ======= =============== ============= ============= =============

褪色していない f=1 ですら、組み直すだけで ΔE00 が 2.71–3.28 乗る。線形の端成分で
分解して組み直すという操作そのものが、褪色より大きい誤差を持ち込んでいる。
現場から採った端成分は存在量の推定ではいちばん良い(茜の偏り +0.093)のに、
組み直しでは f=1 で ΔE00 16.36 —— **見え方の端成分と物質の端成分は別物**で、
前者で分解して後者で組み直すと別の絵になる。

★ この PoC が出した道具の穴(6 件。op 本体には手を入れていない):

  (a) **Kubelka–Munk が 1 つも無い**。彩色層を扱うのに要るのは最低 3 つ ——
      R∞ ↔ K/S の変換、有限厚の層を下地に載せた反射率(双曲線解)、そして
      2 定数 KM の混合。本 PoC は 30 行ほど自前で書いた。とくに効くのは
      ``spec_unmix`` に **解く空間を選ぶ引数**を足すことで、この 1 つで朱の偏りが
      +0.344 → -0.047 に変わる。提案: ``km_ks_from_reflectance(r_inf)`` /
      ``km_reflectance_from_ks(ks)`` / ``km_layer_over(k, s, thickness, r_ground)`` /
      ``spec_unmix(cube, endmembers, space="reflectance"|"ks")``。
  (b) **``spec_mnf`` に外から雑音を渡せない**。雑音共分散は横隣との差に固定で、
      上のとおり細い線が本命の課題では信号を雑音として消す(横差分エネルギーが
      下絵の上で 3.9 倍)。暗電流フレームや平坦部から測った共分散を渡せれば済む。
      提案: ``spec_mnf(cube, n_components=3, noise_cov=None)``(``None`` なら現行)。
  (c) **キューブと波長軸を組にして作る入口が無い**。``spec_nearest_band`` は
      ``BandMeta`` を要求するのに、それを作る op が公開 API に見当たらず、
      結局呼び手が中心波長の配列を持ち回る。提案:
      ``spec_cube(bands, wavelengths_nm, name=None) -> (cube, BandMeta)``。
  (d) **「既知の領域から端成分を採る」op が無い**。修復の現場で実際にやるのは
      PPI のような自動抽出ではなく「この材料だけの場所」を採ることで、本 PoC でも
      それが茜の偏りを -0.833 から +0.093 に変えた(20 行ほど自前)。提案:
      ``spec_region_spectra(cube, labels) -> (K, B) と (K, B, B)``(平均と共分散。
      共分散があると当てはめに重みを付けられる)。
  (e) **地図 + 真値マスク → ROC / 動作点 の op が無い**。これは
      ``examples/poc_forensics_roc.py`` が既に (d) として挙げているので繰り返さない。
      本 PoC が足す点は **同値の扱い**で、分位点閾値 + ``>=`` は存在量マップのように
      負例が 0 に集中する検出器で偽陽性率を跳ね上げる(「再現率 1.000 / 適合率
      0.095」という到達不能な動作点が出た)。提案する op は **実際に到達した偽陽性率を
      必ず返す**こと: ``operating_point(score, positive, negative, fpr=0.01)
      -> {"threshold", "recall", "precision", "achieved_fpr"}``。
  (f) **分光 → ΔE の道に踏み台がある**。``spectrum_to_srgb`` は **線形** sRGB を返し、
      ``delta_e_map`` / ``rgb_to_lab`` は **ガンマ後の** sRGB を期待する。間に
      ``linear_to_srgb`` を挟み忘れても例外は出ず、実測でこの場面の ΔE00 が
      11.22 → 13.55(**21 % 過大**)になる。どちらの docstring も相手に言及していない。
      提案: ``spectrum_to_lab(nm, reflectance, illuminant=None)`` を一本足すか、
      少なくとも両方の docstring に相互参照を書く。

なお ``fs.spec_pca`` / ``fs.spec_unmix`` / ``fs.spec_mnf`` が ``(H, W, 3)`` を拒否する
件は別に報告が上がっているので繰り返さない。本 PoC からの追加は **拒否が刺さる場所**
だけで、バンド数の頭打ちを測るには 3 バンドが要り、しかも可視 / レッドエッジ /
近赤外の 3 バンド機は実在する構成である(RGB の取り違えではない)。
``spec_decorrelation_stretch`` には既に ``allow_rgb`` 相当の逃げ道があるので、
同じ形の明示的なオプトインを他の 3 つにも置けば済む。

分光反射率について: ここに置いた曲線は **文献の実測値ではない**。炭素は全域で暗い /
銅系の青は近赤外でも吸収が残る / 群青は近赤外で明るい / 朱は 590 nm 付近で立ち上がる /
有機レーキは褪色すると吸収が落ちる、という既知の定性的な振る舞いを模した解析曲線で
あり、絶対値の一致は主張しない。散乱能は S(λ) = S550 * (550/λ)^1.5 とした
(近赤外が透けるのは吸収が落ちるからだけでなく散乱が落ちるからでもある)。

実行時間(この機械、Windows 11 / py 3.11 / numpy 2.4.6 / scipy 1.15.2)は全体で
約 20 秒。内訳の大半は ``spec_unmix`` の制約付き解(9600 画素 x 7 端成分で 1 回
0.34 秒、崖の掃引ぶん 54 回)。乱数は雑音にしか使わず種を固定しているので、
**同じ環境で何度走らせても同じ数字を出す**(2 回走らせて出力を突き合わせて確認済み)。
"""
from __future__ import annotations

import time
import unicodedata

import numpy as np

import fullseye as fs

import examplefig as figs   # ★fullseye の後(パスフックがリポジトリ直下を通す)

# --------------------------------------------------------------------------- #
# 0. 表示の道具                                                                 #
# --------------------------------------------------------------------------- #
WL = np.arange(400.0, 1001.0, 5.0)          # 分光格子 (121,) [nm]
VIS = WL <= 700.0                            # 可視の範囲
NIR_LO, NIR_HI = 780.0, 1000.0

H, W = 80, 120
SEED = 20260906


def _dw(s):
    """全角を 2 桁と数えた表示幅(str.format は文字数で数えるので自前で持つ)。"""
    return sum(2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in str(s))


def _pad(s, n, right=False):
    s = str(s)
    fill = " " * max(0, n - _dw(s))
    return (fill + s) if right else (s + fill)


def _table(header, rows, widths=None, aligns=None):
    cols = len(header)
    widths = widths or [max(_dw(header[i]), *(_dw(r[i]) for r in rows)) if rows
                        else _dw(header[i]) for i in range(cols)]
    aligns = aligns or ([False] + [True] * (cols - 1))
    line = "  ".join("-" * w for w in widths)
    print(line)
    print("  ".join(_pad(header[i], widths[i], aligns[i]) for i in range(cols)))
    print(line)
    for r in rows:
        print("  ".join(_pad(r[i], widths[i], aligns[i]) for i in range(cols)))
    print(line)


def _zoom(a, k=3):
    """図に載せるためだけの最近傍拡大(80x120 のままだとパネルの題が入らない)。"""
    return np.repeat(np.repeat(np.asarray(a, float), k, axis=0), k, axis=1)


def _clip_pct(a, lo=1.0, hi=99.0):
    """図の塗り分けだけのための分位クリップ。**数値には一切使わない** ——
    外れ値 1 画素で全体が真っ黒になるのを防ぐためだけの表示処理。"""
    a = np.asarray(a, float)
    return np.clip(a, np.percentile(a, lo), np.percentile(a, hi))


def _sig(x, x0, k):
    return 1.0 / (1.0 + np.exp(-(np.asarray(x, float) - x0) / k))


def _gauss(x, mu, s):
    return np.exp(-0.5 * ((np.asarray(x, float) - mu) / s) ** 2)


# --------------------------------------------------------------------------- #
# 1. 顔料 —— 分光反射率(masstone)と散乱能                                       #
# --------------------------------------------------------------------------- #
# ここに置く曲線は **文献の実測値ではない**。既知の定性的な振る舞い
#   * 炭素は 400–1000 nm の全域で暗い(だから近赤外で下絵が残る)
#   * 銅系の青は近赤外でも吸収が残る(だから近赤外で下が見えにくい)
#   * 群青(ラピスラズリ系)は近赤外で明るく、層が透ける
#   * 朱(硫化水銀)は 590 nm 付近で立ち上がる階段状
#   * 有機レーキは褪色すると吸収 K が落ちて淡くなる
# を模した解析曲線である。**絶対値の一致は主張しない**。実測の分光反射率
# データベースに差し替えるときは PIGMENTS の "R" を置き換えるだけでよい。


def _pigment_table():
    lw = 0.90 - 0.25 * (1.0 - _sig(WL, 425.0, 15.0))            # 鉛白
    ch = 0.87 - 0.12 * (1.0 - _sig(WL, 415.0, 12.0))            # 白亜(地塗り)
    cb = 0.045 + 0.010 * (WL - 400.0) / 600.0                   # 炭素黒(下絵)
    az = 0.045 + 0.500 * _gauss(WL, 468.0, 42.0) + 0.10 * _gauss(WL, 760.0, 90.0)
    ul = 0.050 + 0.420 * _gauss(WL, 455.0, 48.0) + 0.720 * _sig(WL, 780.0, 55.0)
    vm = 0.045 + 0.750 * _sig(WL, 592.0, 9.0)                   # 朱
    md = 0.100 + 0.700 * _sig(WL, 610.0, 22.0) - 0.050 * _gauss(WL, 520.0, 30.0)
    return {
        # 名前:            (masstone R∞, 散乱能 S550, 表示名)
        "lead_white":  (lw, 12.0, "鉛白"),
        "chalk":       (ch, 10.0, "白亜(地)"),
        "carbon":      (cb, 1.20, "炭素黒(下絵)"),
        "azurite":     (az, 4.00, "アズライト"),
        "ultramarine": (ul, 3.00, "群青"),
        "vermilion":   (vm, 6.00, "朱"),
        "madder":      (md, 0.60, "茜レーキ"),
    }


PIGMENTS = _pigment_table()
#: 上層に使う 5 種(地と下絵は層ではないので別扱い)。この順が端成分行列の行順。
LAYER_KEYS = ("lead_white", "azurite", "ultramarine", "vermilion", "madder")
#: 波長による散乱能の減衰指数。S(λ) = S550 * (550/λ)^SCAT_P。
#: 近赤外で層が透けるのは K が落ちるからだけではなく **散乱が落ちるから**でもある。
SCAT_P = 1.5


def ks_ratio(r_inf):
    """masstone R∞ から Kubelka–Munk の K/S を出す(Kubelka 1948)。"""
    r = np.clip(np.asarray(r_inf, float), 1e-4, 1.0 - 1e-6)
    return (1.0 - r) ** 2 / (2.0 * r)


def scat(s550):
    """散乱能の波長依存 S(λ)。短波長ほど強く散る(だから近赤外が透ける)。"""
    return s550 * (550.0 / WL) ** SCAT_P


def km_layer(k_mix, s_mix, thickness, r_ground):
    """厚み有限の Kubelka–Munk 層を下地の上に載せた反射率。

    a = 1 + K/S, b = sqrt(a^2 - 1), t = S * X として

        R = (1 - Rg * (a - b * coth(b t))) / (a - Rg + b * coth(b t))

    t -> 0 で Rg、t -> inf で R∞ = a - b に落ちることは main() で数値確認する。
    """
    a = 1.0 + k_mix / s_mix
    b = np.sqrt(np.maximum(a * a - 1.0, 1e-18))
    bt = np.clip(b * s_mix * thickness, 1e-9, 60.0)
    coth = 1.0 / np.tanh(bt)
    num = 1.0 - r_ground * (a - b * coth)
    den = a - r_ground + b * coth
    return np.clip(num / den, 0.0, 1.0)


# --------------------------------------------------------------------------- #
# 2. 場面 —— 下絵の線・地塗り・上層・剥落                                        #
# --------------------------------------------------------------------------- #
def _stroke(cov, p0, p1, width):
    """線分を被覆率 alpha として焼き込む(端をなだらかにして中間の alpha を作る)。"""
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float64)
    (y0, x0), (y1, x1) = p0, p1
    dy, dx = y1 - y0, x1 - x0
    ll = dy * dy + dx * dx
    t = np.clip(((yy - y0) * dy + (xx - x0) * dx) / max(ll, 1e-9), 0.0, 1.0)
    d = np.hypot(yy - (y0 + t * dy), xx - (x0 + t * dx))
    np.maximum(cov, np.clip(1.0 - (d - width * 0.5) / 0.9, 0.0, 1.0), out=cov)


def _arc(cov, cy, cx, rad, width, a0, a1):
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float64)
    ang = np.arctan2(yy - cy, xx - cx)
    inside = (ang >= a0) & (ang <= a1)
    d = np.abs(np.hypot(yy - cy, xx - cx) - rad)
    v = np.where(inside, np.clip(1.0 - (d - width * 0.5) / 0.9, 0.0, 1.0), 0.0)
    np.maximum(cov, v, out=cov)


def build_scene():
    """真値一式を作る。乱数は雑音にしか使わない(構造は決定的)。

    戻り値の dict:
      ``ink``      (H,W) 下絵の被覆率 alpha。0 = 線なし。
      ``conc``     (H,W,5) 上層の顔料濃度(画素ごとに和 1)。
      ``thick``    (H,W) 上層の厚み X(剥落部は 0)。
      ``flake``    (H,W) bool 剥落。
      ``field``    (H,W) int 0=群青の面 / 1=アズライトの面 / 2=朱+茜の面。
    """
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float64)

    # --- 下絵(線で描く)。太さと濃さを変えて中間の alpha を必ず作る -------------
    ink = np.zeros((H, W))
    _stroke(ink, (8, 14), (72, 30), 1.6)        # 長い斜線
    _stroke(ink, (10, 46), (70, 46), 1.2)       # 縦線(細い)
    _stroke(ink, (16, 34), (16, 108), 1.0)      # 上の横線(いちばん細い)
    _stroke(ink, (64, 20), (64, 112), 1.4)      # 下の横線
    _stroke(ink, (20, 100), (66, 74), 1.8)      # 太い斜線
    _stroke(ink, (24, 62), (52, 90), 1.1)
    _arc(ink, 40.0, 60.0, 22.0, 1.5, -2.4, 0.9)  # 弧
    _arc(ink, 30.0, 92.0, 12.0, 1.2, -3.2, 3.2)  # 小円
    ink *= 0.55 + 0.45 * _sig(xx, 40.0, 26.0)   # 左ほど薄い(筆圧のむら)
    ink = np.clip(ink, 0.0, 1.0)

    # --- 上層の面(3 つの区画)。境界は縦の帯で、面の中は筆致で厚みが揺れる -------
    # 区画 2 はさらに 2 つに割る: 朱の面と、褪色する茜レーキの面。
    # 混ぜてしまうと朱の吸収が茜を覆い隠して「褪色しても何も起きない」になる
    # (最初の版がまさにそれで、f を 1 -> 0.15 に振っても ΔE00 が 0.20 -> 0.43 しか
    #  動かなかった。褪色の実験になっていなかった)。
    field = np.zeros((H, W), int)
    field[:, 40:80] = 1
    field[:, 80:] = 2
    lake = np.zeros((H, W), bool)
    lake[:, 100:] = True                                  # 区画 2 の右半分 = 茜レーキ

    conc = np.zeros((H, W, len(LAYER_KEYS)))
    idx = {k: i for i, k in enumerate(LAYER_KEYS)}
    #  区画 0: 群青 + 鉛白 / 区画 1: アズライト + 鉛白 / 区画 2: 朱 + 鉛白 と 茜 + 鉛白
    mix_lo = 0.30 + 0.25 * _gauss(yy, 40.0, 26.0)        # 白の混ぜ量が面内で変わる
    mix_lo = np.where(lake, 0.35 * mix_lo, mix_lo)       # レーキの面は白が少ない
    f0, f1, f2 = field == 0, field == 1, field == 2
    conc[..., idx["ultramarine"]] = np.where(f0, 1.0 - mix_lo, 0.0)
    conc[..., idx["azurite"]] = np.where(f1, 1.0 - mix_lo, 0.0)
    conc[..., idx["vermilion"]] = np.where(f2 & ~lake, 1.0 - mix_lo, 0.0)
    conc[..., idx["madder"]] = np.where(lake, 1.0 - mix_lo, 0.0)
    conc[..., idx["lead_white"]] = mix_lo
    conc /= conc.sum(axis=2, keepdims=True)

    # --- 厚み。筆致(斜めの縞)+ 端に向かって薄くなる -------------------------
    thick = (1.0
             + 0.35 * np.sin((xx * 0.9 + yy * 0.5) * 0.25)
             + 0.22 * np.cos(yy * 0.18))
    thick *= 0.55 + 0.45 * _sig(np.minimum(np.minimum(xx, W - 1 - xx),
                                           np.minimum(yy, H - 1 - yy)), 5.0, 3.0)
    thick = np.clip(thick, 0.10, None)

    # --- 剥落(上層が失われて地と下絵が露出する) ------------------------------
    flake = np.zeros((H, W), bool)
    for (cy, cx, ry, rx) in ((22, 22, 6, 9), (58, 55, 7, 6),
                             (34, 96, 5, 11), (68, 100, 4, 5)):
        flake |= (((yy - cy) / ry) ** 2 + ((xx - cx) / rx) ** 2) <= 1.0
    thick = np.where(flake, 0.0, thick)
    return {"ink": ink, "conc": conc, "thick": thick, "flake": flake,
            "field": field, "lake": lake}


def render_spectra(scene, tau=1.0, fade=1.0, swap=None, extra_conc=None):
    """場面 -> 画素ごとの分光反射率 (H,W,121)。

    tau    上層の厚みの全体倍率(不透明度のノブ)。
    fade   茜レーキの吸収 K に掛ける倍率。1 = 未褪色、0 に近いほど褪せる。
    swap   ("azurite", R∞配列) の形で 1 種の masstone を差し替える(似た 2 つの青の実験)。
    """
    ks = {}
    ss = {}
    for k, (r_inf, s550, _n) in PIGMENTS.items():
        r = r_inf if (swap is None or swap[0] != k) else swap[1]
        ss[k] = scat(s550)
        ks[k] = ss[k] * ks_ratio(r)
    ks["madder"] = ks["madder"] * float(fade)

    # 下地 = 白亜 + 炭素の線(面積被覆の線形混合)
    ink = scene["ink"][..., None]
    r_ground = (1.0 - ink) * PIGMENTS["chalk"][0] + ink * PIGMENTS["carbon"][0]

    conc = scene["conc"] if extra_conc is None else extra_conc
    k_mix = np.zeros((H, W, WL.size))
    s_mix = np.zeros((H, W, WL.size))
    for i, key in enumerate(LAYER_KEYS):
        c = conc[..., i:i + 1]
        k_mix += c * ks[key][None, None, :]
        s_mix += c * ss[key][None, None, :]
    s_mix = np.maximum(s_mix, 1e-6)

    thick = (scene["thick"] * float(tau))[..., None]
    out = km_layer(k_mix, s_mix, thick, r_ground)
    # 剥落部は層が無いので下地そのもの(km_layer は t->0 でそうなるが明示する)
    out = np.where(scene["flake"][..., None], r_ground, out)
    return out


def endmember_spectra(fade=1.0, swap=None):
    """上層 5 種 + 地 + 下絵の masstone を並べた (7, 121)。線形アンミキシングの端成分。

    ここでは **観測できる面の反射率** に相当する量として masstone R∞ を使う。
    fade を効かせた茜レーキは K を落として R∞ を計算し直す。
    """
    rows = []
    for key in LAYER_KEYS + ("chalk", "carbon"):
        r_inf = PIGMENTS[key][0] if (swap is None or swap[0] != key) else swap[1]
        if key == "madder" and fade != 1.0:
            ksr = ks_ratio(r_inf) * float(fade)
            r_inf = 1.0 + ksr - np.sqrt(ksr * ksr + 2.0 * ksr)
        rows.append(r_inf)
    return np.asarray(rows, float)


ENDMEMBER_NAMES = tuple(PIGMENTS[k][2] for k in LAYER_KEYS) + ("白亜(地)", "炭素黒(下絵)")
CARBON_ROW = len(LAYER_KEYS) + 1


def scene_endmembers(scene, spectra):
    """**現場から採る**端成分 —— 各材料が単独で見えている小領域の平均分光。

    masstone(無限厚の反射率)を端成分にすると、薄く透明な層(レーキの艶出し)は
    自分の masstone と似ても似つかない見え方をする。修復の現場でやるのはむしろ
    「その作品の、その材料だけの場所」を採ることなので、それを再現する。
    真値(どこが何か)を使うので **これは反則側の上限**である。
    """
    ok = (~scene["flake"]) & (scene["ink"] <= 0.02)
    rows = []
    for i, key in enumerate(LAYER_KEYS):
        m = ok & (scene["conc"][..., i] == scene["conc"].max(axis=2)) \
            & (scene["conc"][..., i] > 0.4)
        rows.append(spectra[m].mean(axis=0) if m.sum() >= 10
                    else PIGMENTS[key][0].copy())
    rows.append(spectra[scene["flake"] & (scene["ink"] <= 0.02)].mean(axis=0))
    rows.append(spectra[scene["flake"] & (scene["ink"] >= 0.9)].mean(axis=0))
    return np.asarray(rows, float)


# --------------------------------------------------------------------------- #
# 3. カメラ —— バンド化と雑音                                                    #
# --------------------------------------------------------------------------- #
def band_filters(n_bands, lo=400.0, hi=1000.0):
    """ガウス帯域のフィルタ行列 (n_bands, 121)。各行の和は 1。"""
    edge = (hi - lo) / (2.0 * n_bands)
    centers = np.linspace(lo + edge, hi - edge, n_bands)
    sigma = max((hi - lo) / n_bands, 1.0) / 2.355
    f = np.exp(-0.5 * ((WL[None, :] - centers[:, None]) / sigma) ** 2)
    f /= f.sum(axis=1, keepdims=True)
    return centers, f


#: 光量一定モデルの基準。B バンドに割ると 1 バンドあたりの光子は 1/B なので
#: 反射率換算の雑音は sqrt(B) で増える。SIGMA0 * sqrt(B) が既定。
SIGMA0 = 0.0010


def make_cube(spectra, n_bands, rng, lo=400.0, hi=1000.0, sigma=None, fixed_sigma=False):
    """分光 -> (H,W,B) のキューブ。sigma=None なら光量一定モデル。"""
    centers, f = band_filters(n_bands, lo, hi)
    cube = spectra @ f.T
    if sigma is None:
        sigma = SIGMA0 if fixed_sigma else SIGMA0 * np.sqrt(n_bands)
    if sigma > 0:
        cube = cube + rng.normal(0.0, sigma, cube.shape)
    return centers, cube


def make_rgb(spectra, rng, sigma=None):
    """分光 -> sRGB 画像 (H,W,3)。可視 400–700 nm だけを使う。"""
    lin = fs.spectrum_to_srgb(WL[VIS], spectra[..., VIS])
    if sigma is None:
        sigma = SIGMA0 * np.sqrt(3.0)
    if sigma > 0:
        lin = lin + rng.normal(0.0, sigma, lin.shape)
    return fs.linear_to_srgb(np.clip(lin, 0.0, 1.0))


# --------------------------------------------------------------------------- #
# 4. 検出器 —— 4 手法 + 追加 2 手法                                              #
# --------------------------------------------------------------------------- #
def own_pca(x, n=3):
    """自前の主成分分析。**fullseye の spec_pca は B=3 を拒否する**(色画像と
    分光キューブの型境界。設計として妥当で、既報)。しかしゼロ点はまさに
    「RGB の主成分分析」なので、ここだけは自前で持たざるを得ない。
    """
    a = np.asarray(x, float)
    hh, ww, bb = a.shape
    n = min(int(n), bb)
    flat = a.reshape(-1, bb)
    mean = flat.mean(axis=0)
    xc = flat - mean
    cov = (xc.T @ xc) / max(flat.shape[0] - 1, 1)
    ev, evec = np.linalg.eigh(cov)
    order = np.argsort(ev)[::-1]
    comps = evec[:, order[:n]].T
    return (xc @ comps.T).reshape(hh, ww, n), comps, ev[order[:n]] / max(ev.sum(), 1e-30)


def best_pc_detector(scores, pos, neg, first=1):
    """PC1 以外の各成分を +/- 両符号で試し、**真値を見て AUC 最大**を返す。

    これは検出器に下駄を履かせている(実運用では符号も成分も選べない)。
    ゼロ点である RGB PCA を不当に弱く見せないため、全 PCA 系に同じ下駄を履かせる。
    """
    best, best_auc = None, -1.0
    for j in range(first, scores.shape[2]):
        for sgn in (1.0, -1.0):
            d = sgn * scores[..., j]
            a = auc(d[pos], d[neg])
            if a > best_auc:
                best, best_auc = d, a
    return best, best_auc


def nir_difference(centers, cube):
    """近赤外の単純差分。可視の赤帯 - 近赤外帯。炭素は近赤外でも暗いので正に振れる。"""
    vis = (centers >= 600.0) & (centers <= 700.0)
    nir = (centers >= NIR_LO) & (centers <= NIR_HI)
    if not vis.any() or not nir.any():
        return None
    return cube[..., vis].mean(axis=2) - cube[..., nir].mean(axis=2)


def unmix_carbon(cube, endm_bands, constrained=True):
    """線形アンミキシングの炭素黒の存在量マップ。"""
    return fs.spec_unmix(cube, endm_bands, constrained=constrained)


def ks_transform(cube):
    """反射率 -> K/S。単一定数 Kubelka–Munk では **K/S が線形に混ざる**ので、
    反射率のまま混ぜる線形アンミキシングより素直になるはず、という仮説の検証用。
    """
    r = np.clip(cube, 1e-3, 1.0)
    return (1.0 - r) ** 2 / (2.0 * r)


# --------------------------------------------------------------------------- #
# 5. 評価 —— ROC / 適合率・再現率 / 偏りと散らばり                                #
# --------------------------------------------------------------------------- #
def auc(pos, neg):
    """Mann–Whitney U による AUC(同値は 0.5 として扱う)。"""
    from scipy.stats import rankdata
    if pos.size == 0 or neg.size == 0:
        return float("nan")
    allv = np.concatenate([pos, neg])
    r = rankdata(allv)
    return float((r[:pos.size].sum() - pos.size * (pos.size + 1) / 2.0)
                 / (pos.size * neg.size))


def thresh_at_fpr(neg, fpr):
    """偽陽性率が fpr **以下**になる中でいちばん緩い閾値を返す(判定は ``> thr``)。

    分位点をそのまま閾値にして ``>=`` で数えると、**同値が大量にある検出器**
    (アンミキシングの存在量は負例のほとんどが厳密に 0)で偽陽性率が跳ね上がる。
    実際この PoC の最初の版では線形アンミキシングが「再現率 1.000 / 適合率 0.095」
    という、動作点が存在しないだけの数字を出した。到達できない動作点は
    「到達できなかった」と書けるようにする。
    """
    s = np.sort(np.asarray(neg, float))[::-1]
    k = int(np.floor(fpr * s.size))
    if k <= 0:
        return float(s[0])                     # 負例の最大値。これを超えた分だけ拾う
    if k >= s.size:
        return -np.inf
    return float(s[k])


def pr_at(det, pos_mask, neg_mask, thr):
    """閾値 thr での (再現率, 適合率, 実際の偽陽性率)。判定は厳密に ``> thr``。"""
    hit = det > thr
    tp = int((hit & pos_mask).sum())
    fp = int((hit & neg_mask).sum())
    npos, nneg = int(pos_mask.sum()), int(neg_mask.sum())
    rec = tp / npos if npos else float("nan")
    prec = tp / (tp + fp) if (tp + fp) else float("nan")
    return rec, prec, (fp / nneg if nneg else float("nan"))


def recall_at(det, pos_mask, neg_mask, fpr):
    """その領域だけで閾値を引き直したときの再現率(領域ごとの素の感度)。"""
    if pos_mask.sum() == 0 or neg_mask.sum() == 0:
        return float("nan")
    return pr_at(det, pos_mask, neg_mask, thresh_at_fpr(det[neg_mask], fpr))[0]


def bias_scatter(err):
    """偏り(平均誤差)と散らばり(標準偏差)を分ける。"""
    return float(np.mean(err)), float(np.std(err))


def delta_e(rgb_a, rgb_b):
    return fs.delta_e_map(np.clip(rgb_a, 0.0, 1.0), np.clip(rgb_b, 0.0, 1.0))


#: 既定の上層の厚み倍率。0.6 = 薄めに塗られた層(可視でもわずかに下絵が漏れる)。
TAU0 = 0.6
#: 既定のバンド数(400–1000 nm)。
NB0 = 16


def unmix_any(cube, endm_bands, constrained=True):
    """``fs.spec_unmix`` を呼ぶ。ただし **B=3 は op が拒否する**ので自前に落ちる。

    拒否は「(H,W,3) は色画像であって分光キューブではない」という型境界であり、
    RGB を黙って食わないための設計としては正しい。だが 3 バンドの多波長カメラ
    (可視 / レッドエッジ / 近赤外)は実在する構成で、それも同じ扱いで落ちる。
    バンド数の頭打ちを測るには 3 が要るので、ここだけ自前で解く。
    """
    if np.asarray(cube).shape[2] != 3:
        return fs.spec_unmix(cube, endm_bands, constrained=constrained)
    from scipy.optimize import nnls
    hh, ww, bb = cube.shape
    E = np.asarray(endm_bands, float)
    K = E.shape[0]
    if not constrained:
        return (cube.reshape(-1, bb) @ np.linalg.pinv(E)).reshape(hh, ww, K)
    delta = 1e3
    M = np.vstack([E.T, delta * np.ones((1, K))])
    P = cube.reshape(-1, bb)
    A = np.zeros((P.shape[0], K))
    y = np.empty(bb + 1)
    y[bb] = delta
    for i in range(P.shape[0]):
        y[:bb] = P[i]
        A[i], _ = nnls(M, y)
    return A.reshape(hh, ww, K)


def detectors(scene, spectra, rng, n_bands=NB0, sigma=None, fixed_sigma=False,
              endm_full=None,
              want=("rgb", "vis", "ms", "mnf", "unmix", "ks", "nir", "sam")):
    """全手法の検出マップを作って dict で返す。値が大きいほど「下絵あり」。"""
    out = {}
    if "rgb" in want:
        rgb = make_rgb(spectra, rng, sigma=(sigma if sigma is not None
                                            else SIGMA0 * np.sqrt(3.0)))
        out["_rgb"] = rgb
        out["rgb"] = own_pca(rgb, 3)[0]                      # 成分選択は後段
    if "vis" in want:
        _, cv = make_cube(spectra, n_bands, rng, lo=400.0, hi=700.0,
                          sigma=sigma, fixed_sigma=fixed_sigma)
        out["vis"] = (own_pca(cv, 4)[0] if n_bands == 3
                      else fs.spec_pca(cv, 4)[0])
    centers, cube = make_cube(spectra, n_bands, rng, sigma=sigma, fixed_sigma=fixed_sigma)
    out["_cube"] = cube
    out["_centers"] = centers
    if "ms" in want:
        out["ms"] = (own_pca(cube, 4)[0] if n_bands == 3 else fs.spec_pca(cube, 4)[0])
    if "mnf" in want and n_bands > 3:
        out["mnf"] = fs.spec_mnf(cube, 4)[0]
    _, filt = band_filters(n_bands)
    Eb = (endm_full if endm_full is not None else endmember_spectra()) @ filt.T
    if "unmix" in want:
        A = unmix_any(cube, Eb)
        out["_abund"] = A
        out["unmix"] = A[..., CARBON_ROW]
    if "ks" in want:
        A2 = unmix_any(ks_transform(cube), ks_transform(Eb))
        out["_abund_ks"] = A2
        out["ks"] = A2[..., CARBON_ROW]
    if "nir" in want:
        d = nir_difference(centers, cube)
        if d is not None:
            out["nir"] = d
        nb = (centers >= NIR_LO) & (centers <= NIR_HI)
        if nb.any():
            out["nirb"] = -cube[..., nb].mean(axis=2)      # 近赤外 1 枚(暗い所を拾う)
    if "sam" in want:
        out["sam"] = -fs.spec_angle_mapper(cube, Eb[CARBON_ROW])
    return out


METHODS = (
    ("rgb",   "RGB の PCA(ゼロ点)", True),
    ("vis",   "可視のみ多波長 PCA", True),
    ("ms",    "可視+近赤外 PCA", True),
    ("mnf",   "可視+近赤外 MNF", True),
    ("unmix", "線形アンミキシング", False),
    ("ks",    "K/S アンミキシング", False),
    ("nir",   "近赤外の単純差分", False),
    ("nirb",  "近赤外 1 枚(反転)", False),
    ("sam",   "分光角マッパ", False),
)


def score_maps(det, pos, neg):
    """PCA 系は成分と符号を真値で選ぶ(下駄)。他はそのまま。"""
    maps = {}
    for key, _name, is_pca in METHODS:
        if key not in det:
            continue
        maps[key] = best_pc_detector(det[key], pos, neg)[0] if is_pca else det[key]
    return maps


def main():
    t_all = time.perf_counter()
    rng = np.random.default_rng(SEED)
    scene = build_scene()
    ink, flake, field = scene["ink"], scene["flake"], scene["field"]

    # 評価マスク。中間の被覆率(0.02 < alpha < 0.6)は「どちらとも言えない」ので外す。
    pos_all = ink >= 0.6
    neg_all = ink <= 0.02
    pos, neg = pos_all & ~flake, neg_all & ~flake
    field_names = ("群青の面", "アズライトの面", "朱+茜の面")

    # ---------------------------------------------------------------- 1 -----
    print("\n1. 場面 —— 何を作って、何を真値として握っているか")
    print(f"   画素 {H}x{W} / 分光 {WL[0]:.0f}–{WL[-1]:.0f} nm を {WL.size} 点")
    print("   層: 白亜の地 → 炭素黒の線で下絵 → 上層(区画ごとに顔料が違う)、一部剥落")
    rows = [
        ["下絵の線 (alpha>=0.6)", str(int(pos_all.sum())), "%.1f %%" % (100 * pos_all.mean())],
        ["中間の縁 (0.02<alpha<0.6)", str(int(((ink > 0.02) & (ink < 0.6)).sum())),
         "%.1f %%" % (100 * ((ink > 0.02) & (ink < 0.6)).mean())],
        ["下絵なし (alpha<=0.02)", str(int(neg_all.sum())), "%.1f %%" % (100 * neg_all.mean())],
        ["剥落部", str(int(flake.sum())), "%.1f %%" % (100 * flake.mean())],
        ["剥落部のうち線", str(int((pos_all & flake).sum())), "—"],
    ]
    for f in range(3):
        rows.append(["区画 %d: %s" % (f, field_names[f]), str(int((field == f).sum())),
                     "%.1f %%" % (100 * (field == f).mean())])
    rows.append(["  うち茜レーキの面(褪色する)", str(int(scene["lake"].sum())),
                 "%.1f %%" % (100 * scene["lake"].mean())])
    _table(["真値の内訳", "画素数", "割合"], rows)

    # ---------------------------------------------------------------- 2 -----
    print("\n2. 物理の確認 —— Kubelka–Munk が両端で正しく振る舞うか")
    lim_rows = []
    for key in LAYER_KEYS:
        r_inf, s550, name = PIGMENTS[key]
        S = scat(s550)
        K = S * ks_ratio(r_inf)
        rg = np.full_like(S, 0.5)
        e_thick = float(np.abs(km_layer(K, S, 30.0, rg) - r_inf).max())
        e_thin = float(np.abs(km_layer(K, S, 1e-9, rg) - 0.5).max())
        lim_rows.append([name, "%.3f" % r_inf[WL == 550][0], "%.1f" % s550,
                         "%.1e" % e_thick, "%.1e" % e_thin])
    _table(["顔料", "R∞(550nm)", "散乱能 S550", "厚→∞ の誤差", "厚→0 の誤差"], lim_rows)

    # 下絵そのものの信号(インクを消した同じ場面との差)。手法の話の前に物理を見る。
    scene_noink = dict(scene, ink=np.zeros_like(ink))
    sig_rows = []
    for tau in (0.3, TAU0, 1.0, 2.0):
        d = render_spectra(scene, tau=tau) - render_spectra(scene_noink, tau=tau)
        row = ["%.1f" % tau]
        for f in range(3):
            fm = pos & (field == f)
            row.append("%+.4f" % d[..., WL == 450][..., 0][fm].mean())
            row.append("%+.4f" % d[..., WL == 950][..., 0][fm].mean())
        sig_rows.append(row)
    _table(["厚み倍率 tau",
            "群青 450nm", "群青 950nm",
            "アズ 450nm", "アズ 950nm",
            "朱茜 450nm", "朱茜 950nm"], sig_rows)
    print("   線のところの反射率が、下絵を消した場合と比べてどれだけ下がるか。")
    print("   アズライトは近赤外でも吸収が残るので、下絵の信号がほぼ出ない(後で効く)。")

    print(f"\n   以降の既定: 厚み倍率 tau={TAU0} / バンド数 {NB0}(400–1000 nm) /")
    print(f"   雑音は光量一定モデル sigma = {SIGMA0} * sqrt(B) = "
          f"{SIGMA0 * np.sqrt(NB0):.4f}(RGB は sqrt(3) で {SIGMA0 * np.sqrt(3):.4f})")

    # ---------------------------------------------------------------- 3 -----
    print("\n3. 下絵の検出 —— 適合率と再現率を別々に、面ごとに分けて")
    spec0 = render_spectra(scene, tau=TAU0)
    det0 = detectors(scene, spec0, np.random.default_rng(SEED + 1))
    maps0 = score_maps(det0, pos, neg)

    rows = []
    detect_summary = {}
    for key, name, _p in METHODS:
        if key not in maps0:
            continue
        d = maps0[key]
        a = auc(d[pos], d[neg])
        t1 = thresh_at_fpr(d[neg], 0.01)
        t5 = thresh_at_fpr(d[neg], 0.05)
        r1, p1, f1 = pr_at(d, pos, neg, t1)
        r5, p5, f5 = pr_at(d, pos, neg, t5)
        per = [recall_at(d, pos & (field == f), neg & (field == f), 0.01) for f in range(3)]
        rf = recall_at(d, pos_all & flake, neg_all & flake, 0.01)
        aper = [auc(d[pos & (field == f)], d[neg & (field == f)]) for f in range(3)]
        detect_summary[key] = (a, r1, p1, per, rf, aper, f1)
        rows.append([name, "%.3f" % a, "%.4f" % f1, "%.3f" % r1, "%.3f" % p1,
                     "%.3f" % r5, "%.3f" % p5])
    _table(["手法", "AUC", "実FPR", "再現率@FPR1%", "適合率@FPR1%",
            "再現率@FPR5%", "適合率@FPR5%"], rows)
    print("   閾値は「下絵なしの画素の 1 %(5 %)だけが超える」ところに全体で 1 本。")
    print("   実FPR = その閾値で実際に超えた負例の割合。同値が多い検出器は 1 % に")
    print("   届かない(存在量は負例の大半が厳密に 0 なので、動作点自体が飛び飛び)。")
    print("   PCA の 3 手法は **真値を見て**成分と符号を選んでいる(ゼロ点に下駄を履かせた)。")

    rows = []
    for key, name, _p in METHODS:
        if key not in detect_summary:
            continue
        a, r1, p1, per, rf, aper, _f = detect_summary[key]
        rows.append([name] + ["%.3f" % v for v in aper]
                    + ["%.3f" % v for v in per] + ["%.3f" % rf])
    _table(["手法(面ごとに閾値を引き直す)", "AUC群青", "AUCアズ", "AUC朱茜",
            "再現群青", "再現アズ", "再現朱茜", "再現剥落"], rows)
    print("   上の表と違い、ここは **面ごとに閾値を引き直した**。信号があるかどうかと、")
    print("   全体で 1 本の閾値が引けるかどうかは別の問いだから分ける。")
    # ★「1 つの数字にまとめない」の根拠そのもの。同じ行の中で 1.000 と 0.013 が並ぶ。
    figs.save_table(
        "per_field_auc",
        ["手法", "全体 AUC", "群青 AUC", "アズ AUC", "朱茜 AUC", "剥落 再現率"],
        [[name, "%.3f" % detect_summary[key][0]]
         + ["%.3f" % v for v in detect_summary[key][5]]
         + ["%.3f" % detect_summary[key][4]]
         for key, name, _p in METHODS if key in detect_summary],
        col_w=150,
        title="同じ検出器が、面によって 1.000 にも 0.013 にもなる",
        caption="平均すると全部消える。近赤外の差分は剥落部で盲目、"
                "近赤外 1 枚は面ごとには完璧でも全体では 1 本引けない。")

    # ゼロ点をもう一段強くしてみる: 面ごとに主成分分析ごとやり直す。
    # 弱いゼロ点に勝っても意味がないので、勝てる可能性のある形まで持ち上げる。
    zero_strong = []
    for f in range(3):
        m = field == f
        sc_, _c, _v = own_pca(det0["_rgb"][m].reshape(1, -1, 3), 3)
        pf, nf = pos[m], neg[m]
        d = np.zeros(m.sum())
        best = -1.0
        for j in (1, 2):
            for sgn in (1.0, -1.0):
                cand = sgn * sc_[0, :, j]
                a = auc(cand[pf], cand[nf])
                if a > best:
                    best, d = a, cand
        zero_strong.append((best, pr_at(d, pf, nf, thresh_at_fpr(d[nf], 0.01))[0]))
    # MNF が PCA に負けた理由を推測で済ませない。spec_mnf は雑音共分散を
    # 「横隣との差」から見積もるが、下絵は 1–2 画素幅の線なので、その差にいちばん
    # 効いているのは下絵そのもの。つまり **本命の信号を雑音として白色化している**。
    cube0 = det0["_cube"]
    dh = np.diff(cube0, axis=1) * 0.5
    on_line = (ink[:, :-1] >= 0.6) | (ink[:, 1:] >= 0.6)
    e_line = float((dh[on_line] ** 2).mean())
    e_off = float((dh[~on_line] ** 2).mean())
    print("   MNF が使う横差分のエネルギー: 下絵の上 %.3e / それ以外 %.3e = %.1f 倍。"
          % (e_line, e_off, e_line / max(e_off, 1e-30)))
    print("   spec_mnf の雑音推定は横差分なので、細い線は雑音として白色化されてしまう。")
    print("   ゼロ点をさらに強くする(面ごとに主成分分析からやり直す): "
          + " / ".join("%s AUC %.3f 再現率 %.3f" % (field_names[f], zero_strong[f][0],
                                                    zero_strong[f][1]) for f in range(3)))
    # 「面ごとに得意不得意が入れ替わる」は表の 1 行では読めない。地図で並べると、
    # どの検出器がどの区画で立っているかがそのまま見える(左 40 列 = 群青、
    # 中 40 列 = アズライト、右 40 列 = 朱+茜。楕円の 4 つが剥落部)。
    figs.save_grid("detector_maps",
                   [_zoom(ink), _zoom(det0["_rgb"]),
                    _zoom(_clip_pct(maps0["rgb"])), _zoom(_clip_pct(maps0["nir"])),
                    _zoom(_clip_pct(maps0["nirb"])), _zoom(_clip_pct(maps0["unmix"]))],
                   ["真値 下絵 alpha", "可視 RGB", "RGB PCA(ゼロ点)",
                    "近赤外の差分", "近赤外 1 枚", "線形アンミキシング"],
                   ncols=3, title="同じ 1 枚に対する検出マップ(明るいほど下絵)",
                   caption="近赤外の差分は剥落部(楕円)で消え、近赤外 1 枚は面ごとに"
                           "水準が違う。塗り分けは 1–99 分位でクリップした表示のみ。")

    # ---------------------------------------------------------------- 4 -----
    print("\n4. 崖 (a) —— 上層の光学的厚み。下絵はどこで見えなくなるか")
    taus = (0.15, 0.3, 0.6, 1.0, 1.6, 2.5)
    rows_a = []
    cliff_a = {}
    for tau in taus:
        sp = render_spectra(scene, tau=tau)
        dt = detectors(scene, sp, np.random.default_rng(SEED + 2),
                       want=("rgb", "ms", "unmix", "nir"))
        mp = score_maps(dt, pos, neg)
        row = ["%.2f" % tau]
        cliff_a[tau] = {}
        for key in ("rgb", "ms", "unmix", "nir"):
            d = mp[key]
            r1 = pr_at(d, pos, neg, thresh_at_fpr(d[neg], 0.01))[0]
            r1b = recall_at(d, pos & (field == 1), neg & (field == 1), 0.01)
            cliff_a[tau][key] = (r1, r1b)
            row += ["%.3f" % r1, "%.3f" % r1b]
        rows_a.append(row)
    _table(["tau", "RGB全体", "RGBアズ", "多波長全体", "多波長アズ",
            "アンミ全体", "アンミアズ", "NIR全体", "NIRアズ"], rows_a)
    print("   「全体」= 全体で 1 本の閾値 / 「アズ」= アズライトの面だけで引き直した閾値。")
    print("   平均の厚み(剥落部を除く)= tau x %.3f。" % scene["thick"][~flake].mean())
    # 崖の位置が **同じ絵の中で 4 倍違う**。近赤外の 2 本(全体とアズライト)を
    # 並べると、そこが線の離れ方として出る。
    _t = np.asarray(taus, float)
    figs.save_plot("thickness_cliff",
                   [("近赤外 差分(全体)", _t, np.array([cliff_a[t]["nir"][0] for t in taus])),
                    ("近赤外 差分(アズ)", _t, np.array([cliff_a[t]["nir"][1] for t in taus])),
                    ("多波長 PCA(全体)", _t, np.array([cliff_a[t]["ms"][0] for t in taus])),
                    ("RGB PCA(全体)", _t, np.array([cliff_a[t]["rgb"][0] for t in taus]))],
                   xlabel="上層の厚み倍率 tau", ylabel="再現率 @ FPR 1 %",
                   title="下絵が見えなくなる厚み",
                   caption="半分を割るのは tau 0.30–0.60 のあいだ。アズライトの面だけ"
                           "見ると崖はもっと手前にある —— 同じ絵の中で位置が 4 倍違う。")

    # ---------------------------------------------------------------- 5 -----
    print("\n5. 崖 (b) —— バンド数。増やすほど良い、とは限らない")
    print("   光量は有限なので、同じ帯域を B 本に割ると 1 本あたりの光子は 1/B、")
    print("   反射率換算の雑音は sqrt(B) 倍になる。3 つの前提で並べる:")
    print("     [十分光量] sigma = %.4f * sqrt(B)" % SIGMA0)
    print("     [低照度]   sigma = %.4f * sqrt(B)(露光を 225 分の 1 に切り詰めた場合)"
          % (SIGMA0 * 15))
    print("     [雑音固定] sigma = %.4f(バンドを増やしても増えない、都合のよい仮定)"
          % (SIGMA0 * np.sqrt(NB0)))
    rows_b = []
    cliff_b = {}
    panels = (("十分光量", None, 1.0), ("低照度", None, 15.0),
              ("雑音固定", SIGMA0 * np.sqrt(NB0), 1.0))
    for nb in (3, 8, 16, 31):
        row = [str(nb)]
        cliff_b[nb] = {}
        for tag, sg, dim in panels:
            sigma = sg if sg is not None else SIGMA0 * dim * np.sqrt(nb)
            dt = detectors(scene, spec0, np.random.default_rng(SEED + 3), n_bands=nb,
                           sigma=sigma, want=("ms", "unmix", "nir"))
            mp = score_maps(dt, pos, neg)
            au = auc(mp["unmix"][pos], mp["unmix"][neg])
            rn = pr_at(mp["nir"], pos, neg, thresh_at_fpr(mp["nir"][neg], 0.01))[0]
            # 存在量の散らばり。群青を見る(アズライトは推定が単体の頂点に張り付いて
            # しまい、雑音にもバンド数にも反応しないので指標にならない)。
            lay = dt["_abund"][..., :len(LAYER_KEYS)]
            lay = lay / np.maximum(lay.sum(axis=2, keepdims=True), 1e-12)
            iu = LAYER_KEYS.index("ultramarine")
            m0 = (field == 0) & ~flake & neg_all
            sc_ = bias_scatter(lay[..., iu][m0] - scene["conc"][..., iu][m0])[1]
            cliff_b[nb][tag] = (au, rn, sc_)
            row += ["%.3f" % au, "%.3f" % rn, "%.4f" % sc_]
        rows_b.append(row)
    _table(["バンド数",
            "光:アンミAUC", "光:NIR再現率", "光:群青散らばり",
            "暗:アンミAUC", "暗:NIR再現率", "暗:群青散らばり",
            "固:アンミAUC", "固:NIR再現率", "固:群青散らばり"], rows_b)
    print("   B=3 は fs.spec_unmix / fs.spec_pca が (H,W,3) を拒否するので自前で解いた。")
    print("   拒否は「色画像を分光キューブと取り違えない」ための型境界で設計としては")
    print("   正しいが、可視 / レッドエッジ / 近赤外の 3 バンド機は実在する構成であり、")
    print("   バンド数の頭打ちを測る実験ではその 3 が要る。")

    # ---------------------------------------------------------------- 6 -----
    print("\n6. 崖 (c) —— 似た 2 つの青。どこまで似ると分けられなくなるか")
    print("   ここだけは **層を挟まない**。層(Kubelka–Munk)の非線形を混ぜると、")
    print("   アンミキシングの偏りが飽和して青の似方に反応しなくなる(最初の版が")
    print("   まさにそれで、相関 -0.11 でも 0.9997 でも偏りが +0.474 で一定だった)。")
    print("   線形混合モデルが成り立つ土俵でだけ「分光の似方」の崖を測る。")
    az = PIGMENTS["azurite"][0]
    ul = PIGMENTS["ultramarine"][0]
    _, filt16 = band_filters(NB0)
    # 真値: 2 つの青の配合比を空間的に構造をもって振る(乱数の面にしない)
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float64)
    frac = np.clip(0.5 + 0.45 * np.sin(xx * 0.11) * np.cos(yy * 0.07)
                   + 0.15 * (yy / (H - 1) - 0.5), 0.02, 0.98)
    wfrac = 0.25 + 0.15 * np.cos(xx * 0.05)               # 鉛白の混ぜ量
    lw = PIGMENTS["lead_white"][0]
    rows_c = []
    cliff_c = []
    rng_c = np.random.default_rng(SEED + 4)
    for s in (1.0, 0.5, 0.25, 0.12, 0.06, 0.03, 0.015):
        blue2 = np.clip(az + s * (ul - az), 0.02, 0.95)
        Eb = np.vstack([az, blue2, lw]) @ filt16.T
        r = float(np.corrcoef(Eb[0], Eb[1])[0, 1])
        mix = ((1.0 - wfrac) * frac)[..., None] * Eb[0] \
            + ((1.0 - wfrac) * (1.0 - frac))[..., None] * Eb[1] \
            + wfrac[..., None] * Eb[2]
        cube = mix + rng_c.normal(0.0, SIGMA0 * np.sqrt(NB0), mix.shape)
        A = fs.spec_unmix(cube, Eb)
        est = A[..., 0] / np.maximum(A[..., 0] + A[..., 1], 1e-12)
        b, sc_ = bias_scatter(est - frac)
        worst = float(np.abs(est - frac).max())
        cliff_c.append((r, b, sc_, worst))
        rows_c.append(["%.5f" % r, "%+.4f" % b, "%.4f" % sc_, "%.3f" % worst,
                       "可" if sc_ < 0.10 else "不可"])
    _table(["2 青の相関 r", "配合比の偏り", "配合比の散らばり", "最悪誤差", "分離"],
           rows_c)
    print("   偏り = 平均誤差、散らばり = 誤差の標準偏差。1 つの RMSE に丸めない。")
    print("   「分離 可」= 散らばりが 0.10 未満(配合比を 1 割の精度で言える)。")

    # ---------------------------------------------------------------- 7 -----
    print("\n7. 崖 (d) —— 褪色。端成分を未褪色のまま使うとどれだけ外れるか")
    truth_rgb = make_rgb(render_spectra(scene, tau=TAU0, fade=1.0),
                         np.random.default_rng(SEED + 9), sigma=0.0)
    E_unfaded = endmember_spectra(fade=1.0)
    im = LAYER_KEYS.index("madder")
    f2 = scene["lake"] & ~flake & neg_all
    rows_d = []
    cliff_d = {}
    for fade in (1.0, 0.7, 0.5, 0.3, 0.15):
        sp = render_spectra(scene, tau=TAU0, fade=fade)
        obs_rgb = make_rgb(sp, np.random.default_rng(SEED + 5))
        _, cube = make_cube(sp, NB0, np.random.default_rng(SEED + 5))
        de_null = float(np.median(delta_e(obs_rgb, truth_rgb)[f2]))
        row = ["%.2f" % fade, "%.2f" % de_null]
        cliff_d[fade] = {"null": de_null}
        for tag, E, in_ks in (("固定", E_unfaded, False),
                              ("追従", endmember_spectra(fade=fade), False),
                              ("KS固定", E_unfaded, True),
                              ("現場", scene_endmembers(scene, sp), False)):
            Eb = E @ filt16.T
            A = unmix_any(ks_transform(cube), ks_transform(Eb)) if in_ks \
                else unmix_any(cube, Eb)
            lay = A[..., :len(LAYER_KEYS)]
            lay = lay / np.maximum(lay.sum(axis=2, keepdims=True), 1e-12)
            b, s = bias_scatter(lay[..., im][f2] - scene["conc"][..., im][f2])
            # 未褪色の端成分で組み直して描き直す = 退色前の色の復元。
            # 現場端成分は褪色後の見え方そのものなので、茜の行だけ未褪色に差し替える。
            base = E_unfaded if tag != "現場" else np.vstack(
                [E[:im], E_unfaded[im:im + 1], E[im + 1:]])
            if in_ks:
                rec_ks = np.tensordot(A, ks_transform(base), axes=([2], [0]))
                rec = 1.0 + rec_ks - np.sqrt(rec_ks * rec_ks + 2.0 * rec_ks)
            else:
                rec = np.tensordot(A, base, axes=([2], [0]))
            rec_rgb = make_rgb(rec, np.random.default_rng(SEED + 6), sigma=0.0)
            de = float(np.median(delta_e(rec_rgb, truth_rgb)[f2]))
            cliff_d[fade][tag] = (b, s, de)
            row += ["%+.3f" % b, "%.2f" % de]
        rows_d.append(row)
    _table(["褪色 f", "何もしない ΔE00",
            "固定:茜の偏り", "固定:復元 ΔE00",
            "追従:茜の偏り", "追従:復元 ΔE00",
            "KS固定:偏り", "KS固定:復元 ΔE00",
            "現場:偏り", "現場:復元 ΔE00"], rows_d)
    print("   f = 茜レーキの吸収 K に掛ける倍率。1 = 未褪色。ΔE00 はレーキの面の中央値。")
    print("   「固定」= 端成分を未褪色の masstone のまま / 「追従」= 褪色後の masstone を")
    print("   渡す(真値を使う反則)/ 「KS固定」= K/S 空間で解いて K/S 空間で組み直す /")
    print("   「現場」= 褪色後の画面から材料ごとに採った端成分(これも真値を使う反則)。")
    print("   ゼロ点は「何もしない」列。**それを下回れない復元は復元ではない**。")
    # ★勝てなかったことを図でも残す。ゼロ点の線より下に来ている復元が 1 本も無い。
    _f = np.array([1.0, 0.7, 0.5, 0.3, 0.15])
    figs.save_plot("restoration_vs_null",
                   [("何もしない(ゼロ点)", _f, np.array([cliff_d[v]["null"] for v in _f])),
                    ("端成分 固定", _f, np.array([cliff_d[v]["固定"][2] for v in _f])),
                    ("K/S 固定", _f, np.array([cliff_d[v]["KS固定"][2] for v in _f])),
                    ("現場端成分", _f, np.array([cliff_d[v]["現場"][2] for v in _f]))],
                   xlabel="褪色 f(1 = 未褪色)", ylabel="復元後の ΔE00(中央値)",
                   title="褪色前の色の復元はゼロ点に勝てなかった",
                   caption="ゼロ点の線より下に来た復元が 1 本も無い。f=1(褪色なし)"
                           "ですら、分解して組み直すだけで ΔE00 が 2.7–3.3 乗る。")

    # 分光 -> ΔE の道に踏み台がある。spectrum_to_srgb は **線形** sRGB を返し、
    # delta_e_map / rgb_to_lab は **ガンマ後の** sRGB を期待する。間を linear_to_srgb で
    # 繋がないと例外は出ず、ΔE00 だけが静かにずれる。どれだけずれるかを測っておく。
    sp_f = render_spectra(scene, tau=TAU0, fade=0.30)
    lin_a = np.clip(fs.spectrum_to_srgb(WL[VIS], render_spectra(scene, tau=TAU0)[..., VIS]),
                    0.0, 1.0)
    lin_b = np.clip(fs.spectrum_to_srgb(WL[VIS], sp_f[..., VIS]), 0.0, 1.0)
    de_raw = float(np.median(fs.delta_e_map(lin_a, lin_b)[f2]))
    de_ok = float(np.median(fs.delta_e_map(fs.linear_to_srgb(lin_a),
                                           fs.linear_to_srgb(lin_b))[f2]))
    print("   ついでの落とし穴: 線形 sRGB のまま delta_e_map に渡すと ΔE00 %.2f、"
          % de_raw)
    print("   linear_to_srgb を挟むと %.2f。%.0f %% ずれる(この場面では過大に出る)。"
          % (de_ok, 100 * abs(de_raw - de_ok) / de_ok))
    print("   例外は出ないので気づけない。ΔE を色差として引用するなら致命的な差。")
    gamma_trap = (de_raw, de_ok)

    # ---------------------------------------------------------------- 8 -----
    print("\n8. 崖 (e) —— 雑音")
    rows_e = []
    cliff_e = {}
    for sg in (0.0, 0.001, 0.004, 0.01, 0.03, 0.1):
        dt = detectors(scene, spec0, np.random.default_rng(SEED + 7), sigma=sg,
                       want=("rgb", "ms", "unmix", "nir"))
        mp = score_maps(dt, pos, neg)
        row = ["%.3f" % sg]
        cliff_e[sg] = {}
        for key in ("rgb", "ms", "unmix", "nir"):
            d = mp[key]
            r1 = pr_at(d, pos, neg, thresh_at_fpr(d[neg], 0.01))[0]
            cliff_e[sg][key] = r1
            row.append("%.3f" % r1)
        lay = dt["_abund"][..., :len(LAYER_KEYS)]
        lay = lay / np.maximum(lay.sum(axis=2, keepdims=True), 1e-12)
        iu = LAYER_KEYS.index("ultramarine")
        m0 = (field == 0) & ~flake & neg_all
        bu, su = bias_scatter(lay[..., iu][m0] - scene["conc"][..., iu][m0])
        cliff_e[sg]["scatter"] = su
        row += ["%+.3f" % bu, "%.4f" % su]
        rows_e.append(row)
    _table(["雑音 sigma", "RGB PCA", "多波長 PCA", "アンミックス", "NIR 差分",
            "群青の偏り", "群青の散らばり"], rows_e)
    print("   検出の再現率は同値のせいで鈍い。存在量の散らばりのほうが雑音に素直。")

    # ---------------------------------------------------------------- 9 -----
    print("\n9. 顔料の存在量 —— 偏りと散らばりを分ける(既定条件)")
    painted = ~flake & neg_all
    E_scene = scene_endmembers(scene, spec0)
    A_scene = unmix_any(det0["_cube"], E_scene @ filt16.T)
    rows_f = []
    ab_summary = {}
    for tag, A in (("masstone / R", det0["_abund"]),
                   ("masstone / K,S", det0["_abund_ks"]),
                   ("現場採取 / R", A_scene)):
        lay = A[..., :len(LAYER_KEYS)]
        lay = lay / np.maximum(lay.sum(axis=2, keepdims=True), 1e-12)
        for i, key in enumerate(LAYER_KEYS):
            fm = painted & (scene["conc"][..., i] > 0.02)
            if fm.sum() < 20:
                continue
            b, s = bias_scatter(lay[..., i][fm] - scene["conc"][..., i][fm])
            ab_summary[(tag, key)] = (b, s)
            rows_f.append([tag, PIGMENTS[key][2], str(int(fm.sum())),
                           "%.3f" % scene["conc"][..., i][fm].mean(),
                           "%+.3f" % b, "%.3f" % s])
    _table(["端成分 / 解く空間", "顔料", "対象画素", "真の平均濃度", "偏り", "散らばり"],
           rows_f)
    print("   真値は上層の顔料濃度(和 1)。推定は 7 端成分のうち上層 5 種を和 1 に正規化。")
    print("   線形混合モデルは層構造(Kubelka–Munk)を知らないので、偏りは残って当然。")
    print("   見るべきは **偏りと散らばりのどちらが大きいか** —— 偏りなら補正できる。")
    print("   「現場採取」は真値(どこが何か)を使って採っている **反則側の上限**。")

    print("\n   どこを何と取り違えたか(いちばん大きい存在量の材料。単位 %)")
    rows_g = []
    for tag, A in (("masstone / R", det0["_abund"]), ("現場採取 / R", A_scene)):
        for i, key in enumerate(LAYER_KEYS):
            fm = painted & (scene["conc"][..., i] > 0.4) \
                & (scene["conc"][..., i] == scene["conc"].max(axis=2))
            if fm.sum() < 20:
                continue
            win = np.argmax(A[fm], axis=1)
            share = np.bincount(win, minlength=A.shape[2]) / win.size * 100.0
            top = np.argsort(share)[::-1][:2]
            rows_g.append([tag, PIGMENTS[key][2], str(int(fm.sum()))]
                          + ["%s %.0f%%" % (ENDMEMBER_NAMES[t], share[t]) for t in top])
    _table(["端成分", "真の主材料", "画素数", "1 位", "2 位"], rows_g)

    # --------------------------------------------------------------- 10 -----
    print("\n10. まとめ —— 何が効いて、何が効かなかったか")
    zero = detect_summary["rgb"][1]
    for key, name, _p in METHODS:
        if key not in detect_summary:
            continue
        a, r1, p1, per, rf, aper, f1 = detect_summary[key]
        gain = ("%.2f 倍" % (r1 / zero)) if zero > 1e-6 else "—"
        print("   %s: AUC %.3f / 再現率@FPR1%% %.3f(ゼロ点比 %s)/ 適合率 %.3f"
              % (_pad(name, 22), a, r1, gain, p1))

    print("   復元(退色前の色)は **ゼロ点にほぼ勝てなかった** —— 最良の K/S 固定でも")
    print("   f=0.15 で ΔE00 %.2f → %.2f(改善 %.0f %%)。褪色前の色は「復元できる」と"
          % (cliff_d[0.15]["null"], cliff_d[0.15]["KS固定"][2],
             100 * (1 - cliff_d[0.15]["KS固定"][2] / cliff_d[0.15]["null"])))
    print("   書けるほどの差ではない。f=1(褪色なし)ですら組み直しに ΔE00 %.2f 掛かる。"
          % cliff_d[1.0]["KS固定"][2])

    dt_total = time.perf_counter() - t_all

    # --------------------------------------------------------------- 検証 ----
    # 1. ゼロ点が実在し、可視だけでは下絵がほとんど見えない
    assert detect_summary["rgb"][0] < 0.90, \
        "ゼロ点(RGB PCA)が強すぎる。実験設計が崩れた: AUC %.3f" % detect_summary["rgb"][0]
    assert max(z[0] for z in zero_strong) < 0.99, \
        "面ごとにやり直したゼロ点が完璧になった(可視で見えてしまっている)"
    # 2. バンドを増やすだけ(可視のみ)ではゼロ点に勝てない —— 効いたのは近赤外
    assert abs(detect_summary["vis"][1] - detect_summary["rgb"][1]) < 0.05, \
        "可視のみ 16 バンドが RGB と大きく違う(所見が崩れた): %.3f vs %.3f" \
        % (detect_summary["vis"][1], detect_summary["rgb"][1])
    assert detect_summary["nir"][1] > 2.0 * max(detect_summary["rgb"][1], 0.01), \
        "近赤外がゼロ点に勝てていない"
    assert detect_summary["ms"][1] > 2.0 * detect_summary["vis"][1], \
        "可視+近赤外が可視のみに勝てていない"
    # 3. 面ごとに結果が割れる(1 つの数字にまとめられない)
    nir_per, nir_auc_per = detect_summary["nir"][3], detect_summary["nir"][5]
    assert nir_auc_per[0] > 0.95 and nir_auc_per[2] > 0.95, \
        "近赤外が効くはずの面で効いていない: %r" % (nir_auc_per,)
    assert nir_auc_per[1] < 0.80, \
        "アズライトの面でも近赤外が効いてしまっている(物理の仮定が崩れた): %r" \
        % (nir_auc_per,)
    # 差分は「剥落部で盲目」という固有の穴を持つ(平坦な材料では差が消える)
    assert detect_summary["nir"][4] < 0.10 < detect_summary["nirb"][4], \
        "近赤外『差分』が剥落部で盲目、という所見が崩れた: 差分 %.3f / 1 枚 %.3f" \
        % (detect_summary["nir"][4], detect_summary["nirb"][4])
    # 全体で 1 本の閾値が引けない検出器が実在する(近赤外 1 枚は面ごとには完璧)
    assert detect_summary["nirb"][1] < 0.05 and min(detect_summary["nirb"][3][0],
                                                    detect_summary["nirb"][3][2]) > 0.95, \
        "近赤外 1 枚の「面ごとには完璧・全体では 1 本引けない」が崩れた"
    # 4. 崖 (a): 厚みで単調に落ち、どこかで半分を割る
    nir_a = [cliff_a[t]["nir"][0] for t in taus]
    assert nir_a[0] > 0.8 and nir_a[-1] < 0.1, \
        "厚みの崖が見えない: %r" % (["%.3f" % v for v in nir_a],)
    assert all(b <= a + 1e-9 for a, b in zip(nir_a, nir_a[1:])), \
        "厚みに対して単調でない: %r" % (["%.3f" % v for v in nir_a],)
    # 5. 崖 (b): 8 本で頭打ち。低照度では増やすほど存在量が悪化する
    b3, b8, b16, b31 = (cliff_b[n]["十分光量"][0] for n in (3, 8, 16, 31))
    assert b3 < 0.6 < b8, "3 バンドと 8 バンドの差が見えない: %.3f / %.3f" % (b3, b8)
    assert abs(b31 - b8) < 0.02, \
        "8 本から先も改善が続いている(頭打ちの所見が崩れた): 8=%.3f 16=%.3f 31=%.3f" \
        % (b8, b16, b31)
    d3, d8, d31 = (cliff_b[n]["低照度"][2] for n in (3, 8, 31))
    assert d31 > 2.0 * d3, \
        "低照度でバンドを増やしても存在量が悪化しない(崖の所見が崩れた): " \
        "3=%.4f 8=%.4f 31=%.4f" % (d3, d8, d31)
    # 6. 崖 (c): 相関が上がるほど散らばりが増え、どこかで 0.10 を割り込む
    scat_c = [c[2] for c in cliff_c]
    assert all(b > a for a, b in zip(scat_c, scat_c[1:])), \
        "2 青の相関で散らばりが単調に増えない: %r" % (["%.4f" % v for v in scat_c],)
    assert scat_c[0] < 0.01 < 0.10 < scat_c[-1], "分離の境界が範囲内に無い"
    # 7. 崖 (d): 端成分を固定したままだと褪色が進むほど外れる
    de_fixed = [cliff_d[f]["固定"][2] for f in (1.0, 0.7, 0.5, 0.3, 0.15)]
    assert all(b > a for a, b in zip(de_fixed, de_fixed[1:])), \
        "褪色を進めても固定端成分の誤差が増えない: %r" % (["%.2f" % v for v in de_fixed],)
    assert abs(cliff_d[1.0]["固定"][0] - cliff_d[0.15]["固定"][0]) < 1e-6, \
        "固定端成分の茜の存在量が褪色で動いた(単体の頂点に張り付く所見が崩れた)"
    # 復元はゼロ点にほとんど勝てない —— 勝てないことを数字で固定する
    assert cliff_d[0.15]["KS固定"][2] > 0.90 * cliff_d[0.15]["null"], \
        "復元がゼロ点に大差で勝った(所見が崩れた。良い知らせなので書き直すこと)"
    assert cliff_d[1.0]["現場"][2] > 5.0, \
        "現場端成分での組み直しが褪色なしでも外れる、という所見が崩れた"
    assert abs(gamma_trap[0] - gamma_trap[1]) / gamma_trap[1] > 0.10, \
        "線形 sRGB のまま ΔE を測る落とし穴が再現しない: %r" % (gamma_trap,)
    # 8. 崖 (e): 雑音で単調に落ちる / 存在量の散らばりは単調に増える
    ne = [cliff_e[s]["nir"] for s in (0.0, 0.001, 0.004, 0.01, 0.03, 0.1)]
    assert ne[0] > ne[-1] and ne[-1] < 0.3, \
        "雑音で落ちない: %r" % (["%.3f" % v for v in ne],)
    se = [cliff_e[s]["scatter"] for s in (0.0, 0.001, 0.004, 0.01, 0.03, 0.1)]
    # sigma=0 でも散らばりは 0 にならない —— 層のモデル不整合が床を作っている。
    assert all(b >= a - 1e-9 for a, b in zip(se, se[1:])) and se[-1] > 5.0 * se[0], \
        "雑音で存在量の散らばりが増えない: %r" % (["%.4f" % v for v in se],)
    assert se[0] > 0.01, "雑音ゼロで散らばりが消えた(モデル不整合の床が無い)"
    # 9. 物理の両端(KM の極限)が閉形式に一致
    for key in LAYER_KEYS:
        r_inf, s550, _n = PIGMENTS[key]
        S = scat(s550)
        assert np.abs(km_layer(S * ks_ratio(r_inf), S, 1e-9,
                               np.full_like(S, 0.5)) - 0.5).max() < 1e-5
        assert np.abs(km_layer(S * ks_ratio(r_inf), S, 30.0,
                               np.full_like(S, 0.5)) - r_inf).max() < 1e-2
    # 10. 存在量: 反射率で線形に解くと単体の頂点に張り付く(散らばりより偏りが大きい)
    for key in ("azurite", "vermilion", "madder"):
        b, s = ab_summary[("masstone / R", key)]
        assert abs(b) > 4.0 * s, \
            "%s で偏りが散らばりを圧倒していない(所見が崩れた): 偏り %+.3f 散らばり %.3f" \
            % (key, b, s)
    if figs.errors():
        print("図の書き出しで失敗:", "; ".join(figs.errors()))
    print(f"\n総所要 {dt_total:.1f} 秒")
    print("PASS")
    return True


if __name__ == "__main__":
    raise SystemExit(0 if main() else 1)
