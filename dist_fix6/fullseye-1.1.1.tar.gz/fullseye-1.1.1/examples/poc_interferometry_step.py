# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""poc_interferometry_step — 白色干渉計(コヒーレンス走査、`interferometry` 族)で
**ナノメートルの段差をどこまで正確に測れるか**を、偏りと散らばりに分けて数字にする PoC。

    py -3.11 examples/poc_interferometry_step.py

【この PoC が答える問い】
半導体・精密加工の表面計測でいちばん素朴な問い —「50 nm の段差を、この装置で、
何 nm の確からしさで測れるのか」。カタログの「分解能 0.1 nm」ではなく、
**既知の段差を仕込んで測り返し、偏り(bias)と散らばり(std)を別々に出す**。

`examples/coherence_scanning.py` が「9 op が閉形式の真値と一致すること」を見るのに対し、
こちらは **1 つの測定量(段差)に絞って不確かさを積み上げる**。重ならないように、
雑音なしの一致確認は最小限にとどめてある。

(1) 設計: `csi_design` で走査ステップ上限・包絡線幅・捕捉範囲を先に決める。
(2) 系統誤差ゼロの確認: 雑音なしで 4 種類の段差を測り、モデル誤差の床を見る。
(3) ★繰り返し測定: 雑音の種を変えて 40 回測り、**偏りと散らばりを分ける**。
(4) ★ゼロ点との比較: 素朴な「包絡線の最大サンプル」(`peak`)に対して
    サブサンプル推定(`gaussian` / `centroid`)がどれだけ上回るか。
(5) 走査ステップ掃引: 細かくすれば良くなるのか。Nyquist ぎりぎりは安全か。
(6) 雑音掃引: 精度がどう崩れ、**どこで測れなくなるか**。
(7) 系統誤差探し: 段差が λ/2 の整数倍に近いと位相が巻き戻る、はず — を確かめる。

【グラウンドトゥルース(自分で仕込んだ真値)】
段差は `csi_stack_simulate` に渡す高さマップの左右差そのもの。測定値は
`csi_height_map` の左右平均差。真値は 0.050 / 0.100 / 0.200 / 0.500 µm。

【結果の要点(本文の print が正、以下は道しるべ)】
- 雑音なしの床は 1e-10 nm(倍精度の丸め)。段差 500 nm でも桁が変わらない。
- 雑音 1%(振幅比)で、段差によらず偏り数 nm・散らばり ~10 nm。
  **不確かさは段差の大きさにほぼ依存しない**(相対誤差ではなく絶対誤差の世界)。
- ゼロ点 `peak` の誤差は走査格子への丸め残差 dz·round(段差/dz) − 段差 に厳密一致
  する(最悪 ±走査ステップ/2)。雑音を減らしても消えない **構造を持った嘘**。
- 走査ステップは細かくしても良くならない。Nyquist 上限 λ/4 = 0.15 µm の手前
  0.14 µm で既に雑音なし誤差 +14 nm。**上限は安全な動作点ではない**。
- `centroid` は散らばりが `gaussian` の 1/3〜1/5 なのに、雑音とともに **段差を
  縮めるゲイン誤差**を持つ(雑音 3% で 0.55、10% で 0.20)。繰り返し測定だけでは
  捕まらない。
- **λ/2 の巻き戻りは出ない。** 予想が外れた側が、この族を足した理由そのもの。

【この PoC で分かった fullseye 側の穴 → 末尾の「所見」節】
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import examplefig as figs                                        # noqa: E402
import fringe                                                    # noqa: E402
import interferometry as I                                       # noqa: E402
from fullseye.evaluation import save_video as save_evaluation_video  # noqa: E402

LAM = 0.60          # µm  光源中心波長
DLAM = 0.10         # µm  スペクトル幅
Z_RANGE = 12.0      # µm  走査全長
DZ = 0.05           # µm  既定の走査ステップ
NP = 241            # 面数(0.05 × 240 = 12.0 µm)
BASE = 6.0          # µm  低い側の高さ = 走査の中央(端の切断を避ける)
PH, PW = 12, 12     # 段差の左右パッチ(12×12 画素ずつ、合計 12×24)
STEPS = (0.050, 0.100, 0.200, 0.500)     # µm  仕込む段差
N_TRIAL = 40        # 繰り返し測定の回数(seed を変える)

#: 見出しに載せる結果を、画面・台帳と同じ丸めの文字列で固定する。値が動いたら
#: ``check_headline`` が止めるので、実行結果を確かめてから台帳と一緒に転記し直す。
HEADLINE = {
    "std_min_nm": "10.5", "std_max_nm": "14.1", "bias_abs_nm": "2.4",
    "zstep_012_nm": "+0.35", "zstep_014_nm": "+14.1",
    "noise_limit_pct": "0.5", "centroid_std_nm": "4.2", "gaussian_std_nm": "11.8",
    "centroid_shrink_pct": "19", "phase_limit_um": "0.150",
    "phase_below_um": "0.149", "phase_above_um": "0.151", "phase_jump_um": "-0.300",
    "video_truth_um": "0.650", "video_error_nm": "+11",
}
SHOWN: dict[str, str] = {}


def check_headline() -> None:
    """見出しの数を守る門: この実行の値を、印字と同じ丸めで ``HEADLINE`` と照合する。"""
    diff = {k: (v, SHOWN.get(k)) for k, v in HEADLINE.items() if SHOWN.get(k) != v}
    print("\n見出しの数(この実行): " + "  ".join("%s=%s" % (k, SHOWN.get(k)) for k in HEADLINE))
    assert not diff, "見出しの数が HEADLINE と違う(記録, 実行): %r" % diff


def surface_csi_measurement(size=512, n_planes=48, seed=22):
    """Simulate a scanned two-dimensional stepped surface and recover its height."""
    if size < 32 or n_planes < 32:
        raise ValueError("surface and scan must contain at least 32 samples")
    yy, xx = np.mgrid[0:size, 0:size].astype(np.float64)
    xn = xx / (size - 1) - 0.5
    yn = yy / (size - 1) - 0.5
    truth = 1.75 + 0.42 * xn + 0.22 * yn + 0.65 * (xx >= size // 2)
    rough = (xn + 0.24) ** 2 + (yn - 0.18) ** 2 < 0.105 ** 2
    rng = np.random.default_rng(seed)
    texture = rng.normal(0.0, 0.035, truth.shape)
    texture = (texture + np.roll(texture, 1, 0) + np.roll(texture, 1, 1)) / 3.0
    truth = truth + rough * texture
    z_step = 3.8 / (n_planes - 1)
    design = I.csi_design(wavelength_um=LAM, bandwidth_um=DLAM,
                          z_range_um=3.8, width_px=size, height_px=size)
    sim_kw = dict(envelope_fwhm_um=design["envelope_fwhm_um"], noise=0.0015)
    if n_planes * size * size <= I.MAX_STACK_ELEMENTS:
        stack = I.csi_stack_simulate(truth, 0.0, z_step, n_planes, LAM,
                                     seed=seed, **sim_kw)
    else:
        # The op deliberately caps one allocation; tile the field without changing
        # the optical model or reducing the saved 512-pixel field.
        mid = size // 2
        left = I.csi_stack_simulate(truth[:, :mid], 0.0, z_step, n_planes, LAM,
                                    seed=seed, **sim_kw)
        right = I.csi_stack_simulate(truth[:, mid:], 0.0, z_step, n_planes, LAM,
                                     seed=seed + 1, **sim_kw)
        stack = np.concatenate([left, right], axis=2)
    stack[:, rough] = 0.5 + 0.28 * (stack[:, rough] - 0.5)
    dropout = rough & (((xx.astype(int) * 7 + yy.astype(int) * 11) % 23) < 5)
    stack[:, dropout] = 0.5 + 0.025 * (stack[:, dropout] - 0.5)
    if stack.size <= I.MAX_STACK_ELEMENTS:
        quality = I.csi_contrast_map(stack)
        height = I.csi_height_map(stack, z_step, 0.0, LAM,
                                  mode="gaussian", on_invalid="fill")
    else:
        mid = size // 2
        quality = np.concatenate([I.csi_contrast_map(stack[:, :, :mid]),
                                  I.csi_contrast_map(stack[:, :, mid:])], axis=1)
        height = np.concatenate([
            I.csi_height_map(stack[:, :, :mid], z_step, 0.0, LAM,
                             mode="gaussian", on_invalid="fill"),
            I.csi_height_map(stack[:, :, mid:], z_step, 0.0, LAM,
                             mode="gaussian", on_invalid="fill")], axis=1)
    threshold = float(np.quantile(quality, 0.08))
    height = np.asarray(height, dtype=np.float64)
    height[quality <= threshold] = np.nan
    return {"truth_um": truth, "stack": stack, "height_um": height,
            "quality": quality, "quality_threshold": threshold,
            "rough_mask": rough, "dropout_mask": dropout,
            "z_um": np.arange(n_planes) * z_step}


def csi_resemblance_gate(size=96):
    """Return closed-form CSI checks and the half-bandwidth breaking probe."""
    d = I.csi_design(wavelength_um=LAM, bandwidth_um=DLAM,
                     z_range_um=4.0, width_px=size, height_px=size)
    d_half = I.csi_design(wavelength_um=LAM, bandwidth_um=DLAM / 2.0,
                          z_range_um=4.0, width_px=size, height_px=size)
    closed_width = 0.44 * LAM ** 2 / DLAM
    z = np.linspace(0.0, 2.0 * LAM, 24001)
    signal = np.cos(4.0 * np.pi * z / LAM)
    peaks = z[1:-1][(signal[1:-1] > signal[:-2]) & (signal[1:-1] >= signal[2:])]
    period = float(np.median(np.diff(peaks)))
    estimates = []
    for seed in range(6):
        r = surface_csi_measurement(size=max(48, size), n_planes=64, seed=seed)
        h = r["height_um"]
        xmid = h.shape[1] // 2
        estimates.append(float(np.nanmedian(h[:, xmid + 5:]) - np.nanmedian(h[:, :xmid - 5])))
    return {"envelope_relative_error": abs(d["envelope_fwhm_um"] - closed_width) / closed_width,
            "fringe_period_relative_error": abs(period - LAM / 2.0) / (LAM / 2.0),
            "step_repeatability_nm": float(np.std(estimates, ddof=1) * 1000.0),
            "half_bandwidth_width_ratio": d_half["envelope_fwhm_um"] / d["envelope_fwhm_um"]}


def fig_surface_csi(result=None):
    if not figs.enabled():
        return None
    import annotate as AN
    import fullseye as fs

    r = result if result is not None else surface_csi_measurement(size=512, n_planes=48, seed=22)
    picks = (9, 19, 29, 39)
    figs.save_grid("surface_interferograms", [r["stack"][k] for k in picks],
                   ["z = %.2f um" % r["z_um"][k] for k in picks], ncols=4,
                   gray=True,
                   caption="Raw coherence-scan frames. Tilt changes fringe density; the rough patch loses modulation.")
    lo, hi = float(np.nanmin(r["truth_um"])), float(np.nanmax(r["truth_um"]))

    def coloured(a, vmin, vmax, unit):
        rgb = np.asarray(fs.colorize_depth(np.nan_to_num(a, nan=vmin), name="turbo", vmin=vmin, vmax=vmax), float)[..., :3]
        lut = np.asarray(fs.colorize_depth(np.linspace(vmin, vmax, 256)[None], name="turbo", vmin=vmin, vmax=vmax))[0, :, :3]
        rgb = np.pad(rgb, ((0, 0), (0, 112), (0, 0)), constant_values=1.0)  # バーは右の白い余白へ
        return np.asarray(AN.color_bar(rgb, lut, (522, 36, 18, 434), vmin=vmin, vmax=vmax, unit=unit), float)

    err_nm = (r["height_um"] - r["truth_um"]) * 1000.0
    panels = [coloured(r["truth_um"], lo, hi, "um"),
              coloured(r["height_um"], lo, hi, "um"),
              coloured(err_nm, -20.0, 20.0, "nm"), r["quality"]]
    figs.save_grid("surface_height", panels,
                   ["truth", "recovered", "error", "modulation quality"], ncols=4,
                   gray=[False, False, False, True],
                   caption="Truth, recovered height, error and low-modulation dropout map; pseudo-colour bars carry units.")
    frames = []
    for k in range(48):
        q = np.clip(r["stack"][k], 0.0, 1.0)
        frames.append((np.repeat(q[..., None], 3, axis=2) * 255).astype(np.uint8))
    save_evaluation_video(
        "surface_z_scan", frames,
        caption="48 raw uint8 coherence-scan frames; the localized envelope sweeps over the tilted step.",
        capture_fps=12.0, playback_fps=12.0, hold_frames=0, gif_stride=2,
        display_scale=512 / frames[0].shape[1], interpolation="linear")
    return r


def fig_csi_scan_explained(result=None):
    """入口動画: 縞の包絡線が現れる z と表面高さの対応を 1 画面で示す。"""
    if not figs.enabled():
        return None
    from PIL import Image, ImageDraw
    import annotate as AN
    import fullseye as fs

    r = result if result is not None else surface_csi_measurement(size=512, n_planes=48, seed=22)
    z = np.asarray(r["z_um"], dtype=np.float64)
    truth = np.asarray(r["truth_um"], dtype=np.float64)
    height = np.asarray(r["height_um"], dtype=np.float64)
    stack = np.asarray(r["stack"], dtype=np.float64)
    lo, hi = float(np.nanmin(truth)), float(np.nanmax(truth))
    y, x1, x2 = 256, 200, 312

    # P1/P2 は傾いた同一面上にある。段差だけを測るため、真値の各側から求めた
    # 面内 x 勾配を同じ実行の height/truth の双方から差し引く。
    xx = np.arange(truth.shape[1], dtype=np.float64)
    left = (xx < truth.shape[1] // 2) & np.isfinite(height[y])
    right = (xx >= truth.shape[1] // 2) & np.isfinite(height[y])
    slope_meas = 0.5 * (np.polyfit(xx[left], height[y, left], 1)[0]
                        + np.polyfit(xx[right], height[y, right], 1)[0])
    slope_truth = 0.5 * (np.polyfit(xx[xx < truth.shape[1] // 2],
                                   truth[y, xx < truth.shape[1] // 2], 1)[0]
                         + np.polyfit(xx[xx >= truth.shape[1] // 2],
                                      truth[y, xx >= truth.shape[1] // 2], 1)[0])
    step_meas = float(height[y, x2] - height[y, x1] - slope_meas * (x2 - x1))
    step_truth = float(truth[y, x2] - truth[y, x1] - slope_truth * (x2 - x1))
    step_err_nm = (step_meas - step_truth) * 1000.0
    assert abs(step_err_nm) <= 20.0
    # 動画の数は 1 画素対・1 回の読みで、3 節の繰り返し測定(144 画素の平均、40 回)とは別の量。
    SHOWN.update(video_truth_um="%.3f" % step_truth, video_error_nm="%+.0f" % step_err_nm)

    # 最終コマでは、有効な高さ画素がすべて着色される。
    passed_last = np.isfinite(height) & (truth <= z[-1] - 0.3)
    assert int(np.count_nonzero(passed_last)) == int(np.count_nonzero(np.isfinite(height)))

    def resize_bilinear(a, size):
        q = np.clip(np.asarray(a, dtype=np.float64), 0.0, 1.0)
        im = Image.fromarray(np.rint(q * 255.0).astype(np.uint8), mode="L")
        return np.asarray(im.resize(size, Image.Resampling.BILINEAR), dtype=np.uint8)

    def rgb8(a):
        q = np.clip(np.asarray(a, dtype=np.float64), 0.0, 1.0)
        return np.rint(q * 255.0).astype(np.uint8)

    def put_text(im, text, xy, size=22, anchor="lt", fill=(245, 245, 245),
                 plate=None, pad=3):
        # AN.measure_text は描画より先に全ラベルを実測する。縮小を許さず、22 px 未満にしない。
        m = AN.measure_text(text, font_size=size, min_font_size=size, wrap=False)
        w, h = m["width"], m["height"]
        ax, ay = anchor
        x0 = int(xy[0] - (w if ax == "r" else w // 2 if ax == "c" else 0))
        y0 = int(xy[1] - (h if ay == "b" else h // 2 if ay == "m" else 0))
        if x0 - pad < 0 or y0 - pad < 0 or x0 + w + pad > im.width or y0 + h + pad > im.height:
            raise ValueError("text overflow: %r at %r, rect=(%d,%d,%d,%d), canvas=%r" %
                             (text, xy, x0, y0, w, h, im.size))
        d = ImageDraw.Draw(im)
        if plate is not None:
            d.rectangle((x0 - pad, y0 - pad, x0 + w + pad, y0 + h + pad), fill=plate)
        for i, line in enumerate(m["lines"]):
            d.text((x0, y0 + i * m["line_height"]), line, font=m["font"], fill=fill)

    def paste_gray(im, a, box):
        q = resize_bilinear(a, (box[2], box[3]))
        im.paste(Image.fromarray(np.repeat(q[..., None], 3, axis=2)), (box[0], box[1]))

    def paste_turbo(im, a, valid, box):
        q = np.nan_to_num(a, nan=lo)
        col = rgb8(fs.colorize_depth(q, name="turbo", vmin=lo, vmax=hi))
        dark = np.full_like(col, 36)
        col = np.where(valid[..., None], col, dark)
        rim = Image.fromarray(col).resize((box[2], box[3]), Image.Resampling.BILINEAR)
        im.paste(rim, (box[0], box[1]))

    def graph(im, k):
        d = ImageDraw.Draw(im)
        rect = (990, 145, 1244, 397)
        d.rectangle(rect, outline=(185, 190, 200), width=1)
        x0, y0, x3, y3 = rect
        xp = lambda v: x0 + (float(v) - z[0]) / (z[-1] - z[0]) * (x3 - x0)
        yp = lambda v: y3 - float(v) * (y3 - y0)
        for tv in (0.0, 1.0, 2.0, 3.0, 3.8):
            px = int(round(xp(tv))); d.line((px, y3, px, y3 + 5), fill=(185, 190, 200))
            put_text(im, "%.1f" % tv, (px, y3 + 8), anchor="ct")
        for tv in (0.0, 0.5, 1.0):
            py = int(round(yp(tv))); d.line((x0 - 5, py, x0, py), fill=(185, 190, 200))
            put_text(im, "%.1f" % tv, (x0 - 8, py), anchor="rm")
        cols = ((75, 175, 255), (255, 155, 45))
        for px0, col in zip((x1, x2), cols):
            pts = [(int(round(xp(zz))), int(round(yp(v))))
                   for zz, v in zip(z, stack[:, y, px0])]
            d.line(pts, fill=col, width=2)
            for p in pts:
                d.ellipse((p[0] - 2, p[1] - 2, p[0] + 2, p[1] + 2), fill=col)
        for hv, col in zip((height[y, x1], height[y, x2]), cols):
            px = int(round(xp(hv))); d.line((px, y0, px, y3), fill=col, width=2)
        cur = int(round(xp(z[k]))); d.line((cur, y0, cur, y3), fill=(255, 238, 80), width=2)
        put_text(im, "2画素の信号対 z", (950, 62), size=24)
        put_text(im, "強度", (950, 104))
        put_text(im, "z [µm]", ((x0 + x3) // 2, 438), anchor="ct")
        put_text(im, "P1 高さ %.3f µm\nP2 高さ %.3f µm" %
                 (height[y, x1], height[y, x2]), (950, 475), size=22)
        put_text(im, "段差(傾斜補正) %.3f µm\n真値 %.3f µm" %
                 (step_meas, step_truth), (950, 552), size=22)
        put_text(im, "差 %+.0f nm" % step_err_nm, (950, 640), size=24,
                 fill=(255, 220, 90))

    accumulated = np.zeros_like(truth)
    frames = []
    for k in range(len(z)):
        # コマごとに新しい 1280×720 画布を作る。
        im = Image.new("RGB", (1280, 720), (18, 21, 28))
        d = ImageDraw.Draw(im)
        d.rectangle((0, 0, 1279, 55), fill=(31, 38, 51))
        put_text(im, "白色干渉(コヒーレンス走査)で段差を測る —— 縞が出る高さが表面の高さ",
                 (14, 10), size=24)
        put_text(im, "z = %.2f µm(%d/48)" % (z[k], k + 1), (1265, 10), size=24, anchor="rt")

        paste_gray(im, stack[k], (20, 70, 560, 560))

        # P1/P2 の位置を左パネルに印す(右の信号図と同じ色)。無印だと読者が画素を探せない。

        sx, sy = 560 / stack.shape[2], 560 / stack.shape[1]

        for px0, col, lab in zip((x1, x2), ((75, 175, 255), (255, 155, 45)), ('P1', 'P2')):

            cx, cy = int(round(20 + px0 * sx)), int(round(70 + y * sy))

            d.ellipse((cx - 7, cy - 7, cx + 7, cy + 7), outline=col, width=3)

            put_text(im, lab, (cx + 10, cy - 14), fill=col)
        mask = np.abs(truth - z[k]) < 0.02
        edge = mask & ~(np.roll(mask, 1, 0) & np.roll(mask, -1, 0)
                        & np.roll(mask, 1, 1) & np.roll(mask, -1, 1))
        ey, ex = np.nonzero(edge)
        pts = [(20 + int(round(v * 559 / 511)), 70 + int(round(u * 559 / 511)))
               for u, v in zip(ey, ex)]
        ImageDraw.Draw(im).point(pts, fill=(255, 235, 40))
        put_text(im, "黄 = 真値が今の z。縞のコントラストが立つ場所と一致",
                 (20, 639), size=22)

        accumulated = np.maximum(accumulated, np.abs(stack[k] - 0.5))
        put_text(im, "ここまでの最大変調", (610, 70), size=24)
        paste_gray(im, accumulated / 0.5, (610, 104, 300, 266))

        # ★2026-11-15(独立レビュー): 以前は上限の数字が高さの絵に重なり、下限の数字が「通過」の板に
        #   隠れ、絵とバーの下端が最下段の帯(y ≥ 680)に覆われていた。「通過」の注は題の下へ、絵とバーは
        #   帯より上へ収め、上限・単位・下限の数字はバーの右の余白へ出す(何も重ねない)。
        put_text(im, "ここまでに決まった高さ", (610, 384), size=24)
        put_text(im, "(通過 = 真値 ≤ z − 0.3 µm)", (610, 426), size=22)
        passed = np.isfinite(height) & (truth <= z[k] - 0.3)
        hb = (610, 470, 196, 196)                      # 高さの絵の枠(左, 上, 幅, 高さ)
        paste_turbo(im, height, passed, hb)
        bar = np.linspace(hi, lo, hb[3])[:, None]
        bar_rgb = rgb8(fs.colorize_depth(bar, name="turbo", vmin=lo, vmax=hi))
        bx = hb[0] + hb[2] + 8
        im.paste(Image.fromarray(np.repeat(bar_rgb, 18, axis=1)), (bx, hb[1]))
        put_text(im, "%.2f" % hi, (bx + 26, hb[1]), anchor="lt")
        put_text(im, "µm", (bx + 26, hb[1] + hb[3] // 2), anchor="lm")
        put_text(im, "%.2f" % lo, (bx + 26, hb[1] + hb[3]), anchor="lb")

        graph(im, k)
        # 22 px の日本語フォントは実測 39 px 高なので、指定の下帯から上へ 10 px だけ張り出す。
        ImageDraw.Draw(im).rectangle((0, 680, 1279, 719), fill=(31, 38, 51))
        put_text(im, "Fullseye: CSI stack→contrast→height(gaussian)。粗い円板は変調が落ち、品質下位8 %はNaN(黒)。",
                 (12, 679), size=22, pad=0)
        frames.append(np.asarray(im, dtype=np.uint8))

    figs.save_video("csi_scan_explained", frames, fps=12.0, gif_every=2, gif_width=640,
                    caption="白色干渉の48面走査で、縞のコントラストが立つ高さと表面高さが一致する様子を示す。"
                            "傾斜を除いた段差は測定 %.3f µm、真値 %.3f µm、差 %+.0f nm。"
                            % (step_meas, step_truth, step_err_nm))

    # ★2026-11-15: 目玉のカードのサムネイル用の正方形の静止画(独立レビュー: 以前のサムネイルは灰色の縞と
    #   円板だけで何の図か分からず、動画のコマを切り抜くと見出しの文字が切れる)。同じ走査・同じ高さから組む。
    k_mid = int(np.argmin(np.abs(z - 0.5 * (lo + hi))))
    st = Image.new("RGB", (720, 720), (18, 21, 28))
    ImageDraw.Draw(st).rectangle((0, 0, 719, 71), fill=(31, 38, 51))
    put_text(st, "白色干渉で段差を測る(合成)", (16, 12), size=34)
    paste_gray(st, stack[k_mid], (16, 92, 290, 290))
    paste_turbo(st, height, np.isfinite(height), (322, 92, 290, 290))
    sbar = np.linspace(hi, lo, 290)[:, None]
    st.paste(Image.fromarray(np.repeat(rgb8(fs.colorize_depth(sbar, name="turbo", vmin=lo, vmax=hi)), 18, axis=1)),
             (620, 92))
    put_text(st, "%.2f" % hi, (644, 92), anchor="lt")
    put_text(st, "µm", (644, 92 + 145), anchor="lm")
    put_text(st, "%.2f" % lo, (644, 382), anchor="lb")
    put_text(st, "走査の 1 コマ(z = %.2f µm)" % z[k_mid], (16, 392), size=22)
    put_text(st, "読んだ高さ(黒 = 測れない)", (322, 392), size=22)
    put_text(st, "縞のコントラストが立つ z = 表面の高さ", (16, 452), size=30)
    put_text(st, "傾いた面の段差 %.3f µm を 48 面の走査で読む" % step_truth, (16, 512), size=24)
    put_text(st, "1 画素対の 1 回の読み %.3f µm(差 %+.0f nm)" % (step_meas, step_err_nm), (16, 556), size=24)
    put_text(st, "粗い円板は変調が落ちて測れない", (16, 600), size=24)
    put_text(st, "Fullseye: csi_stack_simulate → csi_contrast_map → csi_height_map", (16, 668), size=18)
    figs.save("csi_scan_still", np.asarray(st, dtype=np.uint8),
              caption="サムネイル用の静止画(合成)。09 の動画と同じ 48 面の走査(雑音 0.15 %%)の z = %.2f µm のコマと、"
                      "読んだ高さ(gaussian、変調の品質の下位 8 %% は測れない = 黒)。段差 %.3f µm(真値 %.3f µm、差 %+.0f nm)は "
                      "1 画素対の 1 回の読みで、3 節の繰り返し測定(144 画素の平均を 40 回)とは別の量。"
                      % (z[k_mid], step_meas, step_truth, step_err_nm))
    return {"step_measured_um": step_meas, "step_truth_um": step_truth,
            "step_error_nm": step_err_nm, "finite_height_pixels": int(np.count_nonzero(np.isfinite(height)))}

# 包絡線幅は設計から取る(設計値と前方モデルを一致させておく。
# ここを手打ちの定数にすると「設計を無視した数字」になってしまう)
DESIGN = I.csi_design(wavelength_um=LAM, bandwidth_um=DLAM, z_range_um=Z_RANGE,
                      width_px=2 * PW, height_px=PH)
FWHM = DESIGN["envelope_fwhm_um"]


def make_stack(step_um, noise, seed, dz=DZ, n_planes=NP):
    """左半分 BASE、右半分 BASE+step の段差表面から走査スタックを合成する。

    戻り値は (真の高さマップ, zscan スタック)。真値は自分で作った配列そのもので、
    op から貰った数ではない。
    """
    truth = np.full((PH, 2 * PW), BASE)
    truth[:, PW:] += step_um
    stack = I.csi_stack_simulate(truth, 0.0, dz, n_planes, LAM,
                                 envelope_fwhm_um=FWHM, noise=noise, seed=seed)
    return truth, stack


def measure_step(step_um, noise, seed, mode="gaussian", dz=DZ, n_planes=NP):
    """段差を 1 回測る。戻り値は (測定した段差 [µm], 拒否された画素の割合)。

    画素単位の拒否(変調度不足など)は `on_invalid="fill"` で NaN にし、
    **何割が拒否されたかを数える**。ここを raise のままにすると雑音掃引の
    後半が例外で落ちて「測れない領域」の形が見えなくなる。
    """
    _, stack = make_stack(step_um, noise, seed, dz, n_planes)
    hmap = I.csi_height_map(stack, dz, 0.0, LAM, mode=mode, on_invalid="fill")
    rejected = float(np.isnan(hmap).mean())
    if rejected == 1.0:
        return float("nan"), rejected
    lo = np.nanmean(hmap[:, :PW])
    hi = np.nanmean(hmap[:, PW:])
    return float(hi - lo), rejected


def repeat(step_um, noise, mode="gaussian", dz=DZ, n_planes=NP, n=N_TRIAL):
    """seed を変えて n 回測り、偏り・散らばり・拒否率を返す(単位 nm)。

    「誤差 2 nm」ではなく「偏り +0.3 nm、標準偏差 1.8 nm」を出すための関数。
    偏りは系統誤差(何度測っても消えない)、散らばりは統計誤差(平均すれば減る)。
    """
    vals, rej = [], []
    for seed in range(1, n + 1):
        v, r = measure_step(step_um, noise, seed, mode, dz, n_planes)
        vals.append(v)
        rej.append(r)
    v = np.asarray(vals, dtype=np.float64)
    ok = ~np.isnan(v)
    if ok.sum() < 2:
        return float("nan"), float("nan"), float(np.mean(rej)), int(ok.sum())
    bias_nm = (float(np.mean(v[ok])) - step_um) * 1000.0
    std_nm = float(np.std(v[ok], ddof=1)) * 1000.0
    return bias_nm, std_nm, float(np.mean(rej)), int(ok.sum())


def _v_txt(img, s, xy, anchor="lt", fs_=12):
    """文字の板。**小さな板(パネル 1 枚)にだけ**描く —— 全面に描くと遅い。"""
    import annotate as AN

    return np.asarray(AN.text_box(img, s, xy, anchor=anchor, font_size=fs_), dtype=np.float64)


def fig_step_sweep_video(n_steps=136, s_max=0.90, n_hold=12, fps=12.0):
    """★動画: 仕込む段差を 0 → 0.90 µm へ連続に増やし、コヒーレンス走査(包絡線)と
    位相シフト法を同じ表面で測り比べる(7 節の 9 点を連続にしたもの)。

    左 = 低い側・高い側の 1 画素ずつの走査信号と、``csi_height_map`` が読んだ高さ(縦線)。
    右 = 測った段差 vs 仕込んだ段差。包絡線は対角線に乗り続け、位相シフト法は λ/4 を
    越えるたびに λ/2 ぶん飛ぶ。雑音なし(seed 0)なので乱数の流れには触れない。
    図を出さない実行では呼ばれない。
    """
    if not figs.enabled():
        return None
    import annotate as AN

    steps = np.linspace(0.0, s_max, n_steps)
    gain_rad = 4.0 * np.pi / LAM
    z_ax = DZ * np.arange(NP)
    sel = (z_ax >= BASE - 1.0) & (z_ax <= BASE + s_max + 1.0)
    zs = z_ax[sel]
    rows = []
    for step in steps:
        _truth, stack = make_stack(float(step), 0.0, 0)
        hmap = I.csi_height_map(stack, DZ, 0.0, LAM, mode="gaussian", on_invalid="fill")
        csi = float(np.nanmean(hmap[:, PW:]) - np.nanmean(hmap[:, :PW]))
        tru = np.full((PH, 2 * PW), 0.0)
        tru[:, PW:] = step
        imgs = fringe.synthesize_fringes(tru, n_steps=4, freq=0.0, phase_gain=gain_rad,
                                         bias=0.5, amplitude=0.4)
        rec = fringe.decode_fringe(imgs, k=1.0 / gain_rad)
        psi = float(rec[:, PW:].mean() - rec[:, :PW].mean())
        rows.append((float(step), csi, psi, stack[sel, PH // 2, PW // 2],
                     stack[sel, PH // 2, PW + PW // 2],
                     float(hmap[PH // 2, PW // 2]), float(hmap[PH // 2, PW + PW // 2])))
    csi_err = max(abs(r[1] - r[0]) for r in rows) * 1000.0
    jumps = [r[0] for r in rows if abs(r[2] - r[0]) > 1e-6]
    first_jump = min(jumps) if jumps else float("nan")
    smin = min(min(r[3].min(), r[4].min()) for r in rows)
    smax = max(max(r[3].max(), r[4].max()) for r in rows)

    S_W, S_H, GAP, TB = 480, 400, 6, 34
    FW, FH = 2 * S_W + GAP, TB + S_H
    xs = [0, S_W + GAP]
    base = np.full((FH, FW, 3), 0.06)
    for k, s in enumerate(("走査信号(左右 1 画素ずつ)と読んだ高さ", "測った段差 vs 仕込んだ段差")):
        strip = base[0:TB, xs[k]:xs[k] + S_W]
        base[0:TB, xs[k]:xs[k] + S_W] = _v_txt(strip, s, (4, TB // 2), anchor="lm", fs_=13)
    # 動かない部分(軸・目盛り・対角線・λ/4 の印・凡例)は 1 度だけ描く
    pa = np.full((S_H, S_W, 3), 0.10)
    ax_a = AN.axes_transform((50, 70, S_W - 66, S_H - 128), (zs[0], zs[-1]),
                             (smin - 0.03, smax + 0.03))
    pa = np.asarray(AN.axes_frame(pa, ax_a), np.float64)
    pa = np.asarray(AN.ticks(pa, ax_a, xticks=[5.0, 5.5, 6.0, 6.5, 7.0, 7.5],
                             yticks=[0.2, 0.5, 0.8], font_size=10), np.float64)
    pa = _v_txt(pa, "走査位置 z [µm]", (S_W // 2 + 20, S_H - 4), anchor="cb", fs_=10)
    pa = _v_txt(pa, "青 = 低い側 / だいだい = 高い側\n縦線 = 包絡線から読んだ高さ", (S_W - 8, 66),
                anchor="rb", fs_=10)
    base[TB:, xs[0]:xs[0] + S_W] = pa
    pb = np.full((S_H, S_W, 3), 0.10)
    ylo, yhi = -0.2, s_max + 0.05
    ax_b = AN.axes_transform((56, 70, S_W - 72, S_H - 128), (0.0, s_max), (ylo, yhi))
    pb = np.asarray(AN.axes_frame(pb, ax_b), np.float64)
    pb = np.asarray(AN.ticks(pb, ax_b, xticks=[0.0, 0.15, 0.3, 0.45, 0.6, 0.75, 0.9],
                             yticks=[-0.15, 0.0, 0.15, 0.3, 0.45, 0.6, 0.75, 0.9], font_size=10),
                    np.float64)
    pb = np.asarray(AN.plot_series(pb, ax_b, [0.0, s_max], [0.0, s_max], color=(0.5, 0.5, 0.5),
                                   width=1), np.float64)
    for q in np.arange(LAM / 4, s_max, LAM / 2):            # λ/4 + n·λ/2 = 位相シフト法が飛ぶ所
        pb = np.asarray(AN.plot_series(pb, ax_b, [q, q], [ylo, yhi], color=(0.30, 0.30, 0.38),
                                       width=1), np.float64)
    pb = _v_txt(pb, "仕込んだ段差 [µm](縦の細線 = λ/4 + n·λ/2)", (S_W // 2 + 20, S_H - 4), anchor="cb", fs_=10)
    pb = _v_txt(pb, "だいだい = コヒーレンス走査(包絡線)\n水色 = 位相シフト法(4 段)\n灰の対角線 = 真値"
                "(0.15 までは 2 つが重なる)",
                (S_W - 8, 66), anchor="rb", fs_=10)
    base[TB:, xs[1]:xs[1] + S_W] = pb

    C_LO, C_HI, C_CSI, C_PSI = (0.40, 0.65, 1.0), (0.95, 0.60, 0.20), (0.95, 0.60, 0.20), (0.40, 0.80, 0.95)
    frames = []
    b_acc = base[TB:, xs[1]:xs[1] + S_W].copy()             # 点は溜まる一方なので、新しい点だけ足していく
    for k in list(range(n_steps)) + [n_steps - 1] * n_hold:
        step, csi, psi, sig_lo, sig_hi, h_lo, h_hi = rows[k]
        f = base.copy()
        a = f[TB:, xs[0]:xs[0] + S_W]
        y0, y1 = smin - 0.03, smax + 0.03
        for h, col in ((h_lo, C_LO), (h_hi, C_HI)):
            if zs[0] <= h <= zs[-1]:
                a = np.asarray(AN.plot_series(a, ax_a, [h, h], [y0, y1], color=col, width=1), np.float64)
        a = np.asarray(AN.plot_series(a, ax_a, zs, sig_lo, color=C_LO, width=1), np.float64)
        a = np.asarray(AN.plot_series(a, ax_a, zs, sig_hi, color=C_HI, width=1), np.float64)
        a = _v_txt(a, "仕込んだ段差 %.3f µm(= λ/2 の %.2f 倍)\n包絡線の中心の差 %.3f µm"
                   % (step, step / (LAM / 2), h_hi - h_lo), (8, 6), fs_=12)
        f[TB:, xs[0]:xs[0] + S_W] = a
        if len(frames) < n_steps:                             # 止めのコマでは点を足さない
            b_acc = np.asarray(AN.plot_series(b_acc, ax_b, [step], [psi], kind="scatter",
                                              color=C_PSI, marker_size=2), np.float64)
            b_acc = np.asarray(AN.plot_series(b_acc, ax_b, [step], [csi], kind="scatter",
                                              color=C_CSI, marker_size=2), np.float64)
        b = b_acc.copy()
        n_ord = int(round((psi - step) / (LAM / 2)))
        b = _v_txt(b, "包絡線 %.4f µm(誤差 %+.1e nm)\n位相シフト %.4f µm%s"
                   % (csi, (csi - step) * 1000.0, psi,
                      "" if n_ord == 0 else "(λ/2 × %+d 飛んだ)" % n_ord), (8, 6), fs_=12)
        f[TB:, xs[1]:xs[1] + S_W] = b
        frames.append(np.clip(f, 0.0, 1.0))
    save_evaluation_video(
        "step_sweep", frames, capture_fps=fps, playback_fps=fps, hold_frames=0, gif_stride=2,
        display_scale=640 / frames[0].shape[1], interpolation="linear",
        caption="動画(%d コマ): 仕込む段差を 0 → %.2f µm へ連続に増やし、同じ表面を 2 つの方法で測る(雑音なし)。"
                            "左は低い側・高い側 1 画素ずつのコヒーレンス走査の信号で、縦線は csi_height_map(gaussian)が"
                            "包絡線から読んだ高さ。右は測った段差 vs 仕込んだ段差。包絡線(だいだい)は全域で対角線に乗り、"
                            "誤差は最大 %.1e nm —— 包絡線には周期が無いので巻き戻らない。位相シフト法(水色、4 段)は "
                            "λ/4 = %.3f µm を越えると λ/2 ぶん飛び、以後 λ/2 ごとに鋸の歯になる。動画の掃引の刻みは "
                            "%.4f µm なので、最初に見える飛びは段差 %.3f µm のコマ(境界そのものは λ/4 ちょうどで、"
                            "7 節の 0.149 / 0.151 µm がそれを挟む)。"
                            % (len(frames), s_max, csi_err, LAM / 4, s_max / (n_steps - 1), first_jump))
    return {"csi_err_nm": csi_err, "first_jump": first_jump}


def main():
    t_all = time.perf_counter()
    gate = csi_resemblance_gate()
    assert gate["envelope_relative_error"] < 0.02
    assert gate["fringe_period_relative_error"] < 1e-3
    assert gate["step_repeatability_nm"] <= 10.0
    assert abs(gate["half_bandwidth_width_ratio"] - 2.0) < 0.02
    print("CSI resemblance: envelope %.3f%%, fringe %.3g, repeatability %.2f nm, half-bandwidth %.3fx"
          % (100 * gate["envelope_relative_error"], gate["fringe_period_relative_error"],
             gate["step_repeatability_nm"], gate["half_bandwidth_width_ratio"]))
    # カード動画の数も CI 相当で測り直す。図を出す実行では同じ配列を 01 / 02 / 09 / 10 に使い回す。
    surface_result = surface_csi_measurement(size=512, n_planes=48, seed=22)
    fig_surface_csi(surface_result)
    truth_surface = np.asarray(surface_result["truth_um"], dtype=np.float64)
    height_surface = np.asarray(surface_result["height_um"], dtype=np.float64)
    y, x1, x2 = 256, 200, 312
    xx = np.arange(truth_surface.shape[1], dtype=np.float64)
    left = (xx < truth_surface.shape[1] // 2) & np.isfinite(height_surface[y])
    right = (xx >= truth_surface.shape[1] // 2) & np.isfinite(height_surface[y])
    slope_meas = 0.5 * (np.polyfit(xx[left], height_surface[y, left], 1)[0]
                        + np.polyfit(xx[right], height_surface[y, right], 1)[0])
    slope_truth = 0.5 * (np.polyfit(xx[xx < truth_surface.shape[1] // 2],
                                   truth_surface[y, xx < truth_surface.shape[1] // 2], 1)[0]
                         + np.polyfit(xx[xx >= truth_surface.shape[1] // 2],
                                      truth_surface[y, xx >= truth_surface.shape[1] // 2], 1)[0])
    video_truth = float(truth_surface[y, x2] - truth_surface[y, x1] - slope_truth * (x2 - x1))
    video_meas = float(height_surface[y, x2] - height_surface[y, x1] - slope_meas * (x2 - x1))
    SHOWN.update(video_truth_um="%.3f" % video_truth, video_error_nm="%+.0f" % ((video_meas - video_truth) * 1000.0))

    # ------------------------------------------------------------------ #
    # 1) 設計 — 測る前に決まってしまう限界                                  #
    # ------------------------------------------------------------------ #
    print("1) 設計(λ=%.2f µm, Δλ=%.2f µm, 走査 %.1f µm, %d×%d 画素):"
          % (LAM, DLAM, Z_RANGE, PH, 2 * PW))
    print("   包絡線 FWHM(走査軸)      = %.4f µm" % FWHM)
    print("   縞周期 λ/2                 = %.4f µm" % DESIGN["fringe_period_um"])
    print("   走査ステップ上限(Nyquist) = %.4f µm  推奨 %.4f µm"
          % (DESIGN["max_z_step_um"], DESIGN["recommended_z_step_um"]))
    print("   捕捉範囲(可視度 30%%)     = %.4f µm" % DESIGN["capture_range_um"])
    print("   位相シフト法の一意段差      = %.4f µm  ← 本 PoC の段差 0.500 µm は"
          " この 3.3 倍" % DESIGN["phase_unambiguous_step_um"])
    # 走査の中央に置いた表面が捕捉範囲の内側にあること(端の切断は別の失敗モード)
    assert BASE - DESIGN["capture_range_um"] > 0.0
    assert BASE + max(STEPS) + DESIGN["capture_range_um"] < Z_RANGE

    # ------------------------------------------------------------------ #
    # 2) 雑音なし — モデル誤差の床(ここが 0 でなければ以降は全部無意味)     #
    # ------------------------------------------------------------------ #
    print("\n2) 雑音なしで測った段差(系統誤差の床):")
    print("   仕込んだ段差 |        測定値 |        誤差")
    floor_nm = 0.0
    for step in STEPS:
        got, _ = measure_step(step, 0.0, 0)
        err_nm = (got - step) * 1000.0
        floor_nm = max(floor_nm, abs(err_nm))
        print("   %8.1f nm | %12.6f µm | %+12.3e nm" % (step * 1000, got, err_nm))
    print("   床 = %.3e nm。段差 500 nm でも桁が変わらない = 誤差は段差に比例しない"
          % floor_nm)
    assert floor_nm < 0.05          # 雑音が無ければ 0.05 nm 以内

    # ------------------------------------------------------------------ #
    # 3) ★繰り返し測定 — 偏りと散らばりを分ける                            #
    # ------------------------------------------------------------------ #
    print("\n3) 雑音 1%%(振幅比)で %d 回測り直した結果 [nm]:" % N_TRIAL)
    print("   仕込んだ段差 |     偏り |  標準偏差 | 平均の標準誤差 | 偏りは有意か")
    rep, rep_sem = {}, {}
    for step in STEPS:
        bias, std, _, n_ok = repeat(step, 0.01)
        rep[step] = (bias, std)
        sem = std / np.sqrt(n_ok)
        rep_sem[step] = sem
        sig = "有意" if abs(bias) > 2 * sem else "雑音と区別できない"
        print("   %8.1f nm | %+8.2f | %9.2f | %14.2f | %s"
              % (step * 1000, bias, std, sem, sig))
    stds = [rep[s][1] for s in STEPS]
    print("   標準偏差は段差 50 nm と 500 nm で %.2f 倍しか変わらない"
          " = **不確かさは段差の大きさでなく光と画素数で決まる**"
          % (max(stds) / min(stds)))
    assert max(stds) / min(stds) < 2.0
    # 偏りは散らばりよりずっと小さい = この推定量は「ずれている」のではなく「ばらつく」
    assert all(abs(rep[s][0]) < rep[s][1] for s in STEPS)
    SHOWN.update(std_min_nm="%.1f" % min(stds), std_max_nm="%.1f" % max(stds),
                 bias_abs_nm="%.1f" % max(abs(rep[s][0]) for s in STEPS))
    assert all(abs(rep[s][0]) <= 2.0 * rep_sem[s] for s in STEPS), (rep, rep_sem)

    # 画素数を増やせば散らばりだけが減る(偏りは減らない)ことの確認
    single = np.array([measure_step(0.100, 0.01, s)[0] for s in range(1, 21)])
    _, stack = make_stack(0.100, 0.01, 1)
    hmap = I.csi_height_map(stack, DZ, 0.0, LAM, on_invalid="fill")
    px_std_nm = float(np.nanstd(hmap - make_stack(0.100, 0.0, 0)[0])) * 1000.0
    pred_nm = px_std_nm * np.sqrt(2.0 / (PH * PW))
    # 図: この PoC が測っている生データそのもの。左右 1 画素ずつの走査信号を
    #     重ねると、段差 100 nm = 縞周期 0.3 µm の 1/3 のずれとして見える。
    z_ax = 0.0 + DZ * np.arange(stack.shape[0])
    sel = (z_ax > BASE - 1.5) & (z_ax < BASE + 1.5)
    figs.save_plot("interferogram",
                   [("低い側(1 画素)", z_ax[sel], stack[sel, PH // 2, PW // 2]),
                    ("高い側(1 画素)", z_ax[sel], stack[sel, PH // 2, PW + PW // 2])],
                   xlabel="走査位置 z [µm]", ylabel="輝度",
                   title="コヒーレンス走査の生信号(段差 100 nm、雑音 1 %)",
                   caption="包絡線の中心が段差ぶんずれる。包絡線には周期が無いので"
                           "巻き戻る対象が無い(7 節)。")
    print("   1 画素あたりの散らばり %.1f nm → %d 画素の左右平均差の予測 %.1f nm、"
          "実測 %.1f nm(√N 則どおり)"
          % (px_std_nm, PH * PW, pred_nm, float(np.std(single, ddof=1)) * 1000))
    assert 0.5 < pred_nm / (float(np.std(single, ddof=1)) * 1000) < 2.0

    # ------------------------------------------------------------------ #
    # 4) ★ゼロ点(包絡線の最大サンプル)との比較                            #
    # ------------------------------------------------------------------ #
    print("\n4) ゼロ点 = 素朴な最大サンプル(`peak`)vs サブサンプル推定:")
    print("   走査ステップ 0.04 µm(段差 100 nm は 2.5 ステップ = 格子に載らない):")
    for mode in ("peak", "parabolic", "gaussian", "centroid"):
        got, _ = measure_step(0.100, 0.0, 0, mode=mode, dz=0.04, n_planes=301)
        print("      %-10s 雑音なし誤差 %+11.3e nm" % (mode, (got - 0.100) * 1000))
    peak_err = (measure_step(0.100, 0.0, 0, "peak", dz=0.04, n_planes=301)[0]
                - 0.100) * 1000
    gauss_err = (measure_step(0.100, 0.0, 0, "gaussian", dz=0.04, n_planes=301)[0]
                 - 0.100) * 1000
    print("   `peak` の誤差 %+.1f nm はちょうど走査ステップの半分(%.1f nm)。"
          % (peak_err, 0.04 * 1000 / 2))
    print("   サブサンプル推定は同じ走査データから %+.3e nm を返す = "
          "ゼロ点に対して %.0f 桁の改善。"
          % (gauss_err, np.log10(abs(peak_err) / max(abs(gauss_err), 1e-12))))
    assert abs(abs(peak_err) - 20.0) < 1e-6      # = dz/2 ちょうど
    assert abs(gauss_err) < 0.05

    # ゼロ点の誤差は雑音でも「小さな揺らぎ」でもなく、走査格子への丸め残差そのもの
    print("   ★`peak` の誤差は雑音由来ではない。走査格子への丸め残差"
          " dz·round(段差/dz) − 段差 に厳密一致する:")
    for dz, npl in ((0.02, 601), (0.04, 301), (0.05, 241), (0.08, 151),
                    (0.10, 121), (0.12, 101)):
        got, _ = measure_step(0.100, 0.0, 0, "peak", dz=dz, n_planes=npl)
        # numpy の round は偶数丸め。2.5 → 2 になるので予測もそれに合わせる
        pred = (dz * float(np.round(0.100 / dz)) - 0.100) * 1000
        print("      走査ステップ %.2f µm(段差 = %5.2f ステップ)→ 誤差 %+6.1f nm"
              "  予測 %+6.1f nm" % (dz, 0.100 / dz, (got - 0.100) * 1000, pred))
        assert abs((got - 0.100) * 1000 - pred) < 1e-6
    print("      → 最悪でステップの半分(%.1f nm @ 0.04 µm)。雑音を 0 にしても"
          "消えず、走査を細かくしないと減らない = **系統誤差**。" % (0.04 * 1000 / 2))

    # ------------------------------------------------------------------ #
    # 5) 走査ステップ掃引 — 細かくすれば良くなるのか                        #
    # ------------------------------------------------------------------ #
    print("\n5) 走査ステップを振る(走査全長 12 µm 固定、段差 100 nm、雑音 1%):")
    print("   z step | 面数 | 雑音なし誤差 |     偏り |  標準偏差 | 1 回の所要")
    sweep = {}
    for dz, npl in ((0.02, 601), (0.04, 301), (0.05, 241), (0.08, 151),
                    (0.10, 121), (0.12, 101), (0.14, 86)):
        clean, _ = measure_step(0.100, 0.0, 0, dz=dz, n_planes=npl)
        t0 = time.perf_counter()
        bias, std, _, _ = repeat(0.100, 0.01, dz=dz, n_planes=npl, n=16)
        dt = (time.perf_counter() - t0) / 16
        sweep[dz] = (clean - 0.100) * 1000
        print("   %6.2f | %4d | %+12.3f nm | %+8.2f | %9.2f | %7.1f ms"
              % (dz, npl, sweep[dz], bias, std, dt * 1000))
    dzs = sorted(sweep)
    figs.save_plot("zstep_sweep",
                   [("雑音なし誤差", dzs, [sweep[d] for d in dzs])],
                   xlabel="走査ステップ [µm]", ylabel="段差の誤差 [nm]",
                   title="走査ステップを細かくしても良くならない",
                   caption="0.02〜0.10 µm は雑音なし誤差 0.05 nm 以内で平ら、0.12 µm で %+.2f nm、"
                           "Nyquist 上限 %.2f µm の手前 0.14 µm で %+.1f nm の崖。"
                           % (sweep[0.12], DESIGN["max_z_step_um"], sweep[0.14]))
    print("   ★細かくしても良くならない。0.02 µm(601 面)は 0.10 µm(121 面)と同等で、"
          "計算量だけ 5 倍。局所当てはめは argmax 近傍 3 点しか見ないため。")
    print("   ★Nyquist 上限 λ/4 = %.2f µm の手前 0.14 µm で、雑音が無いのに誤差 %+.1f nm。"
          "**上限は安全な動作点ではない**(推奨 %.3f µm = λ/8 に余裕がある理由)。"
          % (DESIGN["max_z_step_um"], sweep[0.14], DESIGN["recommended_z_step_um"]))
    assert abs(sweep[0.14]) > 5.0          # Nyquist 手前で既に nm オーダーを外す
    SHOWN.update(zstep_012_nm="%+.2f" % sweep[0.12], zstep_014_nm="%+.1f" % sweep[0.14])
    assert max(abs(sweep[d]) for d in (0.02, 0.04, 0.05, 0.08, 0.10)) < 0.05
    # Nyquist を割ると拒否される(黙って間欠的に間違うより拒否を選んでいる)
    try:
        measure_step(0.100, 0.0, 0, dz=0.16, n_planes=76)
        print("   [FAIL] Nyquist 割れが拒否されなかった")
        return False
    except ValueError as exc:
        print("   走査ステップ 0.16 µm(> λ/4)は拒否: %s"
              % str(exc).split(" — ")[0][:72])

    # ------------------------------------------------------------------ #
    # 6) ★雑音掃引 — どこで測れなくなるか                                  #
    # ------------------------------------------------------------------ #
    print("\n6) 雑音を振る(段差 100 nm、%d 回)。"
          "総合誤差 = √(偏り² + 標準偏差²):" % N_TRIAL)
    print("   雑音 |            gaussian             |           centroid"
          "             | 画素拒否")
    print("        |    偏り  標準偏差    総合        |    偏り  標準偏差    総合")
    limit_nm = 0.100 * 1000 * 0.10          # 段差の 10% を「測れた」の線とする
    boundary = {}
    rows6 = {}                              # 見出しの数の門に使う(表と同じ数字)
    noise_pts = []                          # 図用。表と同じ数字を溜めるだけ
    for noise in (0.002, 0.005, 0.01, 0.02, 0.05, 0.10, 0.20, 0.50):
        row = {}
        rej = 0.0
        for mode in ("gaussian", "centroid"):
            b, s, r, _ = repeat(0.100, noise, mode=mode)
            row[mode] = (b, s, float(np.hypot(b, s)))
            rej = r
        for mode in ("gaussian", "centroid"):
            if row[mode][2] <= limit_nm:
                boundary[mode] = noise
        rows6[noise] = row
        noise_pts.append((noise, row["gaussian"][2], row["centroid"][2]))
        print("   %5.3f | %+7.2f %8.2f %8.2f nm | %+7.2f %8.2f %8.2f nm | %5.1f%%"
              % (noise, *row["gaussian"], *row["centroid"], 100 * rej))
    nx = [np.log10(p[0]) for p in noise_pts]
    figs.save_plot("noise_sweep",
                   [("gaussian 総合誤差", nx, [np.log10(p[1]) for p in noise_pts]),
                    ("centroid 総合誤差", nx, [np.log10(p[2]) for p in noise_pts]),
                    ("測れたの線(段差の 10 %)", nx,
                     [np.log10(limit_nm)] * len(noise_pts))],
                   xlabel="log10 雑音(振幅比)", ylabel="log10 総合誤差 [nm]",
                   title="どこで測れなくなるか(段差 100 nm)",
                   caption="centroid は散らばりが gaussian の 1/3〜1/5 なのに"
                           "総合誤差では上に来る。差の正体は段差を縮める"
                           "ゲイン誤差(下の表)。")
    print("   測れなくなる境目(総合誤差が段差の 10%% = %.0f nm を超える点):"
          % limit_nm)
    for mode in ("gaussian", "centroid"):
        print("      %-9s 雑音 %.3f までは 10%% 以内" % (mode, boundary[mode]))
    assert boundary["gaussian"] <= 0.01 and boundary["centroid"] <= 0.01
    SHOWN["noise_limit_pct"] = "%.1f" % (100 * boundary["gaussian"])

    # ★散らばりが小さいことは正しさの証拠にならない
    print("\n   ★`centroid` は散らばりが `gaussian` の 1/3〜1/5 なのに、雑音とともに"
          "**段差そのものを縮める**:")
    print("   雑音 | 段差 50 nm | 100 nm | 200 nm | 500 nm |  ゲイン(測定/真値)")
    gain_at = {}
    gain_rows = []
    for noise in (0.0, 0.01, 0.03, 0.10):
        gains, cells = [], []
        for step in STEPS:
            b, _, _, _ = repeat(step, noise, mode="centroid", n=16)
            gains.append((step * 1000 + b) / (step * 1000))
            cells.append("%+7.1f" % b)
        gain_at[noise] = float(np.mean(gains))
        gain_rows.append(["%.2f" % noise] + [c.strip() for c in cells]
                         + ["%.4f" % gain_at[noise]])
        print("   %4.2f | %s | %.4f ± %.4f"
              % (noise, " | ".join(cells), gain_at[noise], float(np.std(gains))))
    figs.save_table("centroid_gain",
                    ["雑音"] + ["%.0f nm の偏り" % (1000 * s) for s in STEPS]
                    + ["ゲイン"],
                    gain_rows,
                    title="centroid は段差そのものを縮める(偏り [nm])",
                    caption="4 種の段差でゲインが揃う = オフセットではなく倍率の"
                            "誤差。再現性を精度と読み替えるとここで嘘をつく。")
    g_lo, g_mid, g_hi = gain_at[0.0], gain_at[0.03], gain_at[0.10]
    print("   ゲインが段差 4 種でほぼ揃う = これはオフセットではなく**倍率の誤差**。"
          "雑音 0 で %.3f、3%% で %.3f、10%% で %.3f まで落ちる。"
          % (g_lo, g_mid, g_hi))
    print("   同じ雑音 10%% で `gaussian` の標準偏差は %.1f nm、`centroid` は %.1f nm。"
          "再現性だけを見ると `centroid` が最良に見えるので、"
          "**再現性を精度と読み替えるとここで嘘をつく**。"
          % (repeat(0.100, 0.10, mode="gaussian", n=16)[1],
             repeat(0.100, 0.10, mode="centroid", n=16)[1]))
    assert g_lo > 0.999 and g_hi < 0.9      # 雑音で倍率が落ちる
    s_c, s_g = rows6[0.01]["centroid"][1], rows6[0.01]["gaussian"][1]
    assert s_c < s_g, (s_c, s_g)
    SHOWN.update(centroid_std_nm="%.1f" % s_c, gaussian_std_nm="%.1f" % s_g,
                 centroid_shrink_pct="%.0f" % (100 * (1 - gain_at[0.01])))

    # ------------------------------------------------------------------ #
    # 7) 系統誤差探し — λ/2 の巻き戻りは出るか                              #
    # ------------------------------------------------------------------ #
    print("\n7) 段差を λ/2 = %.2f µm の整数倍に近づける(位相の巻き戻りを探す):"
          % (LAM / 2))
    print("   段差 | 段差/(λ/2) | コヒーレンス法の誤差 | 位相シフト法の誤差")
    gain_rad = 4.0 * np.pi / LAM                       # rad/µm(往復)
    worst_csi = 0.0
    wrapped = []
    phase_errors = {}
    for step in (0.10, 0.149, 0.151, 0.299, 0.300, 0.301, 0.599, 0.600, 0.900):
        csi, _ = measure_step(step, 0.0, 0)
        truth = np.full((PH, 2 * PW), 0.0)
        truth[:, PW:] = step
        imgs = fringe.synthesize_fringes(truth, n_steps=4, freq=0.0,
                                         phase_gain=gain_rad, bias=0.5,
                                         amplitude=0.4)
        rec = fringe.decode_fringe(imgs, k=1.0 / gain_rad)
        psi = float(rec[:, PW:].mean() - rec[:, :PW].mean())
        phase_errors[step] = psi - step
        worst_csi = max(worst_csi, abs(csi - step))
        note = ""
        if abs(psi - step) > 1e-6:
            orders = (psi - step) / (LAM / 2)
            note = "  = λ/2 × %+d(縞次数の飛び)" % round(orders)
            wrapped.append(step)
        print("   %.3f |   %6.3f    | %+13.3e nm | %+10.4f µm%s"
              % (step, step / (LAM / 2), (csi - step) * 1000, psi - step, note))
    print("   ★予想は外れた。**コヒーレンス法では λ/2 の巻き戻りが一度も出ない**"
          "(最悪 %.3e nm)。" % (worst_csi * 1000))
    print("   包絡線には周期が無いので巻き戻る対象が存在しない。同じ表面で位相シフト法は"
          " λ/4 = %.3f µm を超えた %d 点すべてで縞次数を飛ばしている。"
          % (LAM / 4, len(wrapped)))
    print("   「出るはずのものが出ない」ことが、この族を `fringe` の隣に置いた理由。")
    assert worst_csi * 1000 < 0.05
    assert 0.149 not in wrapped and 0.151 in wrapped   # 境界は λ/4 ちょうど
    SHOWN.update(phase_limit_um="%.3f" % (LAM / 4), phase_below_um="%.3f" % 0.149,
                 phase_above_um="%.3f" % 0.151, phase_jump_um="%+.3f" % phase_errors[0.151])

    # ------------------------------------------------------------------ #
    # 所見 — 想定と違ったこと / 途中で自分が間違えたこと                     #
    # ------------------------------------------------------------------ #
    print("\n所見(想定と違ったこと):")
    print("   (a) λ/2 の巻き戻りを探して見つからなかった。7) のとおり、これは"
          "バグではなく包絡線法の定義そのもの。予想を書いた側が間違っていた。")
    print("   (b) 最初、画素ごとの誤差を λ/2 で丸めて数えたら 0/±1 次に 3 割が"
          "落ちたので「縞次数の飛びだ」と読んだ。ヒストグラムを引いたら ±λ/2 に"
          "広がった単峰で、丸めた瞬間に 3 本の柱に見えていただけだった。"
          "**量子化を主張する前に、丸めていない分布を見る**。")
    print("   (c) 走査を細かくすれば精度が上がる、は成り立たない(5)。局所当てはめは"
          " argmax 近傍 3 点しか見ないので、面数を 5 倍にしても散らばりは変わらず"
          "時間だけ増える。")
    print("   (d) 再現性が最良の推定量が最良とは限らない(6)。`centroid` は"
          " `gaussian` の 1/3〜1/5 の散らばりを保ったまま、雑音 3%% で段差を"
          " %.0f%% 縮める。真値を仕込まない繰り返し測定では検出できない種類の"
          "誤りで、これが「真値は自分で決める」規律の根拠。" % (100 * (1 - g_mid)))
    print("\n所見(fullseye の穴):")
    print("   (e) `csi_design` は `max_z_step_um` = %.3f µm(λ/4)を返すが、5) の"
          "とおりその手前 0.14 µm で既に雑音なし誤差 %+.1f nm が出る"
          "(0.02〜0.12 µm はいずれも %.3f nm 以内)。`recommended_z_step_um` = %.3f µm"
          "(λ/8)を使えば実用上問題ないが、**上限と実用限界の差が返り値からは"
          "読めない**。"
          % (DESIGN["max_z_step_um"], sweep[0.14],
             max(abs(sweep[d]) for d in (0.02, 0.04, 0.05, 0.08, 0.10, 0.12)),
             DESIGN["recommended_z_step_um"]))
    print("   (f) `on_invalid=\"fill\"` の画素拒否率は返り値に出ず、NaN を自分で"
          "数えるしかない(6 の右端列)。雑音 5% で 3 割、20% で 5 割が落ちており、"
          "拒否率は測定の信頼度そのもの。拒否数を返す口があると下流で使いやすい。")

    # 動画は既存の図の**最後**に書く(番号が後ろの図のファイル名をずらさないように)。
    if figs.enabled():
        fig_step_sweep_video()
        fig_csi_scan_explained(surface_result)
    if figs.errors():
        print("図の書き出しで失敗:", "; ".join(figs.errors()))

    check_headline()
    print("\n総所要 %.1f 秒" % (time.perf_counter() - t_all))
    print("\nPASS: 既知の段差 50/100/200/500 nm に対し、雑音なしで %.3f nm 以内、"
          "雑音 1%% で偏り %.1f nm 以内・標準偏差 %.1f nm 以内で測り返した"
          % (floor_nm, max(abs(rep[s][0]) for s in STEPS),
             max(rep[s][1] for s in STEPS)))
    return True


if __name__ == "__main__":
    raise SystemExit(0 if main() else 1)
