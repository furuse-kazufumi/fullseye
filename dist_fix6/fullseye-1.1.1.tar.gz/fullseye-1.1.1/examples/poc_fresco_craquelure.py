# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""絵画のひび割れ網(craquelure)を測る —— 3 指標のうち撮影条件で壊れるのは分岐次数だけ。

絵画・壁画の表面に走る**ひび割れの網**を撮影画像から定量し、乾燥ひび(塗膜が
乾くときに縮んでできる、セルが小さく曲がりくねった網)と経年ひび(支持体の
伸縮で何十年もかけてできる、セルが大きく直線的で格子に近い網)を**数字で分ける**、
という文化財調査の仕事です。真贋鑑定では「網の統計が年代と矛盾しないか」が
論点になるので、**指標のどれが照明や撮影条件で動くか**を知らずには使えません。

EXTEND: 実写に差し替えるなら :func:`make_scene` が返す辞書の ``img`` を撮影画像に
置き換えます。真値(``label`` = セルの番地、``edges`` = ひびの折れ線)は実写では
得られないので、指標の**絶対値**ではなく、この PoC で測った**条件依存の向きと大きさ**
(斜光で幅が片側に太る量、質感で偽陽性がどう増えるか、セル径が壁の分だけ小さく
出ること)を持ち込んでください。斜光の向きと強さは撮影記録から取れるはずで、
それが無い写真の網統計は比較に使えません。人為的な模造(乾燥ひびを熱で作る等)は
本 PoC では作っていない —— 2 種の真値の**中間**を自分で仕込んで同じ表を作ること。

この PoC が示すこと(数字はいずれも実行時に印字される実測値):

1. **ゼロ点(暗い画素を大津で数える)は、ひび画素率をそのまま返さない**。
   きれいな条件(質感なし・斜光なし)でも ひび画素率 真値 10.18 % に対して
   推定 28.10 %(2.8 倍。ぼけた縁まで数える)。質感(コントラスト 0.08)を入れると
   44.55 %(4.4 倍)—— 絵の具の色斑が「ひび」に数えられる。
2. **リッジ op → ヒステリシス → 面積オープニング → 骨格 → 枝刈り → 分岐点/端点/枝
   の op 列で網は取れる**。xsk_meijering は既定条件(質感 0.08・ぼけ 0.8 px・雑音)で
   中心線の再現率 0.978 / 適合率 0.961(許容 2 px)、斜光でもセル 50 個(真値 52)。
   ★**sk_frangi は分岐点で応答が落ちる(Frangi の設計どおり)ので、斜光でセルが
   16 個に崩れる**。★そして正直に書くと、**暗さそのもの(cv_blackhat)が 3 種の
   リッジ op より全条件で上**(再現率 0.996 / 0.995 / 0.987)—— ひびが常に暗い合成
   では当然で、リッジ op が要るのは暗さが一様でない実写のほう。以後は
   xsk_meijering で測る。
3. ★**3 指標の分離力と壊れ方は別物**。乾燥 vs 経年で、真値の平均セル径は 18.0 vs
   45.2 px(2.5 倍)、直線度(弦/弧)は 0.960 vs 1.000、次数 4 以上の分岐点の割合は
   0.20 vs 0.83。3 つとも 2 種を分ける。ところが経年型で、きれいな条件の
   次数 4 割合 0.87 が **質感で 0.64、斜光(強さ 1.0)で 0.70** と乾燥側へ動く。
   セル径は 41.7 → 40.4 / 41.7 px、直線度は 0.978 → 0.966 / 0.983 で動かない。
   ★予想は「斜光で直線度が壊れる(片側の影で骨格が蛇行する)」だったが、実測で
   壊れたのは**分岐次数** —— 質感は 3 差路の偽分岐を足して割合を薄め、斜光は
   4 差路を 3 差路 2 個に割る。セル径の推定は壁(骨格を 1 px 太らせた 3 px)の分だけ
   一定に小さい(乾燥 3.7 px / 経年 3.5 px 不足)ので引き算で戻る。異方性は真値 0.09
   に対して推定 0.20 と上に偏るが、条件を変えても 0.17〜0.20 で動かない。
4. ★**ひび幅の崖は来なかった(予想は外れた)**。幅 0.15 → 4 px の掃引で、幾何の予想
   (ぼけ後の点コントラスト = 深さ × erf(w / 2√2σ) が質感の 2 倍を割る幅)は 0.60 px
   だったが、実測は 0.5 px でも再現率 0.926、0.15 px でも 0.696 —— 崖ではなく緩い坂。
   線検出は線に沿って積分するので、点のコントラストでは予想できない。先に壊れる
   のは適合率(0.5 px で 0.784)と**幅の推定**: 真値 0.5 px → 2.41 px(4.8 倍)、
   1.0 px → 1.94 px、4.0 px → 3.63 px。ぼけ σ 0.8 px の半値幅 1.9 px が下限を作る。
5. ★**質感でも偽陽性は爆発しなかった(予想は外れた)**。予想は「色斑の最暗部 3σ が
   ひびの深さ 0.55 に届く c ≈ 0.18 で爆発」。実測の 偽陽性長/真値長 は c = 0.16 で
   0.141、0.32 で 0.273、0.64 で 0.382 と直線的に増えるだけ —— ヒステリシスの
   しきい値がリッジ応答の最大値に相対で、面積オープニングが小さい島を落とすから。
   代わりに再現率が 0.981 → 0.871 と削れる。ゼロ点(大津)は c = 0.08 で 44.6 %。
6. **斜光は幅を片側に太らせる**。強さ 0 → 1 で推定幅 2.49 → 2.86 px(真値 2 px、
   +0.37 px)、検出した中心線は光源側へ 0.75 px ずれる(影の側だけが暗いので、
   半値幅のマスクがそちらへ伸びる)。異方性は 0.20 → 0.19 で動かない。
7. **ぼけがセルの小ささの下限を決める**。セル径 8 / 12 / 16 / 24 px × ぼけ σ 0.5〜3 px
   の表で、セル数の再現率 0.9 を保つ最小径は σ=1 で 8 px、σ=2 で 12 px、σ=3 で
   16 px(径 8 px は σ=3 で 0.16)—— **径 < 5σ + 幅** で隣のひびがぼけで融合する、
   という目安(σ=2 → 12 px、σ=3 → 17 px)と一致。
8. **対照群**: 乾燥型は質感でも斜光でも次数 4 割合 0.25 → 0.21〜0.25 で動かない。
   壊れるのは**格子的な網の 4 差路だけ**で、乾燥ひびの統計は撮影条件に強い。

【グラウンドトゥルース】
網は**種点のボロノイ図**を閉形式で描く。種点は格子 + 乱れ(規則性 β: 1 で完全格子、
0 で一様乱数)、経年型は長方格子(縦横比 1.3)で異方性も仕込む。蛇行は座標を低周波
の正弦で歪める(ドメインワープ、逆写像は不動点反復)。ひび = ボロノイ辺(画像座標の
折れ線)までの距離が幅の半分より小さい画素で、被覆率で反エイリアス(幅 0.15 px も
描ける)。その上に 絵の具の色斑(ガウス平滑した乱数、コントラスト c)、ニスの光沢むら
(低周波の乗算)、斜光(溝の斜面の勾配 × 強さ s、光源の反対側の壁が明るく手前が影)、
ガウスぼけ、雑音を足す。真値の統計(セル面積・分岐次数・直線度・異方性)はボロノイの
頂点・辺から幾何で出す(画像処理を通さない)。分岐点は真値・検出とも 3 px で束ね、
次数は半径 4 px の環を横切る本数で数える。

来歴(公開文献のみ): Frangi らの管状構造フィルタ(MICCAI 1998)、Meijering らの
neuriteness フィルタ(Cytometry 2004)、Bucklow "The description of craquelure
patterns" (Studies in Conservation 1997、乾燥ひびと経年ひびの分類軸 = セル径・直線性・
網の規則性)、ボロノイ図(Okabe et al. 2000)。
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
from scipy import ndimage as ndi
from scipy.spatial import Voronoi, cKDTree

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import examplefig as figs                                        # noqa: E402
import fullseye as fs                                            # noqa: E402

# --------------------------------------------------------------------------- #
N_PIX = 320            # 視野 [px]
SEED = 7
K_CRACK = 0.55         # ひびの深さ(暗さ、反射率の落ち)
BASE_ALBEDO = 0.72     # 絵の具の平均反射率
TEX_LEN = 5.0          # 色斑の相関長 [px]
GLOSS_AMP = 0.10       # ニスの光沢むら(乗算、低周波)
BLUR_SIG = 0.8         # 撮影のぼけ σ [px]
NOISE_SIG = 0.01       # 雑音 σ
TEX_C = 0.08           # 既定の色斑コントラスト(標準偏差)
TOL_PX = 2.0           # 中心線の照合許容 [px]
MERGE_PX = 3.0         # 分岐点を 1 つに数える半径 [px](真値・検出とも)
RING_PX = 4.0          # 分岐次数を数える環の半径 [px]

# 2 種のひび網(Bucklow 1997 の分類軸)
TYPES = {
    "乾燥": dict(cell=16.0, beta=0.3, aspect=1.0, warp_amp=1.2, warp_len=11.0, width=2.0),
    "経年": dict(cell=40.0, beta=0.92, aspect=1.3, warp_amp=0.3, warp_len=60.0, width=2.0),
}

_LAB = fs.ledger       # blob 族の公開経路


# --------------------------------------------------------------------------- #
# 1. 真値の網とシーン                                                            #
# --------------------------------------------------------------------------- #
def _warp_field(n: int, amp: float, wl: float, rng) -> tuple[np.ndarray, np.ndarray]:
    """座標の歪み D(y, x) = (dy, dx)。低周波の正弦 2 成分(閉形式)。"""
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    ph = rng.uniform(0, 2 * np.pi, 4)
    k = 2 * np.pi / wl
    dy = amp * np.sin(k * xx + ph[0]) * np.cos(0.7 * k * yy + ph[1])
    dx = amp * np.sin(k * yy + ph[2]) * np.cos(0.7 * k * xx + ph[3])
    return dy, dx


def make_net(kind: str, rng, n: int = N_PIX, **over) -> dict:
    """ボロノイ網の真値。``label``(セル番地)、``e``(二等分線までの距離)、
    ``edges``(画像座標の折れ線 = 辺)、``verts``(頂点)を返す。"""
    p = dict(TYPES[kind])
    p.update(over)
    cell, beta, asp = p["cell"], p["beta"], p["aspect"]
    sy, sx = cell * np.sqrt(asp), cell / np.sqrt(asp)      # 面積を保って縦横比 asp
    pad = 3 * cell
    gy = np.arange(-pad, n + pad, sy)
    gx = np.arange(-pad, n + pad, sx)
    GY, GX = np.meshgrid(gy, gx, indexing="ij")
    jit = (1.0 - beta) * 0.5
    seeds = np.stack([GY.ravel() + rng.uniform(-jit * sy, jit * sy, GY.size),
                      GX.ravel() + rng.uniform(-jit * sx, jit * sx, GX.size)], 1)
    dy, dx = _warp_field(n, p["warp_amp"], p["warp_len"], rng)
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    q = np.stack([(yy + dy).ravel(), (xx + dx).ravel()], 1)      # 歪めた座標
    _, idx = cKDTree(seeds).query(q, k=1)
    label = idx.reshape(n, n)                                     # セルの番地(歪み込み)

    # 幾何の真値: 頂点と辺(歪めた座標系 → 画像座標へ逆写像)
    vor = Voronoi(seeds)
    def inv_warp(pts):
        """x' = x + D(x) の逆。|∇D| < 1 なので不動点反復で収束(40 回)。"""
        x = pts.copy()
        for _ in range(40):
            yi = np.clip(x[:, 0], 0, n - 1)
            xi = np.clip(x[:, 1], 0, n - 1)
            dyi = ndi.map_coordinates(dy, [yi, xi], order=1)
            dxi = ndi.map_coordinates(dx, [yi, xi], order=1)
            x = pts - np.stack([dyi, dxi], 1)
        return x
    edges, dense = [], []
    for (v0, v1) in vor.ridge_vertices:
        if v0 < 0 or v1 < 0:
            continue
        a, b = vor.vertices[v0], vor.vertices[v1]
        if not (np.all(a > -cell) and np.all(a < n + cell) and
                np.all(b > -cell) and np.all(b < n + cell)):
            continue
        L = float(np.hypot(*(b - a)))
        m = max(3, int(np.ceil(L / 0.3)) + 1)
        t = np.linspace(0, 1, m)[:, None]
        poly = inv_warp(a[None, :] * (1 - t) + b[None, :] * t)
        dense.append(poly)
    edges = dense
    verts = inv_warp(vor.vertices)
    # ひびの中心線までの距離(画像座標)。歪みがあっても幅は画像座標で厳密。
    pts = np.concatenate(dense, 0)
    e, _ = cKDTree(pts).query(np.stack([yy.ravel(), xx.ravel()], 1), k=1)
    e = e.reshape(n, n)
    return dict(label=label, e=e, edges=edges, verts=verts, vor=vor, width=p["width"],
                seeds=seeds)


def render(net: dict, rng, tex_c: float = TEX_C, rake: float = 0.0,
           blur: float = BLUR_SIG, noise: float = NOISE_SIG, width: float | None = None,
           gloss: float = GLOSS_AMP) -> dict:
    """真値の網からシーン画像を作る。斜光は -x 方向(左)から。"""
    n = net["label"].shape[0]
    w = net["width"] if width is None else width
    e = net["e"]
    cover = np.clip(w / 2 - e + 0.5, 0.0, 1.0)                   # 反エイリアスの被覆率
    # 絵の具の色斑(ガウス平滑した乱数、標準偏差を tex_c に合わせる)
    tex = ndi.gaussian_filter(rng.normal(0, 1, (n, n)), TEX_LEN)
    tex = tex / (tex.std() + 1e-12) * tex_c
    # ニスの光沢むら(低周波、乗算)
    gl = ndi.gaussian_filter(rng.normal(0, 1, (n, n)), 40.0)
    gl = 1.0 + gl / (gl.std() + 1e-12) * gloss
    albedo = np.clip(BASE_ALBEDO + tex, 0.05, 1.0)
    img = albedo * gl * (1.0 - K_CRACK * cover)
    # 斜光: 溝の斜面 h = -exp(-(e/σw)^2)、∂h/∂x > 0 の壁(光源の反対側の壁)が明るい
    sig_w = w / 2 + 0.6
    h = -np.exp(-(e / sig_w) ** 2)
    dh_dx = np.gradient(h, axis=1)
    img = img + rake * 0.9 * dh_dx * gl
    img = ndi.gaussian_filter(img, blur) if blur > 0 else img
    img = img + rng.normal(0, noise, (n, n))
    return dict(img=np.clip(img, 0, 1), cover=cover, width=w, tex_c=tex_c, rake=rake,
                blur=blur)


_SCENES: dict = {}


def make_scene(kind: str, seed: int = SEED, **kw) -> dict:
    """同じ引数なら同じシーン(決定的)。何度も呼ぶので memo する。"""
    key = (kind, seed, tuple(sorted(kw.items())))
    if key in _SCENES:
        return _SCENES[key]
    rng = np.random.default_rng(seed)
    net = make_net(kind, rng, **{k: v for k, v in kw.items()
                                 if k in ("cell", "beta", "aspect", "warp_amp", "warp_len", "n")})
    ren = render(net, rng, **{k: v for k, v in kw.items()
                              if k in ("tex_c", "rake", "blur", "noise", "width", "gloss")})
    sc = dict(net)
    sc.update(ren)
    sc["kind"] = kind
    _SCENES[key] = sc
    return sc


_MEAS: dict = {}


def measure_scene(sc: dict) -> dict:
    """既定の op 列(xsk_meijering)で測る。同じシーンは memo。"""
    key = id(sc)
    if key not in _MEAS:
        det = extract_net(sc["img"])
        me = measure(sc, det)
        me["det"] = det
        _MEAS[key] = me
    return _MEAS[key]


# --------------------------------------------------------------------------- #
# 2. 真値の統計(幾何から)                                                       #
# --------------------------------------------------------------------------- #
def _cluster_points(pts: np.ndarray, r: float) -> np.ndarray:
    """距離 r 以内の点を同じ群にする(union-find)。群番号を返す。"""
    m = len(pts)
    parent = np.arange(m)
    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    if m:
        for i, j in cKDTree(pts).query_pairs(r):
            ri, rj = find(i), find(j)
            if ri != rj:
                parent[ri] = rj
    return np.asarray([find(i) for i in range(m)])


def truth_stats(sc: dict) -> dict:
    n = sc["label"].shape[0]
    lab = sc["label"]
    # セル: 視野の縁に触れないセルの面積(画素数) → 等価直径
    border = np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))
    ids, cnt = np.unique(lab, return_counts=True)
    keep = ~np.isin(ids, border)
    area = cnt[keep].astype(float)
    diam = np.sqrt(4 * area / np.pi)
    # 分岐次数: 視野内の頂点を MERGE_PX で束ね、束から出る辺の本数
    vor, verts = sc["vor"], sc["verts"]
    inside = np.all((verts > RING_PX + 2) & (verts < n - RING_PX - 3), axis=1)
    vid = np.nonzero(inside)[0]
    grp = _cluster_points(verts[vid], MERGE_PX)
    g_of = dict(zip(vid.tolist(), grp.tolist()))
    deg = {}
    for (v0, v1) in vor.ridge_vertices:
        if v0 < 0 or v1 < 0:
            continue
        g0, g1 = g_of.get(v0), g_of.get(v1)
        if g0 is not None and g1 is not None and g0 == g1:
            continue                                    # 束の内側の短い辺
        if g0 is not None:
            deg[g0] = deg.get(g0, 0) + 1
        if g1 is not None:
            deg[g1] = deg.get(g1, 0) + 1
    degs = np.asarray(list(deg.values()), float)
    # 直線度と異方性: 辺の折れ線(画像座標)から
    st, L, th = [], [], []
    for poly in sc["edges"]:
        seg = np.diff(poly, axis=0)
        arc = float(np.hypot(seg[:, 0], seg[:, 1]).sum())
        chord = float(np.hypot(*(poly[-1] - poly[0])))
        if arc < 4 or not np.all((poly > 0) & (poly < n - 1)):
            continue
        st.append(chord / arc)
        L.append(chord)
        th.append(np.arctan2(poly[-1][0] - poly[0][0], poly[-1][1] - poly[0][1]))
    L = np.asarray(L)
    th = np.asarray(th)
    aniso = float(abs((L * np.exp(2j * th)).sum()) / L.sum()) if L.size else 0.0
    return dict(n_cells=int(keep.sum()), diam=float(diam.mean()), diam_all=diam,
                deg4=float((degs >= 4).mean()) if degs.size else 0.0, n_junc=int(degs.size),
                degs=degs, straight=float(np.mean(st)) if st else 0.0, aniso=aniso,
                crack_frac=float(sc["cover"].mean()),
                len_true=float(sum(np.hypot(*np.diff(p, axis=0).T).sum() for p in sc["edges"])))


# --------------------------------------------------------------------------- #
# 3. 測定(fullseye の op 列)                                                    #
# --------------------------------------------------------------------------- #
def zero_point(img: np.ndarray) -> float:
    """ゼロ点: 反転画像の大津しきい値で暗い画素を数える → ひび画素率。"""
    m = np.asarray(fs.apply(1.0 - img, "otsu"))
    return float(m.mean())


def extract_net(img: np.ndarray, ridge: str = "xsk_meijering", a_lo: float = 0.0,
                b_hi: float = 0.0) -> dict:
    """リッジ検出 → ヒステリシス → 面積オープニング → 骨格 → 枝刈り → 分岐点/端点/枝。

    ``ridge`` は fullseye のリッジ op 名(``xsk_meijering`` / ``xsk_sato`` /
    ``sk_frangi``)か、``"cv_blackhat"``(暗さそのもの、対照用)。
    """
    if ridge == "cv_blackhat":
        resp = np.asarray(fs.apply(img, "cv_blackhat", a=1.0, b=0.5))   # 構造要素 9 px
    else:
        resp = np.asarray(fs.apply(img, ridge, a=0.5, b=0.5))           # 暗いリッジ、σ=1..3
    mask = np.asarray(fs.apply(resp, "hysteresis_threshold", a=a_lo, b=b_hi))
    mask = np.asarray(fs.apply(mask, "sk_area_opening", a=0.0))         # 16 px 未満の島を消す
    skel = np.asarray(fs.apply(mask, "skeleton"))
    skel = np.asarray(fs.apply(skel, "pruning", a=0.25)) > 0.5          # ヒゲ 2 回
    junc = np.asarray(fs.apply(skel.astype(float), "junctions_skeleton")) > 0.5
    ends = np.asarray(fs.apply(skel.astype(float), "r2_endpoints_skeleton")) > 0.5
    branch = np.asarray(fs.apply(skel.astype(float), "hx_split_skeleton_region")) > 0.5
    # 幅: ブラックハット(周囲より暗い量、最大値で正規化される)を、骨格上の典型値の半分で
    # 切った暗画素マスク(= 半値幅)。面積 / 骨格の弧長 が幅。
    bh = np.asarray(fs.apply(img, "cv_blackhat", a=1.0, b=0.5))
    half = 0.5 * float(np.median(bh[skel])) if skel.any() else 0.5
    dark = np.asarray(fs.apply(bh, "threshold", a=half)) > 0.5
    return dict(resp=resp, mask=mask > 0.5, skel=skel, junc=junc, ends=ends,
                branch=branch, dark=dark)


def _true_center(sc: dict) -> np.ndarray:
    """真値の中心線(e が局所最小 かつ e < 0.75 px)。"""
    return sc["e"] < 0.75


def measure(sc: dict, det: dict) -> dict:
    n = sc["label"].shape[0]
    skel = det["skel"]
    # --- 中心線の再現率・適合率(許容 TOL_PX) ---
    tc = _true_center(sc)
    d_true = ndi.distance_transform_edt(~tc)          # 真値中心線までの距離
    d_det = ndi.distance_transform_edt(~skel)
    recall = float((d_det[tc] <= TOL_PX).mean())
    prec = float((d_true[skel] <= TOL_PX).mean()) if skel.any() else 0.0
    fp_len = float((d_true[skel] > TOL_PX).sum())
    # 中心線の横ずれ(x 方向、光源側が負): 検出画素から最寄り真値中心線への変位
    iy, ix = ndi.distance_transform_edt(~tc, return_distances=False, return_indices=True)
    dxs = (ix - np.arange(n)[None, :])[skel & (d_true <= TOL_PX)]
    # 縦のひび(x にずれると横方向に変位が出る)だけで平均すると意味が明瞭
    offs = float(-np.mean(dxs)) if dxs.size else 0.0
    # --- 幅: 暗画素マスクの EDT × 2 を骨格上で(公開経路の距離変換は正規化されるので scipy) ---
    # (暗画素マスクのうち骨格につながる成分だけ数え、面積 / 骨格の弧長)
    dl, _ = ndi.label(det["dark"], np.ones((3, 3), int))
    keep_d = np.isin(dl, np.unique(dl[skel & det["dark"]]))
    keep_d &= dl > 0
    skl_len = _arc_length(skel)
    width = float(keep_d.sum() / skl_len) if skl_len > 0 else 0.0
    # --- セル: 骨格を 1 px 太らせた補集合の連結成分 ---
    wall = ndi.binary_dilation(skel, np.ones((3, 3), bool))
    lab = np.asarray(_LAB.blob_label(~wall))
    f = _LAB.blob_features(lab)
    keep = ~np.asarray(f["touches_border"], bool)
    area = np.asarray(f["area"], float)[keep]
    diam = np.sqrt(4 * area / np.pi)
    # --- 分岐次数: 分岐点を MERGE_PX で束ね、束の中心から半径 RING_PX の環を横切る骨格の本数 ---
    jy, jx = np.nonzero(det["junc"])
    jpts = np.stack([jy, jx], 1).astype(float)
    grp = _cluster_points(jpts, MERGE_PX)
    degs = []
    r0, r1 = RING_PX - 1.0, RING_PX + 1.0
    for g in np.unique(grp):
        cy, cx = jpts[grp == g].mean(0)
        y0, y1 = int(max(0, cy - r1 - 1)), int(min(n, cy + r1 + 2))
        x0, x1 = int(max(0, cx - r1 - 1)), int(min(n, cx + r1 + 2))
        if y0 <= 0 or x0 <= 0 or y1 >= n or x1 >= n:
            continue                                            # 縁の束は数えない
        sub = skel[y0:y1, x0:x1]
        yy, xx = np.mgrid[y0:y1, x0:x1]
        rr = np.hypot(yy - cy, xx - cx)
        ring = sub & (rr >= r0) & (rr <= r1)
        _, k = ndi.label(ring, np.ones((3, 3), int))
        degs.append(k)
    degs = np.asarray(degs, float)
    bl = np.asarray(_LAB.blob_label(det["branch"]))
    # --- 直線度・異方性: 枝ごとに 弦 / 弧 ---
    st, L, th = [], [], []
    nb = ndi.convolve(det["branch"].astype(int), np.ones((3, 3), int), mode="constant") - 1
    for k, sl in enumerate(ndi.find_objects(bl), start=1):
        if sl is None:
            continue
        m = bl[sl] == k                                   # 枝の外接箱だけ見る(速さのため)
        if m.sum() < 6:
            continue
        end = m & (nb[sl] <= 1)
        ey, ex = np.nonzero(end)
        if len(ey) != 2:
            continue
        # 弧長: 4 近傍の歩幅 1、斜めの歩幅 √2
        arc = _arc_length(m)
        chord = float(np.hypot(ey[1] - ey[0], ex[1] - ex[0]))
        if arc <= 0:
            continue
        st.append(min(1.0, chord / arc))
        L.append(chord)
        th.append(np.arctan2(ey[1] - ey[0], ex[1] - ex[0]))
    L = np.asarray(L)
    th = np.asarray(th)
    aniso = float(abs((L * np.exp(2j * th)).sum()) / L.sum()) if L.size else 0.0
    return dict(recall=recall, prec=prec, fp_ratio=fp_len, offset=offs, width=width,
                n_cells=int(keep.sum()), diam=float(diam.mean()) if diam.size else 0.0,
                diam_all=diam, deg4=float((degs >= 4).mean()) if degs.size else 0.0,
                n_junc=int(degs.size), degs=degs,
                straight=float(np.mean(st)) if st else 0.0, aniso=aniso,
                labels=lab)


def _arc_length(m: np.ndarray) -> float:
    """1 画素幅の枝の弧長(直交隣接 = 1、斜め隣接 = √2、斜めは直交で繋がる場合は数えない)。"""
    m = m.astype(bool)
    h = (m[:, :-1] & m[:, 1:]).sum()
    v = (m[:-1, :] & m[1:, :]).sum()
    d1 = m[:-1, :-1] & m[1:, 1:]
    d2 = m[:-1, 1:] & m[1:, :-1]
    # 直交で既に繋がっている斜め対は数えない(骨格の角)
    d1 = d1 & ~((m[:-1, :-1] & m[:-1, 1:] & m[1:, 1:]) | (m[:-1, :-1] & m[1:, :-1] & m[1:, 1:]))
    d2 = d2 & ~((m[:-1, 1:] & m[:-1, :-1] & m[1:, :-1]) | (m[:-1, 1:] & m[1:, 1:] & m[1:, :-1]))
    return float(h + v + np.sqrt(2) * (d1.sum() + d2.sum()))


# --------------------------------------------------------------------------- #
# 4. 節                                                                          #
# --------------------------------------------------------------------------- #
def section_zero_and_net() -> dict:
    print("\n" + "=" * 78)
    print("1) ゼロ点(暗い画素の大津しきい値)と、op 列で取った網")
    print("=" * 78)
    out = {}
    conds = [("きれい", dict(tex_c=0.0)), ("+質感", dict()), ("+斜光", dict(tex_c=0.0, rake=1.0))]
    for cond, kw in conds:
        sc = make_scene("経年", **kw)
        tr = truth_stats(sc)
        z = zero_point(sc["img"])
        out[cond] = dict(sc=sc, tr=tr, z=z)
        print("  %-6s ひび画素率 真値 %.2f %% / ゼロ点(大津) %.2f %%" % (cond, 100 * tr["crack_frac"], 100 * z))
    print("  ゼロ点は、きれいでも真値の %.1f 倍(ぼけた縁まで数える)。質感で %.1f 倍。"
          % (out["きれい"]["z"] / out["きれい"]["tr"]["crack_frac"],
             out["+質感"]["z"] / out["+質感"]["tr"]["crack_frac"]))

    print("\n  リッジ op の比較(経年型、許容 %.0f px。真値: 分岐点 %d / セル %d)" % (
        TOL_PX, out["きれい"]["tr"]["n_junc"], out["きれい"]["tr"]["n_cells"]))
    print("   %-14s %-6s %6s %6s %5s %5s" % ("op", "条件", "再現率", "適合率", "分岐点", "セル"))
    rows, comp = [], {}
    for ridge, lo, hi in [("xsk_meijering", 0.0, 0.0), ("xsk_sato", 0.0, 0.0), ("sk_frangi", 0.0, 0.0),
                          ("cv_blackhat", 0.3, 0.5)]:
        for cond, _ in conds:
            sc = out[cond]["sc"]
            det = extract_net(sc["img"], ridge, lo, hi)
            me = measure(sc, det)
            comp[(ridge, cond)] = me
            if cond == "+質感":
                out[cond].setdefault("det", {})[ridge] = det
            print("   %-14s %-6s %6.3f %6.3f %5d %5d" % (ridge, cond, me["recall"], me["prec"],
                                                       me["n_junc"], me["n_cells"]))
            rows.append([ridge, cond, "%.3f" % me["recall"], "%.3f" % me["prec"],
                         "%d" % me["n_junc"], "%d" % me["n_cells"]])
    fr, mj = comp[("sk_frangi", "+斜光")], comp[("xsk_meijering", "+斜光")]
    print("  ★Frangi は分岐点で応答が落ちる(設計どおり)ので斜光でセルが %d 個に崩れる。"
          "Meijering は %d 個(真値 %d)。以後の測定は xsk_meijering を使う。"
          % (fr["n_cells"], mj["n_cells"], out["+斜光"]["tr"]["n_cells"]))
    figs.save_table("ridge_ops", ["リッジ op", "条件", "再現率", "適合率", "分岐点 [個]", "セル [個]"],
                    rows, title="リッジ検出 op の比較(経年型、中心線の許容 %.0f px)" % TOL_PX,
                    caption="Frangi は分岐点で応答が落ち、斜光でセルが崩れる。")
    assert out["+質感"]["z"] > 1.3 * out["きれい"]["z"], "質感でゼロ点が増えなくなった"
    assert mj["n_cells"] > 2 * fr["n_cells"], "Frangi と Meijering の差が消えた"
    assert comp[("xsk_meijering", "+質感")]["recall"] > 0.95
    return out


def section_indicators() -> dict:
    print("\n" + "=" * 78)
    print("2) 3 指標(セル径 / 直線度 / 次数 4 割合)+異方性 —— 2 種を分けるか、照明で壊れるか")
    print("=" * 78)
    conds = [("真値", None),
             ("きれい", dict(tex_c=0.0, rake=0.0)),
             ("+質感", dict(tex_c=TEX_C, rake=0.0)),
             ("+斜光", dict(tex_c=0.0, rake=1.0)),
             ("質感+斜光", dict(tex_c=TEX_C, rake=1.0))]
    rows, table = [], {}
    print("  %-6s %-10s %8s %8s %8s %8s %7s" % ("種類", "条件", "セル径px", "直線度", "次数4割", "異方性", "セル数"))
    for kind in TYPES:
        for name, kw in conds:
            if kw is None:
                sc = make_scene(kind, tex_c=0.0)
                r = truth_stats(sc)
            else:
                sc = make_scene(kind, **kw)
                r = measure_scene(sc)
            table[(kind, name)] = r
            print("  %-6s %-10s %8.1f %8.3f %8.2f %8.2f %7d" % (
                kind, name, r["diam"], r["straight"], r["deg4"], r["aniso"], r["n_cells"]))
            rows.append([kind, name, "%.1f" % r["diam"], "%.3f" % r["straight"],
                         "%.2f" % r["deg4"], "%.2f" % r["aniso"], "%d" % r["n_cells"]])
    t_d, t_a = table[("乾燥", "真値")], table[("経年", "真値")]
    c_d, c_a = table[("乾燥", "きれい")], table[("経年", "きれい")]
    x_a, r_a = table[("経年", "+質感")], table[("経年", "+斜光")]
    print("\n  分離(真値): セル径 %.1f vs %.1f px(%.1f 倍) / 直線度 %.3f vs %.3f / 次数 4 割合 %.2f vs %.2f"
          % (t_d["diam"], t_a["diam"], t_a["diam"] / t_d["diam"], t_d["straight"], t_a["straight"],
             t_d["deg4"], t_a["deg4"]))
    print("  セル径の推定は壁(骨格を 1 px 太らせた 3 px)の分だけ一定に小さい: 乾燥 %.1f px / 経年 %.1f px 不足"
          "(壁 3 px + 反エイリアス)。引き算で戻る。" % (t_d["diam"] - c_d["diam"], t_a["diam"] - c_a["diam"]))
    print("  経年の次数 4 割合: きれい %.2f → +質感 %.2f / +斜光 %.2f(真値 %.2f)。質感は 3 差路の偽分岐を"
          "足して割合を薄め、斜光は 4 差路を 3 差路 2 個に割る。" % (c_a["deg4"], x_a["deg4"], r_a["deg4"], t_a["deg4"]))
    print("  セル径 %.1f → %.1f / %.1f px、直線度 %.3f → %.3f / %.3f は動かない。"
          % (c_a["diam"], x_a["diam"], r_a["diam"], c_a["straight"], x_a["straight"], r_a["straight"]))
    print("  ★予想は「斜光で直線度が壊れる(片側の影で骨格が蛇行する)」。実測で動いたのは分岐次数だった。")
    print("  異方性は真値 %.2f に対して推定 %.2f と上に偏るが、条件を変えても %.2f〜%.2f で動かない。"
          % (t_a["aniso"], c_a["aniso"], min(x_a["aniso"], r_a["aniso"], c_a["aniso"]),
             max(x_a["aniso"], r_a["aniso"], c_a["aniso"])))
    figs.save_table("indicators", ["種類", "条件", "セル径 [px]", "直線度(弦/弧)", "次数 4 割合",
                                   "異方性", "セル数"], rows,
                    title="3 指標の分離力と壊れ方(乾燥 vs 経年 × 撮影条件)",
                    caption="真値は幾何(ボロノイの頂点・辺)から。質感と斜光で動くのは次数 4 割合だけ。")
    assert t_a["deg4"] > t_d["deg4"] + 0.4 and t_a["straight"] > t_d["straight"] + 0.03
    assert c_a["deg4"] - r_a["deg4"] > 0.1, "斜光で次数 4 割合が落ちなくなった"
    assert c_a["deg4"] - x_a["deg4"] > 0.1, "質感で次数 4 割合が落ちなくなった"
    assert abs(c_a["straight"] - r_a["straight"]) < 0.02 and abs(c_a["diam"] - r_a["diam"]) < 1.0
    return table


def section_width_sweep() -> dict:
    print("\n" + "=" * 78)
    print("3) 崖: ひび幅 0.15 → 4 px(経年型、質感 %.2f、ぼけ σ %.1f px)" % (TEX_C, BLUR_SIG))
    print("=" * 78)
    ws = [0.15, 0.25, 0.35, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.0]
    from scipy.special import erf
    print("   幅px  予測ｺﾝﾄﾗｽﾄ  再現率  適合率  推定幅px  偏りpx")
    rec, prc, wid, pred = [], [], [], []
    for w in ws:
        sc = make_scene("経年", width=w)
        me = measure_scene(sc)
        c = K_CRACK * erf(w / (2 * np.sqrt(2) * BLUR_SIG))
        rec.append(me["recall"])
        prc.append(me["prec"])
        wid.append(me["width"])
        pred.append(c)
        print("   %4.2f   %8.3f   %6.3f  %6.3f   %6.2f   %+6.2f" % (
            w, c, me["recall"], me["prec"], me["width"], me["width"] - w))
    # 幾何の予想: ぼけ後の**点**コントラストが質感の 2 倍を割る幅
    from scipy.optimize import brentq
    w_pred = brentq(lambda w: K_CRACK * erf(w / (2 * np.sqrt(2) * BLUR_SIG)) - 2 * TEX_C, 0.05, 10)
    i90 = next((i for i, r in enumerate(rec) if r >= 0.9), len(ws) - 1)
    print("  ★予想の崖(点コントラスト = 質感 × 2)は %.2f px。実測は再現率 0.9 を割るのが %.2f px より下で、"
          "%.2f px でも %.2f —— 崖ではなく緩い坂。線検出は線に沿って積分するので、点のコントラストでは"
          "予想できない(予想は外れた)。" % (w_pred, ws[i90], ws[0], rec[0]))
    print("  先に壊れるのは適合率(%.2f px で %.2f)と幅: 真値 0.5 px → %.1f px(%.1f 倍)、1.0 px → %.1f px、"
          "4.0 px → %.1f px。ぼけ σ %.1f px の半値幅 %.1f px が下限。"
          % (0.5, prc[ws.index(0.5)], wid[ws.index(0.5)], wid[ws.index(0.5)] / 0.5, wid[ws.index(1.0)],
             wid[ws.index(4.0)], BLUR_SIG, 2.355 * BLUR_SIG))
    figs.save_plot("width_cliff", [("中心線の再現率", ws, rec), ("適合率", ws, prc),
                                   ("推定幅 − 真値幅 [px]", ws, [v - w for v, w in zip(wid, ws)])],
                   xlabel="ひび幅の真値 [px]", ylabel="再現率 / 適合率 / 幅の偏り [px]",
                   title="ひび幅の崖(ぼけ σ %.1f px、質感 %.2f)" % (BLUR_SIG, TEX_C),
                   caption="再現率の崖は 0.5 px より下。幅の推定は細いほど太る(ぼけの半値幅が下限)。")
    assert rec[ws.index(0.5)] > 0.85, "0.5 px で崖が来た: %s" % rec
    assert rec[0] < 0.8, "0.15 px でも取れてしまう: %s" % rec
    assert wid[ws.index(1.0)] > 1.5 and abs(wid[ws.index(4.0)] - 4.0) < 0.6
    return dict(ws=ws, rec=rec, prc=prc, wid=wid, w_pred=w_pred, i90=i90)


def section_texture_sweep() -> dict:
    print("\n" + "=" * 78)
    print("4) 崖: 質感のコントラスト 0 → 0.64(経年型、幅 2 px)—— 偽陽性はどこで爆発するか")
    print("=" * 78)
    cs = [0.0, 0.04, 0.08, 0.12, 0.16, 0.24, 0.32, 0.48, 0.64]
    print("   質感c  偽陽性長/真値長  再現率  ゼロ点%  真値%")
    fp, rec, zs = [], [], []
    for c in cs:
        sc = make_scene("経年", tex_c=c)
        tr = truth_stats(sc)
        me = measure_scene(sc)
        z = zero_point(sc["img"])
        fp.append(me["fp_ratio"] / tr["len_true"])
        rec.append(me["recall"])
        zs.append(100 * z)
        print("   %4.2f   %10.3f     %6.3f   %6.2f  %5.2f" % (c, fp[-1], me["recall"], 100 * z,
                                                              100 * tr["crack_frac"]))
    c_pred = K_CRACK / 3.0
    i_ex = next((i for i, v in enumerate(fp) if v > 0.5), None)
    where = ("c = %.2f で 0.5 を超える" % cs[i_ex]) if i_ex is not None else "0.64 まで 0.5 を超えない"
    print("  ★予想は「色斑の最暗部 3σ がひびの深さ %.2f に届く c ≈ %.2f で爆発」。実測は爆発せず: "
          "c = %.2f で %.2f、%.2f で %.2f、%.2f で %.2f(%s)。" % (
              K_CRACK, c_pred, cs[4], fp[4], cs[6], fp[6], cs[8], fp[8], where))
    print("  ヒステリシスのしきい値がリッジ応答の最大値に相対で、面積オープニングが小さい島を落とすので、"
          "偽陽性は「爆発」ではなく直線的に増える。代わりに再現率が %.3f → %.3f と削れる。"
          % (rec[0], rec[8]))
    z0 = 100 * truth_stats(make_scene("経年", tex_c=0.0))["crack_frac"]
    print("  ゼロ点(大津)は c = 0 でも %.1f %%(真値 %.1f %% の %.1f 倍)、c = %.2f で %.1f %%。"
          % (zs[0], z0, zs[0] / z0, cs[2], zs[2]))
    figs.save_plot("texture_cliff", [("偽陽性長 / 真値長", cs, fp), ("再現率", cs, rec),
                                     ("ゼロ点のひび画素率 / 真値", cs, [z / z0 for z in zs])],
                   xlabel="色斑のコントラスト(標準偏差)", ylabel="比",
                   title="質感のコントラストと偽陽性 —— 爆発はしない",
                   caption="ひびの深さ %.2f。予想の境目 c ≈ %.2f は来なかった。" % (K_CRACK, c_pred))
    assert fp[4] < 0.25 and fp[8] < 1.0 and fp[8] > fp[4], "質感の増え方が変わった: %s" % fp
    assert zs[0] > 2 * z0
    return dict(cs=cs, fp=fp, rec=rec, zs=zs, c_pred=c_pred, z0=z0)


def section_rake_sweep() -> dict:
    print("\n" + "=" * 78)
    print("5) 崖: 斜光の強さ 0 → 1(経年型、幅 2 px)—— 幅は片側にどれだけ太るか")
    print("=" * 78)
    ss = [0.0, 0.25, 0.5, 0.75, 1.0]
    print("   強さ  推定幅px  中心線ずれpx  異方性  次数4割  再現率")
    wid, off, an, d4 = [], [], [], []
    for s in ss:
        sc = make_scene("経年", tex_c=0.0, rake=s)
        me = measure_scene(sc)
        wid.append(me["width"])
        off.append(me["offset"])
        an.append(me["aniso"])
        d4.append(me["deg4"])
        print("   %4.2f   %6.2f     %+6.2f      %5.2f   %5.2f   %5.3f" % (
            s, me["width"], me["offset"], me["aniso"], me["deg4"], me["recall"]))
    print("  推定幅 %.2f → %.2f px(真値 2 px、+%.2f px)、中心線は光源側へ %.2f px、次数 4 割合 %.2f → %.2f、"
          "異方性 %.2f → %.2f。" % (wid[0], wid[-1], wid[-1] - wid[0], -off[-1], d4[0], d4[-1], an[0], an[-1]))
    print("  影の側だけが暗くなるので、半値幅のマスクが光源側へ伸び、骨格もそちらへ寄る。")
    figs.save_plot("rake_bias", [("推定幅 [px]", ss, wid), ("次数 4 割合", ss, d4),
                                 ("中心線ずれ [px](負 = 光源側)", ss, off)],
                   xlabel="斜光の強さ(0 = 拡散光)", ylabel="px / 割合",
                   title="斜光で幅は片側に太り、4 差路が割れる",
                   caption="光源は左。影側が暗くなるので暗画素マスクが左に伸びる。")
    assert wid[-1] - wid[0] > 0.25 and off[-1] < -0.5 and abs(an[-1] - an[0]) < 0.05
    assert d4[0] - d4[-1] > 0.1
    return dict(ss=ss, wid=wid, off=off, an=an, d4=d4)


def section_blur_cell() -> dict:
    print("\n" + "=" * 78)
    print("6) ぼけ × セル径 —— セルの小ささの下限(乾燥型、幅 2 px、質感なし)")
    print("=" * 78)
    cells = [8.0, 12.0, 16.0, 24.0]
    blurs = [0.5, 1.0, 2.0, 3.0]
    print("   セル径px | ぼけσ=" + "  ".join("%4.1f" % b for b in blurs) + "   (セル数の再現率)")
    grid, rows = {}, []
    for c in cells:
        line = []
        for b in blurs:
            sc = make_scene("乾燥", cell=c, warp_amp=1.0, tex_c=0.0, blur=b, n=256)
            tr = truth_stats(sc)
            me = measure_scene(sc)
            r = me["n_cells"] / max(1, tr["n_cells"])
            grid[(c, b)] = r
            line.append(r)
        print("   %6.0f    |       %s" % (c, "  ".join("%4.2f" % v for v in line)))
        rows.append(["%.0f" % c] + ["%.2f" % v for v in line])
    lim = []
    for b in blurs:
        ok = [c for c in cells if grid[(c, b)] >= 0.9]
        lim.append(min(ok) if ok else float("nan"))
    print("  再現率 0.9 を保つ最小セル径: " + " / ".join("σ=%.1f → %s px" % (b, ("%.0f" % l) if np.isfinite(l) else "無し")
                                                     for b, l in zip(blurs, lim)))
    print("  目安: 径 < 5σ + 幅 で隣のひびがぼけで融合する(σ=2 → 12 px、σ=3 → 17 px、実測と一致)。")
    figs.save_table("blur_cell_limit", ["セル径 [px]"] + ["ぼけ σ=%.1f px" % b for b in blurs], rows,
                    title="セル数の再現率(乾燥型、幅 2 px)",
                    caption="ぼけが大きいほど小さいセルから消える。目安は 径 < 5σ + 幅。")
    assert grid[(24.0, 0.5)] >= 0.9 and grid[(8.0, 3.0)] < 0.5 and grid[(12.0, 3.0)] < 0.9
    assert grid[(16.0, 3.0)] >= 0.9 and grid[(12.0, 2.0)] >= 0.9
    return dict(grid=grid, lim=lim)


def section_scene_figs(base: dict) -> None:
    sc_d = make_scene("乾燥")
    sc_a = make_scene("経年")
    sc_r = make_scene("経年", rake=1.0)
    panels, caps = [], []
    for sc, name in [(sc_d, "乾燥ひび(セル小・蛇行)"), (sc_a, "経年ひび(セル大・格子的)"),
                     (sc_r, "経年ひび + 斜光(左から)")]:
        panels.append(sc["img"])
        caps.append(name)
    panels.append(make_scene("経年", tex_c=0.32)["img"])
    caps.append("経年ひび、質感 0.32(偽陽性が爆発する側)")
    figs.save_grid("scene", panels, caps, ncols=2,
                   title="ひび割れ網の合成シーン(視野 %d px)" % N_PIX,
                   caption="絵の具の色斑 + ニスの光沢むら + ぼけ + 雑音。斜光は溝の片側を影にする。")
    me = measure_scene(sc_a)
    det = me["det"]
    ov = np.stack([sc_a["img"]] * 3, -1)
    ov[det["skel"]] = (0.1, 0.4, 1.0)
    ov[ndi.binary_dilation(det["junc"], np.ones((3, 3), bool))] = (1.0, 0.6, 0.0)
    ov[ndi.binary_dilation(det["ends"], np.ones((3, 3), bool))] = (0.0, 0.8, 0.2)
    figs.save_grid("map_stages", [sc_a["img"], det["resp"], det["mask"].astype(float), ov],
                   ["入力(経年、既定条件)", "xsk_meijering の応答", "ヒステリシス + 面積オープニング",
                    "骨格(青)・分岐点(橙)・端点(緑)"],
                   ncols=2, title="op 列の段階(経年ひび)",
                   caption="分岐点 %d 個、セル %d 個を検出。" % (me["n_junc"], me["n_cells"]))
    figs.save_grid("map_cells", [_LAB.blob_overlay(sc_a["img"], me["labels"]),
                                 _LAB.blob_overlay(sc_d["img"], measure_scene(sc_d)["labels"])],
                   ["経年: 検出したセル", "乾燥: 検出したセル"], ncols=2,
                   title="セルの切り出し(骨格の補集合の連結成分)",
                   caption="縁に触れるセルは統計から外す(真値も同じ規約)。")
    # 分岐次数のヒストグラム(真値 vs 検出、斜光あり/なし)
    tr = truth_stats(sc_a)
    me_r = measure_scene(sc_r)
    degs_x = [3, 4, 5]
    def hist(d):
        d = np.asarray(d)
        return [float((d == k).mean()) if d.size else 0 for k in degs_x[:-1]] + \
               [float((d >= degs_x[-1]).mean()) if d.size else 0]
    figs.save_plot("degree_hist", [("真値", degs_x, hist(tr["degs"])),
                                   ("検出(拡散光)", degs_x, hist(me["degs"])),
                                   ("検出(斜光 1.0)", degs_x, hist(me_r["degs"]))],
                   xlabel="分岐点の次数(5 は 5 以上)", ylabel="割合",
                   title="分岐次数の分布 —— 斜光で 4 が 3 に割れる(経年)",
                   caption="次数 4 割合 真値 %.2f / 拡散光 %.2f / 斜光 %.2f" % (tr["deg4"], me["deg4"], me_r["deg4"]))
    # セル面積分布(乾燥 vs 経年、真値と検出)
    def cdf(v):
        v = np.sort(np.asarray(v, float))
        return v, np.arange(1, v.size + 1) / max(1, v.size)
    tr_d = truth_stats(sc_d)
    me_d = measure_scene(sc_d)
    series = []
    for lbl, v in [("乾燥 真値", tr_d["diam_all"]), ("乾燥 検出", me_d["diam_all"]),
                   ("経年 真値", tr["diam_all"]), ("経年 検出", me["diam_all"])]:
        x, y = cdf(v)
        series.append((lbl, x, y))
    figs.save_plot("cell_diameter_cdf", series, xlabel="セルの等価直径 [px]", ylabel="累積割合",
                   title="セル径の分布(真値 vs 検出)",
                   caption="乾燥 %.1f px / 経年 %.1f px(真値の平均)。" % (tr_d["diam"], tr["diam"]))


def section_tool_gaps() -> None:
    print("\n" + "=" * 78)
    print("7) 道具の穴(この PoC で fullseye を引いてみて)")
    print("=" * 78)
    m = np.zeros((32, 32)); m[8:24, 8:24] = 1
    d = np.asarray(fs.apply(m, "distance_transform"))
    assert abs(float(d.max()) - 1.0) < 1e-9
    print("  (a) 2-D の距離変換(distance_transform / cv_dist / xsp_chamfer_dist)はどれも最大値で"
          "正規化されるので、画素単位のひび幅が取れない。幅は scipy の EDT で測った。")
    print("  (b) 分岐点の**次数**を返す op が無い(junctions_skeleton は位置だけ)。分岐点を束ねて"
          "半径 %.0f px の環を横切る骨格の本数を自前で数えた。3-D には topology_signature がある。" % RING_PX)
    print("  (f) 2-D の暗さ(ブラックハット)も最大値で正規化されるので、絶対しきい値の暗画素マスクが"
          "作れない。骨格上の典型値の半分で切る相対しきい値にした。")
    print("  (c) 枝ごとの弧長・弦長(直線度)を返す op が無い。骨格の枝を 1 本ずつ歩いて自前で出した。")
    print("  (d) 骨格の枝の向きから異方性(2 次のモーメント)を出す op が無い。")
    two = np.full((64, 64), 0.7); two[:, 30:32] = 0.2
    o = np.asarray(fs.apply(1.0 - two, "otsu"))
    print("  (e) バグ疑い: 雑音の無い 2 値だけの画像に `otsu` を掛けると全画素が前景になる"
          "(実測 %d / %d 画素。sk_otsu は %d)。" % (int(o.sum()), o.size,
                                              int(np.asarray(fs.apply(1.0 - two, "sk_otsu")).sum())))


# --------------------------------------------------------------------------- #
def main() -> int:
    t0 = time.perf_counter()
    print("=" * 78)
    print("絵画のひび割れ網(craquelure)を測る —— 3 指標のうち撮影条件で壊れるのは分岐次数だけ")
    print("視野 %d px / ひびの深さ %.2f / ぼけ σ %.1f px / 質感 %.2f" % (N_PIX, K_CRACK, BLUR_SIG, TEX_C))
    print("=" * 78)

    base = section_zero_and_net()
    table = section_indicators()
    sw = section_width_sweep()
    tx = section_texture_sweep()
    rk = section_rake_sweep()
    bc = section_blur_cell()
    section_scene_figs(base)
    section_tool_gaps()

    print("\n" + "=" * 78)
    print("まとめ")
    print("=" * 78)
    t_d, t_a = table[("乾燥", "真値")], table[("経年", "真値")]
    print("  * 3 指標(セル径 %.1f vs %.1f px / 直線度 %.3f vs %.3f / 次数 4 割合 %.2f vs %.2f)は"
          "どれも 2 種を分けるが、質感と斜光で動くのは次数 4 割合だけ(%.2f → %.2f / %.2f)。"
          % (t_d["diam"], t_a["diam"], t_d["straight"], t_a["straight"], t_d["deg4"], t_a["deg4"],
             table[("経年", "きれい")]["deg4"], table[("経年", "+質感")]["deg4"],
             table[("経年", "+斜光")]["deg4"]))
    print("  * 崖: 幅は再現率 0.9 を %.2f px まで保ち、%.2f px でも %.2f(予想の崖 %.2f px は来なかった)/ "
          "質感は c = %.2f でも偽陽性 %.2f で爆発しない(予想 c ≈ %.2f)/ 斜光で幅 +%.2f px。"
          % (sw["ws"][sw["i90"]], sw["ws"][0], sw["rec"][0], sw["w_pred"], tx["cs"][8], tx["fp"][8],
             tx["c_pred"], rk["wid"][-1] - rk["wid"][0]))
    print("\n  所要 %.1f 秒" % (time.perf_counter() - t0))
    if figs.errors():
        print("図の書き出しで失敗:", "; ".join(figs.errors()))
    print("\nPASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
