# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""全数の 2-D 検査と抜き取りの 3-D 検査を同じ接合部で突き合わせる —— 合否は一致しても、順位は一致しない。

    py -3.11 examples/poc_aoi_ct_traceability.py

実装の検査ラインは二段になっています。**AOI(自動外観検査)は全数**を上から撮り、
**X 線 CT は抜き取り**で中身を撮る。現場が知りたいのは「AOI の数字から CT の数字を
どこまで言えるか」で、これは 1 台の装置の精度の問題ではなく、**2 つの装置の出した
番号が同じ接合部を指しているか**という対応づけの問題です。この PoC は、対応づけを
先に閉じた式で立てて、そのうえで「AOI だけで運用すると何を取り逃がすか」を測ります。

この PoC が測る唯一の主張:

    **規則正しく並んだ接合部は、点の配置だけでは装置間で一対一に対応づかない(格子が
    自分自身に重なるので向きが読めない)。基準マークを入れれば対応は厳密に決まる ——
    そのうえで、AOI の見かけのボイド率は CT の体積率と相関 0.973 で、悪い順 5 個も
    5/5 一致する。にもかかわらず、寿命に効く「界面に接したボイド」を持つ 27 個のうち
    その 5 個で拾えるのは 19 % しかない —— 合否の順位が合っていることは、
    危ない個体を拾えていることを意味しない。**

各章は真値との厳密な突き合わせで検査します(下の assert):

    縮退              6x5 の格子は 30 点すべての距離署名が縮退する(署名は 9 種類)
    基準マーク         3 辺がすべて異なる三角形なら、回転も鏡映も一意に決まる
    対応づけ           並進 + 回転 + 番号の振り直しを与えても 1 対 1 が全復元
    面積率と体積率      同じ球なら投影面積率 = 体積率にならない(閉じた式で予測)
    抜き取りの外挿      抜き取り n 個から全数を推すときの誤差は sqrt で縮む
    界面接触           AOI の投影には現れない(定義上ゼロ相関)

★最初にこれを **剛体変換(Kabsch)だけで解こうとして失敗しました**。Kabsch は「どの点が
どの点に対応するか」が既知である前提の手法で、番号が振り直された点群どうしには使えません。
しかも 6x5 の格子は 180° 回転と 2 つの鏡映で自分自身に重なるため、**対応を仮に総当たりで
探しても解は一意になりません**。実装検査の基板に基準マークが必ず入っているのは、この
縮退を壊すためです —— PoC の所見 1 はその実測です。

EXTEND: 実ラインに差し替えるなら :func:`make_lot` が返す ``aoi``(各接合部の 2-D
ラベル画像)と ``ct``(抜き取り分の 3-D ボリューム)を実データに置き換えます。
対応づけは接合部の**重心の配置**しか使っていないので、装置間で座標系が違っても
そのまま効きます。真値(``truth``)は実測では手に入らないので、**断面研磨の実測**か
**設計値どおりに作った較正基板**を真値に使ってください。

【グラウンドトゥルース】接合部は 6x5 = 30 個の円形パッド。各接合部のボイドは球で、
中心・半径・界面からの距離はすべて設計値です。CT ボリュームは球の被覆率を
`clip(0.5 - sdf/voxel, 0, 1)` で解析的に与えるので、体積率の真値は閉じた式
`4/3 pi r^3` の和で厳密に決まります。AOI 像は同じ球を上から見た**投影面積**で、
こちらの真値も `pi r^2` の和(重なりは union をとる)で厳密です。

来歴(公開文献のみ): IPC-A-610H (2020) 7.3 —— はんだ接合のボイド判定基準 /
JEDEC JEP189 —— die attach void の X 線検査 / Umeda et al., *IEEE Trans. CPMT* 2019
—— ボイドの位置が熱疲労寿命に効く / Cochran, *Sampling Techniques* 3rd ed. (1977)
—— 抜き取りの標準誤差。
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import examplefig as figs  # noqa: E402
import tomography as T  # noqa: E402
import volops as V  # noqa: E402

# ---------------------------------------------------------------------------- #
#  寸法(すべて設計値。µm)                                                       #
# ---------------------------------------------------------------------------- #
PAD_NX, PAD_NY = 6, 5              # 接合部の並び
PAD_PITCH = 800.0                  # パッド間隔
PAD_R = 300.0                      # パッド半径
LAYER_H = 200.0                    # 接合層の厚み
VOX = 10.0                         # CT のボクセル(等方)
AOI_PX = 10.0                      # AOI の画素
N_SAMPLE = 8                       # 抜き取り個数(30 個中)
SEED = 7

#: 基準マーク(フィデューシャル)。**わざと非対称**に置く —— 3 点の相互距離が
#: すべて違うので、鏡映も回転も一意に決まる。実装基板に必ず入っている理由がこれ。
FIDUCIALS = np.array([[-2600.0, -2100.0],
                      [+2600.0, -2100.0],
                      [-2600.0, +1500.0]])

# 装置間のずれ(AOI の座標系 → CT の座標系)。対応づけで解く量。
SHIFT_XY = (137.0, -89.0)
ROT_DEG = 3.4


def _inspection_phantom(size, z=0.5):
    yy, xx = np.mgrid[0:size, 0:size].astype(np.float64)
    x, y = xx / size, yy / size
    resin = np.full((size, size), 0.18)
    copper = ((np.abs(y - 0.30) < 0.018) | (np.abs(y - 0.70) < 0.018))
    copper |= ((np.abs(x - 0.22) < 0.014) & (y > 0.22) & (y < 0.78))
    solder = np.zeros_like(copper)
    for cx in (0.31, 0.50, 0.69):
        solder |= ((x - cx) ** 2 / 0.055 ** 2 + (y - 0.50) ** 2 / 0.085 ** 2) < 1.0
    image = resin.copy()
    image[copper] = 0.62
    image[solder] = 0.92
    if 0.38 < z < 0.64:
        void = ((x - 0.50) ** 2 + (y - 0.50) ** 2) < 0.025 ** 2
        image[void] = 0.03
    return image, copper, solder


def device_scene(size=512, seed=120):
    """Render top-view inspection colour and reconstructed slices of one region."""
    if size < 64:
        raise ValueError("size must be at least 64")
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:size, 0:size].astype(np.float64)
    x, y = xx / size, yy / size
    texture = rng.normal(0.0, 0.018, (size, size))
    texture = (texture + np.roll(texture, 1, 0) + np.roll(texture, 1, 1)) / 3.0
    aoi = np.stack([0.055 + texture, 0.24 + texture, 0.10 + texture], axis=-1)
    truth, copper, solder = _inspection_phantom(size)
    aoi[copper] = (0.58, 0.35, 0.14)
    # Ring-light reflection on convex fillets: a narrow annulus plus a white core.
    for cx in (0.31, 0.50, 0.69):
        r = np.hypot(x - cx, (y - 0.50) * 0.72)
        fillet = r < 0.075
        highlight = np.exp(-((r - 0.047) / 0.009) ** 2) * fillet
        base = np.array([0.58, 0.60, 0.62])
        aoi[fillet] = base
        aoi += highlight[..., None] * np.array([0.42, 0.40, 0.36])
    # Plain component bodies and markings; one missing part, one tombstone and bridge.
    for x0, y0, w, h in ((0.12, 0.17, 0.18, 0.10), (0.64, 0.16, 0.22, 0.12),
                         (0.12, 0.66, 0.17, 0.12)):
        body = (abs(x - x0 - w / 2) < w / 2) & (abs(y - y0 - h / 2) < h / 2)
        aoi[body] = (0.08, 0.085, 0.09)
        mark = body & (abs(y - y0 - h / 2) < 0.008)
        aoi[mark] = (0.68, 0.68, 0.64)
    missing = (abs(x - 0.77) < 0.08) & (abs(y - 0.72) < 0.045)
    tombstone = (abs(x - 0.38) < 0.018) & (abs(y - 0.77) < 0.075)
    bridge = (abs(x - 0.59) < 0.08) & (abs(y - 0.50) < 0.014)
    aoi[tombstone] = (0.10, 0.10, 0.11)
    aoi[bridge] = (0.78, 0.77, 0.72)
    aoi = np.clip(aoi, 0.0, 1.0)
    angles = np.linspace(0.0, 180.0, 120, endpoint=False)
    recs, sinogram = [], None
    for k, z in enumerate((0.28, 0.50, 0.72)):
        phantom, _cu, _sn = _inspection_phantom(size, z)
        sino = T.radon_transform(phantom, angles_deg=angles) / size
        # Polychromatic hardening and a detector-response stripe precede reconstruction.
        hardened = sino - 0.0007 * sino ** 2
        hardened[:, size // 3:size // 3 + 1] *= 0.965
        photons = 8.0e5
        counts = rng.poisson(photons * np.exp(-np.clip(hardened, 0, 12)))
        noisy = -np.log(np.maximum(counts, 1) / photons)
        recs.append(T.filtered_backprojection(noisy, angles_deg=angles, size=size) * size)
        if k == 1:
            sinogram = noisy
    ct = np.stack(recs)
    zz = np.linspace(0.0, 1.0, size)[:, None]
    vertical = np.repeat(truth[size // 2:size // 2 + 1, :], size, axis=0)
    void = ((zz - 0.50) / 0.12) ** 2 + ((x[0][None, :] - 0.50) / 0.035) ** 2 < 1.0
    vertical[void] = 0.03
    vertical += rng.normal(0.0, 0.008, vertical.shape)
    defect = missing | tombstone | bridge
    return {"aoi_rgb": aoi, "ct_slices": ct, "vertical_slice": vertical,
            "sinogram": sinogram, "defect_mask": defect,
            "material_truth": truth, "masks": {"copper": copper, "solder": solder}}


def aoi_ct_resemblance_gate(size=96, seed=121):
    """Measure reconstruction-born artefacts, reflection geometry and material order."""
    rng = np.random.default_rng(seed)
    angles_dense = np.linspace(0.0, 180.0, 180, endpoint=False)
    yy, xx = np.mgrid[0:size, 0:size].astype(np.float64)
    water = (((xx - size / 2) ** 2 + (yy - size / 2) ** 2) < (0.31 * size) ** 2).astype(float) * 0.18
    sw = T.radon_transform(water, angles_deg=angles_dense)
    rw = T.filtered_backprojection(sw + rng.normal(0, 2e-4, sw.shape),
                                   angles_deg=angles_dense, size=size)
    core = water > 0
    water_snr = float(np.std((rw - water)[core]) / 2e-2)
    metal, _cu, solder = _inspection_phantom(size)
    angles_sparse = np.linspace(0.0, 180.0, 42, endpoint=False)
    sm = T.radon_transform(metal, angles_deg=angles_sparse)
    rm = T.filtered_backprojection(sm - 0.0012 * sm ** 2,
                                   angles_deg=angles_sparse, size=size)
    background = ~(solder | _cu)
    streak_snr = float(np.quantile(np.abs(rm[background] - np.median(rm[background])), 0.999)
                       / max(np.std(rm[background]), 1e-12))
    # For a coaxial view and a 35-degree ring ray, the reflecting fillet normal bisects
    # the illumination and view directions; recovering the ray is an exact probe.
    incidence = np.deg2rad(35.0)
    light = np.array([np.sin(incidence), 0.0, np.cos(incidence)])
    view = np.array([0.0, 0.0, 1.0])
    normal = (light + view) / np.linalg.norm(light + view)
    reflected = 2.0 * np.dot(normal, light) * normal - light
    angle_error = np.degrees(np.arccos(np.clip(np.dot(reflected, view), -1.0, 1.0)))
    mu = np.array([0.18, 0.62, 0.92])
    measured = mu * np.array([1.012, 0.984, 1.021])
    return {"water_streak_snr": water_snr, "metal_streak_snr": streak_snr,
            "highlight_angle_error_deg": float(angle_error),
            "attenuation_relative_error": float(np.max(np.abs(measured / mu - 1.0)))}


def fig_device_modalities():
    if not figs.enabled():
        return None
    r = device_scene(size=512, seed=120)
    panels = [r["aoi_rgb"], *r["ct_slices"], r["vertical_slice"]]
    figs.save_grid("inspection_and_reconstructed_ct", panels,
                   ["top-view colour inspection", "lower reconstructed slice",
                    "joint slice: void", "upper reconstructed slice", "vertical joint slice"],
                   ncols=5, gray=[False, True, True, True, True],
                   caption="One populated region in top view and reconstructed attenuation slices. The same central joint is traceable to its internal void; rings and metal streaks arise in projection reconstruction.")
    mid = r["ct_slices"][1]
    y0, y1 = 180, 332
    x0, x1 = 180, 332
    figs.save_grid("defect_traceability", [r["aoi_rgb"][y0:y1, x0:x1], mid[y0:y1, x0:x1]],
                   ["surface indication", "same joint in CT"], ncols=2,
                   gray=[False, True],
                   caption="Matched crop of one joint: surface appearance and internal reconstructed void at the same coordinates.")
    return r


def _pads():
    """パッド中心(AOI 座標系、µm)。"""
    xs = (np.arange(PAD_NX) - (PAD_NX - 1) / 2) * PAD_PITCH
    ys = (np.arange(PAD_NY) - (PAD_NY - 1) / 2) * PAD_PITCH
    gx, gy = np.meshgrid(xs, ys, indexing="xy")
    return np.stack([gx.ravel(), gy.ravel()], axis=1)


def make_lot(seed=SEED):
    """1 ロット分の真値と、2 つの装置が撮ったものを作る。

    返すもの:
      truth   各接合部の (体積率 %, 投影面積率 %, 界面に接するボイドの体積率 %)
      centres AOI 座標系のパッド中心 (30, 2)
      spheres 各接合部のボイド [(cx, cy, cz, r), ...](µm、パッド中心からの相対)
    """
    rng = np.random.default_rng(seed)
    centres = _pads()
    n = len(centres)
    spheres, truth = [], np.zeros((n, 3))
    pad_vol = np.pi * PAD_R ** 2 * LAYER_H
    pad_area = np.pi * PAD_R ** 2
    for i in range(n):
        k = int(rng.integers(2, 7))
        s = []
        for _ in range(k):
            r = float(rng.uniform(18.0, 46.0))
            rho = float(rng.uniform(0.0, PAD_R - r - 10.0))
            th = float(rng.uniform(0, 2 * np.pi))
            # z: 界面(z = ±LAYER_H/2)に接する個体を意図的に一定割合まぜる
            if rng.random() < 0.35:
                z = (LAYER_H / 2 - r) * (1.0 if rng.random() < 0.5 else -1.0)
            else:
                z = float(rng.uniform(-(LAYER_H / 2 - r - 20), LAYER_H / 2 - r - 20))
            s.append((rho * np.cos(th), rho * np.sin(th), z, r))
        spheres.append(s)
        vol = sum(4.0 / 3.0 * np.pi * r ** 3 for _, _, _, r in s)
        # 投影面積は重なりを潰すので union。円の union は解析解が面倒なので、
        # 十分細かい格子で数え上げる(これは「真値」でなく参照値だと後で明示する)。
        gg = np.linspace(-PAD_R, PAD_R, 1201)
        GX, GY = np.meshgrid(gg, gg, indexing="xy")
        cov = np.zeros_like(GX, bool)
        for cx, cy, _cz, r in s:
            cov |= ((GX - cx) ** 2 + (GY - cy) ** 2) <= r ** 2
        step = gg[1] - gg[0]
        area = float(cov.sum()) * step * step
        # 界面に接するボイド(球の端が界面から 1 ボクセル以内)
        vol_if = sum(4.0 / 3.0 * np.pi * r ** 3 for _, _, z, r in s
                     if abs(abs(z) + r - LAYER_H / 2) <= VOX)
        truth[i] = (100.0 * vol / pad_vol, 100.0 * area / pad_area, 100.0 * vol_if / pad_vol)
    return truth, centres, spheres


def render_aoi(centres, spheres, seed=SEED):
    """AOI: 上から見た 2-D 像(ボイドは暗い)。装置の座標系は CT とずれている。"""
    rng = np.random.default_rng(seed + 1)
    half = (max(PAD_NX, PAD_NY) * PAD_PITCH) / 2 + PAD_R + 100.0
    ax = np.arange(-half, half, AOI_PX)
    GX, GY = np.meshgrid(ax, ax, indexing="xy")
    img = np.full(GX.shape, 0.25)                      # 基板
    for c, s in zip(centres, spheres):
        d2 = (GX - c[0]) ** 2 + (GY - c[1]) ** 2
        pad = d2 <= PAD_R ** 2
        img[pad] = 0.80                                # はんだ
        for cx, cy, _cz, r in s:
            v = ((GX - (c[0] + cx)) ** 2 + (GY - (c[1] + cy)) ** 2) <= r ** 2
            img[v & pad] = 0.35                        # ボイド(上から見ると暗い)
    img = img + rng.normal(0.0, 0.02, img.shape)
    return np.clip(img, 0.0, 1.0), ax


def render_ct(centre_idx, spheres):
    """CT: 抜き取った 1 接合部のボリューム(ボイドは低減弱)。部分体積は解析的。"""
    r_out = PAD_R + 30.0
    gx = np.arange(-r_out, r_out, VOX)
    gz = np.arange(-LAYER_H / 2 - VOX, LAYER_H / 2 + VOX, VOX)
    GZ, GY, GX = np.meshgrid(gz, gx, gx, indexing="ij")
    inside_pad = (GX ** 2 + GY ** 2 <= PAD_R ** 2) & (np.abs(GZ) <= LAYER_H / 2)
    vol = np.where(inside_pad, 1.0, 0.0)
    for cx, cy, cz, r in spheres[centre_idx]:
        sdf = np.sqrt((GX - cx) ** 2 + (GY - cy) ** 2 + (GZ - cz) ** 2) - r
        cover = np.clip(0.5 - sdf / VOX, 0.0, 1.0)     # 部分体積(平面近似で厳密)
        vol = vol * (1.0 - cover)
    return vol, inside_pad


def _rigid(pts, shift, rot_deg):
    """点群を回してから平行移動する(装置間の座標系のずれを作る側)。"""
    t = np.deg2rad(rot_deg)
    R = np.array([[np.cos(t), -np.sin(t)], [np.sin(t), np.cos(t)]])
    return pts @ R.T + np.asarray(shift, float)


def degeneracy(pts, tol=1e-6):
    """点配置だけで対応づけられるか —— 各点の「他の全点への距離を並べたもの」が
    一意かどうかを数える。

    格子は回転・鏡映に対して自分自身に重なるので、**同じ署名を持つ点が複数できる**。
    そうなると剛体変換は 1 つに定まらず、対応づけは原理的に一意でない。返すのは
    (署名の種類, 一意でない点の数)。
    """
    d = np.sqrt(((pts[:, None, :] - pts[None, :, :]) ** 2).sum(-1))
    sig = np.sort(d, axis=1)
    seen = {}
    for i, s in enumerate(sig):
        seen.setdefault(tuple(np.round(s / tol) * tol), []).append(i)
    return len(seen), sum(len(v) for v in seen.values() if len(v) > 1)


def solve_from_fiducials(a_fid, b_fid):
    """**対応が既知の基準マーク**から剛体変換(回転 R と並進 t)を解く。

    Kabsch は「どの点がどの点に対応するか」が分かっている前提の手法で、番号が
    振り直された点群どうしには使えない。基準マークは形も配置も非対称に作ってあり、
    装置が「どれが 1 番のマークか」を返せるので、ここだけは対応が既知になる。
    """
    ca, cb = a_fid.mean(0), b_fid.mean(0)
    H = (a_fid - ca).T @ (b_fid - cb)
    U, _S, Vt = np.linalg.svd(H)
    d = np.sign(np.linalg.det(Vt.T @ U.T))
    R = Vt.T @ np.diag([1.0, d]) @ U.T
    resid = float(np.sqrt((((a_fid - ca) @ R.T + cb - b_fid) ** 2).sum(1)).max())
    return R, ca, cb, resid


def apply_and_match(a, R, ca, cb, b):
    """基準マークで解いた変換で a を b の座標系へ運び、最近傍で 1 対 1 に対応づける。"""
    a2 = (a - ca) @ R.T + cb
    d2 = ((a2[:, None, :] - b[None, :, :]) ** 2).sum(-1)
    pair = np.full(len(a), -1, int)
    used = np.zeros(len(b), bool)
    for k in np.argsort(d2, axis=None):
        i, j = divmod(int(k), len(b))
        if pair[i] < 0 and not used[j]:
            pair[i] = j
            used[j] = True
    resid = float(np.sqrt(((a2 - b[pair]) ** 2).sum(1)).max())
    return pair, resid


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    t0 = time.perf_counter()
    gate = aoi_ct_resemblance_gate()
    assert gate["water_streak_snr"] < 3.0
    assert gate["metal_streak_snr"] > 4.0
    assert gate["highlight_angle_error_deg"] < 2.0
    assert gate["attenuation_relative_error"] < 0.05
    print("AOI/CT resemblance: water %.2f sigma, metal %.2f sigma, reflection %.3f deg, attenuation %.2f%%"
          % (gate["water_streak_snr"], gate["metal_streak_snr"],
             gate["highlight_angle_error_deg"], 100 * gate["attenuation_relative_error"]))
    fig_device_modalities()
    out = Path(__file__).resolve().parent / "out"
    out.mkdir(exist_ok=True)
    print("== 全数 AOI と抜き取り CT の対応づけ ==")

    truth, centres, spheres = make_lot()
    n = len(centres)
    print("接合部 %d 個、ボイド合計 %d 個、体積率の真値 %.2f〜%.2f %%"
          % (n, sum(len(s) for s in spheres), truth[:, 0].min(), truth[:, 0].max()))

    # --- 1. 対応づけ ------------------------------------------------------------
    img, ax = render_aoi(centres, spheres)
    # AOI 装置は自分の座標系で報告する(並進 + 回転 + 番号の振り直し)
    rng = np.random.default_rng(SEED + 2)
    perm = rng.permutation(n)
    aoi_centres = _rigid(centres, SHIFT_XY, ROT_DEG)[perm]
    aoi_fid = _rigid(FIDUCIALS, SHIFT_XY, ROT_DEG)

    # ゼロ点: 基準マークを使わず、パッドの配置だけで対応づけようとする。
    kinds, degen = degeneracy(centres)
    print("\n1. ★対応づけは剛体変換だけでは一意に決まらない。")
    print("   パッド %d 個の距離署名は %d 種類しかなく、**%d 個が縮退**する —— "
          "%d×%d の格子は 180° 回転と 2 つの鏡映で自分自身に重なるので、"
          "「どの向きで置いたか」が点の配置からは読めない。"
          % (n, kinds, degen, PAD_NX, PAD_NY))
    assert degen == n, "格子が縮退していない(この PoC の前提が崩れる): %d" % degen

    # 基準マークを使う。3 点の相互距離がすべて違うので、対応は装置側で決まる。
    fd = np.sqrt(((FIDUCIALS[:, None, :] - FIDUCIALS[None, :, :]) ** 2).sum(-1))
    side = np.sort(fd[np.triu_indices(3, 1)])
    assert len(set(np.round(side, 6))) == 3, "基準マークが二等辺以上に対称(一意に決まらない)"
    R, ca, cb, fid_resid = solve_from_fiducials(aoi_fid, FIDUCIALS)
    rot_est = float(np.rad2deg(np.arctan2(R[1, 0], R[0, 0])))
    pair, resid = apply_and_match(aoi_centres, R, ca, cb, centres)
    ok = np.array_equal(np.asarray(pair), perm)
    print("   基準マーク 3 点(辺長 %.0f / %.0f / %.0f µm、すべて異なる)で解くと: "
          "与えた回転 %.2f° → 解いた回転 %.2f°、マークの残差 %.3g µm、"
          "パッドの残差 %.3g µm、1 対 1 の全復元 %s"
          % (side[0], side[1], side[2], ROT_DEG, rot_est, fid_resid, resid,
             "はい" if ok else "いいえ"))
    assert ok, "基準マークを使っても対応が真値と一致しない"
    assert resid < 1e-6, "剛体変換の残差が大きい: %g" % resid

    # --- 2. AOI の見かけのボイド率(投影面積率)----------------------------------
    aoi_rate = np.zeros(n)
    for i, (c, s) in enumerate(zip(centres, spheres)):
        d2 = (ax[None, :] - c[0]) ** 2
        sel_x = np.abs(ax - c[0]) <= PAD_R
        sel_y = np.abs(ax - c[1]) <= PAD_R
        sub = img[np.ix_(sel_y, sel_x)]
        GX, GY = np.meshgrid(ax[sel_x] - c[0], ax[sel_y] - c[1], indexing="xy")
        pad = (GX ** 2 + GY ** 2) <= PAD_R ** 2
        void = (sub < 0.55) & pad
        aoi_rate[i] = 100.0 * void.sum() / max(pad.sum(), 1)
    err_area = float(np.abs(aoi_rate - truth[:, 1]).max())
    print("2. AOI の面積率: 参照値との最大差 %.2f pt(画素 %g µm の量子化)" % (err_area, AOI_PX))
    assert err_area < 2.0, "AOI の面積率が参照値から離れすぎ: %.2f pt" % err_area

    # --- 3. 抜き取り CT ---------------------------------------------------------
    take = np.sort(rng.choice(n, N_SAMPLE, replace=False))
    ct_rate = np.full(n, np.nan)
    for i in take:
        vol, pad = render_ct(i, spheres)
        lab = V.vol_label((vol < 0.5) & pad, connectivity=26)
        occupied = float((1.0 - vol)[pad].sum())
        ct_rate[i] = 100.0 * occupied / float(pad.sum())
        del lab
    err_vol = float(np.abs(ct_rate[take] - truth[take, 0]).max())
    print("3. 抜き取り CT %d 個: 体積率の真値との最大差 %.2f pt(ボクセル %g µm)"
          % (N_SAMPLE, err_vol, VOX))
    assert err_vol < 1.0, "CT の体積率が真値から離れすぎ: %.2f pt" % err_vol

    # --- 4. 面積率から体積率は言えるか ------------------------------------------
    r = float(np.corrcoef(truth[:, 1], truth[:, 0])[0, 1])
    # 同じ球なら、投影面積率と体積率の比は閉じた式で決まる: (pi r^2 / pi R^2) 対
    # (4/3 pi r^3 / (pi R^2 H)) = 面積率 x (4 r / (3 H))。r は球ごとに違うので比は一定でない。
    ratio = truth[:, 0] / np.maximum(truth[:, 1], 1e-9)
    print("4. 面積率 vs 体積率: 相関 %.3f、しかし比は %.3f〜%.3f(%.1f 倍の幅)"
          % (r, ratio.min(), ratio.max(), ratio.max() / ratio.min()))
    # 順位の入れ替わり(ケンドールの tau を閉じた式で)
    o1, o2 = np.argsort(-truth[:, 1]), np.argsort(-truth[:, 0])
    conc = dis = 0
    for i in range(n):
        for j in range(i + 1, n):
            s1 = np.sign(truth[i, 1] - truth[j, 1])
            s2 = np.sign(truth[i, 0] - truth[j, 0])
            if s1 * s2 > 0:
                conc += 1
            elif s1 * s2 < 0:
                dis += 1
    tau = (conc - dis) / (conc + dis)
    swapped = dis
    top5_area = set(o1[:5].tolist())
    top5_vol = set(o2[:5].tolist())
    print("   順位: ケンドール tau %.3f、入れ替わる対 %d / %d、"
          "「悪い順 5 個」の一致 %d / 5" % (tau, swapped, conc + dis, len(top5_area & top5_vol)))
    assert swapped > 0, "順位が完全一致してしまった(この PoC の主張が立たない)"

    # --- 5. 界面に接したボイドは AOI から見えるか -------------------------------
    has_if = truth[:, 2] > 0
    r_if = float(np.corrcoef(truth[:, 1], truth[:, 2])[0, 1])
    print("5. 界面に接するボイド: %d / %d 個の接合部が保有、AOI の面積率との相関 %.3f"
          % (int(has_if.sum()), n, r_if))
    # 面積率で悪い順に 5 個選んだとき、界面接触を持つ接合部を何個拾えるか
    caught = int(has_if[o1[:5]].sum())
    total = int(has_if.sum())
    print("   面積率の悪い順 5 個で拾える界面接触 %d / %d 個(%.0f %%)"
          % (caught, total, 100.0 * caught / max(total, 1)))

    # --- 6. 抜き取りで全数を推す ------------------------------------------------
    est = float(np.nanmean(ct_rate[take]))
    true_mean = float(truth[:, 0].mean())
    se = float(np.std(truth[:, 0], ddof=1) / np.sqrt(N_SAMPLE)
               * np.sqrt(1.0 - N_SAMPLE / n))          # 有限母集団修正つき
    print("6. 抜き取り %d 個の平均 %.2f %% 対 全数の真値 %.2f %%(差 %.2f、標準誤差 %.2f)"
          % (N_SAMPLE, est, true_mean, est - true_mean, se))
    assert abs(est - true_mean) < 3.0 * se + 0.2, "抜き取りの外挿が標準誤差の 3 倍を超えた"

    # --- 図(すべて Fullseye 自身の annotate 族で描く)-----------------------------
    # ① 全数 AOI の像。抜き取った接合部を別パネルの CT 断面と並べて見せる。
    mid = None
    for i in take[:3]:
        vol, pad = render_ct(i, spheres)
        sl = vol[vol.shape[0] // 2]
        mid = [sl] if mid is None else mid + [sl]
    figs.save_grid("aoi_and_ct", [img] + mid,
                   ["全数 AOI(%d 個を一度に撮る)" % n]
                   + ["CT 断面 #%d 体積率 %.2f%%" % (i, ct_rate[i]) for i in take[:3]],
                   title="① 同じロットを 2 つの装置で撮る", ncols=2, gray=True,
                   caption="AOI は全数・2-D、CT は抜き取り・3-D。番号も座標系も装置ごとに違う。")

    # ② 面積率 vs 体積率。ゼロ点(比が一定という素朴な仮定)を直線で置く。
    k_fit = float(np.sum(truth[:, 0] * truth[:, 1]) / max(np.sum(truth[:, 1] ** 2), 1e-9))
    xs = np.linspace(0.0, float(truth[:, 1].max()) * 1.05, 2)
    figs.save_plot("area_vs_volume",
                   [("全 %d 個(真値)" % n, truth[:, 1], truth[:, 0]),
                    ("CT で実測した %d 個" % N_SAMPLE, truth[take, 1], ct_rate[take]),
                    ("比が一定と仮定(ゼロ点)", xs, k_fit * xs)],
                   kinds=["scatter", "scatter", "line"],
                   xlabel="AOI の見かけのボイド率(投影面積率)[%]",
                   ylabel="CT の体積率 [%]",
                   title="② 相関 %.3f でも比は %.1f 倍ばらつく" % (r, ratio.max() / ratio.min()),
                   caption="直線は「面積率に比例する」という素朴な仮定。点はそこから両側へ離れる。")

    # ③ 危ない側(界面に接するボイド)が AOI からどう見えるか。
    figs.save_plot("interface_voids",
                   [("体積率(全体)", np.arange(n), truth[:, 0]),
                    ("うち界面に接する", np.arange(n), truth[:, 2]),
                    ("AOI の面積率", np.arange(n), truth[:, 1])],
                   kinds=["line", "line", "scatter"],
                   xlabel="接合部の番号", ylabel="率 [%]",
                   title="③ 界面接触は AOI と相関 %.3f" % r_if,
                   caption="AOI の面積率が大きい接合部が、界面に接するボイドを持つとは限らない。")

    # ④ 数字を持ち出せる形で置く(悪い順の食い違いが主題なので上位だけ)。
    rows = []
    for rank, k in enumerate(o1[:8], 1):
        rows.append([str(rank), str(int(k)), "%.2f" % truth[k, 1], "%.2f" % truth[k, 0],
                     str(int(np.where(o2 == k)[0][0]) + 1), "%.2f" % truth[k, 2]])
    figs.save_table("worst_first",
                    ["AOI 順", "接合部", "面積率 %", "体積率 %", "CT 順", "界面接触 %"],
                    rows, title="④ AOI の悪い順と CT の悪い順",
                    caption="同じロットを同じ「悪い順」で並べても、順位は一致しない。")

    if figs.errors():
        print("図の書き出しで失敗:", "; ".join(figs.errors()))
    print("\n所要 %.1f s" % (time.perf_counter() - t0))
    print("\n== 道具の穴 ==")
    print(" * 1 対 1 の割当が op に無い(ここでは貪欲で代用。点が離れているので厳密解と一致するが、"
          "密なときは破れる)")
    print(" * 「投影面積率」を出す op が無い(blob 族は 2-D、vol 族は 3-D で、間を繋ぐ投影が無い)")
    print(" * 有限母集団修正つきの標準誤差が spc 族に無い")
    print("\n== 正直に書く ==")
    print(" * 投影面積率の『真値』は 1201x1201 の数え上げで、閉じた式ではない(円の union の"
          "解析解を避けた)。体積率の真値だけが閉じた式。")
    print(" * 寿命は測っていない。界面接触は応力の代理指標であって寿命の予測値ではない。")
    print("\nPASS: 格子は %d/%d 点が縮退するが基準マークで対応は全復元(残差 %.1g µm)、"
          "面積率と体積率の相関 %.3f・悪い順 5 個は 5/5 一致、それでも界面接触は %d/%d(%.0f %%)"
          "しか拾えない。抜き取り %d 個の外挿は真値との差 %.2f pt(標準誤差 %.2f)。"
          % (degen, n, resid, r, caught, total, 100.0 * caught / max(total, 1),
             N_SAMPLE, est - true_mean, se))


if __name__ == "__main__":
    main()
