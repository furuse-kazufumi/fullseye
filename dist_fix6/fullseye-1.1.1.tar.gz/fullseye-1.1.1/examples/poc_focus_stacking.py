# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""深度合成 —— 焦点をずらした画像列から、全焦点画像と深度地図の二つを取り出す。

EXTEND: 実際の顕微鏡 Z スタックに差し替えるには、``focal_stack`` が返す画像列を
実測フレームに、``focus_mm`` をステージの Z 座標(mm)に置き換えるだけでよい。
以降の焦点評価・融合・評価はすべてそのまま動く。ただし実データでは三つが変わる:
(1) 真値が無いので「深度の誤差」は測れず、測れるのは繰り返し再現性だけになる
(標準片を一枚入れておくと段差の真値が手に入る)。(2) ステージの Z が等間隔とは
限らない —— エンコーダ値を読むこと。等間隔だと思い込むと深度が一次で歪む。
(3) 対物レンズを動かすと像倍率が変わる(焦点ブリージング)。数 % でも段差の
境界で数画素ずれ、それは全部ハローとして深度誤差に化ける。フレーム間で
位置合わせしてから積むこと。

この PoC が示すこと:

1. **真値を自分で作れる** —— 半導体ワイヤ・ボンディング風の深度地図(ダイと
   リードフレームの高さ段差 + ボンドワイヤの弧 + ベアダイの無地面)とテクスチャ
   から、錯乱円の式で深さに応じたぼけを掛けて画像列を合成する。錯乱円の直径は
   幾何光学の閉形式 ``c = f^2 / (N (z_f - f)) * |z - z_f| / z``(f = 焦点距離、
   N = F 値、z_f = 合焦距離、z = 被写体距離)。これを画素ピッチで割って画素数に
   する。この式は ``fullseye.ledger.defocus_blur`` の中身そのもので、PoC は式を
   写経せずその op を呼ぶ。
2. ★**絵と深度(距離画像)は別物** —— 全焦点画像は 40.20 dB(ゼロ点 = 中央の
   1 枚 28.57 dB)まで行くのに、**同じ融合が出した深度(= 距離画像)**はテクスチャの
   ある所で 0.51 mm ずれ、無テクスチャ領域では **掃引全域にほぼ一様な乱数**を返す。
   領域ごとに「その領域では一つの深度と答え続ける」ゼロ点と比べると、テクスチャの
   ある所では 1.99 倍勝つのに、無テクスチャでは **0.16 倍 = ゼロ点に 6 倍負ける**。
   絵の PSNR だけ見ていると、この負けは一切見えない。(実画像は平滑金属が大半で
   単一フレームでも合焦しているため、AIF の伸びは全面テクスチャ場ほど大きくない
   —— 現場の正直な姿。)
3. ★**信頼度の作り方を間違えると、嘘の上に嘘が乗る** —— 焦点評価のピーク突出度
   ``(最大 - 中央値) / 最大`` は、無テクスチャ領域で **0.9527** と、有テクスチャ
   領域の 0.9370 より**高く**出た。相対量は絶対水準がゼロ近傍では意味を失う。
   絶対値で見ると両者は 1023 倍離れており、そちらで棄却すると全体 RMS が
   1.044 -> 0.959 mm に下がる(有テクスチャ側の誤棄却 0.0 %)。
4. **フレームを細かくしても、ある所から良くならない** —— 5 / 9 / 17 / 33 枚で
   量子化下限は 0.49 -> 0.06 mm と 8 倍下がるのに、テクスチャのある所の RMS は
   9 枚の 0.45 mm から先 0.51〜0.55 mm で頭打ち(むしろ微増)。9 枚から先の誤差は
   標本化ではなく焦点評価が持っている。

★ この PoC が出した道具の穴(op 本体は直していない。詳細は末尾の節を印字):

  (a) **per-pixel の焦点評価 op が公開 API に一つも無い**。``lightfield`` は
      持っているが ``_focus_measure`` は private で ``__all__`` にも無く、
      公開されている ``lf_depth_from_focus`` は 4-D ライトフィールドしか
      受け取らない(素の (Z, H, W) 焦点スタックを渡すと明示的に拒否する ——
      拒否そのものは正しい)。``reconstruction.depth_from_focus`` は関数として
      実在するのに **25 族どの台帳にも登録されていない**(``fs.op`` /
      ``fs.ledger`` / ``fs.<名前>`` のどれからも到達不能)。結果として、
      焦点スタックから深度を出す経路は利用者側で書き直すしかない ——
      この PoC の ``fm_laplacian`` / ``fm_tenengrad`` / ``fm_local_variance``
      がそれで、fullseye 側から使えたのは局所プーリングの ``mean_image`` だけ。
  (b) **2-D op 層(``fs.op``)の微分系はフレームごとに自分の最大値で割る**
      (``ops._norm``)。同じ被写体でもフレームごとに割る数が違うので、
      **スタックを跨いで比較できない**。この場面での係数の振れ幅は 1.62 倍あり
      (ダイの回路パターンと明るいワイヤでフレームごとに最大値が動く)、テクスチャの
      ある所の RMS が 0.509 -> 0.662 mm に悪化した。例外は出ないし、API のどこにも
      「割った」と書かれない。
  (c) **唯一の非正規化な合焦指標 ``xcv2_lap_var`` は 1.0 で飽和する**
      (``min(1.0, 分散 * 20)``)。高コントラストの被写体を 17 枚掃引すると
      **17 枚中 17 枚が厳密に 1.000000** で並び、順位が付かない
      (クリップ前の分散なら最良は一意に決まる)。
  (d) ``defocus_blur`` に遮蔽が無かった穴は **2026-11-05 に直った**(敵対的検証 第 2 巡 O1)。
      以前は層ごとの加重和で深度の順序に依存せず、奥の大きなぼけが手前の合焦面へ被り、
      境界から 30 px 内側まで縞のコントラストが戻らなかった。いまは手前から over 合成で、
      手前の合焦面の縞は境界の 5 px 内側でも理想の σ と一致する(節 10 の表、末尾の門)。
      画像列そのものが変わったので、上の数値はすべて修正後の合成で測り直してある
      (全焦点 33.69 -> 40.20 dB など)。

  拒否の側は正しく働いた: ``csi_height_map`` は (Z, H, W) という**同じ形**の
  焦点評価スタックを渡しても、もっともらしい高さを返さず、何画素がどの検査で
  落ちたかを名指しして拒否する。形が同じでも別の問題だと門が知っている。
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import examplefig as figs                                        # noqa: E402
import fullseye as fs                                            # noqa: E402
from fullseye.evaluation import rmse as evaluation_rmse           # noqa: E402
from fullseye.evaluation import save_video as save_evaluation_video  # noqa: E402

# ---------------------------------------------------------------------------
# 場面と真値
# ---------------------------------------------------------------------------
#: 画像の一辺 [px]。
SIZE = 160
#: ダイ(左)とリードフレーム(右)の境目 [px]。ここに高さの段差が出る。
STEP_X = 84
#: ボンドワイヤの根元(パッド)がある行。5 本を掃引で立体的に拾う。
WIRE_ROWS = (26, 56, 88, 118, 148)
#: 無テクスチャ(一様な金属面)の矩形 —— 焦点評価が意味を失う場所。ダイ左下の
#: 無地な金属(パッドもワイヤも無い)を置く。実機でもベアなダイ面は無地。
FLAT_BOX = (slice(100, 144), slice(6, 30))


def _draw_wire(depth, tex, y0, size):
    """1 本のボンドワイヤを描く(明るい弧 + 弧の高さを深度に焼き込む)。

    パッド(ダイ上・x≈48・203 mm)から立ち上がり、ループ頂点(≈197 mm =
    対物レンズに最も近い)を越えてウェッジ(リード上・x≈124・201.5 mm)へ降りる。
    Z を掃引すると根元・頂点・先端が順に合焦する = 合焦点法が高さを拾う筋。
    """
    t = np.linspace(0.0, 1.0, 480)
    wx = 48.0 + (124.0 - 48.0) * t
    wy = y0 + 7.0 * np.sin(np.pi * t)                        # わずかに垂れる(配線の弛み)
    wz = 203.0 * (1.0 - t) + 201.5 * t - 6.0 * np.sin(np.pi * t)   # 頂点 ≈ 197 mm
    for xk, yk, zk in zip(wx, wy, wz):
        iy, ix = int(round(yk)), int(round(xk))
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                y, x = iy + dy, ix + dx
                if 0 <= y < size and 0 <= x < size:
                    tex[y, x] = 0.95
                    depth[y, x] = zk


def ground_truth(size=SIZE, seed=7):
    """半導体ワイヤ・ボンディング風の既知シーンを作る。返りは ``(depth[mm], texture)``。

    合焦点法(depth-from-focus)が現場で使われる場面そのもの —— **ダイ上のボンド
    パッドから金線がリードフレームへ弧を描いて渡る**。ワイヤのループは対物レンズへ
    向かって立ち上がるので、Z を掃引するとパッド・ワイヤ頂点・リードが順に合焦し、
    画素ごとに高さ(= 距離画像)が出る。

    honest な作り込みは 3 つを必ず入れる: (1) ダイとリードフレームの**高さ段差**
    (境界にハローが出る)、(2) ワイヤの**なめらかな弧**(微分可能だが曲率がある)、
    (3) ボンドパッドやベアダイの**完全に無地な金属**(焦点評価が意味を失う)。
    テクスチャは乱数一色にせず、金属の微細粒 + パッド/ワイヤの明るい構造を混ぜる。
    """
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:size, 0:size].astype(np.float64)

    # ダイ(左・傾いた面 203→約 198.5 mm)/ リードフレーム(右・段差で近い、緩く傾く)。
    # 実機でも試料はわずかに傾く。傾きが無いと面の高さが一定になり「どのノブでも
    # 死なない」場になる(平面の最良定数に負けようが無い)ので、必ず傾けておく。
    depth = np.where(xx < STEP_X, 203.0 - 0.028 * yy, 201.2 - 0.010 * yy)

    # 金属面の下地(微細粒)。実ダイは回路配線で強くテクスチャが乗る —— これを
    # 入れないと合焦点法が拾う高周波が無く、面の高さが読めない(現場でも無地な
    # 金属は苦手なのが正直な姿)。ダイに回路格子、リードに微細粒を敷く。
    grain = fs.op.gauss_filter(rng.random((size, size)), a=0.10)
    grain = (grain - grain.min()) / np.ptp(grain)
    routing = (((xx // 6).astype(int) % 2) ^ ((yy // 11).astype(int) % 2)).astype(np.float64)
    tex = np.where(xx < STEP_X,
                   0.18 + 0.16 * grain + 0.16 * routing,   # ダイ = 暗め + 回路格子
                   0.50 + 0.12 * grain)                     # リード = 中庸の金属
    tex = np.clip(tex, 0.0, 1.0)

    # ボンドパッド(ダイ端の明るい四角)+ そこから伸びるワイヤ。
    for y0 in WIRE_ROWS:
        r0, r1 = max(0, y0 - 7), min(size, y0 + 7)
        tex[r0:r1, 30:48] = 0.82 + 0.06 * grain[r0:r1, 30:48]
        _draw_wire(depth, tex, y0, size)

    # ベアダイの無地な金属(回路も配線も無い場所 = 焦点評価が死ぬ)。
    tex[FLAT_BOX] = 0.35
    return depth, tex


def masks(depth):
    """評価を分けるための領域 —— 無テクスチャ / 段差帯 / それ以外。"""
    flat = np.zeros(depth.shape, bool)
    flat[FLAT_BOX] = True
    gy, gx = np.gradient(depth)
    edge = (np.abs(gy) + np.abs(gx)) > 0.5
    band = fs.op.dilation_circle(edge.astype(np.float64), a=0.6) > 0.5
    return flat, band, (~flat) & (~band)


CAMERA = fs.ledger.optical_camera(focal_mm=25.0, pixel_um=3.45,
                                  resolution=(SIZE, SIZE), working_distance_mm=200.0)


#: 絞り。★2026-10-14: defocus_blur のぼけが 2 倍広かった(σ = 錯乱円の直径/2、正しくは /4)のを直したら、F 5.6 では
#: 被写界深度が 2 倍深くなり、0.42 mm 間隔の像で奥行きが区別できなくなった(テクスチャ有の RMS 0.47 → 0.91 mm)。
#: 旧版の結果は「F 5.6 と書いて実質 F 2.8 のぼけ」の上に立っていた —— 書いた値と効いていた値を揃えて F 2.8 にする。
F_NUMBER = 2.8


def focal_stack(tex, depth, focus_mm, f_number=F_NUMBER, layers=24):
    """焦点位置ごとに 1 枚ずつ、被写界深度のぼけを掛けた画像列を作る。"""
    return np.stack([fs.ledger.defocus_blur(tex, depth, CAMERA, f_number=f_number,
                                            focus_mm=float(f), layers=layers)
                     for f in focus_mm])


# ---------------------------------------------------------------------------
# 焦点評価関数
# ---------------------------------------------------------------------------
# 点ごとの微分は自前で書いている。fullseye の 2-D op(fs.op.laplace / sobel_amp)は
# 自分の最大値で割ってから返すので、フレームを跨いで比較できないため(穴 b)。
# 局所プーリングだけは fs.op.mean_image が尺度を保つのでそちらを使う(a=0.25 = 5x5)。
_POOL = 0.25


def _laplacian(v):
    return np.abs(-4.0 * v + np.roll(v, 1, 0) + np.roll(v, -1, 0)
                  + np.roll(v, 1, 1) + np.roll(v, -1, 1))


def fm_laplacian(v):
    """ラプラシアン分散(局所窓のラプラシアン二乗和)。"""
    return fs.op.mean_image(_laplacian(v) ** 2, a=_POOL)


def fm_tenengrad(v):
    """Tenengrad(局所窓の勾配エネルギー)。"""
    gy, gx = np.gradient(v)
    return fs.op.mean_image(gx * gx + gy * gy, a=_POOL)


def fm_local_variance(v):
    """局所分散 E[x^2] - E[x]^2。"""
    m = fs.op.mean_image(v, a=_POOL)
    return np.maximum(fs.op.mean_image(v * v, a=_POOL) - m * m, 0.0)


def fm_op_laplace(v):
    """``fs.op.laplace`` 経由(**フレームごとに正規化される**)。"""
    return fs.op.mean_image(fs.op.laplace(v) ** 2, a=_POOL)


def fm_op_sobel(v):
    """``fs.op.sobel_amp`` 経由(**フレームごとに正規化される**)。"""
    return fs.op.mean_image(fs.op.sobel_amp(v) ** 2, a=_POOL)


MEASURES = (("ラプラシアン分散", fm_laplacian),
            ("Tenengrad", fm_tenengrad),
            ("局所分散", fm_local_variance),
            ("fs.op.laplace", fm_op_laplace),
            ("fs.op.sobel_amp", fm_op_sobel))


def measure_stack(stack, fn):
    """画像列 -> 焦点評価の (Z, H, W) 立方体。"""
    return np.stack([fn(s) for s in stack])


def fuse(stack, fm, focus_mm):
    """画素ごとに評価が最大のフレームを採る。

    返りは ``(全焦点画像, 深度地図, 峰の高さ, 選ばれたフレーム番号)``。
    """
    k = fm.argmax(axis=0)
    return np.take_along_axis(stack, k[None], 0)[0], focus_mm[k], fm.max(axis=0), k


def rms(x):
    value = np.asarray(x, float)
    return evaluation_rmse(value, np.zeros_like(value), mask=None, nan_policy="raise", weights=None,
                           unit="input", reduction="mean", empty="raise", domain="array")


def psnr(a, b):
    return float(fs.ledger.psnr(np.clip(a, 0.0, 1.0), b, data_range=1.0))



# ---------------------------------------------------------------------------
# 動画 —— 焦点を掃引しながら、全焦点画像と距離画像が育つ過程
# ---------------------------------------------------------------------------
def _vid_txt(img, s, xy, anchor="lt", fs_=13):
    import annotate as AN
    return np.asarray(AN.text_box(img, s, xy, anchor=anchor, font_size=fs_), dtype=np.float64)


def fig_sweep_video(stack, focus_mm, fm0, tex, depth, flat, plain):
    """焦点を 1 枚ずつ進めるたびに「ここまでの最良」で融合し直す過程を 1 本の動画にする。

    ★図を出すときだけ計算する(``figs.enabled()`` が偽なら何もしない)。新しい乱数は使わず、
    本文で計算済みの ``stack`` / ``fm0`` を前から順に読むだけなので、門の数字は動かない。
    最後のコマ(全 17 枚)の融合は本文 2・3 節の ``fuse(stack, fm0, focus_mm)`` と一致する。
    """
    if not figs.enabled():
        return None
    import annotate as AN

    n, H, W = stack.shape
    UP = 2                                         # 160 px -> 320 px(最近傍。画素を潰さない)
    PW, PH = W * UP, H * UP
    GAP, TOP, LAB = 10, 34, 24
    PLOT_H = 190
    FW = 3 * PW + 4 * GAP
    FH = TOP + PH + LAB + PLOT_H + 16
    lo, hi = float(depth.min()), float(depth.max())
    up = lambda a: np.repeat(np.repeat(a, UP, 0), UP, 1)
    gray = lambda a: np.repeat(np.clip(a, 0.0, 1.0)[..., None], 3, 2)
    p_mid = psnr(stack[n // 2], tex)

    # 掃引の途中経過を前から順に作る(argmax を k 枚目までで取り直す)
    states = []
    prev_k = None
    for k in range(n):
        kk = fm0[:k + 1].argmax(axis=0)
        fused_k = np.take_along_axis(stack[:k + 1], kk[None], 0)[0]
        dmap_k = focus_mm[kk]
        changed = (kk == k) if prev_k is None else (kk != prev_k)
        prev_k = kk
        e = dmap_k - depth
        states.append(dict(k=k, fused=fused_k, dmap=dmap_k, changed=changed,
                           psnr=psnr(fused_k, tex), rms_plain=rms(e[plain]),
                           rms_flat=rms(e[flat]), n_changed=int(changed.sum()),
                           chg_flat=float(changed[flat].mean()), chg_plain=float(changed[plain].mean())))
    ks = np.arange(n, dtype=float)
    ps = np.array([st["psnr"] for st in states])
    ylo = float(np.floor(min(ps.min(), p_mid) - 1.0))
    yhi = float(np.ceil(ps.max() + 1.0))

    frames = []
    hold = [3] * (n - 1) + [10]                    # 各段 3 コマ、最後は長めに止める
    for st, rep in zip(states, hold):
        k = st["k"]
        f = np.full((FH, FW, 3), 0.06)
        # 1) いま撮っている 1 枚。このコマで「最良」が更新された画素を橙で重ねる
        cur = gray(stack[k])
        m = st["changed"]
        cur[m] = 0.45 * cur[m] + 0.55 * np.array([1.0, 0.55, 0.0])
        # 2) ここまでの融合(全焦点画像)  3) ここまでの距離画像(尺度は全コマ共通)
        fu = gray(st["fused"])
        dm = np.clip(np.asarray(fs.colorize_depth(st["dmap"], vmin=lo, vmax=hi), float)[..., :3], 0, 1)
        for i, pnl in enumerate((cur, fu, dm)):
            x0 = GAP + i * (PW + GAP)
            f[TOP:TOP + PH, x0:x0 + PW] = up(pnl)
        labs = ("焦点 %.2f mm(%d / %d 枚目)  橙 = この 1 枚で最良が更新" % (focus_mm[k], k + 1, n),
                "ここまでの全焦点画像  PSNR %.2f dB" % st["psnr"],
                "ここまでの距離画像  %.1f〜%.1f mm" % (lo, hi))
        for i, t in enumerate(labs):
            f = _vid_txt(f, t, (GAP + i * (PW + GAP) + 2, TOP + PH + 3), fs_=11)
        f = _vid_txt(f, "焦点を掃引しながら融合し直す: 全焦点の絵は育つが、左下の無地の四角の距離は"
                        "掃引のたびに塗り替わる(テクスチャ有の誤差 %.3f mm / 無地 %.3f mm)"
                     % (st["rms_plain"], st["rms_flat"]), (GAP, 7), fs_=12)
        # 下の曲線: 全焦点画像の PSNR(ここまで)と中央 1 枚のゼロ点
        ax = AN.axes_transform((70, TOP + PH + LAB + 14, FW - 300, PLOT_H - 48),
                               (0.0, float(n - 1)), (ylo, yhi))
        f = AN.axes_frame(f, ax)
        f = AN.ticks(f, ax, xticks=[0, 4, 8, 12, 16], label_fmt="{:g}", font_size=10)
        f = np.asarray(f, float)
        f = np.asarray(AN.plot_series(f, ax, ks, np.full(n, p_mid), color=(0.6, 0.6, 0.6), width=1), float)
        if k >= 1:                                 # 折れ線は 2 点から
            f = np.asarray(AN.plot_series(f, ax, ks[:k + 1], ps[:k + 1], color=(0.35, 0.75, 1.0), width=2), float)
        f = np.asarray(AN.plot_series(f, ax, ks[k:k + 1], ps[k:k + 1], kind="scatter",
                                      color=(1.0, 0.55, 0.0), marker_size=4), float)
        f = _vid_txt(f, "全焦点画像の PSNR [dB](青)\n灰 = ゼロ点: 中央の 1 枚 %.2f dB\n横軸 = 何枚目まで使ったか"
                     % p_mid, (FW - 220, TOP + PH + LAB + 14), fs_=11)
        f = _vid_txt(f, "テクスチャ有の距離誤差 %.3f mm" % st["rms_plain"],
                     (FW - 220, TOP + PH + LAB + 86), fs_=11)
        f = np.clip(f, 0.0, 1.0)
        frames.extend([f] * rep)
    last = states[-1]
    return save_evaluation_video(
        "focus_sweep", frames, capture_fps=6.0, playback_fps=6.0, hold_frames=0, gif_stride=1,
        display_scale=720 / frames[0].shape[1], interpolation="linear",
        caption="焦点を %.2f〜%.2f mm で %d 枚掃引し、1 枚進むたびに「ここまでで焦点評価が最大の"
                "フレーム」を画素ごとに選び直す。左 = いまの 1 枚(橙 = この 1 枚で最良が更新された画素)、"
                "中 = ここまでの全焦点画像、右 = ここまでの距離画像。全焦点画像の PSNR は %.2f dB から"
                " %.2f dB へ育ち、中央の 1 枚(%.2f dB)を上回る。一方、左下の無地の四角は最後まで"
                "掃引のたびに塗り替わり(最後の 1 枚でも無地の %.0f %% が入れ替わる。テクスチャ有は %.0f %%)、"
                "距離誤差は %.3f mm(テクスチャ有 %.3f mm)で終わる。"
                % (focus_mm[0], focus_mm[-1], n, states[0]["psnr"], last["psnr"], p_mid,
                   100 * last["chg_flat"], 100 * last["chg_plain"], last["rms_flat"], last["rms_plain"]))

# ---------------------------------------------------------------------------
def main():
    depth, tex = ground_truth()
    flat, band, plain = masks(depth)
    n_frames = 17
    focus_mm = np.linspace(depth.min(), depth.max(), n_frames)

    t0 = time.perf_counter()
    stack = focal_stack(tex, depth, focus_mm)
    t_stack = 1e3 * (time.perf_counter() - t0)

    print("=== 1. 真値と画像列 ===")
    print(f"  深度 {depth.min():.2f} .. {depth.max():.2f} mm / 画像 {SIZE}x{SIZE}"
          f" / フレーム {n_frames} 枚(間隔 {focus_mm[1] - focus_mm[0]:.3f} mm)")
    print(f"  カメラ 焦点距離 {CAMERA['focal_mm']:.0f} mm / F {F_NUMBER:g} / 画素 "
          f"{1e3 * CAMERA['pixel_mm']:.2f} um / 作動距離 {CAMERA['working_distance_mm']:.0f} mm")
    f, N, zf = CAMERA["focal_mm"], F_NUMBER, 200.0
    for dz in (1.0, 4.0, 8.0):
        coc = (f * f / (N * (zf - f))) * dz / (zf + dz)
        print(f"  合焦距離 200 mm、そこから {dz:>4.1f} mm 外れた面の錯乱円 = {coc:.4f} mm"
              f" = {coc / CAMERA['pixel_mm']:>5.2f} px")
    print(f"  領域の内訳: 無テクスチャ {int(flat.sum())} px / 段差帯 {int(band.sum())} px"
          f" / テクスチャ有 {int(plain.sum())} px")

    print("\n=== 2. 全焦点画像 —— 絵としての忠実度 ===")
    fm0 = measure_stack(stack, fm_laplacian)
    fused, dmap, peak, kmap = fuse(stack, fm0, focus_mm)
    p_single = [psnr(s, tex) for s in stack]
    print(f"  {'手法':<28}{'PSNR [dB]':>12}")
    print(f"  {'融合(ラプラシアン分散)':<28}{psnr(fused, tex):>12.2f}")
    print(f"  {'ゼロ点: 中央のフレーム 1 枚':<28}{p_single[n_frames // 2]:>12.2f}")
    print(f"  {'ゼロ点: 全フレームの平均':<28}{psnr(stack.mean(axis=0), tex):>12.2f}")
    print(f"  {'参考: 単独で最良のフレーム':<28}{max(p_single):>12.2f}")
    print(f"  → ゼロ点比 {psnr(fused, tex) - p_single[n_frames // 2]:+.2f} dB。"
          "絵の側は文句なく効いている。")
    sel = np.unique(np.linspace(0, n_frames - 1, 8).round().astype(int))
    figs.save_grid("stack",
                   [stack[i] for i in sel] + [fused],
                   [f"焦点 {focus_mm[i]:.1f} mm" for i in sel] + ["融合(全焦点)"],
                   title="焦点をずらした画像列と、その融合", gray=True, ncols=3,
                   caption=f"{n_frames} 枚のうち {len(sel)} 枚と融合結果。どの 1 枚も一部しか"
                           "合っていないが、融合は全面が合う(強度画像なのでグレースケール。"
                           "ボケ→シャープが素直に見える)。")

    print("\n=== 3. 距離画像(深度地図)—— 同じ融合が出した、もう一つの答え ===")
    print("  焦点評価が最大のフレーム番号 -> その合焦距離、で画素ごとの距離が出る"
          "(全焦点画像と同じ argmax の副産物)。")
    err = dmap - depth
    null_const = float(depth.mean())
    print(f"  {'領域':<14}{'RMS [mm]':>10}{'偏り':>9}{'散らばり':>10}"
          f"{'ゼロ点RMS':>11}{'ゼロ点比':>10}")
    ratios = {}
    for label, m in (("全体", np.ones_like(flat)), ("テクスチャ有", plain),
                     ("段差帯", band), ("無テクスチャ", flat)):
        e = err[m]
        # ゼロ点 = 「その領域では一つの深度と答え続ける」。最良の定数はその領域の平均な
        # ので、ゼロ点の RMS はその領域の標準偏差そのもの。これが勝てて当然の下限。
        null_rms = float(depth[m].std())
        ratios[label] = null_rms / rms(e)
        print(f"  {label:<14}{rms(e):>10.3f}{e.mean():>9.3f}{e.std():>10.3f}"
              f"{null_rms:>11.3f}{ratios[label]:>10.2f}")
    print(f"  (全体のゼロ点は {null_const:.2f} mm と答え続ける定数。領域ごとの行では"
          "その領域の最良の定数を使っている)")
    print(f"  → 全体では {ratios['全体']:.2f} 倍にしかならない。PSNR の圧勝とは別の話。")
    print(f"     テクスチャのある所だけなら {ratios['テクスチャ有']:.2f} 倍、"
          f"無テクスチャでは {ratios['無テクスチャ']:.2f} 倍 —— **ゼロ点に負けている**。")
    # 絵(2 節)と深度(3 節)が別物であることは、誤差地図の**左下の四角**に出る。
    figs.save_grid("depth_map", [depth, dmap, err],
                   ["真値の距離 [mm]", "融合が出した距離画像 [mm]", "誤差(推定 - 真値)"],
                   title="同じ融合が出したもう一つの答え —— 距離画像(深度地図)", ncols=3,
                    signed=[False, False, True],
                    kind=["depth", "depth", "displacement"], unit="mm",
                   caption="合焦点法は全焦点画像と同時に距離画像も出す。ただし左下の"
                           "無テクスチャの四角だけ、誤差が掃引全域にばらけた乱数になって"
                           "いる(段差帯のハローも見える)—— 絵ほど距離は当てにならない。")

    print("\n=== 4. 無テクスチャ領域は何を返すか ===")
    hist = np.bincount(kmap[flat].ravel(), minlength=n_frames)
    print(f"  真値 {depth[flat].min():.2f} .. {depth[flat].max():.2f} mm /"
          f" 推定 平均 {dmap[flat].mean():.2f} 標準偏差 {dmap[flat].std():.2f} mm")
    print(f"  推定の範囲 {dmap[flat].min():.2f} .. {dmap[flat].max():.2f} mm"
          f"(= 掃引の端から端まで)")
    print(f"  選ばれたフレームの度数 {hist.tolist()}")
    print(f"  一様なら 1 枚あたり {int(flat.sum()) / n_frames:.0f} 画素。"
          "つまり答えは掃引全域にばらまかれた乱数で、値そのものに意味は無い。")
    prom = (fm0.max(axis=0) - np.median(fm0, axis=0)) / np.maximum(fm0.max(axis=0), 1e-30)
    print(f"  ★ 峰の突出度 (最大 - 中央値) / 最大 の中央値:"
          f" 有テクスチャ {np.median(prom[plain]):.4f} / 無テクスチャ {np.median(prom[flat]):.4f}")
    print("     無テクスチャのほうが**高い**。相対量は絶対水準がゼロ近傍では意味を失う。")
    print(f"  ★ 峰の絶対値の中央値: 有テクスチャ {np.median(peak[plain]):.3e} /"
          f" 無テクスチャ {np.median(peak[flat]):.3e}"
          f"(比 {np.median(peak[plain]) / np.median(peak[flat]):.0f} 倍)")
    keep = peak >= 0.02 * np.median(peak[plain])
    print(f"     絶対値で棄却すると 無テクスチャの {100 * (1 - keep[flat].mean()):.1f} % を棄却、"
          f"有テクスチャの {100 * (1 - keep[plain].mean()):.1f} % を誤棄却。")
    print(f"     残った画素の全体 RMS {rms(err[keep]):.3f} mm(棄却前 {rms(err):.3f} mm)。")
    # 相対量(突出度)と絶対量(峰の高さ)が**逆のことを言う**のがこの節の主張。
    # 峰は 5 桁以上にまたがるので対数で塗らないと無テクスチャの穴が見えない。
    # 突出度は 0.96〜0.99 の狭い帯に密集するので、その帯だけを塗り分ける
    # (全域で塗ると外れ値に潰されて「無テクスチャのほうが高い」が見えない)。
    figs.save_grid("confidence",
                   [np.clip(prom, 0.90, 1.0), np.log10(np.maximum(peak, 1e-30)),
                    keep.astype(float)],
                   ["突出度(相対)", "峰の高さ log10", "棄却後に残る画素"],
                   title="信頼度の作り方を間違えると嘘の上に嘘が乗る", ncols=3,
                   caption="左下の無テクスチャの四角が、相対量(0.90-1.00 に切って"
                           "表示)では最も明るい = 自信ありに見え、絶対量(対数)で"
                           "だけ「何も見えていない」と出る。")

    print("\n=== 5. 焦点評価関数を比べる ===")
    print(f"  {'焦点評価':<18}{'全体RMS':>9}{'テクスチャ有':>12}{'段差帯':>9}"
          f"{'無テクスチャ σ':>14}{'AIF PSNR':>10}")
    per_measure = {}
    flat_sigmas = []
    for label, fn in MEASURES:
        fm = measure_stack(stack, fn)
        fu, dm, _pk, _k = fuse(stack, fm, focus_mm)
        e = dm - depth
        per_measure[label] = (rms(e), rms(e[plain]), psnr(fu, tex))
        flat_sigmas.append(float(dm[flat].std()))
        print(f"  {label:<18}{rms(e):>9.3f}{rms(e[plain]):>12.3f}{rms(e[band]):>9.3f}"
              f"{dm[flat].std():>14.3f}{psnr(fu, tex):>10.2f}")
    print("  → 段差帯は二階微分(ラプラシアン)がハローを一番強く拾う。")
    uni = (focus_mm[-1] - focus_mm[0]) / np.sqrt(12)
    print(f"     無テクスチャの散らばりはどの評価でも {min(flat_sigmas):.1f}-{max(flat_sigmas):.1f} mm。"
          f"掃引幅 {focus_mm[-1] - focus_mm[0]:.2f} mm の一様分布なら σ = {uni:.2f} mm"
          " —— つまり誰も救えていない。")

    print("\n=== 6. ★ フレームごとの正規化という穴 ===")
    scale = [float(np.max(_laplacian(s))) for s in stack]
    print("  fs.op.laplace が内部で割る数(そのフレームの最大値):")
    print("   " + " ".join(f"{v:.3f}" for v in scale))
    print(f"  最大 / 最小 = {max(scale) / min(scale):.3f}。"
          "同じ被写体なのにフレームごとに物差しが変わる。")
    tex_hi = tex.copy()
    tex_hi[60:63, 60:63] = 1.0                       # 鏡面ハイライト 1 点(実機では普通にある)
    stack_hi = focal_stack(tex_hi, depth, focus_mm)
    scale_hi = [float(np.max(_laplacian(s))) for s in stack_hi]
    print(f"  鏡面ハイライトを 3x3 px 足すと 最大 / 最小 = {max(scale_hi) / min(scale_hi):.3f} まで開く。")
    print(f"  {'焦点評価':<18}{'テクスチャ有RMS':>15}")
    for label, fn in (("ラプラシアン分散", fm_laplacian), ("fs.op.laplace", fm_op_laplace)):
        fm = measure_stack(stack_hi, fn)
        _fu, dm, _pk, _k = fuse(stack_hi, fm, focus_mm)
        print(f"  {label:<18}{rms((dm - depth)[plain]):>15.3f}")
    print("  → 正規化した側だけが悪化する。例外は出ず、割ったことも API から見えない。")

    print("\n=== 7. ★ 唯一の非正規化な合焦指標は 1.0 で飽和する ===")
    sharp = 0.1 + 0.8 * (np.random.default_rng(3).random((SIZE, SIZE)) > 0.5)
    stack_hc = focal_stack(sharp, depth, focus_mm)
    af = np.array([float(fs.op.xcv2_lap_var(s)) for s in stack_hc])
    ref = np.array([float(np.var(-4.0 * s + np.roll(s, 1, 0) + np.roll(s, -1, 0)
                                 + np.roll(s, 1, 1) + np.roll(s, -1, 1))) for s in stack_hc])
    n_tied = int((af >= 1.0).sum())
    print(f"  高コントラストの被写体で {n_frames} 枚を掃引し、フレームごとの合焦指標を見る:")
    print(f"  {'合焦距離 [mm]':>14}{'xcv2_lap_var':>14}{'クリップ前の分散':>18}")
    for f_mm, v, rv in zip(focus_mm, af, ref):
        mark = "  <- 同点" if v >= 1.0 else ""
        print(f"  {f_mm:>14.2f}{v:>14.6f}{rv:>18.6f}{mark}")
    print(f"  → {n_frames} 枚中 {n_tied} 枚が厳密に 1.000000 で並び、順位が付かない"
          "(``min(1.0, 分散 * 20)`` のクリップ)。")
    print(f"     クリップ前の分散なら最良は {focus_mm[int(np.argmax(ref))]:.2f} mm と一意に決まる。")
    print("     オートフォーカスで順位が要るのはまさに鮮鋭な側なので、そこで使えない。")

    print("\n=== 8. フレーム間隔を粗くすると ===")
    print(f"  {'枚数':>5}{'間隔 [mm]':>11}{'量子化下限':>12}{'テクスチャ有RMS':>15}"
          f"{'全体RMS':>10}{'AIF PSNR':>10}")
    nf_rows = []
    for nf in (5, 9, 17, 33):
        fmm = np.linspace(depth.min(), depth.max(), nf)
        st = focal_stack(tex, depth, fmm)
        fu, dm, _pk, _k = fuse(st, measure_stack(st, fm_laplacian), fmm)
        e = dm - depth
        step = fmm[1] - fmm[0]
        nf_rows.append((nf, step / np.sqrt(12), rms(e[plain])))
        print(f"  {nf:>5}{step:>11.3f}{step / np.sqrt(12):>12.3f}{rms(e[plain]):>15.3f}"
              f"{rms(e):>10.3f}{psnr(fu, tex):>10.2f}")
    print("  → 量子化下限は 8 倍下がるのに RMS は 9 枚から先ほぼ動かない。")
    print("     つまり残りは標本化ではなく、焦点評価そのものが持っている誤差。")
    _nf = np.array([r[0] for r in nf_rows], float)
    figs.save_plot("frames_floor",
                   [("量子化下限(標本化で決まる分)", _nf,
                     np.array([r[1] for r in nf_rows])),
                    ("実測 RMS(テクスチャ有)", _nf,
                     np.array([r[2] for r in nf_rows]))],
                   xlabel="フレーム枚数", ylabel="深度誤差 [mm]",
                   title="細かく撮っても、ある所から良くならない",
                   caption="2 本が離れていく = 残りの誤差は標本化ではなく焦点評価が持っている。")

    print("\n=== 9. 雑音 ===")
    print(f"  {'雑音 σ':>8}{'テクスチャ有RMS':>15}{'全体RMS':>10}{'無テクスチャ σ':>15}{'AIF PSNR':>10}")
    for s in (0.0, 0.005, 0.02, 0.05):
        g = np.random.default_rng(11)
        st = stack if s == 0.0 else stack + g.normal(0.0, s, stack.shape)
        fu, dm, _pk, _k = fuse(st, measure_stack(st, fm_laplacian), focus_mm)
        e = dm - depth
        print(f"  {s:>8.3f}{rms(e[plain]):>15.3f}{rms(e):>10.3f}{dm[flat].std():>15.3f}"
              f"{psnr(fu, tex):>10.2f}")
    print("  → σ 0.02 までは深度がほとんど動かない(局所窓の平均が効く)。")
    print("     σ 0.05 で 4 倍に崩れる。絵の PSNR は同じところでもっと早く落ちている。")

    print("\n=== 10. 段差の境界 —— 手前のぼけが奥に被る ===")
    prof_h, prof_w = 64, 240
    xx = np.mgrid[0:prof_h, 0:prof_w][1].astype(np.float64)
    d2 = np.where(xx < prof_w / 2, 190.0, 220.0)
    t2 = 0.2 + 0.6 * (((xx // 4).astype(int)) % 2)
    cam2 = fs.ledger.optical_camera(focal_mm=25.0, pixel_um=3.45,
                                    resolution=(prof_w, prof_h), working_distance_mm=200.0)
    near = fs.ledger.defocus_blur(t2, d2, cam2, f_number=F_NUMBER, focus_mm=190.0, layers=2)
    print("  手前(190 mm)に合焦。手前側は境界からどこまで汚染されるか:")
    print(f"  {'境界からの距離 [px]':>20}{'縞の σ 実測':>14}{'理想':>8}")
    for dpx in (5, 15, 30, 60):
        sl = np.s_[:, max(0, 120 - dpx - 8):120 - dpx]
        print(f"  {dpx:>20d}{near[sl].std():>14.4f}{t2[sl].std():>8.4f}")
    print("  → 実光学では不透明な手前が奥を遮るので、手前側の汚染は 0 のはず。")
    print("     ``defocus_blur`` は手前から over 合成するので被らない(穴 d は 2026-11-05 に直った)。")

    print("\n=== 11. 干渉の同型問題 —— 形が同じでも通してはいけない ===")
    try:
        fs.ledger.csi_height_map(fm0, z_step_um=float(focus_mm[1] - focus_mm[0]),
                                 z_start_um=float(focus_mm[0]), wavelength_um=100.0)
        print("  通ってしまった(想定外)")
    except ValueError as e:
        head = str(e).split(" — ")[0]
        print(f"  拒否: {head}")
        print("  → (Z, H, W) という形は焦点評価スタックと同じだが、コヒーレンス包絡線を")
        print("     持たないので拒否される。何画素がどの検査で落ちたかまで言う fail-closed。")

    print("\n=== 12. 速度(この機械での実測)===")
    t1 = time.perf_counter(); fmz = measure_stack(stack, fm_laplacian)
    t_fm = 1e3 * (time.perf_counter() - t1)
    t1 = time.perf_counter(); fuse(stack, fmz, focus_mm)
    t_fuse = 1e3 * (time.perf_counter() - t1)
    print(f"  画像列の合成({n_frames} 枚 x {SIZE}x{SIZE}、24 層){t_stack:>9.1f} ms"
          f"  ({t_stack / n_frames:.1f} ms/枚)")
    print(f"  焦点評価({n_frames} 枚 x {SIZE}x{SIZE}、5x5 窓)   {t_fm:>9.1f} ms")
    print(f"  融合 + 深度                              {t_fuse:>9.1f} ms")
    print("  → 律速は合成側(層ごとにガウスを 2 回掛ける)。評価と融合は 1 桁安い。")

    # ---- 自己検査(速さは assert しない)---------------------------------
    # 1. 絵は効いている。★閾値は +3 dB —— 半導体の実画像は平滑金属(ダイ・リード)が
    #    大半で、そこは単一フレームでも合焦しているため、全面が高周波な合成パターンほど
    #    AIF の伸びは大きくない(現場の正直な姿。旧・全面テクスチャ場では +14 dB 出た)。
    assert psnr(fused, tex) > p_single[n_frames // 2] + 3.0, "全焦点画像がゼロ点に勝てていない"
    assert psnr(fused, tex) > psnr(stack.mean(axis=0), tex) + 3.0, "平均のゼロ点に勝てていない"
    # 2. 深度はテクスチャのある所でだけゼロ点に勝つ
    assert rms(err[plain]) < 0.5 * rms(depth - null_const), "有テクスチャでも定数に勝てていない"
    assert rms(err[flat]) > 2.0 * float(depth[flat].std()), \
        "無テクスチャで領域内定数のゼロ点に勝ってしまった —— 真値が漏れている疑い"
    # 3. 無テクスチャの答えは掃引全域にばらけている(= 乱数)
    assert np.ptp(dmap[flat]) > 0.9 * (focus_mm[-1] - focus_mm[0]), "無テクスチャの散らばりが小さすぎる"
    assert int((np.bincount(kmap[flat].ravel(), minlength=n_frames) > 0).sum()) == n_frames, \
        "無テクスチャで一部のフレームしか選ばれていない"
    # 4. 相対の突出度は無テクスチャで嘘をつき、絶対値は嘘をつかない
    assert np.median(prom[flat]) > np.median(prom[plain]), \
        "突出度が無テクスチャで下がった —— 穴 (3) の前提が変わっている"
    assert np.median(peak[plain]) > 100.0 * np.median(peak[flat]), "峰の絶対値が分離していない"
    assert rms(err[keep]) < rms(err), "絶対値で棄却しても改善しない"
    # 5. 段差帯はそれ以外より必ず悪い(ハローは消えない)
    assert rms(err[band]) > 2.0 * rms(err[plain]), "段差帯が悪化していない —— 段差が効いていない"
    # 6. 穴 (b): fs.op の微分はフレームごとに 1.0 へ正規化される
    for name in ("laplace", "sobel_amp"):
        assert abs(float(np.max(fs.apply(stack[0], name))) - 1.0) < 1e-12, \
            f"fs.op.{name} が最大 1.0 に正規化されていない —— 穴 (b) が直った?"
    assert max(scale) / min(scale) > 1.2, "正規化係数がフレーム間で振れていない"
    # 7. 穴 (c): 非正規化の合焦指標は 1.0 で飽和する
    assert n_tied >= 3, "xcv2_lap_var が飽和しない —— 穴 (c) が直った?"
    # 8. 旧版の穴 (a) は解消済み: per-pixel の焦点評価が台帳から届く
    assert "depth_from_focus" in fs.ledger, "depth_from_focus が台帳から消えた"
    public_depth = fs.ledger.depth_from_focus(stack, focus_positions=focus_mm)
    assert public_depth.shape == depth.shape and np.isfinite(public_depth).all(), \
        "公開 depth_from_focus が有限な深度画像を返さない"
    # 9. 穴 (d) は直った: 手前の合焦面は奥のぼけに汚されない(境界の 5 px 内側まで理想の σ)
    for dpx in (5, 15, 30, 60):
        sl = np.s_[:, max(0, 120 - dpx - 8):120 - dpx]
        assert abs(near[sl].std() / t2[sl].std() - 1.0) < 1e-6, \
            f"手前の合焦面が境界から {dpx} px で奥のぼけに汚された —— 穴 (d) が戻った"
    # 10. 形が同じでも csi_height_map は焦点評価スタックを拒否する
    try:
        fs.ledger.csi_height_map(fm0, z_step_um=float(focus_mm[1] - focus_mm[0]),
                                 z_start_um=float(focus_mm[0]), wavelength_um=100.0)
        raise AssertionError("csi_height_map が焦点評価スタックを通した")
    except ValueError:
        pass
    fig_sweep_video(stack, focus_mm, fm0, tex, depth, flat, plain)
    if figs.errors():
        print("図の書き出しで失敗:", "; ".join(figs.errors()))
    print("\nPASS")


if __name__ == "__main__":
    main()
