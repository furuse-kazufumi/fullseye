# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""PoC: 材料の光学物性ライブラリ —— 光学・音響・シンチレータの材料 96 種を 1 つの表にし、
カタログ公表値と第二実装で採点する。

【問い】観察用の光学系(レンズ・窓・鏡・膜)と観察対象(ウェハ・モールド・はんだ)は、どちらも材料の
光学特性で見え方が決まる。両方が**同じ材料表**を引けるか —— 硝材カタログの分散式、半導体の n,k の表、
金属の複素屈折率、液体とプラスチックを 1 つのレコード型に載せ、波長曲線をすべて同じ形(λ [nm], 値)で
返す。新 op 16 本(`materials`)。6 章:

  1. **硝材 46 種の Abbe 図**(4 社のカタログ、CC0 の refractiveindex.info database から): 分散式から計算した
     n_d / V_d が**カタログの公表値と 1e-4 / 0.3 以内**(46 種全部)。プラスチック・結晶・液体を同じ図に。
     **第二実装** optiland 0.6.3(同じ一次文献を別のコードで評価)の n(λ) と 23 点で 1e-6。
  2. **Si の NIR 窓**(Green 2008): 公表の点 k(1.0 µm) = 5.09e-4、k(1.2 µm) = 2.1e-7 を再現、吸収端を跨ぐ
     3 桁の落差、平行平板の透過率は閉形式(1−R)²e^{−αt}/(1−R²e^{−2αt})と 1e-9、自由キャリア吸収は
     Schroder 1978 の λ² 則、平行平板の焦点ずれ t(1 − 1/n) と縦球面収差(NA²)は閉形式。
  3. **鏡の材料**(Johnson & Christy / Rakić / Weaver): 10 金属の反射率。門: 銀は 500 nm で ≥ 0.97、
     アルミの谷は 750〜900 nm(≈ 0.87)、金は 500 nm で < 0.6・700 nm で > 0.95。色は CIE 等色関数から
     (金は R > G > B、銀はほぼ中性)。
  4. **硝子とプラスチック**: 分散曲線と dn/dT(カタログの式 A)。門: 基準温度で Δn = 0、dn/dT は Δn の
     有限差分と 1e-3、プラスチックの V_d は硝子の同じ n_d より小さい。
  5. **取り込み口**: .agf(硝材カタログ)の雛形を読んで同梱レコードと 1e-12、環境変数 ``FULLSEYE_GLASS_DIR``
     にユーザーのカタログがあれば同名の硝材を照合(無ければ「未配置」と明示)。
  6. **同じ表を引く**(第 2 段、2026-10-14): レンズ(`raytrace`)・鏡(`glassmirror`)・観察対象
     (`optscene.scene_material`)が `materials` の同じレコードを引く。門: raytrace が手で写していた 20 種の
     係数は materials と 1e-12 で同じ曲線、別のカタログの硝材・樹脂のレンズの F/d/C 線の焦点距離は厚肉レンズの
     閉形式と 1e-9、軸上色収差 Δf/f は 1/V_d と 4 % 以内(5 材料)、金属の実測経路は第二実装 optiland の
     n と 1e-6(k は写した有効数字まで)。**所見**: 初版の材料表は W と Pt に REELS 逆算の表を選んでいて、可視の反射率が
     0.84 / 0.93 と別の測定(W 0.50・Pt 0.64〜0.73)から外れていた —— 独立の表と突き合わせる門を足して差し替えた。

【外部真値】refractiveindex.info database(CC0 1.0、Polyanskiy, Sci. Data 11, 94 (2024))の一次文献と
カタログ公表値、Green, Sol. Energy Mater. Sol. Cells 92, 1305 (2008)、Johnson & Christy, Phys. Rev. B 6,
4370 (1972)、Schroder, Thomas & Swartz, IEEE TED 25, 254 (1978)、optiland 0.6.3(OSS、第二実装)。
硝材は銘柄名でなく、カタログ公表の n_d・ν_d から引き、6 桁の硝材コード(n_d の小数 3 桁 + ν_d × 10)で
表示する(BK7・SF11 相当の 2 種は慣用の分類名で書く)。係数の出どころは公開の硝材カタログ値。
【学習した数】0。【較正】0。
"""
from __future__ import annotations

import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import examplefig as figs  # noqa: E402
import fullseye as fs  # noqa: E402
import materials as MT  # noqa: E402
import realdata  # noqa: E402

REDUCED = os.environ.get("FULLSEYE_POC_BUDGET",
                         "reduced" if os.environ.get("CI") else "full") == "reduced"
GLASS_DIR = os.environ.get("FULLSEYE_GLASS_DIR", "").strip()

def _glass(nd: float, vd: float) -> str:
    """カタログ公表の n_d・ν_d に一致する同梱の硝材を 1 つ引き、表のキーを返す。

    公開側のソースに銘柄名(社名が分かる型番)を書かないための入口。一致が 1 つでなければ
    ValueError(黙って別の硝材を選ばない)。
    """
    hit = [r["name"] for r in MT.material_table("glass")
           if abs(r["nd"] - nd) < 5e-6 and abs(r["vd"] - vd) < 5e-4]
    if len(hit) != 1:
        raise ValueError("n_d %.6f / ν_d %.6f に一致する硝材が %d 件" % (nd, vd, len(hit)))
    return hit[0]


def _code(name: str) -> str:
    """6 桁の硝材コード(n_d − 1 の小数 3 桁 + ν_d × 10)。"""
    a = MT.abbe_number(name)
    return "%03d%03d" % (round((a["nd_catalog"] - 1.0) * 1000.0), round(a["vd_catalog"] * 10.0))


#: 慣用の分類名で書く硝材(材料表の別名)と、樹脂の一般名。
BK7, SF11, COP = (MT.material_record(a)["name"] for a in ("BK7", "SF11", "COP"))
G516641 = _glass(1.51633, 64.142022)        # BK7 と同じ帯のホウケイ酸クラウン(別カタログ)
G517642B = _glass(1.5168, 64.198732)        # 同上(さらに別のカタログ)
G517642C = _glass(1.5168, 64.2)             # 同上(.agf の雛形に入っている方)
G805255 = _glass(1.80518, 25.46)            # 重フリント
G847238 = _glass(1.84667, 23.791236)        # 重フリント(最も分散が大きい側)
G883408 = _glass(1.882997, 40.765107)       # 高屈折率ランタン系


def _catalogue_letter() -> dict:
    """硝材ごとのカタログを A, B, … の記号にする(どの社かは書かない。出典は各レコードの一次文献)。"""
    first = []
    for r in MT.material_table("glass"):
        key = str(r["reference"]).split()[0]
        if key not in first:
            first.append(key)
    return {r["name"]: "ABCDEFGH"[first.index(str(r["reference"]).split()[0])] for r in MT.material_table("glass")}


def _label(name: str) -> str:
    """図・表・ログに出す材料名。硝材は分類名か 6 桁コード、樹脂は一般名。"""
    rec = MT.material_record(name)
    if rec["name"] == BK7:
        return "BK7 相当"
    if rec["name"] == SF11:
        return "SF11 相当"
    if rec["name"] == COP:
        return "COP"
    if rec["class"] == "glass":
        code = _code(rec["name"])
        dup = sum(_code(r["name"]) == code for r in MT.material_table("glass")) > 1
        return "硝材 %s%s" % (code, "(カタログ %s)" % _catalogue_letter()[rec["name"]] if dup else "")
    return rec["name"]


#: 第二実装 optiland 0.6.3(同じ refractiveindex.info の一次文献を別のコードで評価、2026-10-14 実行)。
#: (材料, λ nm) → (n, k)。Si は Green 2008 と Salzberg、水は n が Daimon(20 ℃)と Hale の区間。
#: ★2026-10-15: 水の k を Hale & Querry 1973 から Segelstein 1981 に差し替えた(RII の Hale の表は NIR を
#: 0.2 µm おきにしか持たず、1.45 / 1.94 µm の吸収帯を線形補間で 1/3 に潰していた。n は滑らかなので Hale のまま)。
#: 1500 nm の k は optiland 0.6.3 の MaterialFile で Segelstein.yml を評価し直した値(2.2392e-4)。
OPTILAND = {
    (BK7, 400): (1.530848538, 1.0227e-08), (BK7, 1550): (1.500652043, 1.4361e-07),
    (SF11, 500): (1.802555175, 7.6618e-08), (G516641, 600): (1.515825156, 1.4345e-08),
    (G517642B, 700): (1.513071801, 1.6736e-08), (G805255, 900): (1.779252370, 1.4338e-08),
    (G847238, 800): (1.823406896, 1.2745e-08), ("SI", 1000): (3.572000000, 5.0930e-04),
    ("SI", 3000): (3.432322072, 0.0), ("AG", 500): (0.050000000, 3.1309e+00),
    ("AU", 600): (0.248731988, 3.0740e+00), ("SILICA", 1064): (1.449630990, 0.0),
    ("CAF2", 1500): (1.426257966, 0.0), ("GE", 1550): (4.250000000, 2.5190e-02),
    ("ZNSE", 1200): (2.471354515, 0.0), ("ZNS", 800): (2.313185509, 0.0),
    ("TIO2", 633): (2.583580138, 0.0), ("HFO2", 550): (1.902098695, 0.0),
    ("GAN", 450): (2.486916613, 0.0), ("PMMA", 800): (1.484307203, 0.0),
    ("WATER", 500): (1.336795977, 0.0), ("WATER", 1500): (1.319000000, 2.2392e-04),
    ("SAPPHIRE", 800): (1.760132585, 0.0),
}

#: Green 2008 の表の公表点(λ µm, n, k)。
GREEN_2008 = {1.0: (3.572, 5.093e-4), 1.2: (3.520, 2.1008e-7), 0.5: (4.294, 4.4165e-2)}

METALS = ["AG", "AL", "AU", "CU", "RH", "CR", "NI", "W", "TI", "PT"]

FAILS: list[str] = []
GATES: list[str] = []
NUMBERS: dict[str, float] = {}


def gate(name: str, ok: bool, detail: str = "") -> None:
    print("   [%s] %s%s" % ("ok" if ok else "NG", name, (" — " + detail) if detail else ""))
    GATES.append(name)
    if not ok:
        FAILS.append(name)


def _at(curve, x):
    return float(curve[int(np.argmin(np.abs(curve[:, 0] - x))), 1])


# --------------------------------------------------------------------------- #
# 1. 硝材の Abbe 図と第二実装                                                    #
# --------------------------------------------------------------------------- #
def chapter_glass():
    print("\n1. 硝材 46 種の Abbe 図(カタログ公表値)と第二実装 optiland")
    cat = MT.material_table()
    print("   同梱 %d 材料: %s" % (len(cat), ", ".join("%s %d" % (c, sum(r["class"] == c for r in cat))
                                                   for c in MT.CLASSES[:-1])))
    gate("同梱の材料は 96 種(光学 89 種・発光の列だけのシンチレータ 4 種・音響専用 3 種)", len(cat) == 96
         and sum(r["class"] == "glass" for r in cat) == 46)
    rec = MT.material_record("SI")
    print("   例: Si のレコード = %s、区間 %s" % (rec["class"], ", ".join("%s %s %.3g-%.3g µm (%s)" % (
        d["type"], d.get("formula", ""), d["range_um"][0], d["range_um"][1], d["page"].split("/")[-1]) for d in rec["datasets"])))
    gate("レコードは区間ごとに一次文献のページを持つ(Si は Green 2008 と Salzberg)",
         all(d["page"].endswith(".yml") for d in rec["datasets"]) and len(rec["datasets"]) == 2)
    worst_n, worst_v = 0.0, 0.0
    rows = []
    for r in MT.material_table("glass"):
        a = MT.abbe_number(r["name"])
        dn, dv = abs(a["nd"] - a["nd_catalog"]), abs(a["vd"] - a["vd_catalog"])
        worst_n, worst_v = max(worst_n, dn), max(worst_v, dv)
        rows.append((r["name"], a["nd"], a["nd_catalog"], a["vd"], a["vd_catalog"], a["PgF"] if a["PgF"] is not None else float("nan"), r["density_kg_m3"]))
    NUMBERS["glass_worst_dn"], NUMBERS["glass_worst_dv"] = worst_n, worst_v
    gate("46 種すべてで分散式の n_d がカタログ公表値と 1e-4 以内、V_d が 0.3 以内",
         worst_n <= 1e-4 and worst_v <= 0.3, "最大 |Δn_d| %.1e、|ΔV_d| %.3f" % (worst_n, worst_v))
    gm = MT.glass_map()
    cls = {c: [g for g in gm if g["class"] == c] for c in ("glass", "polymer", "crystal", "liquid", "film", "semiconductor")}
    print("   Abbe 図に載る材料 %d(硝材 %d・高分子 %d・結晶 %d・液体 %d・膜 %d・半導体 %d)"
          % (len(gm), *[len(cls[c]) for c in ("glass", "polymer", "crystal", "liquid", "film", "semiconductor")]))
    gate("可視で吸収する金属は Abbe 図に載らず、硝材 46 種は全部載る",
         not any(g["class"] == "metal" for g in gm) and len(cls["glass"]) == 46)
    pm = {g["name"]: g for g in gm}
    gate("プラスチック 4 種はどれも V_d < 60(硝子なら同じ n_d のクラウンが 60 前後)",
         all(pm[p]["vd"] < 60 for p in ("PMMA", "POLYCARBONATE", "POLYSTYRENE", COP)),
         "PMMA %.1f / PC %.1f / PS %.1f / COP %.1f" % tuple(pm[p]["vd"] for p in ("PMMA", "POLYCARBONATE", "POLYSTYRENE", COP)))
    worst, worst_k, zero_k = 0.0, 0.0, 0.0
    for (name, wl), (n2, k2) in OPTILAND.items():
        a = MT.material_optical_constants(name, wl)
        worst = max(worst, abs(a["n"] - n2))
        if k2 > 0:
            worst_k = max(worst_k, abs(a["k"] / k2 - 1.0))
        else:
            zero_k = max(zero_k, abs(a["k"]))
    NUMBERS["optiland_worst"] = worst
    NUMBERS["optiland_worst_k_rel"] = worst_k
    # ★2026-10-15: 以前は k の相対差に 1e-6 を掛けて n の門に混ぜていたので、k が ±100 % ずれても通った。
    #   写した k は有効数字 5 桁(1.4361e-07 など)なので、丸めの幅は相対 5e-5。optiland が k を持たない点(0)では
    #   こちらも 1e-8 未満(水の 500 nm は Segelstein の 9e-10、吸収の無い区間)。
    gate("第二実装 optiland の n(λ) と %d 点で 1e-6 以内、k は写した桁(相対 5e-5)、k を持たない点は 1e-8 未満" % len(OPTILAND),
         worst <= 1e-6 and worst_k <= 5e-5 and zero_k < 1e-8,
         "n 最大 %.1e・k 相対 %.1e・k の 0 点 %.1e" % (worst, worst_k, zero_k))
    return rows, gm


# --------------------------------------------------------------------------- #
# 2. Si の NIR 窓                                                               #
# --------------------------------------------------------------------------- #
def chapter_silicon():
    print("\n2. Si の NIR 窓(Green 2008)、平行平板の透過率と焦点ずれ、自由キャリア吸収")
    for wl, (n_pub, k_pub) in sorted(GREEN_2008.items()):
        a = MT.material_optical_constants("SI", wl * 1e3)
        gate("Si %.1f µm: n = %.3f, k = %.4g(Green 2008 の表の点)" % (wl, n_pub, k_pub),
             abs(a["n"] - n_pub) < 5e-4 and abs(a["k"] / k_pub - 1.0) < 1e-3, "n %.4f k %.4g" % (a["n"], a["k"]))
    # 同梱表の Si(Green 2008 の実測の n,k の表)を公表の点と照合し終えた
    realdata.mark_read("refractiveindex-info-green2008-si")
    al = MT.material_absorption("SI", 900, 1400, 101)
    a10, a12 = _at(al, 1000), _at(al, 1200)
    NUMBERS["si_alpha_1000"], NUMBERS["si_alpha_1200"] = a10, a12
    gate("吸収係数は 1.0 → 1.2 µm で 3 桁落ちる(吸収端 ≈ 1.1 µm)", a10 / a12 > 1e3, "%.1f → %.4f /cm" % (a10, a12))
    t_mm = 0.775
    T = MT.material_transmittance("SI", t_mm, 900, 1400, 101)
    c12 = MT.material_optical_constants("SI", 1200.0)
    R = c12["reflectance_normal"]
    inner = np.exp(-c12["alpha_per_cm"] * t_mm * 0.1)
    closed = (1 - R) ** 2 * inner / (1 - R * R * inner * inner)
    NUMBERS["si_T_1200"], NUMBERS["si_T_1000"] = _at(T, 1200), _at(T, 1000)
    gate("775 µm のウェハ: T(1.2 µm) = (1−R)²e^{−αt}/(1−R²e^{−2αt}) と 1e-9", abs(_at(T, 1200) - closed) < 1e-9,
         "%.4f(R = %.3f なので多重反射込みで半分強)" % (_at(T, 1200), R))
    gate("775 µm のウェハ: T(1.0 µm) < 1 %(吸収端の上は透過しない)", _at(T, 1000) < 0.01, "%.2e" % _at(T, 1000))
    Ti = MT.material_transmittance("SI", t_mm, 900, 1400, 101, include_fresnel=False)
    gate("内部透過率は Fresnel 込みより大きく、1.3 µm で 0.99 以上", np.all(Ti[:, 1] >= T[:, 1] - 1e-12) and _at(Ti, 1300) > 0.99,
         "内部 %.4f / 全体 %.4f" % (_at(Ti, 1300), _at(T, 1300)))
    fc = MT.silicon_free_carrier_absorption(1e19, "n", 1000, 2000, 101)
    fcp = MT.silicon_free_carrier_absorption(1e19, "p", 1000, 2000, 101)
    gate("自由キャリア吸収は λ²(1.0 → 2.0 µm で 4 倍)、p 型は n 型の 2.7 倍(Schroder 1978)",
         abs(_at(fc, 2000) / _at(fc, 1000) - 4.0) < 1e-9 and abs(_at(fcp, 1300) / _at(fc, 1300) - 2.7) < 1e-9,
         "n 型 1e19 cm⁻³ の 1.3 µm で %.1f /cm" % _at(fc, 1300))
    NUMBERS["fc_1e19_1300"] = _at(fc, 1300)
    T_doped = np.exp(-_at(fc, 1300) * t_mm * 0.1)
    print("   高濃度基板(1e19 cm⁻³、775 µm)は 1.3 µm で自由キャリアだけで ×%.2f に暗くなる" % T_doped)
    NUMBERS["fc_T_1e19"] = T_doped
    p = MT.plate_focus_shift("SI", t_mm, 1100.0, 0.1)
    gate("平行平板の近軸焦点ずれ = t(1 − 1/n)、縦球面収差 = Δ(θ) − Δ₀ > 0",
         abs(p["paraxial_shift_mm"] - t_mm * (1 - 1 / p["n"])) < 1e-12 and p["spherical_aberration_mm"] > 0,
         "Δ₀ %.3f mm、NA 0.1 で収差 %.1f µm" % (p["paraxial_shift_mm"], p["spherical_aberration_mm"] * 1e3))
    NUMBERS["plate_shift"], NUMBERS["plate_sa"] = p["paraxial_shift_mm"], p["spherical_aberration_mm"]
    p3 = MT.plate_focus_shift("SI", t_mm, 1100.0, 0.3)
    gate("縦球面収差は NA の 2 乗(NA 0.1 → 0.3 で 8.5〜9.5 倍、波面収差なら 4 乗)",
         8.5 < p3["spherical_aberration_mm"] / p["spherical_aberration_mm"] < 9.5,
         "%.2f 倍、NA 0.3 で %.1f µm" % (p3["spherical_aberration_mm"] / p["spherical_aberration_mm"], p3["spherical_aberration_mm"] * 1e3))
    return T, Ti, fc


# --------------------------------------------------------------------------- #
# 3. 鏡の材料                                                                   #
# --------------------------------------------------------------------------- #
def chapter_mirror():
    print("\n3. 鏡の材料 10 種の反射率と色")
    R = {m: MT.material_reflectance(m, 300, 1900, 161) for m in METALS}
    # 同梱表の金属の実測 n,k(Johnson & Christy ほか)を読んだ
    realdata.mark_read("refractiveindex-info-metals-nk")
    gate("銀は 500 nm で R ≥ 0.97(Johnson & Christy)", _at(R["AG"], 500) >= 0.97, "%.4f" % _at(R["AG"], 500))
    ral = R["AL"]
    sel = (ral[:, 0] >= 400) & (ral[:, 0] <= 1500)
    imin = int(np.argmin(np.where(sel, ral[:, 1], 9.0)))
    NUMBERS["al_dip_nm"], NUMBERS["al_dip_R"] = ral[imin, 0], ral[imin, 1]
    gate("アルミの反射率の谷は 750〜900 nm(バンド間遷移)", 750 <= ral[imin, 0] <= 900, "最小 %.3f at %.0f nm" % (ral[imin, 1], ral[imin, 0]))
    gate("金は 500 nm で R < 0.6、700 nm で R > 0.95(黄色い理由)", _at(R["AU"], 500) < 0.6 and _at(R["AU"], 700) > 0.95,
         "%.3f / %.3f" % (_at(R["AU"], 500), _at(R["AU"], 700)))
    gate("銅も 500 nm では金と同じ側(R < 0.65)で 700 nm で > 0.95", _at(R["CU"], 500) < 0.65 and _at(R["CU"], 700) > 0.95)
    def _vis(m):
        r = R[m][(R[m][:, 0] >= 400) & (R[m][:, 0] <= 700), 1]
        return float(np.ptp(r)), float(r.mean())
    grey = {m: _vis(m) for m in ("RH", "CR", "NI", "W", "PT", "TI")}
    gate("灰色の鏡(Rh・Cr・Ni・W・Pt・Ti)は可視の変化が金(%.2f)の半分以下で、平均は銀(%.3f)より暗い"
         % (_vis("AU")[0], _vis("AG")[1]),
         all(v[0] < 0.5 * _vis("AU")[0] and v[1] < _vis("AG")[1] for v in grey.values()),
         " / ".join("%s 変化 %.2f 平均 %.2f" % (m, v[0], v[1]) for m, v in grey.items()))
    import matappear
    grid = np.linspace(380.0, 780.0, 81)
    rgb = {}
    for m in METALS:
        Rv = MT.material_reflectance(m, 380, 780, 81)[:, 1]
        rgb[m] = np.asarray(matappear.spectrum_to_srgb(grid, Rv), dtype=np.float64).ravel()
    gate("色は塗っていない: 金と銅は R > G > B、銀は 3 成分が 10 % 以内で中性",
         rgb["AU"][0] > rgb["AU"][1] > rgb["AU"][2] and rgb["CU"][0] > rgb["CU"][1] > rgb["CU"][2]
         and np.ptp(rgb["AG"]) / rgb["AG"].max() < 0.10,
         "Au %s Ag %s" % (np.round(rgb["AU"], 3), np.round(rgb["AG"], 3)))
    Rs = MT.material_reflectance("AL", 633, 634, 2, angle_deg=60.0, polarization="s")[0, 1]
    Rp = MT.material_reflectance("AL", 633, 634, 2, angle_deg=60.0, polarization="p")[0, 1]
    Ru = MT.material_reflectance("AL", 633, 634, 2, angle_deg=60.0)[0, 1]
    gate("斜入射(60°)で s > p、無偏光は平均", Rs > Rp and abs(Ru - 0.5 * (Rs + Rp)) < 1e-12, "s %.3f p %.3f" % (Rs, Rp))
    return R, rgb


# --------------------------------------------------------------------------- #
# 4. 硝子とプラスチック                                                          #
# --------------------------------------------------------------------------- #
def chapter_plastic():
    print("\n4. 硝子とプラスチックの分散と dn/dT")
    names = [BK7, SF11, "SILICA", "CAF2", "PMMA", "POLYCARBONATE", COP]
    disp = {n: MT.material_dispersion(n, 440, 1000, 57) for n in names}
    def slope(n):
        d = disp[n]
        return (d[0, 1] - d[-1, 1]) / d[0, 1]
    gate("ポリカーボネートの分散(440 → 1000 nm の n の落ち)は BK7 相当の 2 倍以上、CaF2 は BK7 相当より小さい",
         slope("POLYCARBONATE") > 2 * slope(BK7) and slope("CAF2") < slope(BK7),
         "PC %.4f / BK7 相当 %.4f / CaF2 %.4f" % (slope("POLYCARBONATE"), slope(BK7), slope("CAF2")))
    th_names = [BK7, SF11, G516641, G805255, G847238]
    temps = np.linspace(-20.0, 80.0, 41)
    th = {}
    worst = 0.0
    for n in th_names:
        tref = MT.thermo_optic_coefficient(n, 546.07, 20.0)["reference_temperature_c"]
        a = MT.thermo_optic_coefficient(n, 546.07, tref)
        gate("%s: 基準温度 %.0f ℃ で Δn = 0" % (_label(n), tref), abs(a["delta_n"]) < 1e-15)
        dn = np.array([MT.thermo_optic_coefficient(n, 546.07, t)["delta_n"] for t in temps])
        th[n] = dn
        # dn/dT = dΔn/dT を 40 ℃ の有限差分で確かめる(式 A の D₁・D₂・E₁ の項まで)
        h = 0.01
        fd = (MT.thermo_optic_coefficient(n, 546.07, 40.0 + h)["delta_n"] - MT.thermo_optic_coefficient(n, 546.07, 40.0 - h)["delta_n"]) / (2 * h)
        an = MT.thermo_optic_coefficient(n, 546.07, 40.0)["dn_dt_per_k"]
        worst = max(worst, abs(fd / an - 1.0))
    gate("dn/dT は Δn の有限差分と 1e-3 以内(5 種、40 ℃)", worst < 1e-3, "最大 %.1e" % worst)
    bk = MT.thermo_optic_coefficient(BK7, 546.07, 30.0)["dn_dt_per_k"]
    NUMBERS["bk7_dndt"] = bk
    gate("BK7 相当の dn/dT(e 線、20〜40 ℃)は 1.4〜1.8e-6 /K", 1.4e-6 < bk < 1.8e-6, "%.2e /K" % bk)
    for n in ("PMMA", "WATER"):
        try:
            MT.thermo_optic_coefficient(n)
            gate("%s に dn/dT の係数は無い → ValueError" % n, False)
        except ValueError:
            gate("%s に dn/dT の係数は無い → ValueError(黙って 0 にしない)" % n, True)
    return disp, temps, th


# --------------------------------------------------------------------------- #
# 5. 取り込み口                                                                 #
# --------------------------------------------------------------------------- #
def chapter_import():
    print("\n5. 硝材カタログ(.agf)の取り込みと自前の材料")
    recs = MT.read_glass_catalog_agf(None)
    worst = 0.0
    for r in recs:
        for wl in (400.0, 587.56, 800.0, 1000.0):
            worst = max(worst, abs(MT.material_optical_constants(r, wl)["n"] - MT.material_optical_constants(r["name"], wl)["n"]))
    gate("雛形 .agf の %s を読むと同梱レコードと 1e-12 以内(Sellmeier 1 とべき級数の分散式の両方)" % " / ".join(_label(r["name"]) for r in recs),
         worst < 1e-12 and [r["name"] for r in recs] == [BK7, G517642C], "最大 %.1e" % worst)
    k = MT.material_optical_constants(recs[0], 400.0)["k"]
    gate("IT 行(内部透過率)から k を復元する(BK7 相当の 400 nm で 1e-9〜1e-7)", 1e-9 < k < 1e-7, "%.2e" % k)
    custom = MT.material_from_sellmeier("my_glass", reference="worked example")
    gate("自前の Sellmeier 係数(既定は BK7 相当)からレコードを作り、他の op に渡せる",
         abs(MT.abbe_number(custom)["nd"] - 1.5168) < 1e-4)
    cur = MT.material_from_curves(MT.material_dispersion(SF11, 400, 1000, 61), MT.material_extinction(SF11, 400, 1000, 61), "measured")
    gate("測った曲線(pairs)から作ったレコードは節で元と一致し、区間外は外挿しない",
         abs(MT.material_optical_constants(cur, 600.0)["n"] - MT.material_optical_constants(SF11, 600.0)["n"]) < 1e-12)
    try:
        MT.material_optical_constants(cur, 1200.0)
        gate("区間外は ValueError", False)
    except ValueError:
        gate("区間外は ValueError", True)
    if GLASS_DIR and os.path.isdir(GLASS_DIR):
        user = MT.read_glass_catalog_agf(GLASS_DIR)
        hit = [r for r in user if r["name"] in MT.MATERIALS]
        worst = 0.0
        for r in hit:
            lo, hi = r["datasets"][0]["range_um"]
            for wl in np.linspace(max(lo, 0.4), min(hi, 1.0), 4):
                worst = max(worst, abs(MT.material_optical_constants(r, wl * 1e3)["n"] - MT.material_optical_constants(r["name"], wl * 1e3)["n"]))
        print("   ユーザーのカタログ: %d 硝材、同梱と同名 %d、n の最大差 %.1e" % (len(user), len(hit), worst))
        NUMBERS["user_glass_count"] = len(user)
        gate("ユーザーのカタログの同名硝材は同梱レコードと 1e-4 以内", worst < 1e-4, "%.1e" % worst)
    else:
        print("   ユーザーの硝材カタログ(FULLSEYE_GLASS_DIR)は未配置 —— 雛形だけで採点")
    return recs


#: 550 nm の垂直反射率。materials に選んだ表と、refractiveindex.info database の別の一次文献
#: (2026-10-14 に読んだ値)。"REELS" は初版が選んでいた Werner 2009 の電子エネルギー損失からの逆算。
DATASET_R550 = {
    "W": {"REELS": 0.836, "independent": {"Rakić 1998 LD": 0.496, "Werner 2009 DFT": 0.537}},
    "PT": {"REELS": 0.934, "independent": {"Rakić 1998 LD": 0.641, "Werner 2009 DFT": 0.734}},
}

#: レンズの材料(別々のカタログの硝材と樹脂)。焦点距離の色収差を閉形式と比べる。
LENS_MEDIA = [BK7, G883408, G847238, "PMMA", "POLYCARBONATE"]


def chapter_shared():
    """6. レンズ・鏡・観察対象が同じ材料表を引く。"""
    print("\n6. 同じ表を引く(raytrace / glassmirror / optscene → materials)")
    import glassmirror as GM
    import optscene as OS
    import raytrace as RT
    names = RT.glass_catalog()
    local = names[:20]
    lam = np.linspace(0.40, 0.95, 56)
    worst = 0.0
    for nm in local:
        a = np.array([RT.refractive_index(nm, w) for w in lam])
        b = MT.material_dispersion(nm, 400, 950, 56)[:, 1]
        worst = max(worst, float(np.max(np.abs(a - b))))
    NUMBERS["local_vs_table"] = worst
    gate("raytrace が手で写していた 20 種の Sellmeier 係数は materials と同じ曲線(400〜950 nm で 1e-12)",
         len(local) == 20 and worst < 1e-12, "最大 %.1e" % worst)
    transparent = [m for m in MT.MATERIALS if MT.material_record(m)["class"] in ("glass", "crystal", "polymer", "liquid")
                   and any(d["type"] in ("formula", "nk", "n") for d in MT.material_record(m)["datasets"])]
    gate("レンズの媒質の一覧 = 透過材 %d 種(硝材・結晶・樹脂・水)、金属はレンズに使えない" % len(transparent),
         sorted(names) == sorted(transparent) and _refuses(lambda: RT.glass_catalog("AU")), "%d 種" % len(names))
    lens = {}
    worst_f, worst_v = 0.0, 0.0
    for g in LENS_MEDIA:
        sysd = RT.lens_system([{"R": 50.0, "t": 4.0, "n": g, "ap": 8}, {"R": -50.0, "t": None, "n": 1.0}])
        rows = RT.chromatic_shift(sysd)["per_wavelength"]
        for r in rows:
            n = RT.refractive_index(g, r["wavelength_um"])
            worst_f = max(worst_f, abs(r["efl"] - RT.thick_lens(50.0, -50.0, 4.0, n)["efl"]))
        f = [r["efl"] for r in rows]
        vd = RT.glass_catalog(g)["vd"]
        ratio = (f[2] - f[0]) / f[1] * vd
        worst_v = max(worst_v, abs(ratio - 1.0))
        lens[g] = (vd, f, ratio)
    NUMBERS["lens_efl_worst"], NUMBERS["lens_colour_worst"] = worst_f, worst_v
    gate("別のカタログの硝材・樹脂のレンズ(%d 種)の F/d/C 線の焦点距離 = 厚肉レンズの閉形式(その線の n)と 1e-9" % len(LENS_MEDIA),
         worst_f < 1e-9, "最大 %.1e mm" % worst_f)
    gate("軸上色収差 (f_C − f_F)/f_d は 1/V_d と 4 %% 以内(薄肉レンズの式、%d 種)" % len(LENS_MEDIA), worst_v < 0.04,
         " / ".join("%s %.3f" % (_label(g), v[2]) for g, v in lens.items()))
    w = np.linspace(400.0, 800.0, 81)
    pinned = [("AG", 500), ("AU", 600)]
    worst_n, worst_k = 0.0, 0.0
    for m, wl in pinned:
        n, k = GM.metal_optical_constants(m.lower(), float(wl), source="materials")
        n2, k2 = OPTILAND[(m, wl)]
        worst_n = max(worst_n, abs(float(n) - n2))
        worst_k = max(worst_k, abs(float(k) - k2) / k2)
    # 写した optiland の k は有効数字 5 桁(3.1309 など)なので、k の門はその丸め幅 2e-5 まで
    gate("鏡の op の実測経路(source=\"materials\")は第二実装 optiland と n で 1e-6、k で写した桁(相対 2e-5)まで一致",
         worst_n < 1e-6 and worst_k < 2e-5, "n 最大 %.1e・k 相対 %.1e" % (worst_n, worst_k))
    coarse, measured, dmax = {}, {}, {}
    for m in GM.METALS:
        n1, k1 = GM.metal_optical_constants(m, w, source="table")
        n2, k2 = GM.metal_optical_constants(m, w, source="materials")
        coarse[m] = np.asarray(GM.fresnel_conductor(1.0, n1, k1), dtype=np.float64)
        measured[m] = np.asarray(GM.fresnel_conductor(1.0, n2, k2), dtype=np.float64)
        i = int(np.argmax(np.abs(coarse[m] - measured[m])))
        dmax[m] = (float(abs(coarse[m][i] - measured[m][i])), float(w[i]))
    NUMBERS["coarse_worst"] = max(v[0] for v in dmax.values())
    rgb_t = {m: np.asarray(GM.metal_mirror_rgb(m, source="table"), dtype=np.float64) for m in GM.METALS}
    rgb_m = {m: np.asarray(GM.metal_mirror_rgb(m, source="materials"), dtype=np.float64) for m in GM.MEASURED_METALS}
    warm = all(c["au"][0] > c["au"][1] > c["au"][2] and c["cu"][0] > c["cu"][1] > c["cu"][2] for c in (rgb_t, rgb_m))
    gate("粗い表(5 点)と実測の表で、金・銅は両方とも R > G > B(色の順序は表の粗さに依らない)", warm,
         "粗い表と実測の差は最大 %.3f(%s)" % (NUMBERS["coarse_worst"],
                                              " / ".join("%s %.3f at %.0f nm" % (m, d, x) for m, (d, x) in dmax.items())))
    r550 = {m: MT.material_optical_constants(m, 550.0)["reflectance_normal"] for m in DATASET_R550}
    ok = True
    for m, d in DATASET_R550.items():
        ind = list(d["independent"].values())
        lo, hi = min(ind) - 0.03, max(ind) + 0.03
        ok &= lo <= r550[m] <= hi and not (lo <= d["REELS"] <= hi)
    gate("W と Pt の 550 nm 反射率は別の測定 2 本の幅に入り、初版の REELS 逆算(0.84 / 0.93)は入らない", ok,
         "W %.3f・Pt %.3f" % (r550["W"], r550["PT"]))
    mat = OS.scene_material("dielectric", glass=G883408)
    nrgb = np.array([RT.refractive_index(G883408, u) for u in OS._RGB_UM])
    met = OS.scene_material("conductor", metal="pt", metal_source="materials")
    # 2026-10-15: scene_material の金属の既定は実測の表(glassmirror の既定と同じ)。粗い表を選んだときだけ Pt を拒む
    gate("観察対象の材質(optscene)も同じ表: 別のカタログの硝材の n_RGB は raytrace と一致、Pt の材質は実測の表(既定)で作れ、粗い表では拒む",
         np.array_equal(mat["n_rgb"], nrgb) and met["metal_source"] == "materials"
         and OS.scene_material("conductor", metal="pt")["metal_source"] == "materials" and _refuses(
             lambda: OS.scene_material("conductor", metal="pt", metal_source="table")), "n_RGB %s" % np.round(mat["n_rgb"], 4))
    return lens, coarse, measured, w, rgb_t, rgb_m, r550


def _refuses(fn) -> bool:
    try:
        fn()
    except ValueError:
        return True
    return False


def chapter_acoustic_and_doping():
    """7 材料の音響表と、ドープ濃度を配線した Si 透過率を採点する。"""
    print("\n7. 同じ材料レコードの音響物性とドープ Si の透過率")
    names = ("water", "silicon", "sio2", "copper", "air", "polyimide", "epoxy_underfill")
    acoustic = [MT.material_acoustic(name) for name in names]
    gate("7 材料の密度・縦波音速・音響インピーダンスに出典がある",
         all(r["acoustic_source"] and r["acoustic_impedance_mrayl"] ==
             r["density_kg_m3"] * r["sound_speed_longitudinal_m_s"] / 1e6 for r in acoustic))
    mismatch = MT.acoustic_impedance_mismatch("water", "silicon")
    z1, z2 = mismatch["impedance1_mrayl"], mismatch["impedance2_mrayl"]
    gate("水と Si の音響反射率はインピーダンス不整合の閉形式と一致",
         mismatch["reflection"] == ((z2 - z1) / (z2 + z1)) ** 2)
    doping = (0.0, 1e15, 1e18)
    curves = [MT.material_transmittance("SI", 0.775, 1100, 1600, 101,
                                       doping_cm3=None if n == 0 else n) for n in doping]
    gate("775 µm Si の 1.2 µm 透過率はキャリア密度 0 → 1e15 → 1e18 cm⁻³ で単調減少",
         _at(curves[0], 1200) > _at(curves[1], 1200) > _at(curves[2], 1200))
    return acoustic, doping, curves


# --------------------------------------------------------------------------- #
# 図                                                                            #
# --------------------------------------------------------------------------- #
def make_figures(glass, si, mirror, plastic, agf, shared, acoustic_doping):
    import matappear  # noqa: F401
    rows, gm = glass
    T, Ti, fc = si
    R, rgb = mirror
    disp, temps, th = plastic
    series, kinds, colors = [], [], []
    for cls, label, col in (("glass", "硝材 46 種(4 社)", "neutral"), ("polymer", "プラスチック 4 種", "emphasis"),
                            ("crystal", "結晶・IR 材", "right"), ("liquid", "水", "reference"), ("film", "膜", "wrong"),
                            ("semiconductor", "半導体(GaN・SiC)", "wrong")):
        pts = [g for g in gm if g["class"] == cls]
        if pts:
            series.append((label, np.array([g["vd"] for g in pts]), np.array([g["nd"] for g in pts])))
            kinds.append("scatter")
            colors.append(col)
    figs.save_plot("abbe_diagram", series, xlabel="Abbe 数 V_d(慣例と逆向きに右へ増える)", ylabel="n_d",
                   title="Abbe 図: 同梱 %d 材料(硝材はカタログ公表値と |Δn_d| ≤ %.0e、|ΔV_d| ≤ %.3f)"
                         % (len(gm), NUMBERS["glass_worst_dn"], NUMBERS["glass_worst_dv"]),
                   kinds=kinds, colors=colors,
                   caption="分散式(refractiveindex.info の一次文献、CC0)から計算した n_d と V_d。プラスチックは同じ n_d の硝子より左(分散が大きい)、CaF2 と石英は右端。")
    letter = _catalogue_letter()
    figs.save_table("glass_catalogue", ["硝材コード", "カタログ", "n_d 計算", "n_d 公表", "V_d 計算", "V_d 公表", "P_g,F", "密度 kg/m³"],
                    [[_code(r[0]), letter[r[0]], "%.5f" % r[1], "%.5f" % r[2], "%.2f" % r[3], "%.2f" % r[4], "%.4f" % r[5], "%.0f" % r[6]] for r in rows[:46]],
                    title="硝材 46 種: 分散式の n_d / V_d とカタログ公表値", caption="4 つの公開カタログ(記号 A〜D)の Sellmeier 式とべき級数の分散式を同じレコード型で評価した。"
                            "硝材コードは n_d − 1 の小数 3 桁と V_d × 10(係数の出どころは公開の硝材カタログ値)。")
    figs.save_table("second_implementation", ["材料", "λ nm", "n (optiland 0.6.3)", "n (fullseye)", "k (optiland)", "k (fullseye)"],
                    [[_label(nm), "%g" % wl, "%.9f" % n2, "%.9f" % MT.material_optical_constants(nm, wl)["n"], "%.4e" % k2,
                      "%.4e" % MT.material_optical_constants(nm, wl)["k"]] for (nm, wl), (n2, k2) in OPTILAND.items()],
                    title="第二実装との突き合わせ(最大差 %.1e)" % NUMBERS["optiland_worst"],
                    caption="同じ一次文献を optiland(MIT)が別のコードで評価した値。式 1〜5 と数表の補間が同じ答えを返す。")
    # 2. Si
    wl = np.linspace(250.0, 1450.0, 241)
    n_si = MT.material_dispersion("SI", 250, 1450, 241)
    k_si = MT.material_extinction("SI", 250, 1450, 241)
    pub = np.array(sorted(GREEN_2008))
    figs.save_plot("silicon_index", [("n(λ)", n_si[:, 0], n_si[:, 1]), ("Green 2008 の表の点", pub * 1e3, np.array([GREEN_2008[w][0] for w in pub]))],
                   xlabel="波長 [nm]", ylabel="n", title="Si の屈折率(Green 2008、300 K)", kinds=["line", "scatter"], colors=["emphasis", "reference"],
                   caption="紫外の 370 nm 付近で n ≈ 6.9 の峰(直接遷移)、NIR で 3.5。")
    keep = k_si[:, 1] > 0
    figs.save_plot("silicon_extinction", [("log10 k(λ)", k_si[keep, 0], np.log10(k_si[keep, 1])),
                                          ("Green 2008 の表の点", pub * 1e3, np.log10([GREEN_2008[w][1] for w in pub]))],
                   xlabel="波長 [nm]", ylabel="log10 k", title="Si の消衰係数: 吸収端 ≈ 1.1 µm で 3 桁落ちる",
                   kinds=["line", "scatter"], colors=["emphasis", "reference"],
                   caption="k(1.0 µm) = 5.1e-4 → k(1.2 µm) = 2.1e-7。NIR 透過検査が 1.1 µm より長い波長を使う理由。")
    ths = [0.1, 0.3, 0.775, 2.0]
    figs.save_plot("silicon_transmittance", [("%g mm" % t, *(MT.material_transmittance("SI", t, 900, 1400, 101).T)) for t in ths],
                   xlabel="波長 [nm]", ylabel="透過率(多重反射込み)", title="Si 平板の透過率(厚さ別)", ylim=(0.0, 0.6),
                   caption="吸収端の上は厚さに関わらず 0、下は (1−R)²/(1−R²) ≈ 0.53 に漸近(n ≈ 3.5 の Fresnel 損失)。")
    frames = []
    for t in np.geomspace(0.05, 3.0, 20):
        Tt = MT.material_transmittance("SI", float(t), 900, 1400, 101)
        img = figs.render_plot([("厚さ %.2f mm" % t, Tt[:, 0], Tt[:, 1])], xlabel="波長 [nm]", ylabel="透過率",
                               title="Si 平板 %.2f mm: T(1.1 µm) %.3f、T(1.2 µm) %.3f、T(1.3 µm) %.3f" % (t, _at(Tt, 1100), _at(Tt, 1200), _at(Tt, 1300)),
                               colors=["emphasis"], ylim=(0.0, 0.6), xlim=(900.0, 1400.0))
        frames.append(np.asarray(img))
    figs.save_gif("silicon_window_thickness", frames, fps=4.0,
                  caption="厚さ 0.05 → 3 mm: 吸収端が長波長側へ押され、1.1 µm の肩が消えていく。薄いダイなら 1.0 µm 台でも透け、厚いウェハは 1.2 µm 以上。")
    dops = np.logspace(14, 20, 61)
    curves = []
    for wl_nm in (1200.0, 1300.0, 1550.0):
        a = np.array([_at(MT.silicon_free_carrier_absorption(N, "n", wl_nm, wl_nm + 1, 2), wl_nm) for N in dops])
        curves.append(("n 型 %.0f nm" % wl_nm, np.log10(dops), np.exp(-a * 0.775 * 0.1)))
    figs.save_plot("silicon_free_carrier", curves, xlabel="log10 キャリア密度 [cm⁻³]", ylabel="自由キャリア吸収だけの透過率(775 µm)",
                   title="自由キャリア吸収(Schroder 1978、α = 1e-18 N λ²)", ylim=(0.0, 1.05),
                   caption="1e18 cm⁻³ を超える基板は吸収端の下でも暗くなり、長波長ほど(λ²)早く落ちる。")
    nas = np.linspace(0.02, 0.5, 49)
    sa = np.array([MT.plate_focus_shift("SI", 0.775, 1100.0, float(na))["spherical_aberration_mm"] for na in nas]) * 1e3
    sh = np.array([MT.plate_focus_shift("SI", 0.775, 1100.0, float(na))["marginal_shift_mm"] for na in nas]) * 1e3
    figs.save_plot("plate_focus_shift", [("縁の光線の焦点ずれ [µm]", nas, sh), ("縦球面収差 [µm]", nas, sa),
                                         ("近軸 Δ₀ = t(1−1/n)", nas, np.full_like(nas, NUMBERS["plate_shift"] * 1e3))],
                   xlabel="NA", ylabel="µm", title="Si ウェハ 775 µm 越しの焦点(1.1 µm): 近軸で %.0f µm、縦球面収差は NA²" % (NUMBERS["plate_shift"] * 1e3),
                   styles=[None, None, "dashed"], colors=["emphasis", "right", "reference"],
                   caption="平行平板は像を t(1−1/n) 奥へ動かし、NA の 2 乗で縦球面収差(波面では 4 乗)を足す。ウェハ越しの結像で NA を抑える理由。")
    # 3. 鏡
    figs.save_plot("mirror_reflectance", [(m, R[m][:, 0], R[m][:, 1]) for m in METALS], xlabel="波長 [nm]", ylabel="垂直入射の反射率",
                   title="鏡の材料 10 種(Johnson & Christy / Rakić / Weaver)", ylim=(0.0, 1.0),
                   caption="銀は可視〜NIR で最も明るく 400 nm 以下で落ちる。アルミは 815 nm に谷。金・銅は 500 nm 以下で暗い(黄・赤)。")
    sw = np.ones((180, 100 * len(METALS), 3))
    for i, m in enumerate(METALS):
        c = np.clip(rgb[m], 0.0, 1.0) ** (1 / 2.2)
        sw[20:120, i * 100 + 5:i * 100 + 95] = c
        sw = np.asarray(fs.text_box(sw, m, (i * 100 + 50, 130), anchor="ct", font_size=12))
    figs.save("mirror_colours", sw, caption="n,k → 分光反射率 → CIE 等色関数 → sRGB。色は塗っていない: 金と銅が暖色で銀が中性なのは表の n,k から出る。")
    # 4. 分散と dn/dT
    figs.save_plot("dispersion_glass_vs_plastic", [(_label(n), disp[n][:, 0], disp[n][:, 1]) for n in disp], xlabel="波長 [nm]", ylabel="n",
                   title="硝子・結晶・プラスチックの分散(440〜1000 nm)",
                   caption="ポリカーボネートは BK7 相当の 2 倍以上の落ち(V_d ≈ 30)。CaF2 と石英はほぼ平ら。")
    figs.save_plot("thermo_optic", [(_label(n), temps, th[n] * 1e6) for n in th], xlabel="温度 [℃]", ylabel="Δn × 1e6(e 線、真空中)",
                   title="硝材の温度による屈折率変化(カタログの式 A)",
                   caption="重フリント(硝材 805255)は低温側で負の dn/dT を持つ。基準温度(20 ℃ / 25 ℃)で 0 を通る。")
    # 6. 同じ表を引く
    lens, coarse, measured, w, rgb_t, rgb_m, r550 = shared
    import raytrace as RT
    lam = np.linspace(440.0, 1000.0, 57)                 # PMMA の表は 436.8 nm から
    curves = []
    for g in LENS_MEDIA:
        sysd = RT.lens_system([{"R": 50.0, "t": 4.0, "n": g, "ap": 8}, {"R": -50.0, "t": None, "n": 1.0}])
        fd = lens[g][1][1]
        efl = [RT.paraxial_trace(RT.with_wavelength(sysd, float(x) / 1000.0))["efl"] / fd for x in lam]
        curves.append(("%s(V_d %.1f)" % (_label(g), lens[g][0]), lam, (np.array(efl) - 1.0) * 100.0))
    figs.save_plot("lens_axial_colour", curves, xlabel="波長 [nm]", ylabel="焦点距離の変化 [%](d 線基準)",
                   title="同じ形のレンズを材料表の 5 材料で: 色収差は 1/V_d(閉形式と最大 %.1e mm)" % NUMBERS["lens_efl_worst"],
                   caption="R = ±50 mm・厚さ 4 mm の両凸レンズ。材料のキーを変えるだけで、別のカタログの硝材も樹脂も同じ光線追跡に乗る。動きは 1/V_d に比例: PMMA は BK7 相当の 1.2 倍、高屈折率ランタン系(硝材 883408)は 1.6 倍、ポリカーボネートと重フリント(硝材 847238)は 2.3〜2.7 倍。")
    import glassmirror as GM
    series, styles, colors = [], [], []
    palette = {"ag": "neutral", "al": "reference", "au": "emphasis", "cr": "wrong", "cu": "right"}
    for m in GM.METALS:
        series += [("%s 実測の表" % m.upper(), w, measured[m]), ("%s 5 点の粗い表" % m.upper(), w, coarse[m])]
        styles += [None, "dashed"]
        colors += [palette[m], palette[m]]
    figs.save_plot("metal_table_vs_measured", series, xlabel="波長 [nm]", ylabel="垂直入射の反射率", styles=styles, colors=colors,
                   title="鏡の op の 2 つの経路: 5 点の粗い表(既定)と実測の数表(最大差 %.3f)" % NUMBERS["coarse_worst"], ylim=(0.3, 1.0),
                   caption="既定は従来どおり粗い表(既存の図と値を変えない)。source=\"materials\" で一次文献の数表になる。差が大きいのは銅の 565 nm の肩(0.13)と銀の 400 nm(0.10)。")
    names = list(GM.MEASURED_METALS)
    sw = np.ones((300, 100 * len(names), 3))
    for i, m in enumerate(names):
        if m in rgb_t:
            sw[10:95, i * 100 + 5:i * 100 + 95] = np.clip(rgb_t[m], 0.0, 1.0) ** (1 / 2.2)
        sw[150:240, i * 100 + 5:i * 100 + 95] = np.clip(rgb_m[m], 0.0, 1.0) ** (1 / 2.2)
        sw = np.asarray(fs.text_box(sw, m.upper(), (i * 100 + 50, 250), anchor="ct", font_size=12))
    sw = np.asarray(fs.text_box(sw, "上: 5 点の粗い表(5 種)  下: 実測の数表(10 種)", (10, 104), anchor="lt", font_size=12))
    figs.save("mirror_colours_two_tables", sw,
              caption="同じ等色関数で、n,k の出どころだけを変えた。Ni・Pt・Ti・W・Rh は実測の表で初めて選べる。W と Pt が灰色なのは REELS 逆算の表を外したから(初版は Pt が 0.93 で銀に近かった)。")
    figs.save_table("metal_dataset_choice", ["金属", "選んだ表の R(550 nm)", "初版(REELS 逆算)", "別の測定 1", "別の測定 2"],
                    [[m, "%.3f" % r550[m], "%.3f" % d["REELS"]] + ["%s %.3f" % kv for kv in d["independent"].items()]
                     for m, d in DATASET_R550.items()],
                    title="材料表の選定の誤り: W と Pt",
                    caption="同じ金属でも一次文献で反射率が 0.3 違う。表を 1 本に決めるなら、別の測定と突き合わせる門が要る。")
    acoustic, doping, curves = acoustic_doping
    figs.save_table("material_acoustic", ["材料", "密度 kg/m³", "縦波音速 m/s", "音響インピーダンス MRayl", "検証"],
                    [[r["material"], "%.4g" % r["density_kg_m3"], "%.5g" % r["sound_speed_longitudinal_m_s"],
                      "%.5g" % r["acoustic_impedance_mrayl"], "済" if r["verified"] else "代表値"] for r in acoustic],
                    title="同じ材料レコードから引く音響物性 7 種",
                    caption="音響インピーダンスは密度と縦波音速の積。未検証の代表値は表で明示し、既定では超音波計算に使わない。")
    figs.save_plot("silicon_doped_transmittance",
                   [("真性" if n == 0 else "%.0e cm⁻³" % n, c[:, 0], c[:, 1]) for n, c in zip(doping, curves)],
                   xlabel="波長 [nm]", ylabel="透過率", title="775 µm Si: 自由キャリア濃度による透過率低下",
                   ylim=(0.0, 0.6), caption="材料固有の k(λ)へ既存の λ² 自由キャリア吸収を加えた。濃度が高いほど透過率が下がる。")


def main():
    t0 = time.time()
    print("PoC 材料の光学物性ライブラリ(予算 %s、ユーザーの硝材カタログ %s)" % ("reduced" if REDUCED else "full", "あり" if GLASS_DIR else "未配置"))
    glass = chapter_glass()
    si = chapter_silicon()
    mirror = chapter_mirror()
    plastic = chapter_plastic()
    agf = chapter_import()
    shared = chapter_shared()
    acoustic_doping = chapter_acoustic_and_doping()
    if not REDUCED and figs.target_dir() is not None:
        make_figures(glass, si, mirror, plastic, agf, shared, acoustic_doping)
    print("\n所要 %.1f s、門 %d 件中 NG %d 件" % (time.time() - t0, len(GATES), len(FAILS)))
    if FAILS:
        print("FAIL: " + ", ".join(FAILS))
        sys.exit(1)
    assert not figs.errors(), figs.errors()
    print("PASS")


if __name__ == "__main__":
    main()
