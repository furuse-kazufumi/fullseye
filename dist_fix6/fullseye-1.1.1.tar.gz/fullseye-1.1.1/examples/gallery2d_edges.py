# -*- coding: utf-8 -*-
"""事例: 2-D エッジ / 微分 / コーナー演算子ギャラリー (task: edges)

平たく言うと (この op ファミリーは何のためのものか):
  「画像のどこで明るさが急に変わるか(= 輪郭・エッジ)」「どこが角か(= コーナー特徴点)」
  を取り出す演算子ファミリー。中身は 4 系統 --
    * 一次微分の輪郭検出: sobel / prewitt / roberts / scharr / frei-chen / kirsch / robinson,
      勾配の強さ (amp/mag) と向き (dir) を返すもの。
    * 二次微分・帯域通過: laplace / LoG (laplace_of_gauss) / DoG (diff_of_gauss) / dog,
      ゼロ交差でエッジ、平坦部やなだらかな勾配には応答しない。
    * コーナー/特徴点: harris / min-eigen / foerstner / GFTT / FAST / Moravec / Kanade-Rosenfeld,
      直線エッジではなく「二方向に曲がる角」で強く応答。
    * 拡張系 (x*/f2_*/tf_*): PIL/scipy/wavelet/steerable/位相合同性 (phase congruency) や
      shock filter・topographic など、別バックエンド由来のエッジ・コーナー表現。
  用途: 物体の輪郭抽出、トラッキング/マッチング用の特徴点、欠陥・画質のエッジ強調。

検証(グラウンドトゥルース / 数値で嘘を弾く):
  edges カテゴリの **全 op** を実入力 (conftest 由来の再現画像) で呼び、op ごとに
    (1) 出力が有限     -- NaN / Inf を含まない
    (2) 宣言 out_sort と一致 -- image は 2 次元 float かつ値域 [0,1]
    (3) 決定的         -- 同一入力 → ビット一致 (2 回呼んで array_equal)
  を強制する。例外を投げた op は握りつぶさず即失敗させる。
  さらに挙動が既知の代表 op には beat-the-null つきの強い GT を課す:
    * sobel/prewitt/roberts_mag は段差(エッジ列)で強く応答し、平坦部では ~0
      (定数画像 = 勾配ゼロでは応答の分散 ~0)。
    * laplace / dog は定数画像(勾配ゼロ)に応答せず(帯域通過に DC 成分なし)、
      段差では明確に応答する。
    * cv_corner_harris は正方形の「角」で直線エッジ・平坦部より強く応答する
      (エッジ検出器ではなくコーナー検出器であることの確認)。

  edges カテゴリの全 op を漏れなく呼び、上記契約を全 op に、GT を代表 op に適用する。
  2026-09-02 まで registry には 'laplace' が 2 度登録されていた (ops.py のコア実装 +
  backends_auto の再定義; 9 通りの入力で出力は完全一致 = 純粋な重複)。本例はそれを
  「既知の癖」として明記し、57 エントリ / 56 ユニーク名という数で辻褄を合わせていた。
  重複は ops.py 側の登録で弾くようになった (名前は addressing の鍵で、同名を 2 つ
  登録すると先の 1 つが名前で引けなくなり、しかも抽選には両方入って確率が 2 倍に
  なるため)。いまは 56 エントリ = 56 ユニーク名。

    py -3.11 examples/gallery2d_edges.py
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # repo root first

import numpy as np  # noqa: E402
from scipy import ndimage  # noqa: E402
import ops  # noqa: E402


# --------------------------------------------------------------------------- #
# 入力ファクトリ -- tests/conftest.py の image_bank / color_bank "normal" を複製。 #
# (examples は tests/ から import しない規約のため、構成をここに再掲する)          #
# --------------------------------------------------------------------------- #
def _image_normal(n: int = 48) -> np.ndarray:
    """conftest.image_bank(n)['normal'] と同一構成の 2-D float 画像 (値域 [0,1])。"""
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    grad = xx / (n - 1)
    disk = ((yy - n * 0.35) ** 2 + (xx - n * 0.4) ** 2) < (n * 0.18) ** 2
    checker = ((xx.astype(int) // 6 + yy.astype(int) // 6) % 2) * 0.15
    noise = 0.03 * np.random.default_rng(20260812).standard_normal((n, n))
    return np.clip(0.35 * grad + 0.45 * disk + checker + noise, 0, 1)


def _color_normal(n: int = 48) -> np.ndarray:
    """conftest.color_bank(n)['normal'] と同一構成の HxWx3 カラー画像。"""
    g = _image_normal(n)
    return np.clip(np.stack([g, 0.7 * g + 0.1, 1 - g], -1), 0, 1)


def input_for(in_sort: str) -> np.ndarray:
    """op.in_sort に合う妥当な入力を返す。edges ファミリーで出会う sort は image / color のみ。"""
    if in_sort == "image":
        return _image_normal()
    if in_sort == "color":
        return _color_normal()
    # registry が別 sort の edges op を増やしたら黙って通さず落とす。
    raise ValueError(f"input_for: unexpected in_sort for edges family: {in_sort!r}")


# --------------------------------------------------------------------------- #
# TARGET op 名 -- edges カテゴリの登録順・全 56 エントリを文字列リテラルで明示。    #
# (2026-09-02 まで 'laplace' が重複登録されていて 2 回現れていた; 下の drift      #
#  チェックで live registry の名前マルチセットと突き合わせる)。索引はこの列を読む。 #
# うち 5 件 (KORNIA_OPTIONAL) は backends_kornia (要 torch+kornia) 由来の任意 op で、  #
# 未インストール環境では registry から静かに消える (backends_kornia.build が [] を    #
# 返す; ops.py 側は例外を握りつぶす)。BASE = 常設分、OPTIONAL = kornia 依存分。         #
# --------------------------------------------------------------------------- #
OPS = [
    "sobel_mag", "laplace", "prewitt_mag", "roberts_mag", "dog", "grad_dir",
    "edge_transition_width",
    "log", "corner_response", "sk_scharr", "sk_farid", "sk_dog", "sk_hessian_det",
    "sk_corner_harris", "cv_scharr", "cv_laplacian", "cv_corner_harris",
    "cv_min_eigen", "cv_precorner", "derivate_gauss", "laplace_of_gauss",
    "diff_of_gauss", "sobel_amp", "sobel_dir", "prewitt_amp", "prewitt_dir",
    "roberts", "kirsch_amp", "kirsch_dir", "frei_amp", "robinson_amp",
    "points_foerstner", "points_harris_binomial", "dots_image",
    "frei_dir", "robinson_dir", "edges_color", "xsk_hessian_eig", "xpil_contour",
    "xpil_find_edges", "xsp_morph_laplace", "xsp_gauss_grad_mag", "xsk2_corner_kr",
    "xsk2_inv_gauss_grad", "xwt_hf_reconstruct", "xwt_directional_detail",
    "xsk3_corner_moravec", "xsk3_corner_fast", "xkor_laplacian", "xkor_harris",
    "xkor_gftt", "xkor_hessian", "xkor_dog", "f2_shock", "f2_shock_diffuse", "xdog", "f2_topographic",
    "tf_steerable_filter", "tf_phase_congruency",
]

# kornia backend 依存の任意 op (torch/kornia 不在なら registry に現れない)。
KORNIA_OPTIONAL = ["xkor_laplacian", "xkor_harris", "xkor_gftt", "xkor_hessian", "xkor_dog"]
BASE_OPS = [n for n in OPS if n not in KORNIA_OPTIONAL]  # 常設分 (= 53)

_TOL = 1e-6  # 値域 [0,1] 判定の浮動小数許容。


def _validate(name: str, op, out) -> None:
    """1 op の出力に契約 (有限 / out_sort 一致 / 値域) を課す。違反は AssertionError。"""
    if op.out_sort in ("image", "region"):
        arr = np.asarray(out, dtype=np.float64)
        assert arr.ndim == 2, f"{name}: {op.out_sort} は 2 次元のはず (got ndim={arr.ndim})"
        assert np.all(np.isfinite(arr)), f"{name}: 非有限値 (NaN/Inf) を含む"
        lo, hi = float(arr.min()), float(arr.max())
        assert -_TOL <= lo and hi <= 1 + _TOL, f"{name}: 値域が [0,1] 外: ({lo}, {hi})"
    elif op.out_sort == "contour":
        assert isinstance(out, dict) and "cs" in out, f"{name}: contour は 'cs' を持つ dict のはず"
    elif op.out_sort == "feature":
        arr = np.asarray(out, dtype=np.float64)
        assert arr.ndim <= 1 and np.all(np.isfinite(arr)), f"{name}: feature は有限のスカラ/1D"
    else:
        raise AssertionError(f"{name}: 未対応の out_sort {op.out_sort!r}")


def _call_twice(op, sort):
    """同一入力で 2 回呼び、(出力, 決定的か) を返す。in-place 変更に備え copy を渡す。"""
    base = input_for(sort)
    a = op.fn(base.copy(), 0.5, 0.5)
    b = op.fn(base.copy(), 0.5, 0.5)
    deterministic = np.array_equal(np.asarray(a), np.asarray(b))
    return a, deterministic


# --------------------------------------------------------------------------- #
# GT 用の合成画像 (効果が既知)。                                                 #
# --------------------------------------------------------------------------- #
def _step_edge(n: int = 48) -> np.ndarray:
    x = np.zeros((n, n)); x[:, n // 2:] = 1.0  # 左 0 / 右 1、col=n/2 に縦エッジ
    return x


def _constant(n: int = 48, v: float = 0.4) -> np.ndarray:
    return np.full((n, n), v)


def _filled_square(n: int = 48) -> np.ndarray:
    x = np.zeros((n, n)); x[14:34, 14:34] = 1.0  # 4 隅を持つ塗り正方形
    return x


def _ground_truth_checks(BY) -> int:
    """挙動が既知の代表 op に beat-the-null つきの強い GT を課す。GT 件数を返す。"""
    n = 48
    step, const, sq = _step_edge(n), _constant(n), _filled_square(n)
    checks = 0

    # 一次微分エッジ検出: 段差で強く応答し平坦部では ~0。定数画像では応答分散 ~0。
    for name, margin in (("sobel_mag", 0.3), ("prewitt_mag", 0.3), ("roberts_mag", 0.2)):
        o = BY[name].fn(step.copy(), 0.5, 0.5)
        edge_resp = float(o[:, n // 2 - 1:n // 2 + 1].mean())
        flat_resp = float(o[:, 4:8].mean())
        assert edge_resp > flat_resp + margin, (
            f"GT {name}: エッジ応答 {edge_resp:.4f} が平坦部 {flat_resp:.4f} を上回らない")
        oc = BY[name].fn(const.copy(), 0.5, 0.5)
        assert float(oc.std()) < 1e-6, (
            f"GT {name}: 勾配ゼロの定数画像で応答が出ている (std={oc.std():.2e})")
        checks += 1

    # エッジ遷移幅: **ぼかすほど幅が広がる**。ぼけを作る simulate_defocus の対で、
    # こちらは測る側。理想の段差(σ=0)は 1 画素、σ でぼかせば約 2.507σ 画素になる
    # (ガウシアンの最大傾き 1/(σ√(2π)) の逆数) —— これは解析解なので強い GT になる。
    _etw = BY["edge_transition_width"].fn
    _k9 = 9                                    # a=0.99 -> 窓 9
    widths = []
    for sigma in (0.0, 1.0, 2.0):
        e = _step_edge(n) if sigma == 0 else ndimage.gaussian_filter(_step_edge(n), sigma)
        o = _etw(e, 0.99, 0.5) * _k9
        widths.append(float(o[:, n // 2 - 4:n // 2 + 5].max()))
    assert widths[0] < 1.05, (
        f"GT edge_transition_width: 理想の段差が 1 画素でない ({widths[0]:.3f}) — "
        "中心差分に戻ると 2.0 になる")
    assert widths[0] < widths[1] < widths[2], (
        f"GT edge_transition_width: ぼかしても幅が単調に増えない {widths}")
    assert abs(widths[1] - 2.507) < 0.35, (
        f"GT edge_transition_width: σ=1 の解析解 2.507 から離れすぎ ({widths[1]:.3f})")
    _flat = _etw(_constant(n), 0.99, 0.5)
    assert float(np.abs(_flat).max()) == 0.0, (
        f"GT edge_transition_width: 空フレームに端を見ている (max={_flat.max():.3e})")
    checks += 1

    # 二次微分・帯域通過: 定数画像には応答せず (DC なし)、段差では明確に応答。
    for name in ("laplace", "dog"):
        oc = BY[name].fn(const.copy(), 0.5, 0.5)
        assert float(np.abs(oc).mean()) < 1e-6, (
            f"GT {name}: 定数画像に応答している (|mean|={np.abs(oc).mean():.2e})")
        oe = BY[name].fn(step.copy(), 0.5, 0.5)
        assert float(oe.max()) > 0.1, f"GT {name}: 段差に応答していない (max={oe.max():.4f})"
        checks += 1

    # コーナー検出: 正方形の「角」が直線エッジ・平坦部より強い (= 単なるエッジ検出でない)。
    o = BY["cv_corner_harris"].fn(sq.copy(), 0.5, 0.5)
    corner = float(o[12:17, 12:17].max())   # 角 (14,14) 近傍
    straight = float(o[12:17, 22:27].max())  # 上辺中央 (直線エッジ)
    flat = float(o[22:27, 22:27].mean())     # 内部平坦
    assert corner > straight + 0.2 and corner > flat + 0.2, (
        f"GT cv_corner_harris: 角 {corner:.4f} が直線 {straight:.4f} / 平坦 {flat:.4f} を上回らない")
    checks += 1

    # 拡散と収縮の反復(f2_shock_diffuse)—— 素の衝撃との違いを数字で。
    # ★null を破るのは「雑音の扱い」: 素の衝撃は雑音を構造に化かすので、
    #   段差が**真値を超える**。超えたら鮮鋭化ではなく増幅である。
    from scipy import ndimage as _nd
    n2 = 128
    _, xx2 = np.mgrid[0:n2, 0:n2]
    true_step = 0.5
    blurred = _nd.gaussian_filter(np.where(xx2 < n2 // 2, 0.25, 0.75).astype(float), 3.0)
    noisy = np.clip(blurred + np.random.default_rng(5).normal(0, 0.02, (n2, n2)), 0.0, 1.0)

    def _step_of(m):
        return float(np.abs(np.diff(np.asarray(m)[n2 // 2, :])).max())

    def _flat_noise(m):
        return float(np.asarray(m)[:, :40].std())

    in_step, in_noise = _step_of(noisy), _flat_noise(noisy)
    plain = BY["f2_shock"].fn(noisy.copy(), 0.5, 0.0)
    assert _step_of(plain) > true_step, (
        "f2_shock が真の段差 %.3f を超えていない(%.3f)—— 雑音を構造に化かす性質が"
        "消えたなら、2 つの op を分けている根拠がなくなる" % (true_step, _step_of(plain)))
    assert _flat_noise(plain) > 2.0 * in_noise,         "f2_shock が平坦部の雑音を増幅していない(%.4f -> %.4f)" % (in_noise, _flat_noise(plain))
    # 交互版: b を上げるほど雑音が減り、鋭さは落ちる(取引が単調であること)
    steps, noises = [], []
    for bb in (0.0, 0.25, 0.5, 1.0):
        o = BY["f2_shock_diffuse"].fn(noisy.copy(), 0.5, bb)
        steps.append(_step_of(o))
        noises.append(_flat_noise(o))
    assert all(noises[i] > noises[i + 1] for i in range(len(noises) - 1)),         "b を上げても雑音が単調に減らない: %s" % [round(x, 4) for x in noises]
    assert all(steps[i] > steps[i + 1] for i in range(len(steps) - 1)),         "b を上げても鋭さが単調に落ちない(取引になっていない): %s" % [round(x, 3) for x in steps]
    # 存在理由そのもの: 弱い拡散(b=0.10)で「雑音を減らしながら段差を 2 倍以上」。
    # 実測 段差 0.112 -> 0.272(2.4 倍) / 雑音 0.0201 -> 0.0091(0.45 倍)。
    # b を上げると雑音はさらに減るが段差も落ちるので、この主張が言えるのは弱い側。
    o10 = BY["f2_shock_diffuse"].fn(noisy.copy(), 0.5, 0.10)
    s10, n10 = _step_of(o10), _flat_noise(o10)
    assert n10 < 0.6 * in_noise and s10 > 2.0 * in_step, (
        "f2_shock_diffuse(b=0.10)が『雑音を減らしつつ鋭くする』になっていない: "
        "雑音 %.4f (入力 %.4f) / 段差 %.3f (入力 %.3f)" % (n10, in_noise, s10, in_step))
    # どの b でも真値を超えない(超えたら増幅している)
    assert max(steps) <= true_step + 1e-9,         "f2_shock_diffuse が真の段差を超えた(増幅している): %s" % [round(x, 3) for x in steps]
    checks += 1

    # XDoG(線画調): 段差の暗い側にだけ線が出て、遠い平坦部は紙の白(1.0)のまま。
    # tau = 1 の DoG は縁の中心について奇関数なので、その符号が暗い側を決める(閉形式)。
    xd = BY["xdog"].fn(step.copy(), 0.2, 0.0)[n // 2]
    assert xd[:8].min() == 1.0 and xd[-8:].min() == 1.0, "GT xdog: 遠い平坦部が白でない"
    assert xd.min() < 0.05 and int(np.argmin(xd)) < n // 2, "GT xdog: 線が暗い側に出ていない"
    assert xd[n // 2:].min() > 0.99, "GT xdog: 明るい側に線が出た"
    assert float(np.ptp(BY["xdog"].fn(const.copy(), 0.5, 0.5))) == 0.0, "GT xdog: 定数画像に線が出た"
    checks += 1

    return checks


def main() -> None:
    # BY は task 指定どおり name->op (registry 全体; 'laplace' は 1 つに畳まれる)。
    BY = {o.name: o for o in ops.REGISTRY}

    edges = [o for o in ops.REGISTRY if o.category == "edges"]
    lap_entries = [o for o in edges if o.name == "laplace"]
    live_names = {o.name for o in edges}

    # --- kornia 不在なら KORNIA_OPTIONAL 分を除いた「利用可能集合」を対象にする ---- #
    skipped = sorted(n for n in KORNIA_OPTIONAL if n not in live_names)
    if skipped:
        print(f"skipped {len(skipped)} optional ops (kornia not installed): {', '.join(skipped)}")
    active_ops = [n for n in OPS if n not in skipped]
    expected = len(BASE_OPS) + (len(KORNIA_OPTIONAL) - len(skipped))

    # --- ハードコード OPS (利用可能集合) を live registry と突き合わせ (drift 検出) - #
    assert len(edges) == expected, (
        f"registry drift: edges エントリは {expected} のはず (got {len(edges)}, "
        f"base={len(BASE_OPS)} skipped_kornia={skipped})")
    assert len(lap_entries) == 1, (
        f"'laplace' は 1 度だけ登録のはず (got {len(lap_entries)}) — "
        "重複が復活していると名前で引ける方が 1 つに減り、抽選確率が 2 倍になる")
    assert sorted(active_ops) == sorted(o.name for o in edges), "OPS の名前マルチセットが registry と不一致"
    assert len(active_ops) == expected, f"active_ops 長は {expected} のはず (got {len(active_ops)})"

    # --- 全 op を呼んで契約検証 ------------------------------------------------ #
    n_called = 0
    for name in active_ops:
        op = ops._BY_NAME[name]
        assert op.category == "edges", f"{name}: _BY_NAME が edges 以外を指している"
        out, deterministic = _call_twice(op, op.in_sort)
        assert deterministic, f"{name}: 非決定的 (同一入力で出力がビット不一致)"
        _validate(name, op, out)
        n_called += 1

    assert n_called == expected, f"呼び出し数が {expected} でない (got {n_called})"

    # --- 代表 op に強い GT ----------------------------------------------------- #
    gt = _ground_truth_checks(BY)

    print(f"PASS: {n_called} ops exercised ({len(set(active_ops))} unique names), "
          f"all finite/typed/deterministic; {gt} GT checks")


if __name__ == "__main__":
    main()
