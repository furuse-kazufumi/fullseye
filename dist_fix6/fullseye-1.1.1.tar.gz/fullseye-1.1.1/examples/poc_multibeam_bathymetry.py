# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""多ビーム測深で海底が笑う —— 直下較正後も外側に残る音速誤差。

多ビーム音響測深機(マルチビーム)は、送受波器から扇状にビームを出し、
往復時間と射出角から海底の深さを出します。ところが音は水中で**まっすぐ
進みません** —— 水温・塩分で音速 c が深さごとに変わり、Snell の法則で
光線が曲がります。処理で音速プロファイル c(z) を取り違えると、平らな
海底が反り返って記録されます。直下で平均音速を較正すると直下誤差は消えますが、
外側ビームには反りが残ります。表面音速をそのまま使う条件では直下もずれます。現場ではこれを見た目から
「スマイル(smile)」「フラウン(frown)」と呼びます。

この PoC は、平らな海底と線形音速プロファイルを自分で植えてから、
(a) 平均音速の取り違え、(b) 屈折(光線の曲がり)、(c) 角度測定、
(d) エコー検出、を**別々に**測ります。ゼロ点は「表面の音速計だけを見て
定数と仮定する」現場の手です。

EXTEND: 実データに差し替えるなら :func:`trace_to_depth` が返す走時を、
測深機の生記録(ビームごとの往復時間 τ とビーム角)に置き換え、
:func:`profile_linear` を CTD/SVP キャストの (深さ, 音速) 列に置き換えます。
**この PoC の中心である「真の c(z) と比べる」は実データではできません** ——
真の音速場は誰も測っていないからです(キャストは 1 本の柱の、その瞬間の
値でしかない)。実データでできるのは §9 の**隣接測線の重なりの食い違い**
(これは現場でスマイルを見つける実際の手口)と、キャストを取り替えたときの
差分だけで、絶対誤差は出せません。

**実データの節(``FULLSEYE_DATA_DIR`` を立てたときだけ)**。NOAA NCEI の航海
NF-14-06(NOAA Ship Nancy Foster、2014-09-11、EPA Palm Beach 投棄場、深さ約
181 m、Reson SeaBat 7125)の生の HSX と、NOAA が CARIS で作った 5 m の BAG、
同じ航海の CTD キャスト PB-04 を読みます。データは repo に入れず、
``$FULLSEYE_DATA_DIR/noaa_multibeam/`` に置いたときだけ節が走ります(無ければ
「実データ: 無し(合成だけ)」と 1 行出し、門は数えません —— 合成の門と結果は
データの有無で変わりません)。門は :func:`section_real_noaa` の 3 つ: (R1) 音速
一定のスマイルが Order 1a を割る角度を §4 の閉形式で**先に**予測して実測と
比べる、(R2) 隣接測線の重なりの差の 95 % 点が光線追跡では TVU 未満・音速一定では
TVU 超(両向き)、(R3) ±61 度より外の外れ値は別枠で数え、光線追跡でも直らない
ことを確かめる。TVU は IHO S-44 Edition 6.1.0(2022-10)の 3.2.3 節
TVU_max(d) = √(a² + (b·d)²) と 7.3 TABLE 1 の Order 1a(a = 0.5 m, b = 0.013)
—— 「95 % 信頼水準でこの値を超えてはならない」。
★**NOT FOR NAVIGATION**(NOAA の ISO メタデータ useLimitation: 生データで QC 未実施、
保証なし)。出典: National Oceanic and Atmospheric Administration (NOAA) (2014):
Multibeam collection for NF-14-06: Multibeam data collected aboard NOAA Ship
NANCY FOSTER (R352) from 03-Sep-14 to 11-Sep-14, Fort Pierce, Florida to Cape
Canaveral, FL. NOAA National Centers for Environmental Information.
https://www.ngdc.noaa.gov/ships/nancy_foster/NF-14-06_mb.html, accessed 2026-10-02.

この PoC が示すこと(数字はすべて最終実行の実測値):

1. **ゼロ点(表面の音速計だけを見て定数と仮定)は、直下ビームからもう失格**。
   水深 50 m・水柱の音速差 -40 m/s の場面で、表面音速 1520.0 m/s をそのまま
   使うと直下で **+0.670 m** 深く出ます。IHO S-44 Order 1a の鉛直不確かさ
   TVU(50 m) = 0.820 m の **82 %** を、いちばん素直なビーム 1 本で
   食い潰しています(70 度では -3.545 m)。
2. ★**平均音速を直下ビームで較正すると、誤差は「消える」のではなく
   「外側へ移動」します**。較正後の直下は誤差 0.000 m ちょうどですが、
   65 度は **-2.697 m**、70 度は **-4.159 m**。★これが厄介な非対称です ——
   現場は直下の深さをバーチェックや錘で確かめるので、**検査が届く所だけが
   直り、検査が届かない所に全部が寄ります**。
3. ★**崖の位置は測る前に閉形式で出せる。ただし「屈折だけ」の話として**。
   ラフな展開式 Δz ≈ (g D²/2c₀)·tan²θ の予測が **48.15 度**、厳密な円弧の
   閉形式の予測が **48.68 度**。エコー検出を止めた経路の実測は **48.68 度**
   (厳密式と 2.0e-11 m 一致)。★ところが**全経路(ビーム形成 + 振幅検出)
   を通した実測は 47.95 度**で、予測より **0.73 度 手前**に来ました ——
   閉形式に入っていない量(4. の検出偏り)があるからです。
   展開式のほうは 45 度までは 3.0 % 以内ですが、70 度では **19.4 %** 過大
   (厳密 -4.159 m に対し展開 -4.966 m)。「tan² で効く」は外側で崩れます。
4. ★★**予測を 1 つ外しました。「エコー検出の誤差は無視できる床」ではない**。
   直下では検出のずれ -2.9 µs(深さ -0.002 m)ですが、**70 度では -2828 µs
   ＝ -0.725 m**。ビームが照らす帯が 70 度では **21396 µs**(直下の 171 倍)
   に伸び、往復時間が角度に対して凸なのでエコーが非対称になり、振幅検出の
   頂点がビーム軸より手前へ寄るためです。この合成モデルでは外側ほど振幅ピーク
   検出の偏りが増え、外側で位相検出を使う利点と整合します。★**「床は一定」と書いてはいけません**。
5. ★**第 1 層の Snell 処理を直すと、等音速の中点近似は規格内で 2 次収束します**。
   修正前に規格を割った値は層分割そのものではなく、第 1 層で ray parameter を
   保存しなかった実装誤りでした。射出角を海面音速で定義し、
   ray parameter を第 1 層から保存すると、65 度・50 m の深さ誤差は
   **2 層で −0.016 m**、32 層で約 −0.00006 m。層数 16 倍で約 256 分の 1 になる。
   一方、層内の音速を 1 次とすれば層数を 1→256 に
   変えても走時は 1.6e-15 s しか動きません(円弧が厳密だから)。
6. **要因を 1 つずつ止めた対照群**(65 度)。勾配ゼロ + 真の平均音速では
   1e-12 m 未満、角度推定だけを入れても **0.000000 m**(`beamform_doa` の
   誤差は 0.0000 度)、エコー検出だけで -0.222 m、屈折だけで **-2.697 m**、
   全部で -3.024 m。**スマイルは角度誤差ではありません**。
7. ★**深い所ほど崖は浅い角度に来ます**。IHO の許容 TVU は深さに比例して
   増えますが(b·d の項)、屈折誤差も深さに比例して増えるので、深水では
   **崖の角度が深さに依らなくなります**。予測した漸近値
   arctan√(2·b·c₀/|Δc|) = **44.83 度**に対し、200 ケース(音速差 25 通り ×
   深さ 8 通りの格子、乱数ではない)の実測は 10 m で 64.47 度 → 200 m で
   **45.53 度**。漸近値との差は 19.64 → 0.70 度 と**単調に**縮みますが、
   ぴったりには乗りません(TVU の定数項 a = 0.5 m が 200 m でもまだ
   b·d = 2.60 m の 2 割ある)。★**「浅い所は危ない」は逆で、浅い所のほうが
   swath を広く使えます**。±65 度の swath は 200 ケース中 **156(78.0 %)**
   が端で Order 1a を割りました。
8. ★**上向き屈折(frown)は、外側ビームが海底に届きません**。音速が深さ
   とともに増えると sinθ = p·c が増え、θ₀ > arcsin(c₀/c_bottom) の光線は
   反転して戻ります。Δc = +60 m/s・50 m で予測した限界角 **73.90 度**に
   対し、実測で最後に返ったビームは 73.0 度、最初に返らないビームは
   74.0 度(1 度刻み)。限界角を超えたビームは何も記録されず swath が黙って
   狭くなります。一方、限界角未満で届く外側ビームにも深度誤差が残り、
   65 度では +5.919 m と深く出ます。
9. ★**フットプリントの教科書式 d·Δθ/cos²θ は、電子的に振ったビームには
   足りません**。`beamform_delay_sum` で自分の配列のビーム幅を実測すると、
   ステア 0/45/70 度で 1.100 / 1.550 / 3.150 度 ＝ **1/cosθ で広がって
   います**(予測 1.058 / 1.496 / 3.092 度、比のずれは最大 6.5 %)。指数は
   2 でなく **3**: 70 度の等音速対照群で cos² 式 **8.21 m**、cos³ 式
   23.99 m、光線から直に測った実測 **24.14 m**(cos³ は -0.6 %)。
   **cos² 式は実測の 34 %** しかありません。なお屈折を入れると同じ
   フットプリントは 18.47 m へ **-23.5 %** 縮みます(別の要因なので分けて
   測りました)。
10. ★**隣接測線の重なりに段差が立ちます**。測線間隔を swath の半幅
    (101.4 m)= 重複 50 % にすると、重なりの**真ん中**では両測線が同じ振れ角なので差は 0.0000 m
    ですが、**帯の端**では片方の直下ビームと片方の最外ビームが同じ海底を
    測り、食い違いは **2.697 m**(TVU の 3.3 倍)。★重なりを平均で見ると
    ゼロに見えるので、**帯の端まで見ないと見つかりません**。これは真値を
    使わず実データにも適用できる、**この PoC で実装した自己整合検査**です。
11. ★**平らな海底が「地形」に見えます**。`dem_slope` で測ると、測線 1 本
    (継ぎ目なし)でも平均 1.494 度 / 最大 **2.985 度** の見かけの勾配が
    立ち(スマイルの曲がりそのもの)、測線 2 本を格子化すると重なり帯が
    **縞**になって最大 **49.4 度**。対照群(真に平らな海底を同じ手順で)は
    0.000000 度。どちらも海底図の上では「谷の縁」に見えます。
12. **サーモクラインは一定勾配で書けません**。混合層 + サーモクライン +
    深層の真値に対し、等音速処理の最大誤差 5.357 m を、表層と海底の 2 点を
    結ぶ一定勾配の当てはめは 1.253 m まで 77 % 改善しますが、残差は TVU を超えます。
    真のプロファイルで処理すれば 1.65e-07 m なので、**残りは処理の実装
    ではなくプロファイルの形の取り違え**だと切り分けられます。
    ★おまけに当てはめは**直下を +0.262 m 悪くします**(等音速側は直下較正
    済みで 0 だった)—— **外側を良くする代わりに、いちばん検査される所を
    犠牲にしています**。
13. **道具の穴**。`fs.<name>` / `fs.op.<name>` / `fs.ledger.<name>` /
    `fs.op_find(語幹)` の 4 層すべてを引いて、**音響測深そのものの op は
    1 つもありませんでした**(``sonar`` / ``swath`` / ``bathym`` / ``tvu``
    は 4 層とも 0 件。``sound_speed`` / ``footprint`` / ``crossline`` は
    ``op_find`` が 4 / 2 / 9 件を返しますが中身は ``flow_speed`` /
    ``sk_median_disk`` / ``piv_cross_correlate`` で無関係 —— ★**件数だけ
    見て「在る」と言ってはいけません**)。使えたのは `beamform_delay_sum` /
    `beamform_doa`(電波レーダの語彙のまま、角度スペクトルだけを使う)、
    `find_peaks` / `peak_subbin`、`snell_angle`、`interp_scattered`、
    `dem_slope`。★**使おうとして使えなかったもの**と、次に埋めるべき op は
    §11 に列挙しました。

【グラウンドトゥルース】海底は**深さ 50.0 m の完全な水平面**として置きました
(:data:`DEPTH_REF`)。音速は深さの 1 次式 c(z) = c₀ + g z(:func:`profile_linear`、
水柱全体で -40.0 m/s = 夏の沿岸で表層が速い形)。一定勾配にしたのは、
**光線が半径 R = c/(g sinθ) の円弧に閉じる**からです —— 走時も水平距離も
閉形式で書け、レイトレースの検算ができます。対照群は (a) 勾配ゼロの等音速、
(b) 直下較正の有無、(c) 屈折を止めて角度・エコー検出だけを入れた経路。
構造を持つプロファイル(混合層 + サーモクライン + 深層、:func:`profile_thermocline`)も
1 本混ぜて、一定勾配の当てはめでは直らないことを見ます。

【来歴】IHO S-44 第 6 版の鉛直不確かさ TVU = √(a² + (b·d)²) と、その
Order 1a の係数 a = 0.5 m / b = 0.013 は公開規格の値です(Special Order
a = 0.25 / b = 0.0075、Order 2 a = 1.0 / b = 0.023 も表に入れました)。
一定勾配の層で光線が円弧になること、および走時 t = (1/g)·ln[(c₂/c₁)·
(1+cosθ₁)/(1+cosθ₂)] は Snell の法則からの初等的な積分で、文献は引きません。
音速 1500 m/s 前後・水柱の変化 ±60 m/s は沿岸域で普通に起きる幅として
置いた仮定で、特定の海域の観測値ではありません。
"""
from __future__ import annotations

import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import examplefig as figs                                        # noqa: E402
import fullseye as fs                                            # noqa: E402

# --- 場面の諸元 -------------------------------------------------------------- #
#: 海底の深さ [m](完全な水平面として植える)。
DEPTH_REF = 50.0

#: 水柱全体の音速差 [m/s]。負 = 表層が速い(夏の沿岸)= スマイル側。
DELTA_C_REF = -40.0

#: 水柱の中央深さでの音速 [m/s]。プロファイルはここを軸に対称に置く。
C_MID = 1500.0

#: ビーム角(鉛直から、度)。±70 度・1 度刻み = 141 本。
BEAM_DEG = np.arange(-70.0, 70.001, 1.0)

#: 送受波器の周波数 [Hz] と素子数。浅海用 200 kHz、素子は λ/2 間隔。
FREQ_HZ = 200.0e3
N_ELEM = 96

#: エコー包絡線の標本化周波数 [Hz] とパルス長 [s]。
ECHO_FS = 48.0e3
PULSE_S = 150.0e-6

#: IHO S-44 第 6 版の鉛直不確かさ係数 ``(a [m], b [-])``。TVU = √(a² + (b d)²)。
IHO_ORDERS = {"Special": (0.25, 0.0075), "Order 1a": (0.5, 0.013),
              "Order 2": (1.0, 0.023)}

#: この PoC の判定に使う等級。
ORDER = "Order 1a"


def tvu(depth, order: str = ORDER) -> float:
    """IHO S-44 の許容鉛直不確かさ [m](95 % 信頼水準)。"""
    a, b = IHO_ORDERS[order]
    return float(np.hypot(a, b * np.asarray(depth, float)))


# --------------------------------------------------------------------------- #
# 音速プロファイル —— 真値も仮定も同じ形で持つ                                  #
# --------------------------------------------------------------------------- #
def profile_linear(delta_c: float, depth: float, c_mid: float = C_MID,
                   z_max: float | None = None):
    """一定勾配の c(z)。``(z ノード, c ノード)``。

    水柱 ``depth`` の全体で音速が ``delta_c`` だけ変わる形。勾配
    ``g = delta_c / depth`` [1/s] は下端より深い所まで**そのまま延長**する
    (処理側が走時を使い切るまで進めるように)。
    """
    g = delta_c / depth
    c0 = c_mid - 0.5 * delta_c
    zm = float(z_max if z_max is not None else 1.8 * depth + 20.0)
    return np.array([0.0, zm]), np.array([c0, c0 + g * zm])


def profile_constant(c: float, z_max: float = 400.0):
    """等音速(対照群、および「表面の音速だけ」の仮定)。"""
    return np.array([0.0, z_max]), np.array([float(c), float(c)])


def profile_thermocline(z_max: float = 400.0):
    """混合層 + サーモクライン + 深層。**一定勾配では書けない構造**を 1 本混ぜる。

    乱数ではなく段のある形にするのは、一定勾配の当てはめが「平均としては
    合っているのに形が違う」ときに何が残るかを見るため。
    """
    z = np.array([0.0, 8.0, 10.0, 22.0, 30.0, z_max])
    c = np.array([1522.0, 1521.4, 1512.0, 1486.0, 1483.4, 1482.0])
    return z, c


def sound_speed(prof, z):
    """プロファイルを線形補間して深さ z [m] の音速 [m/s]。"""
    zn, cn = prof
    return np.interp(np.asarray(z, float), zn, cn)


def _segments(prof, z_target: float):
    """``[0, z_target]`` を覆う層の ``(z1, z2, c1, c2)``。境界に z_target を足す。"""
    zn, cn = prof
    edges = np.unique(np.concatenate([zn[(zn > 0.0) & (zn < z_target)],
                                      [0.0, float(z_target)]]))
    ce = np.interp(edges, zn, cn)
    return edges[:-1], edges[1:], ce[:-1], ce[1:]


# --------------------------------------------------------------------------- #
# レイトレース —— 一定勾配の層は円弧に閉じる                                    #
# --------------------------------------------------------------------------- #
#: 勾配が実質ゼロとみなす閾値 [1/s]。これ未満は直線として扱う。
G_TINY = 1e-12


def trace_to_depth(prof, theta_deg, z_target: float):
    """射出角 ``theta_deg``(鉛直から、度)の光線を深さ ``z_target`` まで撃つ。

    返り値 ``(x, t, ok)`` —— 水平距離 [m]、**片道**走時 [s]、届いたか。
    層内で音速が 1 次なら、Snell の不変量 p = sinθ/c を使って

    * x += p (c₁+c₂) Δz / (cosθ₁ + cosθ₂)   —— 円弧の弦(勾配 0 でも成立)
    * t += ln[(c₂/c₁)(1+cosθ₁)/(1+cosθ₂)] / g

    と閉形式で積める。**桁落ちを避けた形にしてある**: 素直な
    ``(cosθ₁-cosθ₂)/(g p)`` や ``arctanh`` の差は、直下付近で 1 - 1 になる。

    ``|p c| >= 1`` になる層があると光線はそこで**反転**して海底に届かない
    (上向き屈折の外側ビーム)。その列は ``ok=False`` で返す。
    """
    z1a, z2a, c1a, c2a = _segments(prof, z_target)
    th = np.radians(np.asarray(theta_deg, float))
    p = np.sin(th) / float(c1a[0])
    u = np.cos(th).astype(np.float64)             # cosθ(現在の深さ)
    x = np.zeros_like(u)
    t = np.zeros_like(u)
    ok = np.ones(u.shape, bool)
    for z1, z2, c1, c2 in zip(z1a, z2a, c1a, c2a):
        dz = float(z2 - z1)
        if dz <= 0.0:
            continue
        s2 = p * c2
        ok &= np.abs(s2) < 1.0                    # 反転(turning point)
        u2 = np.sqrt(np.clip(1.0 - s2 * s2, 0.0, 1.0))
        den = np.where(u + u2 > 1e-12, u + u2, 1.0)
        x = x + p * (c1 + c2) * dz / den
        g = (c2 - c1) / dz
        if abs(g) > G_TINY:
            t = t + np.log((c2 / c1) * (1.0 + u) / (1.0 + u2)) / g
        else:
            t = t + dz / (c1 * np.maximum(u, 1e-12))
        u = u2
    return x, t, ok


def trace_const_layers(prof, theta_deg: float, z_target: float, n_layers: int):
    """層内を**等音速**とみなす粗いレイトレース。境界の曲がりは op に任せる。

    現場の古い実装(と多くの教科書)はこれ —— キャストを層に切り、層の中は
    直線、境界で Snell。曲がりの計算に :func:`fullseye.ledger.snell_angle` を
    そのまま使う。**音響では屈折率が音速の逆数に比例する**(n ∝ 1/c)ので、
    ``eta1 = 1/c₁`` / ``eta2 = 1/c₂`` を渡す —— ここは読む人が必ず躓く所。

    返り値 ``(x, t)``。射出角は海面音速で定義されるため、ray parameter
    ``p = sin(theta0) / c(0)`` を第 1 層を含む全層で保存する。
    """
    edges = np.linspace(0.0, z_target, n_layers + 1)
    c_mid = np.interp(0.5 * (edges[:-1] + edges[1:]), prof[0], prof[1])
    p_ray = math.sin(math.radians(float(theta_deg))) / float(np.interp(0.0, prof[0], prof[1]))
    x = t = 0.0
    for k in range(n_layers):
        h = float(edges[k + 1] - edges[k])
        c = float(c_mid[k])
        s = p_ray * c
        if abs(s) >= 1.0:
            return float("nan"), float("nan")
        r = math.asin(s)
        x += h * math.tan(r)
        t += h / (c * math.cos(r))
    return x, t


def trace_for_time(prof, theta_deg, t_one_way):
    """**処理側**の光線: 片道走時 ``t_one_way`` だけ進んだ点 ``(x, z, ok)``。

    測深機が測るのは往復時間とビーム角だけなので、深さは「仮定した
    プロファイルの中を、その時間だけ進んだ先」として出す。これが実務の
    レイトレース処理そのもの。仮定が等音速なら直線 z = c t cosθ に退化する。
    """
    zn, _cn = prof
    z1a, z2a, c1a, c2a = _segments(prof, float(zn[-1]))
    th = np.radians(np.asarray(theta_deg, float))
    p = np.sin(th) / float(c1a[0])
    vertical = np.abs(p) < 1e-14                  # 直下ビーム(arctanh が発散する)
    u = np.cos(th).astype(np.float64)
    x = np.zeros_like(u)
    z = np.zeros_like(u)
    rem = np.asarray(t_one_way, float) * np.ones_like(u)
    ok = np.ones(u.shape, bool)
    for z1, z2, c1, c2 in zip(z1a, z2a, c1a, c2a):
        dz = float(z2 - z1)
        if dz <= 0.0:
            continue
        g = (c2 - c1) / dz
        s2 = p * c2
        u2 = np.sqrt(np.clip(1.0 - s2 * s2, 0.0, 1.0))
        if abs(g) > G_TINY:
            with np.errstate(divide="ignore", invalid="ignore"):
                dt_full = np.log((c2 / c1) * (1.0 + u) / (1.0 + u2)) / g
        else:
            dt_full = dz / (c1 * np.maximum(u, 1e-12))
        # 層の底まで届かない(反転する)列は、残り時間をこの層で使い切る。
        dt_full = np.where(np.abs(s2) >= 1.0, np.inf, dt_full)
        dt = np.minimum(rem, np.where(np.isfinite(dt_full), dt_full, rem))
        # ★走時を使い切った光線は cosθ が層の途中の値のまま残り、後ろの層で dt_full が
        #   負になりうる。負の dt は rem を「生き返らせ」光線を進めてしまう(実データの
        #   152 節点のキャストで 57 度・0.13 s が 110 m → 493 m になった)ので 0 で止める。
        dt = np.maximum(dt, 0.0)
        live = dt > 0.0                           # まだ走時が残っている列だけ動かす
        if abs(g) > G_TINY:
            # 層内で dt だけ進んだ後の cosθ は tanh(arctanh(cosθ) − g·dt)。
            a = np.arctanh(np.clip(u, -1.0 + 1e-14, 1.0 - 1e-14))
            u_new = np.tanh(a - g * dt)
            c_new = np.where(vertical, c1 * np.exp(g * dt),
                             np.sqrt(np.clip(1.0 - u_new * u_new, 0.0, 1.0))
                             / np.maximum(np.abs(p), 1e-300))
            u_new = np.where(vertical, 1.0, u_new)
            dz_step = (c_new - c1) / g
        else:
            u_new = u
            c_new = np.full_like(u, c1)
            dz_step = c1 * dt * u
        dz_step = np.where(live, dz_step, 0.0)
        den = np.where(u + u_new > 1e-12, u + u_new, 1.0)
        x = x + np.where(live, p * (c1 + c_new) * dz_step / den, 0.0)
        z = z + dz_step
        ok &= ~(live & (u_new <= 1e-9))            # 反転した = 下へ進んでいない
        u = np.where(live, u_new, u)
        rem = np.maximum(rem - dt, 0.0)
    return x, z, ok


# --------------------------------------------------------------------------- #
# 閉形式 —— 測る前に印字する予測                                                #
# --------------------------------------------------------------------------- #
def harmonic_mean_speed(delta_c: float, depth: float, c_mid: float = C_MID) -> float:
    """直下ビームを合わせる平均音速 [m/s]。``D / t(0)`` = 調和平均。"""
    g = delta_c / depth
    c0 = c_mid - 0.5 * delta_c
    if abs(g) < G_TINY:
        return float(c0)
    return float(g * depth / math.log((c0 + g * depth) / c0))


def smile_exact(theta_deg, delta_c: float, depth: float, c_mid: float = C_MID):
    """直下較正した等音速処理の深さ誤差 [m]。**厳密な円弧の閉形式**。

    z/D = cosθ₀·[arctanh(cosθ₀) − arctanh(√(1−k²sin²θ₀))] / ln k、k = c_D/c₀。
    数値は :func:`trace_to_depth` と同じ式から出るが、**層に切らずに 1 本**で
    書けるところが違う(実務のレイトレースはここを層で刻む)。
    """
    g = delta_c / depth
    c0 = c_mid - 0.5 * delta_c
    if abs(g) < G_TINY:
        return np.zeros_like(np.asarray(theta_deg, float))
    k = (c0 + g * depth) / c0
    th = np.radians(np.asarray(theta_deg, float))
    u0 = np.cos(th)
    s = np.sin(th)
    ud = np.sqrt(np.clip(1.0 - (k * s) ** 2, 0.0, 1.0))
    t = np.log(k * (1.0 + u0) / (1.0 + ud)) / g
    ca = harmonic_mean_speed(delta_c, depth, c_mid)
    return ca * t * u0 - depth


def smile_tan2(theta_deg, delta_c: float, depth: float, c_mid: float = C_MID):
    """同じ量の**ラフな展開式** Δz ≈ (g D²/2c₀)·tan²θ₀。

    ε = gD/c₀ の 2 次まで取ると、直下較正した処理の誤差はこの 1 行になる。
    現場の勘所(「外側は角度の 2 乗で効く」)はここから来ている。
    """
    g = delta_c / depth
    c0 = c_mid - 0.5 * delta_c
    return (g * depth * depth / (2.0 * c0)) * np.tan(np.radians(
        np.asarray(theta_deg, float))) ** 2


def cliff_from_tan2(delta_c: float, depth: float, order: str = ORDER,
                    c_mid: float = C_MID) -> float:
    """展開式から出した崖の角度 [度](|Δz| = TVU になる θ₀)。"""
    g = delta_c / depth
    c0 = c_mid - 0.5 * delta_c
    coef = abs(g) * depth * depth / (2.0 * c0)
    if coef <= 0.0:
        return float("inf")
    v = tvu(depth, order) / coef
    return float(math.degrees(math.atan(math.sqrt(v))))


def cliff_from_exact(delta_c: float, depth: float, order: str = ORDER,
                     c_mid: float = C_MID, hi: float = 89.0) -> float:
    """厳密式から出した崖の角度 [度]。二分法で |Δz(θ)| = TVU を解く。"""
    lim = tvu(depth, order)
    if abs(smile_exact(hi, delta_c, depth, c_mid)) < lim:
        return float("inf")
    lo = 0.0
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        if abs(float(smile_exact(mid, delta_c, depth, c_mid))) < lim:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def cliff_deep_asymptote(delta_c: float, order: str = ORDER,
                         c_mid: float = C_MID) -> float:
    """深水での崖の角度の漸近値 [度]。

    許容 TVU の深さ比例項 b·d と、屈折誤差 (Δc·d/2c₀)tan²θ の**どちらも
    深さに比例する**ので、深水では d が消えて
    tan²θ = 2 b c₀ / |Δc| —— **崖の角度が深さに依らなくなる**。
    """
    b = IHO_ORDERS[order][1]
    c0 = c_mid - 0.5 * delta_c
    return float(math.degrees(math.atan(math.sqrt(2.0 * b * c0 / abs(delta_c)))))


def turning_angle(delta_c: float, depth: float, c_mid: float = C_MID) -> float:
    """海底に届く最大の射出角 [度]。``arcsin(c₀ / c_max)``、下向き屈折なら inf。"""
    if delta_c <= 0.0:
        return float("inf")
    c0 = c_mid - 0.5 * delta_c
    return float(math.degrees(math.asin(min(1.0, c0 / (c0 + delta_c)))))


# --------------------------------------------------------------------------- #
# 配列とビーム形成 —— fullseye の op をそのまま使う                             #
# --------------------------------------------------------------------------- #
#: ビーム形成の角度グリッド [度]。0.05 度刻み(3601 点)。
ANGLE_GRID = np.arange(-90.0, 90.001, 0.05)


def array_snapshot(theta_deg: float, wavelength: float, spacing: float,
                   n_elem: int = N_ELEM):
    """一様直線配列に平面波が角度 ``theta_deg`` から来たときの素子ごとの複素値。"""
    k = np.arange(n_elem, dtype=np.float64)
    return np.exp(1j * 2.0 * np.pi * spacing * k
                  * math.sin(math.radians(theta_deg)) / wavelength)


def as_beat_cube(snapshot):
    """``beamform_*`` が要求する ``(素子, チャープ, 高速時間)`` の立方体に詰める。

    ★ここが**電波レーダの語彙を音響に読み替える**地点。op は FMCW レーダ用で、
    立方体の 2 軸目(チャープ = 遅い時間)と 3 軸目(高速時間)を FFT して
    レンジ-ドップラー面を作り、その 1 セルの素子方向スナップショットを
    ビーム形成する。**パルス測深機にレンジ-ドップラー面は無い**(ビート
    周波数が距離になるのは FMCW だけ)ので、2 軸目・3 軸目を最小の 2 に
    潰して**縮退した 1 セル**にし、**角度スペクトルだけ**を使う。
    その結果 ``range_m`` / ``velocity_ms`` は ``None`` で返り、
    ``range_bin`` / ``doppler_bin`` は 0 —— **意味のある量ではない**ので
    読まない。読み替えが成り立つのは「一様直線配列 + 狭帯域 + 平面波 +
    素子間位相 2πd sinθ/λ」の部分だけで、そこは音波でも電波でも同じ式。
    """
    a = np.asarray(snapshot, complex)
    cube = np.zeros((a.size, 2, 2), complex)
    cube[:, :, :] = a[:, None, None]
    return cube


def beam_pattern(theta_deg: float, wavelength: float, spacing: float,
                 n_elem: int = N_ELEM, grid=ANGLE_GRID):
    """角度スペクトル(正規化)。``fs.ledger.beamform_delay_sum`` をそのまま。"""
    cube = as_beat_cube(array_snapshot(theta_deg, wavelength, spacing, n_elem))
    return np.asarray(fs.ledger.beamform_delay_sum(
        cube, wavelength_m=wavelength, element_spacing_m=spacing,
        angles_deg=grid, normalize=True), np.float64)


def half_power_width(power, grid=ANGLE_GRID) -> float:
    """角度スペクトルの -3 dB 幅 [度](ピークから両側へ半値まで歩く)。"""
    i = int(np.argmax(power))
    half = 0.5 * float(power[i])
    lo = i
    while lo > 0 and power[lo] > half:
        lo -= 1
    hi = i
    while hi < power.size - 1 and power[hi] > half:
        hi += 1
    return float(grid[hi] - grid[lo])


# --------------------------------------------------------------------------- #
# エコー検出 —— 1-D 信号の op をそのまま使う                                    #
# --------------------------------------------------------------------------- #
#: ビーム軸から何ビーム幅ぶんの海底をエコーに入れるか(片側)。
ECHO_SPAN_BW = 1.5

#: エコーを合成する部分角の本数。★これを 61 にすると、70 度では隣り合う
#: 部分角の到来時間が 330 µs 離れ、パルス幅 64 µs より広くなるので、包絡線が
#: **櫛**になって振幅検出が歯を 1 本拾う(検出のずれが -1131 µs と出た)。
#: 到来時間の密度をヒストグラムで作り、パルスで畳むほうが正しい。
ECHO_N_SUB = 4001


def echo_envelope(prof, theta_deg: float, wavelength: float, spacing: float,
                  bw0: float, depth: float = DEPTH_REF):
    """受信包絡線を**ビームが照らす海底を足し上げて**作る。

    ★ここが素直な「τ にガウスを 1 個置く」との違い。ビームは 1 点でなく
    **帯**を照らすので、エコーはその帯の往復時間の分布になる。重みは

    * 配列の角度応答 —— :func:`beam_pattern`(= ``beamform_delay_sum``)を
      そのまま部分角の位置で読む。**自分の配列の実測パターンを使う**。
    * 後方散乱の Lambert 則 cosθ —— 斜めに当たるほど返りが弱い。

    往復時間 τ(φ) は角度に対して**凸**なので、対称なビームでも
    エコーは非対称になり、振幅検出の頂点はビーム軸の τ とずれる。

    作り方は「到来時間の密度をヒストグラムに積んでから、パルスで畳む」。
    部分角ごとにガウスを足す素直な書き方だと、外側では隣り合う部分角の
    到来時間がパルス幅より離れて**櫛**になる(:data:`ECHO_N_SUB` 参照)。

    返り値は ``(包絡線, 窓の先頭の時刻 [s], ビーム軸の往復時間 [s])``。
    """
    bw = bw0 / math.cos(math.radians(theta_deg))
    # ★下限を 0 でクリップしない —— 直下ビームは片側だけになり、照らす帯が
    #   半分になってしまう(フットプリントが半分に出る形で 1 度踏んだ)。
    lo = theta_deg - ECHO_SPAN_BW * bw
    hi = min(88.0, theta_deg + ECHO_SPAN_BW * bw)
    sub = np.linspace(lo, hi, ECHO_N_SUB)
    _, t_sub, ok_sub = trace_to_depth(prof, sub, depth)
    patt = beam_pattern(theta_deg, wavelength, spacing)
    w = np.interp(sub, ANGLE_GRID, patt) * np.cos(np.radians(sub))
    w = np.where(ok_sub, w, 0.0)
    tau = 2.0 * t_sub
    _, t_ax, _ = trace_to_depth(prof, np.array([theta_deg]), depth)
    tau_axis = 2.0 * float(t_ax[0])
    half = int(1.4 * float(np.max(np.abs(tau - tau_axis))) * ECHO_FS) + 64
    i0 = int(round(tau_axis * ECHO_FS)) - half
    n = 2 * half + 1
    bins = np.rint(tau * ECHO_FS).astype(np.int64) - i0
    keep = (bins >= 0) & (bins < n)
    hist = np.zeros(n, np.float64)
    np.add.at(hist, bins[keep], w[keep])
    sig_s = PULSE_S / 2.355 * ECHO_FS                 # パルス幅 [標本]
    k = np.arange(-int(4 * sig_s) - 1, int(4 * sig_s) + 2, dtype=np.float64)
    env = np.convolve(hist, np.exp(-0.5 * (k / sig_s) ** 2), mode="same")
    return env / max(float(env.max()), 1e-300), i0 / ECHO_FS, tau_axis


def detect_two_way(env, t_start: float, fs_hz: float = ECHO_FS) -> float:
    """振幅検出 —— ``find_peaks`` で山を拾い、``peak_subbin`` で標本の間へ。"""
    idx = np.asarray(fs.ledger.find_peaks(env, height=0.5), np.int64)
    if idx.size == 0:
        return float("nan")
    best = int(idx[int(np.argmax(env[idx]))])
    sub = float(np.asarray(fs.peak_subbin(env, np.array([best]), mode="gauss"))[0])
    return t_start + sub / fs_hz


# --------------------------------------------------------------------------- #
def _pct(v, ref):
    return 100.0 * (v - ref) / ref


# --------------------------------------------------------------------------- #
# 1. 場面 —— 真値を植え、閉形式とレイトレースを突き合わせる                      #
# --------------------------------------------------------------------------- #
def section_scene():
    print("=== 1. 場面 —— 平らな海底と、線形の音速プロファイル ===")
    prof = profile_linear(DELTA_C_REF, DEPTH_REF)
    c0 = float(sound_speed(prof, 0.0))
    cb = float(sound_speed(prof, DEPTH_REF))
    g = DELTA_C_REF / DEPTH_REF
    ca = harmonic_mean_speed(DELTA_C_REF, DEPTH_REF)
    print(f"  海底 深さ {DEPTH_REF:.1f} m の完全な水平面(真値)")
    print(f"  音速 表層 {c0:.1f} m/s → 海底 {cb:.1f} m/s、勾配 g = {g:+.3f} /s")
    print(f"  直下ビームを合わせる平均音速(調和平均)= {ca:.3f} m/s")
    print(f"  IHO S-44 {ORDER} の TVU({DEPTH_REF:.0f} m) = {tvu(DEPTH_REF):.4f} m")
    # 光線の円弧半径(閉形式)。R = c / (g sinθ) = 1/(g p)。
    for th in (30.0, 60.0):
        p = math.sin(math.radians(th)) / c0
        print(f"  射出角 {th:.0f} 度の光線は半径 R = 1/(g p) = {abs(1.0/(g*p)):.0f} m "
              f"の円弧(直線ではない)")
    # 層に切ったレイトレースが閉形式と一致するか(層数を変えても動かないはず)
    x_ref, t_ref, ok = trace_to_depth(prof, BEAM_DEG, DEPTH_REF)
    assert bool(np.all(ok))
    worst = 0.0
    for n_layer in (1, 4, 32, 256):
        zn = np.linspace(0.0, float(prof[0][-1]), n_layer + 1)
        sub = (zn, np.interp(zn, prof[0], prof[1]))
        _, t_l, _ = trace_to_depth(sub, BEAM_DEG, DEPTH_REF)
        worst = max(worst, float(np.max(np.abs(t_l - t_ref))))
        print(f"  層 {n_layer:>4} 枚に切ったレイトレース: 走時の差 "
              f"{float(np.max(np.abs(t_l - t_ref))):.3e} s")
    print("  → 層内の音速が 1 次なら、層に切っても走時は動かない(円弧が厳密だから)。")
    # 層内を**等音速**とみなす粗い実装(境界の曲がりは fs.ledger.snell_angle)
    th_probe = 65.0
    i65 = int(np.argmin(np.abs(BEAM_DEG - th_probe)))
    print(f"  層内を**等音速**とみなし ray parameter を全層で保存すると、"
          f"{th_probe:.0f} 度で:")
    conv = []
    for n_layer in (2, 4, 8, 16, 32):
        xc, tc = trace_const_layers(prof, th_probe, DEPTH_REF, n_layer)
        dz = ca * (tc - float(t_ref[i65])) * math.cos(math.radians(th_probe))
        conv.append((n_layer, abs(dz)))
        print(f"    層 {n_layer:>3} 枚: 走時の差 {tc - float(t_ref[i65]):+.3e} s "
              f"= 深さ {dz:+.4f} m、水平 {xc - float(x_ref[i65]):+.4f} m")
    ratio = conv[0][1] / conv[-1][1]
    order = math.log(conv[0][1] / conv[-1][1]) / math.log(conv[-1][0] / conv[0][0])
    print(f"  → 層を 2 → 32 枚に細かくすると誤差は {ratio:.1f} 倍小さくなる"
          f"(層数 16 倍で {ratio:.1f} 倍、観測次数 {order:.2f})。")
    print(f"     ★2 枚の深さ誤差は {conv[0][1]:.3f} m。中点一定近似は約 2 次で収束する。")
    return {"prof": prof, "c0": c0, "cb": cb, "g": g, "ca": ca,
            "x": x_ref, "t": t_ref, "layer_worst": worst, "conv": conv}


# --------------------------------------------------------------------------- #
# 2. 測定系の床 —— 角度もエコーも、屈折より 3 桁小さい                           #
# --------------------------------------------------------------------------- #
def section_floor(scene):
    print("\n=== 2. 床を測る —— 角度推定とエコー検出は、どれだけ効くか ===")
    lam = C_MID / FREQ_HZ
    d = 0.5 * lam
    print(f"  {FREQ_HZ/1e3:.0f} kHz / 音速 {C_MID:.0f} m/s → λ = {1000*lam:.3f} mm、"
          f"素子 {N_ELEM} 本を λ/2 = {1000*d:.3f} mm 間隔(開口 {N_ELEM*d:.3f} m)")
    # (a) 角度推定の床 —— beamform_doa
    rows, err_ang = [], []
    for th in (0.0, 10.0, 30.0, 45.0, 60.0, 70.0):
        cube = as_beat_cube(array_snapshot(th, lam, d))
        r = fs.ledger.beamform_doa(cube, wavelength_m=lam, element_spacing_m=d,
                                   angles_deg=ANGLE_GRID)
        got = float(r["angles_deg"][0])
        err_ang.append(abs(got - th))
        rows.append((f"{th:.1f}", f"{got:.3f}", f"{got - th:+.4f}",
                     f"{float(r['angular_resolution_deg']):.4f}"))
        print(f"  ステア {th:5.1f} 度 → beamform_doa {got:8.3f} 度 "
              f"(誤差 {got - th:+.4f})、報告するビーム幅 "
              f"{float(r['angular_resolution_deg']):.4f} 度")
    print(f"  ★ range_m / velocity_ms は {r['range_m']} / {r['velocity_ms']} "
          f"—— レンジ-ドップラーは音響パルスに無いので**読まない**(§10)")
    # 角度誤差が深さに効く量: dz = -r sinθ dθ
    slant = DEPTH_REF / math.cos(math.radians(60.0))
    dz_ang = slant * math.sin(math.radians(60.0)) * math.radians(max(err_ang) or 1e-4)
    print(f"  → 角度誤差の最大 {max(err_ang):.4f} 度 は、60 度・{DEPTH_REF:.0f} m で "
          f"深さ {dz_ang:.4f} m 相当")
    # (b) エコー検出の床 —— find_peaks + peak_subbin
    prof = scene["prof"]
    rows_e, err_t = [], []
    bw0 = half_power_width(beam_pattern(0.0, lam, d))
    print(f"  {'ビーム [度]':>12}{'往復 [µs]':>12}{'エコー長 [µs]':>14}"
          f"{'検出のずれ [µs]':>16}{'深さ換算 [m]':>14}")
    for th in (0.0, 30.0, 45.0, 60.0, 70.0):
        env, t0e, tau_axis = echo_envelope(prof, th, lam, d, bw0)
        got = detect_two_way(env, t0e)
        # エコーの長さ(半値幅)を測る。ビームが照らす帯の往復時間の幅。
        above = np.where(env > 0.5)[0]
        length = (float(above[-1] - above[0]) / ECHO_FS) if above.size else 0.0
        dz = 0.5 * scene["ca"] * (got - tau_axis) * math.cos(math.radians(th))
        err_t.append(abs(dz))
        rows_e.append((f"{th:.0f}", f"{1e6*tau_axis:.1f}", f"{1e6*length:.1f}",
                       f"{1e6*(got-tau_axis):+.2f}", f"{dz:+.5f}"))
        print(f"  {th:>12.0f}{1e6*tau_axis:>12.1f}{1e6*length:>14.1f}"
              f"{1e6*(got-tau_axis):>16.2f}{dz:>14.5f}")
    print(f"  → 標本間隔 {1e6/ECHO_FS:.2f} µs(深さ {0.5*C_MID/ECHO_FS*100:.2f} cm)を、"
          f"peak_subbin が標本の間へ落としている。")
    print(f"  ★**床は角度 {dz_ang:.4f} m / エコー {max(err_t):.4f} m**。")
    print("     ★エコーの床は直下では µs 未満だが、外側では**ビームが照らす帯**が")
    print("     長くなり、しかも往復時間が角度に対して凸なのでエコーが非対称になる。")
    print("     振幅検出の頂点はビーム軸からずれる —— 外側で位相検出を使う利点と整合。")
    figs.save_table("floor", ["ビーム角 [度]", "往復時間 [µs]", "エコー長 [µs]",
                              "検出のずれ [µs]", "深さ換算 [m]"], rows_e,
                    title="測定系の床 —— 角度推定とエコー検出は深さに何 m 効くか",
                    caption="エコーは beamform_delay_sum の角度応答 × Lambert 後方散乱で"
                            "海底の帯を足し上げて合成。find_peaks + peak_subbin で検出。")
    if figs.enabled():
        series, lens = [], []
        for th in (0.0, 45.0, 70.0):
            env, t0e, tau_axis = echo_envelope(prof, th, lam, d, bw0)
            above = np.where(env > 0.5)[0]
            ln = max(float(above[-1] - above[0]) / ECHO_FS, 1.0 / ECHO_FS)
            lens.append(1e6 * ln)
            # ★横軸を**そのビーム自身のエコー長**で割る。生の µs で重ねると
            #   70 度(21 ms)が軸を独占して、直下と 45 度が縦線 1 本になる。
            tt = ((np.arange(env.size) / ECHO_FS + t0e) - tau_axis) / ln
            # ★``plot_series`` は xlim の外の点を**拒否する**(枠に貼り付いて
            #   本物のデータに見えるから)。切るのは呼び手の仕事なので先に切る。
            m = np.abs(tt) <= 1.6
            series.append((f"ビーム {th:.0f} 度(長さ {1e6*ln:.0f} µs)",
                           tt[m], env[m]))
        figs.save_plot("echo", series, xlim=(-1.6, 1.6),
                       xlabel="ビーム軸からのずれ ÷ そのビームのエコー長",
                       ylabel="正規化した受信包絡線",
                       title="外側ビームのエコーは長く、そして非対称",
                       caption="長さは %s µs(170 倍の開き)。直下はほぼ左右対称、"
                               "外側は頂点がビーム軸より**手前**へずれる —— "
                               "振幅検出はその頂点を取るので、深さが浅く出る。"
                               % " / ".join("%.0f" % v for v in lens))
    return {"lam": lam, "d": d, "ang_rows": rows, "err_ang": max(err_ang),
            "dz_ang": dz_ang, "err_echo": max(err_t), "bw0": bw0}


# --------------------------------------------------------------------------- #
# 3. ゼロ点 —— 表面の音速だけを定数と仮定する                                    #
# --------------------------------------------------------------------------- #
def section_null(scene):
    print("\n=== 3. ゼロ点 —— 表面の音速計だけを見て、定数と仮定する ===")
    prof = scene["prof"]
    _, t1, ok = trace_to_depth(prof, BEAM_DEG, DEPTH_REF)
    assert bool(np.all(ok))
    out = {}
    for name, ca in (("表面音速 c₀", scene["c0"]),
                     ("水柱の平均(算術)", 0.5 * (scene["c0"] + scene["cb"])),
                     ("直下較正(調和平均)", scene["ca"])):
        z = ca * t1 * np.cos(np.radians(BEAM_DEG))
        dz = z - DEPTH_REF
        nadir = float(dz[int(np.argmin(np.abs(BEAM_DEG)))])
        edge = float(dz[-1])
        out[name] = {"ca": ca, "dz": dz, "nadir": nadir, "edge": edge}
        print(f"  {name:>18}(c_a = {ca:8.3f} m/s): 直下 {nadir:+.3f} m / "
              f"65 度 {float(dz[np.argmin(np.abs(BEAM_DEG-65.0))]):+.3f} m / "
              f"70 度 {edge:+.3f} m")
    lim = tvu(DEPTH_REF)
    print(f"  TVU({DEPTH_REF:.0f} m) = {lim:.4f} m")
    n0 = out["表面音速 c₀"]["nadir"]
    print(f"  → ★ゼロ点は**直下ビームからもう** TVU の {100*abs(n0)/lim:.0f} % を"
          f"食い潰している({n0:+.3f} m)。")
    print("  → ★直下較正すると直下の誤差は 0 になるが、外側は残る —— "
          "**誤差が消えたのではなく、検査されない所へ移った**。")
    print("     現場は直下の深さをバーチェックや錘で確かめる。**直る所だけ直る**。")
    return out


# --------------------------------------------------------------------------- #
# 4. 崖 —— 閉形式で予測してから、全経路を通して測る                              #
# --------------------------------------------------------------------------- #
def section_cliff(scene, floor):
    print("\n=== 4. 崖 —— 何度から IHO S-44 を割るか。予測を先に印字する ===")
    pred_tan2 = cliff_from_tan2(DELTA_C_REF, DEPTH_REF)
    pred_exact = cliff_from_exact(DELTA_C_REF, DEPTH_REF)
    print(f"  予測(ラフな展開 Δz ≈ (gD²/2c₀)tan²θ): 崖 = {pred_tan2:.2f} 度")
    print(f"  予測(厳密な円弧の閉形式)          : 崖 = {pred_exact:.2f} 度")
    print("  ↑ ここまでは測る前。以下が実測。")
    prof = scene["prof"]
    lam, d = floor["lam"], floor["d"]
    # 全経路: ビーム形成で角度 → レイトレースで走時 → エコー検出 → 等音速で処理
    ths = np.arange(0.0, 71.0, 1.0)
    meas, noecho, exact, tan2 = [], [], [], []
    for th in ths:
        cube = as_beat_cube(array_snapshot(th, lam, d))
        r = fs.ledger.beamform_doa(cube, wavelength_m=lam, element_spacing_m=d,
                                   angles_deg=ANGLE_GRID)
        th_m = float(r["angles_deg"][0])
        env, t0e, tau_ax = echo_envelope(prof, th, lam, d, floor["bw0"])
        tau_m = detect_two_way(env, t0e)
        cth = math.cos(math.radians(th_m))
        meas.append(0.5 * scene["ca"] * tau_m * cth - DEPTH_REF)
        # 対照群: エコー検出を止め、走時をそのまま渡す(角度だけ op 経由)
        noecho.append(0.5 * scene["ca"] * tau_ax * cth - DEPTH_REF)
        exact.append(float(smile_exact(th, DELTA_C_REF, DEPTH_REF)))
        tan2.append(float(smile_tan2(th, DELTA_C_REF, DEPTH_REF)))
    meas = np.array(meas)
    noecho = np.array(noecho)
    exact = np.array(exact)
    tan2 = np.array(tan2)
    lim = tvu(DEPTH_REF)

    def cliff_of(curve):
        """0.01 度刻みに補間して |Δz| が TVU を越える最初の角度 [度]。"""
        fine = np.arange(0.0, 70.001, 0.01)
        v = np.interp(fine, ths, np.abs(curve))
        return float(fine[int(np.argmax(v > lim))]) if (v > lim).any() else float("inf")

    cliff_meas, cliff_noecho = cliff_of(meas), cliff_of(noecho)
    print(f"  {'θ₀ [度]':>8}{'実測 全経路':>14}{'実測 検出なし':>16}{'厳密式':>12}"
          f"{'展開式':>12}{'展開の外し':>12}")
    rows = []
    for th in (0.0, 20.0, 40.0, 45.0, 50.0, 60.0, 65.0, 70.0):
        i = int(np.argmin(np.abs(ths - th)))
        off = f"{100*(tan2[i]-exact[i])/exact[i]:+.1f} %" if exact[i] else "—"
        rows.append((f"{th:.0f}", f"{meas[i]:+.4f}", f"{noecho[i]:+.4f}",
                     f"{exact[i]:+.4f}", f"{tan2[i]:+.4f}", off))
        print(f"  {th:>8.0f}{meas[i]:>14.4f}{noecho[i]:>16.4f}{exact[i]:>12.4f}"
              f"{tan2[i]:>12.4f}{off:>12}")
    print(f"  → **エコー検出を止めた経路の崖は {cliff_noecho:.2f} 度** —— "
          f"厳密式の予測 {pred_exact:.2f} 度 と "
          f"{abs(cliff_noecho - pred_exact):.2f} 度 差。**閉形式は当たっている**。")
    print(f"  → ★**全経路の崖は {cliff_meas:.2f} 度**、予測より "
          f"{pred_exact - cliff_meas:.2f} 度 **早い**。差は閉形式に入っていない量 ——")
    print("     振幅検出がビームの照らす帯の非対称なエコーの頂点を取り、")
    print("     外側ほど浅い側へ引っ張るから(§2)。**予測は「屈折だけ」で正しく、")
    print("     機械を通すと崖はもう少し手前に来る**。")
    print(f"  → 展開式の予測 {pred_tan2:.2f} 度 は厳密式より "
          f"{pred_exact - pred_tan2:.2f} 度 手前。45 度までは "
          f"{abs(100*(tan2[45]-exact[45])/exact[45]):.1f} % 以内だが、70 度では "
          f"{100*(abs(tan2[-1]/exact[-1])-1):.1f} % 過大 —— "
          f"**「tan² で効く」は外側で崩れる**。")
    print(f"  → 検出なしの経路と厳密式の差は最大 "
          f"{float(np.max(np.abs(noecho - exact))):.2e} m、"
          f"全経路との差は最大 {float(np.max(np.abs(meas - exact))):.4f} m。")
    figs.save_table("cliff", ["θ₀ [度]", "実測 全経路 [m]", "実測 検出なし [m]",
                              "厳密式 [m]", "展開式 [m]", "展開の外し"], rows,
                    title="スマイルの大きさ —— 実測 / 厳密式 / ラフな展開式",
                    caption=f"深さ {DEPTH_REF:.0f} m・音速差 {DELTA_C_REF:+.0f} m/s。"
                            f"TVU = {lim:.3f} m を割るのは全経路で {cliff_meas:.2f} 度、"
                            f"屈折だけなら {cliff_noecho:.2f} 度 から。")
    if figs.enabled():
        x_at = DEPTH_REF * np.tan(np.radians(ths))
        figs.save_plot(
            "smile",
            [("実測(全経路)", x_at, meas),
             ("実測(エコー検出なし)", x_at, noecho),
             ("厳密な円弧の閉形式", x_at, exact),
             ("ラフな展開 tan²", x_at, tan2),
             ("IHO %s の許容(-)" % ORDER, x_at, np.full_like(x_at, -lim))],
            xlabel="航跡直交距離 [m]", ylabel="深さの誤差 [m](負 = 浅く出る)",
            title="平らな海底が笑う —— 外側ビームだけが浮き上がる",
            caption=f"直下は較正済みで 0。{cliff_meas:.1f} 度(直交距離 "
                    f"{DEPTH_REF*math.tan(math.radians(cliff_meas)):.1f} m)から "
                    f"IHO {ORDER} を割る。展開式は外側で過大に予測する。")
    return {"ths": ths, "meas": meas, "noecho": noecho, "exact": exact, "tan2": tan2,
            "pred_tan2": pred_tan2, "pred_exact": pred_exact,
            "cliff": cliff_meas, "cliff_noecho": cliff_noecho, "lim": lim,
            "gap_noecho": float(np.max(np.abs(noecho - exact))),
            "path_gap": float(np.max(np.abs(meas - exact)))}


# --------------------------------------------------------------------------- #
# 5. 対照群 —— 要因を 1 つずつ止める                                            #
# --------------------------------------------------------------------------- #
def section_controls(scene, floor):
    print("\n=== 5. 対照群 —— 要因を 1 つずつ止める ===")
    lam, d = floor["lam"], floor["d"]
    th_edge = 65.0
    rows = []

    def run(prof, use_beamform, use_echo, ca):
        """1 本のビームを、指定した経路だけ通して深さを出す。"""
        th_m = th_edge
        if use_beamform:
            cube = as_beat_cube(array_snapshot(th_edge, lam, d))
            r = fs.ledger.beamform_doa(cube, wavelength_m=lam, element_spacing_m=d,
                                       angles_deg=ANGLE_GRID)
            th_m = float(r["angles_deg"][0])
        _, t1, _ = trace_to_depth(prof, np.array([th_edge]), DEPTH_REF)
        tau = 2.0 * float(t1[0])
        if use_echo:
            env, t0e, _ = echo_envelope(prof, th_edge, lam, d, floor["bw0"], DEPTH_REF)
            tau = detect_two_way(env, t0e)
        return 0.5 * ca * tau * math.cos(math.radians(th_m)) - DEPTH_REF

    flat = profile_constant(C_MID)
    cases = [
        ("勾配ゼロ + 真の平均音速(何も無い)", flat, False, False, C_MID),
        ("角度推定だけ入れる", flat, True, False, C_MID),
        ("エコー検出だけ入れる", flat, False, True, C_MID),
        ("角度 + エコー(屈折なし)", flat, True, True, C_MID),
        ("屈折だけ入れる(直下較正)", scene["prof"], False, False, scene["ca"]),
        ("全部入れる", scene["prof"], True, True, scene["ca"]),
    ]
    out = {}
    for name, prof, ub, ue, ca in cases:
        dz = run(prof, ub, ue, ca)
        out[name] = dz
        rows.append((name, f"{dz:+.6f}"))
        print(f"  {name:<36}{dz:>+12.6f} m")
    only_ang = abs(out["角度推定だけ入れる"])
    only_echo = abs(out["エコー検出だけ入れる"])
    only_ref = abs(out["屈折だけ入れる(直下較正)"])
    floor_here = max(only_ang, only_echo)
    print(f"  → ★屈折 {only_ref:.4f} m に対し、角度 {only_ang:.6f} m / "
          f"エコー {only_echo:.6f} m。")
    print(f"     大きいほうの床でも屈折の 1/{only_ref/max(floor_here, 1e-9):.0f}。"
          f"**スマイルは角度誤差でもエコー検出誤差でもない**。屈折そのもの。")
    print("     ただし §2 のとおり**エコーの床は角度とともに増える**ので、"
          "「床は一定」と書いてはいけない。")
    figs.save_table("controls", ["止めずに入れた要因", "65 度での深さ誤差 [m]"], rows,
                    title="対照群 —— 要因を 1 つずつ入れる",
                    caption="勾配ゼロ + 真の平均音速がゼロ点。屈折だけが m の単位で効く。")
    return out


# --------------------------------------------------------------------------- #
# 6. 掃引 —— 200 ケースで崖の位置を測り、深水の漸近を確かめる                     #
# --------------------------------------------------------------------------- #
def section_sweep():
    print("\n=== 6. 掃引 —— 音速差 25 通り × 深さ 8 通り = 200 ケース ===")
    deltas = np.arange(-60.0, 60.001, 5.0)          # 25 通り(0 を含む = 対照群)
    depths = np.array([10.0, 20.0, 30.0, 50.0, 70.0, 100.0, 150.0, 200.0])
    print(f"  音速差 {deltas.min():+.0f} 〜 {deltas.max():+.0f} m/s({deltas.size} 通り)"
          f" × 深さ {depths.min():.0f} 〜 {depths.max():.0f} m({depths.size} 通り)"
          f" = **{deltas.size * depths.size} ケース**(乱数ではなく格子)")
    print(f"  予測: 深水では TVU の b·d と屈折の Δc·d/2c₀ がどちらも d に比例するので、")
    print(f"        崖の角度は深さに依らなくなる —— tan²θ = 2 b c₀ / |Δc|。")
    for dc in (-40.0, -20.0, -60.0):
        print(f"        Δc = {dc:+.0f} m/s の漸近値 = "
              f"{cliff_deep_asymptote(dc):.2f} 度")
    cliffs = np.full((deltas.size, depths.size), np.inf)
    for i, dc in enumerate(deltas):
        for j, dep in enumerate(depths):
            if abs(dc) < 1e-9:
                continue                             # 対照群: 崖は無い
            cliffs[i, j] = cliff_from_exact(float(dc), float(dep))
    zero_row = int(np.argmin(np.abs(deltas)))
    assert not np.isfinite(cliffs[zero_row]).any(), "勾配ゼロに崖が立った"
    print(f"  {'深さ [m]':>10}", end="")
    for dc in (-60.0, -40.0, -20.0, -10.0):
        print(f"{'Δc=%+.0f' % dc:>12}", end="")
    print(f"{'漸近(-40)':>12}")
    rows = []
    for j, dep in enumerate(depths):
        vals = [cliffs[int(np.argmin(np.abs(deltas - dc))), j]
                for dc in (-60.0, -40.0, -20.0, -10.0)]
        print(f"  {dep:>10.0f}", end="")
        for v in vals:
            print(f"{v:>12.2f}", end="")
        print(f"{cliff_deep_asymptote(-40.0):>12.2f}")
        rows.append([f"{dep:.0f}"] + [f"{v:.2f}" for v in vals])
    asym = cliff_deep_asymptote(-40.0)
    j40 = int(np.argmin(np.abs(deltas + 40.0)))
    shallow, deep = cliffs[j40, 0], cliffs[j40, -1]
    gaps = [float(cliffs[j40, j] - asym) for j in range(depths.size)]
    print(f"  → ★Δc = -40 m/s で、崖は 10 m の {shallow:.2f} 度 から "
          f"200 m の {deep:.2f} 度 へ**単調に浅い角度へ寄り**、"
          f"漸近値 {asym:.2f} 度 に近づく。")
    print("     漸近値との差 " + " → ".join("%.2f" % g for g in gaps)
          + " 度(深さ 10 → 200 m)。")
    print(f"     ★ぴったりには乗らない({deep - asym:+.2f} 度 残る)—— 漸近値は "
          f"TVU の定数項 a = {IHO_ORDERS[ORDER][0]} m を捨てた形で、200 m でも "
          f"a はまだ b·d = {IHO_ORDERS[ORDER][1]*200:.2f} m の 2 割ある。")
    print("     **浅い所のほうが swath を広く使える**。深い所は許容 TVU も"
          "大きくなるが、屈折の誤差も同じだけ大きくなるので相殺する。")
    # 65 度 swath で何 % のケースが失格になるか(率を出すので分母を明示)
    fail = 0
    total = 0
    for i, dc in enumerate(deltas):
        for j, dep in enumerate(depths):
            total += 1
            if cliffs[i, j] < 65.0:
                fail += 1
    print(f"  → ±65 度の swath を使うと、{total} ケース中 **{fail} ケース"
          f"({100*fail/total:.1f} %)** が端で {ORDER} を割る。")
    print(f"     分母は {deltas.size}×{depths.size} の格子。うち "
          f"{depths.size} ケース(Δc = 0)は原理的に崖が無い対照群。")
    figs.save_table("sweep", ["深さ [m]", "Δc=-60", "Δc=-40", "Δc=-20", "Δc=-10"],
                    rows, title="崖の角度 [度] —— 深いほど浅い角度へ寄る",
                    caption=f"Δc = -40 m/s の深水漸近値は {asym:.2f} 度。"
                            "深さと一緒に許容も誤差も増えるので、比が止まる。")
    if figs.enabled():
        series = []
        for dc in (-60.0, -40.0, -20.0, -10.0):
            i = int(np.argmin(np.abs(deltas - dc)))
            series.append((f"Δc = {dc:+.0f} m/s", depths, cliffs[i]))
        figs.save_plot("sweep_cliff", series, xlabel="水深 [m]",
                       ylabel="IHO %s を割り始める角度 [度]" % ORDER,
                       title="崖の角度は、深くなるほど浅い角度へ寄る",
                       caption="どの曲線も 2·b·c₀/|Δc| の漸近値へ落ちる。"
                               "浅い所ほど広い swath が使える。")
    return {"deltas": deltas, "depths": depths, "cliffs": cliffs,
            "asym": asym, "shallow": shallow, "deep": deep, "gaps": gaps,
            "fail": fail, "total": total}


# --------------------------------------------------------------------------- #
# 7. 上向き屈折 —— 外側ビームが海底に届かない                                    #
# --------------------------------------------------------------------------- #
def section_frown():
    print("\n=== 7. 上向き屈折(frown)—— 外側ビームは海底に届かない ===")
    dc = +60.0
    prof = profile_linear(dc, DEPTH_REF)
    c0 = float(sound_speed(prof, 0.0))
    cb = float(sound_speed(prof, DEPTH_REF))
    pred = turning_angle(dc, DEPTH_REF)
    print(f"  音速 表層 {c0:.1f} → 海底 {cb:.1f} m/s(冬の沿岸や淡水層の下)。")
    print(f"  予測: sinθ = p·c は深さとともに増えるので、"
          f"θ₀ > arcsin(c₀/c_bottom) = **{pred:.2f} 度** の光線は反転して戻る。")
    ths = np.arange(0.0, 85.001, 1.0)
    _, _, ok = trace_to_depth(prof, ths, DEPTH_REF)
    last = float(ths[ok][-1]) if ok.any() else float("nan")
    first_bad = float(ths[~ok][0]) if (~ok).any() else float("nan")
    print(f"  実測: 海底に届いた最大のビームは **{last:.1f} 度**、"
          f"届かなくなる最初のビームは {first_bad:.1f} 度(1 度刻み)。")
    print(f"  → 予測 {pred:.2f} 度 はこの 2 本の間 "
          f"({last:.1f} < {pred:.2f} < {first_bad:.1f})。")
    dz = smile_exact(ths[ok], dc, DEPTH_REF)
    print(f"  → 届いたビームは**逆向きに**曲がる: 65 度で "
          f"{float(smile_exact(65.0, dc, DEPTH_REF)):+.3f} m(深く出る = frown)。")
    print("  → ★限界角を超えたビームは記録されない。一方、届く外側ビームにも深度誤差が残る。")
    print("     swath が黙って狭くなるだけなので、記録を見ても異常に見えない。")
    return {"pred": pred, "last": last, "first_bad": first_bad,
            "dz65": float(smile_exact(65.0, dc, DEPTH_REF)),
            "dz_max": float(np.max(np.abs(dz)))}


# --------------------------------------------------------------------------- #
# 8. フットプリント —— 教科書の cos² 式は足りない                                #
# --------------------------------------------------------------------------- #
def section_footprint(scene, floor):
    print("\n=== 8. 分解能の崖 —— フットプリントは cos² か cos³ か ===")
    lam, d = floor["lam"], floor["d"]
    bw0 = floor["bw0"]
    print(f"  自分の配列のビーム幅を実測する(beamform_delay_sum の -3 dB 幅):")
    print(f"  {'ステア [度]':>12}{'実測 -3dB [度]':>16}{'予測 0.886λ/(Nd cosθ)':>24}"
          f"{'比':>8}")
    rows_bw, widths = [], {}
    for th in (0.0, 30.0, 45.0, 60.0, 70.0):
        w = half_power_width(beam_pattern(th, lam, d))
        pred = math.degrees(0.886 * lam / (N_ELEM * d)) / math.cos(math.radians(th))
        widths[th] = w
        rows_bw.append((f"{th:.0f}", f"{w:.4f}", f"{pred:.4f}", f"{w/pred:.4f}"))
        print(f"  {th:>12.0f}{w:>16.4f}{pred:>24.4f}{w/pred:>8.4f}")
    print(f"  → **ビーム幅は 1/cosθ で広がる**(比は 1.0 前後、最大の外れ "
          f"{max(abs(float(r[3])-1.0) for r in rows_bw)*100:.1f} %)。")
    print("     電子的に振った配列は、開口が cosθ に縮んで見えるから。")
    # フットプリント 4 通り。**等音速(対照群)と屈折込みを分けて測る**。
    prof = scene["prof"]
    iso = profile_constant(scene["ca"])
    print(f"  {'θ₀ [度]':>8}{'cos² 式':>12}{'cos³ 式':>12}"
          f"{'実測(等音速)':>16}{'実測(屈折込み)':>18}{'cos² の外し':>13}")
    rows, foot_meas, foot_iso, foot2, foot3 = [], [], [], [], []
    for th in (0.0, 30.0, 45.0, 60.0, 65.0, 70.0):
        bw = bw0 / math.cos(math.radians(th))       # 実測した広がりを使う
        f2 = DEPTH_REF * math.radians(bw0) / math.cos(math.radians(th)) ** 2
        f3 = DEPTH_REF * math.radians(bw0) / math.cos(math.radians(th)) ** 3
        # 実測: ビームの縁 2 本を実際に撃って、海底での水平距離の差を取る
        edges = np.array([th - 0.5 * bw, min(88.0, th + 0.5 * bw)])
        xr, _, ok_r = trace_to_depth(prof, edges, DEPTH_REF)
        xi, _, ok_i = trace_to_depth(iso, edges, DEPTH_REF)
        assert bool(np.all(ok_r) and np.all(ok_i))
        fm, fi = float(abs(xr[1] - xr[0])), float(abs(xi[1] - xi[0]))
        foot_meas.append(fm)
        foot_iso.append(fi)
        foot2.append(f2)
        foot3.append(f3)
        rows.append((f"{th:.0f}", f"{f2:.3f}", f"{f3:.3f}", f"{fi:.3f}", f"{fm:.3f}",
                     f"{100*(f2-fi)/fi:+.1f} %"))
        print(f"  {th:>8.0f}{f2:>12.3f}{f3:>12.3f}{fi:>16.3f}{fm:>18.3f}"
              f"{100*(f2-fi)/fi:>12.1f}%")
    print(f"  → ★70 度、**等音速の対照群**で cos² 式 {foot2[-1]:.2f} m、"
          f"cos³ 式 {foot3[-1]:.2f} m、実測 {foot_iso[-1]:.2f} m。")
    print(f"     **cos² 式は実測の {100*foot2[-1]/foot_iso[-1]:.0f} %** —— "
          f"ビーム幅の広がりを勘定に入れていないから。cos³ 式は "
          f"{100*(foot3[-1]/foot_iso[-1]-1):+.1f} % で当たる。")
    print(f"  → 屈折を入れると 70 度のフットプリントは {foot_meas[-1]:.2f} m へ "
          f"{100*(foot_meas[-1]/foot_iso[-1]-1):+.1f} %。光線が鉛直側へ曲がって"
          f"届く先が縮む。")
    print("     ★**分解能の崖と深さの崖は別の量**: 深さは外側で浅く出て、"
          "分解能は外側でぼやける。片方だけ直しても swath は広がらない。")
    figs.save_table("footprint", ["θ₀ [度]", "cos² 式 [m]", "cos³ 式 [m]",
                                  "実測 等音速 [m]", "実測 屈折込み [m]",
                                  "cos² の外し"], rows,
                    title="海底フットプリント —— 教科書の cos² 式は 3 分の 1",
                    caption=f"深さ {DEPTH_REF:.0f} m、ビーム幅 {bw0:.3f} 度(実測)。"
                            "等音速が対照群。電子的に振ると幅も 1/cosθ で広がる。")
    figs.save_table("beamwidth", ["ステア [度]", "実測 -3dB [度]",
                                  "予測 [度]", "比"], rows_bw,
                    title="ビーム幅は 1/cosθ で広がる(op で実測)",
                    caption="beamform_delay_sum の角度スペクトルの -3 dB 幅。")
    if figs.enabled():
        grid = ANGLE_GRID
        figs.save_plot(
            "beam_pattern",
            [("ステア 0 度", grid, beam_pattern(0.0, lam, d)),
             ("ステア 45 度", grid, beam_pattern(45.0, lam, d)),
             ("ステア 70 度", grid, beam_pattern(70.0, lam, d))],
            xlabel="到来角 [度]", ylabel="正規化パワー",
            xlim=(-90.0, 90.0),
            title="配列の角度スペクトル(beamform_delay_sum)",
            caption=f"素子 {N_ELEM} 本・λ/2 間隔。振るほど主ローブが太る。")
    return {"widths": widths, "foot_meas": foot_meas, "foot_iso": foot_iso,
            "foot2": foot2, "foot3": foot3, "rows_bw": rows_bw}


# --------------------------------------------------------------------------- #
# 9. DTM 化 —— 測線を 2 本引いて、重なりの段差を測る                             #
# --------------------------------------------------------------------------- #
def section_dtm(scene):
    print("\n=== 9. DTM にして見る —— 隣接測線の重なりに段差が立つ ===")
    prof = scene["prof"]
    ca = scene["ca"]
    beams = np.arange(-65.0, 65.001, 1.0)
    x_true, t1, ok = trace_to_depth(prof, beams, DEPTH_REF)
    assert bool(np.all(ok))
    z_meas = ca * t1 * np.cos(np.radians(beams))
    y_meas = ca * t1 * np.sin(np.radians(beams))
    half_swath = float(np.max(np.abs(y_meas)))
    print(f"  swath 半幅 {half_swath:.2f} m(±65 度・深さ {DEPTH_REF:.0f} m)")
    print(f"  ★航跡直交位置も動く: 65 度のビームは真の {float(x_true[-1]):.3f} m を "
          f"{float(y_meas[-1]):.3f} m と記録({float(y_meas[-1]-x_true[-1]):+.3f} m)。")
    # 測線 2 本。間隔は swath の半分(重複 50 %)。
    spacing = half_swath
    along = np.arange(0.0, 60.001, 2.0)             # 2 m ごとに ping
    pts, vals, line_id = [], [], []
    for line, y0 in enumerate((0.0, spacing)):
        for yy in along:
            pts.append(np.column_stack([y_meas + y0, np.full(beams.size, yy)]))
            vals.append(z_meas)
            line_id.append(np.full(beams.size, line))
    pts = np.vstack(pts)
    vals = np.concatenate(vals)
    line_id = np.concatenate(line_id)
    print(f"  測線 2 本 × ping {along.size} 発 × ビーム {beams.size} 本 = "
          f"{pts.shape[0]} 測点、測線間隔 {spacing:.1f} m")
    # 重なりの食い違い: 同じ航跡直交位置を、測線 1 の外側と測線 2 の内側が測る。
    # ★重なりの**真ん中**を見てはいけない —— そこは両測線とも同じ振れ角なので、
    #   誤差が同じだけ乗って差がゼロになる。**帯全体で最大**を取る。
    ys = np.linspace(spacing - half_swath, half_swath, 401)
    d1 = np.interp(ys, y_meas, z_meas)                       # 測線 1(外側寄り)
    d2 = np.interp(ys - spacing, y_meas, z_meas)             # 測線 2(内側寄り)
    diff = np.abs(d1 - d2)
    k = int(np.argmax(diff))
    mid = 0.5 * (ys[0] + ys[-1])
    a, b = float(d1[k]), float(d2[k])
    print(f"  重なりの帯 x = {ys[0]:.1f} 〜 {ys[-1]:.1f} m。")
    print(f"  ★真ん中(x = {mid:.1f} m)では差 {abs(float(d1[200]-d2[200])):.4f} m —— "
          f"両測線とも同じ振れ角なので**誤差が同じだけ乗って消える**。")
    # どちらの測線がその点を「直下」で測っているかは、振れ角の小さいほう。
    off1, off2 = abs(float(ys[k])), abs(float(ys[k] - spacing))
    near, far = (a, b) if off1 < off2 else (b, a)
    print(f"  帯の端 x = {ys[k]:.1f} m は、片方が**ほぼ直下**(振れ "
          f"{min(off1, off2):.0f} m)で {near:.3f} m、もう片方が**最外ビーム**"
          f"(振れ {max(off1, off2):.0f} m)で {far:.3f} m と測る点。")
    print(f"     → **食い違い {abs(a-b):.3f} m**")
    print(f"     (TVU {tvu(DEPTH_REF):.3f} m の {abs(a-b)/tvu(DEPTH_REF):.1f} 倍)")
    print("  → ★これはこの PoC で実装した、実データにも使える真値不要の自己整合検査。"
          "\n     同じ海底を 2 度測った差なら、真値なしで出る。")
    # グリッド化して dem_slope で見かけの勾配を測る
    cell = 1.0
    gx = np.arange(-half_swath, spacing + half_swath + 0.001, cell)
    gy = np.arange(0.0, 60.001, cell)
    qx, qy = np.meshgrid(gx, gy)
    got = fs.interp_scattered(pts, vals, np.column_stack([qx.ravel(), qy.ravel()]),
                              method="linear", fill_value=np.nan)
    dtm = np.asarray(got["value"], np.float64).reshape(qx.shape)
    outside = float(got["outside_fraction"])
    filled = np.nan_to_num(dtm, nan=DEPTH_REF)
    slope = np.asarray(fs.ledger.dem_slope(filled, cell), np.float64)
    inner = slope[2:-2, 2:-2]
    print(f"  グリッド {dtm.shape[0]}x{dtm.shape[1]}(セル {cell:.1f} m)、"
          f"凸包の外 {100*outside:.1f} %")
    # 測線 1 本だけの DTM(継ぎ目なし)—— スマイルの曲がりだけを見る。
    # 同じ格子に載せる(右半分は測線 1 の外なので「未測」= 真の深さで埋める)。
    n1 = along.size * beams.size
    got1 = fs.interp_scattered(pts[:n1], vals[:n1],
                               np.column_stack([qx.ravel(), qy.ravel()]),
                               method="linear", fill_value=np.nan)
    dtm1 = np.asarray(got1["value"], np.float64).reshape(qx.shape)
    covered = int(np.searchsorted(gx, half_swath))     # 測線 1 が届く列まで
    dtm1_fill = np.nan_to_num(dtm1, nan=DEPTH_REF)
    slope1 = np.asarray(fs.ledger.dem_slope(dtm1_fill, cell),
                        np.float64)[2:-2, 2:covered - 2]
    flat_slope = float(np.asarray(fs.ledger.dem_slope(
        np.full_like(filled, DEPTH_REF), cell))[2:-2, 2:-2].max())
    print(f"  見かけの勾配(dem_slope、**測線 1 本・継ぎ目なし**): "
          f"平均 {float(slope1.mean()):.3f} 度 / 最大 {float(slope1.max()):.3f} 度")
    print(f"  同(**測線 2 本・継ぎ目あり**): 平均 {float(inner.mean()):.3f} 度 / "
          f"最大 **{float(inner.max()):.3f} 度**")
    print(f"  対照群(真の平らな海底を同じ手順で)最大 {flat_slope:.6f} 度")
    print("  → ★2 つは別物。**継ぎ目なしの数度**はスマイルの曲がりそのもの")
    print("     (平らな海底が浅い谷に見える)。**継ぎ目の数十度**は測線の"
          "貼り合わせで、\n     海底には無い崖が 1 本立つ。地形図として読むと"
          "どちらも「地形」に見える。")
    if figs.enabled():
        figs.save_grid("dtm",
                       [dtm1_fill, filled, filled - DEPTH_REF, slope],
                       ["測線 1 本だけ(右半分は未測)", "測線 2 本",
                        "真の海底との差 [m]", "見かけの勾配 [度]"],
                       ncols=2, signed=[False, False, True, False],
                       title="平らな海底の DTM —— 重なり帯が縞になる",
                       caption=f"測線 2 本、間隔 {spacing:.0f} m。差は "
                               f"{float(np.nanmin(filled-DEPTH_REF)):+.2f} 〜 "
                               f"{float(np.nanmax(filled-DEPTH_REF)):+.2f} m。"
                               f"重なり帯では 2 本の値が最大 {abs(a-b):.2f} m 食い違うので、"
                               f"格子化すると**どちらの測線の三角形を踏んだか**で"
                               f"値が飛び、縞になる(勾配は最大 {float(inner.max()):.0f} 度)。")
        # ★縦軸は**高さ**(= −深さ)にする。深さのまま描くと上下が逆さになり、
        #   「笑っている」形が「しかめ面」に見えてしまう。
        figs.save_plot(
            "across_track",
            [("測った海底", y_meas, -z_meas),
             ("真の海底", y_meas, np.full_like(y_meas, -DEPTH_REF))],
            xlabel="航跡直交距離 [m]", ylabel="海底の高さ = −深さ [m]",
            title="1 発の ping の断面 —— これが「スマイル」",
            caption=f"直下は較正済みで一致。端 65 度で "
                    f"{float(DEPTH_REF-z_meas[-1]):+.2f} m 持ち上がる —— "
                    f"平らな海底が口角を上げた形に記録される。")
    return {"half_swath": half_swath, "spacing": spacing, "mismatch": abs(a - b),
            "slope_max": float(inner.max()), "slope_flat": flat_slope,
            "slope1_max": float(slope1.max()), "slope1_mean": float(slope1.mean()),
            "outside": outside, "n_points": int(pts.shape[0]),
            "y_shift": float(y_meas[-1] - x_true[-1]), "lines": int(line_id.max()) + 1}


# --------------------------------------------------------------------------- #
# 10. 構造のあるプロファイル —— 一定勾配の当てはめでは直らない                    #
# --------------------------------------------------------------------------- #
def section_thermocline(scene):
    print("\n=== 10. サーモクライン —— 一定勾配を当てはめても直らない ===")
    true_prof = profile_thermocline()
    zs = np.linspace(0.0, DEPTH_REF, 6)
    print("  真のプロファイル(混合層 8 m + サーモクライン + 深層):")
    print("   " + "  ".join(f"{z:.0f} m:{float(sound_speed(true_prof, z)):.1f}"
                            for z in zs))
    _, t1, ok = trace_to_depth(true_prof, BEAM_DEG, DEPTH_REF)
    assert bool(np.all(ok))
    ca_true = DEPTH_REF / float(t1[int(np.argmin(np.abs(BEAM_DEG)))])
    print(f"  直下較正の平均音速 {ca_true:.3f} m/s")
    z_const = ca_true * t1 * np.cos(np.radians(BEAM_DEG))
    # 一定勾配の当てはめ: 表層と海底の音速を結ぶ直線(現場の「2 点キャスト」)
    c_top = float(sound_speed(true_prof, 0.0))
    c_bot = float(sound_speed(true_prof, DEPTH_REF))
    fit = (np.array([0.0, 400.0]),
           np.array([c_top, c_top + (c_bot - c_top) / DEPTH_REF * 400.0]))
    _, z_fit, ok2 = trace_for_time(fit, BEAM_DEG, t1)
    assert bool(np.all(ok2))
    print(f"  {'θ₀ [度]':>8}{'等音速で処理':>16}{'一定勾配で処理':>18}{'改善':>10}")
    rows = []
    for th in (0.0, 30.0, 45.0, 60.0, 65.0, 70.0):
        i = int(np.argmin(np.abs(BEAM_DEG - th)))
        a, b = z_const[i] - DEPTH_REF, z_fit[i] - DEPTH_REF
        # 直下は等音速側が(較正済みなので)厳密に 0。比を取ると発散するので出さない。
        gain = "—" if abs(a) < 1e-6 else f"{100*(1-abs(b)/abs(a)):.0f} %"
        rows.append((f"{th:.0f}", f"{a:+.4f}", f"{b:+.4f}", gain))
        print(f"  {th:>8.0f}{a:>+16.4f}{b:>+18.4f}{gain:>10}")
    e_const = float(np.max(np.abs(z_const - DEPTH_REF)))
    e_fit = float(np.max(np.abs(z_fit - DEPTH_REF)))
    print(f"  → 等音速だと最大 {e_const:.3f} m、2 点の一定勾配だと "
          f"{e_fit:.3f} m。**減るが消えない**"
          f"({100*(1-e_fit/e_const):.0f} % しか取れない)。")
    print("     当てはめた形(直線)と真の形(段)が違うので、"
          "自由度を 1 つ増やしても偏りは残る。")
    nadir_fit = float(z_fit[int(np.argmin(np.abs(BEAM_DEG)))] - DEPTH_REF)
    print(f"  → ★しかも一定勾配の当てはめは**直下で {nadir_fit:+.3f} m** ——")
    print("     等音速のほうは直下較正済みなので直下は 0 だった。")
    print("     **外側を良くする代わりに、いちばん検査される所を悪くしている**。")
    print("  → ★対照群として、**真のプロファイルで処理すれば** 誤差は")
    _, z_ok, _ = trace_for_time(true_prof, BEAM_DEG, t1)
    print(f"     最大 {float(np.max(np.abs(z_ok - DEPTH_REF))):.2e} m "
          f"—— 処理の実装ではなく、**プロファイルの取り違え**が原因だと分かる。")
    figs.save_table("thermocline", ["θ₀ [度]", "等音速で処理 [m]",
                                    "一定勾配で処理 [m]", "改善"], rows,
                    title="サーモクラインは一定勾配で書けない",
                    caption="2 点キャスト(表層と海底だけ)の一定勾配当てはめ。"
                            "誤差は減るが消えない。")
    if figs.enabled():
        zz = np.linspace(0.0, 60.0, 200)
        # ★縦軸は −深さ。深さのまま描くと海面が下、海底が上の逆さ図になる。
        figs.save_plot(
            "svp",
            [("真(混合層 + サーモクライン)", sound_speed(true_prof, zz), -zz),
             ("2 点の一定勾配当てはめ", sound_speed(fit, zz), -zz),
             ("等音速(直下較正)", np.full_like(zz, ca_true), -zz)],
            xlabel="音速 [m/s]", ylabel="−深さ [m](0 が海面、下へ −60 m)",
            title="音速プロファイル —— 平均が合っていても形が違う",
            caption="等音速(水色)は直下の走時が真と一致するよう較正してある。"
                    "2 点の一定勾配(橙)は平均としては近いが、混合層の段を"
                    "持たないので直下ですら合わない。")
    return {"e_const": e_const, "e_fit": e_fit, "ca": ca_true,
            "e_true": float(np.max(np.abs(z_ok - DEPTH_REF)))}


# --------------------------------------------------------------------------- #
# 11. 道具の穴 —— 4 層すべて引いてから「無い」と言う                              #
# --------------------------------------------------------------------------- #
def section_op_holes():
    print("\n=== 11. 道具の穴 —— fs / fs.op / fs.ledger / op_find の 4 層を引く ===")
    wanted = [
        ("sonar", "音響測深そのもの"),
        ("swath", "swath(扇状の帯)の処理"),
        ("bathym", "測深・海底地形"),
        ("sound_speed", "音速プロファイル"),
        ("raytrace_layers", "層に切ったレイトレース"),
        ("tvu", "測量の不確かさ規格(IHO S-44)"),
        ("footprint", "ビームの海底フットプリント"),
        ("crossline", "測線交差点の食い違い"),
    ]
    rows, holes = [], []
    for name, note in wanted:
        tiers = (hasattr(fs, name), hasattr(fs.op, name), hasattr(fs.ledger, name))
        hits = [d["op"] for d in fs.op_find(name)]
        # ★``op_find`` は語幹の部分一致で拾うので、件数が 0 でなくても中身は
        #   無関係なことがある("footprint" → ``sk_median_disk``)。**最上位の
        #   名前まで見て**から「無い」と言う。
        top = hits[0] if hits else "—"
        rows.append((name, "○" if tiers[0] else "-", "○" if tiers[1] else "-",
                     "○" if tiers[2] else "-", f"{len(hits)} ({top})", note))
        print(f"  {name:<16} fs:{'○' if tiers[0] else '-'} "
              f"fs.op:{'○' if tiers[1] else '-'} "
              f"fs.ledger:{'○' if tiers[2] else '-'} "
              f"op_find:{len(hits):>2} 件 (先頭 {top:<24}) {note}")
        if not any(tiers) and name not in hits:
            holes.append(name)
    used = ["beamform_delay_sum", "beamform_doa", "find_peaks", "peak_subbin",
            "snell_angle", "interp_scattered", "dem_slope"]
    print("  使えた op: " + ", ".join(used))
    for name in used:
        assert hasattr(fs, name) or hasattr(fs.ledger, name), name
    print("  ★使おうとして**使えなかった**もの:")
    print("    * `beamform_doa` の `range_m` / `velocity_ms` —— FMCW レーダの")
    print("      レンジ-ドップラー面が前提。パルス測深機には無いので None のまま。")
    print("      角度スペクトルの部分だけが音響に読み替えられる(§2 の as_beat_cube)。")
    print("    * `beamform_*` は立方体の 2 軸目・3 軸目に最低 2 を要求するので、")
    print("      素子スナップショット 1 枚を渡すのに `(N,2,2)` へ**水増し**が要る。")
    print("      `beamform_snapshot(x, wavelength, spacing)` があれば素直に書ける。")
    print("    * `snell_angle` は屈折率で受けるので、音響では `eta = 1/c` と")
    print("      **逆数を渡す**必要がある(n ∝ 1/c)。合ってはいるが、読む人は必ず躓く。")
    print("      またスカラー専用なので、141 本のビームを一括で曲げられない。")
    print("      ★これを書いていて**別の片道の穴**が出た: ベクトル版 `refract` の")
    print("      docstring は「1 本でも全反射があるとバッチ全体が None。1 本ずつ")
    print("      回すこと」とだけ書いていて、**光線ごとに TIR を判定する")
    print("      `refract_rays` が既にある**ことに触れていなかった(逆向きの参照は")
    print("      在った)。名前の見つけやすい側から辿ると遠回りさせられる ——")
    print("      2026-09-08 に両方の docstring へ相互参照と `eta = 1/c` を書いた。")
    print("    * `dem_slope` は NaN を通すと周囲まで NaN になるので、凸包の外を")
    print("      埋めてから渡した(§9)。「未測定」と「平ら」が区別できない。")
    print("  ★次に埋めるべき op(この PoC を書いていて欲しかった順):")
    print("    1. `svp_ray_trace(profile, angles, depth)` —— 一定勾配層の閉形式。")
    print("       円弧の弦と走時を桁落ちなしで積む(この PoC の trace_to_depth)。")
    print("    2. `svp_harmonic_mean(profile, depth)` —— 直下較正の平均音速。")
    print("    3. `iho_s44_tvu(depth, order)` / `iho_s44_thu` —— 規格の閾値。")
    print("       閾値を各自が書き写すと、必ずどこかで係数が古くなる。")
    print("    4. `beamform_snapshot(snapshot, wavelength, spacing, angles)` ——")
    print("       レンジ-ドップラーを経由しない、素子スナップショット直入力の口。")
    print("    5. `snell_angle` の配列版(+ 音速で受ける薄いラッパ)。")
    print("    6. `crossline_discrepancy(soundings_a, soundings_b)` —— 真値なしで")
    print("       行う、この PoC の真値不要の自己整合検査(§9)。測量では標準の受入検査。")
    figs.save_table("op_holes", ["語幹", "fs", "fs.op", "fs.ledger",
                                 "op_find 件数(先頭)", "何が欲しかったか"], rows,
                    title="4 層すべて引いた結果 —— 音響測深の op は 1 つも無い",
                    caption="○ = 在る。件数が 0 でなくても中身は無関係"
                            "(footprint → sk_median_disk)。`beamform_*` は"
                            "電波レーダの語彙のまま流用した。")
    return {"holes": holes, "rows": rows, "used": used}

# ───────────────────── 動画(図を出すときだけ組む) ─────────────────────
# 3-D は render3d.render_mesh(z-buffer)で描き、色は頂点の値を重心座標で補間する。
# ★座標の約束: 格子の行 0 を**北(画像の上)**とし、世界座標は (x = 東, Y = 北 = -行方向, z = 上)。
#   行方向をそのまま +Y にすると左手系になり、絵が鏡像になる(上から見た静止図と左右が食い違う)。
def _v_mesh(Z, xs, ys, step=1):
    """標高格子 ``Z[行, 列]`` → 三角形メッシュ ``(V, F)``。``xs`` = 列の座標 [m]、``ys`` = 行の座標 [m]
    (行方向 = 南向き)。世界座標は ``(x, -y, z)``。NaN の頂点に触れる三角形は捨てる。"""
    Zs = np.asarray(Z, np.float64)[::step, ::step]
    h, w = Zs.shape
    gx, gy = np.meshgrid(np.asarray(xs, np.float64)[::step], np.asarray(ys, np.float64)[::step])
    ok = np.isfinite(Zs).ravel()
    V = np.column_stack([gx.ravel(), -gy.ravel(), np.where(np.isfinite(Zs), Zs, 0.0).ravel()])
    idx = np.arange(h * w).reshape(h, w)
    a, b = idx[:-1, :-1].ravel(), idx[:-1, 1:].ravel()
    c, d = idx[1:, :-1].ravel(), idx[1:, 1:].ravel()
    F = np.concatenate([np.column_stack([a, b, d]), np.column_stack([a, d, c])])
    F = F[ok[F].all(axis=1)]
    return V, F


def _v_render(V, F, vcol, pose, K, w, h, light=None, ambient=0.35, bg=(0.07, 0.08, 0.10)):
    """頂点色 ``vcol (nv,3)`` のメッシュを描く → ``(rgb (h,w,3), depth (h,w))``。
    ``light`` = 世界座標の光の向き(None なら頂点色そのまま = 陰影は呼び手が色に焼き込み済み)。"""
    import render3d as R3

    r = R3.render_mesh(V, F, pose=pose, intrinsics=K, width=w, height=h, attributes=True)
    img = np.empty((h, w, 3), np.float64)
    img[:] = bg
    m = r["face"] >= 0
    if m.any():
        fi = r["face"][m]
        col = np.einsum("nk,nkc->nc", r["bary"][m], np.asarray(vcol, np.float64)[F[fi]])
        if light is not None:
            L = pose[:3, :3] @ (np.asarray(light, np.float64) / np.linalg.norm(light))
            col = col * (ambient + (1.0 - ambient) * np.clip(r["normals"][m] @ L, 0.0, 1.0))[:, None]
        img[m] = col
    return np.clip(img, 0.0, 1.0), r["depth"]


def _v_project(P, pose, K):
    """世界座標の点 → ``(列 u, 行 v, 奥行き)``。render_mesh と同じ約束(カメラは -Z を見る)。"""
    P = np.atleast_2d(np.asarray(P, np.float64))
    Vc = P @ pose[:3, :3].T + pose[:3, 3]
    dep = -Vc[:, 2]
    s = np.where(dep > 1e-9, dep, np.nan)
    return K[0, 0] * Vc[:, 0] / s + K[0, 2], K[1, 2] - K[1, 1] * Vc[:, 1] / s, dep


def _v_disk(img, u, v, r, color):
    """画面上の (u, v) に半径 r の円を塗る(はみ出しは切る)。"""
    if not (np.isfinite(u) and np.isfinite(v)):
        return img
    h, w = img.shape[:2]
    r0, r1 = max(0, int(v - r - 1)), min(h, int(v + r + 2))
    c0, c1 = max(0, int(u - r - 1)), min(w, int(u + r + 2))
    if r0 >= r1 or c0 >= c1:
        return img
    yy, xx = np.mgrid[r0:r1, c0:c1]
    m = (yy - v) ** 2 + (xx - u) ** 2 <= r * r
    img[r0:r1, c0:c1][m] = color
    return img


def _v_line(img, p0, p1, color, width=2.0):
    """画面上の線分 (u0,v0)-(u1,v1)。"""
    (u0, v0), (u1, v1) = p0, p1
    if not all(np.isfinite([u0, v0, u1, v1])):
        return img
    n = int(max(abs(u1 - u0), abs(v1 - v0)) * 1.5) + 2
    for t in np.linspace(0.0, 1.0, n):
        _v_disk(img, u0 + t * (u1 - u0), v0 + t * (v1 - v0), width * 0.5, color)
    return img


def _v_txt(img, s, xy, anchor="lt", fs=13):
    import annotate as AN

    return np.asarray(AN.text_box(img, s, xy, anchor=anchor, font_size=fs), dtype=np.float64)


def _v_cbar(img, lut, rect, vmin, vmax, unit, fs=11):
    import annotate as AN

    return np.asarray(AN.color_bar(img, lut, rect, vmin=vmin, vmax=vmax, unit=unit, font_size=fs,
                                   label_fmt="{:.2f}" if abs(vmax - vmin) < 5 else "{:.0f}"),
                      dtype=np.float64)


def _v_cmap(vals, name, vmin, vmax):
    """値の並び → RGB(尺度は vmin..vmax で固定)。"""
    import imgio

    a = np.asarray(vals, np.float64)
    return np.asarray(imgio.apply_cmap(a.reshape(1, -1), name, vmin=vmin, vmax=vmax),
                      np.float64).reshape(a.shape + (3,))


def fig_survey(scene, dtm, VW=640, VH=360, fps=30.0):
    """主図(動画): 船が 2 本の測線を走り、扇形のビームで平らな海底を測っていく。

    水色の曲線 = 真の音線(線形の c(z) で円弧に曲がる、``trace_to_depth``)、白い点 = 直下較正した等音速の
    処理が記録する海底(§9 と同じ式)。測った面は「測った深さ − 真の深さ」で塗り、**高さの誤差だけ
    画面上 5 倍**に伸ばす(真の海底は濃い灰の平面)。最後に 2 本の重なり帯の段差を回り込んで見る。
    """
    import render3d as R3

    prof, ca = scene["prof"], scene["ca"]
    beams = np.arange(-65.0, 65.001, 1.0)
    _, t1, _ = trace_to_depth(prof, beams, DEPTH_REF)
    z_meas = ca * t1 * np.cos(np.radians(beams))
    y_meas = ca * t1 * np.sin(np.radians(beams))
    err = z_meas - DEPTH_REF                         # 負 = 浅く出る(スマイル)
    ex = 5.0
    spacing = dtm["spacing"]
    along = np.arange(0.0, 60.001, 2.0)
    zs = np.linspace(0.0, DEPTH_REF, 26)[1:]
    ray_b = beams[::8]
    ray_x = np.stack([trace_to_depth(prof, ray_b, z)[0] for z in zs], axis=1)   # (本, 深さ)
    emax = 3.0
    lut = _v_cmap(np.linspace(-emax, emax, 256), "coolwarm", -emax, emax)
    K = R3.intrinsics_from_fov(45.0, VW, VH)
    xlo, xhi = float(y_meas.min()) - 5.0, float(spacing + y_meas.max()) + 5.0
    zf = -DEPTH_REF - 0.3
    floor_V = np.array([[xlo, -5.0, zf], [xhi, -5.0, zf], [xhi, 65.0, zf], [xlo, 65.0, zf]])
    floor_F = np.array([[0, 1, 2], [0, 2, 3]])
    floor_C = np.full((4, 3), 0.22)
    per_line, n_orbit = 140, 90
    frames = []

    def swath(line, n_ping):
        """測線 line の先頭 n_ping 発ぶんの面(世界座標: x = 航跡直交, Y = 航跡方向, z = 上)。"""
        if n_ping < 2:
            return None
        y0 = (0.0, spacing)[line]
        Z = -(DEPTH_REF + ex * err)[None, :] * np.ones((n_ping, 1))
        V, F = _v_mesh(Z, y_meas + y0, -along[:n_ping])   # 行 = ping。ys に -along を渡すと世界の Y = +along
        C = _v_cmap(np.tile(err, n_ping), "coolwarm", -emax, emax)
        return V, F, C

    def scene_mesh(parts):
        Vs, Fs, Cs, off = [floor_V], [floor_F], [floor_C], 4
        for p in parts:
            if p is None:
                continue
            Vs.append(p[0])
            Fs.append(p[1] + off)
            Cs.append(p[2])
            off += len(p[0])
        return np.concatenate(Vs), np.concatenate(Fs), np.concatenate(Cs)

    for k in range(2 * per_line + n_orbit):
        if k < 2 * per_line:
            line, kk = divmod(k, per_line)
            s = kk / (per_line - 1) * along[-1]
            n_ping = int(np.floor(s / 2.0 + 1e-9)) + 1
            y0 = (0.0, spacing)[line]
            parts = [swath(0, along.size if line == 1 else n_ping), swath(1, n_ping) if line == 1 else None]
            ship = np.array([y0, s, 0.0])
            eye = ship + np.array([-95.0 + 45.0 * line, -70.0, 55.0])
            tgt = np.array([y0 + 15.0, s + 10.0, -DEPTH_REF + 5.0])
        else:
            kk = k - 2 * per_line
            parts = [swath(0, along.size), swath(1, along.size)]
            ship = None
            a = np.radians(-120.0 + 100.0 * kk / (n_orbit - 1))
            mid = np.array([spacing / 2, 30.0, -DEPTH_REF])
            eye = mid + np.array([140.0 * np.cos(a), 140.0 * np.sin(a), 70.0])
            tgt = mid
        V, F, C = scene_mesh(parts)
        pose = R3.look_at(eye, tgt, up=(0.0, 0.0, 1.0))
        img, dep = _v_render(V, F, C, pose, K, VW, VH, light=(0.2, -0.4, 0.9), ambient=0.6)
        if ship is not None:
            # 真の音線(曲がる)と、処理が記録した点
            for j in range(ray_b.size):
                P = np.column_stack([ship[0] + np.concatenate([[0.0], ray_x[j]]),
                                     np.full(zs.size + 1, ship[1]), -np.concatenate([[0.0], zs])])
                u, v, d = _v_project(P, pose, K)
                for q in range(zs.size):
                    if d[q] > 0 and d[q + 1] > 0:
                        img = _v_line(img, (u[q], v[q]), (u[q + 1], v[q + 1]), (0.45, 0.85, 1.0), width=1.2)
            Pm = np.column_stack([ship[0] + y_meas, np.full(beams.size, ship[1]), -(DEPTH_REF + ex * err)])
            u, v, d = _v_project(Pm, pose, K)
            for j in range(beams.size):
                img = _v_disk(img, u[j], v[j], 1.6, (1.0, 1.0, 1.0))
            u, v, d = _v_project([ship], pose, K)
            img = _v_disk(img, u[0], v[0], 6, (1.0, 0.6, 0.1))
            if 30 < u[0] < VW - 30 and 30 < v[0] < VH - 10:
                img = _v_txt(img, "測線 %d" % (line + 1), (u[0], v[0] - 9), anchor="cb", fs=11)
            txt = ("測線 %d / ping %d 発目(2 m ごと)・ビーム ±65 度 %d 本\n"
                   "直下較正した等音速で処理: 直下 %+.3f m / 65 度 %+.3f m\n"
                   "IHO %s の TVU(%.0f m)= %.3f m"
                   % (line + 1, line * along.size + n_ping, beams.size,
                      err[beams.size // 2], err[-1], ORDER, DEPTH_REF, tvu(DEPTH_REF)))
        else:
            txt = ("2 本の測線の重なり帯(間隔 %.1f m)\n同じ海底を直下と最外ビームで測った食い違い %.3f m\n"
                   "= TVU %.3f m の %.1f 倍 —— 真値なしで見つかる段差"
                   % (spacing, dtm["mismatch"], tvu(DEPTH_REF), dtm["mismatch"] / tvu(DEPTH_REF)))
        img = _v_txt(img, txt, (6, 6), fs=12)
        img = _v_cbar(img, lut, (VW - 80, 92, 14, VH - 150), -emax, emax, "m")
        img = _v_txt(img, "測った − 真の深さ", (VW - 8, 70), anchor="rt", fs=11)
        img = _v_txt(img, "高さの誤差は画面上 5 倍 / 水色 = 真の音線 / 灰 = 真の海底", (6, VH - 6), anchor="lb", fs=11)
        frames.append(img)
    figs.save_video("survey", frames, fps=fps, gif_every=4, gif_width=480,
                    caption="主図(動画、%d × %d・%.0f fps・%.0f 秒): 深さ %.0f m の平らな海底を、船が 2 本の測線(間隔 %.1f m)で測る。"
                            "水色は真の音線(水柱の音速差 %+.0f m/s の線形プロファイルで円弧に曲がる)、白い点と面は直下較正した"
                            "等音速の処理が記録する海底で、色は「測った − 真の深さ」(高さの誤差だけ画面上 5 倍)。直下は %+.3f m、"
                            "65 度は %+.3f m —— 平らな海底が外側だけ持ち上がる「スマイル」。最後に重なり帯を回り込むと、"
                            "同じ海底を直下と最外ビームで測った %.3f m の段差(TVU %.3f m の %.1f 倍)が立っている。"
                            % (VW, VH, fps, len(frames) / fps, DEPTH_REF, spacing, DELTA_C_REF, err[beams.size // 2], err[-1],
                               dtm["mismatch"], tvu(DEPTH_REF), dtm["mismatch"] / tvu(DEPTH_REF)))



# --------------------------------------------------------------------------- #
# --------------------------------------------------------------------------- #
# 実データ —— NOAA NF-14-06(``FULLSEYE_DATA_DIR`` を立てたときだけ走る)       #
# --------------------------------------------------------------------------- #
#: 実データの置き場を指す環境変数。**未設定なら実データの節は丸ごと飛ばす**
#: (既定のパスは持たない —— CI にはデータが無く、合成の門だけを数える)。
DATA_ENV = "FULLSEYE_DATA_DIR"

#: ``$FULLSEYE_DATA_DIR`` の下の NOAA 標本の置き場(repo には入れない)。
NOAA_SUBDIR = "noaa_multibeam"

#: 出典(ISO メタデータ ``otherConstraints`` の "Cite as" を埋めたもの)。
NOAA_CREDIT = ("National Oceanic and Atmospheric Administration (NOAA) (2014): "
               "Multibeam collection for NF-14-06: Multibeam data collected aboard "
               "NOAA Ship NANCY FOSTER (R352) from 03-Sep-14 to 11-Sep-14, Fort Pierce, "
               "Florida to Cape Canaveral, FL. NOAA National Centers for Environmental "
               "Information. https://www.ngdc.noaa.gov/ships/nancy_foster/NF-14-06_mb.html, "
               "accessed 2026-10-02.")

#: ISO メタデータ ``useLimitation`` の要旨。図・印字の全部に付ける。
NOAA_NOTICE = "NOT FOR NAVIGATION / 航行用ではない(NOAA: raw, not QC'd, no warranty)"

#: BAG の南西セル中心 [m](NAD83 / UTM 17N、BAG メタデータの cornerPoints)と格子 [m]。
BAG_SW = (603615.0, 2961050.0)
BAG_RES = 5.0

#: これより外の |角度| [度] は**別枠**で数える(Reson 7125 の外縁。音速では直らない外れ値)。
REAL_EDGE_DEG = 61.0

#: 角度の階級幅 [度] と、中央値を出す最小本数。
REAL_BIN_DEG = 1.0
REAL_MIN_BIN = 50

#: 崖の角度の門の許容 [度](偶部 = 左右平均の崖と、§4 の一定勾配の閉形式の差)。
#: 実際のキャストは一定勾配でない(表層 1545 → 181 m で 1498 m/s だが途中は曲がる)
#: ので、閉形式に求めてよいのは 1 度の桁まで。崖の付近で残差曲線の傾きは約
#: 0.2 m/度しかなく、0.3 m の食い違いで崖は 1.5 度動く —— それ以上の一致は主張しない。
REAL_CLIFF_TOL_DEG = 1.5

#: HSX(MB-System format 201, MBF_HYSWEEP1)の RMB 行のビーム配列。ビットが立った
#: 順に 1 行ずつ並ぶ。並びは MB-System の一次ソース ``mbsys_hysweep.h`` /
#: ``mbr_hysweep1.c``(github.com/dwcaress/MB-System)で確かめたもの。0x0004 は
#: 東・北の 2 行を消費する。この標本は ``5b01`` = 距離・射出角・方向角・強度・品質・
#: 不確かさ の 6 行だけ(4698 ping すべて同じ)。
HSX_RMB_FIELDS = ((0x0001, "range"), (0x0002, "cast"), (0x0004, "east"),
                  (0x0004, "north"), (0x0008, "depth"), (0x0010, "along"),
                  (0x0020, "across"), (0x0040, "pitchang"), (0x0080, "rollang"),
                  (0x0100, "takeoff"), (0x0200, "direction"), (0x0400, "delay"),
                  (0x0800, "intensity"), (0x1000, "quality"), (0x2000, "flags"),
                  (0x4000, "uncert"))


def real_data_dir(sub: str):
    """``$FULLSEYE_DATA_DIR/<sub>``。未設定・不在なら ``(None, 理由)``。"""
    import os
    d = os.environ.get(DATA_ENV, "").strip()
    if not d:
        return None, "%s が未設定" % DATA_ENV
    p = Path(d) / sub
    if not p.is_dir():
        return None, "%s が無い" % p
    return p, ""


def read_svp(path):
    """HYPACK の .svp(``[SVP_VERSION_2]``、3 行目から ``深さ 音速``)。重複深さは捨てる。"""
    z, c = [], []
    for ln in Path(path).read_text().splitlines()[3:]:
        p = ln.split()
        if len(p) == 2:
            z.append(float(p[0]))
            c.append(float(p[1]))
    z = np.asarray(z)
    c = np.asarray(c)
    o = np.argsort(z, kind="stable")
    z, c = z[o], c[o]
    keep = np.r_[True, np.diff(z) > 0]
    return z[keep], c[keep]


def svp_profile(z, c, z_max: float = 600.0):
    """キャストを PoC の ``(z ノード, c ノード)`` に。表層は最浅値、深層は最深値で延ばす。"""
    zn = np.r_[0.0, z, max(z_max, float(z[-1]) + 1.0)]
    cn = np.r_[c[0], c, c[-1]]
    return zn, cn


def _hsx_corrected_angles(theta, direction, roll, pitch):
    """``mbr_hysweep1.c`` の sonar type 3(球面角)の姿勢補正をベクトル化したもの。

    射出角 θ・方向角 → (α, β)(``mb_takeoff_to_rollpitch``)、α += pitch、
    β -= (−HCP の roll)、戻す(``mb_rollpitch_to_takeoff``)。
    """
    phi = 90.0 - direction
    x = np.sin(np.radians(theta)) * np.cos(np.radians(phi))
    y = np.sin(np.radians(theta)) * np.sin(np.radians(phi))
    rollang = np.arccos(np.clip(x, -1, 1))
    s = np.sin(rollang)
    pitchang = np.degrees(np.arcsin(np.clip(
        np.where(s > 1e-12, y / np.where(s > 1e-12, s, 1), 0), -1, 1)))
    rollang = np.degrees(rollang)
    alpha = pitchang + pitch
    beta = rollang - (-roll)
    xx = np.cos(np.radians(beta))
    yy = np.sin(np.radians(alpha)) * np.sin(np.radians(beta))
    zz = np.cos(np.radians(alpha)) * np.sin(np.radians(beta))
    return np.degrees(np.arccos(np.clip(zz, -1, 1))), np.degrees(np.arctan2(yy, xx))


def hsx_soundings(mb_dir, prof):
    """生の HSX(gzip)から測深点を作る。npz が無いときの経路。

    深さは 2 通り: ``z_straight`` = 表面の音速計の値を定数とした直線
    (r cosθ、この PoC のゼロ点)、``z_svp`` = **この PoC の** :func:`trace_for_time`
    でキャストの中を片道走時 r/c_表面 だけ進めた点。どちらも heave を足す。
    適用していないもの(隠さない): レバーアーム、喫水、潮位(ファイルは TID=0)、遅延。
    """
    import gzip
    cols = {k: [] for k in ("E", "N", "z_straight", "r", "th", "sv", "heave",
                            "sgn", "line")}
    files = sorted(Path(mb_dir).glob("*.HSX.mb201.gz"))
    for li, f in enumerate(files):
        with gzip.open(f, "rt", errors="replace") as fh:
            lines = fh.read().splitlines()
        pos, gyr, hcp, pings = [], [], [], []
        i, n_lines = 0, len(lines)
        while i < n_lines:
            ln = lines[i]
            tag = ln[:3]
            if tag == "POS":
                p = ln.split()
                pos.append((float(p[2]), float(p[3]), float(p[4])))
            elif tag == "GYR":
                p = ln.split()
                if p[1] == "0":
                    gyr.append((float(p[2]), float(p[3])))
            elif tag == "HCP":
                p = ln.split()
                hcp.append((float(p[2]), float(p[3]), float(p[4]), float(p[5])))
            elif tag == "RMB":
                p = ln.split()
                t, bd, nb, sv = float(p[2]), int(p[5], 16), int(p[6]), float(p[7])
                arr, k = {}, i + 1
                for bit, name in HSX_RMB_FIELDS:
                    if bd & bit:
                        v = np.array(lines[k].split(), dtype=float)
                        if v.size != nb:
                            raise ValueError("%s 行 %d: %s が %d 個(%d のはず)"
                                             % (f.name, k, name, v.size, nb))
                        arr[name] = v
                        k += 1
                pings.append((t, sv, arr))
                i = k
                continue
            i += 1
        pos, gyr, hcp = np.array(pos), np.array(gyr), np.array(hcp)
        hd_unw = np.unwrap(np.radians(gyr[:, 1]))
        for t, sv, a in pings:
            r = a["range"]
            nb = r.size
            q = a.get("quality", np.full(nb, 3.0))
            ok = (r > 0) & (q >= 2)            # Reson 品質 < 2 は捨てる(MB-System と同じ規則)
            if not ok.any():
                continue
            roll = np.interp(t, hcp[:, 0], hcp[:, 2])
            pitch = np.interp(t, hcp[:, 0], hcp[:, 3])
            heave = np.interp(t, hcp[:, 0], hcp[:, 1])
            th, ph = _hsx_corrected_angles(a["takeoff"], a["direction"], roll, pitch)
            h = float(np.interp(t, gyr[:, 0], hd_unw))
            e0 = np.interp(t, pos[:, 0], pos[:, 1])
            n0 = np.interp(t, pos[:, 0], pos[:, 2])
            cols["E"].append(np.full(int(ok.sum()), e0))
            cols["N"].append(np.full(int(ok.sum()), n0))
            cols["z_straight"].append((r * np.cos(np.radians(th)) + heave)[ok])
            cols["r"].append(r[ok])
            cols["th"].append(th[ok])
            cols["sv"].append(np.full(int(ok.sum()), sv))
            cols["heave"].append(np.full(int(ok.sum()), heave))
            # 横向きの符号と、方向角の向き(水平の振り分けに使う)を 1 本に詰める
            cols["sgn"].append(np.stack([np.cos(np.radians(ph)), np.sin(np.radians(ph)),
                                         np.full(nb, h)], axis=1)[ok])
            cols["line"].append(np.full(int(ok.sum()), li))
    S = {k: np.concatenate(v) for k, v in cols.items()}
    # 光線追跡はこの PoC の処理側の関数をそのまま使う(層ごとに円弧で厳密)
    x, z, _ = trace_for_time(prof, S["th"], S["r"] / S["sv"])
    cph, sph, hh = S["sgn"][:, 0], S["sgn"][:, 1], S["sgn"][:, 2]
    across, along = x * cph, x * sph
    return {"E": S["E"] + along * np.sin(hh) + across * np.cos(hh),
            "N": S["N"] + along * np.cos(hh) - across * np.sin(hh),
            "z_straight": S["z_straight"], "z_svp": z + S["heave"],
            "theta": S["th"] * np.sign(cph), "line": S["line"]}


def read_bag_depth(path):
    """BAG(HDF5)の ``BAG_root/elevation`` を深さ [m](正 = 下)に。欠測 1e6 は NaN。"""
    import h5py
    with h5py.File(path, "r") as f:
        el = f["BAG_root/elevation"][:].astype(np.float64)
    el[el >= 1e6] = np.nan
    return -el


def load_nf1406(root: Path):
    """NF-14-06 一式。``(dict, "")`` か ``(None, 飛ばす理由)``。

    derived の npz があればそれ(``tools/hsx_soundings.py`` の出力)、無ければ生の
    HSX から :func:`hsx_soundings` で作る。
    """
    try:
        import h5py  # noqa: F401
    except ImportError:
        return None, "h5py が無い(BAG を読めない)"
    bag = root / "NF-14-06" / "products" / "NF-14-06-EPA_Paml_Beach_5m.bag"
    svp = root / "NF-14-06" / "ancillary" / "ctd" / "SVP" / "PB-04_142540237.svp"
    npz = root / "derived" / "soundings_NF-14-06.npz"
    mb = root / "NF-14-06" / "MB"
    for p in (bag, svp):
        if not p.is_file():
            return None, "%s が無い" % p
    zc, cc = read_svp(svp)
    prof = svp_profile(zc, cc)
    if npz.is_file():
        with np.load(npz) as d:
            S = {k: np.asarray(d[k]) for k in ("E", "N", "z_straight", "z_svp",
                                                "theta", "line")}
        src = "derived/%s(tools/hsx_soundings.py の出力)" % npz.name
    elif mb.is_dir() and any(mb.glob("*.HSX.mb201.gz")):
        S = hsx_soundings(mb, prof)
        src = "生の HSX %d 本(npz が無いのでこの PoC の光線追跡で処理)" \
            % len(list(mb.glob("*.HSX.mb201.gz")))
    else:
        return None, "測深点(npz も生の HSX も)が無い"
    return {"S": S, "depth": read_bag_depth(bag), "cast": (zc, cc), "prof": prof,
            "src": src}, ""


def _bag_sample(grid, E, N, flip: bool):
    col = np.round((E - BAG_SW[0]) / BAG_RES).astype(np.int64)
    row = np.round((N - BAG_SW[1]) / BAG_RES).astype(np.int64)
    if flip:
        row = grid.shape[0] - 1 - row
    ok = (row >= 0) & (row < grid.shape[0]) & (col >= 0) & (col < grid.shape[1])
    v = np.full(E.shape, np.nan)
    v[ok] = grid[row[ok], col[ok]]
    return v


def _bag_cells(E, N, z, shape):
    """測深点を BAG の 5 m 格子へ平均(行 0 = 南)。点の無いセルは NaN。"""
    col = np.round((E - BAG_SW[0]) / BAG_RES).astype(np.int64)
    row = np.round((N - BAG_SW[1]) / BAG_RES).astype(np.int64)
    ok = (row >= 0) & (row < shape[0]) & (col >= 0) & (col < shape[1])
    flat = row[ok] * shape[1] + col[ok]
    cnt = np.bincount(flat, minlength=shape[0] * shape[1]).astype(np.float64)
    s = np.bincount(flat, weights=z[ok], minlength=shape[0] * shape[1])
    with np.errstate(invalid="ignore", divide="ignore"):
        g = np.where(cnt > 0, s / np.maximum(cnt, 1.0), np.nan)
    return g.reshape(shape)


def _crossing(centers, med, lim: float, side: int, edge: float):
    """直下から片側へ歩き、|中央値| が ``lim`` を最初に越える角度 [度](線形補間)。"""
    sel = np.where((np.sign(centers) == side) & (np.abs(centers) <= edge)
                   & np.isfinite(med))[0]
    sel = sel[np.argsort(np.abs(centers[sel]))]
    prev = None
    for k in sel:
        if abs(med[k]) > lim:
            if prev is None:
                return abs(float(centers[k]))
            a0, a1 = abs(float(centers[prev])), abs(float(centers[k]))
            m0, m1 = abs(float(med[prev])), abs(float(med[k]))
            return a0 + (a1 - a0) * (lim - m0) / (m1 - m0)
        prev = k
    return float("inf")


def section_real_noaa():
    """実データ: NOAA NF-14-06(EPA Palm Beach 投棄場、深さ約 181 m、Reson 7125)。

    門は 3 つ(数字はすべて実行時に計算する):

    * (R1) **音速一定でスマイルが Order 1a を割る角度**を、測る前に §4 の閉形式
      (:func:`cliff_from_exact`、Δc と d はキャストと BAG から)で予測し、
      測深点 − BAG の角度別中央値(直下の偏りを引く)が TVU を越える角度と比べる。
      TVU は IHO S-44 Edition 6.1.0 の 3.2.3 節 TVU_max(d) = √(a² + (b·d)²)、
      7.3 TABLE 1 の Order 1a(a = 0.5 m, b = 0.013)。★片舷ずつ測ると左右で
      ±1.5 度割れる(左 43.9 / 右 41.0 度)ので、残差を角度について**偶部**
      (音速の取り違えは左右対称)と**奇部**(ロールの小さな取付偏りや参照の
      左右差は D tanθ δ で反対称)に分け、偶部の崖を比べる。門は (a) 偶部の崖が
      閉形式から :data:`REAL_CLIFF_TOL_DEG` 以内、(b) キャストの**形のまま**この
      PoC の :func:`trace_to_depth` で追跡した予測のほうが一定勾配の閉形式より近い、
      (c) 光線追跡解は ±61 度の中で一度も TVU を越えない、(d) 奇部は 2 つの解で
      ほぼ同じ(= 左右差は音速ではない。奇部そのものより 4 倍以上小さい差)。
    * (R2) **隣接測線の重なりの差の 95 % 点**(真値を使わない、現場の検査)が
      光線追跡解では TVU(1a) 未満、音速一定では TVU(1a) 超(両向き、全対)。
      S-44 の TVU は 95 % 信頼水準の値なので 95 % 点と比べる。
    * (R3) **±61 度より外**は別枠で数える。本数は全体の 1 % 未満で、光線追跡でも
      中央値が TVU を桁で越える —— 音速では直らない外れ値(外縁の検出)であって
      スマイルではない、を両側で確かめる。

    **報告だけで門にしないもの**: 直下の絶対偏り(光線追跡解で約 −3 m)は
    喫水・レバーアーム・潮位(ファイルは TID=0)を当てていないことと BAG の鉛直
    基準が不明(メタデータに無い)ことの和で、音速の性質ではない。左右の非対称は
    ロールの取付偏り(パッチテスト未実施)を疑うが、手元の資料では確かめられない。
    """
    root, why = real_data_dir(NOAA_SUBDIR)
    D = None
    if root is not None:
        D, why = load_nf1406(root)
    if D is None:
        print("\n実データ: 無し(合成だけ) —— " + why)
        return None
    print("\n" + "=" * 78)
    print("実データ —— NOAA NF-14-06 / EPA Palm Beach(" + NOAA_NOTICE + ")")
    print("=" * 78)
    S, depth = D["S"], D["depth"]
    zc, cc = D["cast"]
    print("  出典: " + NOAA_CREDIT)
    print("  測深点: %s、%d 点 / 測線 %d 本" % (D["src"], S["E"].size,
                                            int(S["line"].max()) + 1))
    # 格子の向き: BAG の行 0 が南か北か。測深点との食い違いで決め、決め手の強さも出す
    mad = {}
    for flip in (False, True):
        g = _bag_sample(depth, S["E"], S["N"], flip)
        d = S["z_svp"] - g
        m = np.isfinite(d) & (np.abs(S["theta"]) < 30.0)
        mad[flip] = float(np.median(np.abs(d[m] - np.median(d[m]))))
    flip = mad[True] < mad[False]
    print("  BAG の向き: 行 0 = %s(食い違いの MAD %.3f m 対 逆向き %.3f m)"
          % ("北" if flip else "南", mad[flip], mad[not flip]))
    ref = _bag_sample(depth, S["E"], S["N"], flip)
    d_med = float(np.nanmedian(depth))
    lim = tvu(d_med)
    print("  BAG 5 m 格子 %d x %d、深さの中央値 %.2f m → IHO S-44 6.1.0 Order 1a の "
          "TVU = %.3f m" % (depth.shape[0], depth.shape[1], d_med, lim))
    # 閉形式の予測(測る前に印字): Δc はキャストの表層と、海底深さでの音速の差
    c0 = float(cc[0])
    cd = float(np.interp(d_med, zc, cc))
    dc = cd - c0
    cmid = 0.5 * (c0 + cd)
    pred = cliff_from_exact(dc, d_med, c_mid=cmid)
    pred_t2 = cliff_from_tan2(dc, d_med, c_mid=cmid)
    th_f = np.arange(0.0, 70.001, 0.05)
    _, t_f, _ = trace_to_depth(D["prof"], th_f, d_med)
    dz_cast = (d_med / float(t_f[0])) * t_f * np.cos(np.radians(th_f)) - d_med
    pred_cast = float(th_f[np.argmax(np.abs(dz_cast) > lim)])
    print("  キャスト PB-04: 表層 %.2f m/s → %.0f m で %.2f m/s(Δc = %+.1f m/s)"
          % (c0, d_med, cd, dc))
    print("  予測(§4 の厳密な閉形式、一定勾配): 崖 = %.2f 度 / ラフな展開式 %.2f 度"
          % (pred, pred_t2))
    print("  予測(キャストの形のまま光線追跡、報告のみ): %.2f 度" % pred_cast)
    print("  ↑ ここまでは測る前。以下が実測。")
    # 角度別の残差(直下 ±5 度の中央値を偏りとして引く)
    edges = np.arange(-70.0, 70.001, REAL_BIN_DEG)
    centers = 0.5 * (edges[1:] + edges[:-1])
    th = S["theta"]
    idx = np.digitize(th, edges) - 1
    res = {}
    for key in ("z_straight", "z_svp"):
        d = S[key] - ref
        m = np.isfinite(d)
        bias = float(np.median(d[m & (np.abs(th) < 5.0)]))
        med = np.full(centers.size, np.nan)
        cnt = np.zeros(centers.size, np.int64)
        for k in range(centers.size):
            mk = m & (idx == k)
            cnt[k] = int(mk.sum())
            if cnt[k] > REAL_MIN_BIN:
                med[k] = float(np.median(d[mk])) - bias
        inner = np.abs(centers) <= REAL_EDGE_DEG
        outer = m & (np.abs(th) > REAL_EDGE_DEG)
        res[key] = {"bias": bias, "med": med, "cnt": cnt,
                    "port": _crossing(centers, med, lim, -1, REAL_EDGE_DEG),
                    "stbd": _crossing(centers, med, lim, +1, REAL_EDGE_DEG),
                    "inner_max": float(np.nanmax(np.abs(med[inner]))),
                    "n_outer": int(outer.sum()), "n": int(m.sum()),
                    "outer_med": float(np.median(d[outer]) - bias) if outer.any()
                    else float("nan")}
    st, sv = res["z_straight"], res["z_svp"]
    # ★左右に分ける: 音速の取り違えは θ について**偶**(左右対称)。ロールの小さな
    #   取付偏りや参照格子の左右の食い違いは**奇**(D tanθ δ)。中心対称な階級なので
    #   k と n−1−k が鏡像。偶部で崖を測り、奇部は両解で同じか(= 音速でない)を見る。
    mirror = centers.size - 1 - np.arange(centers.size)
    assert np.allclose(centers[mirror], -centers)
    for r in (st, sv):
        r["even"] = 0.5 * (r["med"] + r["med"][mirror])
        r["odd"] = 0.5 * (r["med"] - r["med"][mirror])        # 右舷側で正 = 右舷が浅い
        r["even_cliff"] = _crossing(centers, r["even"], lim, +1, REAL_EDGE_DEG)
    band = (centers >= 20.0) & (centers <= 55.0)
    odd_gap = float(np.nanmax(np.abs(st["odd"][band] - sv["odd"][band])))
    odd_max = float(np.nanmax(np.abs(st["odd"][band])))
    i44 = int(np.argmin(np.abs(centers - 44.5)))
    roll_eq = math.degrees(abs(float(st["odd"][i44]))
                           / (d_med * math.tan(math.radians(float(centers[i44])))))
    print("  %-26s %9s %9s %9s %12s %13s" % ("解", "左舷の崖", "右舷の崖", "偶部の崖",
                                            "±61 内の最大", "直下の偏り"))
    for name, r in (("音速一定(表面の音速計)", st), ("光線追跡(キャスト PB-04)", sv)):
        print("  %-26s %8.2f° %8.2f° %8.2f° %10.3f m %+11.3f m"
              % (name, r["port"], r["stbd"], r["even_cliff"], r["inner_max"], r["bias"]))
    print("  ★片舷ずつだと 左 %.2f / 右 %.2f 度 —— 予測 %.2f 度を**はさんで ±%.1f 度**割れる。"
          % (st["port"], st["stbd"], pred, 0.5 * abs(st["port"] - st["stbd"])))
    print("     崖の付近で曲線の傾きは約 0.2 m/度しかないので、左右 ±%.2f m の奇部"
          "(ロール換算 %.2f 度)だけで崖が ±1 度以上動く。" % (abs(float(st["odd"][i44])),
                                                             roll_eq))
    print("  ★偶部(左右平均)の崖 %.2f 度: 閉形式(一定勾配)%.2f 度とは %+.2f 度、"
          "キャストの形のまま追跡した予測 %.2f 度とは %+.2f 度。"
          % (st["even_cliff"], pred, st["even_cliff"] - pred, pred_cast,
             st["even_cliff"] - pred_cast))
    print("     → 一定勾配の閉形式は 1 度の桁で当たり、キャストの**形**を入れると"
          "さらに近い(実際のキャストは表層が一様でない)。")
    print("  ★奇部は両解でほぼ同じ(20〜55 度で差 最大 %.3f m、奇部そのものは最大 %.3f m)"
          " —— **左右差は音速ではない**。" % (odd_gap, odd_max))
    # 外縁の別枠
    n_all = st["n"]
    print("  外縁(|角度| > %.0f 度): %d 本(%.2f %%)。中央値の残差は 音速一定 %+.1f m / "
          "光線追跡 %+.1f m —— **光線追跡でも直らない**ので音速の問題ではない。"
          % (REAL_EDGE_DEG, st["n_outer"], 100.0 * st["n_outer"] / n_all,
             st["outer_med"], sv["outer_med"]))
    # 報告のみ: 直下の絶対偏りと奇部の原因
    print("  報告のみ(門にしない): 光線追跡解の直下の偏り %+.2f m(喫水・レバーアーム・"
          "潮位を未適用、BAG の鉛直基準は不明)。" % sv["bias"])
    print("     奇部の原因(ロールの取付偏り %.2f 度か、BAG 側の左右差か)は、パッチテストの"
          "記録が無いので切り分けられない。" % roll_eq)
    asym = float(st["odd"][i44])
    # 隣接測線の重なり(真値を使わない)
    lines = sorted(set(int(v) for v in np.unique(S["line"])))
    cells = {}
    for key in ("z_straight", "z_svp"):
        cells[key] = {li: _bag_cells(S["E"][S["line"] == li], S["N"][S["line"] == li],
                                     S[key][S["line"] == li], depth.shape)
                      for li in lines}
    ov = []
    print("  隣接測線の重なり(差の 95 % 点、TVU(1a) は重なりの深さの中央値で):")
    for a, b in zip(lines, lines[1:]):
        row = [a, b]
        for key in ("z_svp", "z_straight"):
            dd = cells[key][a] - cells[key][b]
            m = np.isfinite(dd)
            row.append(int(m.sum()))
            row.append(float(np.percentile(np.abs(dd[m]), 95)) if m.sum() >= 200
                       else float("nan"))
        dref = depth[::-1] if flip else depth
        both = np.isfinite(cells["z_svp"][a] - cells["z_svp"][b])
        row.append(tvu(float(np.nanmedian(dref[both]))))
        ov.append(row)
        print("    測線 %d-%d: %5d セル  光線追跡 %.2f m / 音速一定 %.2f m  (TVU %.2f m)"
              % (a, b, row[2], row[3], row[5], row[6]))
    out = {"pred": pred, "pred_t2": pred_t2, "pred_cast": pred_cast, "lim": lim,
           "dc": dc, "d": d_med, "cmid": cmid, "st": st, "sv": sv, "ov": ov, "mad": mad,
           "flip": flip, "asym": asym, "odd_gap": odd_gap, "odd_max": odd_max,
           "roll_eq": roll_eq, "centers": centers, "n": n_all}
    _fig_real_noaa(out, depth, cells, lines, flip)
    return out


def _fig_real_noaa(R, depth, cells, lines, flip):
    """実データの図(``enabled()`` のときだけ)。出典と NOT FOR NAVIGATION を必ず載せる。"""
    if not figs.enabled():
        return
    c = R["centers"]
    keep = np.abs(c) <= REAL_EDGE_DEG
    th_p = np.arange(-REAL_EDGE_DEG, REAL_EDGE_DEG + 0.01, 0.5)
    # 予測曲線は崖の予測と同じ Δc・d・c_mid で引く(測る前に決まっている量だけ)
    pred_curve = np.asarray(smile_exact(np.abs(th_p), R["dc"], R["d"], c_mid=R["cmid"]))
    series = [("音速一定(表面の音速計)", *finite_xy(c[keep], R["st"]["med"][keep])),
              ("光線追跡(CTD PB-04)", *finite_xy(c[keep], R["sv"]["med"][keep])),
              ("予測: §4 の閉形式 Δc=%+.0f m/s" % R["dc"], th_p, pred_curve),
              ("IHO S-44 Order 1a −TVU", np.r_[-REAL_EDGE_DEG, REAL_EDGE_DEG],
               np.r_[-R["lim"], -R["lim"]])]
    figs.save_plot("real_smile", series, xlim=(-REAL_EDGE_DEG, REAL_EDGE_DEG),
                   xlabel="ロール補正後のビーム角 [度](− 左舷 / + 右舷)",
                   ylabel="中央値(測深 − BAG)− 直下の偏り [m]",
                   title="実データのスマイル —— NOAA NF-14-06(NOT FOR NAVIGATION)",
                   size=(900, 520),
                   caption=("音速一定は左 %.1f / 右 %.1f 度で Order 1a(−%.2f m)を割る。"
                            "左右平均(偶部)の崖 %.1f 度は、一定勾配の閉形式 %.1f 度と "
                            "%+.1f 度、キャストの形のまま追跡した予測 %.1f 度と %+.2f 度。"
                            "光線追跡は ±61 度の中で割らない。NOT FOR NAVIGATION。出典: %s "
                            "改変: 生の HSX を姿勢補正・光線追跡し、BAG との差を 1 度ごとの"
                            "中央値にして直下の偏りを引いた。"
                            % (R["st"]["port"], R["st"]["stbd"], R["lim"],
                               R["st"]["even_cliff"], R["pred"],
                               R["st"]["even_cliff"] - R["pred"], R["pred_cast"],
                               R["st"]["even_cliff"] - R["pred_cast"], NOAA_CREDIT)))
    # 地図: BAG と、重なりの最も大きい対の差(音速一定 / 光線追跡)
    best = max(R["ov"], key=lambda r: r[2])
    a, b = best[0], best[1]
    dd_s = cells["z_straight"][a] - cells["z_straight"][b]
    dd_v = cells["z_svp"][a] - cells["z_svp"][b]
    rr, cc_ = np.where(np.isfinite(dd_s))
    # 重なりの帯は南北に長く細い。全長だと細長すぎて題が入らず、save_grid が 8 倍に
    # 拡大して 1 万 px 幅になった(2026-10-02 に実測)ので、南端から 160 セル(800 m)を切る。
    r0 = int(rr.min())
    sl = (slice(r0, min(r0 + 160, int(rr.max()) + 1)),
          slice(max(int(cc_.min()) - 4, 0), int(cc_.max()) + 5))
    lim3 = 3.0
    # 最近傍の整数倍拡大(値を作らない)で短辺を 240 px 以上に
    # (BAG の深さの面も並べたが、この幅 250 m では 181 m 前後の一色で何も読めず外した)
    h_, w_ = dd_s[sl].shape
    k = max(1, int(math.ceil(240.0 / min(h_, w_))))

    def up(a):
        return np.repeat(np.repeat(np.flipud(a), k, axis=0), k, axis=1)

    figs.save_grid("real_overlap",
                   [up(np.clip(dd_s[sl], -lim3, lim3)), up(np.clip(dd_v[sl], -lim3, lim3))],
                   captions=["測線 %d − %d 音速一定 p95 %.2f m" % (a, b, best[5]),
                             "同 光線追跡 p95 %.2f m" % best[3]],
                   signed=True, ncols=2,
                   title="NF-14-06 隣接測線の重なり —— NOT FOR NAVIGATION",
                   caption=("重なりの最も大きい対(南端から 800 m、北が上)。差の 95 %% 点は "
                            "音速一定 %.2f m(TVU %.2f m を超える)、光線追跡 %.2f m(下回る)。"
                            "差の色は ±%.0f m で切った。黒 = 片方の測線しか無いセル。"
                            "NOT FOR NAVIGATION。出典: %s 改変: 測線ごとに 5 m 格子へ平均して"
                            "差を取った。" % (best[5], best[6], best[3], lim3, NOAA_CREDIT)))


def finite_xy(x, y):
    """図に渡す前に NaN を落とす(``save_plot`` は有限値しか受けない)。"""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    m = np.isfinite(x) & np.isfinite(y)
    return x[m], y[m]


def gates_real_noaa(R) -> int:
    """実データの門。``R`` が None(データ無し)なら 0 本。数えた本数を返す。"""
    if R is None:
        return 0
    st, sv = R["st"], R["sv"]
    n = 0
    # 前提: BAG の向きは決め手が強い(逆向きの食い違いが 10 倍以上)
    assert R["mad"][not R["flip"]] > 10.0 * R["mad"][R["flip"]], R["mad"]
    n += 1
    # R1a. 音速一定の崖(偶部 = 左右平均)は §4 の閉形式と ±REAL_CLIFF_TOL_DEG で一致
    assert abs(st["even_cliff"] - R["pred"]) < REAL_CLIFF_TOL_DEG, (st["even_cliff"], R["pred"])
    n += 1
    # R1b. キャストの形のまま追跡した予測のほうが近い(一定勾配は近似であって真値でない)
    assert abs(st["even_cliff"] - R["pred_cast"]) < abs(st["even_cliff"] - R["pred"]), \
        (st["even_cliff"], R["pred_cast"], R["pred"])
    n += 1
    # R1c. 両向き: 光線追跡は ±61 度の中で Order 1a を一度も割らない(片舷・偶部とも)
    assert sv["inner_max"] < R["lim"], (sv["inner_max"], R["lim"])
    assert not any(math.isfinite(sv[k]) for k in ("port", "stbd", "even_cliff")), sv
    n += 1
    # R1d. 左右差(奇部)は 2 つの解で同じ —— 音速では生じない成分。奇部が実際に在る
    #      (0.1 m 超)ことも確かめる(無ければこの門は何も言っていない)
    assert R["odd_max"] > 0.1, R["odd_max"]
    assert R["odd_gap"] < 0.25 * R["odd_max"], (R["odd_gap"], R["odd_max"])
    n += 1
    # R2. 重なりの差の 95 % 点: 光線追跡 < TVU < 音速一定(全対)
    assert len(R["ov"]) >= 3, R["ov"]
    for a, b, n_v, p_v, n_s, p_s, lim in R["ov"]:
        assert p_v < lim < p_s, (a, b, p_v, lim, p_s)
        n += 1
    # R3. 外縁は別枠: 1 % 未満、しかも光線追跡でも中央値が TVU を超える(音速では直らない)
    assert 0 < st["n_outer"] < 0.01 * R["n"], (st["n_outer"], R["n"])
    assert abs(sv["outer_med"]) > R["lim"], sv["outer_med"]
    n += 1
    return n


def main() -> int:
    t0 = time.perf_counter()
    print("=" * 78)
    print("多ビーム測深で海底が笑う —— 音速を取り違えると、壊れるのは外側ビームだけ")
    print(f"深さ {DEPTH_REF:.0f} m の平らな海底 / 水柱の音速差 {DELTA_C_REF:+.0f} m/s / "
          f"ビーム ±70 度 {BEAM_DEG.size} 本 / IHO S-44 {ORDER}")
    print("=" * 78)

    scene = section_scene()
    floor = section_floor(scene)
    null = section_null(scene)
    cliff = section_cliff(scene, floor)
    ctrl = section_controls(scene, floor)
    sweep = section_sweep()
    frown = section_frown()
    foot = section_footprint(scene, floor)
    dtm = section_dtm(scene)
    thermo = section_thermocline(scene)
    holes = section_op_holes()

    print("\n" + "=" * 78)
    print("まとめ —— 何がどれだけ効いたか")
    print("=" * 78)
    rows = [
        ("ゼロ点: 表面音速のまま(直下)",
         f"{null['表面音速 c₀']['nadir']:+.3f} m"),
        ("ゼロ点: 表面音速のまま(70 度)",
         f"{null['表面音速 c₀']['edge']:+.3f} m"),
        ("直下較正だけした(直下)", f"{null['直下較正(調和平均)']['nadir']:+.3f} m"),
        ("直下較正だけした(70 度)", f"{null['直下較正(調和平均)']['edge']:+.3f} m"),
        ("角度推定の床(65 度)", f"{ctrl['角度推定だけ入れる']:+.6f} m"),
        ("エコー検出の床(65 度)", f"{ctrl['エコー検出だけ入れる']:+.4f} m"),
        ("等音速 2 層の実装誤差(65 度)", f"{scene['conv'][0][1]:+.4f} m"),
        (f"IHO {ORDER} を割る角度(全経路)", f"{cliff['cliff']:.2f} 度"),
        ("同(屈折だけ = 検出なし)", f"{cliff['cliff_noecho']:.2f} 度"),
        ("同(厳密式の予測)", f"{cliff['pred_exact']:.2f} 度"),
        ("同(ラフな展開式の予測)", f"{cliff['pred_tan2']:.2f} 度"),
        ("±65 度 swath が失格になる割合",
         f"{100*sweep['fail']/sweep['total']:.1f} %"),
        ("隣接測線の重なりの食い違い", f"{dtm['mismatch']:.3f} m"),
        ("見かけの勾配(測線 1 本 / 継ぎ目あり)",
         f"{dtm['slope1_max']:.2f} / {dtm['slope_max']:.1f} 度"),
        ("70 度のフットプリント(cos² 式 / 実測)",
         f"{foot['foot2'][-1]:.2f} / {foot['foot_iso'][-1]:.2f} m"),
    ]
    for name, val in rows:
        print(f"  {name:<38}{val:>14}")
    figs.save_table("summary", ["条件", "値"], rows,
                    title="多ビーム測深 —— 何がどれだけ効くか",
                    caption="直下較正は誤差を消さず、検査されない外側へ移す。")
    # 動画は図を出すときだけ組む(図なしの実行を変えない)。既存の図の後ろに書く(番号をずらさない)
    if figs.enabled():
        fig_survey(scene, dtm)

    # --- 所見を固定する(穴が塞がったら鳴る)--------------------------------- #
    # 1. 一定勾配の層に切ったレイトレースは閉形式と一致する(円弧が厳密だから)
    assert scene["layer_worst"] < 1e-12, scene["layer_worst"]
    # ray parameter を全層で保存する等音速中点近似は 2 次収束
    n_lo, e_lo = scene["conv"][0]
    n_hi, e_hi = scene["conv"][-1]
    assert (n_hi / n_lo) == 16.0
    assert 240.0 < e_lo / e_hi < 270.0, scene["conv"]
    assert 0.015 < e_lo < 0.018, scene["conv"]
    # 2. 角度推定は完全。エコー検出は**直下では無視できるが外側では効く**
    assert floor["dz_ang"] < 1e-3, floor["dz_ang"]
    assert floor["err_echo"] > 0.1, floor["err_echo"]
    # 3. ゼロ点は直下からもう TVU の半分以上を食う
    assert abs(null["表面音速 c₀"]["nadir"]) > 0.5 * cliff["lim"]
    # 4. 直下較正は直下を厳密に 0 にし、外側には残す(誤差の「移動」)
    assert abs(null["直下較正(調和平均)"]["nadir"]) < 1e-9
    assert abs(null["直下較正(調和平均)"]["edge"]) > 3.0
    # 5. 崖: エコー検出を止めた経路は厳密式と一致する(閉形式の検算)
    assert cliff["gap_noecho"] < 1e-6, cliff["gap_noecho"]
    assert abs(cliff["cliff_noecho"] - cliff["pred_exact"]) < 0.02, cliff
    # ★全経路の崖は**予測より手前**。差は振幅検出の偏り(閉形式に無い量)
    assert 0.3 < cliff["pred_exact"] - cliff["cliff"] < 1.5, cliff
    assert cliff["pred_exact"] - cliff["pred_tan2"] > 0.4, cliff
    # 展開式は外側で過大(45 度で 5 % 以内、70 度で 15 % 超)
    i45 = int(np.argmin(np.abs(cliff["ths"] - 45.0)))
    assert abs(cliff["tan2"][i45] / cliff["exact"][i45] - 1.0) < 0.05
    assert cliff["tan2"][-1] / cliff["exact"][-1] > 1.15, cliff["tan2"][-1]
    # 6. 対照群: 勾配ゼロは厳密に 0、屈折だけが 1 桁大きい
    assert abs(ctrl["勾配ゼロ + 真の平均音速(何も無い)"]) < 1e-12
    assert abs(ctrl["角度推定だけ入れる"]) < 1e-9
    assert abs(ctrl["屈折だけ入れる(直下較正)"]) > 10.0 * abs(
        ctrl["エコー検出だけ入れる"])
    # 7. 掃引: 200 ケース、崖は深いほど浅い角度へ寄り漸近値に近づく
    assert sweep["total"] == 200, sweep["total"]
    assert sweep["shallow"] > sweep["deep"] > sweep["asym"], sweep
    # 漸近値へ**単調に**近づく(ぴったり乗るとは言わない: TVU の定数項が残る)
    gaps = sweep["gaps"]
    assert all(x > y > 0.0 for x, y in zip(gaps, gaps[1:])), gaps
    assert sweep["deep"] - sweep["asym"] < 1.0, (sweep["deep"], sweep["asym"])
    assert sweep["fail"] > 100, sweep["fail"]
    # 8. 上向き屈折: 予測した反転角は「届いた最後」と「届かない最初」の間
    assert frown["last"] < frown["pred"] < frown["first_bad"], frown
    assert frown["dz65"] > 0.0, frown["dz65"]      # frown は深く出る
    # 9. フットプリント: ビーム幅は 1/cosθ で広がり、cos² 式は足りない
    for th in (30.0, 45.0, 60.0, 70.0):
        pred = math.degrees(0.886 * floor["lam"] / (N_ELEM * floor["d"])) \
            / math.cos(math.radians(th))
        assert abs(foot["widths"][th] / pred - 1.0) < 0.10, (th, foot["widths"][th])
    # cos² 式は等音速の対照群の半分以下、cos³ 式は 5 % 以内で当たる
    assert foot["foot2"][-1] < 0.5 * foot["foot_iso"][-1], foot
    assert abs(foot["foot3"][-1] / foot["foot_iso"][-1] - 1.0) < 0.05, foot
    # 屈折を入れるとフットプリントは縮む(別の要因なので混ぜない)
    assert foot["foot_meas"][-1] < 0.85 * foot["foot_iso"][-1], foot
    # 10. DTM: 重なりの段差が TVU を超え、平らな海底に見かけの勾配が立つ
    assert dtm["mismatch"] > cliff["lim"], dtm["mismatch"]
    assert dtm["slope1_max"] > 1.0, dtm["slope1_max"]        # 継ぎ目なしでも数度
    assert dtm["slope_max"] > 10.0 * dtm["slope1_max"], dtm  # 継ぎ目は桁違い
    assert dtm["slope_flat"] < 1e-6, dtm["slope_flat"]
    assert dtm["outside"] == 0.0, dtm["outside"]
    # 11. サーモクライン: 一定勾配の当てはめは減らすが消さない
    assert thermo["e_true"] < 1e-6, thermo["e_true"]
    assert 0.05 * thermo["e_const"] < thermo["e_fit"] < 0.9 * thermo["e_const"], thermo
    # 12. 道具の穴: 音響測深そのものの op は 4 層のどこにも無い
    #     (op_find が語幹で拾う件数は 0 でないことがあるので、名前まで見る)
    for name in ("sonar", "swath", "bathym", "sound_speed", "tvu", "footprint",
                 "crossline", "raytrace_layers"):
        assert name in holes["holes"], (name, holes["holes"])

    # --- 実データ(FULLSEYE_DATA_DIR があるときだけ。無ければ 1 行で飛ばし、門は数えない)
    #     合成の門より後ろに置く: 合成の印字・図の番号・門をデータの有無で変えないため。
    real = section_real_noaa()
    n_real = gates_real_noaa(real)
    if n_real:
        print(f"  実データの門 {n_real} 本: すべて通過")

    print(f"\n所要 {time.perf_counter() - t0:.1f} s")
    if figs.errors():
        print("図の書き出しで失敗:", "; ".join(figs.errors()))
    print("\nPASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
