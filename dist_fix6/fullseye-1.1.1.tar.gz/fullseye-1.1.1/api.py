"""fullseye / imgevolve — stable programmatic API for other projects.

This is the surface another project imports. It works on **numpy arrays**
(no file I/O required), so a robotics/vision pipeline can hand imgevolve a frame
and get a measured result back::

    import fullseye                       # or: import api
    import numpy as np
    frame = np.random.rand(480, 640)      # float64 gray in [0, 1]
    edges = fullseye.apply(frame, "sobel_amp")          # HALCON name or op name
    seg   = fullseye.apply(frame, "otsu")               # image -> region (binary)
    n     = fullseye.apply(seg,   "count_obj")          # region -> feature (scalar)
    out   = fullseye.run_pipeline(frame, ["gauss_filter", "sobel_amp", "otsu"])

Operators are resolved by their op **name** first, then by HALCON alias (the same
rule the CLI uses), so both ``"gauss_filter"`` (HALCON) and ``"gaussian"`` (op
name) work. ``a`` and ``b`` are the two knobs, each in ``[0, 1]``.

Sorts (an op's declared input/output type):
  image  H*W float64 in [0, 1]      region  H*W in {0, 1}
  color  H*W*3 RGB float64          feature scalar float (returned as a Python float)
  contour XLD dict {"shape", "cs"}  volume  D*H*W stack

Discover ops with :func:`list_ops` / :func:`op_names`, or the CLI
(``py -3.11 imgevolve.py ops --search edge``).
"""
from __future__ import annotations

import os
import warnings
import sys
from typing import Iterable, NamedTuple, Sequence

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

import ops as _ops  # noqa: E402  (the engine registry; imports its backends on load)
import opnames as _opnames  # noqa: E402  (canonical op-name aliases, phase 1 of the naming cleanup)
import backend_safe as _bs  # noqa: E402  (fallback ledger / strict mode — the one mediator)
from fslib import FsValueError as _FsValueError  # noqa: E402  (FS_E_INVALID_ARG: input outside the declared domain)
from backend_safe import FullseyeFallbackWarning  # noqa: E402,F401  (re-exported)
import stereo  # noqa: E402  (numpy+scipy depth building blocks)
import terrain  # noqa: E402  (elevation map / traversability)
import imgio  # noqa: E402  (coercion / colormap visualisation / export)
import detect  # noqa: E402  (object segmentation / description / identification)
import registration  # noqa: E402  (rigid point-cloud registration: Kabsch + ICP)
import deformreg  # noqa: E402  (deformable image registration: Thirion's demons + field warp)
import ppf  # noqa: E402  (6-DoF surface matching by Point Pair Features -> object pose for grasping)
import pointcloud  # noqa: E402  (point-cloud geometry: normals, voxel downsample)
import pcseg  # noqa: E402  (point-cloud segmentation/fitting: RANSAC plane/sphere/cylinder, clusters, OBB)
import mesh  # noqa: E402  (3-D object import: OBJ/STL/PLY/OFF -> vertices, points, voxels)
import fileio  # noqa: E402  (in-memory CSV / mesh / point-cloud file operators)
import meshio_opt  # noqa: E402  (optional heavier object formats: glTF/GLB, LAS/LAZ, PCD-binary)
import pose  # noqa: E402  (silhouette posture descriptors)
import locomotion  # noqa: E402  (balance/gait perception: contacts, support polygon, stability margin, gait phase)
import occupancy  # noqa: E402  (2-D occupancy / free-space navigation grids: inflate, clearance, line-of-sight)
import flow  # noqa: E402  (dense optical flow: two-frame motion)
import motion  # noqa: E402  (flow analysis: energy / dominant / segmentation)
import sceneflow  # noqa: E402  (scene flow / ego-motion: FoE, time-to-contact, looming, 3D scene flow)
import features  # noqa: E402  (sparse keypoints/descriptors/matching: Harris/FAST + patch match)
import events  # noqa: E402  (neuromorphic / event-camera vision from frames: DVS events, time surface, contrast max)
import video  # noqa: E402  (read/write video & GIF clips as numpy frames)
import recipes  # noqa: E402  (curated sample pipelines)
import measure  # noqa: E402  (line profiles / distance / angle)
from filters_freq import phase_correlation_shift  # noqa: E402,F401
import volio  # noqa: E402  (volumetric/medical import: DICOM/NIfTI/NRRD/MetaImage/TIFF -> volume)
import raster  # noqa: E402  (bit-depth-preserving raster + metric depth: 16-bit/float/PFM)
import render3d  # noqa: E402  (mesh -> depth/silhouette/normals render + SDF + solid voxelization)
import camera  # noqa: E402  (pinhole geometry: project/triangulate/PnP/essential/rectify -- 2D<->3D backbone)
import odometry  # noqa: E402  (visual/RGB-D odometry: frame-to-frame camera motion + trajectory)
import grasp  # noqa: E402  (antipodal grasp synthesis: force-closure + Ferrari-Canny quality)
import meshrepair  # noqa: E402  (watertight/repair/decimate + exact inertia -> sim-ready body)
import volops  # noqa: E402  (3-D volume analysis: Frangi/Sato/label/distance/region props)
import volregion  # noqa: E402  (RLE 3-D regions: run-length masks + direct-on-runs queries)
import handpose  # noqa: E402  (hand 21-keypoint pose + finger flexions; detection needs optional mediapipe)
import complexops  # noqa: E402  (complex/FFT-domain ops + 2-D phase unwrap [HALCON has none])
import specops  # noqa: E402  (multispectral/hyperspectral cube: ENVI + SAM + unmix + band math)
import videops  # noqa: E402  (video / temporal (T,H,W): temporal denoise, bg-subtract, motion, spatiotemporal filters)
import algo  # noqa: E402  (general-algorithm tier: seq/scalar sorts+reductions with Python+C references)
import algo_codegen  # noqa: E402  (standalone Python/C emission for the general tier)
import algo_difftest as _algo_difftest  # noqa: E402  (honest gate: Python==oracle, C==Python bit-for-bit)
import synth  # noqa: E402  (learn an image's features -> synthesise a similar image; classical texture synthesis)
import funct1d  # noqa: E402  (HALCON funct_1d family: 1-D function/profile analysis on the index grid)
import mathops  # noqa: E402  (math for visual metrology: linalg / stats / interp / poly)
import optics  # noqa: E402  (optics for imaging systems: geometric / wave / imaging / polarisation)
import raytrace  # noqa: E402  (lens design: real ray tracing / OPD wavefront / Seidel sums / tolerances)
from videops import (  # noqa: E402,F401
    temporal_mean, temporal_median, temporal_std, temporal_max, temporal_min,
    frame_difference, background_subtraction, temporal_gradient, motion_energy,
    moving_average, spatiotemporal_gaussian, spatiotemporal_sobel, per_frame,
    flicker_reduce, optical_flow_sequence,
)
from stereo import (  # noqa: E402,F401
    disparity_map, disparity_subpixel, lr_consistency,
    depth_from_disparity, reproject_to_points,
    census_transform, disparity_census, disparity_sgm,
    speckle_filter, fill_disparity, disparity_confidence,
)
from measure import (line_profile, distance, angle,  # noqa: E402,F401
                     fit_line, fit_circle, fit_circle_geometric,
                     fit_curve_principal_axis, fit_ellipse, fit_rectangle2,
                     fit_rectangle2_lsq)
# 2026-11-09 op 点検: はみ出しを扱う NCC / 刻み指定の回転照合(ncc_locate / shape_locate の契約は不変)
from matching import ncc_map_partial, ncc_locate_ex, shape_locate_fine  # noqa: E402,F401
# Exact geometric predicates (robust orientation / in-circle / in-sphere): the
# correct SIGN even when float64 rounds a near-degenerate determinant to the wrong
# side. Used by the convex hull; exposed for robust user-side geometry.
from predicates import (orient2d, orient3d, incircle, insphere,  # noqa: E402,F401
                        orient2d_exact, orient3d_exact, incircle_exact, insphere_exact)
# Precision-union storage: a tiled array whose bit-depth varies per tile (a union
# over {0,1,2,4,8,16} bits), chosen per tile from its local entropy. Cuts memory
# on low-entropy machine-vision data (label/region maps, smooth depth, 3-D
# volumes) while presenting one uniform op surface (to_dense/threshold/mean/map).
from precision_union import (PrecisionUnion, LAZY_OPS as _PU_LAZY,  # noqa: E402,F401
                             LAZY_NARY as _PU_LAZY_NARY, LAZY_FEATURES as _PU_LAZY_FEAT)
# Robust geometry queries built on the exact predicates above: point-in-polygon /
# tetrahedron / convex-polytope (3-valued in/on/out), convexity, Delaunay validity,
# and mesh orientation consistency — the combinatorial decisions that flip under a
# naive float determinant but not under the exact-sign predicates.
from geompred import (point_in_polygon, point_in_convex_polygon, is_convex_polygon,  # noqa: E402,F401
                      point_in_tetrahedron, point_in_convex_polytope,
                      is_delaunay_2d, mesh_orientation_consistent)
# 見え方を**波長から**作る 3 族(2026-09-04): 構造色(回折・干渉・異方性)= matappear、
# ガラスと鏡面の界面/体積/分散 = glassmirror、加工された金属表面(仕上げの筋と粗さ)
# = metalfinish。どれも色を絵の具として塗らず、n,k や格子ピッチや膜厚から計算して
# CIE 等色関数で RGB に落とすので、角度やパラメータを変えると色が物理的に動く。
from matappear import (cie_xyz_from_wavelength, spectrum_to_srgb,  # noqa: E402,F401
                       thin_film_reflectance, grating_wavelengths, grating_rgb,
                       thin_film_rgb, ward_anisotropic)
from glassmirror import (fresnel_dielectric, fresnel_conductor,  # noqa: E402,F401
                         brewster_angle_deg, critical_angle_deg,
                         metal_optical_constants, metal_mirror_rgb,
                         beer_lambert_transmittance, slab_transmittance,
                         refract_rays, prism_min_deviation_deg)
from metalfinish import (finish_catalog, tangent_field, micro_normals,  # noqa: E402,F401
                         blast_normals, finish_shade)
# 金属・ガラス以外の素材と表面(粗い拡散・上塗り・布・木・濡れ・腐食・すりガラス)。
from surfacelib import (material_catalog, oren_nayar, clearcoat_shade,  # noqa: E402,F401
                        metallic_flake_normals, sheen_shade, weave_normals,
                        wood_grain, wetness, corrosion_mask, subsurface_approx,
                        rough_transmission)
# op 別の入力補助(探す / すぐ動かす / 型を繋ぐ)。台帳 op ではなく利用の入口。
import opassist  # noqa: E402,F401
from opassist import (op_find, op_run, op_path, op_assist,  # noqa: E402,F401
                      op_presets, op_producers, op_consumers, op_accepts, op_sorts)
# 3-D metrology fits — the (depth, row, col) analogue of the 2-D fits above.
# numpy-only (no torch), so always available; the torch-backed op registry below is guarded.
from measure3d import (  # noqa: E402,F401
    fit_line3, fit_plane3, fit_sphere3, fit_circle3,
    fit_surface_principal_axes,
    smallest_box3, smallest_box3_axis, fit_box3, smallest_sphere3)
from regionprops3d import inner_box3  # noqa: E402,F401  (3-D inner_rectangle1)
import measure3d          # noqa: E402,F401
import regionprops3d      # noqa: E402,F401
_PIPELINE3D_NAMES = ("register_pointclouds", "align_cad_to_scan", "measure_plane",
                     "inspect_roundness", "match_sdf", "register_auto")


def _pipeline3d_missing(name, why):
    def _f(*args, **kwargs):
        raise ImportError("%s は pipeline3d(3-D 合成パイプライン)の op で、import に失敗している: %s" % (name, why))
    _f.__name__ = name
    _f.__doc__ = "pipeline3d が import できない環境の代役(呼ぶと ImportError)。"
    return _f


try:                      # full typed 3-D op registry + composite pipelines
    import ops3d          # noqa: E402,F401  (needs the `threed` extra — torch)
    import pipeline3d     # noqa: E402,F401
    # ★2026-10-02: 合成パイプライン 6 本を fs.<名前> から出す。以前は ``fs.pipeline3d.<fn>`` でしか届かず、
    #   公開経路の門では「1 本も届かない島」として _INTERNAL に置かれていた。import 自体は torch が無くても
    #   通る(torch_lazy)。torch を要るのは呼んだときの FPFH / ICP の側だけ。
    from pipeline3d import (  # noqa: E402,F401
        register_pointclouds, align_cad_to_scan, measure_plane, inspect_roundness, match_sdf, register_auto)
except ImportError as _e:  # keep the facade importable on a numpy-only install
    ops3d = None
    pipeline3d = None
    for _n in _PIPELINE3D_NAMES:
        globals()[_n] = _pipeline3d_missing(_n, _e)
except Exception as _e:   # noqa: BLE001 - installed but BROKEN is not the same as absent
    ops3d = None
    pipeline3d = None
    _bs.record("ops3d", _e, None, source="import")
    for _n in _PIPELINE3D_NAMES:
        globals()[_n] = _pipeline3d_missing(_n, _e)
from registration import (  # noqa: E402,F401
    kabsch, icp, point_to_plane_icp, apply_transform, pca_align, register, feature_register,
    icp_gated, point_to_plane_icp_gated,
)
from ppf import ppf_model, surface_match, find_surface_pose  # noqa: E402,F401
from pointcloud import (  # noqa: E402,F401
    estimate_normals, voxel_downsample,
    remove_statistical_outliers, remove_radius_outliers, fpfh,
)
from pcseg import (  # noqa: E402,F401
    fit_plane, fit_plane_ransac, fit_sphere_ransac, fit_cylinder_ransac,
    plane_distance, height_above_plane, remove_ground,
    euclidean_clusters, region_growing, aabb, obb, crop_box, crop_sphere,
    farthest_point_sampling, curvature, centroid, principal_axes,
)
from pocviewer import (  # noqa: E402,F401
    write_viewer, viewer_spec, viewer_text, viewer_number, viewer_mesh_tab, viewer_points_tab,
    viewer_frames_tab, viewer_split_tab, viewer_anim3d_tab,
    viewer_export_strings, viewer_motion_gate, viewer_motion_gate_data, viewer_quality_gate_data,
)
import pocviewer  # noqa: E402,F401
from mesh import (  # noqa: E402,F401
    read_mesh, read_points, write_mesh, write_points, sample_surface, mesh_to_points,
    voxelize, bounds, recenter, normalize_scale,
)
from fileio import (  # noqa: E402,F401
    table_write_csv, table_read_csv,
    mesh_write_ply, mesh_read_ply, mesh_write_stl, mesh_read_stl,
    mesh_write_obj, mesh_read_obj, mesh_write_off, mesh_read_off,
    points_write_xyz, points_read_xyz,
    e57_write, e57_read,
    archive_probe, archive_list, archive_extract, archive_create,
    astro_fits_write, astro_fits_read,
    em_mrc_write, em_mrc_read,
    nrrd_write, nrrd_read,
    nifti_write, nifti_read,
    ome_tiff_write, ome_tiff_read,
)
from meshio_opt import (  # noqa: E402,F401
    read_gltf, read_gltf_merged, read_las, read_pcd, formats_available,
)
from volio import read_volume, write_volume, list_dicom_series, VolumeMeta  # noqa: E402,F401
from raster import read_raster, to01, read_depth, read_pfm, write_pfm, save16  # noqa: E402,F401
from render3d import (  # noqa: E402,F401
    render_mesh, look_at, intrinsics_from_fov, auto_view, mesh_to_sdf,
    voxelize_solid, marching_cubes,
)
from camera import (  # noqa: E402,F401
    intrinsic_matrix, decompose_intrinsics, projection_matrix,
    project_points, backproject, depth_to_points, normals_from_depth,
    normals_from_depth_edgeaware,
    triangulate, reprojection_error, solve_pnp, rodrigues, rotation_log,
    fundamental_matrix, essential_matrix, essential_from_fundamental,
    decompose_essential, recover_pose, epipolar_lines,
    distort_points, undistort_points, distort_image, undistort_image, estimate_distortion, stereo_rectify,
)
from calib import (  # noqa: E402,F401
    camera_calibration,
)
from odometry import (  # noqa: E402,F401
    rgbd_odometry, pnp_odometry, integrate_trajectory,
    umeyama_align, trajectory_error,
)
from grasp import (  # noqa: E402,F401
    Grasp, sample_antipodal_grasps, grasps_from_mesh, force_closure,
    ferrari_canny_quality, approach_vector_from_normals, rank_grasps,
    grasp_pose, collision_free,
)
from meshrepair import (  # noqa: E402,F401
    is_watertight, is_edge_manifold, boundary_edges, weld_vertices,
    remove_degenerate_faces, orient_consistent, fill_holes, smooth_taubin,
    decimate_qem, convex_hull, inertia_tensor, components,
)
from volops import (  # noqa: E402,F401
    vol_frangi, vol_sato, vol_hessian_blobness, vol_distance_transform,
    vol_label, vol_region_props, vol_gradient_magnitude, vol_local_maxima,
    vol_watershed,
    vol_reduce_domain, vol_bounding_box, vol_crop_domain, vol_uncrop,
    vol_boundary, vol_boundary_points, vol_tiled_map,
    vol_local_std, vol_local_thickness, vol_euler_number,
    vol_granulometry, vol_orientation_coherence,
)
from volregion import (  # noqa: E402,F401
    VolRLE, vol_rle_encode, vol_rle_decode, vol_rle_volume, vol_rle_bbox,
    vol_rle_centroid, vol_rle_union, vol_rle_intersect, vol_rle_difference,
    vol_rle_components,
)
import volgray  # noqa: E402  (3-D intensity transforms: CT windowing / equalize / gamma / stretch)
import volxform  # noqa: E402  (3-D geometric transforms: resize / rotate / affine)
import volprobe  # noqa: E402  (3-D virtual probe: profile line / edge probe / wall thickness)
import volfreq  # noqa: E402  (3-D FFT filtering: low/high/band-pass)
import volrestore  # noqa: E402  (3-D restoration: Richardson-Lucy deconvolution)
from volgray import (  # noqa: E402,F401
    vol_window_level, vol_equalize, vol_gamma, vol_stretch,
)
from volxform import (  # noqa: E402,F401
    vol_resize, vol_rotate, vol_affine,
)
from volprobe import (  # noqa: E402,F401
    PreparedVolProbe, prepare_vol_probe,
    vol_profile_line, vol_edge_probe, vol_wall_thickness,
)
from volfreq import (  # noqa: E402,F401
    vol_fft_lowpass, vol_fft_highpass, vol_fft_bandpass,
)
from volrestore import (  # noqa: E402,F401
    vol_gaussian_psf, vol_richardson_lucy,
)
from handpose import (  # noqa: E402,F401
    hand_landmarks, finger_flexions, hand_skeleton_edges, draw_hand_landmarks,
)
from complexops import (  # noqa: E402,F401
    cx_fft, cx_ifft, cx_magnitude, cx_phase, cx_real, cx_imag, cx_log_magnitude,
    cx_from_mag_phase, phase_unwrap, cx_wiener_deconvolve, cx_apply_transfer_function,
    cx_bandpass,
)
from specops import (  # noqa: E402,F401
    BandMeta, read_envi, write_envi, spec_band, spec_rgb_composite, spec_nearest_band,
    spec_band_ratio, spec_index, spec_angle_mapper, spec_pca, spec_mnf, spec_unmix,
    spec_endmembers_ppi, spec_continuum_removal,
    spec_pansharpen, spec_decorrelation_stretch, spec_fuse,
    stain_unmix, stain_recompose, stain_vectors_from_patches, STAIN_VECTORS,
)
# realdata: 実写サンプルの取り口。PoC の EXTEND が利用者にこれを指すので、
# **公開経路に載せる**(埋もれた実装を作らない)。
from realdata import (  # noqa: E402,F401
    SAMPLE_PHOTOS, sample_photo, sample_photo_rgb, sample_photo_raw,
    sample_stereo_pair, sample_photo_credit,
    sem_metal_layer_cache, sem_metal_layer_root, sem_metal_layer_pairs,
    sem_metal_layer_credit, e57_bunny_cache, e57_bunny_files,
    walnut_cbct_projection_indices, walnut_cbct_cache, walnut_cbct_write_manifest,
    walnut_cbct_root, walnut_cbct_credit,
    dtu_pv_irt_cache, dtu_pv_irt_root, dtu_pv_irt_frame, dtu_pv_irt_load, dtu_pv_irt_credit,
)
from deformreg import (  # noqa: E402,F401
    warp_by_field, demons_register, field_magnitude, residual_ssd,
)
# 照合と位置合わせ(opsmatchreg 台帳、2026-11-03)の合成の道具。12 op 本体は fs.ledger から引ける。
# 既知の変換・既知の変形場で対を作る側(精度の表・地図の真値の作り方そのもの)なので公開経路に載せる。
from featmatch import (  # noqa: E402,F401
    synthetic_scene, warp_homography, corner_error, condition_homography,
)
from intensityreg import warp_parametric, synthesize_moving, smooth_test_field  # noqa: E402,F401
from pose import pose_descriptor, skeleton_nodes, principal_axis  # noqa: E402,F401
from flow import (  # noqa: E402,F401
    optical_flow_lk, optical_flow_hs, warp_by_flow, flow_magnitude, flow_angle,
    track_points,
)
from motion import (  # noqa: E402,F401
    frame_motion_energy, dominant_motion, flow_from_model, residual_motion,
    motion_segments, motion_energy_series, detect_events,
)
from sceneflow import (  # noqa: E402,F401
    flow_divergence, flow_curl, focus_of_expansion, time_to_contact,
    looming, ego_translation_from_flow, scene_flow,
)
from features import (  # noqa: E402,F401
    harris_corners, fast_corners, describe_patches, match_descriptors, match_keypoints,
)
from events import (  # noqa: E402,F401
    simulate_events, event_count, event_image, event_rate, event_rate_map,
    time_surface, warp_frame, contrast_maximization,
)
from video import (  # noqa: E402,F401
    read_frames, iter_frames, frame_pairs, write_video, probe,
)
from terrain import (  # noqa: E402,F401
    elevation_map, traversability, foothold_score, fill_gaps,
    ground_surface, ground_plane, detect_obstacles,
    fuse_elevation, slope_map, roughness_map, surface_normals,
    step_edges, foothold_candidates,
)
from locomotion import (  # noqa: E402,F401
    contact_points, com_from_silhouette, support_polygon,
    com_support_margin, gait_phase,
)
from occupancy import (  # noqa: E402,F401
    occupancy_grid_2d, inflate_obstacles, clearance_map, line_of_sight, frontier_cells,
)
from imgio import (  # noqa: E402,F401
    to_float01, to_uint8, apply_cmap, colorize_depth, colorize_disparity,
    colorize_labels, colorize_height, colorize_flow, shaded_relief, overlay_mask,
    save, load, save_ply, COLORMAPS,
    colorize_categorical, colorize_bivariate, colorize_significance,
    NORMS, QUALITATIVE, PERCEPTUAL_SAFE, CVD_SAFE, CYCLIC,
)
from detect import segment_objects, object_descriptor, nearest_prototype, draw_objects  # noqa: E402,F401
from synth import (  # noqa: E402,F401
    learn_features, synthesize_like, match_histogram, radial_power_spectrum,
    feature_distance, patch_novelty, pyramid_stat_distance,
)
from funct1d import (  # noqa: E402,F401
    smooth_funct_1d_gauss, smooth_funct_1d_mean,
    derivate_funct_1d, integrate_funct_1d,
    zero_crossings_funct_1d, local_min_max_funct_1d,
    funct_1d_to_pairs, abs_funct_1d, negate_funct_1d, scale_y_funct_1d,
    compose_funct_1d, num_points_funct_1d, distance_funct_1d,
    sample_funct_1d, get_pair_funct_1d, invert_funct_1d,
    transform_funct_1d, x_range_funct_1d, y_range_funct_1d,
    get_y_value_funct_1d, create_funct_1d_array, create_funct_1d_pairs,
    match_funct_1d_trans,
)
from mathops import (  # noqa: E402,F401
    mat_solve, mat_lstsq, mat_svd, mat_eigh, mat_pinv, mat_cond,
    mat_lu, mat_qr, mat_cholesky, mat_eig,
    stat_describe, stat_histogram, stat_covariance, stat_correlation,
    stat_zscore,
    interp_linear, interp_cubic, interp_scattered,
    poly_fit, poly_eval, poly_roots,    cplx_contour_circle, cplx_poly_eval, cplx_contour_integral,
    cplx_winding_number, cplx_cauchy_value, cplx_argument_principle,
    cplx_laurent_coeffs, cplx_joukowski, cplx_mobius, cplx_cr_residual,
    # 複素平面を「面」で見る(2026-09-22)—— 曲線の層に対する領域の層
    cplx_plane_grid, cplx_rational_field, cplx_domain_colour,
    cplx_newton_basins, cplx_escape_time, mandelbrot_interior,
    potential_flow_joukowski, joukowski_circulation,
    # 定理が門になる図(2026-09-23)
    circle_packing_apollonian, ford_circles,
    phyllotaxis_pattern, neighbour_index_gaps,
    ifs_fractal, ifs_similarity_dimension,
    space_filling_curve, curve_locality,
    # 波動 —— 膜の固有モード・干渉・回折(2026-09-23)
    wave_membrane_mode, wave_mode_frequencies, wave_nodal_lines,
    wave_two_slit, wave_fringe_period, wave_grating_orders,
    wave_dominant_frequency,
    # 力学系 —— 積む・断面・指数・分岐(2026-09-23)
    ode_flow_states, ode_vector_field_grid, dynsys_poincare_section,
    dynsys_lyapunov_spectrum, dynsys_bifurcation_map,
    dynsys_correlation_dimension,
)
# フーリエ以外の積分変換(Abel / Hankel / Laplace)と s 領域の線形系(2026-10-03)
from mathtransforms import (  # noqa: E402,F401
    abel_transform,
    abel_inverse,
    abel_inverse_image,
    abel_revolve,
    HankelPlan,
    hankel_transform,
    tf_poles_zeros,
    tf_freq_response,
    tf_impulse_response,
    tf_step_response,
    tf_bilinear,
    laplace_inverse_talbot,
    laplace_inverse_func,
    hankel_image,
    dct_transform,
    wavelet_filters,
    dwt_transform,
    dwt_inverse,
)
# 数値計算の古典(求積・低食い違い列・Chebyshev・シンプレクティック積分)と特殊関数(2026-10-03)
from mathnumerics import (  # noqa: E402,F401
    erf,
    erfc,
    bessel,
    gauss_quadrature,
    gauss_cubature,
    chebyshev_coeffs_nd,
    chebyshev_eval_nd,
    low_discrepancy,
    chebyshev_nodes,
    interp_barycentric,
    integrate_hamiltonian,
)
# FFT では足りないスペクトル推定(不等間隔の周期図・部分空間法の到来方向推定、2026-10-03)
from mathspectral import (  # noqa: E402,F401
    lomb_scargle,
    music_doa,
    esprit_doa,
    ula_snapshots,
    n_sources_mdl,
    hilbert_analytic,
)
# 推定と統計の古典(割当・分布の距離・検定・Cramér–Rao・Kalman 平滑化・行列の指数と対数、2026-10-03)
from mathestimation import (  # noqa: E402,F401
    assign_hungarian,
    hist_distance,
    stat_ttest_paired,
    stat_ttest_welch,
    stat_ks_test,
    stat_chi2_gof,
    crlb_gaussian,
    kalman_smooth,
    mat_expm,
    mat_logm,
    se3_exp,
    se3_log,
)
# 離散幾何と位相の古典(Euler 標数・角欠損・Delaunay・熱法の測地距離、2026-10-03)
from mathgeometry import (  # noqa: E402,F401
    mesh_euler_characteristic,
    angle_defect,
    delaunay_triangulate,
    geodesic_heat,
    geodesic_heat_grid,
    mesh_torus,
    nurbs_curve,
    nurbs_circle,
    nurbs_surface,
    nurbs_revolve,
)
# 仮想マシンビジョン環境: 部品を買う前に「その構成で狙う欠陥が見つかるか」を
# 閉形式の光学 + 数式で作った欠陥 + 撮像連鎖で先に確かめる層。
import defectgen  # noqa: E402  (mathematical defect models with pixel-perfect masks)
import visiondesign  # noqa: E402  (closed-form feasibility: resolution / DOF / falloff)
import visionlab  # noqa: E402  (the whole loop: design -> part -> capture -> inspect)
from defectgen import (  # noqa: E402,F401
    defect_scratch, defect_pits, defect_crack, defect_blob,
    surface_texture, composite_defect, defect_stats,
)
from visiondesign import (  # noqa: E402,F401
    system_geometry, resolving_power, system_feasibility, image_formation,
    detectability_limit,
)
from visionlab import (  # noqa: E402,F401
    VisionSystem, render_part, inspection_sweep, detection_report,
)
# ライトフィールド(plenoptic): 4-D (V,U,H,W) を扱う族。1 回の露光から視点・
# リフォーカス・深度を出す経路で、既存の stereo / focus_stack とは入力が違う。
import lightfield  # noqa: E402  (4-D light field: views / refocus / depth)
from lightfield import (  # noqa: E402,F401
    lf_synthesize, lf_from_mla, lf_to_mla, lf_stats,
    lf_subaperture, lf_center_view, lf_views, lf_epi,
    lf_refocus, lf_focal_stack, lf_aperture_mask, lf_synthetic_aperture,
    lf_depth_from_focus, lf_epi_slope, lf_disparity_to_depth, lf_all_in_focus,
    lf_plenoptic_design,
)
# 光子計数・時間分解: 光が「連続した明るさ」でなく**数えられる粒**になる領域。
# 加法ガウス雑音を足す aug_* とは雑音モデルが違い(乗法的なショット雑音)、
# 到達時刻ヒストグラムから距離・寿命を出す経路をまとめて持つ。
import photoncount  # noqa: E402  (photon counting / SPAD / TCSPC / dToF / lifetime)
from photoncount import (  # noqa: E402,F401
    photon_sample, photon_statistics, photon_uncertainty,
    anscombe_transform, anscombe_inverse,
    spad_deadtime_apply, spad_deadtime_correct, tcspc_coates_correct,
    tcspc_simulate, tcspc_irf_convolve, tcspc_background_subtract, tcspc_stats,
    dtof_depth, dtof_cube_simulate, dtof_cube_depth,
    lifetime_fit, lifetime_phasor,
)
# 鏡面反射の分離と反射モデル: 光沢面・鏡面部品の検査で Lambertian 前提が
# 破れる領域。二色性反射モデル(色の方向で分ける)・BRDF・影に強い
# フォトメトリックステレオ・偏光による分離。
import specularity  # noqa: E402  (dichromatic split / BRDF / robust photometric stereo)
# 位相ベースのモーション増幅: 目に見えない微小振動を可視化・定量化する層。
# 既存の optical_flow_* は「どこがどれだけ動いたか」を返すが、こちらは
# サブピクセルの周期運動を帯域で選んで増幅する(別の問題を解いている)。
# 四元数・双対四元数による 3-D 姿勢代数。**実装は前からあったが、どちらの
# facade からも 1 つも引けなかった**(module-only)。3-D 姿勢の合成・逆・補間は
# 回転行列より数値的に素直で、ねじ運動(screw)表現も持つ。
import pose_quat  # noqa: E402  (quaternion / dual-quaternion 3-D pose algebra)
from pose_quat import (  # noqa: E402,F401
    axis_angle_to_quat, convert_point_3d_cart_to_spher,
    convert_point_3d_spher_to_cart, convert_pose_type, create_pose,
    dual_quat_compose, dual_quat_conjugate, dual_quat_interpolate,
    dual_quat_normalize, dual_quat_to_pose, dual_quat_to_screw,
    dual_quat_trans_point_3d, get_pose_type, hom_mat3d_to_pose_local,
    pose_average, pose_compose, pose_invert, pose_to_dual_quat,
    pose_to_hom_mat3d_local, pose_to_quat, quat_compose, quat_conjugate,
    quat_interpolate, quat_normalize, quat_rotate_point_3d,
    quat_to_hom_mat3d, quat_to_pose, screw_to_dual_quat,
)
# 四元数画像: 画素が 4 成分になる層。複素画像 (cimage) の回転軸は 1 本だが、
# 四元数の純虚部 (0,R,G,B) は 3 次元ベクトルで、q·x·q* が**色空間の 3 次元
# 回転**になる — チャンネルごとの複素演算では構造的に書けない操作。加えて
# Riesz 変換 / モノジェニック信号(解析信号の 2 次元一般化)を持つ。
# 1-D 信号 / 音響 / 振動。**画像の外**の入力を同じ op 体系で扱う層で、
# 音声 I/O とスペクトログラム・帯域通過・包絡線・実効値まで持つ。
# 振動を「映像から測る」経路は motionmag、「音から測る」経路がこちら。
# **api にだけ無く fullseye にはある**という食い違いがあったので揃えた
# (2026-09-01 実測: api.__all__ に bandpass が無く fullseye にはあった)。
import dsp  # noqa: E402  (1-D signal / acoustic / vibration)
from dsp import (  # noqa: E402,F401
    read_wav, write_wav, read_audio, spectrum, spectrogram, lowpass,
    highpass, bandpass, envelope, rms, find_peaks, peak_subbin,
    local_std as signal_local_std, quantize as signal_quantize,
    companding_mu_law as signal_companding_mu_law,
    point_spectrum, signal_features,
    resample, zero_crossing_rate,
)
# FMCW レンジ-ドップラー: 既存の lidar_* が幾何(レイキャスト)だけで信号処理層が
# 空だったところを埋める層。距離と**速度を同時に**出し、遅延和ビームフォーミングで
# 到来角も出す。photoncount(dToF)とは原理が逆で、型も分けてある。
# 音響・振動診断: 「1-D が扱えるなら音響も扱える」を道具にした層。反転可能な
# 短時間フーリエ変換、軸受欠陥の包絡線スペクトル、次数比分析、オクターブ帯域と
# 周波数重み付け。motionmag が「映像から測る振動」、こちらが「音から測る振動」。
# コヒーレンス走査干渉 / クロマティック共焦点: 既存の fringe(位相シフト法)が
# 2π 不定性に負ける段差を、包絡線のピークで解く経路。実測で fringe は
# 段差 λ/4 = 0.15 µm ちょうどから λ/2 の整数倍ずれた答えを**無言で**返す。
import interferometry  # noqa: E402  (coherence-scanning interferometry / chromatic confocal)
from interferometry import (  # noqa: E402,F401
    chromatic_confocal_height, chromatic_confocal_simulate,
    csi_contrast_map, csi_design, csi_envelope, csi_height_map,
    csi_peak_position, csi_signal_simulate, csi_stack_simulate,
)
# ハエ視葉の視覚処理経路: 設計側(optics/visiondesign)と処理側(sceneflow)は
# あったが、広視野・低解像度の複眼から運動・衝突時間・進行方向を出す**視覚処理**の
# 経路が空だった。六角格子・EMD 運動・LGMD looming・水平系読み出しを閉形式で埋める。
import flyvision  # noqa: E402  (fly optic-lobe vision pathway)
from flyvision import (  # noqa: E402,F401
    fly_hex_lattice, fly_hex_resample, fly_emd_response,
    fly_lgmd_eta, fly_tau_from_expansion,
    fly_hs_readout, fly_sky_1f, fly_dsi,
    # 2026-10-13 縞に近づくハエの眼: 周期面の解析的な標本化・エイリアスの距離・
    # 眼全体の流れからの τ・実測軌跡の τ̇・フィボナッチの眼・モアレの尖り
    fly_view_plane_texture, sampling_alias_distance, fly_expansion_readout,
    traj_tau_dot, fly_vogel_lattice, lattice_moire_peak,
)
# 統計的工程管理: マシンビジョンの計測(measure1d/shapestat/imgmetrics/blob)に
# 「工程が管理下か・能力があるか」の判定を足す。管理図・CUSUM・工程能力・多変量 T²。
import spc  # noqa: E402  (statistical process control)
from spc import (  # noqa: E402,F401
    spc_xbar_r, spc_cusum, spc_ewma, spc_capability, spc_hotelling_t2,
    spc_mt_unit_space, spc_mt_distance, spc_mt_sn_ratio,
)
import graphinv  # noqa: E402  (graph invariants of wiring matrices)
from graphinv import (  # noqa: E402,F401
    graph_degree_summary, graph_cycle3, graph_degree_preserving_null, graph_swap_symmetry,
    graph_edge_consensus, graph_strength_growth, graph_kcore, graph_rich_club_curve,
    graph_core_persistence,
)
import treemorph  # noqa: E402  (neuron trees from SWC)
import segcompare  # noqa: E402  (compare two segmentations: VOI / Rand)
from segcompare import (seg_contingency, seg_variation_of_information, seg_rand,  # noqa: E402,F401
                        seg_synapse_partners, seg_wiring_variation, seg_synapse_nri,
                        seg_wiring_exposure)
from physarum_search import (  # noqa: E402,F401
    graph_physarum_path, physarum_route, graph_physarum_transport, physarum_transport_image,
)
from carpath import car_dubins_path, car_reeds_shepp_path, car_hybrid_astar  # noqa: E402,F401
import drivecourse  # noqa: E402  (教習所コース: 規格寸法の 2-D 多角形)
from drivecourse import (  # noqa: E402,F401
    course_crank, course_s_curve, course_turnaround, course_slope, course_intersection,
    course_parallel_parking, course_crossing, course_road, course_loop_bend, course_loop, course_layout,
    course_occupancy, course_contains, polygon_area, slope_height,
)
import driveworld  # noqa: E402  (教習所の 3-D 世界: 路面・縁石・車・信号機・カメラ)
from driveworld import (  # noqa: E402,F401
    world_build, world_add, world_camera, world_bounds, set_signal_state, add_asset, add_signal, world_move,
    load_asset, place_mesh, read_obj_colored, asset_dir, camera_pose, camera_intrinsics, world_project_points,
    overlay_points, polygon_triangulate,
)
import drivettc  # noqa: E402  (τ 理論の衝突までの時間: 深度像 + 剛体運動の閉形式が真値)
from drivettc import (  # noqa: E402,F401
    camera_backproject, camera_project, relative_motion, foe_from_motion, flow_from_depth_motion, ttc_truth,
    ttc_from_flow, ttc_from_scale, ttc_from_range, label_extent, foe_from_flow,
)
import rsssafety  # noqa: E402  (RSS の安全距離: 閉形式 + 最悪ケースの積分)
from rsssafety import (  # noqa: E402,F401
    rss_params, rss_stopping_distance, rss_longitudinal_same, rss_longitudinal_opposite, rss_lateral,
    rss_longitudinal_check, rss_lateral_check, rss_worst_case_gap, rss_worst_case_gap_opposite,
    rss_worst_case_gap_lateral,
)
import lidarsim  # noqa: E402  (回転式 LiDAR をメッシュに撃つ)
import driveterrain  # noqa: E402  (閉形式の地形・路面の材質・手続きの木と歩行者: 世界は生成時に真値を持つ)
from driveterrain import (  # noqa: E402,F401
    perlin2, fbm_params, fbm_height, fbm_gradient, radial_periodogram, spectral_slope, course_distance,
    terrain_params, terrain_height, terrain_gradient, terrain_mesh, world_apply_terrain, material_params,
    world_materials, tree_mesh, pedestrian_mesh, crosswalk_mesh, add_mesh_object, scatter_offroad, mesh_signed_volume,
)
import ballistics  # noqa: E402  (球の力学: 真空の閉形式 + 抗力・マグヌスの RK4、跳ねは接触点の角運動量が保存)
from ballistics import (  # noqa: E402,F401
    ball_params, impact_params, flight_vacuum, flight_ode, flight_simulate, flight_state_at, magnus_lift_coefficient,
    drag_coefficient_sphere, bounce, contact_angular_momentum, apex_sequence, bounce_total_time, restitution_from_apexes,
    restitution_from_intervals, fit_parabola, flight_fit, fit_aero, fit_spin, fit_spin_aero, fit_bounce, slide_stop_distance, incline_slip_angle,
    mu_from_stop_distance, roll_slide_state, tether_simulate, pendulum_period, cup_catch_check,
    thrust_ode, thrust_fit, drag_fit, aic_from_rss, ballistic_vs_thrust, time_stretch_from_gravity,
)
import balltrack  # noqa: E402  (球の追跡: サブピクセル検出 → 追跡 → DLT 三角測量 → 等加速度 Kalman、模様から角速度)
from balltrack import (  # noqa: E402,F401
    ball_detect, ball_track, kalman_ca, triangulate_dlt, track_triangulate, bounce_detect, marker_direction,
    spin_from_markers, spin_from_marker_sequence, reproject,
)
import ballworld  # noqa: E402  (真値つきの台の世界: ITTF の台 + 球の模様 + カメラ、投影の真値)
from ballworld import (  # noqa: E402,F401
    table_params, table_world, ball_mesh, add_ball, ball_set_pose, rotation_from_omega, camera_rig, ball_truth, icosphere,
)
import racket  # noqa: E402  (ラケット: 動く板との衝突・狙い・打ち合い)
from racket import (  # noqa: E402,F401
    racket_params, racket_impact, racket_hit_check, aim_velocity, racket_plan, racket_move, rally_simulate,
    strategy_attacker, strategy_feeder, shot_is_legal,
)
import kendama  # noqa: E402  (けん玉: 大振幅振り子の定理・張力と弛む角・振り上げ・皿への閉ループの捕球)
from kendama import (  # noqa: E402,F401
    kendama_params, elliptic_k_agm, pendulum_period_exact, pendulum_launch_speed, pendulum_rod_simulate,
    tether_tension_fixed, tether_slack_angle, swing_up_plan, swing_up_apex, kendama_catch_check, kendama_simulate,
    catch_plan_ballistic, noisy_perceiver, catch_success_rate, catch_plan_staged, swing_up_lift, parabola_fit_g, hole_detect,
    kendama_combo_simulate,
)
import driveenv  # noqa: E402  (太陽と天気: 太陽の位置・影・逆光・霧・雨・夜の前照灯、見えてから止まれる速さ)
import driveinf  # noqa: E402  (終わらない地図: 決定的な区画・継ぎ目でつながる道・桁の落ちない座標)
import drivetraffic  # noqa: E402  (動く交通参加者と死角: IDM と癖・横ふらつき・歩行者の意図・死角・すれ違い・稀な飛び出し)
import drivedecide  # noqa: E402  (判断の場面: ミラー・確認の順序・信号の予測・緊急車両・バスの発進)
import drivelateral  # noqa: E402  (横の運動: 摩擦円・2 輪モデル・内輪差・クロソイド・位置保持の制御則・速度計画)
import drivecrossing  # noqa: E402  (踏切と交差点の優先: 警報と遮断機・余地・見通し・優先・横断歩道・駐停車禁止)
from drivecrossing import (  # noqa: E402,F401
    crossing_timing_check, crossing_gate_state, crossing_lamp_signal, lamp_pair_phase, crossing_clear_time,
    exit_room_check, crossing_stop_check, track_sight_distance, sight_triangle_distance, priority_rule,
    conflict_zone_intervals, obstruction_decel, crosswalk_overtake_check, crosswalk_stopped_vehicle_check,
    no_stopping_zones, legal_stop_intervals, parking_position_check,
)
import drivepass  # noqa: E402  (追越しと見えない所: 追越し・進路変更・環状交差点・坂の頂上・カーブミラー)
from drivepass import (  # noqa: E402,F401
    overtake_requirement, overtake_return_gap, no_overtaking_zones, overtake_permitted,
    overtaken_conduct_check, lane_change_follower_decel, lane_change_permitted, roundabout_entry_check,
    roundabout_signal_point, roundabout_signal_check, crest_sight_distance, crest_safe_speed, hill_meeting_yield,
    convex_mirror_image, convex_mirror_misjudge, mirror_image_side, mirror_road_coverage,
)
from drivelateral import (  # noqa: E402,F401
    friction_circle_usage, curve_speed_limit, design_min_radius, understeer_gradient, steady_cornering,
    bicycle_model_step, ackermann_steer_angles, offtracking_circle, rear_axle_path, fresnel_integrals,
    clothoid_points, clothoid_design, pure_pursuit_curvature, pure_pursuit_circle_offset, stanley_steer,
    stanley_straight_decay, curvature_speed_plan, lateral_offset, time_to_line_crossing, turn_maneuver_check,
)
from drivedecide import (  # noqa: E402,F401
    mirror_reflection_matrix, mirror_virtual_camera, mirror_aim_normal, convex_mirror_fov, mirror_blind_zone, check_sequence_score,
    signal_phase_plan, signal_state, predict_amber_onset, dilemma_zone, flash_frequency, aliased_frequency,
    siren_signal, doppler_shift, doppler_track, tdoa_bearing, yield_maneuver_check, bus_departure_yield_check,
)
from drivetraffic import (  # noqa: E402,F401
    idm_accel, idm_equilibrium_gap, idm_platoon_simulate, driver_style, lateral_wobble, ou_estimate,
    social_force_step, pedestrian_crossing, occlusion_reveal_distance, occlusion_visible_intervals, occlusion_safe_speed, passing_gap_required,
    passing_decision, passing_simulate, bus_stop_rate, poisson_events, poisson_events_xt, importance_risk_estimate,
)
from driveinf import (  # noqa: E402,F401
    tile_hash, tile_uniform, pose_normalize, tile_params, tile_edge_crossing, tile_roads,
    tile_road_distance, tile_height, tile_mesh, tile_digest, tile_stream, global_to_tile,
)
from driveenv import (  # noqa: E402,F401
    julian_day, sun_at, sun_events, sun_vector, sun_illuminance, koschmieder, mor_from_beta, beta_from_mor,
    road_row_distance, fog_beta_from_profile, veiling_luminance, veil_chroma_limit, sight_stop_speed, env_params, tone_map, env_render,
)
import drivelong  # noqa: E402  (車の縦の運動と坂: 停止距離の閉形式、坂道発進、技能試験の採点)
from drivelong import (  # noqa: E402,F401
    long_params, road_profile, road_eval, long_simulate, long_energy_residual, stopping_distance_grade, stop_line_plan,
    plan_command, hill_hold_brake_min, hill_start_rollback, hill_start_command, skill_test_thresholds, skill_test_score,
)
import gsplatnp  # noqa: E402  (世界 → 3D Gaussian Splatting: 面に貼ったガウシアンと EWA 描画、密度と誤差のつまみ)
from gsplatnp import gs_from_world, gs_update, gs_render, gs_render_fn, gs_read_file  # noqa: E402,F401
from gsviewer import gs_viewer_html, gs_catalog_html  # noqa: E402,F401
import motionio  # noqa: E402  (動きのデータ: BVH モーションキャプチャ・イベントカメラの x y t p、2026-10-03)
from motionio import read_bvh, read_events, events_to_frames  # noqa: E402,F401
import drivehumanoid  # noqa: E402  (運転の世界を歩くヒューマノイド: 間引いたメッシュ + マスク付きの事前描画、2026-10-03)
from drivehumanoid import (  # noqa: E402,F401
    humanoid_walk_clip, humanoid_clip_mesh, world_pose_humanoid, humanoid_impostors, world_camera_impostors)
import pegsim  # noqa: E402  (柔らかい手首のペグ挿入: MuJoCo の場面・手首カメラ・接触状態・ルールベースの挿入。台帳は opsdrive "pegsim")
from pegsim import (  # noqa: E402,F401
    peg_scene_build, peg_set_pose, peg_wrist_render, peg_scene_close, peg_contact_state, peg_two_point_depth_sim, peg_depth_sample_offset, peg_insertion_run, peg_insertion_grid,
)
import puck  # noqa: E402  (エアホッケーのパック追跡・予測・打ち返し: 閉形式と外部シムの台で、学習なし。台帳は opsdrive "puck")
from puck import (  # noqa: E402,F401
    puck_challenge_mjcf, puck_mujoco_run,
)
import pegfail  # noqa: E402  (ペグ挿入の失敗検出と回復: 規則の分類表 × 接触計測、真値は Whitney と MuJoCo。台帳は opsdrive "pegfail")
from pegfail import (  # noqa: E402,F401
    pegfail_scene_build, pegfail_episode_run, pegfail_failure_grid,
)
import granular  # noqa: E402  (粉体の山を画像で測る: 安息角・体積・質量・流動性・排出率、真値は閉形式・公表値・MuJoCo。台帳は opsdrive "granular")
from granular import (  # noqa: E402,F401
    heap_mujoco_pour, heap_mujoco_discharge,
)
import pegtactile  # noqa: E402  (ペグ挿入を 2 本指の膜で読む: 接触レンチ → Whitney の状態・μ・手首剛性。台帳は opsdrive "pegtactile")
from pegtactile import (  # noqa: E402,F401
    pegtactile_episode_run, pegtactile_prefetch, pegtactile_process_episode, pegtactile_cutaway_xml,
)
import cutting  # noqa: E402  (食材の切断を画像で測る: 刃・厚み・粗さ・手首の力、真値は Atkins の閉形式と MuJoCo。台帳は opsdrive "cutting")
from cutting import (  # noqa: E402,F401
    cutting_mujoco_wrist,
)
import diabolo  # noqa: E402  (ディアボロの解析模型と視覚: 原文から写して直した模型を閉形式・厳密な糸・MuJoCo で確かめ、合成映像から軸・回転・張力。台帳は opsdrive "diabolo")
from diabolo import (  # noqa: E402,F401
    diabolo_mujoco_simulate,
)
import pegsym  # noqa: E402  (ペグの対称性で回転の探索を 1/n に絞る: 角・六角・キー付きペグの MuJoCo 挿入。台帳は opsdrive "pegsym")
from pegsym import (  # noqa: E402,F401
    pegsym_scene_build, pegsym_views, pegsym_insert_try, pegsym_search_run, pegsym_two_point_depth_sim, pegsym_scene_close,
)
import polish  # noqa: E402  (研削・研磨・拭き取りを画像で測る: MuJoCo で工具を手首のばねで押して動かす。台帳は opsdrive "polish")
from polish import polish_scene_build, polish_scene_close, polish_stroke_run  # noqa: E402,F401
import scoop  # noqa: E402  (粉体のすくいと注ぎを画像で測る: すくった量と注ぎの流量、真値は閉形式・Boolean 模型・MuJoCo。台帳は opsdrive "scoop")
from scoop import (  # noqa: E402,F401
    scoop_mujoco_fill, scoop_mujoco_pour,
)
import kendamaworld  # noqa: E402  (けんの真値つき世界: けん + 大皿 + 糸のメッシュ、カメラの組、皿の投影の真値)
from kendamaworld import (  # noqa: E402,F401
    ken_mesh, add_ken, ken_set_pose, string_mesh, add_string, string_set, kendama_world, kendama_rig, ken_truth,
    kendama_pose, kendama_clearance, camera_perceiver,
)
import roadjp  # noqa: E402  (日本の信号灯器と道路標識: 公表寸法をそのまま頂点に持つメッシュ、driveworld の世界に足す)
from roadjp import (  # noqa: E402,F401
    sign_params, sign_image, plate_mesh_from_image, sign_mesh, add_sign, signal_jp_mesh, add_signal_jp,
)
from lidarsim import (  # noqa: E402,F401
    lidar_spec, lidar_scan, lidar_points_sensor_frame, lidar_range_image_to_points, ray_plane_range,
    ray_box_ranges,
)
from treemorph import tree_from_swc, tree_morphometry, tree_sholl  # noqa: E402,F401
import textregion  # noqa: E402  (where is the text, without a recogniser)
import vxcore  # noqa: E402  (OpenVX 1.3.1 primitive ports: gradients, LUT, histogram, NMS)
from textregion import swt_map, text_candidates, text_lines  # noqa: E402,F401
import residue  # noqa: E402  (values known modulo several periods -> Chinese remainder theorem)
import doe  # noqa: E402  (design of experiments: LHS, orthogonal arrays, fractions, CCD, Box-Behnken)
import multivar  # noqa: E402  (table PCA / PLS / response surfaces / main effects / image feature tables)
import sensitivity  # noqa: E402  (Morris / Sobol sensitivity, collinearity index, residual PCA)
import simcal  # noqa: E402  (sim-to-real calibration: forward model, observation, screening, refusing fit)
import simcalcheck  # noqa: E402  (sim-to-real checks: profile likelihood, uncertainty, over-fitting gates, discrepancy)
import converge  # noqa: E402  (convergent computation: fixed-point driver, observed order / GCI, sequential Monte Carlo)
import mcphoton  # noqa: E402  (Monte Carlo photon transport in layered turbid slabs, MCML rules, with intervals)
import deconvstop  # noqa: E402  (Richardson-Lucy stopped by the discrepancy principle)
import codematch  # noqa: E402  (robust code matching: orientation code, increment sign, selective correlation, radial reach)
from residue import (  # noqa: E402,F401
    residue_integer_crt, residue_crt, residue_fault_locate, crt_displacement, harmonic_rotation,
)
# 画像 → CAD 面の**逆写像**: 既存の align_cad_to_scan / ICP / ppf は「姿勢は出す」
# が、2-D 画像上で見つけた欠陥が CAD 面のどの座標かに落とす経路が空だった。
# 姿勢は**既知として受け取る**側で、一度も推定しない(推定は pipeline3d /
# registration / ppf の仕事)。render3d.render_mesh がラスタライザ(全画素の
# depth 画像)なのに対し、こちらは**任意の画素だけを問い合わせる**逆向きで、
# face_id と重心座標を返す。
import cadmap  # noqa: E402  (defect pixel -> CAD surface inverse mapping)
from cadmap import (  # noqa: E402,F401
    cad_pixel_to_surface, cad_surface_to_pixel, cad_defect_to_cad,
    cad_visible_faces,
)
# 断層撮影。CT ボリュームを**扱う** op は多数あったのに、**投影から作る**側が
# 完全に空だった(radon / サイノグラム / FBP / 反復再構成がゼロ)。閉形式の真値
# (円板の弦長 2√(r²−s²)、楕円の解析 Radon 変換)で検証してある。
# 図の配色を「役割」で決める層。図ごとに作者が色を選ぶと同じ意味に違う色が付く
# (実際この repo でも「赤=誤り/緑=正しい」と青-黒-橙が同居していた)。既定の
# Okabe-Ito は**赤と緑を対にしない** ― 赤緑の対は色覚特性によっては情報量ゼロ。
import palette  # noqa: E402  (semantic colour roles for figures)
from palette import (  # noqa: E402,F401
    semantic_palette, role_color, role_rgb8, diverging_lut,
    assert_not_red_green_pair, ROLES, ROLE_MARKERS, SCHEMES,
)
# 図注(figure annotation)の層。描画は imagedraw の 5 op(線・円・マーカー)
# しか無く、**図に意味を載せる側**が空だった ― その穴を、図の生成器 6 本が各自の
# 私的ヘルパーで埋めていた(実測の重複: _font 16 / _text 7 / _fill 5 / _legend 2)。
# 文字は必ず幅を測ってから描き、収まらなければ黙って切らずに例外にする。
# 2 枚の絵の差を測る層。op カタログ全文の実測(2026-09-02)で ssim / psnr /
# mutual_information / delta_e が **一件も無かった** ― 変換する op は数百あるのに、
# その出力が入力とどれだけ違うかを言う op が無く、進化の目的関数も図注も
# その場限りの平均二乗誤差を毎回書き直していた。この族は **答え合わせが外から
# できる**のが特徴(CIEDE2000 は公開検証表 34 組と一致、SSIM は独立実装と差 0.0)。
# ``data_range`` を推測しないのが中心的な設計判断 ― [0,1] を 255 と取り違えると
# PSNR が 48.13 dB ずれるが例外は出ない。
# sRGB の伝達関数は gfx2d が実体なので、ここでは再輸出しない(重複を作らない)。
import imgmetrics  # noqa: E402  (SSIM / PSNR / CIEDE2000 / mutual information / NCD)
import opsimgmetrics  # noqa: E402  (the image-metrics op ledger)
from imgmetrics import (  # noqa: E402,F401
    rgb_to_lab, lab_to_rgb, rgb_to_xyz, xyz_to_lab,
    delta_e_2000, delta_e_76, delta_e_map,
    mse, rmse, psnr, ssim, ssim_map, ms_ssim,
    joint_histogram, image_entropy, joint_entropy,
    mutual_information, normalized_mutual_information,
    compressed_size, ncd, compare_images, data_range_of, measure_with, metrics_table,
    D65_WHITE, MS_SSIM_WEIGHTS, CIEDE2000_TEST_PAIRS,
)
# 分布を運ぶ層。imgmetrics が「どれだけ違うかを測る」側なら、こちらは「相手に
# 合わせる」側で、測る op と直す op が対になる。ここも検算できるのが特徴 ―
# 1 次元の最適輸送は総当たりの割当解と差 0.00e+00、Poisson 合成は「内部の
# ラプラシアンが元と一致(1.78e-15)・マスク外は貼り先と厳密一致」という
# 構成上の不変量を出力だけから確かめられる。
import colortransport  # noqa: E402  (optimal transport / colour transfer / Poisson blending)
import opscolortransport  # noqa: E402  (the colour-transport op ledger)
from colortransport import (  # noqa: E402,F401
    wasserstein_1d, transport_plan_1d, histogram_match, color_transfer,
    sinkhorn, sinkhorn_distance, sinkhorn_divergence, transport_cost,
    apply_transport, gaussian_transport_map, poisson_blend,
    COLOR_TRANSFER_METHODS,
)
# 画像フォレンジック層。カタログ全文の実測(2026-09-02)で prnu / ela / copy_move /
# jpeg_ghost / phash / watermark が **一件も無かった**。この族は「改竄側を自分で
# 作れるので正解が手元にある」のが強み(defectgen と自前合成)。どの op も
# 「加工されている」と**断定しない** ― 証拠量と、その証拠が何を意味しないかを返す。
import imgforensics  # noqa: E402  (perceptual hashing, PRNU, ELA, copy-move, watermarking)
import opsimgforensics  # noqa: E402  (the forensics op ledger)
from imgforensics import (  # noqa: E402,F401
    perceptual_hash, hash_distance, sensor_fingerprint, fingerprint_correlate,
    fingerprint_strength_map, error_level_map, jpeg_quality_estimate,
    jpeg_ghost_map, jpeg_ghost_quality, noise_inconsistency_map,
    copy_move_regions, watermark_embed, watermark_extract, watermark_capacity,
    null_distribution, evidence_quantile,
)
# 天体写真スタッキング層。カタログ全文の実測(2026-09-02)で lucky / drizzle /
# sigma_clip / cosmic_ray / astrometr が **一件も無かった**。photoncount(ショット
# ノイズ)・optics(PSF/MTF)・mosaic(RANSAC)・fit_transform(当てはめ)を
# import して合成し、Poisson 標本化も RANSAC も Umeyama も再実装していない。
# この族は検算できるのが取り柄 —— drizzle の総フラックス保存は倍精度の丸め
# (最大 6.3e-15)、開口測光は半径 8σ で誤差 0.0000 %、そして κ-σ 合成は
# **ちょうど 50 % の汚染で壊れる**(理論どおり。壊れる側もテストに残してある)。
import astrostack  # noqa: E402  (lucky imaging, sigma-clip stacking, drizzle, photometry)
import opsastrostack  # noqa: E402  (the astro-stacking op ledger)
from astrostack import (  # noqa: E402,F401
    synth_starfield, synth_frame_series, frame_quality, lucky_select, noise_sigma,
    sigma_clip_stack, drizzle_resample, cosmic_ray_reject, cosmic_ray_reject_stack,
    star_detect, psf_fit, aperture_photometry, frame_align, align_frames,
    STACK_MODES, PSF_MODELS, ALIGN_MODELS, NOISE_METHODS,
)
# 契約層 —— 人が呼ぶ経路(fail-closed)と自動で回す経路(Attempt)を分ける。
# システムパラメータは contextvars 実装で、**厳しくする方向にしか動かせない**。
import metriccontract  # noqa: E402  (strict vs tolerant measurement contracts)
import fssystem  # noqa: E402  (set_system / get_system, contextvar-scoped)
# BLAS のスレッド上限。**fssystem の表には載せられない** —— あの表は
# 「厳しくする方向のみ」か「数値に影響しない」パラメータ専用で、スレッド数は
# 下位ビットを動かすため。理由と実測は fsthreads の docstring。
import fsthreads  # noqa: E402  (BLAS thread caps around decompositions)
from metriccontract import (  # noqa: E402,F401
    MetricContractError, Attempt, attempt, attempt_all,
    DIRECTIONS, worst_case, value_or_worst, best_of, rank_attempts,
)
from fssystem import (  # noqa: E402,F401
    set_system, get_system, query_system, system, reset_system, system_snapshot,
)
from fsthreads import blas_threads  # noqa: E402,F401
import glyphops  # noqa: E402  (glyph verification: is this cell the character I asked for?)
from glyphops import (  # noqa: E402,F401
    # ★名前はすべて glyph_ で始める。1-D / 2-D / 3-D でレジストリが分かれている
    #   repo なので、接頭辞の無い名前は公開経路ごとに別物を指す事故を起こす。
    available_fonts as glyph_fonts,
    render_glyph as glyph_render,
    render_text as glyph_render_text,
    normalise_glyph as glyph_normalise,
    skeleton_chamfer as glyph_skeleton_chamfer,
    glyph_distance,
    typeface_noise_floor as glyph_typeface_noise_floor,
    ink_colors as glyph_ink_colors,
    stroke_thickness as glyph_stroke_thickness,
    match_stroke_weight as glyph_match_stroke_weight,
    edge_transition_width as glyph_edge_transition_width,
    replace_glyph as glyph_replace,
    rendering_noise_floor as glyph_rendering_noise_floor,
    split_cells as glyph_split_cells,
    # ★JSON 一枚で受ける入口。op ではなく API 層の関数(レジストリの op は
    #   (画像, a, b) 固定でノブ 2 つなので、文字列も JSON も渡せない)。
    correct_spec as glyph_correct_spec,
    find_plate as glyph_find_plate,
    rewrite_line as glyph_rewrite_line,
    find_text_lines as glyph_find_text_lines,
    make_spec as glyph_make_spec,
)
import annotate  # noqa: E402  (text plates, arrows, legends, colour bars, axes)
import opsannotate  # noqa: E402  (the annotate op ledger)
from annotate import (  # noqa: E402,F401
    measure_text, text_box, arrow, leader_line, label_points, crosshair,
    legend_box, color_bar, scale_bar,
    axes_transform, data_to_pixel, nice_ticks, axes_frame, grid_lines, ticks,
    plot_series, overlay_labels, zoom_inset, compare_frame, panel_grid,
    rounded_rect, filled_polygon, arc, ellipse,
    # 学術図の作法(2026-09-03): 引き出し線・番号/凡例・寸法・角度・スケールバー・
    # 方位・隅の拡大・輪郭・経路文字・色分け・パネル文字・図の組版(+ *_layout)
    annotate_leader_layout, annotate_leader, annotate_markers, annotate_legend,
    annotate_dimension_layout, annotate_dimension, annotate_angle_layout,
    annotate_angle, annotate_scale_bar_layout, annotate_scale_bar,
    annotate_orientation, annotate_inset_layout, annotate_inset,
    annotate_outline_layout, annotate_outline, annotate_text_path_layout,
    annotate_text_path, annotate_table_layout, annotate_table,
    annotate_invert_visibility, annotate_invert,
    annotate_invert_path, annotate_colorbar, annotate_panel_label,
    annotate_figure_grid_layout, annotate_figure_grid,
)
import meshres  # noqa: E402  (resolution management: measure coarse/dense, remesh, audited reductions)
from meshres import (  # noqa: E402,F401
    mesh_edge_stats, mesh_detail_map, mesh_split_long_edges, mesh_isotropic_remesh,
    mesh_sample_points, mesh_lod_chain, mesh_select_lod, mesh_reduction_report,
    mesh_decimate_preserving, pc_density, pc_poisson_disk, pc_fill_sparse,
    pc_density_equalize, pc_lod_chain, pc_thinning_report,
)
import videostream  # noqa: E402  (frame-by-frame video: ring buffer, stateful ops, VideoPipeline)
import opsvideostream  # noqa: E402  (the streaming-video op ledger)
from videostream import (  # noqa: E402,F401
    FrameRing, StatefulOp, TemporalMedianWindow, MovingAverageWindow,
    BackgroundSubtractionWindow, FrameDifference, ExponentialBackground, RunningStats,
    OpticalFlowStream, VideoPipeline, stream_replay,
    MotionHistoryImage, ThreeFrameDifference, RunningGaussianForeground,
    TemporalBilateral, Deflicker, SceneCutDetection,
    temporal_median_window, moving_average_window, background_subtraction_window,
    frame_difference_causal, exponential_background, exponential_foreground,
    running_mean_std, optical_flow_magnitude_stream,
    motion_history_image, motion_energy_image, three_frame_difference,
    running_gaussian_foreground, running_gaussian_background,
    temporal_bilateral, deflicker, scene_cut_detection,
)
import annotate3d  # noqa: E402  (3-D anchors -> projected arrows / labels / scale bars)
from annotate3d import (  # noqa: E402,F401
    annotate3d_project, annotate3d_arrow, annotate3d_label, annotate3d_scale_bar,
    annotate3d_axes, annotate3d_bbox, annotate3d_measure, project_anchors,
)
# ★ ``annotate.overlay_mask`` は **意図的にトップレベルへ出していない**。同名の
# ``imgio.overlay_mask`` が既に ``fs.overlay_mask`` として公開されており、引数も
# 意味も違う(imgio = 生 RGB・mask>0.5・fill/margin / annotate = 役割名の色・
# 重み [0,1] も可・形の不一致を拒否)。同じ名前に別の約束を載せると、呼び手は
# 例外ではなく**もっともらしく違う絵**を受け取る。公開 API の破壊的変更は
# 独断でしないので、役割つきの方は ``fs.annotate.overlay_mask`` で引く。

# 描画を **ためてから一度に流す** 層。即時描画は呼んだ瞬間に絵になるので、そこから先は
# 検査できない ― 文字がはみ出したかどうかは、ラスタ化後の画素からは判定できない。
# コマンドの列で持てば、描く前に箱を測れて、列は JSON になるので図の差分が
# 「3 番目の text_box の文字列が変わった」まで言え、同じ列を別解像度へも流せる。
import drawlist  # noqa: E402  (deferred draw-command list: inspect / diff / rescale)
from drawlist import (  # noqa: E402,F401
    DrawList, DrawListError, diff_command_lists, format_diff, flush_buffer,
    default_text_metrics, measured_text_metrics, COMMAND_SPECS, TEXT_ADVANCE_RATIO,
)
# 描画状態(色・線幅・線種・塗り)と、ラスタ描画。HALCON は装置に状態を持たせる
# (set_color / set_draw / set_line_width / set_line_style)が、ここは**不変値**の
# DrawStyle を正典にした ― 展示画像は再生成で SHA-256 が一致することが要件で、
# 可変グローバルがあると「前に描いた図の設定」が混ざり、例外にならずに図だけが
# 変わる。HALCON 名は相互運用の別名として残し、値を返す関数にしてある。
import drawstyle  # noqa: E402  (immutable draw state: colour / width / line style / fill)
from drawstyle import (  # noqa: E402,F401
    DrawStyle, draw_style, current_style, set_color, set_line_width,
    set_line_style, set_draw, resolve_pattern, resolve_color,
    LINE_STYLES, DRAW_MODES,
)
import imagedraw  # noqa: E402  (raster annotation: lines / markers / circles / contours)
from imagedraw import (  # noqa: E402,F401
    draw_line, draw_polyline, draw_circle, draw_markers, draw_contour, new_canvas,
)
import tomography  # noqa: E402  (radon / FBP / SART / artifacts / CT-to-voxel)
from tomography import (  # noqa: E402,F401
    projection_angles, sinogram_design, ellipse_phantom, ellipse_sinogram,
    radon_transform, backproject_sinogram, filtered_backprojection,
    sart_reconstruct, beam_hardening_apply, beam_hardening_correct,
    ring_artifact_apply, ring_artifact_remove, metal_trace_interpolate,
    sinogram_center_of_rotation, sinogram_center_shift,
    radon_volume, fbp_volume,
)
import ctscan  # noqa: E402  (cone / helical / laminography / fan scans on one geometry)
from ctscan import (  # noqa: E402,F401
    ct_scan_geometry, shepp_logan_3d, ellipsoid_phantom, ellipsoid_projections,
    ct_forward_project, ct_adjoint_project, fdk_reconstruct, sirt_reconstruct,
    os_sart_reconstruct, tv_reconstruct, ct_dual_energy_reconstruct,
)
import tomography_gpu  # noqa: E402  (the shared CT kernels and the GPU routes)
# 3-D ラベルの色分け。2-D の colorize_labels しか無かったので、ボリュームを
# 断面ごとに着色すると**同じ部品の色が断面ごとに変わる**(断面ごとにラベル番号が
# 振り直されるため。実測: 13 成分中 11 が 32 か所で色が変わる)。ボリュームで
# 着色してから切れば 0 ―― 色は「見た目」ではなく部品の同一性を運ぶので分けた。
import volcolor  # noqa: E402  (3-D label colouring, selection, legend)
from volcolor import (  # noqa: E402,F401
    vol_colorize_labels, vol_label_color_flicker, vol_label_legend,
    vol_label_mpr_rgb, vol_label_overlay, vol_label_palette,
    vol_label_shape_stats, vol_label_slice_rgb, vol_label_volume_render,
    vol_labels_to_meshes, vol_select_labels,
)
import acoustics  # noqa: E402  (STFT / bearing envelope / order tracking / sound level)
from acoustics import (  # noqa: E402,F401
    angular_resample, apply_weighting, bearing_defect_frequencies,
    cepstrum, coherence, envelope_spectrum, equivalent_level, istft,
    octave_bands, octave_spectrum, order_spectrum, percentile_level,
    spectral_kurtosis, stft, stft_cola_check, synthesize_bearing_signal,
    synthesize_speed_ramp, transfer_function, weighting_response,
)
import rangedoppler  # noqa: E402  (FMCW range-Doppler / delay-and-sum beamforming)
from rangedoppler import (  # noqa: E402,F401
    beamform_delay_sum, beamform_doa, fmcw_beat_simulate, fmcw_design,
    fmcw_range_profile, fmcw_window_apply, range_doppler_map,
    range_doppler_peaks,
)
import quatimage  # noqa: E402  (quaternion images / Riesz + monogenic signal)
from quatimage import (  # noqa: E402,F401
    iqft2, monogenic_amplitude, monogenic_metrics, monogenic_orientation, monogenic_phase,
    monogenic_signal, qft2, quat_color_filter, quat_color_rotate,
    quat_conjugate_image, quat_correlate, quat_image_multiply, quat_norm,
    quat_normalize_image, quaternion_to_rgb, rgb_to_quaternion,
    riesz_displacement, riesz_displacement_series, riesz_motion_magnify,
    riesz_transform,
)

# Public helpers introduced by the performance batches.  Keep them reachable
# through the same stable facade as the operators they prepare or accelerate.
from acquire import unpack_lsb  # noqa: E402,F401
from curvature3d import curvature_descriptors  # noqa: E402,F401
from pivops import piv_outlier_mask_stream  # noqa: E402,F401
from sdf_ops import grid_axes  # noqa: E402,F401
import motionmag  # noqa: E402  (phase-based motion magnification / vibration measurement)
from motionmag import (  # noqa: E402,F401
    band_snr, complex_steerable_decompose, complex_steerable_reconstruct,
    displacement_series, motion_magnify, phase_displacement,
    synthesize_translation, temporal_band_power, temporal_bandpass,
)
import gfx2d  # noqa: E402  (real-time 2-D graphics: compositing / sprites / tiles / particles / lighting / post)
from gfx2d import (  # noqa: E402,F401
    alpha_composite, alpha_composite_premul, blend_mode, bloom,
    chromatic_aberration, color_grade, color_lut, dither, film_grain,
    layer_stack, light_mask, linear_to_srgb, nine_slice, normal_map_decode,
    normal_map_shade, palette_quantize, parallax_layers, particle_emit,
    particle_render, particle_step, premultiply, radial_light, shadow_cast_2d,
    sprite_blit, sprite_sheet_slice, sprite_synthesize, sprite_transform,
    srgb_to_linear, tilemap_render, unpremultiply, vignette, viewport,
    BLEND_MODES,
    raw_black_level, raw_dead_pixel_mask, raw_dead_pixel_correct, lens_shading_gain, lens_shading_correct, awb_gains,
    rgb_apply_gains, raw_apply_gains, raw_demosaic_bilinear, color_correction_matrix, hue_saturation, brightness_contrast, BAYER_PATTERNS,
)
from specularity import (  # noqa: E402,F401
    specular_diffuse_split, specular_free_transform,
    specular_coefficient_map, illuminant_from_dichromatic_planes,
    brdf_blinn_phong, brdf_microfacet, dichromatic_render,
    photometric_stereo_robust, photometric_residual, polarization_render,
    polarization_separate, polarization_dolp_map, polarization_stokes,
    polarization_analyze, polarization_stokes_map,
)
from optics import (  # noqa: E402,F401
    thin_lens, abcd_matrix, abcd_trace, depth_of_field, relative_illumination,
    airy_pattern, angular_spectrum_propagate, fraunhofer_pattern, gaussian_beam,
    fourier_plane_filter, four_f_filter,
    defocus_from_shift, pupil_psf, pupil_blur,
    psf_to_mtf, mtf_diffraction, wavefront_stats,
    encircled_energy, ensquared_energy, energy_radii, mtf_tangential_sagittal,
    jones_element, jones_apply, stokes_from_jones,
    mueller_element, mueller_apply, stokes_analyze, mueller_partial_polarizer,
    polarization_demosaic, polarization_demosaic_color, mueller_from_intensities, mueller_checks,
    POLARIZATION_MOSAIC_LAYOUT, POLARIZATION_SWEEP_ANGLES,
)
from raytrace import (  # noqa: E402,F401  (lens design: real rays beyond the paraxial optics module)
    lens_system, thick_lens, glass, refractive_index, example_system,
    paraxial_trace, trace_rays, ray_bundle, spot_diagram, spot_stats, ray_fan,
    opd_map, opd_samples, wavefront_from_opd, seidel_coefficients,
    tolerance_analysis, glass_catalog, sellmeier, chromatic_shift, chief_ray,
    with_wavelength, with_aiming, ray_aiming, set_vignetting,
)
import lenstol  # noqa: E402  (manufacturing tolerances, compensation, and yield)
from lenstol import (  # noqa: E402,F401
    tolerance_table, tolerance_criteria, tolerance_compensators, tolerance_monte_carlo,
    tolerance_sensitivity, tolerance_report, tolerance_table_zmx, tolerance_table_from_zmx,
)
import photoelastic  # noqa: E402  (photoelasticity: stress fields, stress-optic law, polariscope images)
from photoelastic import (  # noqa: E402,F401
    brazilian_disc_stress, kirsch_plate_stress, principal_stress, retardation_from_birefringence,
    photoelastic_retardation, retardation_convert, cubic_photoelastic_birefringence,
    silicon_piezo_optic_coefficients, polariscope_intensity, photoelastic_polarization_images,
    photoelastic_phase_estimate, retardation_unwrap_multiwavelength,
)
import lensopt  # noqa: E402  (damped-least-squares lens optimisation)
from lensopt import optimize_lens, merit_function, bend_singlet  # noqa: E402,F401
import sensorchar  # noqa: E402  (EMVA 1288 camera characterisation)
from sensorchar import (  # noqa: E402,F401
    emva_pair_statistics, emva_photon_transfer, emva_quantum_efficiency, emva_linearity_error, emva_snr_curve, emva_sensitivity_threshold, emva_dynamic_range, emva_dark_current, emva_spatial_nonuniformity, emva_defect_pixels,
    emva_highpass, emva_spectrogram, emva_total_snr, emva_exposure_for_snr, emva_photon_exposure, emva_bspline_regression, emva_ptc_linearity_check, emva_noise_whiteness, emva_filter_distortion,
)
import sensorgeneral  # noqa: E402  (EMVA 1288 Release 4.0 General: non-linear cameras)
from sensorgeneral import emva_general_sensitivity, emva_general_nonuniformity, emva_general_relative_qe  # noqa: E402,F401
import edgesfr  # noqa: E402  (slanted-edge SFR / MTF50 / veiling glare index from photographs)
from edgesfr import edge_spread, sfr_from_edge, mtf50, veiling_glare_index  # noqa: E402,F401
import illumdesign  # noqa: E402  (machine-vision illumination design)
from illumdesign import (  # noqa: E402,F401
    light_source, irradiance_map, illumination_uniformity, defect_contrast,
    lighting_sweep, illumination_design,
    solid_angle_light, solid_angle_boundaries, solid_angle_brightness, solid_angle_sweep, solid_angle_render,
    illumination_train, illumination_field, coaxial_illumination,
)
import lensimage  # noqa: E402  (image formation through a designed lens + synthetic defect datasets)
from lensimage import (  # noqa: E402,F401
    psf_from_opd, psf_field_grid, through_focus_mtf, distortion_map, render_through_lens, defect_dataset,
    calibration_views,
)
# ★2026-10-02: 「名前の無い非公開関数」の棚卸しで、op として振る舞うのに公開経路が 1 本も無かった 18 本。
#   どれも既存の型つき台帳の約束(台帳 = 実装モジュールの集合)に合わないので、facade(fs.<名前>)から出す。
#   門は tests/test_hidden_ops_exposed_2026_10_02.py(定理か第 2 実装)。
from accel_match import ncc_map_3d  # noqa: E402,F401  (3-D 正規化相互相関マップ)
from backend_safe import gradient_normals, subpixel_refine_edges  # noqa: E402,F401
from filters_arith import min_max_gray_n  # noqa: E402,F401
from filters_flow import gen_gauss_bandpass, apply_bandpass  # noqa: E402,F401
from gsplat_sugar import gaussians_to_mesh  # noqa: E402,F401  (open3d は呼んだときだけ要る)
from imgio import ensure_gray, ensure_color  # noqa: E402,F401
from morph_minkowski import dilation2  # noqa: E402,F401
from objmodel3d import get_bounding_box_object_model_3d  # noqa: E402,F401
from photometric import normals_to_gradients, integrate_gradients  # noqa: E402,F401
from reconstruction import triangulate_points, rel_pose_to_essential_matrix  # noqa: E402,F401
from shapematch import pyr_down, image_pyramid  # noqa: E402,F401
from symmetry3d import rotational_symmetry_score  # noqa: E402,F401
from symmetry2d import (  # noqa: E402,F401
    center_from_symmetric_edges, reflection_axis, rotational_symmetry,
    symmetry_difference_map, symmetry_score,
)

__all__ = [
    "orient2d", "orient3d", "incircle", "insphere",
    "orient2d_exact", "orient3d_exact", "incircle_exact", "insphere_exact",
    "point_in_polygon", "point_in_convex_polygon", "is_convex_polygon",
    "point_in_tetrahedron", "point_in_convex_polytope",
    "is_delaunay_2d", "mesh_orientation_consistent",
    "PrecisionUnion",
    "apply", "run_pipeline", "find_op", "list_ops", "op_names",
    "categories", "read_image", "write_image", "RT", "REGISTRY", "version",
    "stereo", "disparity_map", "disparity_subpixel", "lr_consistency",
    "depth_from_disparity", "reproject_to_points",
    "census_transform", "disparity_census", "disparity_sgm",
    "speckle_filter", "fill_disparity", "disparity_confidence",
    "terrain", "elevation_map", "traversability", "foothold_score", "fill_gaps",
    "ground_surface", "ground_plane", "detect_obstacles",
    "fuse_elevation", "slope_map", "roughness_map", "surface_normals",
    "step_edges", "foothold_candidates",
    "locomotion", "contact_points", "com_from_silhouette", "support_polygon",
    "com_support_margin", "gait_phase",
    "occupancy", "occupancy_grid_2d", "inflate_obstacles", "clearance_map",
    "line_of_sight", "frontier_cells",
    "imgio", "to_float01", "to_uint8", "apply_cmap", "colorize_depth",
    "colorize_disparity", "colorize_labels", "colorize_height", "colorize_flow",
    "shaded_relief", "overlay_mask", "save", "load", "save_ply", "COLORMAPS",
    "colorize_categorical", "colorize_bivariate", "colorize_significance",
    "NORMS", "QUALITATIVE", "PERCEPTUAL_SAFE", "CVD_SAFE", "CYCLIC",
    "detect", "segment_objects", "object_descriptor", "nearest_prototype", "draw_objects",
    "registration", "kabsch", "icp", "point_to_plane_icp", "apply_transform",
    "icp_gated", "point_to_plane_icp_gated",
    "ncc_map_partial", "ncc_locate_ex", "shape_locate_fine",
    "pca_align", "register", "feature_register",
    "ppf", "ppf_model", "surface_match", "find_surface_pose",
    "pointcloud", "estimate_normals", "voxel_downsample",
    "remove_statistical_outliers", "remove_radius_outliers", "fpfh",
    "pcseg", "fit_plane", "fit_plane_ransac", "fit_sphere_ransac", "fit_cylinder_ransac",
    "plane_distance", "height_above_plane", "remove_ground",
    "euclidean_clusters", "region_growing", "aabb", "obb", "crop_box", "crop_sphere",
    "farthest_point_sampling", "curvature", "centroid", "principal_axes",
    "pocviewer", "write_viewer", "viewer_spec", "viewer_text", "viewer_number", "viewer_mesh_tab",
    "viewer_points_tab", "viewer_frames_tab", "viewer_split_tab", "viewer_anim3d_tab",
    "viewer_export_strings", "viewer_motion_gate", "viewer_motion_gate_data", "viewer_quality_gate_data",
    "mesh", "read_mesh", "read_points", "write_mesh", "write_points", "sample_surface",
    "fileio", "table_write_csv", "table_read_csv",
    "mesh_write_ply", "mesh_read_ply", "mesh_write_stl", "mesh_read_stl",
    "mesh_write_obj", "mesh_read_obj", "mesh_write_off", "mesh_read_off",
    "points_write_xyz", "points_read_xyz",
    "e57_write", "e57_read",
    "archive_probe", "archive_list", "archive_extract", "archive_create",
    "astro_fits_write", "astro_fits_read",
    "em_mrc_write", "em_mrc_read",
    "nrrd_write", "nrrd_read",
    "nifti_write", "nifti_read",
    "ome_tiff_write", "ome_tiff_read",
    "mesh_to_points", "voxelize", "bounds", "recenter", "normalize_scale",
    "meshio_opt", "read_gltf", "read_gltf_merged", "read_las", "read_pcd", "formats_available",
    "volio", "read_volume", "write_volume", "list_dicom_series", "VolumeMeta",
    "raster", "read_raster", "to01", "read_depth", "read_pfm", "write_pfm", "save16",
    "render3d", "render_mesh", "look_at", "intrinsics_from_fov", "auto_view",
    "mesh_to_sdf", "voxelize_solid", "marching_cubes",
    "camera", "intrinsic_matrix", "decompose_intrinsics", "projection_matrix",
    "project_points", "backproject", "depth_to_points", "normals_from_depth",
    "normals_from_depth_edgeaware",
    "triangulate", "reprojection_error", "solve_pnp", "rodrigues", "rotation_log",
    "fundamental_matrix", "essential_matrix", "essential_from_fundamental",
    "decompose_essential", "recover_pose", "epipolar_lines",
    "distort_points", "undistort_points", "distort_image", "undistort_image", "estimate_distortion", "stereo_rectify", "camera_calibration",
    "odometry", "rgbd_odometry", "pnp_odometry", "integrate_trajectory",
    "umeyama_align", "trajectory_error",
    "grasp", "Grasp", "sample_antipodal_grasps", "grasps_from_mesh", "force_closure",
    "ferrari_canny_quality", "approach_vector_from_normals", "rank_grasps",
    "grasp_pose", "collision_free",
    "meshrepair", "is_watertight", "is_edge_manifold", "boundary_edges", "weld_vertices",
    "remove_degenerate_faces", "orient_consistent", "fill_holes", "smooth_taubin",
    "decimate_qem", "convex_hull", "inertia_tensor", "components",
    "volops", "vol_frangi", "vol_sato", "vol_hessian_blobness", "vol_distance_transform",
    "vol_label", "vol_region_props", "vol_gradient_magnitude", "vol_local_maxima", "vol_watershed",
    "vol_reduce_domain", "vol_bounding_box", "vol_crop_domain", "vol_uncrop",
    "vol_boundary", "vol_boundary_points", "vol_tiled_map",
    "vol_local_std", "vol_local_thickness", "vol_euler_number",
    "vol_granulometry", "vol_orientation_coherence",
    "volregion", "VolRLE", "vol_rle_encode", "vol_rle_decode", "vol_rle_volume",
    "vol_rle_bbox", "vol_rle_centroid", "vol_rle_union", "vol_rle_intersect",
    "vol_rle_difference", "vol_rle_components",
    "volgray", "vol_window_level", "vol_equalize", "vol_gamma", "vol_stretch",
    "volxform", "vol_resize", "vol_rotate", "vol_affine",
    "volprobe", "vol_profile_line", "vol_edge_probe", "vol_wall_thickness",
    "volfreq", "vol_fft_lowpass", "vol_fft_highpass", "vol_fft_bandpass",
    "volrestore", "vol_gaussian_psf", "vol_richardson_lucy",
    "handpose", "hand_landmarks", "finger_flexions", "hand_skeleton_edges", "draw_hand_landmarks",
    "complexops", "cx_fft", "cx_ifft", "cx_magnitude", "cx_phase", "cx_real", "cx_imag",
    "cx_log_magnitude", "cx_from_mag_phase", "phase_unwrap", "cx_wiener_deconvolve",
    "cx_apply_transfer_function", "cx_bandpass",
    "specops", "stain_unmix", "stain_recompose", "stain_vectors_from_patches",
    "SAMPLE_PHOTOS", "sample_photo", "sample_photo_rgb", "sample_photo_raw",
    "sample_stereo_pair", "sample_photo_credit",
    "sem_metal_layer_cache", "sem_metal_layer_root", "sem_metal_layer_pairs",
    "sem_metal_layer_credit", "e57_bunny_cache", "e57_bunny_files",
    "dtu_pv_irt_cache", "dtu_pv_irt_root", "dtu_pv_irt_frame", "dtu_pv_irt_load", "dtu_pv_irt_credit",
    "STAIN_VECTORS",
    "BandMeta", "read_envi", "write_envi", "spec_band", "spec_rgb_composite",
    "spec_nearest_band", "spec_band_ratio", "spec_index", "spec_angle_mapper", "spec_pca",
    "spec_mnf", "spec_unmix", "spec_endmembers_ppi", "spec_continuum_removal",
    "spec_pansharpen", "spec_decorrelation_stretch", "spec_fuse",
    "deformreg", "warp_by_field", "demons_register", "field_magnitude", "residual_ssd",
    "synthetic_scene", "warp_homography", "corner_error", "condition_homography",
    "warp_parametric", "synthesize_moving", "smooth_test_field",
    "videops", "temporal_mean", "temporal_median", "temporal_std", "temporal_max",
    "temporal_min", "frame_difference", "background_subtraction", "temporal_gradient",
    "motion_energy", "moving_average", "spatiotemporal_gaussian", "spatiotemporal_sobel",
    "per_frame", "flicker_reduce", "optical_flow_sequence",
    "pose", "pose_descriptor", "skeleton_nodes", "principal_axis",
    "flow", "optical_flow_lk", "optical_flow_hs", "warp_by_flow",
    "flow_magnitude", "flow_angle", "track_points",
    "motion", "frame_motion_energy", "dominant_motion", "flow_from_model",
    "residual_motion", "motion_segments", "motion_energy_series", "detect_events",
    "sceneflow", "flow_divergence", "flow_curl", "focus_of_expansion", "time_to_contact",
    "looming", "ego_translation_from_flow", "scene_flow",
    "features", "harris_corners", "fast_corners", "describe_patches",
    "match_descriptors", "match_keypoints",
    "video", "read_frames", "iter_frames", "frame_pairs", "write_video", "probe",
    "recipes", "recipe", "measure", "line_profile", "distance", "angle",
    "fit_line", "fit_circle", "fit_circle_geometric", "fit_curve_principal_axis", "phase_correlation_shift", "fit_ellipse", "fit_rectangle2", "fit_rectangle2_lsq",
    "fit_line3", "fit_plane3", "fit_sphere3", "fit_circle3", "fit_surface_principal_axes",
    "smallest_box3", "smallest_box3_axis", "fit_box3", "smallest_sphere3", "inner_box3",
    "measure3d", "regionprops3d", "ops3d", "pipeline3d",
    "algo", "algo_ops", "algo_categories", "find_algo", "run_algo",
    "algo_to_python", "algo_to_c", "algo_difftest",
    "synth", "learn_features", "synthesize_like", "match_histogram",
    "radial_power_spectrum", "feature_distance", "patch_novelty", "pyramid_stat_distance",
    "funct1d", "smooth_funct_1d_gauss", "smooth_funct_1d_mean",
    "derivate_funct_1d", "integrate_funct_1d",
    "zero_crossings_funct_1d", "local_min_max_funct_1d",
    "funct_1d_to_pairs", "abs_funct_1d", "negate_funct_1d", "scale_y_funct_1d",
    "compose_funct_1d", "num_points_funct_1d", "distance_funct_1d",
    "sample_funct_1d", "get_pair_funct_1d", "invert_funct_1d",
    "transform_funct_1d", "x_range_funct_1d", "y_range_funct_1d",
    "get_y_value_funct_1d", "create_funct_1d_array", "create_funct_1d_pairs",
    "match_funct_1d_trans",
    "mathops", "mat_solve", "mat_lstsq", "mat_svd", "mat_eigh", "mat_pinv", "mat_cond",
    "mat_lu", "mat_qr", "mat_cholesky", "mat_eig",
    "stat_describe", "stat_histogram", "stat_covariance", "stat_correlation",
    "stat_zscore",
    "interp_linear", "interp_cubic", "interp_scattered",
    "poly_fit", "poly_eval", "poly_roots",
    "cplx_contour_circle", "cplx_poly_eval", "cplx_contour_integral",
    "cplx_winding_number", "cplx_cauchy_value", "cplx_argument_principle",
    "cplx_laurent_coeffs", "cplx_joukowski", "cplx_mobius", "cplx_cr_residual",
    "cplx_plane_grid", "cplx_rational_field", "cplx_domain_colour",
    "cplx_newton_basins", "cplx_escape_time", "mandelbrot_interior",
    "potential_flow_joukowski", "joukowski_circulation",
    "circle_packing_apollonian", "ford_circles",
    "phyllotaxis_pattern", "neighbour_index_gaps",
    "ifs_fractal", "ifs_similarity_dimension",
    "space_filling_curve", "curve_locality",
    # 波動と力学系(2026-09-23)
    "wave_membrane_mode", "wave_mode_frequencies", "wave_nodal_lines",
    "wave_two_slit", "wave_fringe_period", "wave_grating_orders",
    "wave_dominant_frequency",
    "ode_flow_states", "ode_vector_field_grid", "dynsys_poincare_section",
    "dynsys_lyapunov_spectrum", "dynsys_bifurcation_map",
    "dynsys_correlation_dimension",
    # フーリエ以外の積分変換と s 領域(2026-10-03)
    "abel_transform",
    "abel_inverse",
    "abel_inverse_image",
    "abel_revolve",
    "hankel_transform",
    "tf_poles_zeros",
    "tf_freq_response",
    "tf_impulse_response",
    "tf_step_response",
    "tf_bilinear",
    "laplace_inverse_talbot",
    "laplace_inverse_func",
    "humanoid_walk_clip",
    "peg_scene_build",
    "peg_set_pose",
    "peg_wrist_render",
    "peg_scene_close",
    "peg_contact_state",
    "peg_two_point_depth_sim",
    "peg_depth_sample_offset",
    "peg_insertion_run",
    "peg_insertion_grid",
    "puck_challenge_mjcf",
    "puck_mujoco_run",
    "pegfail_scene_build",
    "pegfail_episode_run",
    "pegfail_failure_grid",
    "heap_mujoco_pour",
    "heap_mujoco_discharge",
    "pegtactile_episode_run",
    "pegtactile_prefetch",
    "pegtactile_process_episode",
    "pegtactile_cutaway_xml",
    "cutting_mujoco_wrist",
    "diabolo_mujoco_simulate",
    "pegsym_scene_build",
    "pegsym_views",
    "pegsym_insert_try",
    "pegsym_search_run",
    "pegsym_two_point_depth_sim",
    "pegsym_scene_close",
    "polish_scene_build",
    "polish_stroke_run",
    "polish_scene_close",
    "scoop_mujoco_fill",
    "scoop_mujoco_pour",
    "hankel_image",
    "dct_transform",
    "wavelet_filters",
    "dwt_transform",
    "dwt_inverse",
    # 数値計算の古典と特殊関数(2026-10-03)
    "erf",
    "erfc",
    "bessel",
    "gauss_quadrature",
    "gauss_cubature",
    "chebyshev_coeffs_nd",
    "chebyshev_eval_nd",
    "low_discrepancy",
    "chebyshev_nodes",
    "interp_barycentric",
    "integrate_hamiltonian",
    # スペクトル推定(2026-10-03)
    "lomb_scargle",
    "music_doa",
    "esprit_doa",
    "ula_snapshots",
    "n_sources_mdl",
    "hilbert_analytic",
    # 推定と統計の古典(2026-10-03)
    "assign_hungarian",
    "hist_distance",
    "stat_ttest_paired",
    "stat_ttest_welch",
    "stat_ks_test",
    "stat_chi2_gof",
    "crlb_gaussian",
    "kalman_smooth",
    "mat_expm",
    "mat_logm",
    "se3_exp",
    "se3_log",
    # 離散幾何と位相の古典(2026-10-03)
    "mesh_euler_characteristic",
    "angle_defect",
    "delaunay_triangulate",
    "geodesic_heat",
    "geodesic_heat_grid",
    "mesh_torus",
    "nurbs_curve",
    "nurbs_circle",
    "nurbs_surface",
    "nurbs_revolve",
    "visiondesign", "system_geometry", "resolving_power", "system_feasibility",
    "image_formation", "detectability_limit",
    "defectgen", "defect_scratch", "defect_pits", "defect_crack", "defect_blob",
    "surface_texture", "composite_defect", "defect_stats",
    "visionlab", "VisionSystem", "render_part", "inspection_sweep",
    "detection_report",
    "lightfield", "lf_synthesize", "lf_from_mla", "lf_to_mla", "lf_stats",
    "lf_subaperture", "lf_center_view", "lf_views", "lf_epi",
    "lf_refocus", "lf_focal_stack", "lf_aperture_mask", "lf_synthetic_aperture",
    "lf_depth_from_focus", "lf_epi_slope", "lf_disparity_to_depth",
    "lf_all_in_focus", "lf_plenoptic_design",
    "photoncount", "photon_sample", "photon_statistics", "photon_uncertainty",
    "anscombe_transform", "anscombe_inverse",
    "spad_deadtime_apply", "spad_deadtime_correct", "tcspc_coates_correct",
    "tcspc_simulate", "tcspc_irf_convolve", "tcspc_background_subtract",
    "tcspc_stats", "dtof_depth", "dtof_cube_simulate", "dtof_cube_depth",
    "lifetime_fit", "lifetime_phasor",
    "dsp",
    "read_wav", "write_wav", "read_audio", "spectrum", "spectrogram",
    "lowpass", "highpass", "bandpass", "envelope", "rms", "find_peaks",
    "signal_local_std", "signal_quantize", "signal_companding_mu_law",
    "peak_subbin", "point_spectrum",
    "signal_features", "resample", "zero_crossing_rate",
    "specularity", "motionmag", "pose_quat", "quatimage", "rangedoppler",
    "acoustics", "interferometry", "flyvision", "spc", "graphinv", "treemorph", "segcompare", "textregion", "vxcore", "residue", "doe", "multivar", "sensitivity", "simcal", "simcalcheck", "converge", "mcphoton", "deconvstop", "codematch",
    "gfx2d", "alpha_composite", "alpha_composite_premul", "blend_mode", "bloom",
    "chromatic_aberration", "color_grade", "color_lut", "dither", "film_grain",
    "layer_stack", "light_mask", "linear_to_srgb", "nine_slice",
    "normal_map_decode", "normal_map_shade", "palette_quantize",
    "parallax_layers", "particle_emit", "particle_render", "particle_step",
    "premultiply", "radial_light", "shadow_cast_2d", "sprite_blit",
    "sprite_sheet_slice", "sprite_synthesize", "sprite_transform",
    "srgb_to_linear", "tilemap_render", "unpremultiply", "vignette",
    "viewport", "BLEND_MODES",
    "raw_black_level", "raw_dead_pixel_mask", "raw_dead_pixel_correct", "lens_shading_gain", "lens_shading_correct",
    "awb_gains", "rgb_apply_gains", "raw_apply_gains", "raw_demosaic_bilinear", "color_correction_matrix",
    "hue_saturation", "brightness_contrast", "BAYER_PATTERNS",
    "cadmap", "cad_pixel_to_surface", "cad_surface_to_pixel",
    "cad_defect_to_cad", "cad_visible_faces",
    "palette", "semantic_palette", "role_color", "role_rgb8", "diverging_lut", "assert_not_red_green_pair", "ROLES", "ROLE_MARKERS", "SCHEMES",
    # 差を測る層(srgb_to_linear / linear_to_srgb は gfx2d が実体なので再輸出しない)
    "imgmetrics", "opsimgmetrics",
    "rgb_to_lab", "lab_to_rgb", "rgb_to_xyz", "xyz_to_lab",
    "delta_e_2000", "delta_e_76", "delta_e_map",
    "mse", "rmse", "psnr", "ssim", "ssim_map", "ms_ssim",
    "joint_histogram", "image_entropy", "joint_entropy",
    "mutual_information", "normalized_mutual_information",
    "compressed_size", "ncd", "compare_images", "data_range_of",
    "measure_with", "metrics_table",
    "D65_WHITE", "MS_SSIM_WEIGHTS", "CIEDE2000_TEST_PAIRS",
    # 分布を運ぶ層(測る imgmetrics と対)
    "colortransport", "opscolortransport",
    "wasserstein_1d", "transport_plan_1d", "histogram_match", "color_transfer",
    "sinkhorn", "sinkhorn_distance", "sinkhorn_divergence", "transport_cost",
    "apply_transport", "gaussian_transport_map", "poisson_blend",
    "COLOR_TRANSFER_METHODS",
    # 画像フォレンジック層(断定せず証拠量を返す)
    "imgforensics", "opsimgforensics",
    "perceptual_hash", "hash_distance", "sensor_fingerprint", "fingerprint_correlate",
    "fingerprint_strength_map", "error_level_map", "jpeg_quality_estimate",
    "jpeg_ghost_map", "jpeg_ghost_quality", "noise_inconsistency_map",
    "copy_move_regions", "watermark_embed", "watermark_extract", "watermark_capacity",
    "null_distribution", "evidence_quantile",
    "astrostack", "opsastrostack",
    "synth_starfield", "synth_frame_series", "frame_quality", "lucky_select",
    "noise_sigma", "sigma_clip_stack", "drizzle_resample", "cosmic_ray_reject",
    "cosmic_ray_reject_stack", "star_detect", "psf_fit", "aperture_photometry",
    "frame_align", "align_frames",
    "STACK_MODES", "PSF_MODELS", "ALIGN_MODELS", "NOISE_METHODS",
    # 契約層(人が呼ぶ経路 / 自動で回す経路)とシステムパラメータ
    "metriccontract", "MetricContractError", "Attempt", "attempt", "attempt_all",
    "DIRECTIONS", "worst_case", "value_or_worst", "best_of", "rank_attempts",
    "fssystem", "set_system", "get_system", "query_system", "system",
    "reset_system", "system_snapshot",
    "fsthreads", "blas_threads",
    "annotate", "opsannotate", "measure_text", "text_box", "arrow", "leader_line",
    "label_points", "crosshair", "legend_box", "color_bar", "scale_bar",
    "axes_transform", "data_to_pixel", "nice_ticks", "axes_frame", "grid_lines",
    "ticks", "plot_series", "overlay_labels", "zoom_inset", "compare_frame",
    "panel_grid", "rounded_rect", "filled_polygon", "arc", "ellipse",
    "annotate_leader_layout", "annotate_leader", "annotate_markers", "annotate_legend",
    "annotate_dimension_layout", "annotate_dimension", "annotate_angle_layout",
    "annotate_angle", "annotate_scale_bar_layout", "annotate_scale_bar",
    "annotate_orientation", "annotate_inset_layout", "annotate_inset",
    "annotate_outline_layout", "annotate_outline", "annotate_text_path_layout",
    "annotate_text_path", "annotate_table_layout", "annotate_table",
    "annotate_invert_visibility", "annotate_invert",
    "annotate_invert_path", "annotate_colorbar", "annotate_panel_label",
    "annotate_figure_grid_layout", "annotate_figure_grid",
    "meshres",
    "mesh_edge_stats", "mesh_detail_map", "mesh_split_long_edges", "mesh_isotropic_remesh",
    "mesh_sample_points", "mesh_lod_chain", "mesh_select_lod", "mesh_reduction_report",
    "mesh_decimate_preserving", "pc_density", "pc_poisson_disk", "pc_fill_sparse",
    "pc_density_equalize", "pc_lod_chain", "pc_thinning_report",
    "videostream", "opsvideostream",
    "FrameRing", "StatefulOp", "TemporalMedianWindow", "MovingAverageWindow",
    "BackgroundSubtractionWindow", "FrameDifference", "ExponentialBackground", "RunningStats",
    "OpticalFlowStream", "VideoPipeline", "stream_replay",
    "MotionHistoryImage", "ThreeFrameDifference", "RunningGaussianForeground",
    "TemporalBilateral", "Deflicker", "SceneCutDetection",
    "temporal_median_window", "moving_average_window", "background_subtraction_window",
    "frame_difference_causal", "exponential_background", "exponential_foreground",
    "running_mean_std", "optical_flow_magnitude_stream",
    "motion_history_image", "motion_energy_image", "three_frame_difference",
    "running_gaussian_foreground", "running_gaussian_background",
    "temporal_bilateral", "deflicker", "scene_cut_detection",
    "annotate3d",
    "annotate3d_project", "annotate3d_arrow", "annotate3d_label",
    "annotate3d_scale_bar", "annotate3d_axes", "annotate3d_bbox", "annotate3d_measure",
    "project_anchors",
    "drawlist", "DrawList", "DrawListError", "diff_command_lists", "format_diff", "flush_buffer", "default_text_metrics", "measured_text_metrics", "COMMAND_SPECS", "TEXT_ADVANCE_RATIO",
    "drawstyle", "DrawStyle", "draw_style", "current_style", "set_color", "set_line_width", "set_line_style", "set_draw", "resolve_pattern", "resolve_color", "LINE_STYLES", "DRAW_MODES",
    "imagedraw", "draw_line", "draw_polyline", "draw_circle", "draw_markers", "draw_contour", "new_canvas",
    "ctscan", "tomography_gpu", "ct_scan_geometry", "shepp_logan_3d", "ellipsoid_phantom",
    "ellipsoid_projections", "ct_forward_project", "ct_adjoint_project", "fdk_reconstruct",
    "sirt_reconstruct", "os_sart_reconstruct", "tv_reconstruct", "ct_dual_energy_reconstruct",
    "tomography", "projection_angles", "sinogram_design", "ellipse_phantom",
    "ellipse_sinogram", "radon_transform", "backproject_sinogram",
    "filtered_backprojection", "sart_reconstruct", "beam_hardening_apply",
    "beam_hardening_correct", "ring_artifact_apply", "ring_artifact_remove",
    "metal_trace_interpolate", "sinogram_center_of_rotation",
    "sinogram_center_shift", "radon_volume", "fbp_volume",
    "volcolor", "vol_colorize_labels", "vol_label_color_flicker",
    "vol_label_legend", "vol_label_mpr_rgb", "vol_label_overlay",
    "vol_label_palette", "vol_label_shape_stats", "vol_label_slice_rgb",
    "vol_label_volume_render", "vol_labels_to_meshes", "vol_select_labels",
    "chromatic_confocal_height", "chromatic_confocal_simulate",
    "csi_contrast_map", "csi_design", "csi_envelope", "csi_height_map",
    "csi_peak_position", "csi_signal_simulate", "csi_stack_simulate",
    "angular_resample", "apply_weighting", "bearing_defect_frequencies",
    "cepstrum", "coherence", "envelope_spectrum", "equivalent_level",
    "istft", "octave_bands", "octave_spectrum", "order_spectrum",
    "percentile_level", "spectral_kurtosis", "stft", "stft_cola_check",
    "synthesize_bearing_signal", "synthesize_speed_ramp",
    "transfer_function", "weighting_response",
    "beamform_delay_sum", "beamform_doa", "fmcw_beat_simulate",
    "fmcw_design", "fmcw_range_profile", "fmcw_window_apply",
    "range_doppler_map", "range_doppler_peaks",
    "iqft2", "monogenic_amplitude", "monogenic_orientation",
    "monogenic_phase", "monogenic_signal", "qft2", "quat_color_filter",
    "quat_color_rotate", "quat_conjugate_image", "quat_correlate",
    "quat_image_multiply", "quat_norm", "quat_normalize_image",
    "quaternion_to_rgb", "rgb_to_quaternion", "riesz_displacement",
    "riesz_displacement_series", "riesz_motion_magnify",
    "riesz_transform",
    "axis_angle_to_quat", "convert_point_3d_cart_to_spher",
    "convert_point_3d_spher_to_cart", "convert_pose_type", "create_pose",
    "dual_quat_compose", "dual_quat_conjugate", "dual_quat_interpolate",
    "dual_quat_normalize", "dual_quat_to_pose", "dual_quat_to_screw",
    "dual_quat_trans_point_3d", "get_pose_type",
    "hom_mat3d_to_pose_local", "pose_average", "pose_compose",
    "pose_invert", "pose_to_dual_quat", "pose_to_hom_mat3d_local",
    "pose_to_quat", "quat_compose", "quat_conjugate", "quat_interpolate",
    "quat_normalize", "quat_rotate_point_3d", "quat_to_hom_mat3d",
    "quat_to_pose", "screw_to_dual_quat",
    "band_snr", "complex_steerable_decompose",
    "complex_steerable_reconstruct", "displacement_series",
    "motion_magnify", "phase_displacement", "synthesize_translation",
    "temporal_band_power", "temporal_bandpass",
    "specular_diffuse_split", "specular_free_transform",
    "specular_coefficient_map", "illuminant_from_dichromatic_planes",
    "brdf_blinn_phong", "brdf_microfacet", "dichromatic_render",
    "photometric_stereo_robust", "photometric_residual",
    "polarization_render", "polarization_separate",
    "polarization_dolp_map", "polarization_stokes", "polarization_analyze",
    "polarization_stokes_map",
    "optics", "thin_lens", "abcd_matrix", "abcd_trace", "depth_of_field",
    "relative_illumination",
    "airy_pattern", "angular_spectrum_propagate", "fraunhofer_pattern",
    "fourier_plane_filter", "four_f_filter",
    "gaussian_beam", "defocus_from_shift", "pupil_psf", "pupil_blur",
    "psf_to_mtf", "mtf_diffraction", "wavefront_stats",
    "encircled_energy", "ensquared_energy", "energy_radii", "mtf_tangential_sagittal",
    "jones_element", "jones_apply", "stokes_from_jones",
    "mueller_element", "mueller_apply", "stokes_analyze", "mueller_partial_polarizer",
    "polarization_demosaic", "polarization_demosaic_color", "mueller_from_intensities", "mueller_checks",
    "POLARIZATION_MOSAIC_LAYOUT", "POLARIZATION_SWEEP_ANGLES",
    "raytrace", "lens_system", "thick_lens", "glass", "refractive_index",
    "example_system", "paraxial_trace", "trace_rays", "ray_bundle",
    "spot_diagram", "spot_stats", "ray_fan", "opd_map", "opd_samples",
    "wavefront_from_opd", "seidel_coefficients", "tolerance_analysis",
    "glass_catalog", "sellmeier", "chromatic_shift", "chief_ray", "with_wavelength",
    "with_aiming", "ray_aiming", "set_vignetting",
    "lensopt", "optimize_lens", "merit_function", "bend_singlet",
    "sensorchar", "emva_pair_statistics", "emva_photon_transfer", "emva_quantum_efficiency", "emva_linearity_error", "emva_snr_curve", "emva_sensitivity_threshold", "emva_dynamic_range", "emva_dark_current", "emva_spatial_nonuniformity", "emva_defect_pixels", "emva_highpass", "emva_spectrogram", "emva_total_snr", "emva_exposure_for_snr", "emva_photon_exposure", "emva_bspline_regression", "emva_ptc_linearity_check", "emva_noise_whiteness", "emva_filter_distortion",
    "sensorgeneral", "emva_general_sensitivity", "emva_general_nonuniformity", "emva_general_relative_qe",
    "edgesfr", "edge_spread", "sfr_from_edge", "mtf50", "veiling_glare_index",
    "illumdesign", "light_source", "irradiance_map", "illumination_uniformity",
    "defect_contrast", "lighting_sweep", "illumination_design",
    "solid_angle_light", "solid_angle_boundaries", "solid_angle_brightness", "solid_angle_sweep", "solid_angle_render",
    "illumination_train", "illumination_field", "coaxial_illumination",
    "lensimage", "psf_from_opd", "psf_field_grid", "through_focus_mtf", "distortion_map",
    "render_through_lens", "defect_dataset", "calibration_views",
    "ncc_map_3d", "gradient_normals", "subpixel_refine_edges", "min_max_gray_n",
    "gen_gauss_bandpass", "apply_bandpass", "gaussians_to_mesh", "ensure_gray", "ensure_color",
    "dilation2", "get_bounding_box_object_model_3d", "normals_to_gradients", "integrate_gradients",
    "triangulate_points", "rel_pose_to_essential_matrix", "pyr_down", "image_pyramid",
    "rotational_symmetry_score",
    "center_from_symmetric_edges", "reflection_axis", "rotational_symmetry",
    "symmetry_difference_map", "symmetry_score",
    "register_pointclouds", "align_cad_to_scan", "measure_plane", "inspect_roundness", "match_sdf",
    "register_auto",
]


def recipe(name):
    """Look up a curated sample pipeline by name (see ``fullseye.recipes``)."""
    return recipes.get(name)


# ---- general-algorithm tier (algo-c parity; opt-in, image-focus-safe) ------- #
# A separate registry from the image REGISTRY: sorts/reductions over 1-D
# sequences, each shipping a Python reference AND a C reference, verified by
# algo_difftest (Python==numpy oracle, C==Python bit-for-bit). Does not touch the
# evolution registry — see ``algo.py`` and ``docs/GENERAL_ALGORITHMS.md``.
def algo_ops() -> list[str]:
    """Names of the general-algorithm ops (sorts/reductions), e.g. ``quicksort``."""
    return algo.algo_names()


def algo_categories() -> dict:
    """General-algorithm ops grouped by category (``sort`` / ``reduce``)."""
    return algo.algo_categories()


def find_algo(name: str):
    """The :class:`algo.AlgoOp` for *name*, or ``None``."""
    return algo.find_algo(name)


def run_algo(name: str, seq):
    """Run general algorithm *name* on *seq* (a sort returns a list; a reduction a float)."""
    return algo.run_algo(name, seq)


def algo_to_python(name: str) -> str:
    """The standalone Python source for general algorithm *name* (defines ``run(a)``)."""
    return algo_codegen.emit_python(algo.ALGO_BY_NAME[name])


def algo_to_c(name: str) -> str:
    """The standalone C source for general algorithm *name* (function + I/O driver)."""
    return algo_codegen.emit_c(algo.ALGO_BY_NAME[name])


def algo_difftest(name: str, workdir="out/algo", **kw) -> dict:
    """Run the honest gate for general algorithm *name* (Python==oracle, C==Python)."""
    return _algo_difftest.difftest(name, workdir, **kw)

def _resolve_version() -> str:
    """version の単一真実源 = pyproject。ハードコードは陳腐化する(0.1.5 でも
    "0.1.0" を返していた)。

    順に試す: (1) この api.py の隣にある ``pyproject.toml`` —— ソース/sdist の
    チェックアウトではこれが正本(wheel では隣に無いので None)。(2) インストール
    済みなら ``importlib.metadata`` の版。(1) を先に見るのは、開発ツリーに古い版が
    pip 済みだと metadata がソースとずれる(0.1.5 のソースで 0.1.4 が返る)ため。
    どちらも駄目なら最後の既知版。
    """
    import os as _os                                      # noqa: PLC0415
    import tomllib as _toml                               # noqa: PLC0415
    try:
        _pp = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "pyproject.toml")
        if _os.path.exists(_pp):
            with open(_pp, "rb") as _f:
                return _toml.load(_f)["project"]["version"]
    except Exception:                                     # noqa: BLE001
        pass
    try:
        from importlib.metadata import version as _v, PackageNotFoundError  # noqa: PLC0415
        try:
            return _v("fullseye")
        except PackageNotFoundError:
            pass
    except Exception:                                     # noqa: BLE001
        pass
    return "0.1.5"


__version__ = _resolve_version()


def version() -> str:
    """インストールされている fullseye パッケージの版(``"0.6.0"`` のような文字列)を返す。"""
    return __version__


# ---- resolution ------------------------------------------------------------ #
# HALCON aliases that several ops share while NO op carries the alias as its own
# name. `find_op` used to fall back to "first registered", so which implementation
# `fullseye.apply(x, "emphasize")` ran depended on backend registration order — a
# silent behaviour change whenever a backend was added. The winner is now a TABLE
# (one row per alias; tests/test_api.py pins that every such alias has a row), so
# a new ambiguous alias fails CI instead of resolving by accident.
_ALIAS_CANONICAL = {
    "emphasize": "unsharp",              # cv_sharpen is the cv2 port of the same idea
    "points_harris": "corner_response",  # sk_/cv_corner_harris, cv_min_eigen are library ports
}


def find_op(name: str):
    """op 名か HALCON 別名から 2-D レジストリの :class:`ops.Op` を引く(無ければ ``None``)。

    Return the :class:`ops.Op` for *name*, or ``None``.

    Exact op name wins; only then the HALCON alias, preferring the canonical op
    (``name == halcon``) when several ops share an alias, then the explicit
    ``_ALIAS_CANONICAL`` row, and only as a last resort the first registered hit.
    Identical rule to the CLI's ``_find_op`` so programmatic and command-line
    resolution agree. An empty or blank name (or a non-string) is ``None``.
    """
    # ★空・空白だけの名前は「無い」(2026-09-20、GenSpark N27): 多くの op は halcon 別名が "" なので、
    # `name == halcon` の一致で "" が **lowpass に解決**し、保存したパイプラインに空名が混ざると
    # 別の op が黙って走っていた。名前の照合はこの先で行うので、ここで先に切る。
    # ★2026-10-11: このコメントと判定が docstring より**前**にあったので、関数に docstring が
    #   無かった(``find_op.__doc__`` が None)。説明の門(台帳・facade 版)が拾った。
    if not isinstance(name, str) or not name.strip():
        return None
    for o in _ops.REGISTRY:
        if o.name == name:
            return o
    # Canonical alias (opnames.REGISTRY_ALIASES, phase 1 of the naming cleanup, 2026-10-07): a lookup
    # name for an EXISTING op, never a new Op - evolution genomes decode by ops.REGISTRY index order.
    # Checked after the exact name and before the HALCON alias; tests forbid a canonical name that
    # equals any op name or HALCON alias, so the order cannot change an existing resolution.
    target = _opnames.REGISTRY_ALIASES.get(name)
    if target is not None:
        return find_op(target)
    hits = [o for o in _ops.REGISTRY if o.halcon == name]
    if not hits:
        # ★大小文字とハイフンだけ違う名前は同じ op(2026-09-20、GenSpark N50): HALCON のリファレンスは
        # GAUSS_FILTER のように大文字で書かれることが多く、`GAUSS_FILTER` / `Gauss-Filter` が unknown だった。
        # 正規化して 1 度だけ引き直す(元の綴りに一致が無いときだけなので、既存の解決は変わらない)。
        norm = name.strip().lower().replace("-", "_")
        if norm != name:
            return find_op(norm)
        return None
    for o in hits:
        if o.name == o.halcon:
            return o
    pick = _ALIAS_CANONICAL.get(name)
    if pick is not None:
        for o in hits:
            if o.name == pick:
                return o
    return hits[0]


def ambiguous_aliases() -> dict:
    """``{alias: [op names]}`` for HALCON aliases shared by >1 op with NO canonical op.

    Each key must have a row in ``_ALIAS_CANONICAL`` naming one of its ops — otherwise
    :func:`find_op` would resolve it by registration order (pinned by tests).
    """
    by_alias: dict = {}
    for o in _ops.REGISTRY:
        if o.halcon:
            by_alias.setdefault(o.halcon, []).append(o.name)
    return {k: v for k, v in by_alias.items() if len(v) > 1 and k not in v}


_NARY_CACHE = None


def _nary_by_name() -> dict:
    """``{name_or_halcon: NaryOp}`` for the n-ary tier (image arithmetic / region set ops)."""
    global _NARY_CACHE
    if _NARY_CACHE is None:
        table = {}
        try:
            import imgops_nary as _na
            for o in _na.build_nary():
                table[o.name] = o
                table.setdefault(o.halcon, o)
        except ImportError:
            pass
        except Exception as e:           # noqa: BLE001 - installed but broken: leave a trace
            _bs.record("imgops_nary", e, None, source="import")
        _NARY_CACHE = table
    return _NARY_CACHE


def _resolve(name: str):
    op = find_op(name)
    if op is None:
        nop = _nary_by_name().get(name)
        if nop is not None:
            # Listed by list_ops() (tier "nary") but not a single-input registry op: say
            # so instead of the old bare KeyError — the fix is to pass a list of inputs.
            raise TypeError(
                "%r is an n-ary operator (arity %d, inputs %s): call "
                "fullseye.apply([%s], %r, a, b) with a list of inputs"
                % (name, nop.arity, list(nop.in_sorts),
                   ", ".join("x%d" % i for i in range(nop.arity)), name))
        hint = _explain_unregistered(_opnames.REGISTRY_ALIASES.get(name, name))
        if hint is not None:
            raise MissingBackendError(hint)
        row = _shipped_index().get(name) or {}
        if row.get("tier") == "ledger":
            # ★2026-09-20(GenSpark 第 35 報 N124): 台帳 op の名前を apply に渡すと「unknown operator」と言い、
            # op_names() を案内していた(そこにも無い)。索引は tier を知っているので、正しい入口を言う。
            raise KeyError(
                "%r is a typed-ledger operator (ledger %r, module %r), not a single-image op: run it with "
                "fullseye.op_run(%r, <inputs>) — fullseye.op_assist(%r) shows its inputs and parameters"
                % (name, row.get("ledger"), row.get("module"), name, name))
        raise KeyError(
            "unknown operator %r — try the op name or its HALCON alias; search with "
            "fullseye.op_find('<words>'), list with fullseye.op_names(); "
            "CLI: `fullseye has %s` (in a checkout: `py -3.11 imgevolve.py has %s`)"
            % (name, name, name)
        )
    return op


#: 登録はされているが、その環境に無い optional 依存を要する op が投げる(fail-closed)。本体は backend_safe。
#: ``MissingBackendError``(登録そのものが無い)と対にして facade から公開する。
MissingDependencyError = _bs.MissingDependencyError


class MissingBackendError(KeyError):
    """The operator exists in the shipped index, but is not registered in this environment.

    Raised by :func:`apply` / :func:`run_pipeline` instead of a bare "unknown operator"
    ``KeyError`` when the name is known to the shipped index (``fullseye/data/OP_INDEX.json``)
    but its providing module registered nothing here — almost always because an optional
    extra is not installed. The message names the module, the optional imports it uses,
    the ones missing here and the ``pip install "fullseye[<extra>]"`` line.

    Subclass of :class:`KeyError`, so existing ``except KeyError`` handlers still catch it::

        try:
            fullseye.apply(img, "sk_canny")
        except fullseye.MissingBackendError as e:
            print(e)      # operator 'sk_canny' exists but ... pip install "fullseye[skimage]"

    ★2026-09-19 の外部レビュー #1 / #2: core install で ``sk_canny`` が「存在しない」と
    案内され、しかも存在しない CLI(``imgevolve.py``)を勧めていた。
    """


_SHIPPED_INDEX_CACHE: dict | None = None


_SHIPPED_KNOBS_CACHE = None      # fullseye/data/op_knob.json (実測したつまみの表、name → 行)
def _shipped_index() -> dict:
    """``fullseye/data/OP_INDEX.json``(wheel に同梱の複製)を name → 行 で返す。

    無ければ checkout の ``docs/OP_INDEX.json``、それも無ければ ``{}``(案内を諦める
    だけで、KeyError の経路は残る)。読むのは未登録の名前を引かれた時だけ。
    """
    global _SHIPPED_INDEX_CACHE
    if _SHIPPED_INDEX_CACHE is not None:
        return _SHIPPED_INDEX_CACHE
    import json
    here = os.path.dirname(os.path.abspath(__file__))
    candidates = [os.path.join(here, "fullseye", "data", "OP_INDEX.json"),
                  os.path.join(here, "docs", "OP_INDEX.json")]
    try:
        from importlib import resources as _res
        candidates.insert(0, str(_res.files("fullseye").joinpath("data", "OP_INDEX.json")))
    except Exception:  # noqa: BLE001 - resources unavailable: fall back to path guesses
        pass
    table: dict = {}
    for p in candidates:
        try:
            with open(p, encoding="utf-8") as f:
                rows = json.load(f).get("ops") or []
            table = {r["name"]: r for r in rows if isinstance(r, dict) and "name" in r}
            if table:
                break
        except Exception:  # noqa: BLE001 - missing/corrupt copy: try the next candidate
            continue
    _SHIPPED_INDEX_CACHE = table
    return table


def _shipped_knobs() -> dict:
    """``fullseye/data/op_knob.json``(``docs/op_knob.json`` の wheel 同梱複製)を op 名 → 行 で返す。

    正本は ``tools/impl2/knob_probe.py`` の実測(構造の違う探針画像 × a / b の掃引)。無ければ checkout の
    ``docs/op_knob.json``、それも無ければ ``{}``。★2026-09-20(GenSpark 第 18〜20 報 I1): ノブが効くかは
    op ノートの文にしか無く、機械可読な形が公開層に無かった —— :func:`list_ops` の各行に ``knobs`` として乗せる。
    実測は登録 op の一部(2026-09-20 時点 461 / 931)なので、**未計測は None** で「効かない」とは言わない。
    """
    global _SHIPPED_KNOBS_CACHE
    if _SHIPPED_KNOBS_CACHE is not None:
        return _SHIPPED_KNOBS_CACHE
    import json
    here = os.path.dirname(os.path.abspath(__file__))
    candidates = [os.path.join(here, "fullseye", "data", "op_knob.json"),
                  os.path.join(here, "docs", "op_knob.json")]
    try:
        from importlib import resources as _res
        candidates.insert(0, str(_res.files("fullseye").joinpath("data", "op_knob.json")))
    except Exception:  # noqa: BLE001 - resources unavailable: fall back to path guesses
        pass
    table: dict = {}
    for p in candidates:
        try:
            with open(p, encoding="utf-8") as f:
                rows = json.load(f)
            table = {r["op"]: r for r in rows
                     if isinstance(r, dict) and r.get("op") and r.get("status") == "determined"}
            if table:
                break
        except Exception:  # noqa: BLE001 - missing/corrupt copy: try the next candidate
            continue
    _SHIPPED_KNOBS_CACHE = table
    return table


def knob_summary(name: str) -> dict | None:
    """What the ``a`` / ``b`` knobs of *name* do, as measured —— or ``None`` when not measured.

    ``{"a": "continuous" | "discrete" | "unused", "b": bool, "breakpoints": [a0, ...]}``:
    ``a`` is the kind of effect sweeping ``a`` has (``discrete`` = the output changes only at the
    listed ``breakpoints``), ``b`` says whether ``b`` changes the output at all. Source =
    ``docs/op_knob.json`` (``tools/impl2/knob_probe.py``), shipped in the wheel as
    ``fullseye/data/op_knob.json``. Rows of :func:`list_ops` carry this under ``"knobs"``.
    """
    r = _shipped_knobs().get(name)
    if r is None:
        return None
    return {"a": r.get("a_kind"), "b": bool(r.get("b_used")),
            "breakpoints": [float(x) for x in (r.get("breakpoints") or [])]}


def _explain_unregistered(name: str) -> str | None:
    """*name* が索引に在るのに登録されていない理由を 1 文で。索引に無ければ None。"""
    row = _shipped_index().get(name)
    if row is None:
        return None
    import importlib.util
    mod = row.get("module") or "?"
    req = list(row.get("requires") or [])
    missing = [m for m in req if importlib.util.find_spec(m) is None]
    deps = _ops.OPTIONAL_DEPS
    if missing:
        pips = ", ".join(deps.get(m, (m, None))[0] for m in missing)
        extras = sorted({deps[m][1] for m in missing if m in deps})
        lines = ['pip install "fullseye[%s]"' % e for e in extras]
        lines += ["pip install %s" % m for m in missing if m not in deps]   # 語彙に無い依存も置き去りにしない
        pip_line = " or ".join(lines)
        if all(m in _ops.OPTIONAL_IN_ALL for m in missing):
            pip_line += ' (or "fullseye[all]")'
        uses = ", ".join(deps.get(m, (m, None))[0] for m in req)
        return ("operator %r exists but is not available here: it is provided by module %r, which uses "
                "%s; not installed in this environment: %s (import name %s). Install with %s "
                "— see fullseye.FAILED_BACKENDS for backends that failed to load."
                % (name, mod, uses, pips, ", ".join(missing), pip_line))
    fb = getattr(_ops, "FAILED_BACKENDS", [])
    failed = dict(fb) if isinstance(fb, list) else {}
    if mod in failed:
        return ("operator %r is provided by module %r, which failed to load here: %s "
                "(fullseye.FAILED_BACKENDS)" % (name, mod, failed[mod]))
    if row.get("tier") and row.get("tier") != "registry":
        return None                 # nary / ledger / color は別経路(_resolve の呼び手が案内する)
    return ("operator %r is in the shipped index (module %r) but not registered in this build — "
            "its dependencies import, so the backend registered nothing: check "
            "fullseye.FAILED_BACKENDS and fullseye.op_names()" % (name, mod))


# Region ops that read the gray VALUES of their input as labels rather than as a
# mask. The registry carries no per-op flag for this, so the set is explicit; add
# an op here when it distinguishes label values instead of foreground/background.
_LABEL_READING_OPS = frozenset({"r3_label_to_region"})


def _needs_binarise(a) -> bool:
    """True when *a* has more than two distinct levels, or any value outside [0,1].

    This is the verdict ``np.unique(a)`` used to give, computed in **O(N)** instead
    of ``O(N log N)``: ``np.unique`` sorts the whole array, which made every region
    op twice as slow through the facade (2048² region: 17.6 ms of a 35.0 ms call —
    ``docs/design/PERF_MEMORY_VIDEO_SURVEY.md`` §1.7 / §5.3 item 3).

    Same verdict, not merely a similar one: an array with min ``mn`` and max ``mx``
    has at most two distinct levels **iff** every element equals ``mn`` or ``mx``.
    NaN is the one case where min/max stop being informative (``nan < 0`` is False,
    so the old code fell through to "leave it alone" for a two-element unique), so a
    NaN-bearing array takes the original ``np.unique`` path verbatim.
    """
    if a.size == 0:
        return False                                  # np.unique -> size 0: neither test fires
    mn = a.min()
    mx = a.max()
    if a.dtype.kind == "f" and (np.isnan(mn) or np.isnan(mx)):   # replay the exact old test
        vals = np.unique(a)
        return bool(vals.size > 2 or vals.min() < 0.0 or vals.max() > 1.0)
    if mn < 0.0 or mx > 1.0:
        return True
    return bool(mn != mx and not np.all((a == mn) | (a == mx)))


def _coerce_input(v, op):
    """Gently match the array to the op's declared input sort (opt-in).

    Only a ``region`` input is touched. It is re-typed to a float64 {0,1} mask —
    never re-valued — when it is not already one:
      * a bool array is re-typed (``-``/``sum`` on bool either raises or silently
        changes meaning);
      * an int/uint array that is already a {0,1} mask is re-typed to float64 so
        the declared "returns float64" contract holds for it too;
      * any array with more than two levels or values outside [0,1] is binarised
        at the same 0.5 threshold every region op uses internally (``ops._bin``).

    A float one- or two-level in-range array such as {0.3, 0.7} is deliberately
    left alone: ``_bin`` already reads it as an unambiguous mask, so binarising
    here would change nothing for mask ops while destroying the gray levels that
    the few label-reading region ops (``r3_label_to_region``) legitimately consume.

    Label-reading ops are exempted outright (``_LABEL_READING_OPS``): a real label
    image has more than two levels by definition, so the two-level carve-out above
    never reaches it — binarising at 0.5 would merge every label into one blob and
    the op could only ever return the whole foreground.
    """
    a = np.asarray(v)
    if op.in_sort != "region":
        return v
    if op.name in _LABEL_READING_OPS:
        return v
    if a.dtype.kind == "b":
        return a.astype(np.float64)                  # mask already; only the dtype is off
    if a.dtype.kind in "fiu":
        if _needs_binarise(a):
            return (a.astype(np.float64) > 0.5).astype(np.float64)
        if a.dtype.kind in "iu":
            return a.astype(np.float64)              # int/uint {0,1} mask -> float64 (same values)
    return v


# ---- run ------------------------------------------------------------------- #
# Error policy. The facade used to be fail-soft with no escape hatch: a broken op, a
# failed GPU kernel or an input of the wrong sort all became a plausible-looking
# array with no trace (2026-09-02 audit: 6 of 7 confirmed bugs were of the
# "no exception, wrong answer" kind). The contradiction — never crash a user's
# pipeline vs. never hide a failure — is resolved by letting the CALLER choose:
#
#   on_error="fallback"  (default) keep the sort-valid fallback; every degradation is
#                        recorded in the ledger (fullseye.fallbacks()) and each op
#                        warns ONCE (FullseyeFallbackWarning);
#   on_error="warn"      as above, but warn on EVERY fallback of this call;
#   on_error="raise"     fail-closed: the op's real exception propagates, a wrong-sort
#                        input raises ValueError, a failed GPU kernel raises.
#
# The default can be set process-wide with FULLSEYE_ON_ERROR=raise (CI / verifiers).
_ON_ERROR_CHOICES = ("fallback", "warn", "raise")
_NDIM_OK = {"image": (2, 3), "region": (2, 3), "color": (3,), "volume": (3, 4)}
_NOACCEL = object()
# GPU circuit breaker (TRIZ #9 preliminary anti-action / #23 feedback): once an op's
# accelerated path has FAILED it is not retried on every call — a broken kernel
# would otherwise cost a GPU attempt + a recorded fallback per invocation. The
# breaker is per op name, opens on the first failure, and `reset_gpu()` closes it
# (half-open: the next call tries the GPU again).
_GPU_OPEN: set = set()
_TORCH_IMPORT_FAILURE: str | None = None     # torch が import できない理由(一度だけ試す)


def resolve_device(device: str = "cpu", *, stages=None, shape=None, n: int = 1) -> str:
    """実行 device を解決する / Resolve ``auto`` and ``FULLSEYE_DEVICE``.

    明示した引数より ``FULLSEYE_DEVICE`` を優先する。既定は ``cpu``(0.9.0、計測の再現性のため GPU は
    明示したときだけ)。``auto`` は CUDA が使えれば ``cuda``、無ければ
    ``cpu``。``cuda`` の明示はそのまま返す: CUDA の無い機械では op ごとに N117 の説明つきで
    台帳に記録して CPU で続き(既定)、``on_error="raise"`` ではその説明つき ``RuntimeError`` になる
    (入口で拒まない = 2026-09-20 の契約 ``tests/test_release_0_2_1_gates_2026_09_20.py``)。

    ``auto`` に仕事の中身 (*stages* = op 名の列、*shape* = 1 枚の形、*n* = 枚数)を渡すと、CUDA が在っても
    転送込みで GPU が CPU に勝たない大きさは ``cpu`` を返す(実測の表 ``fullseye/data/DEVICE_RULES.json``、
    :mod:`device_policy`)。GPU 経路の無い op は、許可リスト(``fullseye/data/gpu_auto_allow.json``)に
    あって倍率を測った大きさ以上なら ``cuda``(:mod:`gpu_shadow` の道)、それ以外は ``cpu``。
    ``auto`` が ``cuda`` を選ぶ前に空き VRAM を見て、``FULLSEYE_GPU_MIN_FREE_MB``(既定
    ``device_policy.DEFAULT_MIN_FREE_MB``)未満なら ``cpu``(LLM が同じ GPU を使っている場面)。
    ``FULLSEYE_DEVICE`` と明示の ``cpu`` / ``cuda`` はこれらの判定より優先する。
    なぜその装置か(経路と理由)は :func:`explain_device` が返す。
    """
    return _decide(device, stages, shape, n)["resolved"]


def explain_device(device: str = "auto", *, stages=None, shape=None, n: int = 1) -> dict:
    """装置の選択とその理由 / The device decision, with the path and the reason.

    返り値(JSON にそのまま載る): ``requested``(渡した値)/ ``source``(``argument`` か
    ``FULLSEYE_DEVICE``)/ ``resolved``(:func:`resolve_device` の値)/ ``device``(実際に計算が走る装置)/
    ``path``(``accel`` / ``allow_single`` / ``allow_resident`` / ``allow_pipeline`` / ``cpu``、鎖で段ごとに
    違えば ``mixed``)/ ``reason``(``cpu`` を選んだ理由: ``requested_cpu`` / ``env_cpu`` / ``no_cuda`` /
    ``vram_low`` / ``crossover`` / ``not_listed`` / ``chain_only`` / ``no_cupy`` / ``below_measured_size`` /
    ``native_not_wired``)。op にどの GPU 経路があるかは :func:`gpu_route.route` だけが決める。
    2 段以上なら ``stages``(段ごとの ``op`` / ``path`` / ``reason``)。空き VRAM を見たときは
    ``vram_free_mb`` / ``vram_min_free_mb``。
    """
    return {k: v for k, v in _decide(device, stages, shape, n).items() if not k.startswith("_")}


def _decide(device, stages, shape, n, assume_cuda: bool = False) -> dict:
    """:func:`resolve_device` と :func:`explain_device` の本体。``_paths`` / ``_reasons`` は段ごとの経路と理由(内部用)。

    *assume_cuda* = CUDA と CuPy が在り、空き VRAM も足りる機械として**経路表だけで**決める
    (:func:`explain_pipeline` が GPU の無い機械でも段の並びを検査するため)。
    """
    requested = os.environ.get("FULLSEYE_DEVICE", device).strip().lower()
    if requested not in ("auto", "cpu", "cuda"):
        raise ValueError("device must be 'auto', 'cpu', or 'cuda'; got %r" % requested)
    source = "FULLSEYE_DEVICE" if "FULLSEYE_DEVICE" in os.environ else "argument"
    dec = {"requested": str(device), "source": source}
    names = None
    if stages is not None:
        found = [find_op(name) if isinstance(name, str) else None for name in stages]
        names = [op.name if op is not None else name for op, name in zip(found, stages)]

    def finish(resolved, paths):
        dec["resolved"] = resolved
        dec["_paths"] = [p for p, _r in paths]
        dec["_reasons"] = [r for _p, r in paths]
        on_gpu = [p for p, _r in paths if p != "cpu"]
        dec["device"] = "cuda" if on_gpu and resolved == "cuda" else "cpu"
        kinds = sorted({p for p, _r in paths})
        dec["path"] = kinds[0] if len(kinds) == 1 else "mixed"
        reasons = [r for p, r in paths if r is not None]
        dec["reason"] = None if dec["device"] == "cuda" else (reasons[0] if reasons else None)
        if names is not None and len(names) > 1:
            dec["stages"] = [{"op": nm, "path": p, "reason": r} for nm, (p, r) in zip(names, paths)]
        return dec

    def all_cpu(reason, resolved="cpu"):
        return finish(resolved, [("cpu", reason)] * (len(names) if names else 1))

    if requested == "cpu":
        return all_cpu("env_cpu" if source == "FULLSEYE_DEVICE" else "requested_cpu")
    if not assume_cuda and not cuda_available():
        # 明示の cuda は入口で拒まない(N117)。計算は CPU で走るので device は cpu
        return all_cpu("no_cuda", resolved="cuda" if requested == "cuda" else "cpu")
    import device_policy
    auto = requested == "auto"
    vram_ok = (lambda: (True, None, device_policy.min_free_mb())) if assume_cuda else device_policy.vram_ok
    if names is None:
        if auto:
            ok, free, need = vram_ok()
            dec.update(vram_free_mb=free, vram_min_free_mb=need)
            if not ok:
                return all_cpu("vram_low")
        dec.update(resolved="cuda", device="cuda", path=None, reason=None, _paths=None)
        return dec
    import gpu_route
    accelerated = gpu_route.accelerated_names()
    runnable = (lambda r: r is not None and r.kind in ("accel", "shadow")) if assume_cuda else gpu_route.runnable
    paths = device_policy.plan_paths(names, shape if auto else None, route_of=gpu_route.route,
                                     runnable=runnable, auto=auto)
    if not auto:
        return finish("cuda", paths)
    shadow_on = any(p.startswith("allow_") for p, _r in paths)
    if (not shadow_on and any(p == "accel" for p, _r in paths) and shape is not None
            and device_policy.route(names, shape, n, accelerated=accelerated) == "cpu"):
        paths = [("cpu", "crossover") if p == "accel" else (p, r) for p, r in paths]
    if all(p == "cpu" for p, _r in paths):
        return finish("cpu", paths)
    ok, free, need = vram_ok()
    dec.update(vram_free_mb=free, vram_min_free_mb=need)
    if not ok:
        return all_cpu("vram_low")
    return finish("cuda", paths)


def _stage_names(stages) -> list:
    """段の並び(:func:`run_pipeline` が受ける書き方のどれか)から op 名だけを取り出す。"""
    if isinstance(stages, str):
        return [s.strip() for s in stages.split(",") if s.strip()]
    names = []
    for s in stages:
        if isinstance(s, str):
            names.append(s)
        elif isinstance(s, dict):
            names.append(s.get("op", s.get("name")))
        elif isinstance(s, (list, tuple)) and s:
            names.append(s[0])
        else:
            names.append(getattr(s, "op", s))
    return names


#: :func:`explain_pipeline` の切り替わりの理由の語彙(``reason`` が CPU 側の段の理由、``detail`` は台帳の根拠)。
SWITCH_REASONS = {
    "not_listed": "GPU 経路が無い(手書き・許可リスト・native のどれにも無い)",
    "crossover": "損益分岐: この大きさでは転送込みで GPU が CPU に勝たない(DEVICE_RULES.json)",
    "below_measured_size": "損益分岐: 倍率を測った大きさ未満(勝つと言えない)",
    "chain_only": "鎖の枠だけの経路で、隣が GPU の段でない(常駐でしか勝たない)",
    "native_not_wired": "native 経路は apply / run_pipeline からまだ走らせない",
    "no_cupy": "許可リストの道を走らせる CuPy が無い",
    "no_cuda": "CUDA が無い", "vram_low": "空き VRAM が閾値未満", "requested_cpu": "cpu を指定した",
    "env_cpu": "FULLSEYE_DEVICE=cpu", "engine_change": "GPU の中で道具が替わる(torch と CuPy の間はホストを経由)",
}


def explain_pipeline(stages, shape=None, *, device: str = "auto", n: int = 1, assume_cuda: bool = False) -> dict:
    """パイプラインを**走らせる前に**検査する / Inspect a pipeline before running it.

    *stages* は :func:`run_pipeline` と同じ書き方(名前の列・``(name, a, b)``・dict・カンマ区切り)。
    *shape* = 1 枚の形(損益分岐の判定に使う。``None`` なら大きさの判定はしない)。*assume_cuda* =
    CUDA・CuPy・空き VRAM のある機械として経路表だけで決める(GPU の無い機械で並びを検査する)。

    返り値(JSON にそのまま載る):

    * ``decision`` —— :func:`explain_device` と同じ欄(``requested`` / ``resolved`` / ``device`` / ``path`` /
      ``reason`` / ``source``、見たなら VRAM)。
    * ``stages`` —— 段ごとに ``index`` / ``op`` / ``in_sort`` / ``out_sort`` / ``path`` / ``reason`` /
      ``on``(``gpu`` / ``cpu``)/ ``route``(経路の種類と場面、無ければ ``None``)/ ``detail``(GPU 経路が
      無い理由の根拠: 台帳で不採用になった理由 ``mismatch`` / ``constant_output`` / ``slower`` 等)。
    * ``type_breaks`` —— 型の切れ目(前段の ``out_sort`` と次段の ``in_sort`` が合わない・op が無い)。
      :func:`run_pipeline` は 1 段も走らせずに ``ValueError`` にする並び。
    * ``segments`` —— 実行の区間(``accel`` = torch の常駐区間 / ``shadow`` = CuPy の区間 / ``cpu``)。
    * ``switches`` —— 区間の境目ごとに ``at``(段の番号)/ ``op`` / ``from`` / ``to`` / ``reason``
      (CPU に戻るときはその段の理由、GPU に入るときは ``None``、GPU どうしの乗り換えは ``engine_change``)。
    * ``n_switches`` / ``n_gpu_stages`` / ``n_cpu_stages`` / ``n_gpu_segments``。
    * ``n_transfers`` —— :func:`run_pipeline` の見込みの往復回数(GPU の区間ごとに送り 1 回・戻し 1 回 =
      1 往復)。``n_transfers_per_stage`` —— 段ごとに :func:`apply` を呼ぶとき(MCP の ``fullseye_pipeline``)の
      往復回数(GPU で走る段ごとに 1 往復)。
    * ``reasons`` —— 出てきた理由の語の説明(:data:`SWITCH_REASONS`)。
    """
    import engine as _engine                     # 型の検査は run_pipeline と同じ規則(_check_chain_sorts)
    import gpu_route
    names = _stage_names(stages)
    found = []
    for nm in names:
        op = find_op(nm) if isinstance(nm, str) else None
        if op is None and isinstance(nm, str):
            op = _nary_by_name().get(nm)
        found.append(op)
    dec = _decide(device, names, shape, n, assume_cuda=assume_cuda) if names else None
    paths = (dec or {}).get("_paths") or []
    reasons = (dec or {}).get("_reasons") or [None] * len(paths)
    on_gpu = bool(dec) and dec.get("device") == "cuda"
    rows = []
    breaks = []
    cur = None
    for i, nm in enumerate(names):
        op = found[i]
        in_sort = getattr(op, "in_sort", None) or (op.in_sorts[0] if op is not None and hasattr(op, "in_sorts") else None)
        out_sort = getattr(op, "out_sort", None)
        if op is None:
            breaks.append({"index": i, "op": nm, "reason": "unknown_op", "expected": None, "got": cur})
            cur = None
        else:
            if cur is not None and not _engine._compatible(cur, in_sort):
                breaks.append({"index": i, "op": nm, "reason": "sort_mismatch", "expected": in_sort, "got": cur})
            cur = _engine._thread_sort(cur, op)
        path = paths[i] if i < len(paths) else "cpu"
        reason = reasons[i] if i < len(reasons) else None
        canon = op.name if op is not None else nm
        r = gpu_route.route(canon, "pipeline" if len(names) > 1 else "single") if isinstance(canon, str) else None
        stage_on = "gpu" if (on_gpu and path != "cpu") else "cpu"
        if stage_on == "cpu" and reason is None and dec is not None:
            reason = dec.get("reason")
        rows.append({"index": i, "op": nm, "in_sort": in_sort, "out_sort": out_sort, "path": path,
                     "reason": None if stage_on == "gpu" else reason, "on": stage_on,
                     "route": {"kind": r.kind, "use": r.use} if r is not None else None,
                     "detail": gpu_route.rejection(canon) if (r is None and isinstance(canon, str)) else None})
    segments = []
    for row in rows:
        kind = "cpu" if row["on"] == "cpu" else ("shadow" if str(row["path"]).startswith("allow_") else "accel")
        if segments and segments[-1]["kind"] == kind:
            segments[-1]["stages"].append(row["op"])
        else:
            segments.append({"kind": kind, "on": row["on"], "start": row["index"], "stages": [row["op"]]})
    switches = []
    for prev_seg, seg in zip(segments, segments[1:]):
        row = rows[seg["start"]]
        if seg["on"] == "cpu":
            why = row["reason"]
        elif prev_seg["on"] == "gpu":
            why = "engine_change"
        else:
            why = None
        switches.append({"at": seg["start"], "op": row["op"], "from": prev_seg["kind"], "to": seg["kind"],
                         "reason": why})
    n_gpu_segments = sum(1 for s in segments if s["on"] == "gpu")
    used = sorted({x for x in [r["reason"] for r in rows] + [s["reason"] for s in switches] if x})
    decision = None if dec is None else {k: v for k, v in dec.items() if not k.startswith("_") and k != "stages"}
    return {"decision": decision, "assume_cuda": bool(assume_cuda),
            "shape": list(shape) if shape is not None else None, "stages": rows, "type_breaks": breaks,
            "segments": segments, "switches": switches, "n_switches": len(switches),
            "n_gpu_stages": sum(1 for r in rows if r["on"] == "gpu"),
            "n_cpu_stages": sum(1 for r in rows if r["on"] == "cpu"),
            "n_gpu_segments": n_gpu_segments, "n_transfers": n_gpu_segments,
            "n_transfers_per_stage": sum(1 for r in rows if r["on"] == "gpu"),
            "reasons": {k: SWITCH_REASONS.get(k, k) for k in used}}


_DECISION = __import__("threading").local()


def last_device_decision() -> dict | None:
    """このスレッドで最後に :func:`apply` / :func:`run_pipeline` が使った装置の選択(:func:`explain_device` の形)。"""
    dec = getattr(_DECISION, "value", None)
    return None if dec is None else {k: v for k, v in dec.items() if not k.startswith("_")}


def _gpu_op_names() -> frozenset:
    """手書きの GPU 経路を持つ core op 名(2-D + 体積 + 照合)。台帳は :mod:`gpu_route` が読む。"""
    import gpu_route
    return gpu_route.accelerated_names()


def cuda_available() -> bool:
    """CUDA が本当に使えるか(torch が無い機械では False、失敗は一度だけ試す)。"""
    global _TORCH_IMPORT_FAILURE
    if _TORCH_IMPORT_FAILURE is not None:
        available, why = False, _TORCH_IMPORT_FAILURE
    else:
        try:
            import torch
            available = bool(torch.cuda.is_available())
            why = "torch %s: torch.cuda.is_available() is False" % torch.__version__
        except Exception as exc:  # noqa: BLE001 - an absent/broken optional torch is a CPU-only host
            available = False
            why = _TORCH_IMPORT_FAILURE = "torch could not be imported: %s: %s" % (type(exc).__name__, str(exc)[:120])
    del why
    return available


def reset_gpu() -> list:
    """Close the GPU circuit breaker for every op; returns the names that were open."""
    was = sorted(_GPU_OPEN)
    _GPU_OPEN.clear()
    return was


def gpu_open_ops() -> list:
    """Op names whose accelerated path is currently disabled by the breaker."""
    return sorted(_GPU_OPEN)


# Same breaker for the CPU fast-twin path (``fast.py``): a twin that raises once is
# not retried on every call.
_FAST_OPEN: set = set()


def reset_fast() -> list:
    """Close the fast-twin circuit breaker for every op; returns the names that were open."""
    was = sorted(_FAST_OPEN)
    _FAST_OPEN.clear()
    return was


def fast_open_ops() -> list:
    """Op names whose CPU fast twin is currently disabled by the breaker."""
    return sorted(_FAST_OPEN)


def _fast_on(flag) -> bool:
    """Is the CPU fast-twin path enabled for this call?

    ``fast=True/False`` wins; ``None`` reads ``FULLSEYE_FAST`` (``1``/``true``/``yes``).
    **Default OFF** — the twins are parity-gated (``fast.parity``) but the switch is
    opt-in until a bench run on the target machine says the default should flip.
    """
    if flag is not None:
        return bool(flag)
    return os.environ.get("FULLSEYE_FAST", "").strip().lower() in ("1", "true", "yes", "on")


def _policy(on_error):
    # ★2026-09-20(GenSpark 第 55 報 N199): `with strict_mode(): apply(gray, "access_channel")` が例外にならず、
    #   入力型の fallback(source="input")が台帳に残っていた。strict は op 本体の例外と GPU / 高速路だけが見ていて、
    #   `_guard_input` と非有限出力の門は `on_error` しか見ていなかった —— 「厳密」が経路ごとに別の意味だった。
    #   strict(strict_mode / set_strict / FULLSEYE_STRICT)は on_error=None のとき "raise" と同じ。明示の
    #   on_error は文脈より強い(引数 > 文脈 > 環境変数 > 既定)。
    if on_error is None and _bs.is_strict():
        return "raise"
    p = on_error if on_error is not None else os.environ.get("FULLSEYE_ON_ERROR", "fallback")
    if p not in _ON_ERROR_CHOICES:
        raise ValueError("on_error must be one of %s, or None (= FULLSEYE_ON_ERROR, default 'fallback'); got %r"
                         % (_ON_ERROR_CHOICES, p))
    return p


# ---- カラー画像を 3 本目の空間軸として扱う op --------------------------------- #
# `_NDIM_OK["image"] = (2, 3)` は 3-D をわざと通している。ところが中の実装は
# `ndimage.*` を素通しするので、(H, W, 3) は「高さ 3 の体積」として扱われ、
# **近傍演算が色を跨ぐ**。
#
# 2026-09-06 の全数計測(因果の形の探針: R と G は両方の入力で 0 と 1 を含む
# よう固定し、**B の中身だけ**を (0,1) の内側で 2 通りに変えて R の出力が動くかを
# 見る。正規化は配列全体の最大で割るので、min/max を動かさないのがこの探針の要)。
# 882 op のうち RGB の形のまま返る 472 op を数えて:
#
#     跨がない 372 / **跨いだ 100** / 形が変わる 370 / 例外 43
#     跨いだ 100 の宣言入力型: image 78 / region 11 / volume 4 / color 3 /
#                              rgbimage 2 / video 2
#
# volume・color・rgbimage・video は 3-D を受けるのが仕様なので正しい。
# **image と region の 89 本が不具合**で、下はそのうち image の 78 本。
#
# ★ **いまのところカラー画像に対して正しい呼び方が存在しない**: まとめて渡すと
#   色が混ざり、チャネルごとに 3 回呼ぶと自己正規化する op が各チャネルを
#   自分の最大で割ってチャネル間の比を壊す(灰色エッジ法の角度誤差が
#   自前 Sobel 1.03 度 -> 画像ごと 4.17 度 -> ch ごと 27.86 度、ゼロ点 29.14 度)。
#   どちらに倒すかは**契約の決め**なので、ここでは既定の数値は 1 つも変えず、
#   `on_error="raise"` のときだけ拒否し、既定では台帳に記録して見えるようにする。
#   詳細と選択肢は docs/KNOWN_ISSUES.md。
_CHANNEL_UNSAFE_IMAGE_OPS = frozenset((
    "bilateral_filter", "bothat", "corner_response", "cv_bilateral",
    "deviation_image", "diff_of_gauss", "dog", "dots_image",
    "dual_rank", "eliminate_min_max", "eliminate_sp", "fft_generic",
    "fft_image", "fft_image_inv", "gauss_filter", "gauss_image",
    "gaussian", "gclose", "gdilate", "gray_dilation_rect",
    "gray_range_rect", "guided_filter", "hx_region_to_mean", "isotropic_diffusion",
    "laplace_of_gauss", "log", "macro_binarize", "max_filter",
    "mean_box", "mean_curvature_flow", "mean_image", "mean_sp",
    "median", "median_image", "median_separate", "median_weighted",
    "morph_grad", "percentile", "phase_deg", "phase_rad",
    "power_byte", "power_ln", "power_real", "rank_image",
    "rank_rect", "rft_generic", "sigma_image", "simulate_defocus",
    "sk_butterworth", "sk_dog", "sk_farid", "sk_frangi",
    "sk_hessian", "sk_hessian_det", "sk_meijering", "sk_nlm",
    "sk_rolling_ball", "sk_tv", "smooth_image", "std_filter",
    "texture_laws", "trimmed_mean", "xmh_regmin", "xmh_selfmatch",
    "xsitk_curv_aniso_diff", "xsitk_curvature_flow", "xsitk_minmax_curv_flow", "xsk2_inv_gauss_grad",
    "xsk3_integral_image", "xsk_hessian_eig", "xsk_inpaint", "xsk_meijering",
    "xsk_sato", "xsk_unwrap_phase", "xsp_dct", "xsp_dct_denoise",
    "xsp_gauss_grad_mag", "xsp_morph_laplace",
))

#: 同じ穴だが宣言入力型が region のもの(二値も 2-D なので同様に混ざる)。
_CHANNEL_UNSAFE_REGION_OPS = frozenset((
    "closest_point_transform", "dilation_seq", "dist_transform", "distance_transform",
    "morph_skeleton", "reg_dilate", "sk_skeleton", "skeleton",
    "xsitk_signed_maurer_dist", "xsk2_isotropic_close", "xsp_chamfer_dist",
))

_CHANNEL_UNSAFE_OPS = _CHANNEL_UNSAFE_IMAGE_OPS | _CHANNEL_UNSAFE_REGION_OPS


def _check_channel_axis(v, op):
    """(H, W, 3|4) を 3 本目の空間軸として扱ってしまう op を指す例外、または None。"""
    if op.name not in _CHANNEL_UNSAFE_OPS:
        return None
    arr = v if isinstance(v, np.ndarray) else None
    if arr is None or arr.ndim != 3 or arr.shape[-1] not in (3, 4):
        return None
    return ValueError(
        "op %r は 2-D の %s 用で、(H, W, %d) を渡すと**色軸を 3 本目の空間軸として "
        "扱う**(近傍演算が色を跨ぐ。2026-09-06 の全数計測で image 78 本 / "
        "region 11 本がこの形)。チャネルごとに呼ぶ手もあるが、自己正規化する op は "
        "チャネル間の比を壊す —— docs/KNOWN_ISSUES.md を読んでから決めること。"
        % (op.name, op.in_sort, arr.shape[-1]))


def _check_input_sort(v, op):
    """Exception describing a clearly wrong input for *op*, or None (light, ndim-level check)."""
    ok = _NDIM_OK.get(op.in_sort)
    if ok is None:
        return None
    try:
        arr = v if isinstance(v, np.ndarray) else np.asarray(v)
    except Exception as e:               # noqa: BLE001
        return TypeError("op %r expects a %s array, got %r (%s)" % (op.name, op.in_sort, type(v).__name__, e))
    if arr.dtype.kind not in "biufc":
        return TypeError("op %r expects a numeric %s array, got dtype %s" % (op.name, op.in_sort, arr.dtype))
    if arr.ndim not in ok:
        return ValueError("op %r expects a %s (%s-D array), got shape %s"
                          % (op.name, op.in_sort, "/".join(map(str, ok)), arr.shape))
    return None


#: 値域の契約(``ops.py`` の 1 行目「image : gray raster, float64 in [0,1]」)を
#: 見る sort。dtype は既に fail-closed だが、**値域は書いてあるだけで誰も検査して
#: いなかった**(2026-09-08)。
_RANGE_CONTRACT_SORTS = frozenset({"image", "color"})

#: [0,1] からこれだけ外れたら契約違反とみなす(丸め・フィルタのわずかな
#: オーバーシュートを弾かないための幅)。
_RANGE_SLACK = 1e-6


def _check_input_range(v, op):
    """``extra_checks='on'`` のとき、``image`` の値域 [0,1] を fail-closed で見る。

    ★なぜ要るか(2026-09-08 実測): 進化 op の**しきい値は絶対値**で書かれている。
    µm 単位の高さ場(値域 0〜50)を ``auto_threshold`` にそのまま渡すと、Otsu は
    「0.5 µm」の位置で切り、blob が **387 個**出た(正解 256)。例外も NaN も出ない。
    画像 530 本を尺度 ×1000 / ×0.001 で掃引すると、**328 本(61.9 %)が
    op(k·x) を op(x) からは説明できない**(残りは 65 本が斉次、81 本が不変)。
    つまり単位つきの量を渡す経路は op ごとの罠ではなく**入口の契約の問題**。

    既定では見ない —— 進化器は正規化した絵しか流さないし、意図して範囲外を
    渡している呼び手を壊さないため(``fssystem`` の ``tightens_only`` 規約)。
    """
    if _fssys().get_system("extra_checks") != "on":
        return None
    if op.in_sort not in _RANGE_CONTRACT_SORTS:
        return None
    a = np.asarray(v)
    if a.dtype.kind != "f" or a.size == 0:
        return None
    lo, hi = float(np.nanmin(a)), float(np.nanmax(a))
    if lo >= -_RANGE_SLACK and hi <= 1.0 + _RANGE_SLACK:
        return None
    return ValueError(
        "%s: the '%s' contract is float in [0, 1] but this input spans "
        "[%.6g, %.6g]. Absolute thresholds inside the op then cut in the wrong "
        "place with no error (measured: a height field in um gave 387 blobs "
        "against a true 256). Normalise first, or drop extra_checks='on' if the "
        "range is deliberate" % (op.name, op.in_sort, lo, hi))


#: 2-D 画像として読める 3-D 配列の最終軸の長さ(グレー 1 / RGB 3 / RGBA 4)。これ以外は体積。
_IMAGE_LAST_AXIS_OK = (1, 3, 4)


def _check_image_volume_axis(v, op):
    """``extra_checks='on'`` のとき、image/region 用の op に**立体**(最終軸が 1/3/4 でない 3-D 配列)が渡るのを断る。

    既定の挙動は変えない(opt-in)。``_NDIM_OK["image"] = (2, 3)`` は (H, W, 3) のカラー画像を通すために
    3-D をわざと受けるが、その結果 8x8x8 のような**立体**も例外なしで通り、同じ形が返る
    (docs/KNOWN_ISSUES.md §34 の同じ根 —— 色軸と空間軸を入口で区別していない)。
    ここでは「最終軸が 1/3/4 の 3-D = カラー」「それ以外 = 立体」と読み、立体は volume 型の op へ導く。
    Opt-in sibling of the range check: an (8, 8, 8) array is a volume, not a colour image; the 2-D op
    would silently run it as a stack. Default behaviour unchanged.
    """
    if op.in_sort not in ("image", "region"):
        return None
    if _fssys().get_system("extra_checks") != "on":
        return None
    arr = v if isinstance(v, np.ndarray) else None
    if arr is None or arr.ndim != 3 or arr.shape[-1] in _IMAGE_LAST_AXIS_OK:
        return None
    return ValueError(
        "op %r is a 2-D %s op but got a 3-D array of shape %s (last axis %d is not 1/3/4, so it is not a "
        "colour image). A volume needs a volume op (see fullseye.op_find); to run the 2-D op per slice, "
        "loop over the first axis. extra_checks='on' refuses it; drop that system setting if the stack "
        "is deliberate" % (op.name, op.in_sort, arr.shape, arr.shape[-1]))


def _fssys():
    import fssystem
    return fssystem


def _check_input_empty(v, op):
    """0 サイズのラスタ入力を 1 文で断る(None なら問題なし)。

    ★2026-09-19 の全 op 走査(scratchpad probe_degenerate、image/region 入力 681 op × 7 種の退化入力):
    空配列 (0,0) は **271 op が 49 種類のばらばらな生エラー**(numpy の reduction / OpenCV の assert /
    FFT の data points 0 / ZeroDivisionError / NoneType.astype …)で落ち、410 op は空や定数を黙って返した。
    空のフレームは「読めなかった」「ROI が画像の外」の下流症状なので、どの op でも同じ文で上流を指す。
    方針は他の入力検査と同じ(raise で止まり、fallback / warn では記録して sort の既定値)。
    """
    if op.in_sort not in _REAL_RASTER_SORTS:
        return None
    arr = v if isinstance(v, np.ndarray) else None
    if arr is not None and arr.size == 0:
        return ValueError(
            "op %r: empty input (shape %s) — nothing to process. An empty frame usually means a failed "
            "read or an ROI that lies off the image; check the step upstream (read_image / crop)"
            % (op.name, arr.shape))
    return None


def _annotate_raw(e, name, v) -> None:
    """op の中から出た生の例外に、**型も文も変えず** op 名と入力の形を注記する(Python 3.11+ の add_note)。

    ★2026-09-19 の全 op 走査: 1×1 / 2×2 の入力で kornia の「Padding size should be less than the
    corresponding input」、numpy の「Shape of array too small to calculate a numerical gradient」、skimage の
    「invalid entry in coordinates array」など、**どの op が・どんな入力で**投げたかが文に無い例外が 9〜19 群
    あった。``on_error="raise"`` の約束は「op の本当の例外をそのまま」なので包み直さず、注記だけ足す。
    """
    add = getattr(e, "add_note", None)
    if add is None or name in str(e):
        return
    arr = v if isinstance(v, np.ndarray) else None
    shape = arr.shape if arr is not None else type(v).__name__
    dt = str(arr.dtype) if arr is not None else "-"
    try:
        add("fullseye: raised inside op %r on input shape %s dtype %s — a raw library error here usually "
            "means the input is too small, empty or outside the op's domain (the op note lists its "
            "constraints: fullseye.op_find(%r))" % (name, shape, dt, name))
    except Exception:  # noqa: BLE001 - a note must never replace the original error
        pass


def _guard_input(v, op, policy):
    err = (_check_input_empty(v, op) or _check_input_sort(v, op) or _check_channel_axis(v, op)
           or _check_input_range(v, op) or _check_image_volume_axis(v, op))
    if err is None:
        return
    if policy == "raise":
        raise err
    _bs.record(op.name, err, op.out_sort, source="input")


# ---- integer input: fail-closed instead of silently wrong -------------------- #
# The public contract is "image = H*W float64 in [0,1]" (module docstring), but the
# facade used to accept an integer array and hand it straight to the op. The core
# ops call ``ndimage.*`` with no dtype argument, so a uint8 image was filtered AS
# uint8 and came back uint8 (gaussian / mean_box / gerode / rotate_img), float16
# (sobel_mag) or all-ones (threshold: ``v > 0.5`` on 0..255). No exception, a
# plausible-looking array, a different answer — the third state between "accept"
# and "reject" (survey §1.3 / §2.1 / §5.3 item 1).
#
# The policy is the ``on_error`` policy, like every other degradation:
#   "raise"              -> ValueError naming the dtype and the contract (fail-closed)
#   "fallback" / "warn"  -> convert explicitly and RECORD it (source="input")
#
# ``region`` inputs are deliberately NOT touched: an int {0,1} mask is a legitimate
# region and ``_coerce_input`` already re-types it without rescaling.
#
# ★2026-11-05(1.0 前の修正 typed-dtype): the typed bridge opened sorts whose values
# are the SAME [0,1] pixel values as ``image`` — ``video`` (T,H,W[,3]) frames,
# ``rgbimage`` (H,W,3) linear RGB, ``lightfield`` (V,U,H,W) views — but the set
# stayed at the three original sorts, so a uint8 video passed ``on_error="raise"``
# and ``tb_temporal_bandpass`` / ``tb_temporal_band_power`` returned the x255 /
# x255**2 answer with no exception and no record (the other 14 video ops are
# scale-equivariant or thresholded and happened to agree). Every entry
# (``apply``, the n-ary tier, ``template=``, ``run_pipeline`` CPU/GPU,
# ``FullseyeEngine.run_cached`` and the MCP stages, which call ``fullseye.apply``)
# reads THIS set, so widening it here is what makes them agree.
#
# Deliberately NOT here — their values are not pixel values, an integer can be the
# meaning, and /255 would be a silent unit change (the opposite bug):
#   counts (photon counts, int64 by contract), cimage / beatcube (complex fields),
#   qimage (quaternion: signed Riesz pairs, QFT spectra far outside [0,1]),
#   signal / matrix / points / keypoints (profiles, linear algebra, coordinates),
#   region (int masks, see above), contour / feature / match / any.
_DTYPE_CONTRACT_SORTS = frozenset({"image", "color", "volume",
                                   "video", "rgbimage", "lightfield"})
_DTYPE_FULL_SCALE = {"uint8": 255.0, "uint16": 65535.0}


def _dtype_scale(a):
    """Divisor mapping *a*'s integer dtype onto the float64 [0,1] contract.

    uint8 / uint16 are the documented sensor dtypes and get their full scale. Any
    other integer dtype has no agreed full scale, so an array that is already inside
    [0,1] (an int mask) is only re-typed, and anything wider is divided by the
    dtype's maximum. Whichever branch runs, the conversion is recorded.
    """
    s = _DTYPE_FULL_SCALE.get(a.dtype.name)
    if s is not None:
        return s
    if a.size == 0:
        return 1.0
    if float(a.min()) >= 0.0 and float(a.max()) <= 1.0:
        return 1.0                                   # already contract-valued; only the dtype is off
    try:
        return float(np.iinfo(a.dtype).max)
    except ValueError:                               # not an integer dtype after all
        return 1.0


def _pu_contract(pu, op, policy, *, in_sort=None, name=None):
    """The :func:`_contract_dtype` rule for a :class:`PrecisionUnion`, done lazily.

    Returns a float64-contract union, or ``None`` when the conversion cannot be
    decided from the dtype alone (an int dtype outside the documented sensor
    dtypes picks its divisor from the DATA in ``_dtype_scale``) — the caller then
    materialises and takes the normal path. The conversion is a pure gain, so it is
    ``scale_shift(1/s, 0)``: codes untouched, and a lossless union stays lossless
    (``atol`` scales by ``1/s``). The same ledger record / ``on_error="raise"``
    refusal as the dense rule, so an integer input is never silently accepted.
    """
    in_sort = op.in_sort if in_sort is None else in_sort      # NaryOp has in_sorts[i]
    name = op.name if name is None else name
    if np.issubdtype(pu.dtype, np.floating):
        return pu
    if in_sort not in _DTYPE_CONTRACT_SORTS:
        return pu                                    # no conversion on the dense path either
    kind = pu.dtype.kind
    if kind not in "bui":
        return pu                                    # complex etc.: unchanged, as dense
    if kind == "b":
        s, how = 1.0, "bool -> float64 {0,1}"
    else:
        s = _DTYPE_FULL_SCALE.get(pu.dtype.name)
        if s is None:
            return None                              # data-dependent divisor: materialise
        how = "%s -> float64 (/%g)" % (pu.dtype, s)
    if policy == "raise":
        raise ValueError(
            "op %r expects a %s of float64 in [0,1] (the fullseye contract), got a "
            "PrecisionUnion of dtype %s. Convert explicitly (e.g. pu.scale_shift(1/255, 0) "
            "for uint8) or build the union from a float array." % (name, in_sort, pu.dtype))
    _bs.record(name,
               ValueError("dtype_converted: %s; the contract is float64 in [0,1]" % how),
               op.out_sort, source="input")
    return pu.scale_shift(1.0 / s, 0.0)


#: 実数のラスタしか受けない sort。複素は cimage の op が受ける(fullseye.op_find("complex"))。
_REAL_RASTER_SORTS = frozenset({"image", "region", "volume", "color"})


def _unwrap_image(v):
    """``fullseye.Image``(unified の画像チェーン)が来たら中の配列に剥がす。それ以外はそのまま。

    ★2026-09-20(GenSpark 第 54・55 報 N188、再現): ``apply(fullseye.Image(img), "gaussian")`` が
    「expects a image array with at least one dimension, got a scalar Image」—— ``np.asarray(Image)`` が 0 次元の
    object 配列になるため。Image は「配列を持つ器」で、剥がし方は一意(``.array``)なので、ここで剥がす。
    型名で判定するのは unified を api から import しないため(unified が api を import する側)。
    """
    if not isinstance(v, np.ndarray) and type(v).__name__ == "Image" and hasattr(v, "array"):
        return v.array
    return v


#: 第 2 入力が畳み込みの核(マスク)である n-ary op。形の一致を要求しない。
_NARY_KERNEL_SECOND = frozenset({"convol_image"})


def _reject_untyped(v, op_or_sort) -> None:
    """数値として読めない配列と、実数 sort への複素配列を **方針に依らず** TypeError で止める。

    ``on_error`` の 3 方針は「op が失敗したとき、sort として妥当な値へ落とすか止めるか」の
    選択で、**変換の定義が無い入力**には落とし先が無い —— 文字列配列を「全 0 の画像」に
    するのは fallback ではなく嘘になる。uint8 → /255 のように**定義された変換**がある
    dtype だけが ``_contract_dtype`` の方針の対象。

    ★2026-09-19 の外部レビュー: (N3) 文字列配列が 0.2.0 では無警告の全 0、いまの木では
    ``np.clip`` の生の UFuncTypeError —— どちらも原因が読めない。(#11) 複素配列は numpy の
    ComplexWarning だけで**虚部が捨てられ**、実部だけの結果が下流へ流れていた(``on_error=
    "raise"`` でも止まらない)。|z| / Re / arg のどれを取るかは呼ぶ側の判断なので、ここでは
    選ばずに止める。
    """
    sort = op_or_sort if isinstance(op_or_sort, str) else op_or_sort.in_sort
    name = "" if isinstance(op_or_sort, str) else " %r" % op_or_sort.name
    if isinstance(v, np.ndarray):
        a = v
    elif sort in _REAL_RASTER_SORTS and not isinstance(v, (list, tuple)):
        # ★2026-09-20(GenSpark 第 26 報 N97): 素の str / dict / スカラーは ndarray でないのでここを素通りし、
        # 既定の fallback 方針では**入力がそのまま**返っていた(``apply("abc", "gaussian") == "abc"``)。
        # raster を取る op には、配列にしてから同じ検査を掛ける。list / tuple は数値の入れ子として下で配列化される。
        try:
            a = np.asarray(v)
        except Exception:  # noqa: BLE001 - cannot even become an array
            raise TypeError("op%s expects a numeric %s array, got %s" % (name, sort, type(v).__name__)) from None
    else:
        return
    if sort in _REAL_RASTER_SORTS and a.ndim == 0:
        raise TypeError("op%s expects a %s array with at least one dimension, got a scalar %s (%r)"
                        % (name, sort, type(v).__name__, v if isinstance(v, (str, bytes, int, float)) else "..."))
    if a.dtype.kind in "USOVMm":          # str / bytes / object / void / datetime / timedelta
        raise TypeError(
            "op%s expects a numeric %s array, got dtype %s — strings, objects and dates have no "
            "image meaning; convert to float64 in [0,1] first (e.g. arr.astype(np.float64) / 255.0)"
            % (name, sort, a.dtype))
    if a.dtype.kind == "c" and sort in _REAL_RASTER_SORTS:
        raise TypeError(
            "op%s expects a real %s (float64 in [0,1]), got complex dtype %s. numpy would silently "
            "discard the imaginary part; choose explicitly — np.abs(z) (magnitude), z.real, or "
            "np.angle(z) — or use the complex-field ops (in_sort 'cimage': fullseye.op_find('complex'))"
            % (name, sort, a.dtype))


def _contract_dtype(v, op, policy, *, in_sort=None, name=None):
    """Bring an integer/bool image onto the float64 [0,1] contract, or refuse it.

    Returns the value to run the op on. Independent of ``coerce`` (which is about
    the *sort*, not the dtype): a dtype outside the contract is wrong for every
    caller, and staying silent is what produced the wrong answers above.

    ``in_sort`` / ``name`` override ``op.in_sort`` / ``op.name`` for one input of an
    n-ary op (``NaryOp`` has ``in_sorts[i]``), exactly as in :func:`_pu_contract`.
    """
    in_sort = op.in_sort if in_sort is None else in_sort
    name = op.name if name is None else name
    if in_sort not in _DTYPE_CONTRACT_SORTS:
        return v
    a = v if isinstance(v, np.ndarray) else None
    if a is not None and a.dtype.kind == "f" and a.dtype.itemsize < 8:
        # ★float16 / float32 → float64 の昇格は無損失(値も範囲も変わらない)なので記録しない(2026-09-20、
        # GenSpark N29): float16 は scipy.ndimage が扱えず op が RuntimeError → fallback で**入力のコピー**が
        # 返っていた。float32 は op が float32 で走り float32 を返していた(契約は float64)。
        return a.astype(np.float64)
    if a is None or a.dtype.kind not in "bui":
        return v                                     # float64 / complex / non-array: unchanged
    if policy == "raise":
        raise ValueError(
            "op %r expects a %s of float64 in [0,1] (the fullseye contract), got dtype %s. "
            "Convert explicitly, e.g. img.astype(np.float64) / 255.0 for uint8 — the core "
            "operators run scipy.ndimage with no dtype argument, so an integer image is "
            "filtered as an integer and the result is a different image, not a slower one."
            % (name, in_sort, a.dtype))
    if a.dtype.kind == "b":
        out = a.astype(np.float64)
        how = "bool -> float64 {0,1}"
    else:
        s = _dtype_scale(a)
        out = a.astype(np.float64) if s == 1.0 else a.astype(np.float64) / s
        how = "%s -> float64 (/%g)" % (a.dtype, s)
    _bs.record(name,
               ValueError("dtype_converted: %s; the contract is float64 in [0,1]" % how),
               op.out_sort, source="input")
    return out


def _run_guarded(name, fn, policy, out_sort=None, v=None):
    """Run ``fn()`` under the error policy, attributing any fallback to *name*.

    The facade is the OUTER boundary: a core op (ops.py) carries no guard of its own,
    so its exception is caught here — recorded (source ``"op"``) and turned into the
    declared-sort fallback under ``"fallback"``/``"warn"``, propagated under ``"raise"``.
    Inner guards (backends) already record; ``"warn"`` silences their once-per-op
    warning and emits one warning per CALL instead (no duplicate on first failure).
    """
    m = _bs.mark()
    with _bs.current_op(name):
        if policy == "raise":
            with _bs.strict_mode(True):
                try:
                    return fn()
                except Exception as e:      # noqa: BLE001 - annotate (op name + input shape), never swallow
                    _annotate_raw(e, name, v)
                    raise
        try:
            if policy == "warn":
                with _bs.quiet_warnings():
                    out = fn()
            else:
                out = fn()
        except _bs.MissingDependencyError:   # fail-closed under every policy (see backend_safe)
            raise
        except Exception as e:           # noqa: BLE001 - recorded, sort-valid fallback
            if policy == "warn":
                with _bs.quiet_warnings():
                    _bs.record(name, e, out_sort, source="op")
            else:
                _bs.record(name, e, out_sort, source="op")
            out = _bs.fallback(v, out_sort)
    if policy == "warn":
        evs = _bs.events_since(m)
        if evs:
            if all(_bs._is_dtype_conversion(e["error"]) for e in evs):
                # on_error="warn" は呼び出しごとに出す方針(明示の指定)。通常の型変換は劣化ではないので中立の文面。
                warnings.warn("fullseye: %r input converted (%s)"
                              % (name, "; ".join(e["error"].split("dtype_converted:", 1)[1].strip() for e in evs)),
                              FullseyeFallbackWarning, stacklevel=4)
            else:
                warnings.warn("fullseye: %r degraded to a fallback (%s)"
                              % (name, "; ".join(e["error"] for e in evs)),
                              FullseyeFallbackWarning, stacklevel=4)
    return out


# core op name -> accel key, built ONCE. The comprehension used to run on every
# single ``apply`` (90+ entries per call — survey §1.7 / §5.3 item 4). Keyed on the
# identity+size of the table so a test that swaps ``accel.ACCEL`` still gets the
# right answer instead of a stale cache.
_ACCEL_REV: tuple = (None, None)


def _accel_reverse(accel) -> dict:
    """Cached ``{core_op_name: accel_key}`` reverse index of ``accel.ACCEL``.

    Same value the per-call dict comprehension produced (later keys win, exactly as
    before), just not rebuilt 90 entries at a time on every call.
    """
    global _ACCEL_REV
    tag = (id(accel.ACCEL), len(accel.ACCEL))
    if _ACCEL_REV[0] != tag:
        _ACCEL_REV = (tag, {c: k for k, (_f, c, _h) in accel.ACCEL.items()})
    return _ACCEL_REV[1]


def _try_fast(op, v, a, b):
    """CPU fast-twin path (``fast.py``, cv2/IPP). ``_NOACCEL`` when there is no twin.

    Same shape as :func:`_try_accel`: OpenCV/``fast`` ABSENT is silent (``ImportError``),
    an input the twin cannot serve faithfully is silent too (``FastUnsupported`` — that
    is an absence, not a failure), and anything else is recorded with ``source="fast"``
    and re-raised under ``on_error="raise"``.
    """
    try:
        import fast as _fast
    except ImportError:
        return _NOACCEL
    if op.name not in _fast.FAST or (op.name in _FAST_OPEN and not _bs.is_strict()):
        return _NOACCEL                  # breaker open; strict mode retries so "raise" can raise
    try:
        return _fast.apply_fast(op.name, v, a, b)
    except _fast.FastUnsupported:
        return _NOACCEL                  # no faithful twin for THIS input: core, no ledger noise
    except Exception as e:               # noqa: BLE001
        if _bs.is_strict():
            raise
        _FAST_OPEN.add(op.name)          # breaker opens: no more twin attempts until reset_fast()
        _bs.record(op.name, e, op.out_sort, source="fast")
        return _NOACCEL


def _try_accel(op, v, a, b, device):
    """GPU single-op path. Returns ``_NOACCEL`` when there is nothing to accelerate.

    torch/accel ABSENT is the documented silent case (``ImportError``). Anything else
    — a broken kernel, a CUDA error — used to be swallowed by ``except Exception: pass``
    and became a silent CPU result; it is now recorded (source ``"gpu"``) and re-raised
    under ``on_error="raise"``.
    """
    try:
        import accel
    except ImportError:
        return _NOACCEL
    try:
        accel_name = _accel_reverse(accel).get(op.name)
    except Exception as e:               # noqa: BLE001 - malformed table is a bug, not an absence
        if _bs.is_strict():
            raise
        _bs.record(op.name, e, op.out_sort, source="gpu")
        return _NOACCEL
    if accel_name is None or (op.name in _GPU_OPEN and not _bs.is_strict()):
        return _NOACCEL                  # breaker open; strict mode retries so "raise" can raise
    _falls_back = getattr(accel, "_b_falls_back", None)
    if _falls_back is not None and _falls_back(accel_name, a, b):
        # 敵対的検証 2026-11-05 第 2 巡 T6: kernel は b の選ぶ端の扱い・構造要素を実装していない → core
        return _NOACCEL
    try:
        if str(device) == "cuda" and getattr(accel, "_HAS_TORCH", False) and not cuda_available():
            # torch が「CUDA なし」と答える機械では torch の kernel を起こさない(N117 の説明で記録して CPU へ)。
            # 以前は torch の生の例外に任せていたので、torch.cuda.is_available() だけが False の機械
            # (GPU のある loco で is_available を差し替えた門)では kernel が走ってしまい門が落ちていた。
            # torch を持たない差し替えの accel 表(故障注入の門)は従来どおり kernel を呼ぶ。
            raise RuntimeError("torch.cuda.is_available() is False")
        return accel.run_batch(accel_name, [v], a, b, device)[0]
    except Exception as e:               # noqa: BLE001
        e = _explain_gpu_failure(device, e)
        if _bs.is_strict():
            raise e
        _GPU_OPEN.add(op.name)           # breaker opens: no more GPU attempts until reset_gpu()
        _bs.record(op.name, e, op.out_sort, source="gpu")
        return _NOACCEL


def _try_accel_nary(nop, inputs, a, b, device):
    """n-ary 版の :func:`_try_accel`(第 3 便)。台帳は ``accel.NARY_ACCEL``、遮断器は単入力と共用。"""
    try:
        import accel
    except ImportError:
        return _NOACCEL
    if nop.name not in accel.NARY_ACCEL or (nop.name in _GPU_OPEN and not _bs.is_strict()):
        return _NOACCEL
    try:
        return accel.run_nary(nop.name, inputs, a, b, device)
    except Exception as e:               # noqa: BLE001
        e = _explain_gpu_failure(device, e)
        if _bs.is_strict():
            raise e
        _GPU_OPEN.add(nop.name)
        _bs.record(nop.name, e, nop.out_sort, source="gpu")
        return _NOACCEL


def _try_shadow(op, v, a, b):
    """許可リストの GPU 経路(:mod:`gpu_shadow`、CuPy)。``_NOACCEL`` = 走らなかった(CPU で続く)。

    失敗は ``_try_accel`` と同じ扱い: 台帳に ``source="gpu"`` で記録し、op の遮断器を開け、
    ``on_error="raise"`` では投げ直す。
    """
    import gpu_route
    r = gpu_route.route(op.name, "single")
    if r is None or r.kind != "shadow":
        return _NOACCEL
    if op.name in _GPU_OPEN and not _bs.is_strict():
        return _NOACCEL
    try:
        return gpu_route.run_single(r, op.name, v, a, b)
    except Exception as e:               # noqa: BLE001
        if _bs.is_strict():
            raise
        _GPU_OPEN.add(op.name)
        _bs.record(op.name, e, op.out_sort, source="gpu")
        return _NOACCEL


def _explain_gpu_failure(device, e):
    """★2026-09-20(GenSpark 第 33 報 N117): CUDA の無い環境で device="cuda" を渡すと torch の生文
    「Torch not compiled with CUDA enabled」が台帳に載り(raise 方針ではそのまま例外)、何が起きたか読めなかった。
    要求した device と検出結果を 1 文で添える —— 元の例外文は残す(故障の注入テストと診断のため)。"""
    if str(device) in ("cpu", "None"):
        return e
    try:
        import torch
        available = bool(torch.cuda.is_available())
        why = "torch %s: torch.cuda.is_available() is False" % torch.__version__
    except Exception as exc:             # noqa: BLE001 - torch absent / broken: same answer, different reason
        available, why = False, "torch could not be imported: %s: %s" % (type(exc).__name__, str(exc)[:120])
    if available:
        return e
    return RuntimeError("device=%r requested but CUDA is not available here (%s) — %s: %s — the op ran on the CPU"
                        % (device, why, type(e).__name__, str(e)[:200]))


def apply(image, name: str, a: float = 0.5, b: float = 0.5, coerce: bool = True,
          device: str = "cpu", on_error: str | None = None, template=None,
          fast: bool | None = None, allow_nonfinite: bool = False):
    """Apply one operator to *image* and return its raw output.

    image  -> image/region  : returns a float64 ndarray
    region -> feature        : returns a Python float (the scalar measurement)
    *      -> contour        : returns the XLD dict {"shape", "cs"}
    [x1, x2] -> nary op      : *image* may be a LIST of inputs for the n-ary tier
                               (``add_image``, ``union2`` … — see ``list_ops(tier)``)

    With ``coerce=True`` (default) a grayscale array handed to a ``region`` op is
    binarised at 0.5 and a bool mask is re-typed to float64, matching the CLI —
    see :func:`_coerce_input` for the exact rule (an in-range two-level array is
    left to the op's own 0.5 binarisation). Pass ``coerce=False`` to feed the
    array through untouched.

    An integer or bool *image* is **not** the contract (float64 in [0,1]): it is
    converted (``/255`` for uint8, ``/65535`` for uint16, re-typed for bool) and the
    conversion is recorded in the ledger, or refused outright under
    ``on_error="raise"``. It used to be handed to the op unchanged, which produced a
    uint8/float16/all-ones result with no exception — see :func:`_contract_dtype`.

    ``device`` (default ``"cpu"``, so the same call gives the same numbers on every host;
    ``"auto"`` = CUDA when available, worth the transfer for this op
    and image size, and enough VRAM is free, else CPU, see :func:`resolve_device` and
    :func:`explain_device`; ``FULLSEYE_DEVICE`` overrides): ``"cuda"`` runs accel-enabled ops
    on the GPU, and ops on the measured allow-list through :mod:`gpu_shadow` when CuPy is
    present; on a host without CUDA the op
    runs on the CPU and the reason is recorded in the fallback ledger (``on_error="raise"`` raises it).
    torch/accel *absent* falls back to CPU silently (documented); a kernel that
    FAILS is recorded in the fallback ledger and raises under ``on_error="raise"``.

    ``fast`` (default ``None`` = read ``FULLSEYE_FAST``, i.e. **off**): on the CPU,
    run the op's parity-gated cv2 twin from ``fast.py`` when it has one (gaussian,
    box, median, gray morphology, sobel/laplace/prewitt, dog, unsharp, std, canny —
    ``fast.FAST``). Same answer (``fast.parity``), several times faster; a twin that
    fails is recorded with ``source="fast"`` and the core op runs instead.

    **Caller errors are refused outright, whatever ``on_error`` is**: *name* not a
    ``str`` (swapped arguments), *image* ``None``, *a*/*b* not numeric or non-finite
    raise ``TypeError`` / ``ValueError``. *a*/*b* outside 0..1 are clamped and
    recorded in the ledger (refused under ``on_error="raise"``). Fail-soft is for
    runtime degradation, not for a wrong call — swallowing the latter used to hand
    the caller their own input back as the "result".
    ``on_error``: ``"fallback"`` (default; sort-valid fallback, recorded, warns once
    per op), ``"warn"`` (warn on every fallback of this call) or ``"raise"``
    (fail-closed). ``None`` reads ``FULLSEYE_ON_ERROR``. See :func:`fallbacks`.

    ``template``: for the matching ops (``ncc_locate`` / ``shape_locate``) the
    template image to locate; it is set for this call only (thread-local) and the
    previous template is restored afterwards. Without one those ops return the
    no-match vector ``[0, 0, 0]`` — see :func:`set_match_template`.

    A :class:`PrecisionUnion` *image* (float) runs an op listed in
    ``precision_union.LAZY_OPS`` (``invert``, ``scale_clip``, ``identity``) lazily —
    per-tile header algebra + clip, O(#tiles), returning a union — and any other op
    by materialising once. Integer/bool unions always materialise so the ``/255``
    contract conversion and its ledger record happen on the normal path.

    **A non-finite input is refused, whatever ``on_error`` is** (2026-10-23): a float
    array (image / volume / points / signal, every input of an n-ary list, the numeric
    leaves of a dict such as an XLD contour) holding a single NaN or ±inf raises
    ``FsValueError("<op>: input contains NaN or infinity")`` before the op runs. The
    audit ``docs/NAN_INPUT_AUDIT.md`` measured 431 ops that turned a NaN input into a
    *finite, plausible* answer with no error — the third state between accept and
    reject — so the entry refuses it instead of guessing. Integer / bool arrays cannot
    hold NaN and are not scanned; a :class:`PrecisionUnion` is not scanned either.
    ``allow_nonfinite=True`` hands the array to the op unchanged (the single escape
    hatch; the answer is then whatever the implementation does with NaN).
    """
    policy = _policy(on_error)
    decision = _decide(device, (name,), getattr(image, "shape", None), 1)
    _DECISION.value = decision
    device = decision["resolved"]
    if decision.get("reason") == "chain_only":
        # 鎖の枠だけの経路(常駐でしか CPU に勝たない)は、明示の cuda でも単独では GPU に送らない。
        # 送ると「cpu / chain_only」と説明しながら GPU で走る(説明と実行が食い違う)。
        device = "cpu"
    shadow = decision.get("path") == "allow_single" and decision["device"] == "cuda"
    if template is None:
        return _apply_impl(image, name, a, b, coerce, device, policy, fast, allow_nonfinite, shadow=shadow)
    template = _check_template(template, name, policy, allow_nonfinite)
    prev = _ops._MATCH_CTX.get("template")
    _ops.set_match_template(template)
    try:
        return _apply_impl(image, name, a, b, coerce, device, policy, fast, allow_nonfinite, shadow=shadow)
    finally:
        _ops.set_match_template(prev)


def _check_template(template, name, policy, allow_nonfinite=False):
    """``apply(template=...)`` のテンプレートに、入力画像と同じ入口の契約を当てる(返り値 = 走らせる値)。

    ★2026-11-05(敵対的検証 C7): テンプレートは ``ncc_locate`` / ``shape_locate`` の 2 本目の入力なのに
    検査が 1 つも無く、NaN 1 画素のテンプレートで ``on_error="raise"`` でも ``[0, 0, 0]``(no-match)が
    例外も台帳記録も無く返っていた(同じ NaN を画像側に入れると拒否される)。画像と同じ順で:
    ``fullseye.Image`` を剥がす → 非有限は方針に依らず拒否(``allow_nonfinite=True`` が唯一の抜け道)→
    数値でない dtype は TypeError → 整数・bool は ``/255`` などで契約へ(記録、``raise`` では拒否)→
    空・次元・extra_checks の値域(:func:`_guard_input`)。未知の op 名はここでは触らない(本体が断る)。
    """
    op = find_op(name) if isinstance(name, str) else None
    if op is None:
        return template
    t = _unwrap_image(template)
    if not allow_nonfinite:
        _refuse_nonfinite(t, "%s (template)" % name)
    t = np.asarray(t)
    _reject_untyped(t, op)
    t = _contract_dtype(t, op, policy)
    _guard_input(t, op, policy)
    return t


def _coerce_sort(v, sort: str):
    """The n-ary tier's version of :func:`_coerce_input`: only ``region`` inputs are touched."""
    a = np.asarray(v)
    if sort != "region":
        return a
    if a.dtype.kind == "b":
        return a.astype(np.float64)
    if a.dtype.kind in "fiu" and a.size:
        if _needs_binarise(a):                       # O(N) min/max test, same verdict as np.unique
            return (a.astype(np.float64) > 0.5).astype(np.float64)
        if a.dtype.kind in "iu":
            return a.astype(np.float64)
    return a



# ---- caller errors are not runtime degradation: refuse them outright ----------- #
# 2026-09-05 実測: `apply(name, image)` と順を逆にすると numpy の「truth value is
# ambiguous」、`a="big"` / `a=None` は op 内の TypeError を guard が拾って**利用者の
# 入力画像がそのまま結果として返る**、`a=nan` は台帳記録すら無く入力が素通り、
# `image=None` はスカラーが返る。fail-soft は**実行時の劣化**を吸収するためのもので、
# 呼び出し側の型誤りまで吸収すると「もっともらしく間違う」だけになる。
# ここは on_error に関係なく即座に拒否する(dtype 契約 `_contract_dtype` と同じ考え方で、
# 値域だけは policy に従って「切り詰めて記録」か「拒否」)。
_KNOB_NUMERIC = (int, float, np.integer, np.floating)


def _check_call_args(image, name, a, b, policy):
    """``apply`` の引数を呼び出し規約に照らす。返り値は (a, b)(値域を切り詰めたもの)。"""
    if not isinstance(name, str):
        if isinstance(image, str) and (isinstance(name, np.ndarray) or name is None):
            # ★2026-10-18(外部レビュー 0.6.0 N224): 以前の文は「got name=ndarray」だけで、受け取った image 側
            #   (op 名の文字列)を言わず、規約の説明と食い違って読めた。受け取った 2 つと、直した呼び方を言う。
            raise TypeError(
                "fullseye.apply(image, name, a, b): arguments look swapped -- got image=%r (str) and "
                "name=%s; the image comes first and the op name second: fullseye.apply(<image>, %r, a, b)"
                % (image, type(name).__name__, image))
        raise TypeError("fullseye.apply(image, name, a, b): name must be str, got %s"
                        % type(name).__name__)
    if image is None:
        raise TypeError("fullseye.apply(%r): image is None; pass a float64 array in [0,1]" % name)
    out = []
    for label, x in (("a", a), ("b", b)):
        if isinstance(x, bool):
            x = float(x)
        if not isinstance(x, _KNOB_NUMERIC):
            raise TypeError("fullseye.apply(%r): %s must be a number in 0..1, got %s"
                            % (name, label, type(x).__name__))
        x = float(x)
        if not np.isfinite(x):
            raise ValueError("fullseye.apply(%r): %s is non-finite (%r); knobs are finite values in 0..1"
                             % (name, label, x))
        if not 0.0 <= x <= 1.0:
            err = ValueError("fullseye.apply(%r): %s=%r is outside 0..1 (clamped)"
                             % (name, label, x))
            if policy == "raise":
                raise err
            _bs.record(name, err, None, source="input")
            x = min(1.0, max(0.0, x))
        out.append(x)
    return out[0], out[1]

#: :func:`_nonfinite_leaf` が降りる入れ子の深さの上限(再帰の歯止め。実際の入力は数段)。
_NONFINITE_MAX_DEPTH = 32


def _nonfinite_leaf(x, depth=0):
    """*x* の最初の非有限な浮動小数の葉を短い文で返す(無ければ None)。

    ndarray は float / complex の種だけ見る(整数・bool は NaN を持てない)。float は
    ``min`` / ``max`` が NaN を伝播し ±inf をそのまま出すので、bool 配列を作らずに済む。
    object 配列は要素ごとに降りる。list / tuple / dict は :data:`_NONFINITE_MAX_DEPTH` 段まで降りる
    (n 項 op の入力リスト、XLD の ``cs``、表の列、入れ子の表)。

    ★2026-11-04(外部監査 v0.9.0 F4): 以前は**スカラーの葉**(``{"x": nan}`` の ``nan``、
    ``[array, inf]`` の ``inf``、複素のスカラー)と object 配列を見ず、深さも 3 段で打ち切っていた ——
    ``apply({"x": nan}, "identity", on_error="raise")`` が NaN をそのまま返した(入口の契約違反)。
    """
    if isinstance(x, (bool, np.bool_)):
        return None
    if isinstance(x, (float, complex, np.floating, np.complexfloating)):
        return None if np.isfinite(x) else "non-finite value %r" % (x,)
    if isinstance(x, np.ndarray):
        if x.dtype == object:
            if depth >= _NONFINITE_MAX_DEPTH:
                return None
            for i, v in enumerate(x.flat):
                hit = _nonfinite_leaf(v, depth + 1)
                if hit is not None:
                    return "element %d: %s" % (i, hit)
            return None
        if x.size == 0 or x.dtype.kind not in "fc":
            return None
        if x.dtype.kind == "f":
            if np.isfinite(x.min()) and np.isfinite(x.max()):
                return None
        else:
            if np.isfinite(x).all():
                return None
        n = int(np.count_nonzero(~np.isfinite(x)))
        return "%d of %d values non-finite (shape %s)" % (n, x.size, x.shape)
    if depth >= _NONFINITE_MAX_DEPTH:
        return None
    if isinstance(x, dict):
        for k, v in x.items():
            hit = _nonfinite_leaf(v, depth + 1)
            if hit is not None:
                return "key %r: %s" % (k, hit)
        return None
    if isinstance(x, (list, tuple)):
        if x and all(isinstance(v, (int, float, np.integer, np.floating)) for v in x):
            return _nonfinite_leaf(np.asarray(x, dtype=np.float64), depth)
        for i, v in enumerate(x):
            hit = _nonfinite_leaf(v, depth + 1)
            if hit is not None:
                return "input %d: %s" % (i, hit)
    return None


def _refuse_nonfinite(image, name):
    """NaN / ±inf を含む入力は ``on_error`` に依らず入口で拒否する(FS_E_INVALID_ARG)。

    ★2026-10-23 の監査(``tools/audit_nan_inputs.py`` → ``docs/NAN_INPUT_AUDIT.md``): 登録 942 op
    のうち 431 op が、中央の 1 画素を NaN / +inf にした入力に対して**例外も NaN も出さず有限の
    もっともらしい答え**を返していた(NaN 282・+inf 392)。受け入れでも拒否でもない第 3 の
    状態なので、生の実装は触らず入口で止める。知った上で渡すなら ``allow_nonfinite=True``。
    """
    hit = _nonfinite_leaf(image)
    if hit is None:
        return
    raise _FsValueError(
        "%s: input contains NaN or infinity (%s). Clean or mask the values first (np.nan_to_num, "
        "np.isfinite), or pass allow_nonfinite=True to hand the array to the op unchanged -- its "
        "answer is then whatever the implementation does with NaN (docs/NAN_INPUT_AUDIT.md)"
        % (name, hit))


class _NaryInput(NamedTuple):
    """n 項 op の入力 1 本を :func:`_guard_input` に渡すための op 相当(名前・その入力の sort・出力 sort)。"""
    name: str
    in_sort: str
    out_sort: str


def _apply_impl(image, name, a, b, coerce, device, policy, fast=None, allow_nonfinite=False, shadow=False):
    a, b = _check_call_args(image, name, a, b, policy)
    nop = _nary_by_name().get(name) if find_op(name) is None else None
    if nop is not None and isinstance(image, (list, tuple)):
        # ★2026-11-05(敵対的検証 C12): 単入力の apply / run_pipeline は fullseye.Image を剥がすのに、
        #   n 項だけが剥がさず「got a scalar Image」の TypeError だった。入力ごとに同じ剥がし方
        #   (非有限の検査より前 —— Image の中身も検査する)。
        image = [_unwrap_image(x) for x in image]
    if not allow_nonfinite and (nop is not None or find_op(name) is not None):
        _refuse_nonfinite(image, name)          # a known op only: an unknown name keeps its own error below
    if nop is not None:                                  # n-ary tier: needs a LIST of inputs
        if isinstance(image, np.ndarray) or not isinstance(image, (list, tuple)):
            raise TypeError(
                "%r is an n-ary operator (arity %d, inputs %s): call "
                "fullseye.apply([%s], %r, a, b) with a list of inputs"
                % (name, nop.arity, list(nop.in_sorts),
                   ", ".join("x%d" % i for i in range(nop.arity)), name))
        if len(image) != nop.arity:
            raise TypeError("%r takes %d inputs %s, got %d"
                            % (name, nop.arity, list(nop.in_sorts), len(image)))
        if any(isinstance(x, PrecisionUnion) for x in image):
            # two unions with the same tiling run a closed op (precision_union.LAZY_NARY)
            # tile-by-tile without materialising; anything else materialises the
            # union inputs and continues on the normal n-ary path.
            lazy = _PU_LAZY_NARY.get(name)
            if (lazy is not None and nop.arity == 2
                    and all(isinstance(x, PrecisionUnion) for x in image)
                    and image[0]._same_tiling(image[1])):
                pus = [_pu_contract(x, nop, policy, in_sort=srt, name=name)
                       for x, srt in zip(image, nop.in_sorts)]
                if all(p is not None for p in pus):
                    return lazy(pus[0], pus[1], a, b)
            image = [x.to_dense() if isinstance(x, PrecisionUnion) else x for x in image]
        for x, srt in zip(image, nop.in_sorts):
            _reject_untyped(x, srt)
        inputs = [(_coerce_sort(x, srt) if coerce else np.asarray(x))
                  for x, srt in zip(image, nop.in_sorts)]
        # ★2026-11-04(外部監査 v0.9.0 F2): 単入力の apply / run_pipeline と PrecisionUnion の n-ary 経路は
        #   dtype 契約(_contract_dtype)を通るのに、密な配列の n-ary だけが通らず、uint8 の 32 + 32 が
        #   on_error="raise" でも例外も台帳記録も無く 1.0(正しくは 64/255)になっていた。入力ごとに同じ規則で。
        #   畳み込みの核(_NARY_KERNEL_SECOND の第 2 入力)は画像でなく重みの表なので、型だけ float64 にする。
        inputs = [(np.asarray(x, np.float64) if (i == 1 and name in _NARY_KERNEL_SECOND
                                                 and np.asarray(x).dtype.kind in "bui")
                   else _contract_dtype(x, nop, policy, in_sort=srt, name=name))
                  for i, (x, srt) in enumerate(zip(inputs, nop.in_sorts))]
        # ★2026-11-05(敵対的検証 C11): 単入力の apply にある _guard_input(空・次元・色軸・extra_checks の
        #   値域)が n 項に無く、空 (0, 0) / 1-D / 4-D / 0..50 の入力が on_error="raise" でも例外も台帳記録も
        #   無く通っていた。入力ごとに同じ検査(その入力の sort で)。畳み込みの核は画像でないので外す。
        for i, (x, srt) in enumerate(zip(inputs, nop.in_sorts)):
            if i == 1 and name in _NARY_KERNEL_SECOND:
                continue
            _guard_input(x, _NaryInput(name, srt, nop.out_sort), policy)
        # the n-ary functions carry no guard of their own: give them the same recorded,
        # sanitised fail-soft as every backend op (strict mode re-raises inside guard)
        def body(v0, aa, bb):
            if device != "cpu":
                res = _try_accel_nary(nop, inputs, aa, bb, device)
                if res is not _NOACCEL:
                    return res
            return nop.fn(inputs, aa, bb)
        # ★形状不一致(2026-09-19 外部レビュー #13): ラスタ同士の n-ary で形が違うと numpy の
        # 「could not be broadcast」がそのまま台帳に残り、既定の方針では**第 1 入力が
        # そのまま返る**(sort として妥当な fallback)。返り値の形だけ見た利用者には
        # 「(32,32)+(32,16) が (32,32) で成功した」と映った。何が要るかを文で言う。
        # ★ただし第 2 入力がマスク(畳み込みの核)の op は形が違って当然 —— 3×3 のマスクを
        # 画像と同じ大きさに埋めないと呼べない、では入口として壊れている(2026-10-12、例の
        # 付与で発見)。核を取る op だけ名指しで外す。
        shapes = [x.shape for x in inputs if isinstance(x, np.ndarray)]
        if (len(shapes) == len(inputs) and len(set(shapes)) > 1 and name not in _NARY_KERNEL_SECOND
                and all(s in _REAL_RASTER_SORTS for s in nop.in_sorts)):
            err = ValueError("%r: its %d raster inputs must share one shape, got %s — crop, pad or "
                             "resize explicitly first (e.g. fullseye.apply(x, 'crop_rectangle1') or "
                             "'zoom_image_size'); under on_error='fallback' the first input is returned unchanged"
                             % (name, len(inputs), shapes))

            def body(v0, aa, bb, _e=err):   # noqa: F811 - the mismatch replaces the op body on purpose
                raise _e
        w = _bs.guard(body, nop.out_sort, name=name)
        out = _run_guarded(name, lambda: w(inputs[0], a, b), policy, nop.out_sort, inputs[0])
        if nop.out_sort == "feature":
            return float(np.asarray(out).reshape(-1)[0])
        return out
    if isinstance(image, (list, tuple)):                 # legacy: a nested list IS an image
        image = np.asarray(image)

    if isinstance(image, PrecisionUnion):
        # A precision-union runs a LAZY op (precision_union.LAZY_OPS) as header
        # algebra + per-tile clip and stays a union — O(#tiles), codes untouched.
        # An integer/bool union is first brought onto the float64 [0,1] contract
        # LAZILY (a pure gain, so a lossless union stays lossless) with the same
        # ledger record / refusal as _contract_dtype; a dtype that needs the data to
        # pick its scale, or an op not in the table, materialises once instead.
        lazy = _PU_LAZY.get(name)
        feat = _PU_LAZY_FEAT.get(name)
        if lazy is not None or feat is not None:
            pu = _pu_contract(image, _resolve(name), policy)
            if pu is not None:
                # a feature (union -> scalar) is computed from the headers where the
                # op allows it and returns the same python float as the dense path
                return lazy(pu, a, b) if lazy is not None else float(feat(pu, a, b))
        image = image.to_dense()

    op = _resolve(name)
    image = _unwrap_image(image)
    _reject_untyped(image, op)
    v = _coerce_input(image, op) if coerce else image
    v = _contract_dtype(v, op, policy)
    _guard_input(v, op, policy)
    use_fast = _fast_on(fast)

    def _call():
        if device != "cpu":
            res = _try_accel(op, v, a, b, device)
            if res is not _NOACCEL:
                return res
            if shadow:                   # 手書きの GPU 経路が無く、許可リストにある op
                res = _try_shadow(op, v, a, b)
                if res is not _NOACCEL:
                    return res
        elif use_fast:
            res = _try_fast(op, v, a, b)
            if res is not _NOACCEL:
                return res
        return _ops.RT[op.name](v, a, b)

    out = _run_guarded(op.name, _call, policy, op.out_sort, v)
    if op.out_sort == "feature":
        return float(np.asarray(out).reshape(-1)[0])
    return out


_NUMBER = (int, float, np.integer, np.floating)


def _normalise_stages(image, stages, a, b) -> list:
    """*stages* を ``[(name, a, b), ...]`` に揃え、外した書き方は**原因を指す** TypeError にする。

    受ける形(全部同じ意味に落ちる):

    * ``"gaussian,sobel_amp,otsu"`` —— CLI ``fullseye pipeline`` と同じカンマ区切り
    * ``["gaussian", "sobel_amp"]`` —— 共通の ``a`` / ``b``
    * ``[("gaussian",), ("sobel_amp", 0.3), ("otsu", 0.4, 0.5)]`` —— 段ごとの位置引数
    * ``[("gaussian", {"a": 0.3}), ("otsu", {"a": 0.4, "b": 0.5})]`` —— 段ごとの dict
    * ``[{"op": "gaussian", "a": 0.3}]`` —— Studio の保存形式と同じ dict(``op`` か ``name``)

    ★2026-09-19 の外部レビュー #4 / #5 / #6: ``(name, {})`` が ``float(dict)`` の TypeError、
    文字列は 1 文字ずつ op 名として引かれ ``unknown operator 'g'``、引数を逆に渡すと
    numpy の「truth value is ambiguous」—— どれも原因が読めなかった。
    """
    if isinstance(stages, np.ndarray) or isinstance(image, str) or (
            isinstance(image, (list, tuple)) and image
            and all(isinstance(s, (str, tuple, list, dict)) for s in image)
            and not isinstance(stages, str)):
        raise TypeError(
            "run_pipeline(image, stages): the first argument is the image array and the second "
            "the stages — they look swapped (got image=%s, stages=%s)"
            % (type(image).__name__, type(stages).__name__))
    if isinstance(stages, str):
        stages = [s.strip() for s in stages.split(",") if s.strip()]
    return [_normalise_stage(i, st, a, b) for i, st in enumerate(stages)]


def _stage_knob(i, name, label, x) -> float:
    """段のノブ 1 つを :func:`_check_call_args` と同じ型の規則で float にする(値域・有限性は後段)。

    ★2026-11-05(敵対的検証 C4): 以前は dict 形(``{"op": .., "a": "0.9"}`` / ``(name, {"a": "0.9"})``)
    だけが ``float("0.9")`` で文字列を通し、tuple 形と ``apply`` は拒否していた。bool は逆で、tuple 形が
    拒否し dict 形と ``apply`` は 1.0 として通していた。**段の書き方によらず** ``apply`` の規則に揃える:
    数値(int / float / numpy の整数・浮動小数)と bool(``float(True) == 1.0``)だけを受け、他は TypeError。
    """
    if isinstance(x, bool):
        return float(x)
    if not isinstance(x, _KNOB_NUMERIC):
        raise TypeError("stage %d (%r): knobs a and b must be numbers in 0..1 (the rule of "
                        "fullseye.apply), got %s=%r (%s)" % (i, name, label, x, type(x).__name__))
    return float(x)


def _normalise_stage(i, st, a=0.5, b=0.5) -> tuple:
    """段 1 つ(5 形のどれか)を ``(name, a, b)`` にする。:func:`_normalise_stages` /
    ``engine.FullseyeEngine`` / ``engine.pipeline_states`` が共有する唯一の読み方
    (C3 / C13、2026-11-05): 未知のキー・3 個を超える位置ノブ・数値でないノブは TypeError。"""
    if isinstance(st, str):
        name, sa, sb = st, a, b
    elif isinstance(st, dict):
        name = st.get("op", st.get("name"))
        if not isinstance(name, str):
            raise TypeError("stage %d: a dict stage needs 'op' (or 'name'), got keys %s"
                            % (i, sorted(st)))
        bad = set(st) - {"op", "name", "a", "b"}
        if bad:
            raise TypeError("stage %d (%r): unknown key(s) %s — ops take only the knobs a and b"
                            % (i, name, sorted(bad)))
        sa, sb = st.get("a", a), st.get("b", b)
    elif isinstance(st, (tuple, list)):
        if not st or not isinstance(st[0], str):
            raise TypeError("stage %d: a tuple stage starts with the op name, got %r" % (i, st))
        name, rest = st[0], list(st[1:])
        if len(rest) == 1 and isinstance(rest[0], dict):
            bad = set(rest[0]) - {"a", "b"}
            if bad:
                raise TypeError("stage %d (%r): unknown knob(s) %s — ops take only a and b"
                                % (i, name, sorted(bad)))
            sa, sb = rest[0].get("a", a), rest[0].get("b", b)
        elif len(rest) <= 2 and all(isinstance(x, _NUMBER) for x in rest):
            # bool は int の部分型: apply と同じく 1.0 / 0.0 として受ける(C4、dict 形と揃える)
            # ★2026-11-04(外部監査 v0.9.0 F1): 以前は ``(rest + [a, b])[:2]`` で、``("op", 0.2)`` の
            #   省いた b に共通の **a** が入っていた(dict 形 ``{"op", "a": 0.2}`` とは別の答え)。
            #   省いた位置の分だけ、その位置の既定値で埋める。
            sa, sb = rest + [a, b][len(rest):]
        else:
            raise TypeError(
                "stage %d (%r): expected (name), (name, a), (name, a, b) or (name, {'a': .., 'b': ..}), got %r"
                % (i, name, st))
    else:
        raise TypeError("stage %d: expected an op name, a (name, a, b) tuple or a dict, got %s"
                        % (i, type(st).__name__))
    return (name, _stage_knob(i, name, "a", sa), _stage_knob(i, name, "b", sb))


def _check_chain_sorts(ops_, where: str = "run_pipeline") -> None:
    """段の列 *ops_*(:class:`ops.Op` の列)の型連鎖を、**何も走らせる前に**検査する。

    前段の出力 sort を ``engine._thread_sort`` で順に流し(``out_sort == "any"`` の
    ``identity`` などは受けた sort を保つ)、次段の ``in_sort`` と合わなければ
    ``ValueError`` で止める —— ``on_error`` の方針に依らない。``on_error`` は「op が
    実行時に失敗したとき sort として妥当な値へ落とすか」の選択で、型の合わない処理列は
    実行時の劣化ではなく呼び出し側の誤り(``_check_call_args`` と同じ扱い)。

    ★2026-10-11 の内部レビュー: 「型が不整合な処理列は実行前に除外する」と書いていたのに、
    ``run_pipeline`` は第 1 段の入力しか見ず、``engine.diagnose_stages`` は不一致を
    warning にしていたので ``is_runnable()`` が True、``FullseyeGraph`` は型を見ていなかった。
    ``[gaussian, vol_gaussian]`` や ``[blob_count, gaussian]`` が例外も台帳記録も無く
    「成功」していた。入口 3 本(run_pipeline / FullseyeEngine / FullseyeGraph)はここを通る。
    """
    import engine as _engine                     # engine imports api: resolve lazily
    cur = None
    prev = None
    for i, op in enumerate(ops_, 1):
        if cur is not None and not _engine._compatible(cur, op.in_sort):
            raise ValueError(
                "%s: type mismatch at stage %d (%s): it takes %r but stage %d (%s) outputs %r "
                "-- the chain was refused before any stage ran; insert an op that converts "
                "%s -> %s between them" % (where, i, op.name, op.in_sort, i - 1, prev, cur,
                                            cur, op.in_sort))
        cur = _engine._thread_sort(cur, op)
        prev = op.name


def _prepare_pipeline(image, stages, a, b, policy):
    """run_pipeline / ``FullseyeEngine.run_stepwise`` の前処理(**何も走らせない**)。

    返り値 = ``(image, norm, ops_)``。段の書き方の正規化、全段の op 解決(未知の名前は
    ここで KeyError / TypeError)、型連鎖の検査(:func:`_check_chain_sorts`)、段ごとの
    ノブ検査(:func:`_check_call_args` —— NaN は方針に依らず拒否、0..1 の外は記録して
    切り詰めるか ``on_error="raise"`` で拒否)を、第 1 段を走らせる前に済ませる。

    ★2026-10-11: ノブは ``apply`` だけが検査し、``run_pipeline`` / ``FullseyeEngine.run`` は
    ``("threshold", nan)`` / ``("threshold", 5.0)`` をそのまま op に渡していた(台帳も空)。
    """
    image = _unwrap_image(image)
    norm = _normalise_stages(image, stages, a, b)
    ops_ = [_resolve(name) for name, _, _ in norm]
    _check_chain_sorts(ops_)
    checked = []
    for (name, sa, sb), op in zip(norm, ops_):
        sa, sb = _check_call_args(image, op.name, sa, sb, policy)
        checked.append((name, sa, sb))
    if ops_:
        _refuse_nonfinite(image, ops_[0].name)       # the entry value, once (stage outputs are sanitised by the guard)
    return image, checked, ops_


def _pipeline_entry(v, op, coerce, policy):
    """鎖の入口の値に、第 1 段の op の入口の契約を当てる(数値でない dtype の拒否 → sort の coerce →
    dtype 契約 → :func:`_guard_input`)。返り値 = 第 1 段に渡す値。

    :func:`_pipeline_steps` の ``entry=True`` と ``FullseyeEngine.run_cached`` が共有する 1 本 ——
    run_cached はキャッシュに当たっても毎回ここを通す(2026-11-05 敵対的検証 C6)。"""
    _reject_untyped(v, op)
    v = _coerce_input(v, op) if coerce else v
    v = _contract_dtype(v, op, policy)
    _guard_input(v, op, policy)
    return v


def _pipeline_steps(image, norm, ops_, coerce, policy, use_fast, entry=True):
    """CPU の段実行の唯一の本体: 各段の後の値を順に yield する。

    ``run_pipeline`` は最後の値を、``FullseyeEngine.run_stepwise`` は全部を取る ——
    同じ本体なので ``run_stepwise(x)[-1] == run(x)``(2026-10-11: stepwise だけが
    dtype 契約と guard を飛ばし、uint8 で別の答えを返していた)。
    """
    v = image
    first = bool(entry)       # entry=False: *image* is already a mid-chain value (Studio's stage cache resumes here)
    for (name, sa, sb), op in zip(norm, ops_):
        if isinstance(v, PrecisionUnion):
            # lazy stages keep the union (see _apply_impl); the first non-lazy stage
            # materialises once and is then coerced/contracted as the entry array.
            lazy = _PU_LAZY.get(name)
            pu = _pu_contract(v, op, policy) if lazy is not None else None
            if pu is not None:
                v = lazy(pu, sa, sb)
                yield v
                continue
            v = v.to_dense()
        if first:
            v = _pipeline_entry(v, op, coerce, policy)
            first = False

        def _stage(_op=op, _v=v, _a=sa, _b=sb):
            if use_fast:
                res = _try_fast(_op, _v, _a, _b)
                if res is not _NOACCEL:
                    return res
            return _ops.RT[_op.name](_v, _a, _b)

        v = _run_guarded(op.name, _stage, policy, op.out_sort, v)
        yield v


def run_pipeline(image, stages: Iterable, a: float = 0.5, b: float = 0.5,
                 coerce: bool = True, device: str = "cpu", on_error: str | None = None,
                 fast: bool | None = None):
    """Apply a sequence of operators, threading the array through each.

    *stages* is either a list of names (one shared ``a``/``b`` for the whole
    chain, like the CLI) **or** a list of ``(name, a, b)`` tuples for per-stage
    knobs — the latter is what you want when different stages need different
    tuning (the CLI cannot do this in a single call).

    ``coerce`` applies to the entry array only: every later value is an op output
    that already carries its declared sort, and region ops binarise at 0.5
    themselves, so re-coercing mid-chain would only strip gray levels a stage may
    still want (see :func:`_coerce_input`).

    ``device`` (default ``"cpu"``; ``"auto"`` = CUDA when available and worth the transfer for this chain
    and image size, else CPU, see :func:`resolve_device`; ``FULLSEYE_DEVICE``
    overrides): ``"cuda"`` (or any non-cpu) runs the chain on the
    ``accel_bridge`` resident pipeline (unsupported ops fall back to CPU inside the
    bridge; consecutive accel ops share one transfer). torch/GPU *absent* silently
    uses the CPU path; a bridge that FAILS is recorded (source ``"gpu"``) and raises
    under ``on_error="raise"``. The GPU path uses ``ops.run_stages`` clip semantics
    (same as evolution champions) and only faithful ops go to the GPU, so task
    metrics are preserved (tests/test_accel_bridge.py).

    ``fast`` (default ``None`` = ``FULLSEYE_FAST``, i.e. off): as in :func:`apply`,
    but for the whole CPU chain — each stage that has a parity-gated cv2 twin in
    ``fast.py`` runs it. Ignored on the GPU path (the bridge is already the fast one).

    ``on_error``: as in :func:`apply`; fallbacks are attributed per stage.

    **Checked before any stage runs, whatever ``on_error`` is**: every op name resolves,
    adjacent stages agree on their sort (a ``ValueError`` names the stage and both sorts;
    ``identity``-style ``"any"`` ops keep the incoming sort) and every stage's knobs pass
    the same check as :func:`apply` (non-finite refused; outside 0..1 clamped and
    recorded, or refused under ``on_error="raise"``). See :func:`_check_chain_sorts`.
    """
    policy = _policy(on_error)
    requested, device = device, resolve_device(device)      # 値の検査はここ(段の検査より先)
    image, norm, ops_ = _prepare_pipeline(image, stages, a, b, policy)
    shadow_paths = None
    if norm:
        decision = _decide(requested, [s[0] for s in norm], getattr(image, "shape", None), 1)
        _DECISION.value = decision
        if device != "cpu":
            device = decision["resolved"]
            if decision["device"] == "cuda" and decision["_paths"]:
                # 段ごとの経路(allow_* は影の区間、chain_only で cpu になった手書き経路は CPU 区間)
                shadow_paths = list(decision["_paths"])

    if isinstance(image, PrecisionUnion) and device != "cpu":
        image = image.to_dense()      # the lazy union path is CPU-only; the GPU bridge needs a dense array
    if device != "cpu" and norm:                          # GPU 経路(accel_bridge 常駐)
        try:
            import accel_bridge as _bridge
        except ImportError:
            _bridge = None
        if _bridge is not None:
            first_op = _resolve(norm[0][0])
            _reject_untyped(image, first_op)
            v0 = _coerce_input(image, first_op) if coerce else image
            v0 = _contract_dtype(v0, first_op, policy)
            _guard_input(v0, first_op, policy)
            try:
                with _bs.current_op("run_pipeline[gpu]"):
                    if policy == "raise":
                        with _bs.strict_mode(True):
                            return _bridge.run(norm, [v0], device=device, shadow=shadow_paths)[0]
                    return _bridge.run(norm, [v0], device=device, shadow=shadow_paths)[0]
            except Exception as e:       # noqa: BLE001 - bridge failed: recorded, then the CPU path runs
                if policy == "raise":
                    raise
                if policy == "warn":
                    with _bs.quiet_warnings():
                        _bs.record("run_pipeline[gpu]", e, None, source="gpu")
                    warnings.warn("fullseye: GPU pipeline failed, running on CPU (%s)" % _bs._fmt_exc(e),
                                  FullseyeFallbackWarning, stacklevel=2)
                else:
                    _bs.record("run_pipeline[gpu]", e, None, source="gpu")

    v = image
    for v in _pipeline_steps(image, norm, ops_, coerce, policy, _fast_on(fast)):
        pass
    return v


# ---- fallback ledger (re-exported from backend_safe) ------------------------ #
fallbacks = _bs.fallbacks
fallback_counts = _bs.fallback_counts
fallback_overflow = _bs.fallback_overflow
clear_fallbacks = _bs.clear_fallbacks
strict_mode = _bs.strict_mode
set_match_template = _ops.set_match_template
FAILED_BACKENDS = _ops.FAILED_BACKENDS


# ---- discovery ------------------------------------------------------------- #
def _rows():
    # ★2026-09-20(GenSpark 第 15・16 報 N67): 4 op の入口の関門(ops.NATIVE_CRASHES_ON_DEGENERATE)は
    # 効いているのに、その事実は ops.py の中にしか無く、registry を使う側からは見えなかった。
    # 行に載せる(None = 関門なし。理由の文がそのまま値)。
    guards = getattr(_ops, "NATIVE_CRASHES_ON_DEGENERATE", {})
    # ★2026-09-20(GenSpark 第 20 報 N84): 同じ HALCON 別名を複数の op が名乗る(cv_ / sk_ の移植と
    # コアの実装)。どれが走るかは find_op の規則(完全一致 → name == halcon → _ALIAS_CANONICAL)で
    # 決まっていて曖昧ではないが、その事実が行に無かった。halcon_peers = 同じ別名を名乗る他の op。
    peers: dict = {}
    for o in _ops.REGISTRY:
        if o.halcon:
            peers.setdefault(o.halcon, []).append(o.name)
    rows = [{"name": o.name, "halcon": o.halcon, "in_sort": o.in_sort,
             "out_sort": o.out_sort, "category": o.category, "tier": "registry",
             "knobs": knob_summary(o.name), "native_guard": guards.get(o.name),
             "halcon_peers": sorted(n for n in peers.get(o.halcon, []) if n != o.name) if o.halcon else []}
            for o in _ops.REGISTRY]
    rows += [{"name": o.name, "halcon": o.halcon, "in_sort": o.in_sorts[0],
              "out_sort": o.out_sort, "category": "nary", "tier": "nary",
              "arity": o.arity, "in_sorts": list(o.in_sorts), "knobs": knob_summary(o.name)}
             for o in {id(o): o for o in _nary_by_name().values()}.values()]
    return rows


def algo_rows() -> list[dict]:
    """Rows for the opt-in general-algorithm tier (``algo.py``), shaped like ``_rows()``.

    ``tier`` = ``"z_algo"`` so they sort AFTER the image / nary ops; ``category`` is
    prefixed ``algo:`` so the op-browser category filter separates them cleanly; and
    ``backend == "general"`` marks them as a DIFFERENT computational model (seq/scalar,
    not an image raster) so the UI can show them read-only rather than let them be
    dropped into an image pipeline. Empty if the algo tier fails to import.
    """
    try:
        import algo
    except Exception:  # noqa: BLE001 - the general tier is optional; never break the image UI
        return []
    return [{"name": op.name, "halcon": None, "in_sort": op.in_sort,
             "out_sort": op.out_sort, "category": "algo:" + op.category,
             "tier": "z_algo", "backend": "general", "provenance": op.provenance,
             "desc": op.doc}          # packed-input contract (surfaced read-only in the UI help card)
            for op in algo.ALGO_REGISTRY]


def ledger_rows() -> list[dict]:
    """Rows for the typed-ledger tier (``opassist._LEDGERS``), shaped like ``_rows()``.

    ★2026-09-25(外部レポート 第 58 報 N218 の一次検証から): ``list_ops()`` は
    レジストリと n-ary しか並べず、**型付き台帳の 1,238 op(msa / gum / spc /
    stroke / halftone / optics / 3d …)を 1 つも返していなかった**。同じ欠陥は
    機械可読索引の側で 2026-09-15 に塞がれている(``imgevolve._ledger_rows``)のに、
    Python から呼ぶ探索関数だけが取り残されていた —— **片側だけ塞がった穴**である。
    「op を並べる」と名乗る関数が黙って 1,238 op を落とすと、返った件数を数えた人は
    「無い」と結論する([[feedback_registered_only_gates_miss_unregistered]])。

    台帳は ``fullseye.op_find``(語幹検索)・``fullseye.ledger``(属性呼び出し)・
    CLI の索引からは**届いていた**ので全滅ではない。欠けていたのは一覧だけ。

    族の一覧は ``opassist._LEDGERS`` を正本にする —— ``imgevolve._ledger_rows`` は
    この関数に委譲する。表を 2 つ持つと、族を足したときに片方だけ増える。
    """
    import importlib

    taken = {r["name"] for r in _rows()}
    rows, seen = [], set(taken)
    halcon = opassist.ledger_halcon_map()
    for mod_name, table in opassist._LEDGERS:
        mod = importlib.import_module(mod_name)
        entries = getattr(mod, table)
        assert isinstance(entries, dict) and entries, "%s.%s が空" % (mod_name, table)
        dim = "3d" if mod_name == "ops3d" else ("oned" if mod_name == "ops1d"
                                                else mod_name[len("ops"):])
        for name, info in entries.items():
            if name in seen:
                continue
            seen.add(name)
            ins = list(info.get("in") or [])
            rows.append({"name": name, "halcon": halcon.get(name, ""), "in_sort": ins[0] if ins else None,
                         "out_sort": info.get("out"), "category": info.get("category"),
                         "tier": "ledger", "ledger": mod_name, "dim": dim,
                         "in_sorts": ins})
    assert rows, "台帳層が空(opassist._LEDGERS が 1 op も返さない)"
    return rows


def _fold(text: str) -> str:
    """Case- and accent-insensitive key for name matching (NFKD, combining marks dropped, casefold)."""
    import unicodedata
    return "".join(ch for ch in unicodedata.normalize("NFKD", str(text)) if not unicodedata.combining(ch)).casefold()


def list_ops(sort: str | None = None, search: str | None = None,
             include_algo: bool = False, include_ledger: bool = False) -> list[dict]:
    """Every operator as a uniform dict. Filter by input *sort* and/or *search*
    (substring over name/halcon/category). *include_algo* (default False, so the image
    focus is unchanged for every existing caller) appends the general-algorithm tier.

    ★*include_ledger* (default False, same reason) appends the **typed-ledger tier** —
    1,238 ops (``msa_*`` / ``gum_*`` / ``spc_*`` / ``stroke_*`` / optics / 3-D …) that
    this function returned **nowhere** until 2026-09-25. Without it the count here is the
    image vocabulary (registry + n-ary), NOT the op count of the package: the machine-readable
    index (``docs/OP_INDEX.json``, what the CLI and MCP read) lists all four tiers. The ledger
    was always reachable through :func:`op_find`, :func:`op_assist` and ``fullseye.ledger`` —
    it was the *listing* that was blind. See :func:`ledger_rows`.

    Each row carries ``"knobs"`` = :func:`knob_summary` (what ``a`` / ``b`` do, as measured;
    ``None`` when the op has not been measured) and, for the ``"nary"`` tier, ``"arity"`` and
    ``"in_sorts"`` (call those with ``apply([x0, x1], name)``). Registry rows also carry
    ``"native_guard"``: the reason text when the op's native backend is known to crash or hang on
    degenerate input and an entry gate refuses such input first (``ops.NATIVE_CRASHES_ON_DEGENERATE``),
    ``None`` otherwise, and ``"halcon_peers"``: the other registry ops that claim the same HALCON
    alias (``[]`` when the alias is unique) — :func:`find_op` resolves an alias to the op whose own
    name equals it, else to the explicit ``_ALIAS_CANONICAL`` row, so the choice is fixed, not the
    first hit.

    *sort* and *search* are both case-insensitive, and *search* ignores accents
    (``"ötsu"`` finds ``otsu``; 2026-09-20, GenSpark N85 — ``sort="IMAGE"`` used to match nothing)."""
    kw = _fold(search or "")
    sort_key = _fold(sort or "")
    rows = (_rows() + (algo_rows() if include_algo else [])
            #: ``knobs`` はここで足す —— 台帳の行は**機械可読索引と 1 バイト同じ形**に
            #: 保つ(``imgevolve._ledger_rows`` がこの関数に委譲するため、鍵を 1 つ足すと
            #: ``docs/OP_INDEX.json`` が動く)。台帳 op は ``a`` / ``b`` を取らないので常に None。
            + [dict(r, knobs=None) for r in (ledger_rows() if include_ledger else [])])
    if sort_key:
        known = sorted({r["in_sort"] for r in rows})
        if sort_key not in {_fold(k) for k in known}:
            # ★2026-09-20(GenSpark 第 24 報 N95): 綴り違いの sort が黙って 0 行だった(「該当なし」と区別できない)。
            raise ValueError("list_ops: unknown sort %r; choose from: %s" % (sort, ", ".join(known)))
    out = []
    for r in rows:
        if sort_key and _fold(r["in_sort"]) != sort_key:
            continue
        hay = _fold(r["name"] + " " + (r["halcon"] or "") + " " + r["category"])
        if kw and kw not in hay:
            continue
        out.append(r)
    #: ★台帳には**入力ゼロ**の op(カタログを返すだけ)が在り ``in_sort`` が None になる。
    #: 生の None を並べ替えの鍵に混ぜると TypeError で落ちる —— レジストリと n-ary だけ
    #: だった頃は None が現れなかったので、この鍵は 2026-09-25 まで壊れずに済んでいた。
    return sorted(out, key=lambda r: (r["tier"], r["in_sort"] or "", r["name"]))


def op_names(include_nary: bool = False) -> list[str]:
    """Sorted list of every registry op name (the identifiers :func:`apply` takes with ONE input).

    ★n-ary ops — ``add_image`` / ``sub_image`` / ``mult_image`` / ``div_image`` … (17) — are **not**
    in this list by default: they take a LIST of inputs (``fullseye.apply([x0, x1], "add_image")``)
    and live in the ``"nary"`` tier of :func:`list_ops`; :func:`op_find` searches them too
    (2026-09-19, GenSpark N2: "callable but unlisted"). ★The default stays the one-input list on
    purpose (its length is the documented registry count and the pipeline / evolution vocabulary);
    pass *include_nary=True* to get both tiers in one sorted list (2026-09-20, GenSpark N60).
    """
    names = [o.name for o in _ops.REGISTRY]
    if include_nary:
        names += list({o.name for o in _nary_by_name().values()})
    return sorted(names)


def categories() -> list[str]:
    """2-D レジストリ(``fullseye.op``)の op が属する分類名の一覧を、重複なしの昇順で返す。

    ``list_ops()`` の行の ``category`` と同じ語。台帳層(``fullseye.ledger``)の分類は含まない。
    """
    return sorted({o.category for o in _ops.REGISTRY})


# ---- optional file helpers (cv2) ------------------------------------------- #
def read_image(path: str, sort: str = "image"):
    """Load *path* as a float64 array matching *sort* (``"image"`` grey [0,1], ``"color"`` RGB (H,W,3),
    ``"region"`` = grey > 0.5). Goes through :func:`imgio.load` (needs opencv-python or Pillow):
    a missing file is ``FileNotFoundError``, a directory ``IsADirectoryError``, an undecodable file
    ``ValueError``; 16-bit rasters keep their depth (divided by 65535).

    ★2026-09-20(GenSpark 第 18 報 N78): 以前は cv2.imread の None を全部 FileNotFoundError にしていた
    (ディレクトリも壊れたファイルも「無い」と言っていた)。
    """
    import imgio
    g = imgio.load(path, color=(sort == "color"))
    if sort == "region":
        return (np.asarray(g, np.float64) > 0.5).astype(np.float64)
    return np.asarray(g, np.float64)


def write_image(path: str, v, depth=None) -> None:
    """Save an image/region array to *path* through :func:`imgio.save`.

    float は **[0,1]** として書く(既定 8 bit = 256 段階、``depth=16`` で PNG / TIFF に 16 bit、
    ``depth="float"`` で PFM / TIFF に float32)。整数型はそのまま画素値: ``uint8`` は 8 bit、
    ``uint16`` は **16 bit のまま**(以前は上位 8 bit に潰していた)。

    ★2026-09-06 に踏んだ不具合: 以前は型を見ずに ``v * 255`` していたので、
    **``uint8`` を渡すと numpy の弱いスカラー昇格(NEP 50)で ``uint8`` のまま
    掛け算が回り、255 を超えた値が折り返して真っ黒に近い絵**が保存されていた。
    ★2026-09-20(GenSpark 第 18 報 N76 / N77 / N79): ``cv2.imwrite`` の False を捨てていたので、
    親ディレクトリが無い・拡張子が書けない・ppm に灰、のどれも **ファイルが無いのに無言**だった。
    いまは imgio.save が書く前に 1 文で止める(ディレクトリは作らない)。
    """
    import imgio
    v = np.asarray(v)
    if np.issubdtype(v.dtype, np.integer) and v.dtype not in (np.uint8, np.uint16):
        v = np.clip(v, 0, 255).astype(np.uint8)
    imgio.save(path, v, depth=depth)


# convenience re-exports
RT = _ops.RT
REGISTRY = _ops.REGISTRY
