# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""examplefig — 例(PoC)が **任意で**図を吐き、Studio がそれを拾うための細い層。

## なぜ要るか(2026-09-06、ユーザー「Studio 上で動くような PoC になってる?」)

PoC 30 本は Studio の 2-D Examples ギャラリーに載っていて Run も編集もできるが、
**出力がテキストの表だけ**だった。画像処理ツールキットの IDE で走らせているのに
絵が 1 枚も出ない。かといって PoC に描画を常時入れると、CLI で回したときに
遅くなり、CI でも無駄なファイルが出る。

そこで **環境変数 ``FULLSEYE_FIGURE_DIR`` があるときだけ書く**。

* 未設定(既定)—— :func:`save` は**何もせず ``None`` を返す**。数字も速度も
  1 ビットも変わらない。`py -3.11 examples/poc_*.py` の挙動は従来どおり。
* 設定あり —— そのディレクトリへ ``NN_<name>.png`` を書き、``figures.json`` に
  題と説明を積む。Studio の Figures タブがこれを読んで並べる。

## 使う側

```python
import examplefig as figs

figs.save("speckle", ref, "基準のスペックル(3000 斑点、1σ 1.6 px)")
figs.save("strain", exx, "ε_xx。±2000 µε で塗り分け", signed=True)
```

図は**すべて fullseye 自身の annotate 族で組む**(ユーザー 2026-09-06:
「表や図は Fullseye でも作れるはず」)。多パネルは
:func:`fullseye.annotate_figure_grid`、折れ線は :func:`fullseye.plot_series` +
:func:`fullseye.axes_transform`、表は :func:`fullseye.text_box`。
外部の作図ライブラリは使わない —— 使うと「この道具で何ができるか」を
示すという例の目的が薄れるし、任意依存も増える。

`save` は **(H,W) / (H,W,3) / (H,W,4) の float か uint8** を受ける。
(H,W) は :func:`fullseye.colorize_depth`(``signed=True`` なら発散 LUT)で
塗ってから書く。**書けなかったら黙って諦める**(例の本文は数値を出すのが
仕事で、図が出ないことで落としてはいけない)—— ただし理由は
:func:`errors` に残るので、Studio と門はそれを見られる。
"""
from __future__ import annotations

import atexit
import hashlib
import json
import os
import re
import sys
from pathlib import Path

import numpy as np

#: 図を書き出すディレクトリを指す環境変数。未設定なら :func:`save` は無処理。
ENV_DIR = "FULLSEYE_FIGURE_DIR"

#: グラフと表を論理寸法の何倍で描くか。寸法だけを後から拡大せず、文字・線・余白も
#: この倍率で Fullseye の annotate 族へ渡す。未設定時は発表用の 2 倍描画。
ENV_SCALE = "FULLSEYE_FIGURE_SCALE"

#: 日本語を描けるフォントの既知パス。PoC 2 本にあった固定順探索を共通化し、
#: Ubuntu の fonts-noto-cjk / fonts-ipafont-gothic と macOS の標準パスを補った。
_JAPANESE_FONT_PATHS = {
    False: (
        r"C:\Windows\Fonts\YuGothM.ttc",
        r"C:\Windows\Fonts\meiryo.ttc",
        r"C:\Windows\Fonts\msgothic.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJKjp-Regular.otf",
        "/usr/share/fonts/opentype/ipafont-gothic/ipag.ttf",
        "/usr/share/fonts/opentype/ipafont-gothic/ipagp.ttf",
        "/usr/share/fonts/truetype/fonts-japanese-gothic.ttf",
        "/usr/share/fonts/truetype/vlgothic/VL-Gothic-Regular.ttf",
        "/usr/share/fonts/truetype/takao-gothic/TakaoPGothic.ttf",
        "/System/Library/Fonts/ヒラギノ角ゴシック W3.ttc",
        "/System/Library/Fonts/Hiragino Sans GB.ttc",
    ),
    True: (
        r"C:\Windows\Fonts\YuGothB.ttc",
        r"C:\Windows\Fonts\meiryob.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJKjp-Bold.otf",
        "/System/Library/Fonts/ヒラギノ角ゴシック W6.ttc",
    ),
}

_JAPANESE_FONT_FAMILIES = (
    "Yu Gothic", "Meiryo", "MS Gothic", "Noto Sans CJK JP", "Noto Sans JP",
    "BIZ UDGothic", "IPA Gothic", "IPAGothic", "VL Gothic", "TakaoGothic",
    "Hiragino Sans",
)

#: 1 回の実行で書く枚数の上限。暴走した例がディスクを埋めないための歯止め。
MAX_FIGURES = 64

_manifest: list[dict] = []
_errors: list[str] = []


def target_dir() -> Path | None:
    """図の出力先(``None`` = 出力しない)。"""
    d = os.environ.get(ENV_DIR, "").strip()
    if not d:
        return None
    try:
        p = Path(d)
        p.mkdir(parents=True, exist_ok=True)
        return p
    except OSError as exc:
        _errors.append("%s を作れない: %s" % (d, exc))
        return None


ENV_SWITCH = "FULLSEYE_FIGURES"


def _auto_default() -> None:
    """素で ``py examples/poc_x.py`` と走らせた人にも図が見えるように、PoC の既定出力先を決める。

    ★2026-09-20(ユーザー「サンプルを動かした人がびっくりする体験を」): 図は ``FULLSEYE_FIGURE_DIR`` を
    立てたときだけ出ていたので、素で走らせた人には文字しか見えなかった。``examples/poc_*.py`` として
    起動され、環境変数が無ければ ``<repo>/out/figures/<PoC 名>/``(gitignore 済み)に書き、置き場所を
    先頭で印字する。``FULLSEYE_FIGURES=off`` で止める(テストの走行はこちら)。pytest の中(sys.argv が
    pytest)では何もしない —— 手動の ``target_dir()`` の約束(未設定 = 出さない)は変えない。
    """
    if os.environ.get(ENV_DIR, "").strip():
        return
    if os.environ.get(ENV_SWITCH, "").strip().lower() in ("off", "0", "none", "false"):
        return
    main = sys.argv[0] if sys.argv else ""
    if not main:
        return
    mp = Path(main)
    if not (mp.stem.startswith("poc_") and mp.suffix == ".py" and mp.parent.name == "examples"):
        return
    d = mp.resolve().parent.parent / "out" / "figures" / mp.stem
    # 既定の置き場は PoC 自身の出力しか無いので、前回の図(番号つき)と台帳を先に消す —— 2 回走らせると
    # 01_a.png と 01_b.png が混ざり、台帳と食い違う(2026-09-20 に実測)。
    if d.is_dir():
        for f in d.iterdir():
            if f.is_file() and (re.match(r"^\d\d_.*\.(png|gif|jpg|jpeg)$", f.name) or f.name == "figures.json"):
                try:
                    f.unlink()
                except OSError:
                    pass
    os.environ[ENV_DIR] = str(d)
    print("[examplefig] figures -> %s   (set %s to choose a place, %s=off to disable)" % (d, ENV_DIR, ENV_SWITCH))


_auto_default()


def enabled() -> bool:
    """図を出す設定になっているか。重い描画を組む前の分岐に使う。"""
    return target_dir() is not None


def _japanese_font_path(*, bold: bool = False, fail_closed: bool = True) -> Path | None:
    """日本語フォントのファイルを固定順で探す。

    ``bold`` は通常体と太字体を混ぜない。既知の Windows/Linux/macOS パスを先に
    調べ、matplotlib があれば登録済みフォントも同じ書体順で調べる。見つからない
    ときは既定で、調べたパスをすべて含む :class:`RuntimeError` を送出する。
    matplotlib のように英語へ退避できる呼び出し側だけ ``fail_closed=False`` を使う。
    """
    searched: list[Path] = []

    def consider(raw_path) -> Path | None:
        path = Path(raw_path)
        if path not in searched:
            searched.append(path)
        return path if path.is_file() else None

    for raw_path in _JAPANESE_FONT_PATHS[bool(bold)]:
        found = consider(raw_path)
        if found is not None:
            return found

    # mesh_props.py の探索範囲を維持する。matplotlib は任意依存なので、無ければ
    # 既知パスだけで完結する。
    try:
        from matplotlib import font_manager
    except ImportError:
        pass
    else:
        family_order = {name: n for n, name in enumerate(_JAPANESE_FONT_FAMILIES)}
        bold_weights = {"bold", "demibold", "semibold", "heavy", "black", "700", "800", "900"}
        entries = []
        for entry in font_manager.fontManager.ttflist:
            if entry.name not in family_order:
                continue
            entry_is_bold = str(entry.weight).lower() in bold_weights
            if entry_is_bold == bool(bold):
                entries.append((family_order[entry.name], str(entry.fname)))
        for _order, raw_path in sorted(entries):
            found = consider(raw_path)
            if found is not None:
                return found

    if not fail_closed:
        return None
    paths = "\n".join("  - %s" % path for path in searched) or "  - (候補なし)"
    raise RuntimeError(
        "showcase 用の日本語%sフォントが見つからない。探したパス:\n%s"
        % ("太字" if bold else "", paths)
    )


def _figure_scale(scale=None) -> int:
    """描画倍率を返す。``scale`` が無ければ :data:`ENV_SCALE`、さらに無ければ 2。

    現在の描画器は画素格子へ整数で配置するため、倍率も正の整数に限定する。誤った
    環境変数を黙って 1 倍へ戻すと発表用の図だけ粗くなるので、ここは fail-closed。
    """
    raw = os.environ.get(ENV_SCALE, "2") if scale is None else scale
    try:
        value = int(raw)
    except (TypeError, ValueError) as exc:
        raise ValueError("%s は正の整数で指定する: %r" % (ENV_SCALE, raw)) from exc
    if value < 1 or str(raw).strip() not in (str(value), "+" + str(value)):
        raise ValueError("%s は正の整数で指定する: %r" % (ENV_SCALE, raw))
    return value


def errors() -> list[str]:
    """図を書こうとして失敗した理由(例の本文は落とさないので、ここに残す)。"""
    return list(_errors)


def _report_errors_at_exit():
    """★書けなかった図を、**終了時に必ず標準出力へ出す**(2026-09-08)。

    それまでは :func:`errors` に積むだけで、誰も見ていなかった。図の失敗が例を
    落とさない設計は正しい(数値を出すのが例の仕事)が、**落とさない = 気づかない**
    ではいけない —— 実際に、看板に選ばれる ``scene`` 図が 1 枚消えたまま
    PoC が ``PASS`` を印字し、担当 2 人が別々に同じ穴に落ちた。
    ここで出しておけば、図つきで走らせた人の目には必ず入る。
    """
    if not _errors or target_dir() is None:
        return
    try:
        print("\n[examplefig] 書けなかった図が %d 件ある(数値には影響しないが、"
              "記事や展示から図が 1 枚消える):" % len(_errors))
        for line in _errors:
            print("  - " + line)
    except Exception:                                   # noqa: BLE001 - 終了処理
        pass


atexit.register(_report_errors_at_exit)


#: 書いた図の sha256 -> 名前。★同じ中身の図が 2 枚出たら台帳に積む
_written: dict[str, str] = {}


def _note_unique(path, name: str) -> None:
    """書いた図の**中身**を突き合わせ、同一バイト列なら errors に積む。

    ★2026-09-24: 4 次元 PoC の `tesseract_rational` と `tesseract_irrational`
    が**バイト単位で同一**だった。投影が 2 枚目の回転に原理的に盲目で(x,y の
    差が厳密に 0)、正反対の主張の図が同じ絵になっていた。枚数・名前・説明を
    見る門は在ったのに、**中身が同じかを見る門だけが無かった**ので通った。

    「同じ絵を 2 回出す」が正しい場面は無い(同じものを見せたいなら同じ図を
    2 度参照すればよい)ので、無条件に欠陥として扱う。
    """
    try:
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
    except Exception:                                    # noqa: BLE001
        return
    prev = _written.get(digest)
    if prev is not None and prev != name:
        _errors.append(
            "%s: %r と**中身が完全に同一**(バイト列が一致)—— "
            "別の主張の図なら、どちらかが主張を示していない" % (name, prev))
    else:
        _written.setdefault(digest, name)


def _to_rgb8(v, signed: bool, gray: bool = False, vrange=None, cmap=None):
    """(H,W) か (H,W,3|4) → uint8 RGB。**値域の伸ばし方をここに 1 か所だけ持つ**。

    ``gray=True`` は (H,W) を**グレースケール**で塗る(疑似カラーにしない)。
    強度そのもの —— 焦点合成の全焦点画像やレンズのボケ列のように「絵」として
    見せる量 —— は疑似カラーにすると「ボケ→シャープ」が読み取れず、ヒートマップに
    見えてしまう(2026-09-13、焦点合成 PoC で踏んだ)。深度・位相・残差のような
    「場」は従来どおり疑似カラー/発散色のままにする。

    ``vrange=(lo, hi)`` で**色の範囲を固定**する(作図ソフトでいう ``clim``)。既定は 1 枚ごとに min..max へ
    伸ばすので、誤差 0.002 の差の図も真っ赤に見える(2026-10-03、逆 Abel の差の図で踏んだ)。
    並べて比べる図は同じ ``vrange`` を渡すこと。
    """
    import fullseye as fs

    a = np.asarray(v)
    if a.dtype == np.uint8 and a.ndim == 3:
        return a[..., :3]
    a = np.asarray(a, np.float64)
    a = np.nan_to_num(a, nan=0.0, posinf=0.0, neginf=0.0)
    if a.ndim == 3:
        lo, hi = float(a.min()), float(a.max())
        if hi > 1.0 or lo < 0.0:
            a = (a - lo) / (hi - lo) if hi - lo > 1e-12 else np.zeros_like(a)
        return (np.clip(a[..., :3], 0, 1) * 255).astype(np.uint8)
    if a.ndim != 2:
        raise ValueError("examplefig.save: (H,W) か (H,W,3|4) のみ。来たのは %r" % (a.shape,))
    if vrange is not None:
        vlo, vhi = (float(x) for x in vrange)
        if not vhi > vlo:
            raise ValueError("examplefig: vrange は lo < hi(来たのは %r)" % (vrange,))
    if gray:
        lo, hi = (vlo, vhi) if vrange is not None else (float(a.min()), float(a.max()))
        g = (a - lo) / (hi - lo) if hi - lo > 1e-12 else np.zeros_like(a)
        g = np.clip(g, 0.0, 1.0)
        return (np.repeat(g[..., None], 3, axis=2) * 255).astype(np.uint8)
    if signed:
        m = (max(abs(vlo), abs(vhi)) if vrange is not None else float(np.max(np.abs(a)))) or 1.0
        if cmap is not None:
            rgb = np.asarray(fs.apply_cmap(a, name=cmap, vmin=-m, vmax=m), np.float64)[..., :3]
            return (np.clip(rgb, 0, 1) * 255).astype(np.uint8)
        lut = np.asarray(fs.diverging_lut(256))
        idx = np.clip(((a / m) * 0.5 + 0.5) * 255.0, 0, 255).astype(np.int32)
        return (np.clip(lut[idx], 0, 1) * 255).astype(np.uint8)
    # ★`colorize_depth` は **float [0,1]** を返す。`np.asarray(..., np.uint8)` で
    #   受けると 0.x が全部 0 に切り捨てられて真っ黒になる(2026-09-06 に踏んだ)。
    kw = {"vmin": vlo, "vmax": vhi} if vrange is not None else {}
    if cmap is not None:
        kw["name"] = cmap
    rgb = np.asarray(fs.colorize_depth(a, **kw), np.float64)[..., :3]
    return (np.clip(rgb, 0, 1) * 255).astype(np.uint8)


def video_frame(v, label: str, size=(720, 720), signed: bool = False,
                gray: bool = False, vrange=None):
    """動画用の単一画像を全面に拡大し、上端へ1行だけ注記する。"""
    from PIL import Image
    import fullseye as fs

    rgb = _to_rgb8(v, signed=signed, gray=gray, vrange=vrange)
    w, h = (int(size[0]), int(size[1]))
    rgb = np.asarray(Image.fromarray(rgb).resize((w, h), Image.Resampling.BILINEAR))
    out = fs.text_box(rgb.astype(np.float64) / 255.0, label, (w // 2, 18), anchor="ct", font_size=24,
                      text_color=(1.0, 1.0, 1.0), box_color=(0.0, 0.0, 0.0))
    return (np.clip(np.asarray(out, np.float64), 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8)


def _assert_video_frames_meaningful(frames, label_rows: int = 48):
    """注記でなく画像本体が十分な面積を持ち、時間変化することを検査する。"""
    seq = np.stack([np.asarray(frame) for frame in frames])
    if seq.ndim != 4 or seq.shape[-1] != 3 or seq.shape[0] < 2:
        raise AssertionError("動画内容: 2 枚以上の RGB コマが必要 (shape=%r)" % (seq.shape,))
    if not 0 <= label_rows < seq.shape[1]:
        raise AssertionError("動画内容: label_rows=%d は高さ %d の範囲外" % (label_rows, seq.shape[1]))
    pic = seq[:, label_rows:].astype(np.float64)
    fractions = []
    for frame in pic.astype(np.uint8):
        colours, counts = np.unique(frame.reshape(-1, 3), axis=0, return_counts=True)
        modal = colours[int(np.argmax(counts))]
        fractions.append(float(np.mean(np.max(np.abs(frame.astype(np.int16) - modal), axis=2) > 10)))
    pair_diffs = np.mean(np.abs(np.diff(pic, axis=0)), axis=(1, 2, 3))
    means = np.mean(pic, axis=(1, 2, 3))
    moving_fraction = float(np.mean(pair_diffs > 0.0))
    mean_pair_diff = float(np.mean(pair_diffs))
    ok = (min(fractions) >= 0.05 and max(fractions) <= 0.98
          and mean_pair_diff >= 0.5 and moving_fraction >= 0.8
          and not np.all(means > 245.0) and not np.all(means < 10.0))
    if not ok:
        raise AssertionError(
            "動画内容が不足: modal差>10の割合 %.4f..%.4f (要0.05..0.98), "
            "連続差平均 %.4f (要>=0.5), 変化組割合 %.4f (要>=0.8), "
            "コマ平均 %.2f..%.2f (全コマ<10/>245は不可)"
            % (min(fractions), max(fractions), mean_pair_diff, moving_fraction,
               float(min(means)), float(max(means))))
    return {"content_fraction_min": min(fractions), "content_fraction_max": max(fractions),
            "mean_pair_difference": mean_pair_diff, "moving_pair_fraction": moving_fraction,
            "frame_mean_min": float(min(means)), "frame_mean_max": float(max(means))}


_MAP_KINDS = frozenset(("depth", "height", "disparity", "displacement"))


def _map_options(kind, gray, colorbar, cmap):
    """Resolve the profiler-map shorthand before output can be disabled."""
    if kind is None:
        return bool(colorbar), cmap
    if kind not in _MAP_KINDS:
        raise ValueError("examplefig: kind must be one of %s (got %r)" %
                         (sorted(_MAP_KINDS), kind))
    if gray:
        raise ValueError("examplefig: kind=%r refuses gray=True; depth/height maps require pseudo-colour" % kind)
    return True, "turbo"


def _value_range(v, signed=False, vrange=None):
    a = np.asarray(v, np.float64)
    a = a[np.isfinite(a)]
    lo, hi = ((float(vrange[0]), float(vrange[1])) if vrange is not None
              else ((float(a.min()), float(a.max())) if a.size else (0.0, 1.0)))
    if signed:
        m = max(abs(lo), abs(hi)) or 1.0
        return -m, m
    if not hi > lo:
        hi = lo + 1.0
    return lo, hi


def _fmt_tick(value):
    return "%.4g" % float(value)


def _append_colorbar(rgb, values, unit="", cmap="turbo", signed=False, vrange=None):
    """Append a labelled vertical colour scale; never paint over ``rgb``."""
    import fullseye as fs

    image = np.asarray(rgb, np.float64)
    h, w = image.shape[:2]
    side = 112
    canvas = np.ones((h, w + side, 3), np.float64)
    canvas[:, :w] = image[..., :3]
    lo, hi = _value_range(values, signed=signed, vrange=vrange)
    y0, y1 = min(8, max(0, h - 1)), max(min(h - 8, h - 1), 0)
    if y1 <= y0:
        y0, y1 = 0, h - 1
    bh = max(1, y1 - y0 + 1)
    ramp = np.linspace(hi, lo, bh)[:, None]
    if signed and cmap is None:
        lut = np.asarray(fs.diverging_lut(256), np.float64)
        idx = np.clip(((ramp / max(abs(lo), abs(hi))) * 0.5 + 0.5) * 255.0,
                      0, 255).astype(np.int32)
        bar = lut[idx]
    else:
        bar = np.asarray(fs.apply_cmap(ramp, name=cmap or "turbo", vmin=lo, vmax=hi), np.float64)
    bx, bw = w + 10, 14
    canvas[y0:y0 + bh, bx:bx + bw] = bar[:, :1, :3]
    text_h = 28  # fullseye's built-in bitmap text plate at font_size=10
    labels = [(y0, _fmt_tick(hi)), (max(y0, h - text_h), _fmt_tick(lo))]
    if signed and lo < 0 < hi:
        yz = int(round(y0 + (hi / (hi - lo)) * (bh - 1)))
        labels.append((max(y0, min(h - text_h, yz - text_h // 2)), "0"))
    for yy, label in labels:
        canvas = np.asarray(fs.text_box(canvas, label, (bx + bw + 5, yy),
                                        anchor="lt", font_size=10))
    if unit:
        canvas = np.asarray(fs.text_box(canvas, str(unit), (bx + bw + 35,
                                        max(0, min(h - text_h, h // 2 - text_h // 2))),
                                        anchor="lt", font_size=10))
    return canvas


def save(name: str, image, caption: str = "", signed: bool = False,
         gray: bool = False, source: str = "", colorbar: bool = False,
         unit: str = "", cmap=None, vrange=None, kind=None) -> Path | None:
    """図を 1 枚書く。``FULLSEYE_FIGURE_DIR`` が無ければ**何もせず ``None``**。

    ``source`` は他人の画像・データを使った図の出典(著者・題・誌・DOI/URL・ライセンス・改変の有無)。空でなければ
    ``figures.json`` の項目に ``"source"`` として載る(2026-10-15、実画像の章を足したとき。CC BY の表示を図の台帳に残す)。

    ``signed=True`` は 0 を中心に塗る(ひずみ・残差・位相差のような符号つきの量)。
    ``gray=True`` は疑似カラーにせずグレースケールで塗る(強度そのものを絵として
    見せる量。詳細は :func:`_to_rgb8`)。
    """
    colorbar, cmap = _map_options(kind, gray, colorbar, cmap)
    d = target_dir()
    if d is None:
        return None
    if len(_manifest) >= MAX_FIGURES:
        _errors.append("上限 %d 枚に達したので %r は書かなかった" % (MAX_FIGURES, name))
        return None
    try:
        import fullseye as fs

        rgb = _to_rgb8(image, signed, gray, vrange, cmap)
        if colorbar:
            rgb = (_append_colorbar(rgb.astype(np.float64) / 255.0, image, unit=unit,
                                    cmap=cmap, signed=signed, vrange=vrange) * 255
                   ).astype(np.uint8)
        path = d / ("%02d_%s.png" % (len(_manifest) + 1, name))
        fs.write_image(str(path), rgb)     # uint8 はそのまま画素値(api.write_image)
        _note_unique(path, name)
        entry = {"file": path.name, "name": name, "caption": caption, "shape": list(np.shape(image))}
        if source:
            entry["source"] = source
        _manifest.append(entry)
        (d / "figures.json").write_text(
            json.dumps(_manifest, ensure_ascii=False, indent=1), encoding="utf-8")
        return path
    except Exception as exc:                            # noqa: BLE001
        # ★例の本文を落とさない。図が出ないのは残念だが、数字は出さねばならない。
        _errors.append("%s: %s: %s" % (name, type(exc).__name__, exc))
        return None


#: GIF 1 本のコマ数の上限。これを超えたら**書かずに理由を残す**
#: (何百コマも書いて数十 MB になるほうが困る)。
MAX_GIF_FRAMES = 300

#: GIF 1 本の大きさの目安 [byte]。超えたら警告として `errors()` に残す
#: (消しはしない —— 見えないより大きいほうがまし)。
GIF_SIZE_WARN = 8 * 1024 * 1024


def _frames_to_rgb8(frames, signed: bool):
    """コマ列 → uint8 RGB の列。**尺度は全コマで 1 つ**。

    ★1 枚ずつ min-max で伸ばすと、中身が動いていなくても明るさがちらつき、
    本当に動いた量が見えなくなる([[feedback_ran_is_not_meaningful_output]] の
    「尺度違い」)。float のコマは全体の min/max で 1 度だけ [0,1] に写す。
    """
    import fullseye as fs

    arrs = [np.asarray(f) for f in frames]
    shapes = {a.shape[:2] for a in arrs}
    if len(shapes) != 1:
        raise ValueError(
            "save_gif: コマの大きさがそろっていない %r —— GIF は黙って詰めるので、"
            "ここで止める" % (sorted(shapes),))
    dims = {a.ndim for a in arrs}
    if len(dims) != 1:
        raise ValueError("save_gif: 灰色のコマとカラーのコマが混ざっている %r" % (sorted(dims),))
    if all(a.dtype == np.uint8 for a in arrs):
        return [a[..., :3] if a.ndim == 3 else np.repeat(a[..., None], 3, 2) for a in arrs]
    fl = [np.nan_to_num(np.asarray(a, np.float64), nan=0.0, posinf=0.0, neginf=0.0)
          for a in arrs]
    lo = min(float(a.min()) for a in fl)
    hi = max(float(a.max()) for a in fl)

    # ★ここで :func:`_to_rgb8` に丸投げしてはいけない。あれは (H,W) を
    #   `colorize_depth` に渡すが、**その中で 1 枚ずつ正規化される**ので、
    #   全コマ 0 の画と全コマ 1 の画が同じ色になる(2026-09-09 に試験が捕まえた)。
    #   値域を明示して渡すことで、初めて尺度が 1 つになる。
    if fl[0].ndim == 3:
        rng = hi - lo
        scale = (hi > 1.0 or lo < 0.0) and rng > 1e-12
        return [(np.clip(((a - lo) / rng if scale else a)[..., :3], 0.0, 1.0) * 255
                 ).astype(np.uint8) for a in fl]
    if signed:
        m = max(float(np.max(np.abs(a))) for a in fl) or 1.0
        lut = np.asarray(fs.diverging_lut(256))
        out = []
        for a in fl:
            idx = np.clip(((a / m) * 0.5 + 0.5) * 255.0, 0, 255).astype(np.int32)
            out.append((np.clip(lut[idx], 0, 1) * 255).astype(np.uint8))
        return out
    if hi - lo < 1e-12:                      # 全コマ一定 —— 割らずに 1 色で出す
        hi = lo + 1.0
    return [(np.clip(np.asarray(fs.colorize_depth(a, vmin=lo, vmax=hi), np.float64)[..., :3],
                     0.0, 1.0) * 255).astype(np.uint8) for a in fl]


def save_gif(name: str, frames, caption: str = "", fps: float = 8.0,
             signed: bool = False, loop: int = 0):
    """動く図を 1 本書く。``FULLSEYE_FIGURE_DIR`` が無ければ**何もせず ``None``**。

    Parameters
    ----------
    frames : sequence
        ``(H,W)`` か ``(H,W,3|4)`` のコマ。**全部同じ大きさ**であること
        (違えば ValueError —— GIF は黙って詰めてしまうので、ここで止める)。
    fps : float
        1 秒あたりのコマ数(GIF の刻みは 10 ms 単位に丸まる)。
    signed : bool
        0 を中心に塗る(符号つきの量)。

    Notes
    -----
    尺度は**全コマで 1 つ**。1 枚ずつ伸ばすと、動いていないものがちらついて
    見え、動いているものが見えなくなる。
    """
    d = target_dir()
    if d is None:
        return None
    if len(_manifest) >= MAX_FIGURES:
        _errors.append("上限 %d 枚に達したので %r は書かなかった" % (MAX_FIGURES, name))
        return None
    try:
        from PIL import Image

        seq = list(frames)
        if not seq:
            raise ValueError("save_gif: コマが 1 枚も無い")
        if len(seq) > MAX_GIF_FRAMES:
            raise ValueError("save_gif: コマが %d 枚(上限 %d)—— 間引いてから渡すこと"
                             % (len(seq), MAX_GIF_FRAMES))
        if not (fps > 0.0):
            raise ValueError("save_gif: fps は正であること(来たのは %r)" % (fps,))
        rgb = _frames_to_rgb8(seq, signed)
        ims = [Image.fromarray(a) for a in rgb]
        path = d / ("%02d_%s.gif" % (len(_manifest) + 1, name))
        ims[0].save(str(path), save_all=True, append_images=ims[1:],
                    duration=max(20, int(round(1000.0 / float(fps)))), loop=int(loop),
                    disposal=2, optimize=False)
        # ★Pillow は**直前とまったく同じコマを 1 枚に畳む**(その分の時間は前の
        #   コマの表示時間に足されるので、動きの速さは変わらない)。書いた後で
        #   数え、渡した数と違えば台帳に**両方**残す —— 「72 コマの GIF」と
        #   言いながら中身が 40 コマ、を黙って通さないため。
        with Image.open(str(path)) as chk:
            written = int(getattr(chk, "n_frames", 1))
        size = path.stat().st_size
        if size > GIF_SIZE_WARN:
            _errors.append("%s: GIF が %.1f MB(目安 %.0f MB)—— コマ数か大きさを減らす"
                           % (name, size / 1e6, GIF_SIZE_WARN / 1e6))
        _note_unique(path, name)
        _manifest.append({"file": path.name, "name": name, "caption": caption,
                          "shape": list(np.shape(rgb[0])), "animated": True,
                          "frames": len(ims), "frames_written": written,
                          "fps": float(fps)})
        (d / "figures.json").write_text(
            json.dumps(_manifest, ensure_ascii=False, indent=1), encoding="utf-8")
        return path
    except Exception as exc:                            # noqa: BLE001
        _errors.append("%s: %s: %s" % (name, type(exc).__name__, exc))
        return None


#: MP4 の上限コマ数(10 分の 60 fps 相当)。GIF と違い、長い映像はこちらで出す
MAX_VIDEO_FRAMES = 36000


def save_video(name: str, frames, caption: str = "", fps: float = 30.0,
               gif_every: int = 1, gif_fps: float | None = None, gif_width: int | None = 480,
               signed: bool = False):
    """動画を 1 本書く: **MP4(全コマ・等倍)** と、記事に埋める **軽い GIF**(間引き・縮小)の対。

    ``FULLSEYE_FIGURE_DIR`` が無ければ**何もせず ``None``**。MP4 は imageio + imageio-ffmpeg
    (extras ``video``)で H.264 / yuv420p に書く(奇数の辺は 1 px 足して偶数にする —— yuv420p の制約)。
    無ければ台帳に積んで GIF だけ出す(黙って落とさない)。

    figures.json に載るのは **GIF の 1 行**(``"video"`` = MP4 のファイル名、``"video_frames"``、
    ``"video_fps"`` を足す)。MP4 自体は行を持たない —— 図の読み手(展示館・op 文書)は画像しか
    扱わないので、MP4 を行にすると全部の読み手が壊れる。記事は GIF を埋め、MP4 へリンクする。

    Parameters
    ----------
    gif_every : int
        GIF は ``gif_every`` コマに 1 枚(MP4 は全コマ)。
    gif_fps : float or None
        GIF の再生速度。None なら ``fps / gif_every``(実時間と同じ速さ)。
    gif_width : int or None
        GIF の幅(px、縦横比は保つ)。None なら等倍。
    """
    d = target_dir()
    if d is None:
        return None
    try:
        seq = list(frames)
        if not seq:
            raise ValueError("save_video: コマが 1 枚も無い")
        if len(seq) > MAX_VIDEO_FRAMES:
            raise ValueError("save_video: コマが %d 枚(上限 %d)" % (len(seq), MAX_VIDEO_FRAMES))
        if not (fps > 0.0) or int(gif_every) < 1:
            raise ValueError("save_video: fps は正、gif_every は 1 以上(来たのは %r, %r)" % (fps, gif_every))
        rgb = _frames_to_rgb8(seq, signed)
        h, w = rgb[0].shape[:2]
        mp4 = d / ("%02d_%s.mp4" % (len(_manifest) + 1, name))
        written_mp4 = None
        try:
            import imageio.v2 as iio

            ph, pw = h + (h % 2), w + (w % 2)
            pad = [a if (ph, pw) == (h, w) else np.pad(a, ((0, ph - h), (0, pw - w), (0, 0)), mode="edge") for a in rgb]
            iio.mimwrite(str(mp4), pad, fps=float(fps), codec="libx264", quality=8,
                         pixelformat="yuv420p", macro_block_size=1)
            written_mp4 = mp4
        except Exception as exc:                        # noqa: BLE001 - 無い環境では GIF だけ
            _errors.append("%s: MP4 を書けなかった(%s: %s)—— extras [video] を入れる" % (name, type(exc).__name__, exc))
        gseq = rgb[::int(gif_every)]
        if gif_width is not None and w > int(gif_width):
            from PIL import Image

            gh = max(1, round(h * int(gif_width) / w))
            gseq = [np.asarray(Image.fromarray(a).resize((int(gif_width), gh), Image.LANCZOS)) for a in gseq]
        gfps = float(gif_fps) if gif_fps else float(fps) / int(gif_every)
        path = save_gif(name, gseq, caption=caption, fps=gfps)
        if path is not None and written_mp4 is not None:
            want = "%02d_%s.mp4" % (int(path.name[:2]), name)
            if written_mp4.name != want:                # GIF の番号と揃える(間に別の図が入らないので通常は同じ)
                written_mp4 = written_mp4.replace(d / want)
            _manifest[-1].update({"video": written_mp4.name, "video_frames": len(rgb), "video_fps": float(fps),
                                  "video_shape": [h, w, 3]})
            (d / "figures.json").write_text(json.dumps(_manifest, ensure_ascii=False, indent=1), encoding="utf-8")
        return path
    except Exception as exc:                            # noqa: BLE001
        _errors.append("%s: %s: %s" % (name, type(exc).__name__, exc))
        return None


def manifest() -> list[dict]:
    """この実行で書いた図の一覧。"""
    return list(_manifest)


def reset() -> None:
    """状態を捨てる(試験用)。"""
    _manifest.clear()
    _errors.clear()
    _written.clear()


# --------------------------------------------------------------------------- #
# 図の組み立て —— すべて fullseye の annotate 族で作る                          #
# --------------------------------------------------------------------------- #
def _panel(v, signed=False, title="", gray=False, vrange=None, colorbar=False,
           unit="", cmap=None):
    """1 枚のパネル(uint8 RGB)。題を左上に置く。"""
    import fullseye as fs

    rgb = _to_rgb8(v, signed, gray, vrange, cmap).astype(np.float64) / 255.0
    if colorbar:
        rgb = _append_colorbar(rgb, v, unit=unit, cmap=cmap,
                               signed=signed, vrange=vrange)
    if title:
        rgb = np.asarray(fs.text_box(rgb, title, (6, 6), anchor="lt", font_size=12))
    return rgb


def save_grid(name: str, panels, captions=None, title=None, ncols=2,
              signed=False, caption: str = "", gray=False, vrange=None,
              colorbar=False, unit="", cmap=None, kind=None) -> Path | None:
    """複数の画像を 1 枚の多パネル図に組んで書く(:func:`annotate_figure_grid`)。

    ``signed`` と ``gray`` は 1 個の bool でも、パネルごとの列でもよい。
    ``gray=True`` のパネルは疑似カラーにせずグレースケールで塗る(強度そのもの
    を「絵」として見せる量に使う。詳細は :func:`_to_rgb8`)。
    ``vrange`` は ``(lo, hi)`` 1 つ(全パネル共通)か、パネルごとの列(``None`` = そのパネルは自動)。
    """
    count = len(panels)
    def per_panel(value, *, pair_is_scalar=False):
        if pair_is_scalar and value is not None and len(value) == 2 and np.isscalar(value[0]):
            return [value] * count
        if isinstance(value, (list, tuple)) and not isinstance(value, str):
            if len(value) != count:
                raise ValueError("option list must match panels (%d != %d)" % (len(value), count))
            return list(value)
        return [value] * count

    sg = per_panel(signed)
    gr = per_panel(gray)
    cb = per_panel(colorbar)
    un = per_panel(unit)
    cm = per_panel(cmap)
    ki = per_panel(kind)
    resolved = [_map_options(k, bool(g), c, m) for k, g, c, m in zip(ki, gr, cb, cm)]
    cb = [x[0] for x in resolved]
    cm = [x[1] for x in resolved]
    if target_dir() is None:
        return None
    try:
        import fullseye as fs

        if vrange is None or (len(vrange) == 2 and np.isscalar(vrange[0])):
            vr = [vrange] * len(panels)
        else:
            vr = list(vrange)
            if len(vr) != len(panels):
                raise ValueError("vrange の列はパネルと同じ数(%d != %d)" % (len(vr), len(panels)))
        imgs = [_panel(v, bool(s), gray=bool(g), vrange=r_, colorbar=bool(c),
                       unit=u, cmap=m)
                for v, s, g, r_, c, u, m in zip(panels, sg, gr, vr, cb, un, cm)]
        caps = list(captions or [])
        # ★2026-09-08: パネルが小さいと題が入らず、``annotate_figure_grid`` が
        # (正しく)拒否して**図が 1 枚黙って消えていた**。29×19 の core 格子や
        # 24×24 の縮小マップは PoC で普通に出るのに、エラーは
        # 「題を短くしろ」と言う —— 実際の直し方は「パネルを大きくしろ」。
        # 2 人の担当が独立に同じ穴に落ちた(看板の scene 図が 1 枚消えた例あり)ので、
        # 呼び手ごとに拡大を書かせず、ここで 1 度だけ補間する。入力が十分大きければ
        # 1 倍のままなので実データの解像度を保つ。拡大が必要な小画像だけは、発表図で
        # 画素の四角を増やす最近傍を避け、双三次補間する。
        for factor in _grid_upscales(imgs, caps):
            try:
                fig = fs.annotate_figure_grid(_upscale(imgs, factor), captions=caps,
                                              ncols=ncols, title=title)
            except ValueError as exc:
                if "does not fit" not in str(exc) or factor == _GRID_UPSCALES[-1]:
                    raise
                continue
            return save(name, fig, caption)
        return None
    except Exception as exc:                            # noqa: BLE001
        _errors.append("%s(grid): %s: %s" % (name, type(exc).__name__, exc))
        return None


#: 題が入らないときに試す拡大率(双三次補間。1 = そのまま)。
_GRID_UPSCALES = (1, 2, 3, 4, 6, 8)


def _grid_upscales(imgs, caps):
    """最初から入りそうな倍率から試す(小さいパネルで無駄な往復をしない)。

    ``annotate_figure_grid`` は概ね 1 文字 ≈ 8 px を要求するので、最長の題から
    必要幅を見積もり、それを満たす最小の倍率から始める。
    """
    if not imgs:
        return _GRID_UPSCALES
    w = min(int(np.asarray(im).shape[1]) for im in imgs)
    need = 8 * max((len(str(c)) for c in caps), default=0) + 24
    start = 0
    for i, f in enumerate(_GRID_UPSCALES):
        if w * f >= need:
            start = i
            break
    return _GRID_UPSCALES[start:]


def _upscale(imgs, factor):
    """双三次補間で整数倍に拡大する。``factor == 1`` は元配列を素通し。"""
    if factor == 1:
        return imgs
    from PIL import Image

    out = []
    for im in imgs:
        a = np.asarray(im)
        h, w = a.shape[:2]
        if np.issubdtype(a.dtype, np.floating):
            # Pillow の RGB float は未対応なので uint8 を補間して元の [0, 1] 表現へ戻す。
            rgb8 = np.clip(np.rint(a * 255.0), 0, 255).astype(np.uint8)
            resized = np.asarray(Image.fromarray(rgb8).resize(
                (w * factor, h * factor), Image.Resampling.BICUBIC))
            out.append(resized.astype(a.dtype) / 255.0)
        else:
            out.append(np.asarray(Image.fromarray(a).resize(
                (w * factor, h * factor), Image.Resampling.BICUBIC)))
    return out


def save_plot(name: str, series, xlabel: str = "", ylabel: str = "", title: str = "",
              caption: str = "", size=(560, 360), xlim=None, ylim=None,
              kinds=None, styles=None, colors=None, aspect=None, source: str = "",
              scale=None, legend_position=None) -> Path | None:
    """折れ線・散布のグラフを書く。``series`` = ``[(ラベル, x, y), ...]``。``source`` は :func:`save` と同じ(出典)。

    ``styles`` は系列ごとの線種(``None`` / ``"dashed"`` / ``"dotted"``)の列。**真値・参照線は破線**にする
    —— 実線どうしが重なると、データと参照の区別がつかない(2026-10-03、傾きの参照線で踏んだ)。
    ``colors`` は系列ごとの配色の役割名(``"reference"`` / ``"emphasis"`` / ``"right"`` / ``"wrong"`` / ``"neutral"``)の列
    (作図ソフトでいう 'Color')。同じ意味の線分を何本も描くときは同じ色にする。**ラベルが空の系列は凡例に載せない**
    (作図ソフトでいう 'HandleVisibility','off')—— 線分ごとに凡例が並ぶと読めない(2026-10-03、割当の図で踏んだ)。
    ``aspect="equal"`` で x と y の 1 単位を同じ画素数にする(作図ソフトでいう axis equal)。範囲は狭い側を中央から広げる
    —— 縮尺が違うと円が楕円に見える(2026-10-03、Delaunay の外接円で踏んだ)。

    軸・目盛り・格子・凡例はすべて fullseye の annotate 族が引く。
    """
    if target_dir() is None:
        return None
    try:
        img = render_plot(series, xlabel=xlabel, ylabel=ylabel, title=title or name, size=size,
                          xlim=xlim, ylim=ylim, kinds=kinds, styles=styles, colors=colors,
                          aspect=aspect, scale=_figure_scale(scale),
                          legend_position=legend_position)
        return save(name, img, caption, source=source)
    except Exception as exc:                            # noqa: BLE001
        _errors.append("%s(plot): %s: %s" % (name, type(exc).__name__, exc))
        return None


def _render_heatmap(values, xvalues, yvalues, xlabel: str = "", ylabel: str = "",
                    vrange=(0.0, 1.0), boundary=None, size=(420, 300),
                    cmap="turbo", colorbar_unit: str = ""):
    """固定尺度のヒートマップを軸・目盛り・任意の白い境界線つきで描く。

    ``boundary`` は ``values`` と同じ形の bool 配列。True/False が隣り合う
    セル境界だけを白線で描く。小さな格子は最近傍で拡大し、存在しない中間値を
    作らない。返り値は :func:`save_grid` のパネルとしてそのまま使える。
    """
    import fullseye as fs

    z = np.asarray(values, dtype=np.float64)
    xv = np.asarray(xvalues, dtype=np.float64).ravel()
    yv = np.asarray(yvalues, dtype=np.float64).ravel()
    if z.ndim != 2 or z.shape != (yv.size, xv.size):
        raise ValueError("render_heatmap: values must have shape (len(yvalues), len(xvalues))")
    if xv.size < 2 or yv.size < 2 or np.any(np.diff(xv) <= 0.0) or np.any(np.diff(yv) <= 0.0):
        raise ValueError("render_heatmap: xvalues/yvalues must be strictly increasing with 2+ values")
    if boundary is not None and np.asarray(boundary).shape != z.shape:
        raise ValueError("render_heatmap: boundary must match values")
    lo, hi = float(vrange[0]), float(vrange[1])
    if not np.isfinite(z).all() or not lo < hi:
        raise ValueError("render_heatmap: values and vrange must be finite, with lo < hi")

    w, h = map(int, size)
    # 8 x 7 程度の格子を整数倍できる描画域。余りは白い軸余白へ回す。
    cell_w = max(1, (w - 100) // xv.size)
    cell_h = max(1, (h - 76) // yv.size)
    rw, rh = cell_w * xv.size, cell_h * yv.size
    rect = (64, 14, rw, rh)
    img = np.ones((h, w, 3), dtype=np.float64)
    rgb = _to_rgb8(z, signed=False, gray=False, vrange=(lo, hi), cmap=cmap)
    enlarged = np.repeat(np.repeat(rgb, cell_h, axis=0), cell_w, axis=1)
    x0, y0, _, _ = rect
    img[y0:y0 + rh, x0:x0 + rw] = enlarged.astype(np.float64) / 255.0

    dx = float(np.median(np.diff(xv)))
    dy = float(np.median(np.diff(yv)))
    axes = fs.axes_transform(rect, (xv[0] - dx / 2.0, xv[-1] + dx / 2.0),
                             (yv[0] - dy / 2.0, yv[-1] + dy / 2.0), invert_y=False)
    img = np.asarray(fs.axes_frame(img, axes, width=1))
    img = np.asarray(fs.ticks(img, axes, xticks=xv, yticks=[], label_fmt="{:.2f}",
                              tick_len=4, font_size=11))
    img = np.asarray(fs.ticks(img, axes, xticks=[], yticks=yv, label_fmt="{:.0f}",
                              tick_len=4, font_size=11))

    if boundary is not None:
        b = np.asarray(boundary, dtype=bool)
        # セル間で判定が変わる辺だけを描くので、等高線補間による架空の値を作らない。
        for row in range(yv.size):
            for col in range(xv.size - 1):
                if b[row, col] != b[row, col + 1]:
                    xx = 0.5 * (xv[col] + xv[col + 1])
                    p0 = fs.data_to_pixel(axes, xx, yv[row] - dy / 2.0)
                    p1 = fs.data_to_pixel(axes, xx, yv[row] + dy / 2.0)
                    img = np.asarray(fs.draw_line(img, p0, p1, color=(1.0, 1.0, 1.0), width=3))
        for row in range(yv.size - 1):
            for col in range(xv.size):
                if b[row, col] != b[row + 1, col]:
                    yy = 0.5 * (yv[row] + yv[row + 1])
                    p0 = fs.data_to_pixel(axes, xv[col] - dx / 2.0, yy)
                    p1 = fs.data_to_pixel(axes, xv[col] + dx / 2.0, yy)
                    img = np.asarray(fs.draw_line(img, p0, p1, color=(1.0, 1.0, 1.0), width=3))

    foot = (xlabel + ("   |   " if xlabel and ylabel else "") + ylabel).strip()
    if foot:
        img = np.asarray(fs.text_box(img, foot, (10, h - 8), anchor="lb", font_size=12))
    if colorbar_unit:
        img = _append_colorbar(img, z, unit=colorbar_unit, cmap=cmap,
                               signed=False, vrange=(lo, hi))
    return img


def render_plot(series, xlabel: str = "", ylabel: str = "", title: str = "", size=(560, 360),
                xlim=None, ylim=None, kinds=None, styles=None, colors=None, aspect=None,
                scale=None, legend_position=None):
    """:func:`save_plot` の絵だけを返す(``(h, w, 3)`` float、[0, 1])。ファイルは書かない。

    ★2026-10-03 に切り出した。Studio の結果ビューが 1-D 系列や表の列を**同じ見た目の
    グラフ**で見せるため(Studio は系列を「Nothing to display」としか言えなかった)。
    引数の意味は :func:`save_plot` と同じ。描けなければ例外(呼び手が扱う)。
    """
    import fullseye as fs
    if not series:
        raise ValueError("render_plot: series is empty")
    # 直接描画は Studio などの画面表示にも使うため等倍を既定にする。発表資料へ
    # 保存する経路だけが FULLSEYE_FIGURE_SCALE を解決して明示的に渡す。
    s = _figure_scale(1 if scale is None else scale)
    logical_w, logical_h = size
    w, h = logical_w * s, logical_h * s
    img = np.full((h, w, 3), 1.0)
    xs_all = np.concatenate([np.asarray(x, float).ravel() for _, x, _ in series])
    ys_all = np.concatenate([np.asarray(y, float).ravel() for _, _, y in series])
    xs_all = xs_all[np.isfinite(xs_all)]
    ys_all = ys_all[np.isfinite(ys_all)]
    xl = xlim or (float(xs_all.min()), float(xs_all.max()))
    yl = ylim or (float(ys_all.min()), float(ys_all.max()))
    if xl[1] - xl[0] < 1e-12:
        xl = (xl[0] - 0.5, xl[1] + 0.5)
    pad = 0.06 * (yl[1] - yl[0] or 1.0)
    yl = (yl[0] - pad, yl[1] + pad)
    if aspect == "equal":
        pw, ph = (logical_w - 96) * s, (logical_h - 108) * s  # 下の rect と同じ大きさ
        sx, sy = (xl[1] - xl[0]) / pw, (yl[1] - yl[0]) / ph
        if sx > sy:
            c_, half = 0.5 * (yl[0] + yl[1]), 0.5 * sx * ph
            yl = (c_ - half, c_ + half)
        else:
            c_, half = 0.5 * (xl[0] + xl[1]), 0.5 * sy * pw
            xl = (c_ - half, c_ + half)
    elif aspect is not None:
        raise ValueError("save_plot: aspect は None か 'equal'")
    # ★2026-10-03: 下の余白を 16 px 広げた。軸名の帯(左下)が x 軸の目盛りの数字に重なって
    #   「0.5」や「20」を隠していた(transforms_tour の図で踏んだ。全部の save_plot に効く)。
    rect = (72 * s, 44 * s, (logical_w - 96) * s, (logical_h - 108) * s)
    ax = fs.axes_transform(rect, xl, yl)
    xt, yt = fs.nice_ticks(xl[0], xl[1], 6), fs.nice_ticks(yl[0], yl[1], 5)
    img = np.asarray(fs.grid_lines(img, ax, xticks=xt, yticks=yt, alpha=0.25))
    img = np.asarray(fs.axes_frame(img, ax, width=1 * s))
    img = np.asarray(fs.ticks(img, ax, xticks=xt, yticks=yt,
                              tick_len=5 * s, font_size=10 * s))
    plain = img.copy()                              # データを描く前(凡例の置き場所を選ぶのに使う)
    # 役名は annotate の配色表にあるものだけ("accent" は無い)。
    colours = ("reference", "emphasis", "right", "wrong", "neutral")
    legend = []
    # ★2026-10-21: 棒を 1 本ずつ別の系列にした図(色を棒ごとに変えるため)は、系列の中に x が 1 つしか
    #   なく plot_series が間隔を知れないので、棒が描画域の 70 % の幅になり隣と重なった(製造公差 PoC の
    #   歩留まりの対比図で目視)。棒の x を**全系列**から集め、その最小間隔(棒が 1 本しかなければ目盛りの
    #   間隔)を画素に直して、1 点の系列にだけ bar_width として渡す。複数点の系列は従来どおり自分の間隔。
    rw_ = rect[2]
    bar_x = [np.asarray(x, float).ravel() for k, (_, x, _) in enumerate(series)
             if (kinds[k] if kinds else "line") == "bar"]
    bar_x = np.unique(np.concatenate(bar_x)) if bar_x else np.empty(0)
    bar_x = bar_x[np.isfinite(bar_x)]
    if bar_x.size >= 2:
        bar_step = float(np.min(np.diff(bar_x)))
    elif len(xt) >= 2:
        bar_step = float(np.min(np.diff(np.asarray(xt, float))))
    else:
        bar_step = float(xl[1] - xl[0])
    single_bar_width = min(1.0, max(1.0 / rw_, 0.7 * bar_step / (xl[1] - xl[0])))
    for k, (label, x, y) in enumerate(series):
        c = colors[k] if colors and colors[k] is not None else colours[k % len(colours)]
        kind = (kinds[k] if kinds else "line")
        ls = styles[k] if styles else None
        extra = {}
        if ls:
            import imagedraw
            extra = {"style": {"style": imagedraw.DrawStyle(line_style=ls)}}
        if kind == "bar" and np.asarray(x, float).ravel().size == 1:
            extra["bar_width"] = single_bar_width
        img = np.asarray(fs.plot_series(img, ax, np.asarray(x, float),
                                        np.asarray(y, float), kind=kind,
                                        color=c, width=2 * s, marker_size=3 * s, **extra))
        if label and (c, label) not in legend:
            legend.append((c, label))
    if len(legend) > 1:
        # ★2026-10-03: 凡例は**データを最も隠さない隅**に置く(MATLAB の legend('best'))。右上固定だと
        #   減衰の遅い応答の山が凡例の下に隠れた。点の数で象限を選ぶ最初の版も、Runge の端の山を
        #   半分隠した —— 隠れるのは「点」でなく「線の画素」なので、各隅に凡例を試しに描き、
        #   その矩形の下にあるデータの画素(背景でも格子でもない画素)を数えて最少の隅を選ぶ。
        x0, y0, rw, rh = rect
        pos = {"rt": (x0 + rw - 6 * s, y0 + 6 * s), "lt": (x0 + 6 * s, y0 + 6 * s),
               "rb": (x0 + rw - 6 * s, y0 + rh - 6 * s),
               "lb": (x0 + 6 * s, y0 + rh - 6 * s)}
        ink = np.abs(img - plain).max(axis=2) > 0.05       # データ線だけが描いた画素
        best, best_cost, box_w = "rt", None, 0
        for corner in ("rt", "lt", "rb", "lb"):
            probe = np.asarray(fs.legend_box(np.ones_like(img), legend, pos[corner], anchor=corner,
                                             markers=True, font_size=11 * s,
                                             swatch=11 * s, pad=6 * s))
            box = np.abs(probe - 1.0).max(axis=2) > 0.02
            cols = np.flatnonzero(box.any(axis=0))
            box_w = max(box_w, int(cols.max() - cols.min() + 1) if cols.size else 0)
            cost = int(np.sum(ink & box))
            if best_cost is None or cost < best_cost:
                best, best_cost = corner, cost
        if legend_position not in (None, "outside"):
            raise ValueError("render_plot: legend_position must be None or 'outside'")
        if legend_position == "outside" or best_cost > 40 * s * s:
            # どの隅でもデータを隠す(Runge の図は四隅すべてに線がある)→ 軸の外、右に出す
            # (MATLAB の 'eastoutside')。キャンバスを凡例の幅だけ広げる。
            wide = np.ones((img.shape[0], img.shape[1] + box_w + 16 * s, 3))
            wide[:, :img.shape[1]] = img
            img = np.asarray(fs.legend_box(wide, legend,
                                           (img.shape[1] + 4 * s, y0 + 6 * s), anchor="lt",
                                           markers=True, font_size=11 * s,
                                           swatch=11 * s, pad=6 * s))
        else:
            img = np.asarray(fs.legend_box(img, legend, pos[best], anchor=best,
                                           markers=True, font_size=11 * s,
                                           swatch=11 * s, pad=6 * s))
    if title:
        img = np.asarray(fs.text_box(img, title, (10 * s, 8 * s), anchor="lt",
                                     font_size=13 * s))
    foot = (xlabel + ("   |   " if xlabel and ylabel else "") + ylabel).strip()
    if foot:
        img = np.asarray(fs.text_box(img, foot, (10 * s, h - 10 * s), anchor="lb",
                                     font_size=11 * s))
    return img


#: 表の列幅の下限[px]。上限は設けない。実測した文字幅を切る上限は、長い日英併記を
#: 隣の列へはみ出させるためである(2026-11-23 の原寸検分で確認)。
COL_W_MIN = 56

#: 列と列のあいだの余白[px]。``text_box`` が左右に ``pad=5`` を取るので、
#: 見た目の隙間はこれから 10 px 引いた分になる。
COL_GAP = 22


def _column_widths(header, rows, col_w=None, scale=1) -> list[int]:
    """表の列幅を **中身を測って**決める(:func:`fullseye.measure_text`)。

    ★2026-09-06 まで固定 110 px だった。数字だけの列でも 110 px 取り、
    「深さ mm(推定/真値)」のような長い見出しは隣の列へはみ出していた。
    ``fullseye`` には**描く前に測る** :func:`measure_text` があるのだから、
    自前の表がそれを使わないのは筋が通らない(ドッグフーディング)。

    ``col_w`` は全列の**下限**。指定値より文字が広ければ、実測幅を優先する。
    """
    import fullseye as fs

    ncol = len(header)
    out = []
    for j in range(ncol):
        cells = [str(header[j])] + [str(r[j]) for r in rows if j < len(r)]
        wide = max(int(fs.measure_text(c, font_size=11 * scale)["width"]) for c in cells)
        requested = int(col_w) * scale if col_w is not None else 0
        out.append(int(max(COL_W_MIN * scale, requested, wide + COL_GAP * scale)))
    return out


def _table_layout(header, rows, title: str = "", col_w=None, row_h=24, scale=None):
    """表の寸法と全セルの文字外接矩形を、描画前の実測だけから返す。

    セル内に改行があれば、その行だけを高くする。返した ``cell_rects`` は全組を調べ、
    交差が 1 件でもあれば例外にする。 / Measure every table cell before drawing and reject
    any intersecting pair of text bounding boxes.
    """
    import fullseye as fs

    s = _figure_scale(1 if scale is None else scale)
    ncol = len(header)
    all_rows = [list(header)] + [list(row[:ncol]) for row in rows]
    measured = [[fs.measure_text(str(cell), font_size=11 * s) for cell in row]
                for row in all_rows]
    widths = _column_widths(header, rows, col_w, scale=s)
    xs = [14 * s + sum(widths[:j]) for j in range(ncol)]
    row_steps = [max(int(row_h) * s,
                     max((int(m["height"]) for m in row), default=0) + 2 * s)
                 for row in measured]
    ys, y = [], 40 * s
    for step in row_steps:
        ys.append(y)
        y += step
    cell_rects = []
    for i, row in enumerate(measured):
        for j, m in enumerate(row):
            cell_rects.append((xs[j], ys[i], xs[j] + int(m["width"]),
                               ys[i] + int(m["height"]), i, j))
    for k, a in enumerate(cell_rects):
        for b in cell_rects[k + 1:]:
            intersects = a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]
            if intersects:
                raise AssertionError("table cell text overlaps: row/col %r and %r" %
                                     ((a[4], a[5]), (b[4], b[5])))
    table_w = 24 * s + sum(widths)
    title_w = (int(fs.measure_text(str(title), font_size=13 * s)["width"]) + 24 * s
               if title else 0)
    return {"scale": s, "widths": widths, "xs": xs, "ys": ys,
            "cell_rects": cell_rects, "width": max(table_w, title_w),
            "height": 56 * s + sum(row_steps)}


def _render_table(header, rows, title: str = "", col_w=None, row_h=24, scale=None):
    """表の画像だけを返す。寸法・文字・余白を同じ倍率で描く。"""
    import fullseye as fs

    layout = _table_layout(header, rows, title=title, col_w=col_w, row_h=row_h,
                           scale=scale)
    s = layout["scale"]
    ncol = len(header)
    xs = layout["xs"]
    ys = layout["ys"]
    w, h = layout["width"], layout["height"]
    img = np.full((h, w, 3), 1.0)
    if title:
        img = np.asarray(fs.text_box(img, title, (12 * s, 8 * s), anchor="lt",
                                     font_size=13 * s))
    for j, cell in enumerate(header):
        img = np.asarray(fs.text_box(img, str(cell), (xs[j], ys[0]),
                                     anchor="lt", font_size=11 * s, color="emphasis"))
    for i, row in enumerate(rows):
        for j, cell in enumerate(row[:ncol]):
            img = np.asarray(fs.text_box(img, str(cell),
                                         (xs[j], ys[i + 1]),
                                         anchor="lt", font_size=11 * s,
                                         box_alpha=0.0, border=0))
    return img


def save_table(name: str, header, rows, title: str = "", caption: str = "",
               col_w=None, row_h=24, scale=None) -> Path | None:
    """数表を**画像として**書き、**同じ内容を CSV/TSV でも置く**。

    「表も Fullseye で作れる」——`text_box` を格子状に置くだけ。値の整形は
    呼び手の責任(``rows`` は文字列の列で渡す)。

    ★2026-09-06、ユーザー「表は Excel にコピーできるといいね」。図は見るため
    のもので、**数字は持ち出せないと使えない**。そこで同じ名前で

    * ``NN_<name>.csv`` —— UTF-8 **BOM つき**。Excel はこれが無いと日本語を
      cp932 と誤読して文字化けする(BOM を付けるのはそのためだけ)。
    * ``NN_<name>.tsv`` —— Studio の「Excel 用にコピー」がこれを貼る。
      Excel は**タブ区切りのクリップボードをセルに展開する**ので、
      CSV より貼り付けが素直(カンマを含む値でも壊れない)。

    を書き、``figures.json`` の項目に ``csv`` / ``tsv`` を入れる。
    """
    if target_dir() is None:
        return None
    try:
        img = _render_table(header, rows, title=title, col_w=col_w, row_h=row_h,
                            scale=_figure_scale(scale))
        path = save(name, img, caption)
        if path is not None:
            _write_table_data(path, header, rows)
        return path
    except Exception as exc:                            # noqa: BLE001
        _errors.append("%s(table): %s: %s" % (name, type(exc).__name__, exc))
        return None


def _write_table_data(png_path: Path, header, rows) -> None:
    """図と同じ名前で CSV(BOM つき)と TSV を置き、manifest に書き足す。"""
    import csv as _csv
    import io as _io

    stem = png_path.with_suffix("")
    cells = [list(map(str, header))] + [list(map(str, r)) for r in rows]
    buf = _io.StringIO()
    _csv.writer(buf, lineterminator=chr(10)).writerows(cells)
    # Excel は BOM が無いと UTF-8 を cp932 と誤読する。ここだけ utf-8-sig。
    stem.with_suffix(".csv").write_text(buf.getvalue(), encoding="utf-8-sig")
    tsv = chr(10).join(chr(9).join(c.replace(chr(9), " ") for c in row) for row in cells)
    stem.with_suffix(".tsv").write_text(tsv + chr(10), encoding="utf-8")
    _manifest[-1]["csv"] = stem.with_suffix(".csv").name
    _manifest[-1]["tsv"] = stem.with_suffix(".tsv").name
    (png_path.parent / "figures.json").write_text(
        json.dumps(_manifest, ensure_ascii=False, indent=1), encoding="utf-8")
