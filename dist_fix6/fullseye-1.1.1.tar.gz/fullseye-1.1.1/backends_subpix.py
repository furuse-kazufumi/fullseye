"""Sub-pixel critical-point extraction (image -> contour point sets).

HALCON has a family of operators that locate the *critical points* of a gray-value
surface with sub-pixel precision: `local_max_sub_pix`, `local_min_sub_pix`,
`saddle_points_sub_pix`, `critical_points_sub_pix`, plus the region operators
`plateaus` (connected flat regions) and `lowlands`/`lowlands_center` (basin
centres). This module implements those genuinely and exposes them as `sp_*` ops
whose out_sort is CONTOUR — a dict ``{"shape": (H, W), "cs": [Nx2 (row, col)]}``.
Each detected point is returned as its own single-point (1x2) sub-contour so the
downstream ``count_contours`` feature reports the number of critical points.

Method (genuine, deterministic):
  * A discrete extremum is a pixel strictly greater (max) / less (min) than all 8
    of its neighbours.  Its position is refined to sub-pixel by fitting a 2-D
    quadratic  z = a0 + a1 x + a2 y + a3 x^2 + a4 y^2 + a5 xy  to the 3x3
    neighbourhood (least squares — a fixed pseudo-inverse), then solving
    grad z = 0  ->  offset = -H^{-1} g  (with a separable 1-D parabola fallback
    when the fitted Hessian is degenerate).
  * A saddle is a pixel whose 3x3 quadratic fit has an indefinite Hessian
    (det H < 0, i.e. mixed-sign eigenvalues) and whose critical offset falls
    inside the pixel cell (|dx|,|dy| <= 0.5).
  * `plateaus` = connected components of (quantised-)equal gray value; centroids
    returned as points.  `lowlands_center` = those flat components that are
    *regional minima* (every neighbouring pixel outside the component is strictly
    higher); basin centroids returned as points.

Knob ``a`` controls the detection threshold / minimum prominence (peak depth for
extrema, basin depth for lowlands, minimum area for plateaus); ``b`` is unused.
Same contract as the other backend modules: ``build()`` returns typed ``Op``
wrappers, each exception-safe and finite.
"""
from __future__ import annotations

import numpy as np

# --------------------------------------------------------------------------- #
# Fixed 3x3 quadratic-fit pseudo-inverse.                                      #
# Basis [1, x, y, x^2, y^2, x*y] over the 9 offsets (dy, dx) in {-1,0,1}^2,    #
# row-major (dy outer, dx inner) so index 4 == the centre (0, 0).             #
# --------------------------------------------------------------------------- #
_OFFS = [(dy, dx) for dy in (-1, 0, 1) for dx in (-1, 0, 1)]
_X = np.array([[1.0, dx, dy, dx * dx, dy * dy, dx * dy] for (dy, dx) in _OFFS])
_MINV = np.linalg.pinv(_X)  # (6, 9): coeffs = _MINV @ zvals


def _as_image(v):
    """Coerce input to a 2-D float64 image in [0, 1]; None if not usable.

    Integer images are scaled by their dtype range first (uint8 -> /255, uint16 ->
    /65535, int8/int16 by their positive max; wider ints such as python-list input
    are scaled by 255 / 65535 / their max according to the data range), so a 0..255
    input is no longer clipped to a flat 1.0 plateau (2026-09-02). Floats are used
    as-is and clipped to [0, 1]; bool -> {0, 1}.
    """
    arr = np.asarray(v)
    if arr.dtype == bool:
        x = arr.astype(np.float64)
    elif np.issubdtype(arr.dtype, np.integer):
        x = arr.astype(np.float64)
        if arr.dtype.itemsize <= 2:
            x /= float(np.iinfo(arr.dtype).max)
        elif x.size:
            mx = float(x.max())
            if mx > 1.0:
                x /= 255.0 if mx <= 255.0 else (65535.0 if mx <= 65535.0 else mx)
    else:
        x = np.asarray(arr, np.float64)
    if x.ndim == 3:
        x = x.mean(-1)
    if x.ndim != 2 or x.size == 0:
        return None
    x = np.nan_to_num(x, nan=0.0, posinf=1.0, neginf=0.0)
    return np.clip(x, 0.0, 1.0)


def _points_dict(shape, pts):
    """Wrap (row, col) points as CONTOUR dict — one 1x2 sub-contour per point."""
    cs = []
    H, W = shape
    for r, c in pts:
        r = float(np.clip(r, 0.0, H - 1))
        c = float(np.clip(c, 0.0, W - 1))
        if np.isfinite(r) and np.isfinite(c):
            cs.append(np.array([[r, c]], np.float64))
    return {"shape": (int(shape[0]), int(shape[1])), "cs": cs}


def _fit_grid(v):
    """Fit the 3x3 quadratic at every interior pixel.

    Returns (S, coeffs) where S is (9, M) the stacked neighbourhood values and
    coeffs is (6, M) the fitted coefficients, for the interior grid of shape
    (H-2, W-2).  None when there is no interior.
    """
    H, W = v.shape
    if H < 3 or W < 3:
        return None
    cols = []
    for (dy, dx) in _OFFS:
        cols.append(v[1 + dy:H - 1 + dy, 1 + dx:W - 1 + dx].ravel())
    S = np.stack(cols, 0)          # (9, M)
    coeffs = _MINV @ S             # (6, M)
    return S, coeffs


def _offsets(coeffs):
    """Sub-pixel offset (dx, dy) of the fitted quadratic's critical point.

    dx is along columns, dy along rows.  Uses -H^{-1} g; where the Hessian is
    (near-)singular the offset is left at 0 (caller may substitute a separable
    estimate).  Also returns det(H) and the flag of which offsets are safe.
    """
    c1, c2, c3, c4, c5 = coeffs[1], coeffs[2], coeffs[3], coeffs[4], coeffs[5]
    det = 4.0 * c3 * c4 - c5 * c5
    safe = np.abs(det) > 1e-9
    dx = np.zeros_like(det)
    dy = np.zeros_like(det)
    d = np.where(safe, det, 1.0)
    dx = np.where(safe, -(2.0 * c4 * c1 - c5 * c2) / d, 0.0)
    dy = np.where(safe, -(-c5 * c1 + 2.0 * c3 * c2) / d, 0.0)
    return dx, dy, det, safe


def _sep_offsets(S):
    """Separable 1-D parabola offsets from the 3x3 cross (fallback for extrema).

    S index map: 1=up(dy-1), 7=down(dy+1), 3=left(dx-1), 5=right(dx+1), 4=centre.
    """
    left, right, cen = S[3], S[5], S[4]
    up, down = S[1], S[7]
    denx = left - 2.0 * cen + right
    deny = up - 2.0 * cen + down
    dx = np.where(np.abs(denx) > 1e-12, 0.5 * (left - right) / np.where(np.abs(denx) > 1e-12, denx, 1.0), 0.0)
    dy = np.where(np.abs(deny) > 1e-12, 0.5 * (up - down) / np.where(np.abs(deny) > 1e-12, deny, 1.0), 0.0)
    return np.clip(dx, -0.5, 0.5), np.clip(dy, -0.5, 0.5)


def _extrema(v, a, want_max):
    """Sub-pixel local maxima (want_max) or minima points."""
    img = _as_image(v)
    if img is None:
        return _points_dict((1, 1), [])
    fit = _fit_grid(img)
    if fit is None:
        return _points_dict(img.shape, [])
    S, coeffs = fit
    Hi, Wi = img.shape[0] - 2, img.shape[1] - 2
    cen = S[4]
    others = np.delete(S, 4, axis=0)      # (8, M)
    # Non-strict comparison so an extremum sitting exactly between pixels (a 2x2
    # plateau of equal values, e.g. a blob centred at (20.5, 20.5) or an 8-bit
    # quantised peak) is not missed; the second term rejects flat neighbourhoods.
    # Adjacent candidates are necessarily equal-valued, so connected components
    # of the candidate mask are exactly the plateaus (2026-09-02 fix).
    if want_max:
        is_ext = (cen >= others.max(0)) & (cen > others.min(0))
        prom = cen - S.min(0)             # depth below the deepest neighbour
    else:
        is_ext = (cen <= others.min(0)) & (cen < others.max(0))
        prom = S.max(0) - cen
    thr = 0.01 + 0.30 * float(np.clip(a, 0.0, 1.0))
    keep = is_ext & np.isfinite(prom)
    if not keep.any():
        return _points_dict(img.shape, [])

    dxq, dyq, _det, safe = _offsets(coeffs)
    dxs, dys = _sep_offsets(S)
    # Prefer the full-3x3 quadratic offset when it is well-posed and stays in the
    # cell; otherwise fall back to the separable 1-D parabola.
    use_q = safe & (np.abs(dxq) <= 1.0) & (np.abs(dyq) <= 1.0)
    dx = np.where(use_q, dxq, dxs)
    dy = np.where(use_q, dyq, dys)
    dx = np.clip(dx, -1.0, 1.0)
    dy = np.clip(dy, -1.0, 1.0)

    from scipy import ndimage
    lab, nlab = ndimage.label(keep.reshape(Hi, Wi), structure=np.ones((3, 3), int))
    labs = lab.ravel()
    idx = np.where(keep)[0]
    li = labs[idx]
    rows = (idx // Wi) + 1 + dy[idx]
    cols = (idx % Wi) + 1 + dx[idx]
    cnt = np.bincount(li, minlength=nlab + 1).astype(np.float64)
    r_mean = np.bincount(li, weights=rows, minlength=nlab + 1) / np.maximum(cnt, 1.0)
    c_mean = np.bincount(li, weights=cols, minlength=nlab + 1) / np.maximum(cnt, 1.0)
    p_max = np.zeros(nlab + 1)
    np.maximum.at(p_max, li, prom[idx])
    pts = [(r_mean[k], c_mean[k]) for k in range(1, nlab + 1)
           if cnt[k] > 0 and p_max[k] >= thr]
    return _points_dict(img.shape, pts)


def _saddles(v, a):
    """Sub-pixel saddle points: indefinite Hessian, critical point inside cell."""
    img = _as_image(v)
    if img is None:
        return _points_dict((1, 1), [])
    fit = _fit_grid(img)
    if fit is None:
        return _points_dict(img.shape, [])
    _, coeffs = fit
    Wi = img.shape[1] - 2
    dx, dy, det, safe = _offsets(coeffs)
    # Saddle prominence = the smaller |principal curvature| (both axes must
    # genuinely curve); scale-robust unlike raw |det|.
    strength = np.minimum(np.abs(2.0 * coeffs[3]), np.abs(2.0 * coeffs[4]))
    thr = 1e-4 + 0.02 * float(np.clip(a, 0.0, 1.0))
    keep = safe & (det < 0.0) & (np.abs(dx) <= 0.5) & (np.abs(dy) <= 0.5) & (strength >= thr)
    idx = np.where(keep)[0]
    rows = (idx // Wi) + 1
    cols = (idx % Wi) + 1
    pts = [(rows[k] + dy[idx[k]], cols[k] + dx[idx[k]]) for k in range(idx.size)]
    return _points_dict(img.shape, pts)


def _critical(v, a):
    """Union of sub-pixel maxima, minima and saddle points (points only)."""
    img = _as_image(v)
    if img is None:
        return _points_dict((1, 1), [])
    mx = _extrema(img, a, True)
    mn = _extrema(img, a, False)
    sd = _saddles(img, a)
    cs = mx["cs"] + mn["cs"] + sd["cs"]
    return {"shape": mx["shape"], "cs": cs}


# --------------------------------------------------------------------------- #
# Flat-region components (plateaus) and regional-minima basins (lowlands).     #
# --------------------------------------------------------------------------- #
def _flat_components(v, q):
    """Label connected components of equal quantised gray value (4-connectivity).

    Returns an int label image (same shape).  Union-find over the equality graph:
    two 4-neighbours join iff they share the same quantised level.  Bounded by
    the number of equal adjacencies (≈0 for noisy images, all edges for flats).
    """
    H, W = v.shape
    q = max(float(q), 1e-9)
    L = np.round(v / q).astype(np.int64)
    n = H * W
    parent = np.arange(n)

    def find(x):
        root = x
        while parent[root] != root:
            root = parent[root]
        while parent[x] != root:
            parent[x], x = root, parent[x]
        return root

    def union(i, j):
        ri, rj = find(i), find(j)
        if ri != rj:
            parent[max(ri, rj)] = min(ri, rj)

    idx = np.arange(n).reshape(H, W)
    eqh = np.where(L[:, 1:] == L[:, :-1])
    for y, x in zip(eqh[0], eqh[1]):
        union(int(idx[y, x]), int(idx[y, x + 1]))
    eqv = np.where(L[1:, :] == L[:-1, :])
    for y, x in zip(eqv[0], eqv[1]):
        union(int(idx[y, x]), int(idx[y + 1, x]))

    roots = np.array([find(i) for i in range(n)]).reshape(H, W)
    return roots


def _plateaus(v, a, b):
    """Connected flat regions -> their centroid points."""
    img = _as_image(v)
    if img is None:
        return _points_dict((1, 1), [])
    H, W = img.shape
    if H * W > 200_000:                       # fail-soft guard on huge inputs
        return _points_dict(img.shape, [])
    aa = float(np.clip(a, 0.0, 1.0))
    q = 1e-6 + 0.05 * aa                       # flatness tolerance grows with a
    min_area = 2 + int(round(aa * 6))          # min plateau area grows with a
    roots = _flat_components(img, q)
    labels, counts = np.unique(roots, return_counts=True)
    yy, xx = np.mgrid[0:H, 0:W]
    pts = []
    for lab, cnt in zip(labels, counts):
        if cnt < min_area:
            continue
        m = roots == lab
        pts.append((float(yy[m].mean()), float(xx[m].mean())))
    return _points_dict(img.shape, pts)


def _lowlands_center(v, a, b):
    """Regional-minima basins -> their centroid points."""
    img = _as_image(v)
    if img is None:
        return _points_dict((1, 1), [])
    H, W = img.shape
    if H * W > 200_000:
        return _points_dict(img.shape, [])
    aa = float(np.clip(a, 0.0, 1.0))
    q = 1e-6 + 0.05 * aa
    min_depth = 0.01 + 0.40 * aa               # basin depth threshold grows with a
    roots = _flat_components(img, q)
    labels = np.unique(roots)
    yy, xx = np.mgrid[0:H, 0:W]
    pts = []
    for lab in labels:
        m = roots == lab
        val = float(img[m].mean())
        # 4-connected outer boundary of this component.
        up = np.zeros_like(m); up[:-1, :] = m[1:, :]
        dn = np.zeros_like(m); dn[1:, :] = m[:-1, :]
        lf = np.zeros_like(m); lf[:, :-1] = m[:, 1:]
        rt = np.zeros_like(m); rt[:, 1:] = m[:, :-1]
        border = (up | dn | lf | rt) & (~m)
        if border.any():
            depth = float(img[border].min()) - val
            is_min = img[border].min() > val + 1e-9   # every neighbour strictly higher
        else:
            depth = np.inf                             # no surroundings (e.g. const image)
            is_min = True
        if is_min and depth >= min_depth:
            pts.append((float(yy[m].mean()), float(xx[m].mean())))
    return _points_dict(img.shape, pts)


# --------------------------------------------------------------------------- #
# Module-level op functions (so tests can call them directly).                #
# --------------------------------------------------------------------------- #
def sp_local_max_sub_pix(v, a, b):
    return _extrema(v, a, True)


def sp_local_min_sub_pix(v, a, b):
    return _extrema(v, a, False)


def sp_saddle_points_sub_pix(v, a, b):
    return _saddles(v, a)


def sp_critical_points_sub_pix(v, a, b):
    return _critical(v, a)


def sp_plateaus(v, a, b):
    return _plateaus(v, a, b)


def sp_lowlands_center(v, a, b):
    return _lowlands_center(v, a, b)


#: 各 ``sp_*`` 関数は 1 行の委譲（docstring 無し）で、実際に登録される ``op.fn`` も
#: ``build()`` 内の ``_safe`` が返すクロージャ ``w`` であり ``__doc__`` を転記
#: しないため、素通しでは説明が消える。ここに Japanese の説明を書き ops.py の
#: 登録ループで Op.doc に積ませる。キーは op 名。座標系はどの op も CONTOUR
#: （``{"shape": (H, W), "cs": [1x2 の (row, col) 配列, ...]}``）で、単位は入力
#: 画像のピクセル（小数値＝サブピクセル位置）。
DOCS = {
    "sp_local_max_sub_pix": (
        "グレー値曲面の極大点をサブピクセル精度で検出する（HALCON "
        "``local_max_sub_pix`` の代替実装。``halcon=\"\"``: 同名の座標は既存の"
        "core op が既にカバー済みなので二重申告しない）。\n\n"
        "3x3 近傍に 2 次曲面 ``z = a0+a1 x+a2 y+a3 x^2+a4 y^2+a5 xy`` を最小二乗"
        "フィットし、勾配 0 の点へのオフセットを解いてサブピクセル位置を求める"
        "（ヘッセ行列が退化する場合は 1 次元放物線補間にフォールバック）。``a``"
        "は極大の顕著さ（周囲の最小値からの深さ）のしきい値を 0.01〜0.31 に振る"
        "（``thr = 0.01 + 0.30*a``）。``b`` は未使用。戻り値は CONTOUR、座標の"
        "単位は入力画像のピクセル（小数値＝サブピクセル）。検出点数は"
        "``count_contours`` で数えられる。"
    ),
    "sp_local_min_sub_pix": (
        "グレー値曲面の極小点をサブピクセル精度で検出する（HALCON "
        "``local_min_sub_pix`` に相当）。\n\n"
        "アルゴリズムは ``sp_local_max_sub_pix`` と対称（3x3 の 2 次曲面フィットで"
        "勾配 0 点へサブピクセル補正）。``a`` は極小の顕著さ（周囲の最大値からの"
        "深さ）のしきい値を 0.01〜0.31 に振り（``thr = 0.01 + 0.30*a``）、``b`` は"
        "未使用。戻り値は CONTOUR、座標の単位は入力画像のピクセル。暗いスポット"
        "・くぼみの検出に向く。"
    ),
    "sp_saddle_points_sub_pix": (
        "グレー値曲面の鞍点（サドルポイント）をサブピクセル精度で検出する"
        "（HALCON ``saddle_points_sub_pix`` に相当）。\n\n"
        "3x3 の 2 次曲面フィットのヘッセ行列が不定符号（``det H < 0``、両主曲率の"
        "符号が逆）になる画素を鞍点候補とし、勾配 0 点がセル内"
        "（``|dx|,|dy| <= 0.5``）に収まるものだけを残す。``a`` は鞍点の強さ"
        "（より小さい方の主曲率の絶対値）のしきい値を 1e-4〜0.0201 に振る"
        "（``thr = 1e-4 + 0.02*a``）。``b`` は未使用。戻り値は CONTOUR、座標の"
        "単位は入力画像のピクセル。"
    ),
    "sp_critical_points_sub_pix": (
        "極大・極小・鞍点のサブピクセル位置をまとめて検出する（HALCON "
        "``critical_points_sub_pix`` に相当）。\n\n"
        "``sp_local_max_sub_pix`` / ``sp_local_min_sub_pix`` / "
        "``sp_saddle_points_sub_pix`` の 3 つを同じしきい値 ``a`` で実行し、"
        "検出点を極大→極小→鞍点の順で 1 つの CONTOUR に連結する。``b`` は未使用。"
        "戻り値の座標単位は入力画像のピクセル（サブピクセル小数値）。個々の種類"
        "を区別せず「臨界点がどこにあるか」だけを知りたい場合に使う。"
    ),
    "sp_plateaus": (
        "同じ（量子化した）グレー値が連結した平坦領域（プラトー）の重心をサブ"
        "ピクセル位置として返す（HALCON ``plateaus`` に相当）。\n\n"
        "隣接画素同士がしきい値 ``q = 1e-6 + 0.05*a`` 以内で等しければ同じ平坦"
        "領域とみなす（Union-Find で連結成分化）。``a`` はこの許容量子化幅と"
        "最小面積（``min_area = 2 + round(6*a)``、これ未満の領域は無視）の両方を"
        "振る。``b`` は未使用。戻り値は CONTOUR で、各プラトーにつき 1 点（その"
        "領域の画素座標の平均、単位はピクセル）。入力が 200,000 画素を超える"
        "場合は安全側で空集合を返す（計算量ガード）。"
    ),
    "sp_lowlands_center": (
        "極小の「盆地」（周囲より低い平坦領域）の重心を返す（HALCON "
        "``lowlands_center`` に相当）。\n\n"
        "``sp_plateaus`` と同じ量子化による平坦領域抽出を行った上で、外周の画素"
        "がすべて厳密に高い（領域極小である）ものだけを残し、さらに深さ（外周の"
        "最小値との差）が ``min_depth = 0.01 + 0.40*a`` 以上のものだけを採用する。"
        "``b`` は未使用。戻り値は CONTOUR、各盆地につき 1 点（重心座標、単位は"
        "ピクセル）。入力が 200,000 画素を超える場合は安全側で空集合を返す。"
    ),
}


def build(Op, IMAGE, REGION, FEATURE, CONTOUR, norm, binm):
    """Return the sub-pixel critical-point ops (image -> contour point sets)."""
    def _safe(fn):
        def w(v, a, b):
            try:
                out = fn(v, a, b)
            except __import__("backend_safe").MissingDependencyError:   # fail-closed: no stand-in value
                raise
            except Exception as _e:  # noqa: BLE001 - recorded, strict mode re-raises
                from backend_safe import is_strict as _bs_strict, record as _bs_record
                if _bs_strict():
                    raise
                _bs_record(None, _e, "contour")
                out = None
            if isinstance(out, dict) and "cs" in out and "shape" in out:
                return out
            # Fail-soft: an empty point set with a best-effort shape.
            try:
                x = _as_image(v)
                shp = x.shape if x is not None else (1, 1)
            except Exception:
                shp = (1, 1)
            return {"shape": (int(shp[0]), int(shp[1])), "cs": []}
        # ラッパは振る舞いを包むのであって説明を消してはいけない
        # (backend_safe.guard と同じ穴。同型のラッパ族が 4 つあった)。
        w.__name__ = getattr(fn, "__name__", "op")
        w.__doc__ = getattr(fn, "__doc__", None)
        return w

    return [
        # ★2026-10-02: 以前は halcon "" で「local_max_sub_pix は core op が既にカバー」と書いていたが、
        #   core の ``local_max`` が名乗るのは画素精度の HALCON ``local_max``(サブピクセルではない)で、
        #   ``local_max_sub_pix`` を名乗る op は 1 本も無かった(accel の表だけが誤って書いていた)。
        #   兄弟の sp_local_min_sub_pix は local_min_sub_pix を名乗っており、max 側だけが空いていた。
        Op("sp_local_max_sub_pix", "subpix", "local_max_sub_pix", IMAGE, CONTOUR, _safe(sp_local_max_sub_pix)),
        Op("sp_local_min_sub_pix", "subpix", "local_min_sub_pix", IMAGE, CONTOUR, _safe(sp_local_min_sub_pix)),
        Op("sp_saddle_points_sub_pix", "subpix", "saddle_points_sub_pix", IMAGE, CONTOUR, _safe(sp_saddle_points_sub_pix)),
        Op("sp_critical_points_sub_pix", "subpix", "critical_points_sub_pix", IMAGE, CONTOUR, _safe(sp_critical_points_sub_pix)),
        Op("sp_plateaus", "subpix", "plateaus", IMAGE, CONTOUR, _safe(sp_plateaus)),
        Op("sp_lowlands_center", "subpix", "lowlands_center", IMAGE, CONTOUR, _safe(sp_lowlands_center)),
    ]
