"""engine.py — the Fullseye runtime: load a saved pipeline and run it from code.

Fullseye Studio is where you *author* an image-operator pipeline; ``FullseyeEngine``
is where you *execute* one — the runtime counterpart, analogous to MVTec's
**HDevEngine** (design a procedure in the visual tool, then call the exported
procedure from your own application without rewriting it).

A pipeline is a list of ``(op, a, b)`` stages. The engine loads one from the JSON
Studio's "Save pipeline" writes, from an ``--ops`` string, or from a Python list,
then lets you introspect its input/output sorts, tune each stage's knobs, and
execute it on a numpy frame (whole, up to a stage, or stage-by-stage). It also
``validate``-s the pipeline (unknown ops, sort mismatches) — the same check that
powers the Studio diagnostics panel.

    import fullseye
    eng = fullseye.FullseyeEngine.load("edge.json")     # or .from_ops("gaussian,sobel_amp,otsu")
    print(eng.input_sort(), "->", eng.output_sort())    # image -> region
    out = eng.run(frame)                                # numpy in, numpy out
    steps = eng.run_stepwise(frame)                     # intermediate result per stage
"""
from __future__ import annotations

import json
import os
from typing import Iterable

import numpy as np

import api
from json_safety import _loads_limited
from studio_result import StageCache, assess_validity

__all__ = ["FullseyeEngine", "diagnose_stages", "stage_name", "StageCache", "pipeline_states", "check_pipeline_header"]


def _input_hash(image):
    """A content signature for the input array, used as the first part of a stage cache key.

    Different pixels -> different key -> the cache does not serve a stale result. Hashes shape,
    dtype and **every byte** with SHA-256 (paid once per ``run_cached`` call, not per stage; about
    2 ms for a 1024x1024 float64 frame, the same as the partial hash it replaced).

    ★2026-11-04 external audit E2: only the first and the last MiB were hashed, so two
    1024x1024 float64 frames that differed in the centre pixel got the same key and the cache
    served the first frame's result for the second. An object array has no byte content to key
    on and is refused."""
    import hashlib
    h = hashlib.sha256()
    _hash_into(h, image, 0)
    return h.hexdigest()


#: :func:`_hash_into` が降りる入れ子の深さの上限(XLD は 2 段: dict → list → 配列)。
_HASH_MAX_DEPTH = 32


def _hash_into(h, v, depth):
    """*v* の内容を正準な形で *h* に流し込む(型の名・形・dtype・全 byte、dict は鍵の順に依らない)。

    ★2026-11-05(敵対的検証 第 2 巡 T8): 以前は ``np.ascontiguousarray(image)`` だけで鍵を作り、XLD 輪郭
    (``{"shape": (H, W), "cs": [(N, 2) ...]}``)は object 配列になって **contour 始まりの鎖が全部 TypeError**
    だった(contour を取る registry op は 66 本、``run`` は通る)。dict / list / tuple / 数値・文字列の
    スカラーを降りて正準化する。object 配列・未知の型は従来どおり TypeError(鍵にできる内容が無い)。"""
    if depth > _HASH_MAX_DEPTH:
        raise TypeError("run_cached: input nests deeper than %d levels" % _HASH_MAX_DEPTH)
    if isinstance(v, np.ndarray):
        arr = np.ascontiguousarray(v)
        if arr.dtype.hasobject:
            raise TypeError("run_cached: cannot key the stage cache on an object array (dtype %s)" % arr.dtype)
        h.update(b"A" + str((arr.shape, arr.dtype.str)).encode())
        h.update(memoryview(arr).cast("B") if arr.size else b"")
        return
    if isinstance(v, dict):
        try:
            keys = sorted(v, key=lambda k: (type(k).__name__, repr(k)))
        except TypeError:
            raise TypeError("run_cached: cannot key the stage cache on this dict") from None
        h.update(b"D%d:" % len(keys))
        for k in keys:
            _hash_into(h, k, depth + 1)
            _hash_into(h, v[k], depth + 1)
        return
    if isinstance(v, (list, tuple)):
        h.update((b"L" if isinstance(v, list) else b"T") + b"%d:" % len(v))
        for x in v:
            _hash_into(h, x, depth + 1)
        return
    if v is None or isinstance(v, (bool, int, float, complex, str, bytes, np.generic)):
        h.update(b"S" + ("%s|%r" % (type(v).__name__, v)).encode("utf-8", "backslashreplace"))
        return
    if hasattr(v, "__array__") and not isinstance(v, (dict, list, tuple)):
        _hash_into(h, np.asarray(v), depth + 1)
        return
    raise TypeError("run_cached: cannot key the stage cache on a %s" % type(v).__name__)


def _detached(v):
    """呼び手に返す値をキャッシュから切り離す(配列は copy、dict / list は deepcopy)。

    ★2026-11-05(敵対的検証 第 2 巡 T1): run_cached は**キャッシュの中の配列そのもの**を返しており、
    利用者が結果を書き換える(``out[:] = 0``)と次の呼び出しがその書き換えた値を返した(同じ object)。"""
    import copy
    if isinstance(v, np.ndarray):
        return v.copy()
    if isinstance(v, (dict, list, tuple)):
        return copy.deepcopy(v)
    return v


def pipeline_states(stages, image, coerce=True):
    """Per-stage ``{index, op, a, b, ran, valid, reasons}`` for a list of ``(op, a, b)`` stages.

    The browser-consumable result state (ideas 129 / 130), Qt-free. ``ran`` is True when the stage
    produced a value without raising; ``valid`` is True / False / None (not judged, from
    :func:`studio_result.assess_validity`) — an op with no success information is never reported
    valid just because it ran, and non-finite counts appear in ``reasons`` rather than being blanked.
    A stage that raises (and every stage after it) gets ``ran=False`` and an ``error`` message. No
    automatic "fix and rerun" is offered — the state only reports."""
    # ★2026-11-05(敵対的検証 C13): 以前は ``tuple(st)[1:3]`` で段を読み、dict 段は鍵の名前
    #   ("op" / "a")を float にしようとして ValueError、``(name, {"a": ..})`` は float(dict) の TypeError
    #   だった(run_pipeline は同じ段を受ける)。名前は stage_name、ノブは api._normalise_stage の 1 本。
    norm = [(stage_name(st), *api._normalise_stage(i, st, 0.5, 0.5)[1:]) for i, st in enumerate(stages)]
    out = []
    if not norm or image is None:
        return [{"index": i, "op": n, "a": a, "b": b, "ran": False, "valid": None, "reasons": []}
                for i, (n, a, b) in enumerate(norm)]
    policy = api._policy(None)
    try:
        img, prep, ops_ = api._prepare_pipeline(image, [(n, a, b) for (n, a, b) in norm], 0.5, 0.5, policy)
        steps = iter(api._pipeline_steps(img, prep, ops_, coerce, policy, api._fast_on(None)))
    except Exception as e:                           # refused before any stage ran (e.g. sort mismatch)
        return [{"index": i, "op": n, "a": a, "b": b, "ran": False, "valid": None,
                 "reasons": [], "error": str(e)} for i, (n, a, b) in enumerate(norm)]
    err = None
    for i, (n, a, b) in enumerate(norm):
        if err is not None:
            out.append({"index": i, "op": n, "a": a, "b": b, "ran": False, "valid": None,
                        "reasons": [], "error": err})
            continue
        try:
            val = next(steps)
        except StopIteration:
            err = "pipeline produced no value for this stage"
            out.append({"index": i, "op": n, "a": a, "b": b, "ran": False, "valid": None,
                        "reasons": [], "error": err})
            continue
        except Exception as e:                       # this op failed on its input
            err = str(e)
            out.append({"index": i, "op": n, "a": a, "b": b, "ran": False, "valid": None,
                        "reasons": [], "error": err})
            continue
        valid, reasons = assess_validity(val)
        out.append({"index": i, "op": n, "a": a, "b": b, "ran": True, "valid": valid, "reasons": reasons})
    return out

# Sorts that thread cleanly into one another; "any" pairs with everything.
_ANY = "any"


def _compatible(out_sort: str, in_sort: str) -> bool:
    return out_sort == in_sort or out_sort == _ANY or in_sort == _ANY


def _thread_sort(cur, op) -> str:
    """The sort flowing OUT of *op* when *cur* flows in (mirrors ``ops._effective_out_sort``).

    An op whose ``out_sort`` is ``"any"`` (``identity``) passes its input through,
    so it KEEPS the incoming sort rather than resetting it to "matches everything".
    Reading the declaration literally made ``diagnose_stages`` go blind after an
    identity stage (``[gaussian, identity, vol_gaussian]`` -> no warning while
    ``[gaussian, vol_gaussian]`` warns) and ``output_sort()`` report ``"any"``
    for a pipeline that plainly produces an image (2026-09-02 review)."""
    if op.out_sort == _ANY and cur is not None:
        return cur
    return op.out_sort


_STAGE_FORMS = "'name', (name, a, b), (name, {'a': .., 'b': ..}) or {'op': name, 'a': .., 'b': ..}"


def stage_name(stage) -> str:
    """段の書き方 5 形から **op 名だけ** を取り出す。engine / :func:`diagnose_stages` / ``unified.Pipeline``
    が共有する唯一の入口 —— 名前の取り出し方が 3 箇所で別々だと、同じ段が場所によって別の意味になる。

    受ける形: ``"gaussian"`` / ``("gaussian", 0.3, 0.5)`` / ``("gaussian", {"a": 0.3})`` /
    ``{"op": "gaussian", "a": 0.3}``(``op`` か ``name``)。ノブの読み方は呼ぶ側の仕事(engine は a / b、
    unified は kwargs)で、ここは名前の規則だけを持つ。

    ★2026-09-20(GenSpark 第 53 報 N179 / N181、設計パターン提案 ②): ``diagnose_stages`` は dict 段を
    ``st[0] if tuple else st`` で読んで **dict そのものを op 名にし**「unknown operator {'op': 'otsu'}」と
    答えていた(Studio が保存する形なのに)。``unified.Pipeline`` は dict / list 段を registry の鍵にして
    ``unhashable type: 'dict'`` で落ちた。engine の ``__init__`` と ``api._normalise_stages`` だけが正しく、
    3 本目・4 本目が別の規則で読んでいた —— 同型の入口は数えて 1 本に寄せる。
    """
    if isinstance(stage, str):
        name = stage
    elif isinstance(stage, dict):
        name = stage.get("op", stage.get("name"))
        if name is None:
            raise TypeError("a dict stage needs 'op' (or 'name'), got keys %s" % sorted(stage))
    elif isinstance(stage, (tuple, list)) and len(stage) > 0:
        name = stage[0]
    else:
        name = None
    if not isinstance(name, str) or not name.strip():
        raise TypeError("the op must be a non-empty name: a stage is %s, got %r" % (_STAGE_FORMS, stage))
    return name.strip()



def diagnose_stages(stages) -> list[dict]:
    """Validate a list of ``(op, a, b)`` stages without running them.

    Returns a list of problem dicts ``{"index", "op", "severity", "message"}``
    (``severity`` = ``"error"`` for an unknown operator **and** for a sort
    mismatch between adjacent stages). A sort-mismatch dict additionally
    carries ``"kind": "sort_mismatch"`` and ``"prev_index"`` / ``"prev_op"`` —
    the upstream stage that produced the incompatible sort. An empty list means
    the pipeline is structurally sound. Pure / Qt-free — reused by the Studio
    diagnostics panel.

    **A sort mismatch is an error (2026-10-11).** It used to be a ``"warning"``,
    so :meth:`FullseyeEngine.is_runnable` said True for ``[gaussian,
    vol_gaussian]`` and :meth:`FullseyeEngine.run` executed it (the result was a
    plausible-looking array). ``api.run_pipeline`` now refuses such a chain
    before any stage runs (``api._check_chain_sorts``), so the validator says
    the same thing the runtime does.

    **Numbering (2026-09-02).** ``index`` / ``prev_index`` are **0-based**
    (they index *stages* directly, so they can be used to select a row).
    ``message`` is prose meant for a human and numbers stages **1-based** —
    the same numbering Studio's Problems panel and the Program view show. The
    two used to be mixed inside a single rendered line ("stage 5
    (circularity_xld): stage 3 (sk_clear_border) ...", where sk_clear_border is
    the 4th stage on screen), which sent readers to the wrong stage. Format the
    dict yourself from ``prev_index`` if you need a different convention.
    """
    problems = []
    prev_out = None
    prev_name = None
    prev_index = None
    for i, st in enumerate(stages):
        try:
            name = stage_name(st)
        except TypeError as e:
            # 壊れた段は検証器の答え(error 行)であって例外ではない —— Studio の Problems 欄に出す
            problems.append({"index": i, "op": repr(st), "severity": "error", "message": "stage %d: %s" % (i + 1, e)})
            prev_out, prev_name, prev_index = _ANY, repr(st), i
            continue
        op = api.find_op(name)
        if op is None:
            # ★backend が入っていないだけの名前は「unknown」でなく不足 extra を言う(api._resolve と同じ門、2026-09-19)
            hint = api._explain_unregistered(name) if isinstance(name, str) else None
            problems.append({"index": i, "op": name, "severity": "error",
                             "message": hint or "unknown operator %r" % name})
            prev_out = _ANY            # don't cascade sort warnings past an unknown op
            prev_name = name
            prev_index = i
            continue
        if prev_out is not None and not _compatible(prev_out, op.in_sort):
            problems.append({
                "index": i, "op": op.name, "severity": "error", "kind": "sort_mismatch",
                "prev_index": prev_index, "prev_op": prev_name,
                # 1-based in the prose, to match the Problems-panel heading that
                # renders this same line's own index as index+1.
                "message": "stage %d (%s) outputs '%s' but %s expects '%s'"
                           % (prev_index + 1, prev_name, prev_out, op.name, op.in_sort)})
        prev_out = _thread_sort(prev_out, op)
        prev_name = op.name
        prev_index = i
    return problems


#: パイプラインのファイル(``to_dict`` / Studio の Save pipeline が書く JSON)の版。印 ``fullseye_pipeline`` の値。
PIPELINE_FORMAT_VERSION = 1


def check_pipeline_header(d, *, where: str = "pipeline file") -> None:
    """パイプラインのファイルの **版の印** を読むときに検査する(各読み手がここを呼ぶ。形式は変えない)。

    - ``fullseye_pipeline`` があるとき、値は整数の :data:`PIPELINE_FORMAT_VERSION`(= 1)でなければ ``ValueError``
      (``99``・``"banana"``・``1.0``・``True`` は断る。何を期待し何が来たかを言う)。**整数は Python の ``int``**:
      JSON から読んだ値はそのまま通るが、Python で dict を組む利用者は ``np.int64(1)`` を ``int()`` に通す。
    - 別の種類の印(``fullseye_graph``)を持つファイルは断る(グラフは ``FullseyeGraph.from_dict``)。``fullseye_pipeline: 1``
      と ``fullseye_graph`` の **両方** を持つ dict も断る(どちらのファイルか決められない)。
    - 印が無い古いファイル(``stages`` だけ)は今までどおり読む(警告は付けない。既存の読み手に警告の流儀が無い)。
    - dict でない入力はここでは見ない(各読み手が自分の言葉で断る)。印以外のキー(``fullseye_kind`` など)も見ない。
    """
    if not isinstance(d, dict):
        return
    if "fullseye_pipeline" in d and "fullseye_graph" in d:
        raise ValueError("%s: ambiguous file: it has both 'fullseye_pipeline' and 'fullseye_graph' (a pipeline file or a graph file, not both)"
                         % where)
    if "fullseye_pipeline" in d:
        v = d["fullseye_pipeline"]
        if type(v) is not int or v != PIPELINE_FORMAT_VERSION:
            hint = " (a numpy integer: pass int(value))" if type(v).__module__ == "numpy" else ""
            raise ValueError("%s: expected 'fullseye_pipeline': %d (a Python/JSON integer), got %r (%s)%s"
                             % (where, PIPELINE_FORMAT_VERSION, v, type(v).__name__, hint))
    elif "fullseye_graph" in d:
        raise ValueError("%s: expected a pipeline file ('fullseye_pipeline': %d), got a graph file ('fullseye_graph': %r)"
                         " -- load graphs with FullseyeGraph.from_dict"
                         % (where, PIPELINE_FORMAT_VERSION, d["fullseye_graph"]))


class _hybridmethod:
    """classmethod としてもインスタンスメソッドとしても呼べる ``load`` / ``from_dict`` / ``from_ops``。

    ★2026-09-20(GenSpark 第 16 報 N37 / N39): ``e = FullseyeEngine(); e.load(path)`` と書くと、classmethod の
    ``load`` は**新しい**エンジンを返して捨てられ、``e`` は空のまま —— ``e.run(img)`` は入力をそのまま返し、
    ``e.describe()`` は ``[]``、``e.validate()`` も ``[]``。第三者はこれを「JSON を検証せず黙って結果を返す」と
    観測した。自然な書き方なので、インスタンスに対して呼ばれたら**そのインスタンスに読み込んで self を返す**。
    """

    def __init__(self, f):
        self.f = f
        self.__doc__ = f.__doc__

    def __get__(self, obj, cls):
        import functools
        return functools.partial(self.f, cls, obj)


class FullseyeEngine:
    """Load a Fullseye pipeline and execute it programmatically.

    Construct with :meth:`load` (JSON file), :meth:`from_ops` (an ``--ops``
    string), :meth:`from_dict`, or directly from a list of ``(op, a, b)`` stages.
    """

    def __init__(self, stages: Iterable | None = None, name: str = "pipeline"):
        self.name = str(name)
        self.stages: list[list] = []
        for i, st in enumerate(stages or []):
            if isinstance(st, (tuple, list)) and len(st) == 0:
                continue                             # skip an empty/malformed stage entry
            # ★op 名は文字列でなければならない(2026-09-20): 以前は str() で何でも名前にしていたので、
            # {"op": "gaussian"} が "{'op': 'gaussian'}" という op 名になり、run で unknown operator になっていた。
            # 名前の規則は stage_name の 1 本(diagnose_stages / unified.Pipeline と共有)。
            try:
                op = stage_name(st)
            except TypeError as e:
                raise ValueError("stage %d: %s" % (i, e)) from None
            # ★2026-11-05(敵対的検証 C3): ノブの読み方は run_pipeline と同じ api._normalise_stage 1 本。
            #   以前はここだけ別の読み方で、dict 段の未知キー({"op": "threshold", "A": 0.9} の打ち間違い)と
            #   4 要素目(("threshold", 0.9, 0.5, 0.1))を黙って捨て、文字列ノブ "0.9" を float() で通していた
            #   —— run_pipeline は同じ段を TypeError で断る。同じ段は入口によらず同じ意味・同じ拒否。
            _, a, b = api._normalise_stage(i, st, 0.5, 0.5)
            self.stages.append([op, a, b])

    # ------------------------------------------------------------------ load --
    def _adopt(self, other: "FullseyeEngine") -> "FullseyeEngine":
        """*other* の中身をこのインスタンスに移す(インスタンスに対する load / from_* 用)。"""
        self.name, self.stages = other.name, list(other.stages)
        return self

    @_hybridmethod
    def from_dict(cls, self, d: dict, name: str = "pipeline") -> "FullseyeEngine":
        """Build from ``{"stages": [...], "name": ...}`` (what :meth:`to_dict` returns). On an instance,
        loads INTO that instance and returns it."""
        check_pipeline_header(d, where="from_dict")
        if not isinstance(d, dict) or "stages" not in d:
            raise ValueError("not a Fullseye pipeline dict (missing 'stages')")
        if d["stages"] is None or isinstance(d["stages"], (int, float, bool)):
            # ★2026-09-20(GenSpark 第 30 報 N107): {"stages": None} が 0 段のエンジンになり、run が入力をそのまま
            # 返していた(壊れた設定が「成功」)。[] は文書どおり恒等、None / 数値は設定の壊れ。
            raise ValueError("not a Fullseye pipeline dict: 'stages' must be a list of stages (or an ops string), got %r"
                             % (d["stages"],))
        stages = d["stages"]
        if isinstance(stages, str):
            # ★2026-09-20(GenSpark 第 30 報 N107 の 'x' の行): 文字列は 1 文字ずつ段になっていた。from_ops と同じ ops 文字列。
            stages = [t.strip() for t in stages.split(",") if t.strip()]
        built = cls(stages, name=d.get("name", name))
        return self._adopt(built) if self is not None else built

    @_hybridmethod
    def load(cls, self, path: str) -> "FullseyeEngine":
        """Load a pipeline from the JSON that Studio's "Save pipeline" writes.
        ``FullseyeEngine.load(path)`` returns a new engine; ``engine.load(path)`` loads into ``engine``."""
        path = os.fspath(path)
        with open(path, encoding="utf-8") as f:
            d = _loads_limited(f.read(), label="pipeline JSON")
        built = cls.from_dict(d, name=os.path.splitext(os.path.basename(path))[0])
        return self._adopt(built) if self is not None else built

    @_hybridmethod
    def from_ops(cls, self, ops, a: float = 0.5, b: float = 0.5,
                 name: str = "pipeline") -> "FullseyeEngine":
        """Build from a comma-separated ``--ops`` string, or a list of names (shared knobs)."""
        if isinstance(ops, (list, tuple)):
            names = [str(s).strip() for s in ops if str(s).strip()]
        else:
            names = [s.strip() for s in str(ops).split(",") if s.strip()]
        built = cls([(n, a, b) for n in names], name=name)
        return self._adopt(built) if self is not None else built

    # --------------------------------------------------------- introspection --
    def __len__(self):
        return len(self.stages)

    def op_names(self) -> list[str]:
        return [s[0] for s in self.stages]

    def describe(self) -> list[dict]:
        """Per-stage metadata: index, op, knobs, sort transform, HALCON alias."""
        out = []
        for i, (name, a, b) in enumerate(self.stages):
            op = api.find_op(name)
            out.append({
                "index": i, "op": name, "a": a, "b": b,
                "in_sort": op.in_sort if op else None,
                "out_sort": op.out_sort if op else None,
                "halcon": (op.halcon or None) if op else None,
                "known": op is not None,
            })
        return out

    def input_sort(self):
        """The sort the pipeline expects as input (first known op's in_sort)."""
        for name, *_ in self.stages:
            op = api.find_op(name)
            if op is not None:
                return op.in_sort
        return None

    def output_sort(self):
        """The sort the pipeline produces — the sort threaded through every known
        op (a pass-through op such as ``identity`` keeps the sort of the stage
        before it; only a leading pass-through op yields ``"any"``)."""
        cur = None
        for name, *_ in self.stages:
            op = api.find_op(name)
            if op is not None:
                cur = _thread_sort(cur, op)
        return cur

    def validate(self) -> list[dict]:
        """Structural problems (unknown ops / sort mismatches); [] if sound."""
        return diagnose_stages(self.stages)

    def is_runnable(self) -> bool:
        """True if every stage resolves to a known operator and adjacent stages agree on
        their sort (no errors from :meth:`validate`) — exactly when :meth:`run` will
        execute the chain instead of refusing it."""
        return not any(p["severity"] == "error" for p in self.validate())

    # ------------------------------------------------------------- parameters --
    def get_knobs(self, i: int) -> tuple:
        return (self.stages[i][1], self.stages[i][2])

    def set_knobs(self, i: int, a: float | None = None, b: float | None = None) -> "FullseyeEngine":
        """Tune stage *i*'s knobs in place; returns self for chaining."""
        # 兄弟(C3): 段の作成と同じ型の規則(数値と bool のみ、"0.9" は TypeError)
        if a is not None:
            self.stages[i][1] = api._stage_knob(i, self.stages[i][0], "a", a)
        if b is not None:
            self.stages[i][2] = api._stage_knob(i, self.stages[i][0], "b", b)
        return self

    # -------------------------------------------------------------- execution --
    def _stage_tuples(self, upto=None):
        if upto is None:
            return [tuple(s) for s in self.stages]
        # ★範囲外は断る(2026-09-20、GenSpark N40): --upto 9 / -1 が黙って全段 / 0 段になっていた
        if not isinstance(upto, (int,)) or isinstance(upto, bool) or not (0 <= int(upto) < len(self.stages)):
            raise ValueError("upto=%r: must be a stage index 0..%d (inclusive; 'run stages 0..upto')"
                             % (upto, len(self.stages) - 1))
        return [tuple(s) for s in self.stages[: int(upto) + 1]]

    def run(self, image, upto: int | None = None, coerce: bool = True):
        """Execute the pipeline on *image* (numpy in, result out).

        *upto* runs only stages ``0..upto`` (default: all); a pipeline with no
        stages returns the input unchanged. Raises ``KeyError`` if a stage names
        an unknown operator and ``ValueError`` if adjacent stages disagree on their
        sort or a knob is non-finite — both **before** any stage runs (call
        :meth:`validate` / :meth:`is_runnable` first to check). Runs through
        ``api.run_pipeline`` (dtype contract, knob check, fallback guard)."""
        stages = self._stage_tuples(upto)
        if not stages:
            return image                             # no stages -> the input, unchanged
        return api.run_pipeline(image, stages, coerce=coerce)

    def run_stepwise(self, image, coerce: bool = True) -> list:
        """Return the intermediate result after each stage (length = #stages).

        The step-through a debugger shows: ``steps[i]`` is the value after stage
        ``i``. Efficient — threads the array through once rather than re-running
        each prefix.

        Shares :meth:`run`'s stage runner (``api._prepare_pipeline`` +
        ``api._pipeline_steps``), so ``run_stepwise(x)[-1]`` equals ``run(x)``: the
        same up-front checks (sort chain, knobs), dtype contract and fallback guard.
        (2026-10-11: it called ``RT`` directly, so a uint8 frame skipped ``/255``
        and the last step disagreed with :meth:`run`.)"""
        stages = self._stage_tuples()
        if not stages:
            return []
        policy = api._policy(None)
        img, norm, ops_ = api._prepare_pipeline(image, stages, 0.5, 0.5, policy)
        return list(api._pipeline_steps(img, norm, ops_, coerce, policy, api._fast_on(None)))

    def run_cached(self, image, cache: "StageCache | None" = None):
        """Run the pipeline through a :class:`studio_result.StageCache`, recomputing only the stages a
        knob/edit changed since the last call with the SAME cache. Returns the final value.

        The engine-layer twin of the Studio stage cache, for use outside the Qt UI (the browser
        version). Pass a cache in and reuse it across calls to keep stage outputs hot; its byte
        budget bounds memory (LRU eviction). Editing stage k reuses stages 0..k-1 and recomputes
        k..n. Equivalent to :meth:`run` (per-stage threading, ``coerce`` on the first stage)."""
        if cache is None:
            cache = StageCache()
        stages = self._stage_tuples()
        if not stages or image is None:
            return image
        # ★2026-11-04 external audit E4: each stage used to go through ``run_pipeline(prev, [st])`` on
        # its own, so the chain-wide checks of :meth:`run` (sort chain, knobs, non-finite entry) never
        # saw the whole pipeline -- ``otsu,invert`` ran here while ``run`` refuses it. Prepare the
        # whole chain first (runs nothing), then resume stage by stage on the same runner Studio's
        # stage cache uses (``entry`` only for the first stage).
        policy = api._policy(None)
        fast = api._fast_on(None)
        img, norm, ops_ = api._prepare_pipeline(image, stages, 0.5, 0.5, policy)
        # ★2026-11-05(敵対的検証 C6): (1) 入口の契約(uint8 の /255 と台帳記録、extra_checks の値域、
        #   strict での拒否)は**キャッシュに当たっても毎回**通す —— 以前は第 1 段が当たると飛び、
        #   strict + extra_checks="on" で run() が断る画像を暖まった run_cached() は返していた。
        #   (2) 結果を変える状態を鍵に入れる: 照合用テンプレート(ops._MATCH_CTX、スレッドローカル)と
        #   fssystem の全パラメータ —— 以前はテンプレート A の答えをテンプレート B で返した。
        #   (3) 計算中に劣化台帳へ記録が残った段はキャッシュしない(当たると記録が消え、fallback の値が
        #   「成功」に見えた)。次の呼び出しでもう一度計算され、同じ記録が残る。
        import backend_safe
        import fssystem
        import ops as _rt_ops
        v0 = api._pipeline_entry(img, ops_[0], True, policy)
        template = _rt_ops._MATCH_CTX.get("template")
        prefix = (_input_hash(img), policy, fast,
                  None if template is None else _input_hash(template),
                  repr(sorted(fssystem.system_snapshot().items())))
        prev = v0
        for i, st in enumerate(norm):
            prefix = prefix + (tuple(st),)
            hit = cache.get(prefix)
            if hit is not None:
                prev = hit
                continue
            mark = backend_safe.mark()
            val = next(iter(api._pipeline_steps(prev, [st], [ops_[i]], True, policy, fast, entry=False)))
            if backend_safe.events_since(mark):
                prev = val                            # degraded: recompute (and re-record) next time
            else:
                prev = cache.put(prefix, val, protect=[prefix])
        return _detached(prev)        # T1: never hand out the cached object itself

    def stepwise_states(self, image, coerce: bool = True) -> list:
        """Per-stage ``ran`` / ``valid`` / ``reasons`` for this pipeline on *image*.

        Thin wrapper over :func:`pipeline_states` — the browser-consumable result state. A completed
        run is not reported valid merely for not raising; an op with no success information is left
        ``valid=None`` (not judged), and non-finite counts are named in ``reasons``."""
        return pipeline_states(self.stages, image, coerce=coerce)

    def run_file(self, in_path: str, out_path: str | None = None,
                 upto: int | None = None):
        """Read an image file, run the pipeline, optionally write the result.

        Returns the raw result. If *out_path* is given and the result is a raster
        (2-D/3-D) it is saved (a scalar/feature result is returned only)."""
        import imgio
        img = imgio.load(os.fspath(in_path))
        result = self.run(img, upto=upto)
        if out_path is not None and isinstance(result, np.ndarray) and result.ndim in (2, 3):
            imgio.save(os.fspath(out_path), result)
        return result

    # ----------------------------------------------------------------- export --
    def to_dict(self) -> dict:
        return {"fullseye_pipeline": 1, "name": self.name,
                "stages": [[op, a, b] for op, a, b in self.stages]}

    def to_ops(self) -> str:
        return ",".join(s[0] for s in self.stages)

    def _check_exportable(self, where: str) -> None:
        """書き出す前に、全段の op 名が registry に在ることを確かめる(無ければ ValueError、何も書かない)。

        ★2026-11-05(敵対的検証 C5): ``to_python`` は op 名を ``# --ops "..."`` の注釈行へ素のまま
        書いていたので、信頼できない pipeline JSON の段名に改行を入れると(``"gaussian\nimport os; ..."``)
        **書き出したスクリプトを import しただけで任意のコードが走った**。registry の名前は識別子なので、
        在る名前だけを書き出せば注入は起きない —— 在らない名前の書き出しはどのみち動かないスクリプトになる。"""
        bad = [(i, name) for i, (name, _, _) in enumerate(self.stages) if api.find_op(name) is None]
        if bad:
            raise ValueError("%s: stage(s) %s name operator(s) that are not in the registry -- refusing to "
                             "write them into generated code (check validate() first)"
                             % (where, ", ".join("%d %r" % (i, n) for i, n in bad)))

    def to_python(self) -> str:
        """The pipeline as a standalone Python function (same as Studio export).

        Every stage must name a registered operator (``ValueError`` otherwise, nothing is
        generated); the ``# --ops`` comment line is written JSON-escaped so it can never
        span more than one line."""
        self._check_exportable("to_python")
        lines = ["# -*- coding: utf-8 -*-",
                 '# --ops %s   (the same pipeline as a CLI string: fullseye run "<ops>" in.png --out out.png)'
                 % json.dumps(",".join(str(s[0]) for s in self.stages), ensure_ascii=True),
                 "import fullseye, numpy as np", "",
                 "# pipeline %r - %d stage(s); rows run top to bottom, each op reads the "
                 "previous op's output (a/b = that op's two knobs)" % (
                     self.name, len(self.stages)),
                 "def %s(frame):" % _py_ident(self.name),
                 "    return fullseye.run_pipeline(frame, ["]
        for name, a, b in self.stages:
            lines.append("        # %s" % _stage_comment(name))
            lines.append("        (%r, %s, %s)," % (name, _knob_literal(a), _knob_literal(b)))
        lines += ["    ])"]
        return "\n".join(lines) + "\n"

    def to_python_staged(self) -> str:
        """The pipeline as STEP-BY-STEP Python — the staged twin of ``to_python``.

        One call per stage with its generated comment above it and the running signal
        in ``x``, so a single stage can be copied out on its own, or your own if/for
        can branch BETWEEN stages (the two-tier interface rule: every sample exists
        both as a one-liner and as a staged form). Same name check as :meth:`to_python`
        (op names are written with ``%r``, which cannot break a line either)."""
        self._check_exportable("to_python_staged")
        fn = _py_ident(self.name)
        lines = ["# -*- coding: utf-8 -*-", "import fullseye, numpy as np", "",
                 "# pipeline %r - STAGED form: x is the running signal; copy any single" % self.name,
                 "# stage on its own, or insert your own if/for between stages.",
                 "def %s_staged(frame):" % fn,
                 "    x = frame"]
        for name, a, b in self.stages:
            lines.append("    # %s" % _stage_comment(name))
            lines.append("    x = fullseye.run_pipeline(x, [(%r, %s, %s)])"
                         % (name, _knob_literal(a), _knob_literal(b)))
        lines += ["    return x"]
        return chr(10).join(lines) + chr(10)

    def save(self, path: str) -> None:
        path = os.fspath(path)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2)

    def __repr__(self):
        return "FullseyeEngine(%r, %d stages: %s)" % (
            self.name, len(self.stages), self.to_ops() or "<empty>")


def _knob_literal(v) -> str:
    """A knob as Python source that evaluates to the SAME float (``repr`` = shortest round trip).

    ★2026-11-04 external audit E3: the exporters wrote ``%.3f``, so a 0.123456 knob ran as 0.123
    in the generated code (Studio's own export already used ``repr``). Non-finite values are
    written as ``float('nan')`` / ``float('inf')`` so the script still parses (and is refused by
    ``run_pipeline`` exactly as :meth:`FullseyeEngine.run` refuses it)."""
    f = float(v)
    if f != f or f in (float("inf"), float("-inf")):
        return "float(%r)" % repr(f)
    return repr(f)


def _stage_comment(name: str) -> str:
    """One generated comment line describing pipeline op *name* (category, HALCON
    counterpart, signal sorts, and the op's one-line doc). Studio's sample code must
    explain itself, so the GENERATOR emits the comments and every recipe, sample and
    export gets them for free. Fail-safe: lookup trouble degrades to a generic note."""
    try:
        op = api.find_op(name)
        doc = (getattr(op.fn, "__doc__", "") or "").strip().splitlines()
        doc1 = doc[0].strip() if doc else ""
        halcon = " (HALCON: %s)" % op.halcon if getattr(op, "halcon", None) else ""
        sorts = "%s -> %s" % (op.in_sort, op.out_sort)
        return " | ".join(x for x in ("%s%s" % (op.category, halcon), sorts, doc1) if x)
    except Exception:
        return "pipeline op"


def _py_ident(name: str) -> str:
    """A safe Python function name from a pipeline name (ASCII, non-keyword)."""
    import keyword
    s = "".join(c if (c.isascii() and (c.isalnum() or c == "_")) else "_" for c in str(name))
    if not s or not s.isidentifier() or keyword.iskeyword(s):
        s = "pipeline_" + s
    if not s.isidentifier() or keyword.iskeyword(s):    # e.g. a leading digit remained
        s = "pipeline"
    return s
