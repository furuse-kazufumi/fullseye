"""XLD 輪郭の生成・解析・集合演算(HALCON "Contours"/"XLD" chapter genuine, numpy).

contour = dict {shape:(H,W), cs:[Nx2 (row,col) float 配列, ...]}。
輪郭の解析幾何(接線角・多角形近似・モーメント・点内外判定)と、
閉輪郭のブール演算(ラスタライズ経由)を本物で実装。
"""
from __future__ import annotations

import numpy as np


def _contour(shape, arrays):
    return {"shape": tuple(shape), "cs": [np.asarray(a, float).reshape(-1, 2) for a in arrays]}


# ── 生成 ─────────────────────────────────────────────────────────────────────── #
def gen_circle_contour_xld(row, col, radius, n=100, start=0.0, end=2 * np.pi, shape=(256, 256)):
    """円弧輪郭を生成(gen_circle_contour_xld)。"""
    t = np.linspace(start, end, int(n))
    arr = np.column_stack([row + radius * np.sin(t), col + radius * np.cos(t)])
    return _contour(shape, [arr])


def gen_ellipse_contour_xld(row, col, phi, ra, rb, n=100, start=0.0, end=2 * np.pi, shape=(256, 256)):
    """楕円弧輪郭を生成(gen_ellipse_contour_xld)。"""
    t = np.linspace(start, end, int(n))
    x = ra * np.cos(t); y = rb * np.sin(t)
    c = col + x * np.cos(phi) - y * np.sin(phi)
    r = row + x * np.sin(phi) + y * np.cos(phi)
    return _contour(shape, [np.column_stack([r, c])])


def gen_rectangle2_contour_xld(row, col, phi, length1, length2, shape=(256, 256)):
    """回転矩形の輪郭を生成(gen_rectangle2_contour_xld)。"""
    l1, l2 = length1, length2
    corners = np.array([[-l1, -l2], [l1, -l2], [l1, l2], [-l1, l2], [-l1, -l2]], float)
    ca, sa = np.cos(phi), np.sin(phi)
    R = np.array([[ca, -sa], [sa, ca]])
    pc = corners @ R.T
    return _contour(shape, [np.column_stack([row + pc[:, 1], col + pc[:, 0]])])


def gen_contour_polygon_xld(points, shape=(256, 256)):
    """点列から多角形輪郭を生成(gen_contour_polygon_xld)。"""
    return _contour(shape, [np.asarray(points, float).reshape(-1, 2)])


def gen_cross_contour_xld(row, col, size=5.0, angle=0.0, shape=(256, 256)):
    """十字マーカー輪郭を生成(gen_cross_contour_xld)。"""
    ca, sa = np.cos(angle), np.sin(angle)
    h = [np.array([[row - size * sa, col - size * ca], [row + size * sa, col + size * ca]])]
    v = np.array([[row - size * ca, col + size * sa], [row + size * ca, col - size * sa]])
    return _contour(shape, h + [v])


def _unit_or_zero(v):
    """長さ 1 に正規化したベクトル。長さ 0 なら 0 ベクトル(床を足さない)。"""
    n = float(np.linalg.norm(v))
    return v / n if n > 0.0 else np.zeros_like(v, dtype=float)


def gen_contour_polygon_rounded_xld(points, radius=2.0, n=8, shape=(256, 256)):
    """角を丸めた多角形輪郭を生成(gen_contour_polygon_rounded_xld)。"""
    p = np.asarray(points, float).reshape(-1, 2)
    out = []
    m = len(p)
    for i in range(m):
        prev = p[(i - 1) % m]; cur = p[i]; nxt = p[(i + 1) % m]
        v1 = prev - cur; v2 = nxt - cur
        # ★1.0 前の修正 2026-11-05 abs-floor: 以前は長さに + 1e-12(座標 1e-6 で丸めの位置が相対 1e-6 ずれた)。長さ 0 の辺は
        #   以前どおり 0 ベクトル。
        v1 = _unit_or_zero(v1); v2 = _unit_or_zero(v2)
        a = cur + v1 * radius; b = cur + v2 * radius
        for t in np.linspace(0, 1, int(n)):
            out.append((1 - t) * a + t * b)
    out.append(out[0])
    return _contour(shape, [np.asarray(out)])


# ── 解析 ─────────────────────────────────────────────────────────────────────── #
def get_contour_angle_xld(contour, k=2):
    """輪郭に沿った接線角(ラジアン)を各点で返す(get_contour_angle_xld)。"""
    out = []
    for a in contour["cs"]:
        d = np.gradient(a, axis=0)
        out.append(np.arctan2(d[:, 0], d[:, 1]))
    return out


def _cross2d(a, b):
    """2D ベクトルの外積(z 成分のスカラー)。numpy>=2.0 で ``np.cross`` の 2 次元
    入力対応が削除される見込みのため、明示式で代替(数式は等価: a×b の z 成分)。"""
    return a[..., 0] * b[..., 1] - a[..., 1] * b[..., 0]


def get_polygon_xld(contour, tolerance=2.0):
    """Douglas-Peucker で輪郭を多角形近似(get_polygon_xld)。頂点列を返す。"""
    def dp(pts, eps):
        if len(pts) < 3:
            return pts
        start, end = pts[0], pts[-1]
        line = end - start; L = float(np.linalg.norm(line))
        # 閉じた輪郭(始点 = 終点)は始点からの距離で分ける(以前は + 1e-12 で割って同じ扱い)
        d = (np.abs(_cross2d(line, pts - start)) / L if L > 0.0
             else np.linalg.norm(pts - start, axis=1))
        idx = int(d.argmax())
        if d[idx] > eps:
            left = dp(pts[:idx + 1], eps); right = dp(pts[idx:], eps)
            return np.vstack([left[:-1], right])
        return np.vstack([start, end])

    out = []
    for a in contour["cs"]:
        closed = len(a) > 2 and np.allclose(a[0], a[-1])
        if closed:
            # 閉輪郭は始点から最遠の点で 2 分割してから DP(退化回避)
            far = int(np.hypot(a[:, 0] - a[0, 0], a[:, 1] - a[0, 1]).argmax())
            p1 = dp(a[:far + 1], tolerance); p2 = dp(a[far:], tolerance)
            out.append(np.vstack([p1[:-1], p2]))
        else:
            out.append(dp(a, tolerance))
    return out


def _strip_closing_point(a):
    """閉輪郭の重複した終点(始点と同じ)を落とす(点統計の偏り防止)。"""
    a = np.asarray(a, float).reshape(-1, 2)
    if len(a) > 2 and np.allclose(a[0], a[-1]):
        return a[:-1]
    return a


def moments_any_points_xld(contour):
    """輪郭点集合の重心・2 次中心モーメント(点あたり平均)(moments_any_points_xld)。
    閉輪郭の重複終点は数えない。"""
    cs = [_strip_closing_point(a) for a in contour["cs"]]
    cs = [a for a in cs if len(a)]
    if not cs:
        raise ValueError("moments_any_points_xld: contour has no points")
    pts = np.vstack(cs)
    c = pts.mean(0)
    d = pts - c
    return {"centroid": c, "m20": float((d[:, 1] ** 2).mean()),
            "m02": float((d[:, 0] ** 2).mean()), "m11": float((d[:, 0] * d[:, 1]).mean()),
            "n": len(pts)}


def get_regress_params_xld(contour):
    """輪郭点への回帰直線パラメータ(法線 nr,nc と原点距離 dist、重心 row,col)
    (get_regress_params_xld)。fail-closed: 2 点未満の輪郭は ``ValueError``
    (以前は NaN を返していた)。"""
    out = []
    for k, a in enumerate(contour["cs"]):
        a = _strip_closing_point(a)
        if len(a) < 2:
            raise ValueError(f"get_regress_params_xld: contour {k} needs >= 2 points (got {len(a)})")
        c = a.mean(0); d = a - c
        _, V = np.linalg.eigh(np.cov(d.T))
        direction = V[:, 1]                                 # 最大分散方向
        normal = np.array([-direction[1], direction[0]])
        out.append({"nr": float(normal[0]), "nc": float(normal[1]),
                    "dist": float(normal @ c), "row": float(c[0]), "col": float(c[1])})
    return out


def test_xld_point(contour, row, col):
    """点が閉輪郭の内部にあるか(交差数法)(test_xld_point)。
    **閉じていない輪郭(始点≠終点)は HALCON と同じく常に False**(以前は暗黙に
    始点-終点を結んで判定していた: 半円の中心が True になっていた)。"""
    res = []
    for a in contour["cs"]:
        n = len(a)
        if n < 3 or not np.allclose(a[0], a[-1]):
            res.append(False)
            continue
        inside = False; j = n - 1
        for i in range(n):
            ri, ci = a[i]; rj, cj = a[j]
            if ((ci > col) != (cj > col)) and \
               (row < (rj - ri) * (col - ci) / (cj - ci + 1e-12) + ri):
                inside = not inside
            j = i
        res.append(inside)
    return res


def local_max_contours_xld(contour, image):
    """輪郭上でグレー値が局所最大となる点を抽出(local_max_contours_xld)。"""
    im = np.asarray(image, float); out = []
    for a in contour["cs"]:
        rr = np.clip(a[:, 0].round().astype(int), 0, im.shape[0] - 1)
        cc = np.clip(a[:, 1].round().astype(int), 0, im.shape[1] - 1)
        g = im[rr, cc]
        loc = np.nonzero((g[1:-1] > g[:-2]) & (g[1:-1] > g[2:]))[0] + 1
        out.append(a[loc])
    return out


# ── 閉輪郭ブール演算(ラスタライズ経由)──────────────────────────────────────── #
def _rasterize(arr, shape):
    from matplotlib.path import Path
    H, W = shape
    rr, cc = np.mgrid[0:H, 0:W]
    pts = np.column_stack([rr.ravel(), cc.ravel()])
    return Path(arr).contains_points(pts).reshape(H, W)


def _trace_mask_boundaries(mask):
    """2 値マスクの境界を **画素の辺(crack)に沿って追跡**し、閉ループのリストを返す。

    各ループは (K,2) の (row, col) float で始点==終点、頂点は画素の角(半整数座標)。
    外側境界も穴も、連結成分ごとに 1 本ずつ別のループになる。多角形面積は
    マスクの画素数に厳密に一致する。斜め接触は 4 連結として分ける(右折優先)。
    2026-09-02 以前は境界画素を重心まわりの角度でソートしていたため、星形でない
    領域(三日月・環)がぐちゃぐちゃになり面積も 6-13 % 小さかった。
    """
    m = np.asarray(mask, bool)
    if m.ndim != 2 or not m.any():
        return []
    H, W = m.shape
    pad = np.zeros((H + 2, W + 2), bool)
    pad[1:-1, 1:-1] = m
    pr, pc = np.nonzero(pad)
    # 各画素の 4 辺: 外側に隣接する辺だけを、画面上時計回り(内側が進行方向右手)で出す
    top = ~pad[pr - 1, pc]; right = ~pad[pr, pc + 1]
    bottom = ~pad[pr + 1, pc]; left = ~pad[pr, pc - 1]
    starts, ends = [], []
    starts.append(np.column_stack([pr[top], pc[top]])); ends.append(np.column_stack([pr[top], pc[top] + 1]))
    starts.append(np.column_stack([pr[right], pc[right] + 1])); ends.append(np.column_stack([pr[right] + 1, pc[right] + 1]))
    starts.append(np.column_stack([pr[bottom] + 1, pc[bottom] + 1])); ends.append(np.column_stack([pr[bottom] + 1, pc[bottom]]))
    starts.append(np.column_stack([pr[left] + 1, pc[left]])); ends.append(np.column_stack([pr[left], pc[left]]))
    S = np.vstack(starts); E = np.vstack(ends)
    key = lambda p: (int(p[0]), int(p[1]))  # noqa: E731
    out_edges: dict = {}
    for s, e in zip(S, E):
        out_edges.setdefault(key(s), []).append(key(e))
    for k in out_edges:
        out_edges[k].sort()
    loops = []
    for start in sorted(out_edges):
        while out_edges[start]:
            cur = start
            prev_dir = None
            loop = [start]
            while True:
                cands = out_edges[cur]
                if not cands:
                    break
                if len(cands) == 1 or prev_dir is None:
                    nxt = cands.pop(0)
                else:
                    # 右折優先(画面上時計回り): cross = dc1*dr2 - dr1*dc2 が最大の候補
                    best = max(range(len(cands)), key=lambda i: prev_dir[1] * (cands[i][0] - cur[0])
                               - prev_dir[0] * (cands[i][1] - cur[1]))
                    nxt = cands.pop(best)
                prev_dir = (nxt[0] - cur[0], nxt[1] - cur[1])
                loop.append(nxt)
                cur = nxt
                if cur == start:
                    break
            if len(loop) >= 4 and loop[0] == loop[-1]:
                arr = np.asarray(loop, float) - 1.5           # padded corner -> image coords
                loops.append(arr)
    # 外側境界(面積大)を先に
    def _area(a):
        y, x = a[:, 0], a[:, 1]
        return abs(float(np.dot(x, np.roll(y, -1)) - np.dot(np.roll(x, -1), y)))
    loops.sort(key=_area, reverse=True)
    return loops


def _mask_to_contour(mask, shape):
    """マスク → 境界ループ(外側 + 穴、成分ごと 1 本)の閉輪郭。"""
    return _contour(shape, _trace_mask_boundaries(mask))


def _binop_closed(c1, c2, op):
    shape = c1.get("shape", (256, 256))
    m1 = np.zeros(shape, bool)
    for a in c1["cs"]:
        m1 |= _rasterize(a, shape)
    m2 = np.zeros(shape, bool)
    for a in c2["cs"]:
        m2 |= _rasterize(a, shape)
    res = op(m1, m2)
    return _mask_to_contour(res, shape)


def union2_closed_contours_xld(contour1, contour2):
    """2 閉輪郭の和(union2_closed_contours_xld)。"""
    return _binop_closed(contour1, contour2, lambda a, b: a | b)


def intersection_closed_contours_xld(contour1, contour2):
    """2 閉輪郭の積(intersection_closed_contours_xld)。"""
    return _binop_closed(contour1, contour2, lambda a, b: a & b)


def difference_closed_contours_xld(contour1, contour2):
    """2 閉輪郭の差(difference_closed_contours_xld)。"""
    return _binop_closed(contour1, contour2, lambda a, b: a & ~b)


def symm_difference_closed_contours_xld(contour1, contour2):
    """2 閉輪郭の対称差(symm_difference_closed_contours_xld)。"""
    return _binop_closed(contour1, contour2, lambda a, b: a ^ b)
