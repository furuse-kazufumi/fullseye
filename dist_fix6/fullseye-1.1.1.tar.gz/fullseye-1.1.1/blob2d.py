# Copyright (c) 2026 Kazufumi Furuse. Licensed under the Apache License, Version 2.0 (see LICENSE).
"""blob2d — 2-D の**連結成分**と、**物体ごと**の形の特徴量。

## なぜ要るか(2026-09-06)

`examples/poc_cell_counting.py` が「2 次元の連結成分ラベリングと per-object の
region props が facade に無い」と書いた。3 層すべてを引いて確かめた結果、
**本当に無かった**(この repo は同じ形で一度間違えているので、今度は先に引いた):

* ``fullseye.ledger.label_components`` / ``region_props`` は **3-D 専用**。
  2-D を渡すと ``ValueError: a 3D voxel array (ndim==3) is required`` で拒否
  される(fail-closed なので嘘は出ないが、2-D では使えない)。
* ``circularity`` / ``eccentricity`` / ``area_center`` / ``select_shape`` /
  ``blob_count`` / ``select_largest`` は**進化 op のレジストリ**
  (``fullseye.op.*``)にしかなく、いずれも画像 1 枚 → スカラ 1 個か画像 1 枚。
  「2 番目の物体の面積」は取り出せない。
* ラベリング自体は ``ndimage.label`` として **op の実装の中**には 20 か所以上
  ある。だがどれも結果を画像かスカラに畳んでから返すので、利用者には出て
  こない。**実装があることと、公開経路があることは別**。

つまり閾値処理のあとの定番の連鎖 —— 領域を物体に切り、物体ごとに測り、
条件で選ぶ —— が、この道具では書けなかった。

## 内容(11 op)

    切る     `blob_label`          … 二値領域 → ラベル画像(4/8 連結)
    測る     `blob_features`       … 物体ごとの 19 項目(面積・重心・慣性主軸…)
    選ぶ     `blob_select`         … 特徴量の範囲で残す(番号は振り直す)
             `blob_select_largest` … 面積の大きい順に n 個
    割る     `blob_distance`       … 背景までの距離(**画素単位。正規化しない**)
             `blob_seeds`          … h-maxima の種(**h は絶対値**)
             `blob_split`          … 種から分水嶺で融合した塊を割る
    数える   `blob_count_interval` … 重なった塊の個数。決まらなければ区間で返す
    取り出す `blob_region`         … 1 個を二値領域として抜く
             `blob_boundaries`     … 物体の輪郭(1 画素幅)
    見る     `blob_overlay`        … 元画像の上に色分けして重ねる

## 規約

* 画像は ``img[i, j]``、``i`` = 行 = y(下向き)、``j`` = 列 = x(右向き)。
* **入力の領域は「0 より大きい画素が前景」**。bool でも実数でもよい。
  NaN は前景にしない(``> 0`` が False になる)。
* ラベルは ``int32``、**背景 = 0、物体 = 1..n の連番**。歯抜けにしない
  (``blob_select`` は残った物体を振り直す)—— 歯抜けを許すと
  ``features["area"][k]`` の ``k`` が何の番号なのか呼び手が追えなくなる。
* ``spacing`` は**画素 1 個の大きさ**[任意単位/px]。長さはこれを、面積は
  その 2 乗を掛けて返す。**bbox と重心の行列番号だけは画素のまま** ——
  あれは長さではなく添字だから。返り値の ``"units"`` に全項目の単位を
  入れてあるので、読み違えたら表で気づける。
* ``angle`` は**行列座標系**での傾き:「+列(右)方向から +行(下)方向へ」正。
  画面上では時計回りが正になる —— 数学の慣習と符号が逆なので、
  ``blob_features`` の返り値の ``units["angle"]`` にもそう書いてある。

## 測って決めたこと

いずれも本ファイルの実装で 2026-09-06 に実測(``tests/test_blob2d.py`` が固定):

* **周長は数え方を 3 つ測ってから選んだ。** 半径 40 px の円板(真値
  251.33 px)で、境界画素を数えると 316 px(**+25.7 %**)、Serra の重みなら
  263.8 px(**+4.95 %**、大きさを変えても同じ率)、Crofton の 4 方向なら
  252.8 px(**+0.56 %**)。円形度が 0.908 で頭打ちになるか 0.988 まで届くかが
  ここで決まるので、Crofton を採った(:func:`_perimeter` に表)。
* **4 連結と 8 連結は「斜めに触れる 2 つ」で割れる。** 市松に並べた 2 個は
  8 連結で 1 個、4 連結で 2 個。既定は 8 —— HALCON の ``connection`` と
  ``ndimage.label`` の既定に合わせる(``poc_cell_counting`` の実測では
  4 連結にすると細胞が過剰計数された)。
* **``solidity`` の分母は凸包を塗り直して数える。** 多角形として面積を出すと
  「画素を点と見るか正方形と見るか」でどちらかへ必ずずれ、**凸な物体の
  solidity が 1 にならない**(半径 40 px の円板で 0.977 か 1.025)。分子が
  画素の数なら分母も画素の数で揃える —— 塗り直すと 1.000 になる。
* **2 次モーメントに 1/12 を足す。** 画素を点ではなく 1 辺 1 の正方形として
  扱う補正で、これが無いと 1 画素幅の線で ``minor`` が 0 になり
  ``eccentricity`` が 1 に張り付く。

来歴(公開文献のみ): Serra, *Image Analysis and Mathematical Morphology*
(Academic Press, 1982)—— Crofton の公式による周長推定 / Hu, *IRE Trans.
Inf. Theory* 8 (1962) 179 —— 2 次モーメントと慣性主軸 / Rosenfeld & Pfaltz,
*J. ACM* 13 (1966) 471 —— 連結成分ラベリング。
"""
from __future__ import annotations

import math
from typing import Any, Optional

import numpy as np
from scipy import ndimage

__all__ = [
    "blob_label", "blob_features", "blob_select", "blob_select_largest",
    "blob_region", "blob_boundaries", "blob_overlay",
    "blob_distance", "blob_seeds", "blob_split", "blob_count_interval",
    "FEATURE_KEYS", "CONNECTIVITIES", "COUNT_STATUSES",
    "PEAK_NOISE", "PEAK_AMBIGUOUS", "PEAK_SURE",
]

#: 受け付ける連結の定義。既定は 8(``ndimage.label`` と HALCON の既定)。
CONNECTIVITIES: tuple[int, int] = (4, 8)

#: :func:`blob_features` が返す物体ごとの項目(``blob_select`` が選べる鍵)。
FEATURE_KEYS: tuple[str, ...] = (
    "label", "area", "row", "col", "bbox_r0", "bbox_c0", "bbox_r1", "bbox_c1",
    "perimeter", "equiv_diameter", "major", "minor", "angle", "eccentricity",
    "circularity", "extent", "solidity", "holes", "touches_border",
)

#: Crofton の公式(4 方向)で周長を数えるための 2x2 近傍の符号化。
_PERIM_KERNEL = np.array([[0, 0, 0],
                          [0, 1, 4],
                          [0, 2, 8]], dtype=np.int32)

#: 符号 0..15 に配る長さ。4 方向(0°/45°/90°/135°)の投影の重みつき平均。
_PERIM_COEF = np.array([
    0.0,
    math.pi / 4 * (1 + 1 / math.sqrt(2)),
    math.pi / (4 * math.sqrt(2)),
    math.pi / (2 * math.sqrt(2)),
    0.0,
    math.pi / 4 * (1 + 1 / math.sqrt(2)),
    0.0,
    math.pi / (4 * math.sqrt(2)),
    math.pi / 4,
    math.pi / 2,
    math.pi / (4 * math.sqrt(2)),
    math.pi / (4 * math.sqrt(2)),
    math.pi / 4,
    math.pi / 2,
    0.0,
    0.0,
], dtype=np.float64)


# --------------------------------------------------------------------------- #
# 入力検証 — fail closed                                                       #
# --------------------------------------------------------------------------- #
def _as_binary(region: Any, op: str, name: str = "region") -> np.ndarray:
    """2-D の前景マスクとして受ける(``> 0`` が前景。NaN は背景)。"""
    a = np.asarray(region)
    if a.ndim != 2:
        raise ValueError(
            f"{op}: {name} must be a 2-D region, got ndim={a.ndim}. "
            "3-D volumes have their own family (label_components / region_props)")
    if a.size == 0:
        raise ValueError(f"{op}: {name} is empty")
    if a.dtype == bool:
        return a
    f = np.asarray(a, np.float64)
    return np.nan_to_num(f, nan=0.0, posinf=0.0, neginf=0.0) > 0.0


def _as_labels(labels: Any, op: str, name: str = "labels") -> np.ndarray:
    """ラベル画像として受ける。**bool と実数のラベルは拒否する**。

    ``blob_label`` の出力は ``int32`` で、番号は 1..n の連番。実数配列を
    許すと ``0.999`` のような値がどの物体なのか決められず、丸め方の違いで
    静かに別の答えが出る —— なので整数だけを通す。
    """
    a = np.asarray(labels)
    if a.ndim != 2:
        raise ValueError(f"{op}: {name} must be a 2-D label image, got ndim={a.ndim}")
    if a.size == 0:
        raise ValueError(f"{op}: {name} is empty")
    if a.dtype == bool:
        # 二値をそのまま渡されたら「物体 1 個」ではなく **ラベリングし直す**
        # のが正しいので、ここでは受けずに直し方を出す。
        raise ValueError(
            f"{op}: {name} is a boolean mask, not a label image. "
            "Call blob_label(mask) first - a mask holding several separate "
            "objects would otherwise be measured as one blob and return "
            "plausible nonsense (one centroid between two cells)")
    if not np.issubdtype(a.dtype, np.integer):
        raise ValueError(
            f"{op}: {name} must have an integer dtype, got {a.dtype}. "
            "blob_label returns int32; a float label image cannot be indexed "
            "without a rounding rule")
    if int(a.min()) < 0:
        raise ValueError(f"{op}: {name} has negative labels (min={int(a.min())})")
    return np.asarray(a, np.int32)


def _positive_float(value: Any, op: str, name: str) -> float:
    v = float(value)
    if not math.isfinite(v) or v <= 0.0:
        raise ValueError(f"{op}: {name} must be finite and > 0, got {value!r}")
    return v


# --------------------------------------------------------------------------- #
# 1. 切る                                                                      #
# --------------------------------------------------------------------------- #
def blob_label(region: Any, connectivity: int = 8) -> np.ndarray:
    """二値領域を連結成分に分け、``int32`` のラベル画像(背景 0、物体 1..n)を返す。

    Parameters
    ----------
    region : array_like
        2-D。``> 0`` が前景(bool でも実数でもよい。NaN は背景)。
    connectivity : {4, 8}
        斜めに触れる 2 画素をつなぐか。既定 8 は対角接続も同じ成分にする。
        ``ndimage.label`` の既定は 4 連結なので異なる。**4 にすると斜めに接した塊が
        別々に数えられる**。

    Returns
    -------
    numpy.ndarray
        ``(H, W)`` の ``int32``。番号は 1 から連番で歯抜けが無い。

    Examples
    --------
    >>> import numpy as np
    >>> m = np.zeros((6, 9), bool); m[1:4, 1:4] = True; m[1:4, 5:8] = True
    >>> int(blob_label(m).max())
    2
    """
    if connectivity not in CONNECTIVITIES:
        raise ValueError(
            f"blob_label: connectivity must be 4 or 8, got {connectivity!r}")
    m = _as_binary(region, "blob_label")
    st = (np.ones((3, 3), bool) if connectivity == 8
          else ndimage.generate_binary_structure(2, 1))
    lab, _ = ndimage.label(m, structure=st)
    return np.asarray(lab, np.int32)


# --------------------------------------------------------------------------- #
# 2. 測る                                                                      #
# --------------------------------------------------------------------------- #
def _perimeter(mask: np.ndarray) -> float:
    """Crofton の公式(4 方向)による周長[px]。

    **数え方を 3 つ測ってから選んだ**(2026-09-06 実測、半径 r の円板):

        r     真値      境界画素を数える     Serra の重み     Crofton 4 方向
        10    62.83     76 (+21.0 %)         65.94 (+4.95 %)  65.20 (+3.77 %)
        20   125.66    156 (+24.1 %)        131.88 (+4.95 %) 127.71 (+1.63 %)
        40   251.33    316 (+25.7 %)        263.76 (+4.95 %) 252.75 (+0.56 %)

    素朴に境界画素を数えると 2 割超の過大。Serra の重み(1 / √2 / (1+√2)/2)は
    **大きさを変えても +4.95 % のまま**で、円板の円形度が 0.908 で頭打ちになる
    —— 「円らしさ 0.9 以上」で切る使い方が成り立たない。Crofton は大きさとともに
    真値へ寄り、r=40 で円形度 0.988。

    **正直に書いておく偏り**: 軸に平行な多角形は逆に小さく出る。20x20 の正方形
    (真値 80)で 74.73(**-6.6 %**)、円形度は π/4 = 0.785 のところ 0.900。
    角ばった物体の円形度を絶対値で語らないこと(相対比較なら向きは保たれる)。
    """
    img = np.pad(mask, 1).astype(np.uint8)
    if not img.any():
        return 0.0
    code = ndimage.convolve(img, _PERIM_KERNEL, mode="constant", cval=0)
    hist = np.bincount(code.ravel(), minlength=16)
    return float(_PERIM_COEF @ hist[:16])


def _convex_area(mask: np.ndarray) -> float:
    """凸包を**塗り直して**数えた面積[px^2](``solidity`` の分母)。

    多角形としての凸包面積ではなく、**凸包の中に中心が入る画素の数**を返す。
    理由は測って決めた(2026-09-06、半径 40 px の円板 = 凸なので真値は 1.0):

        画素の角で多角形の面積 …… 5140 px^2 → solidity 0.977(凸なのに 1 未満)
        画素の中心で多角形面積 …… 4900 px^2 → solidity 1.025(1 を超える)
        凸包を塗り直して数える …… 5025 px^2 → **solidity 1.000**

    多角形の面積は「画素を点と見るか正方形と見るか」でどちらかへ必ずずれ、
    凸な物体の solidity が 1 にならない。分子(面積)が画素の数である以上、
    分母も画素の数で揃えるのが筋が通る。

    退化(1 画素、1 画素幅の線)では凸包が作れないので、そのときは
    **面積そのもの**を返す = solidity 1.0。線分も 1 点も凸なので正しい。
    """
    rows = np.nonzero(mask.any(axis=1))[0]
    if rows.size == 0:
        return 0.0
    # 凸包の頂点は「その行のいちばん左かいちばん右」にしかない(それ以外は
    # 2 点を結ぶ線分の内側)。行ごとの両端だけ渡せば包は変わらず、点数が
    # 物体の周長ではなく**高さ**に比例する。
    first = np.argmax(mask, axis=1)
    last = mask.shape[1] - 1 - np.argmax(mask[:, ::-1], axis=1)
    pts = np.concatenate([np.stack([rows, first[rows]], 1),
                          np.stack([rows, last[rows]], 1)]).astype(np.float64)
    hull = _monotone_chain(pts)
    if hull.shape[0] < 3:                # 1 点・共線 —— どちらも凸なので 1.0
        return float(mask.sum())
    gr, gc = np.mgrid[0:mask.shape[0], 0:mask.shape[1]]
    grid = np.stack([gr.ravel(), gc.ravel()], 1).astype(np.float64)
    a = hull
    b = np.roll(hull, -1, axis=0)
    e = b - a                            # 各辺のベクトル
    # ★符号に注意: 頂点は (row, col) の順で並んでいるので、``_monotone_chain``
    #   が返す向きは (row を x と見た) 反時計回り = 画面では時計回り。内側は
    #   外積が**非負**の側になる(``<= 0`` と書いて全物体 solidity 0 を出した)。
    cross = (e[None, :, 0] * (grid[:, None, 1] - a[None, :, 1])
             - e[None, :, 1] * (grid[:, None, 0] - a[None, :, 0]))
    return float(np.all(cross >= -1e-9, axis=1).sum())


def _monotone_chain(pts: np.ndarray) -> np.ndarray:
    """Andrew の monotone chain による凸包(頂点を反時計回りで返す)。

    Qhull を呼ばないのは速さのため —— 512x512 に 153 物体を撒いて
    ``_convex_area`` 全体を測ると ``ConvexHull`` 版 74.1 ms に対して
    19.4 ms(**3.8 倍**、2026-09-06 実測)。小さな点集合を何千回も包む
    用途では Qhull の起動費が支配的になる。``blob_features`` 全体では
    100.4 ms → 33.6 ms。
    """
    p = np.unique(pts, axis=0)           # 辞書順に整列もされる
    if p.shape[0] < 3:
        return p

    def _half(seq):
        out: list = []
        for q in seq:
            while len(out) >= 2:
                o, t = out[-2], out[-1]
                if (t[0] - o[0]) * (q[1] - o[1]) - (t[1] - o[1]) * (q[0] - o[0]) <= 0:
                    out.pop()
                else:
                    break
            out.append(q)
        return out

    lower = _half(p)
    upper = _half(p[::-1])
    return np.asarray(lower[:-1] + upper[:-1], np.float64)


def blob_features(labels: Any, spacing: float = 1.0) -> dict:
    """物体ごとの形の特徴量を、**鍵ごとに 1 本の配列**で返す。

    Parameters
    ----------
    labels : array_like
        :func:`blob_label` の出力(整数、背景 0)。
    spacing : float
        画素 1 個の大きさ[単位/px]。長さにこれを、面積にその 2 乗を掛ける。
        **既定 1.0 = 画素のまま**。

    Returns
    -------
    dict
        ``n``(物体数 = 実際に在るラベルの数)、``spacing``、``units``(項目 → 単位の対応)と、
        長さ ``n`` の配列 19 本(:data:`FEATURE_KEYS`)。物体が 0 個でも
        鍵は全部揃えて空配列で返す(呼び手が分岐しなくて済む)。ラベルに歯抜けがあると
        ``n`` は ``labels.max()`` より小さい —— 物体は ``f["label"]`` の列で引くこと
        (``f["area"][label - 1]`` は歯抜けの後ろでずれる)。

    Notes
    -----
    * ``angle`` は**行列座標系**の傾き(+列 → +行 が正 = 画面では時計回り)。
    * ``major`` / ``minor`` は**同じ 2 次モーメントを持つ楕円**の軸長
      (``4 sqrt(lambda)``)。画素の並びの外接ではないので、正方形に対しては
      辺長より少し長く出る —— これは定義どおりで、誤差ではない。
    * ``circularity`` は ``4 pi A / P^2`` を **1 で頭打ち**にした値(数画素の物体では周長の
      推定が面積に比べて短く出て 1 を超える —— 1 画素の塊で 1.75 —— が、円より丸い形は無い)。
      **HALCON の ``circularity`` は
      「面積 / 最遠点を半径とする円の面積」で別物**なので、値を突き合わせる
      ときは定義を確かめること。
    * ``touches_border`` が True の物体は、面積も周長も**切れた分だけ小さい**。
      数える前に捨てるか、真値の側も同じ規約で数えること。

    Examples
    --------
    >>> import numpy as np
    >>> m = np.zeros((20, 20), bool); m[4:14, 4:9] = True
    >>> f = blob_features(blob_label(m))
    >>> int(f["n"]), float(f["area"][0])
    (1, 50.0)
    """
    lab = _as_labels(labels, "blob_features")
    sp = _positive_float(spacing, "blob_features", "spacing")
    n = int(lab.max())

    units = {
        "label": "-", "area": "unit^2", "row": "px", "col": "px",
        "bbox_r0": "px index", "bbox_c0": "px index",
        "bbox_r1": "px index (exclusive)", "bbox_c1": "px index (exclusive)",
        "perimeter": "unit", "equiv_diameter": "unit", "major": "unit",
        "minor": "unit", "angle": "rad (+col -> +row, clockwise on screen)",
        "eccentricity": "-", "circularity": "-", "extent": "-",
        "solidity": "-", "holes": "count", "touches_border": "bool",
    }
    out: dict = {"n": n, "spacing": sp, "units": units}
    if n == 0:
        for k in FEATURE_KEYS:
            out[k] = np.zeros(0, np.float64)
        out["label"] = np.zeros(0, np.int32)
        out["holes"] = np.zeros(0, np.int32)
        for k in ("bbox_r0", "bbox_c0", "bbox_r1", "bbox_c1"):
            out[k] = np.zeros(0, np.int32)
        out["touches_border"] = np.zeros(0, bool)
        return out

    objs = ndimage.find_objects(lab)
    h, w = lab.shape
    cols: dict = {k: [] for k in FEATURE_KEYS}
    for idx, sl in enumerate(objs, start=1):
        if sl is None:                                # 歯抜けのラベル(通常来ない)
            continue
        sub = lab[sl] == idx
        r0, r1 = int(sl[0].start), int(sl[0].stop)
        c0, c1 = int(sl[1].start), int(sl[1].stop)
        area_px = float(sub.sum())

        rr, cc = np.nonzero(sub)
        rr = rr + r0
        cc = cc + c0
        row = float(rr.mean())
        col = float(cc.mean())

        # 2 次中心モーメント。1/12 は画素を点でなく 1 辺 1 の正方形として扱う補正。
        mu20 = float(((cc - col) ** 2).mean()) + 1.0 / 12.0
        mu02 = float(((rr - row) ** 2).mean()) + 1.0 / 12.0
        mu11 = float(((cc - col) * (rr - row)).mean())
        common = math.sqrt(max((mu20 - mu02) ** 2 + 4.0 * mu11 * mu11, 0.0))
        lam1 = 0.5 * (mu20 + mu02 + common)           # 長軸側
        lam2 = max(0.5 * (mu20 + mu02 - common), 0.0)
        major = 4.0 * math.sqrt(lam1)
        minor = 4.0 * math.sqrt(lam2)
        angle = 0.5 * math.atan2(2.0 * mu11, mu20 - mu02)
        ecc = math.sqrt(max(1.0 - lam2 / lam1, 0.0)) if lam1 > 0 else 0.0

        perim_px = _perimeter(sub)
        conv_px = _convex_area(sub)
        # 穴の数 = 1 画素ぶん広げた背景の連結成分 - 1(外側)。穴の連結は
        # 4 連結で数える(物体を 8 連結で取ったので、背景は 4 連結が対)。
        pad = np.pad(sub, 1)
        _, nbg = ndimage.label(~pad, structure=ndimage.generate_binary_structure(2, 1))

        cols["label"].append(idx)
        cols["area"].append(area_px * sp * sp)
        cols["row"].append(row)
        cols["col"].append(col)
        cols["bbox_r0"].append(r0)
        cols["bbox_c0"].append(c0)
        cols["bbox_r1"].append(r1)
        cols["bbox_c1"].append(c1)
        cols["perimeter"].append(perim_px * sp)
        cols["equiv_diameter"].append(2.0 * math.sqrt(area_px / math.pi) * sp)
        cols["major"].append(major * sp)
        cols["minor"].append(minor * sp)
        cols["angle"].append(angle)
        cols["eccentricity"].append(ecc)
        cols["circularity"].append(
            min(1.0, 4.0 * math.pi * area_px / (perim_px * perim_px)) if perim_px > 0 else 0.0)
        cols["extent"].append(area_px / float((r1 - r0) * (c1 - c0)))
        cols["solidity"].append(area_px / conv_px if conv_px > 0 else 0.0)
        cols["holes"].append(int(nbg) - 1)
        cols["touches_border"].append(
            bool(r0 == 0 or c0 == 0 or r1 == h or c1 == w))

    for k in FEATURE_KEYS:
        if k == "touches_border":
            out[k] = np.asarray(cols[k], bool)
        elif k == "label" or k == "holes" or k.startswith("bbox_"):
            out[k] = np.asarray(cols[k], np.int32)
        else:
            out[k] = np.asarray(cols[k], np.float64)
    # ★2026-11-09 点検: 以前は n = labels.max() を返し、ラベル 2 を消した像で n = 5・配列の長さ 4 と
    #   食い違った(docstring は「長さ n の配列」)。n は実際に返す物体の数にする。
    out["n"] = int(len(cols["label"]))
    return out


# --------------------------------------------------------------------------- #
# 3. 選ぶ                                                                      #
# --------------------------------------------------------------------------- #
def _renumber(lab: np.ndarray, keep) -> np.ndarray:
    """``keep``(1 起点のラベル番号の並び)だけ残し、その順に 1..k を振り直す。"""
    keep = np.asarray(keep, np.int64)
    lut = np.zeros(int(lab.max()) + 1, np.int32)
    lut[keep] = np.arange(1, len(keep) + 1, dtype=np.int32)
    return lut[lab]


def _selection_feature(lab: np.ndarray, feature: str, spacing: float):
    """Return present labels and a selection feature without unrelated work."""
    counts = np.bincount(lab.ravel(), minlength=int(lab.max()) + 1)
    labels = np.flatnonzero(counts[1:]) + 1
    if feature == "area":
        return labels, counts[labels].astype(np.float64) * spacing * spacing
    if feature == "touches_border":
        h, w = lab.shape
        boxes = ndimage.find_objects(lab)
        values = [
            box[0].start == 0 or box[1].start == 0
            or box[0].stop == h or box[1].stop == w
            for label in labels
            for box in (boxes[int(label) - 1],)
        ]
        return labels, np.asarray(values, bool)
    if feature == "circularity":
        boxes = ndimage.find_objects(lab)
        values = []
        for label in labels:
            box = boxes[int(label) - 1]
            perimeter = _perimeter(lab[box] == label)
            area = float(counts[label])
            values.append(min(1.0, 4.0 * math.pi * area / (perimeter * perimeter))
                          if perimeter > 0 else 0.0)                 # blob_features と同じく 1 で頭打ち
        return labels, np.asarray(values, np.float64)
    features = blob_features(lab, spacing)
    return features["label"], np.asarray(features[feature])


def blob_select(labels: Any, feature: str, vmin: Optional[float] = None,
                vmax: Optional[float] = None, spacing: float = 1.0) -> np.ndarray:
    """特徴量が ``[vmin, vmax]`` に入る物体だけ残す(**番号は 1 から振り直す**)。

    Parameters
    ----------
    labels : array_like
        :func:`blob_label` の出力。
    feature : str
        :data:`FEATURE_KEYS` のどれか。知らない鍵は**候補を並べて拒否する**。
    vmin, vmax : float or None
        両端(含む)。``None`` は片側を開ける。両方 ``None`` は
        「何も選んでいない」ので拒否する —— 全部通す意図なら呼ばなければよい。
    spacing : float
        :func:`blob_features` と同じ意味。``area`` や ``perimeter`` を
        物理単位で切るときに要る。

    Returns
    -------
    numpy.ndarray
        ``int32`` のラベル画像。**残った物体は 1..k の連番**になる
        (元の番号は残さない)。元の番号が要るなら
        ``blob_features(labels)["label"]`` を先に取っておくこと。
    """
    if feature not in FEATURE_KEYS:
        raise ValueError(
            "blob_select: unknown feature %r. Available: %s"
            % (feature, ", ".join(FEATURE_KEYS)))
    if vmin is None and vmax is None:
        raise ValueError(
            "blob_select: give at least one of vmin / vmax - selecting with "
            "neither bound would silently return the input unchanged")
    lab = _as_labels(labels, "blob_select")
    sp = _positive_float(spacing, "blob_select", "spacing")
    labels_present, values = _selection_feature(lab, feature, sp)
    if labels_present.size == 0:
        return np.zeros_like(lab)
    v = np.asarray(values, np.float64)
    ok = np.ones(v.shape, bool)
    if vmin is not None:
        ok &= v >= float(vmin)
    if vmax is not None:
        ok &= v <= float(vmax)
    return _renumber(lab, labels_present[ok])


def blob_select_largest(labels: Any, count: int = 1) -> np.ndarray:
    """面積の大きい順に ``count`` 個だけ残す(**番号は面積の降順に振り直す**)。

    同じ面積が並んだときは元の番号が小さいほうを先にする(実行ごとに順序が
    変わらないよう ``argsort`` を安定ソートで固定してある)。``count`` が
    物体数より多くても**あるだけ**返す(足りないことを例外にはしない ——
    「上位 3 個」を頼んで 2 個しか無いのは異常ではない)。
    """
    c = int(count)
    if c < 1:
        raise ValueError(f"blob_select_largest: count must be >= 1, got {count!r}")
    lab = _as_labels(labels, "blob_select_largest")
    counts = np.bincount(lab.ravel(), minlength=int(lab.max()) + 1)
    labels_present = np.flatnonzero(counts[1:]) + 1
    if labels_present.size == 0:
        return np.zeros_like(lab)
    order = np.argsort(-counts[labels_present], kind="stable")
    return _renumber(lab, labels_present[order[:c]])


# --------------------------------------------------------------------------- #
# 4. 取り出す                                                                  #
# --------------------------------------------------------------------------- #
def blob_region(labels: Any, index: int) -> np.ndarray:
    """物体 1 個を二値領域(bool)として抜く。``index`` は **1 起点**。

    ``labels == index`` を返すだけの選択 op。番号は ``blob_label`` が付けた 1..n の
    連番で、0 は背景。

    - ``labels``: 2-D の整数ラベル画像(``blob_label`` / ``blob_select`` /
      ``blob_split`` の出力)。**bool マスクは拒否**(「複数物体を 1 個として測る」
      事故を防ぐため、先に ``blob_label`` を掛けるよう促す)。float も拒否
      (``0.999`` がどの物体か決められない)。負の番号があれば ``ValueError``。
    - ``index``: ``1 <= index <= labels.max()`` の int。0(背景)や範囲外は
      ``ValueError``。``blob_features`` の ``label`` 列、``blob_select_largest`` の
      結果(1 から振り直される)と同じ番号体系。
    - 返り値: ``(H, W)`` の bool。空になることはない(番号は必ず存在する
      ―― ただし ``blob_select`` で番号を振り直していない自作ラベルに欠番があれば
      全 False が返りうる)。

    抜いた領域は ``blob_distance``(距離変換)や ``blob_overlay`` の重ね描き、
    ``annotate_outline`` の輪郭描画にそのまま渡せる。
    """
    lab = _as_labels(labels, "blob_region")
    i = int(index)
    n = int(lab.max())
    if i < 1 or i > n:
        raise ValueError(
            f"blob_region: index must be in 1..{n} (1-origin, 0 is background), "
            f"got {index!r}")
    return lab == i


def blob_boundaries(labels: Any) -> np.ndarray:
    """物体の輪郭(1 画素幅、bool)。**隣り合う物体の境目も残る**。

    内側の縁を取る(自分と違うラベルに隣接する前景画素)ので、輪郭は必ず
    物体の内部にある —— 外側を取ると隣の物体の画素を輪郭だと言うことになる。

    手順: 3x3(8 近傍)のグレー収縮 ``lo`` と膨張 ``hi`` をラベル画像に掛け、
    ``(labels > 0) & ((lo != labels) | (hi != labels))``。「近傍に自分と違う番号
    (背景 0 も含む)がある前景画素」= 内側 1 画素幅の縁。収縮だけだと番号の
    小さい物体側の境目が消えるので、膨張も見て対称にしてある。

    - ``labels``: 2-D の整数ラベル画像(``blob_label`` の出力)。bool / float / 負の
      番号は ``ValueError``(``blob_region`` と同じ契約)。
    - 返り値: ``(H, W)`` の bool。全物体の縁が 1 枚に重なる(物体ごとに分けたいなら
      ``blob_region`` で抜いてから掛ける)。
    - 画像の縁に接する物体は、scipy の既定(反射境界)で画像端の外を自分の値と
      みなすため、**画像端に沿った辺は縁として出ない**。
    - 1 画素幅の細い物体は全画素が縁になる。

    ``blob_features`` の周長は別の係数法で測っており、この縁の画素数とは一致しない。
    輪郭を折れ線として使うなら ``annotate_outline_layout`` が (x, y) の閉多角形を返す。
    """
    lab = _as_labels(labels, "blob_boundaries")
    fp = np.ones((3, 3), bool)
    # ★収縮だけでは**片側しか出ない**。番号の小さい物体は、隣に番号の大きい
    #   物体が来ても近傍の最小値が自分のままなので「内部」と判定される
    #   (2026-09-06 実測: 1 と 2 が接する列で 1 の側の輪郭が消えた)。
    #   膨張と両方見れば「近傍に自分と違う番号がある」の対称な判定になる。
    lo = ndimage.grey_erosion(lab, footprint=fp)
    hi = ndimage.grey_dilation(lab, footprint=fp)
    return (lab > 0) & ((lo != lab) | (hi != lab))


# --------------------------------------------------------------------------- #
# 5. 割る —— 触れ合って 1 個になった塊を戻す                                    #
# --------------------------------------------------------------------------- #
def blob_distance(region: Any, spacing: float = 1.0) -> np.ndarray:
    """前景の各画素から**いちばん近い背景まで**の距離。単位は ``spacing`` 倍。

    ``scipy.ndimage.distance_transform_edt`` そのもの。**わざわざ口を作った
    理由**は、進化 op の ``distance_transform`` が最大値で正規化して返すため
    (``poc_cell_counting`` の実測: 出力の最大が常に 1.0)、**画素単位の距離が
    取れない**こと。分水嶺の種を作るには絶対値が要る。

    Examples
    --------
    >>> import numpy as np
    >>> m = np.zeros((21, 21), bool); m[5:16, 5:16] = True
    >>> float(blob_distance(m).max())      # 11x11 の正方形の中心まで
    6.0
    """
    m = _as_binary(region, "blob_distance")
    sp = _positive_float(spacing, "blob_distance", "spacing")
    return np.asarray(ndimage.distance_transform_edt(m), np.float64) * sp


def _reconstruct_by_dilation(seed: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """測地膨張による再構成(seed <= mask)。``mask`` の外へは広がらない。"""
    from collections import deque

    out = np.minimum(seed, mask).copy()
    h, w = out.shape
    before = ((-1, -1), (-1, 0), (-1, 1), (0, -1))
    after = ((0, 1), (1, -1), (1, 0), (1, 1))

    # Hybrid reconstruction: the two raster scans perform the cheap directed
    # propagation first. The FIFO then visits only pixels on a still-growing
    # front instead of dilating and comparing the complete image each round.
    for row in range(h):
        for col in range(w):
            value = out[row, col]
            for dr, dc in before:
                rr, cc = row + dr, col + dc
                if 0 <= rr < h and 0 <= cc < w and out[rr, cc] > value:
                    value = out[rr, cc]
            if value > out[row, col]:
                out[row, col] = min(value, mask[row, col])
    for row in range(h - 1, -1, -1):
        for col in range(w - 1, -1, -1):
            value = out[row, col]
            for dr, dc in after:
                rr, cc = row + dr, col + dc
                if 0 <= rr < h and 0 <= cc < w and out[rr, cc] > value:
                    value = out[rr, cc]
            if value > out[row, col]:
                out[row, col] = min(value, mask[row, col])

    queued = np.zeros((h, w), bool)
    queue = deque()
    for row in range(h):
        for col in range(w):
            value = out[row, col]
            for dr, dc in before + after:
                rr, cc = row + dr, col + dc
                if (0 <= rr < h and 0 <= cc < w
                        and out[rr, cc] < value and out[rr, cc] < mask[rr, cc]):
                    queue.append((row, col))
                    queued[row, col] = True
                    break
    while queue:
        row, col = queue.popleft()
        queued[row, col] = False
        value = out[row, col]
        for dr, dc in before + after:
            rr, cc = row + dr, col + dc
            if not (0 <= rr < h and 0 <= cc < w):
                continue
            grown = min(value, mask[rr, cc])
            if grown > out[rr, cc]:
                out[rr, cc] = grown
                if not queued[rr, cc]:
                    queue.append((rr, cc))
                    queued[rr, cc] = True
    return out


def blob_seeds(distance: Any, h: float, connectivity: int = 8) -> np.ndarray:
    """h-maxima の種。**``h`` は ``distance`` と同じ単位の絶対値**。

    「高さ ``h`` 以上そびえている極大」だけを残し、連結成分に番号を振って返す。
    融合した塊を割るときの種として使う。

    **既存の ``fs.op.xsk2_h_maxima`` と違う点**(``poc_cell_counting`` が
    記録した穴):

    * あちらは入力を ``[0, 1]`` に**切り詰める**ので、生の距離マップを渡すと
      壊れる(2 px も 20 px も 1.0 になる)。ここは切り詰めない。
    * あちらの ``h`` は ``0.05 + 0.3a`` = **正規化画像に対する比**なので、
      画像に大きい物体が 1 つ入るだけで小さい物体側の実効 ``h`` が上がる
      (実測で下限が 0.42 → 0.80 px へ動いた)。ここは画素(または物理単位)。

    **速さ**: 再構成は**連結成分ごとの外接箱の中でだけ**回す。背景を通る
    伝播が消えるので、512x512 に 200 個の円で **237.7 ms → 15.3 ms(15.5 倍)**、
    結果は全画素一致(2026-09-06 実測)。

    Parameters
    ----------
    distance : array_like
        2-D の実数場。ふつうは :func:`blob_distance` の出力。
    h : float
        そびえの高さ。``distance`` と同じ単位で、**0 より大きいこと**。
        大きくすると種が減る(= 割りすぎが減り、割り残しが増える)。
    connectivity : {4, 8}
        極大の連結の取り方。

    Returns
    -------
    numpy.ndarray
        ``int32`` のラベル画像(背景 0、種 1..n)。
    """
    f = np.asarray(distance, np.float64)
    if f.ndim != 2:
        raise ValueError(
            f"blob_seeds: distance must be a 2-D field, got ndim={f.ndim}")
    if not np.all(np.isfinite(f)):
        raise ValueError("blob_seeds: distance contains NaN or Inf")
    hh = _positive_float(h, "blob_seeds", "h")
    if connectivity not in CONNECTIVITIES:
        raise ValueError(
            f"blob_seeds: connectivity must be 4 or 8, got {connectivity!r}")

    st = np.ones((3, 3), bool)
    lab, _ = ndimage.label(f > 0, structure=st)
    out = np.zeros(f.shape, bool)
    for idx, sl in enumerate(ndimage.find_objects(lab), start=1):
        if sl is None:
            continue
        pad = (slice(max(sl[0].start - 1, 0), sl[0].stop + 1),
               slice(max(sl[1].start - 1, 0), sl[1].stop + 1))
        sub = np.where(lab[pad] == idx, f[pad], 0.0)
        out[pad] |= (sub - _reconstruct_by_dilation(sub - hh, sub)) > 0
    seed_st = (st if connectivity == 8
               else ndimage.generate_binary_structure(2, 1))
    return np.asarray(ndimage.label(out, structure=seed_st)[0], np.int32)


def blob_split(labels: Any, seeds: Any, distance: Any) -> np.ndarray:
    """種から**高いところ順に**領域を広げて、融合した塊を割る(分水嶺)。

    ``distance`` の高い画素から順に、隣接する既知のラベルを取り込んでいく
    (immersion 型の分水嶺を、距離の降順で回す形)。**種を持たない塊はその
    まま残す** —— 割る材料が無いのに消すのは嘘になるため。

    ``segmentation.watersheds_marker`` を使わないのは、**skimage が無い環境で
    黙って別の算法(マーカーからの最近傍)に落ちる**から。落ちた先は画像を
    一切見ないので、同じ関数名で違うものが返る。ここは numpy と scipy だけで
    閉じる。

    Parameters
    ----------
    labels : array_like
        割る対象。:func:`blob_label` の出力(``> 0`` の画素だけが割られる)。
    seeds : array_like
        :func:`blob_seeds` の出力。``labels`` の外にある種は無視する。
    distance : array_like
        優先度。ふつうは :func:`blob_distance` の出力。

    Returns
    -------
    numpy.ndarray
        ``int32`` のラベル画像。番号は 1 から振り直す。
    """
    lab = _as_labels(labels, "blob_split")
    sd = _as_labels(seeds, "blob_split", "seeds")
    f = np.asarray(distance, np.float64)
    if sd.shape != lab.shape or f.shape != lab.shape:
        raise ValueError(
            "blob_split: labels %s, seeds %s and distance %s must have the "
            "same shape" % (lab.shape, sd.shape, f.shape))

    fg = lab > 0
    cur = np.where(fg, sd, 0).astype(np.int32)      # 領域の外の種は捨てる
    if not cur.any():
        return _renumber(lab, np.unique(lab[fg]))   # 種が無ければそのまま
    fp = np.ones((3, 3), bool)
    # 距離の高い順に「その高さ以上でまだ番号の無い画素」へ広げる。値の段数は
    # ふつう数十しかないので、段ごとに膨張が収まるまで回しても十分速い。
    for level in np.unique(f[fg])[::-1]:
        allowed = fg & (f >= level)
        while True:
            grown = ndimage.grey_dilation(cur, footprint=fp)
            nxt = np.where((cur == 0) & allowed, grown, cur)
            if np.array_equal(nxt, cur):
                break
            cur = nxt
    # 種を 1 つも含まなかった塊は、元の 1 個としてそのまま残す
    left = fg & (cur == 0)
    if left.any():
        keep, _ = ndimage.label(left, structure=fp)
        cur = np.where(left, keep + int(cur.max()), cur)
    return _renumber(cur, np.unique(cur[cur > 0]))


# --------------------------------------------------------------------------- #
# 5b. 数える —— 決まらないときは区間で返す                                       #
# --------------------------------------------------------------------------- #
#: :func:`blob_count_interval` の山の判定の符号(``peaks["status"]``)。
PEAK_NOISE, PEAK_AMBIGUOUS, PEAK_SURE = 0, 1, 2

#: :func:`blob_count_interval` の成分の判定(``components["status"]``)。
COUNT_STATUSES: tuple[str, ...] = ("determined", "ambiguous", "unexplained")


def _component_peaks(f: np.ndarray, m: np.ndarray, st: np.ndarray):
    """1 個の連結成分 ``m`` の中で、``f`` の極大(台地)ごとに高さと突出度を出す。

    突出度 = 0 次元パーシステンス: 水位を上から下げ、その山がより高い山と
    つながった水位までの高さ。成分でいちばん高い山は背景(0)まで生き残るので
    突出度 = 高さ。同じ高さの山どうしは走査順の早いほうが残る(宣言順で決める)。

    返り値: ``(plateau_labels, pos (k, 2), height (k,), prominence (k,))``。
    """
    fm = np.where(m, f, -np.inf)
    mx = ndimage.maximum_filter(fm, footprint=st, mode="constant", cval=-np.inf)
    cand = m & (fm >= mx)
    plab, k = ndimage.label(cand, structure=st)
    idx = np.arange(1, k + 1)
    hts = np.asarray(ndimage.maximum(f, plab, idx), np.float64).reshape(-1)
    pos = np.asarray(ndimage.maximum_position(f, plab, idx), np.int64).reshape(-1, 2)
    prom = np.zeros(k, np.float64)
    alive = np.ones(k, bool)
    if k > 1:
        second = float(np.sort(hts)[::-1][1])
        # 2 番目に高い山より上の水位では併合は起きない(山が 1 つしか水面に出ていない)
        for t in np.unique(f[m & (f <= second)])[::-1]:
            lab, _ = ndimage.label(m & (f >= t), structure=st)
            cid = lab[pos[:, 0], pos[:, 1]]
            a = np.flatnonzero(alive & (cid > 0))
            if a.size < 2:
                continue
            cs = cid[a]
            uniq, cnt = np.unique(cs, return_counts=True)
            for c in uniq[cnt > 1]:
                g = a[cs == c]
                keep = g[np.lexsort((g, -hts[g]))[0]]
                die = g[g != keep]
                alive[die] = False
                prom[die] = hts[die] - float(t)
            if int(alive.sum()) == 1:
                break
    prom[alive] = hts[alive]
    return plab, pos, hts, prom


def _power_split(lab: np.ndarray, comp, rows, cols, hts) -> np.ndarray:
    """種(山の位置と内接円の半径)から、成分ごとに**冪図**で画素を配る。

    画素 x は |x − c_i|² − h_i² が最小の種 i へ。2 つの円が重なっていれば、境は
    2 つの交点を結ぶ弦(根軸)になる —— 円の重なりの分け方として閉形式で正しい。
    分水嶺(:func:`blob_split`)は同じ答えに近いが、段ごとに膨張を収束まで回すので
    520x696 の細胞の真値マスク 1 枚に 4 秒かかった(2026-10-18 実測)。ここは
    成分ごとに (画素 × 種) の 1 回の計算で済む。種の番号は渡した順に 1..k。
    """
    out = np.zeros(lab.shape, np.int32)
    comp = np.asarray(comp, np.int64)
    if comp.size == 0:
        return out
    rows, cols, hts = (np.asarray(v, np.float64) for v in (rows, cols, hts))
    ids = np.arange(1, comp.size + 1, dtype=np.int32)
    for i, sl in enumerate(ndimage.find_objects(lab), start=1):
        if sl is None:
            continue
        k = np.flatnonzero(comp == i)
        if k.size == 0:
            continue
        yy, xx = np.nonzero(lab[sl] == i)
        if k.size == 1:
            out[sl][yy, xx] = ids[k[0]]
            continue
        y = yy[:, None] + sl[0].start
        x = xx[:, None] + sl[1].start
        d = (y - rows[k][None, :]) ** 2 + (x - cols[k][None, :]) ** 2 - hts[k][None, :] ** 2
        out[sl][yy, xx] = ids[k][np.argmin(d, axis=1)]
    return out


def blob_count_interval(region: Any, rel_lo: float = 0.05, rel_hi: float = 0.15,
                        min_prominence: float = 1.0, round_tol: Optional[float] = None,
                        connectivity: int = 8) -> dict:
    """重なった物体を数える。**決まらないときは個数ではなく区間を返す**(fail-closed)。

    融合した塊の中の物体は、距離変換の山として現れる。2 つの円が重なると
    くびれができ、くびれが浅くなるほど(山の**突出度**が小さいほど)「2 個か
    1 個か」が決まらなくなる。``blob_seeds`` + ``blob_split`` は h を 1 つ選んで
    **必ず 1 つの個数を返す** —— 重なりが深くて決まらない所でも、もっともらしい
    数が出る。この op は山ごとに突出度を測り、閾値の帯に落ちた山を「あいまい」
    として個数を ``lo`` 〜 ``hi`` の区間で返す。区間の幅が 0 のときだけ
    ``count`` を返す。

    山の判定(突出度 p、高さ h、相対突出度 p/h。h は内接円の半径にあたる):

    * ``p >= min_prominence`` かつ ``p/h >= rel_hi`` → 確かな山(数える)
    * ``p >= min_prominence`` かつ ``rel_lo <= p/h < rel_hi`` → あいまい
      (lo には数えず hi には数える)
    * それ以外 → 雑音(格子の量子化で出る山。楕円で実測 0.6 px 未満)

    **相対突出度を使う理由**: 等しい半径 r の 2 円が重なり率 o(中心間
    d = 2r(1 − o))で重なると、くびれの半幅は w = sqrt(r² − (d/2)²) で、
    p/h = 1 − sqrt(1 − (1 − o)²) —— **半径によらない**。絶対値の h を選ぶと、
    大きい泡と小さい泡が混ざった画像で片方にしか合わない(``poc_cell_counting``
    が記録した穴と同じ形)。既定の帯 0.05〜0.15 は重なり率 0.69〜0.47 に当たる。

    ``round_tol`` を与えると、**山では説明できない面積**も拒否する。
    重なり率が 0.7 を超えると、くびれが格子の量子化に埋もれて山が 1 つしか
    残らない(2 個が 1 個に見える)。そこで成分の面積を、確かな山とあいまいな山の
    内接円の面積の和 Σπh² と比べ、面積 > (1 + round_tol + 1/h_min) · Σπh² なら
    上限を開く(``hi = None``)。1/h_min は格子の量子化の分(半径 8 px 以上の円板で
    比 1.09 以下、2026-10-18 実測)。``round_tol`` は**許す縦横比 − 1** にあたる
    (縦横比 a/b の楕円は面積比 a/b)。泡のように丸い物体なら 0.1、細胞のように
    いびつなら 0.3 程度。``None`` は形を仮定しない(深い重なりは見逃す)。

    **区間の上限は保証ではない**: ``hi`` は山として見えた物体の数で、山を残さずに
    埋もれた物体(大きい泡に食い込んだ小さい泡など)は ``hi`` にも入らない。面積の
    検査がそれを拾えたときだけ上限を開く。``determined`` が False のときは「数を
    言えない」ことだけが確かで、区間は目安(実際の泡の形の半合成で、決まらないと
    答えた塊の真値が ``hi`` を 1 個上回る例が出た。``poc_dense_bubble_count``)。

    Parameters
    ----------
    region : array_like
        2-D の前景(``> 0`` が前景)。
    rel_lo, rel_hi : float
        相対突出度の帯。``0 < rel_lo <= rel_hi < 1``。
    min_prominence : float
        突出度の絶対の床 [px]。``>= 0``。距離変換の量子化の山を落とす。
    round_tol : float or None
        面積の検査の許し(上を参照)。``None`` で検査しない。
    connectivity : {4, 8}
        成分と水位の連結の取り方。

    Returns
    -------
    dict
        ``count``(区間の幅が 0 なら int、そうでなければ ``None``)、``lo``、
        ``hi``(上限が開いていれば ``None``)、``determined``、``reason``、
        ``labels``(確かな山だけを種にした分割、int32、内接円の冪図)、``labels_hi``
        (あいまいな山も種にした分割)、``components``(成分ごとの ``label`` / ``lo`` /
        ``hi``(開いていれば -1)/ ``status`` / ``area`` / ``area_ratio``)、
        ``peaks``(山ごとの ``component`` / ``row`` / ``col`` / ``height`` /
        ``prominence`` / ``rel_prominence`` / ``status``(0 雑音・1 あいまい・2 確か))、
        ``params``。

    Examples
    --------
    >>> import numpy as np
    >>> yy, xx = np.mgrid[0:80, 0:120]
    >>> two = ((yy - 40) ** 2 + (xx - 40) ** 2 < 400) | ((yy - 40) ** 2 + (xx - 76) ** 2 < 400)
    >>> blob_count_interval(two)["count"]              # 重なり率 0.1: 2 個に決まる
    2
    >>> deep = ((yy - 40) ** 2 + (xx - 50) ** 2 < 400) | ((yy - 40) ** 2 + (xx - 66) ** 2 < 400)
    >>> r = blob_count_interval(deep, round_tol=0.1)   # 重なり率 0.6: 決まらない
    >>> r["count"] is None, r["lo"]
    (True, 1)

    来歴(公開文献のみ): Edelsbrunner, Letscher & Zomorodian, *Discrete Comput.
    Geom.* 28 (2002) 511 —— パーシステンス / Vincent & Soille, *IEEE TPAMI* 13
    (1991) 583 —— 分水嶺 / Aurenhammer, *SIAM J. Comput.* 16 (1987) 78 —— 冪図(分割)。
    """
    op = "blob_count_interval"
    m = _as_binary(region, op)
    lo_r, hi_r = float(rel_lo), float(rel_hi)
    if not (math.isfinite(lo_r) and math.isfinite(hi_r) and 0.0 < lo_r <= hi_r < 1.0):
        raise ValueError(
            f"{op}: need 0 < rel_lo <= rel_hi < 1, got rel_lo={rel_lo!r}, rel_hi={rel_hi!r}")
    mp = float(min_prominence)
    if not math.isfinite(mp) or mp < 0.0:
        raise ValueError(f"{op}: min_prominence must be finite and >= 0, got {min_prominence!r}")
    rt = None
    if round_tol is not None:
        rt = float(round_tol)
        if not math.isfinite(rt) or rt < 0.0:
            raise ValueError(f"{op}: round_tol must be None or finite and >= 0, got {round_tol!r}")
    if connectivity not in CONNECTIVITIES:
        raise ValueError(f"{op}: connectivity must be 4 or 8, got {connectivity!r}")
    st = (np.ones((3, 3), bool) if connectivity == 8
          else ndimage.generate_binary_structure(2, 1))

    lab, n = ndimage.label(m, structure=st)
    lab = np.asarray(lab, np.int32)
    f = np.asarray(ndimage.distance_transform_edt(m), np.float64)
    c_lab, c_lo, c_hi, c_status, c_area, c_ratio = [], [], [], [], [], []
    p_cols: dict = {k: [] for k in ("component", "row", "col", "height", "prominence",
                                    "rel_prominence", "status")}
    for i, sl in enumerate(ndimage.find_objects(lab), start=1):
        if sl is None:
            continue
        pad = (slice(max(sl[0].start - 1, 0), sl[0].stop + 1),
               slice(max(sl[1].start - 1, 0), sl[1].stop + 1))
        cm = lab[pad] == i
        cf = np.where(cm, f[pad], 0.0)
        plab, pos, hts, prom = _component_peaks(cf, cm, st)
        rel = prom / np.maximum(hts, 1e-12)
        status = np.where((prom >= mp) & (rel >= hi_r), PEAK_SURE,
                          np.where((prom >= mp) & (rel >= lo_r), PEAK_AMBIGUOUS, PEAK_NOISE))
        # 成分でいちばん目立つ山は必ず数える(成分がある = 物体が 1 個以上ある)
        top = int(np.lexsort((np.arange(hts.size), -prom))[0])
        status[top] = PEAK_SURE
        n_sure = int(np.sum(status == PEAK_SURE))
        n_amb = int(np.sum(status == PEAK_AMBIGUOUS))
        area = int(cm.sum())
        # 面積の検査は上限の仮説(確か + あいまいな山)で行う: それでも説明できない面積が
        # 残るなら、上限そのものが決まらない
        h_up = hts[status != PEAK_NOISE]
        disc = math.pi * float(np.sum(h_up ** 2))
        ratio = area / disc if disc > 0 else math.inf
        kind, hi_c = ("determined" if n_amb == 0 else "ambiguous"), n_sure + n_amb
        if rt is not None and ratio > 1.0 + rt + 1.0 / max(float(h_up.min()), 1.0):
            kind, hi_c = "unexplained", -1
        c_lab.append(i)
        c_lo.append(n_sure)
        c_hi.append(hi_c)
        c_status.append(kind)
        c_area.append(area)
        c_ratio.append(ratio)
        for j in range(hts.size):
            p_cols["component"].append(i)
            p_cols["row"].append(int(pos[j, 0]) + pad[0].start)
            p_cols["col"].append(int(pos[j, 1]) + pad[1].start)
            p_cols["height"].append(float(hts[j]))
            p_cols["prominence"].append(float(prom[j]))
            p_cols["rel_prominence"].append(float(rel[j]))
            p_cols["status"].append(int(status[j]))

    lo = int(sum(c_lo))
    open_hi = any(h < 0 for h in c_hi)
    hi = None if open_hi else int(sum(c_hi))
    determined = hi == lo
    n_amb_c = sum(s == "ambiguous" for s in c_status)
    n_unx_c = sum(s == "unexplained" for s in c_status)
    if determined:
        reason = "determined: every peak is clearly in or clearly out"
    else:
        reason = (f"undetermined: {n_amb_c} component(s) have a peak inside the "
                  f"rel_prominence band [{lo_r}, {hi_r}), {n_unx_c} component(s) have "
                  "area the counted peaks cannot explain (upper bound open)")
    pk = {k: np.asarray(v) for k, v in p_cols.items()}
    sure = pk["status"] == PEAK_SURE if n else np.zeros(0, bool)
    up = pk["status"] != PEAK_NOISE if n else np.zeros(0, bool)
    labels = _power_split(lab, pk["component"][sure], pk["row"][sure], pk["col"][sure], pk["height"][sure]) \
        if n else np.zeros(m.shape, np.int32)
    labels_hi = _power_split(lab, pk["component"][up], pk["row"][up], pk["col"][up], pk["height"][up]) \
        if n else np.zeros(m.shape, np.int32)
    return {
        "count": lo if determined else None,
        "lo": lo,
        "hi": hi,
        "determined": bool(determined),
        "reason": reason,
        "labels": labels,
        "labels_hi": labels_hi,
        "components": {
            "label": np.asarray(c_lab, np.int32), "lo": np.asarray(c_lo, np.int32),
            "hi": np.asarray(c_hi, np.int32), "status": list(c_status),
            "area": np.asarray(c_area, np.int64), "area_ratio": np.asarray(c_ratio, np.float64),
        },
        "peaks": {k: np.asarray(v, np.float64 if k in ("height", "prominence", "rel_prominence")
                                else np.int64) for k, v in p_cols.items()},
        "params": {"rel_lo": lo_r, "rel_hi": hi_r, "min_prominence": mp,
                   "round_tol": rt, "connectivity": int(connectivity)},
    }


# --------------------------------------------------------------------------- #
# 6. 見る                                                                      #
# --------------------------------------------------------------------------- #
def blob_overlay(image: Any, labels: Any, alpha: float = 0.5,
                 seed: int = 0) -> np.ndarray:
    """元画像の上に物体を色分けして重ね、``(H, W, 3)`` の float RGB を返す。

    この族の**出口**。作れて測れるが見られない型にしないために置く。
    色は :func:`fullseye.colorize_labels` と同じ規則で、背景は元画像のまま。
    """
    import imgio

    lab = _as_labels(labels, "blob_overlay")
    a = float(alpha)
    if not (0.0 <= a <= 1.0):
        raise ValueError(f"blob_overlay: alpha must be in [0, 1], got {alpha!r}")
    img = np.asarray(image, np.float64)
    if img.ndim == 2:
        if img.shape != lab.shape:
            raise ValueError(
                f"blob_overlay: image {img.shape} and labels {lab.shape} differ")
        lo, hi = float(np.nanmin(img)), float(np.nanmax(img))
        g = (img - lo) / (hi - lo) if hi - lo > 1e-12 else np.zeros_like(img)
        base = np.repeat(np.nan_to_num(g)[:, :, None], 3, axis=2)
    elif img.ndim == 3 and img.shape[2] in (3, 4):
        if img.shape[:2] != lab.shape:
            raise ValueError(
                f"blob_overlay: image {img.shape[:2]} and labels {lab.shape} differ")
        base = np.clip(img[:, :, :3], 0.0, 1.0)
    else:
        raise ValueError(
            f"blob_overlay: image must be (H,W) or (H,W,3|4), got {img.shape}")

    colour = np.asarray(imgio.colorize_labels(lab, seed=seed), np.float64)[:, :, :3]
    m = (lab > 0)[:, :, None]
    return np.where(m, (1.0 - a) * base + a * colour, base)
