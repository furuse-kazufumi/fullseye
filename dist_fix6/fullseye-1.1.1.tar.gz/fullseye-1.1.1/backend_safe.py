"""Shared safety net for library-backed operators.

Every backend wraps its op functions with an exception guard. The old fallback
was `return v` (the input), which had two defects the 2026-08-12 audit found:

  * it does NOT strip NaN/Inf that libraries emit on degenerate inputs (e.g.
    scipy.signal.wiener / skimage.denoise_wavelet / SimpleITK.LaplacianSharpening
    on a constant image) — np.clip does not remove NaN, so the whole pipeline
    score becomes NaN;
  * it returns the *input* even when the declared out_sort is region / feature /
    contour, so a failed segmentation returns a continuous grayscale image where
    a binary region is required (a type-contract violation).

`sanitize` centralises a finite-safe, sort-aware fallback: a failed or non-finite
op degrades to a valid, benign value of the DECLARED sort, derived from the input.
"""
from __future__ import annotations

import numpy as np

import os
import threading
import warnings
from collections import deque
from contextlib import contextmanager

# --------------------------------------------------------------------------- #
# Fallback ledger — the ONE mediator every fail-soft wrapper reports to.
#
# 2026-09-02 audit: 23 backend files each carried a private ``_safe`` that swallowed
# ``Exception`` and recorded nothing, so the strict mode / error ring that lived in
# ``backends.py`` covered exactly one of 24 wrapper families.  A permanently broken
# op (an API that raises on every input) was indistinguishable from a working
# identity op — for evolution, difftest, coverage and the user alike.
#
# The contradiction is real (TRIZ: reliability #27 / ease of use #33 vs measurement
# accuracy #28 / detectability #37): the facade must not crash a user's pipeline,
# yet every degradation must be visible.  It is resolved by SEPARATION, not by
# picking a side:
#   * in SPACE   — inner wrappers may degrade but must report here (``guard``);
#                  the OUTER layer (``api.apply``) decides what to do about it;
#   * by CONDITION — the caller chooses ``on_error="fallback" | "warn" | "raise"``
#                  (or the env var FULLSEYE_ON_ERROR / IMGEVOLVE_STRICT_BACKENDS);
#   * in TIME    — the default path warns ONCE per op (``FullseyeFallbackWarning``)
#                  so a notebook user sees it and a long batch is not spammed;
#   * feedback   — ``fallbacks()`` / ``fallback_counts()`` expose the ledger so CI can
#                  assert "no op fell back on the structured probe set".
# See docs/design/TRIZ_DESIGN_PATTERN_MATRIX.md for the pattern mapping.
# --------------------------------------------------------------------------- #

class FullseyeFallbackWarning(RuntimeWarning):
    """An operator failed and a sort-valid fallback value was returned instead.

    Emitted once per op name on the default (``on_error="fallback"``) path.  Silence
    with ``warnings.filterwarnings("ignore", category=FullseyeFallbackWarning)``;
    turn it into an exception with ``on_error="raise"``.
    """


class MissingDependencyError(ImportError):
    """An op needs an optional library (scikit-image / OpenCV / …) that is not installed here.

    **Fail-closed, whatever the policy.** :func:`guard`, the per-backend wrapper families and
    ``api.apply`` (``on_error="fallback"`` / ``"warn"``) all let this exception propagate instead
    of degrading to a sort-valid fallback, because the alternative was worse than a crash: on
    2026-10-25 a probe ran every image/region op in a numpy+scipy-only build and **89 ops ran
    without any exception and returned a different answer** (23 region features all returned
    the area ratio, ``*_circle`` morphology used a square, ``skeleton`` was the identity, …).
    The message names the op, the missing import, the pip package and the ``fullseye[<extra>]``
    line, so ``studio_errors`` can show the user what to install.

    Where a numpy-only path with the *same* answer exists it is used instead
    (``numpy_twins``); this error is for the ops that have no such twin.
    """

    def __init__(self, op, module, why="", pip=None, extra=None):
        self.op, self.module, self.why, self.pip, self.extra = op, module, why, pip, extra
        want = []
        if extra:
            want.append('pip install "fullseye[%s]"' % extra)
        want.append("pip install %s" % (pip or module))
        msg = ("%s: needs the optional dependency %r (%s) which is not installed — %s. "
               "There is no numpy-only path that gives the same answer%s, so this op refuses "
               "rather than return a different value (fail-closed)."
               % (op, module, pip or module, " / ".join(want), (" (%s)" % why) if why else ""))
        super().__init__(msg)


def which_outside_cwd(name):
    """PATH から外部コマンド *name* を探す。**作業フォルダは暗黙には探さない**。見つからなければ ``None``。

    ``shutil.which`` は Windows で作業フォルダを PATH の先頭に足す(Python 3.11 は常に。3.12 以降は
    ``NeedCurrentDirectoryForExePath`` に従う)。書庫を開くフォルダや信頼できないフォルダに
    ``7z.bat`` / ``gcc.cmd`` が置いてあると、Fullseye がそれを実行してしまう(2026-11-12、インストーラの
    レビューで ``powershell`` について見つかり、同じ形を一掃した)。

    * 名前にフォルダが付いている(``tools\\7z.exe`` など)ときは、呼び出し側が場所を指定しているので
      ``shutil.which`` に任せる。
    * Windows の裸の名前は、PATH の**絶対パスの項目だけ**を順に見る(空・``.``・相対の項目は飛ばす)。
      作業フォルダを PATH に絶対パスで入れている利用者の指定は尊重する。
    * Windows 以外の ``shutil.which`` は作業フォルダを足さないので、そのまま使う。
    """
    import shutil
    if not isinstance(name, str) or not name.strip():
        return None
    if os.name != "nt" or os.path.dirname(name):
        return shutil.which(name)
    exts = [e for e in os.environ.get("PATHEXT", ".COM;.EXE;.BAT;.CMD").split(os.pathsep) if e]
    names = [name] if os.path.splitext(name)[1].lower() in {e.lower() for e in exts} else [name + e for e in exts]
    for folder in os.environ.get("PATH", "").split(os.pathsep):
        folder = folder.strip().strip('"')
        if not folder or not os.path.isabs(folder):
            continue
        for candidate in names:
            full = os.path.join(folder, candidate)
            if os.path.isfile(full):
                return full
    return None


def missing_dependency(module, why="", op=None):
    """Build a :class:`MissingDependencyError` for the op the facade is currently running.

    *module* is the import name (``"skimage"``, ``"cv2"``, …); the pip name and the
    ``fullseye[<extra>]`` extra come from ``ops.OPTIONAL_DEPS`` (the one table the usability
    tests check against ``pyproject.toml``) when it is importable, else the import name is
    used as the pip name.  *op* defaults to the op recorded by :func:`current_op`.
    """
    name = op or getattr(_TL, "op", None) or "op"
    pip, extra = None, None
    try:
        from ops import OPTIONAL_DEPS
        pip, extra = OPTIONAL_DEPS.get(module, (None, None))
    except Exception:                        # noqa: BLE001 - ops not importable (unit test of this module alone)
        pass
    return MissingDependencyError(name, module, why, pip, extra)


def require_dependency(have, module, why="", op=None):
    """``if not have: raise missing_dependency(...)`` — the one-liner the backends use at a guarded branch."""
    if not have:
        raise missing_dependency(module, why, op)


_LEDGER_LOCK = threading.Lock()
_EVENT_MAX = 256
_EVENTS = deque(maxlen=_EVENT_MAX)  # bounded ring, oldest first (O(1) append, drops the oldest)
_COUNTS: dict = {}                  # name -> number of fallbacks since clear
_WARNED: set = set()                # names that already emitted their one warning
_SEQ = 0                            # monotonically increasing event counter (never reset)
_DROPPED = 0                        # events evicted from the ring since the last clear (N158)
_TL = threading.local()             # .op = name the facade is currently running


def _env_flag(*names):
    for n in names:
        if os.environ.get(n, "") not in ("", "0", "false", "False"):
            return True
    return False


_STRICT = _env_flag("IMGEVOLVE_STRICT_BACKENDS", "FULLSEYE_STRICT")
_WARN_ONCE = not _env_flag("FULLSEYE_QUIET_FALLBACK")


def is_strict() -> bool:
    """True when guarded ops re-raise instead of degrading to a fallback.

    A thread-local override (``strict_mode``) wins over the process default
    (``set_strict`` / env), so two threads running different ``on_error`` policies
    cannot flip each other's behaviour.
    """
    ov = getattr(_TL, "strict", None)
    return _STRICT if ov is None else ov


def set_strict(on: bool = True) -> bool:
    """Turn strict mode on/off; returns the PREVIOUS value so callers can restore it."""
    global _STRICT
    prev, _STRICT = _STRICT, bool(on)
    return prev


@contextmanager
def strict_mode(on: bool = True):
    """Scoped, THREAD-LOCAL strict mode — a verifier wraps a probe call in this to
    tell a dead op (raises) from an op that genuinely returns its input (does not)."""
    prev = getattr(_TL, "strict", None)
    _TL.strict = bool(on)
    try:
        yield
    finally:
        _TL.strict = prev


@contextmanager
def quiet_warnings():
    """Suppress the once-per-op warning of :func:`record` inside the block (the caller
    emits its own, e.g. ``api.apply(on_error="warn")`` warns per call instead)."""
    prev = getattr(_TL, "quiet", False)
    _TL.quiet = True
    try:
        yield
    finally:
        _TL.quiet = prev


def _fmt_exc(exc) -> str:
    """``"Type: message"`` — never raises, even for an exception whose ``__str__`` is broken."""
    try:
        return "%s: %s" % (type(exc).__name__, exc)
    except Exception:                        # noqa: BLE001 - the ledger must never be the thing that fails
        return "%s: <unprintable>" % type(exc).__name__


@contextmanager
def current_op(name):
    """Attribute every fallback recorded inside the block to op *name* (thread-local)."""
    prev = getattr(_TL, "op", None)
    _TL.op = name
    try:
        yield
    finally:
        _TL.op = prev


def record(name, exc, out_sort=None, source: str = "op") -> dict:
    """Append one fallback event to the ledger and emit the once-per-name warning.

    *name* may be None: then the op the facade is currently running (``current_op``)
    is used.  *source* tags where the degradation happened: ``"op"`` (the op body
    raised), ``"gpu"`` (an accelerated path failed and the CPU op ran instead),
    ``"import"`` (a whole backend module failed to import at registry build),
    ``"input"`` (the facade was handed an array that does not match the op's
    declared input sort).
    """
    global _SEQ
    key = str(name if name is not None else getattr(_TL, "op", None) or "?")
    ev = {"name": key, "source": source, "out_sort": out_sort,
          "error": _fmt_exc(exc), "thread": threading.get_ident()}
    with _LEDGER_LOCK:
        _SEQ += 1
        ev["seq"] = _SEQ
        # ★2026-09-20(GenSpark 第 44 報 N158): 環状バッファは黙って古い方を捨てる。捨てた数を数えないと、
        #   `fallbacks()` が 256 件しか返さない理由が利用者から見えない(counts と件数が合わない)。
        global _DROPPED
        if len(_EVENTS) == _EVENT_MAX:
            _DROPPED += 1
        _EVENTS.append(ev)
        _COUNTS[key] = _COUNTS.get(key, 0) + 1
        first = key not in _WARNED
        if first:
            _WARNED.add(key)
    if first and _WARN_ONCE and not getattr(_TL, "quiet", False):
        if _is_dtype_conversion(ev["error"]):
            # ★2026-11-11(外部ユーザー指摘): uint8 を渡す(最も普通の入力)だけで「degraded to a fallback」と
            #   出て、通常の型変換が劣化に読めた。結果は契約どおりで、劣化ではない —— 中立な文面にする。
            #   記録(fallbacks() / fallback_counts())は据え置き。本当の劣化の文面は下のまま。
            warnings.warn("fullseye: %r input converted (%s). Further conversions of this op "
                          "are counted silently - see fullseye.fallbacks(); pass float64 in [0,1] "
                          "or on_error='raise' to refuse integer input."
                          % (key, ev["error"].split("dtype_converted:", 1)[1].strip()),
                          FullseyeFallbackWarning, stacklevel=3)
        else:
            warnings.warn("fullseye: %r degraded to a fallback (%s; %s). Further fallbacks "
                          "of this op are counted silently - see fullseye.fallbacks() or "
                          "pass on_error='raise'." % (key, source, ev["error"]),
                          FullseyeFallbackWarning, stacklevel=3)
    return ev


def _is_dtype_conversion(error) -> bool:
    """True for the ledger text of a lossless-by-contract input dtype conversion (``api._contract_dtype``).

    Warning policy (one place, so it stays consistent): the **first** time an op name records any event in
    the process, one :class:`FullseyeFallbackWarning` is emitted; later events of the same name are only
    counted (``fallbacks()`` / ``fallback_counts()``). An integer/bool input conversion gets a neutral
    "input converted" text; every other event (the op body raised, a GPU path failed, a backend failed to
    import, a sort mismatch) keeps the "degraded to a fallback" text. ``FULLSEYE_QUIET_FALLBACK`` silences
    both; ``on_error='raise'`` refuses integer input instead of converting it.
    """
    return "dtype_converted:" in str(error)


def fallbacks() -> list:
    """Copy of the recorded fallback events (oldest first, bounded ring)."""
    with _LEDGER_LOCK:
        return [dict(e) for e in _EVENTS]


def fallback_overflow() -> int:
    """How many fallback events the bounded ring (256 newest) has evicted since the last
    :func:`clear_fallbacks`. ``fallbacks()`` returns only the newest 256 events; when this is
    non-zero, ``sum(fallback_counts().values()) == len(fallbacks()) + fallback_overflow()``.

    >>> fullseye.clear_fallbacks(); ...; fullseye.fallback_overflow()
    0
    """
    with _LEDGER_LOCK:
        return _DROPPED


def fallback_counts() -> dict:
    """``{name: n}`` - how many times each op fell back since the last ``clear_fallbacks``."""
    with _LEDGER_LOCK:
        return dict(_COUNTS)


def last_fallback():
    """The most recent fallback event as a dict, or None."""
    with _LEDGER_LOCK:
        return dict(_EVENTS[-1]) if _EVENTS else None


def clear_fallbacks(reset_warnings: bool = False) -> None:
    """Drop the ledger (call before a probe run). ``reset_warnings=True`` also lets
    every op warn again once."""
    global _DROPPED
    with _LEDGER_LOCK:
        _EVENTS.clear()
        _COUNTS.clear()
        _DROPPED = 0
        if reset_warnings:
            _WARNED.clear()


def mark() -> int:
    """Opaque position in the ledger; pair with :func:`events_since`."""
    with _LEDGER_LOCK:
        return _SEQ


def events_since(m: int, this_thread: bool = True) -> list:
    """Events recorded after :func:`mark` value *m* (still in the ring).

    ``this_thread=True`` (default) keeps only events recorded on the calling thread,
    so a per-call inspection is not polluted by concurrent work elsewhere.
    """
    tid = threading.get_ident()
    with _LEDGER_LOCK:
        return [dict(e) for e in _EVENTS if e["seq"] > m and (not this_thread or e.get("thread") == tid)]


def guard(fn, out_sort=None, *, name=None, on_fail=None, finish=None):
    """Wrap an op ``fn(v, a, b)`` so a failure degrades to a sort-valid value - RECORDED.

    This is the single exception guard every backend should use (``backends._safe``
    and the per-backend ``_safe`` helpers delegate here).  Behaviour:

    * ``fn`` raises  -> in strict mode the exception propagates unchanged; otherwise
      the event is recorded via :func:`record` and the result is ``on_fail(v)`` when
      given, else the sort fallback from :func:`sanitize`.
    * ``fn`` returns -> ``finish(out, v)`` when given (a backend's own post-processing,
      e.g. nan_to_num + clip), else :func:`sanitize` (finite, sort-valid).

    The recorded name is *name* if given, else the op the facade is running
    (``current_op``), else the function's qualname.
    """
    def w(v, a, b):
        try:
            out = fn(v, a, b)
        except MissingDependencyError:   # fail-closed: no sort-valid stand-in for a missing library
            raise
        except Exception as e:           # noqa: BLE001 - the whole point is to record it
            if is_strict():
                raise
            record(name or getattr(_TL, "op", None) or getattr(fn, "__qualname__", repr(fn)),
                   e, out_sort)
            out = None
        if out is None and on_fail is not None:
            return on_fail(v)
        if finish is not None:
            return finish(out, v)
        if out is not None:                 # 例外の経路は既に記録済み
            _note_nonfinite(out, v, out_sort,
                            name or getattr(_TL, "op", None) or getattr(fn, "__qualname__", repr(fn)))
        return sanitize(out, v, out_sort)
    w.__wrapped__ = fn
    w.__name__ = getattr(fn, "__name__", "op")
    # ガードは**振る舞いの装飾**であって説明の差し替えではない。``__doc__`` を
    # 転記しないと、実装がちゃんと書いた説明が「説明なし」に化ける —— 2026-09-05
    # 実測で 82 op がこれで消えていた(`tools/opdocs.py` は `fn.__doc__` を読む)。
    w.__doc__ = getattr(fn, "__doc__", None)
    # Keep "_safe" in the qualname: the registry-integrity tests identify a guarded
    # op that way, and `__fullseye_guarded__` is the structured form of the same fact.
    w.__qualname__ = "_safe(%s)" % getattr(fn, "__qualname__", w.__name__)
    w.__fullseye_guarded__ = True
    return w



def require_finite(x, what):
    """非有限(NaN / Inf)を含む入力を**入口で拒否**する。

    ネイティブ実装のいくつかは NaN を渡されると比較がすべて偽になり、
    境界の外へ書き込む。Python の例外にならないので `guard` でも捕まらず、
    **プロセスごと死ぬ**(2026-09-05 実測: `skimage.morphology.reconstruction`
    と `h_maxima` を NaN 画像で交互に呼ぶと SIGSEGV。単独では落ちず、
    交互に呼んだときだけ落ちるのでヒープ破壊と見られる)。

    ここで `ValueError` にしておけば `guard` が台帳に記録して sort に合う値へ
    落とす —— **落ちない**という約束を守れる。NaN を 0 に読み替えて計算を
    続けることはしない: 「測れなかった点」を「値 0 の点」に化けさせると、
    数字を見ても気づけない。
    """
    a = np.asarray(x)
    if a.dtype.kind in "fc" and not np.all(np.isfinite(a)):
        raise ValueError("%s: 非有限(NaN/Inf)を含む入力は扱えない" % what)
    return x


def _reflect_padded(fn, x, sigma=1.0, extra=3):
    """*fn* を鏡映の余白で包んだ 2-D 画像に当て、元の窓に切り戻す。

    skimage の ``structure_tensor`` / ``hessian_matrix`` / ``shape_index`` / ``corner_kitchen_rosenfeld`` は
    既定が ``mode='constant', cval=0``(画像の外を 0 で埋める)で、``corner_harris`` / ``corner_foerstner`` /
    ``hessian_matrix_det`` には mode の引数が無い。一様な画像でも枠に明るさの段差が生まれ、その偽の応答が
    最大になって ``signed01`` / ``_norm`` の正規化を支配し、内側の値まで背景の明るさで変わっていた
    (敵対的検証 2026-11-05 第 2 巡 P6)。余白は scipy の ``mode='reflect'``(= numpy の ``symmetric``)と同じ
    鏡映で ``ceil(4·sigma) + extra`` 画素(ガウスの打ち切り 4σ + 微分の核)。

    2-D でない入力はそのまま *fn* に渡す。*fn* が tuple / list を返すときは各成分を切り戻す。
    """
    x = np.asarray(x, np.float64)
    if x.ndim != 2 or x.size == 0:
        return fn(x)
    p = int(np.ceil(4.0 * float(sigma))) + int(extra)
    out = fn(np.pad(x, p, mode="symmetric"))
    crop = (slice(p, p + x.shape[0]), slice(p, p + x.shape[1]))
    if isinstance(out, (tuple, list)):
        return type(out)(np.asarray(o)[crop] for o in out)
    return np.asarray(out)[crop]


def signed01(x):
    """Map a SIGNED filter response to [0,1] with the zero-crossing at 0.5.

    Signed responses (Harris R, Laplacian-of-Gaussian, morphological Laplace,
    high/band-pass, phase) carry information in their sign. `_norm(x)=x/max|x|`
    yields [-1,1]; the pipeline's [0,1] clip then discards the entire negative
    half. This preserves it: 0 -> 0.5, ±max -> 0/1.
    """
    x = np.asarray(x, np.float64)
    m = float(np.max(np.abs(x))) if x.size else 0.0
    return np.clip(x / (2 * m) + 0.5, 0, 1) if m > 1e-8 else np.full_like(x, 0.5)


def subpixel_refine_edges(pts, mag, ny, nx):
    """Move edge points onto the gradient-magnitude ridge with sub-pixel accuracy.

    勾配の**法線方向**に 1 px 離れた 3 点 (p-n, p, p+n) の勾配強度に放物線を当て、
    その頂点まで点をずらす(古典的なサブピクセル・エッジ位置決め。Devernay 1995 /
    HALCON ``edges_sub_pix`` と同じ考え方)。オフセットは ±1 px に制限する
    (3 点補間の外挿は当てにならない)。

    引数はすべて (row, col) 規約: ``pts`` (N,2)、``mag`` 勾配強度画像、
    ``ny``/``nx`` 単位勾配ベクトルの行/列成分(``mag`` と同 shape)。

    ★``ops._edges_sub_pix`` と ``backends_auto._sh_xld(kind="edges_sub_pix")`` の
    **両方**がこれを使う。以前は 2 つが別々に「``np.where`` の整数座標をそのまま
    返す」実装を持っており(レジストリは同名の **後勝ち** なので実際に走るのは
    backends_auto 側)、``sub_pix`` を名乗りながら画素精度しか無かった。

    既知の限界(2026-10-02 実測、直していない): 3 点の放物線補間は、真の端が画素の中点(x.5)に在れば
    厳密だが、そこから外れると系統的に偏る(棚卸しの探針で最大およそ 0.11 px)。Devernay の補正や
    より広い窓のガウス当てはめで減らせる。
    """
    from scipy import ndimage as _nd

    pts = np.asarray(pts, np.float64)
    if pts.size == 0:
        return pts
    r, c = pts[:, 0], pts[:, 1]
    ri = np.clip(r.astype(int), 0, mag.shape[0] - 1)
    ci = np.clip(c.astype(int), 0, mag.shape[1] - 1)
    nyv, nxv = ny[ri, ci], nx[ri, ci]

    def _s(rr, cc):
        return _nd.map_coordinates(mag, [rr, cc], order=1, mode="nearest")

    m0, mm, mp = _s(r, c), _s(r - nyv, c - nxv), _s(r + nyv, c + nxv)
    den = mm - 2.0 * m0 + mp
    ok = np.abs(den) > 1e-12
    t = np.zeros_like(m0)
    t[ok] = 0.5 * (mm[ok] - mp[ok]) / den[ok]
    t = np.clip(np.nan_to_num(t), -1.0, 1.0)
    out = np.stack([r + t * nyv, c + t * nxv], 1)
    return np.where(np.isfinite(out), out, pts)


def gradient_normals(x):
    """Sobel gradient magnitude and the UNIT gradient (= edge normal), (mag, ny, nx)."""
    from scipy import ndimage as _nd

    x = np.asarray(x, np.float64)
    gy, gx = _nd.sobel(x, 0), _nd.sobel(x, 1)
    g = np.hypot(gx, gy)
    gs = np.where(g < 1e-12, 1e-12, g)
    return g, gy / gs, gx / gs


def _as_arr(v):
    return v if isinstance(v, np.ndarray) else None


def _clip01_finite(arr):
    """``np.clip(arr, 0, 1)`` の**非有限を残さない**版。

    ★`np.clip` は NaN を通す —— `np.clip(np.nan, 0, 1)` は `nan`。
    入力そのものが非有限のとき(空配列の 0/0、センサの欠測、NaN を弾いた op が
    投げた例外)、`fallback` は「入力を切り詰めたもの」を返すので、
    **非有限がそのまま外へ出ていた**。「返り値は有限」という `guard` の約束は
    そこだけ守られていなかった(2026-09-05、`require_finite` を入れて発覚)。
    `_finite` と同じ換算(NaN→0 / +Inf→1 / -Inf→0)で潰してから切り詰める。
    """
    a = np.asarray(arr)
    if a.dtype.kind in "fc":
        a = np.nan_to_num(a.real if a.dtype.kind == "c" else a,
                          nan=0.0, posinf=1.0, neginf=0.0)
    return np.clip(a, 0, 1)


def fallback(v, out_sort):
    """A valid, benign value of `out_sort`, derived from the input `v`."""
    vv = _as_arr(v)
    if out_sort == "feature":
        return np.float64(0.0)
    if out_sort == "contour":
        shape = tuple(vv.shape[:2]) if vv is not None and vv.ndim >= 2 else (1, 1)
        return {"shape": shape, "cs": []}
    if out_sort == "region":
        return np.zeros(vv.shape[:2], np.float64) if vv is not None and vv.ndim >= 2 else np.zeros((1, 1))
    if out_sort == "color":
        if vv is not None and vv.ndim == 3 and vv.shape[-1] == 3:
            return _clip01_finite(vv)
        if vv is not None and vv.ndim == 2:
            return _clip01_finite(np.stack([vv] * 3, -1))
        return np.zeros((1, 1, 3))
    if out_sort == "match":
        return np.array([0.0, 0.0, 0.0])
    # image / volume / any / unknown -> the clipped input if it is an array
    return _clip01_finite(vv) if vv is not None else v


def region01(out):
    """Coerce a `region` result to the declared {0,1} contract.

    ★`sanitize` guaranteed FINITENESS but never RANGE: on the success path a
    finite float region whose values fell outside {0,1} — or an int/bool one —
    was returned untouched, so the "sort-valid" half of its promise held only by
    convention.  Every current region producer `astype`s from a bool mask, so
    this is an identity for all of them; it closes the contract for any future
    producer (a label map, a soft mask) that is not already binary.

    Out-of-range values are binarised at 0.5, the same rule `api._coerce_input`
    applies on the INPUT side.  Non-array / non-numeric outputs are left alone:
    a region op returning those is a sort bug, not a range one.
    """
    if not isinstance(out, np.ndarray) or not out.size or out.dtype.kind not in "biufc":
        return out
    r = out.real if out.dtype.kind == "c" else out
    if out.dtype.kind == "f" and np.all((r == 0) | (r == 1)):
        return out                              # already {0,1} float -> unchanged
    return (r > 0.5).astype(np.float64)


#: 出力の NaN を**仕様として文書化している** op。``_note_nonfinite`` はこれらを記録しない。
#: ★2026-09-19 の門(tests/test_op_probe_ledger)が最初に捕まえたのがこれ: ``fly_tau_from_expansion`` は
#: 「膨張していない標本の time-to-contact は NaN(数を発明すると plausible-wrong)」と docstring に書き、
#: レジストリの ``tb_fly_tau_from_expansion`` はそれを signal の既定値で埋めて有限契約を守る。
#: 関数を直接呼べば NaN の意味が保たれる(flyvision の docstring 参照)。ここに足すときは、その op の
#: docstring に「NaN を返す理由」が書いてあることを確かめること。
NONFINITE_BY_DESIGN: frozenset = frozenset({"tb_fly_tau_from_expansion"})


def _keep_complex(out, v, out_sort, name):
    """複素の sort(cimage / beatcube)用の ``finish``: 虚部を残したまま、非有限だけは記録して 0 で埋める。

    ★2026-10-07: ``sanitize`` は実 sort 向けの規約で**実部だけ**を返すので、複素の op を通すと位相が
    黙って消えていた。素通しにすると今度は NaN / Inf がそのまま出る(全体スイートの非有限入力の門が
    捕まえた)。ここでは「記録し、黙らない」(``_note_nonfinite``)を守ったうえで、複素のまま返す。
    """
    if out is None:
        return fallback(v, out_sort)
    _note_nonfinite(out, v, out_sort, name)
    a = np.asarray(out)
    # ★2026-10-18(0.7.0 の preflight の退化スイープ): 複素の sort を名乗る op でも、入力が実数の NaN / Inf
    #   だと実数の配列を返すことがある(3 op とも float64 の NaN を返した)。複素の時だけ埋めていたので、
    #   その実数の非有限がそのまま外へ出ていた。実数でも複素数でも、非有限は記録したうえで 0 で埋める。
    if a.dtype.kind in "fc" and a.size and not np.isfinite(a).all():
        return np.where(np.isfinite(a), a, np.zeros((), a.dtype))
    return out


def _note_nonfinite(out, v, out_sort, name) -> None:
    """``sanitize`` が NaN/Inf を置き換える**前に**、その事実を台帳に残す(strict では例外)。

    ★2026-09-19(GenSpark #14): 中央 1 画素だけ NaN の画像を gaussian / median_image / mean_image /
    sobel_amp に通すと、出力は**全画素が有限**で、警告も台帳の記録も無かった。``_finite`` が
    非有限の画素を sort の既定値で埋めて返していたから —— 「有限で sort として妥当」の約束は
    守っていたが、**「記録し、黙らない」の約束を破っていた**(``on_error="raise"`` でも止まらない)。
    センサ欠損・0 除算・マスク由来の NaN が「正常な有限値」に化けるのは、検査では見逃しに直結する。
    ここでは値を変えず(置き換えは従来どおり ``sanitize``)、件数を数えて記録するだけ。
    """
    bad = None
    if isinstance(out, np.ndarray) and out.size and out.dtype.kind in "fc":
        real = out.real if out.dtype.kind == "c" else out
        finite = np.isfinite(real)
        if not finite.all():
            bad = (int(real.size - np.count_nonzero(finite)), int(real.size))
    elif isinstance(out, (float, int, np.floating, np.integer, np.complexfloating, complex)):
        if not np.isfinite(float(np.real(out))):
            bad = (1, 1)
    if bad is None or name in NONFINITE_BY_DESIGN:
        return
    vin = v if isinstance(v, np.ndarray) else None
    nin = 0
    if vin is not None and vin.dtype.kind in "fc" and vin.size:
        nin = int(vin.size - np.count_nonzero(np.isfinite(vin.real if vin.dtype.kind == "c" else vin)))
    err = ValueError(
        "non_finite_output: %d of %d values are NaN/Inf%s; they are replaced by the sort fallback — the "
        "contract is finite float64 in [0,1]. Mask or fill non-finite input first (np.isfinite / np.nan_to_num)"
        % (bad[0], bad[1], " (the input itself has %d non-finite values)" % nin if nin else ""))
    if is_strict():
        raise err
    record(name, err, out_sort, source="output")


def sanitize(out, v, out_sort=None):
    """Return a finite, sort-valid result.

    Finiteness is handled by `_finite`; for out_sort=="region" the result is
    additionally forced onto the {0,1} contract by `region01`.
    """
    out = _finite(out, v, out_sort)
    return region01(out) if out_sort == "region" else out


def _finite(out, v, out_sort=None):
    """Return a finite result of the declared sort.

    * out is None (op raised)                 -> sort fallback
    * out is a float/complex array w/ NaN/Inf -> keep finite pixels, patch the
      rest from the sort fallback (or nan_to_num when shapes differ)
    * complex output for a real sort          -> take the real part
    otherwise the op's own output is returned unchanged.
    """
    if out is None:
        return fallback(v, out_sort)
    if isinstance(out, np.ndarray) and out.size and out.dtype.kind in "fc":
        real = out.real if out.dtype.kind == "c" else out
        if np.all(np.isfinite(real)):
            return real if out.dtype.kind == "c" else out
        fb = fallback(v, out_sort)
        if isinstance(fb, np.ndarray) and fb.shape == real.shape:
            return np.where(np.isfinite(real), real, fb)
        return np.nan_to_num(real, nan=0.0, posinf=1.0, neginf=0.0)
    # ★A feature op returns a numpy SCALAR, not an ndarray, so the branch above
    # never saw it: a NaN/Inf measurement (e.g. a 0/0 inside sk_blur_effect on a
    # degenerate frame) used to flow straight out of api.apply.  Scrub non-finite
    # scalars to the sort fallback so the declared "finite, sort-valid" guarantee
    # actually holds for feature/contour scalars too.
    if isinstance(out, (float, int, np.floating, np.integer, np.complexfloating, complex)):
        if not np.isfinite(float(np.real(out))):
            return fallback(v, out_sort)
    return out
