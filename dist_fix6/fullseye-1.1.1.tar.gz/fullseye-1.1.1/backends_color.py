"""Multichannel (color) sort — HALCON color operators as a first-class sort.

Introduces `color` (H x W x 3 float64, RGB in [0,1]) into the typed pipeline so
the registry can host genuine HALCON color operators. The evolution reaches the
color sort through the bridge op `cfa_to_rgb` (image -> color, a real Bayer
demosaic); color -> image ops (rgb1_to_gray, access_channel, edges_color) bring
the sort back to gray. Grayscale tasks are unaffected: sorts are threaded, so a
gray-only op never receives a color array, and a color-ending pipeline is coerced
to a constant by `apply_genome` (poor fitness, no crash).

HALCON's Python binding types color ops with three separate R/G/B HObjects; the
multichannel-sort representation (one H x W x 3 array) is the faithful analog of
the same operation. Every op is a real cv2/numpy/skimage implementation; the
color functional gate (`verify()`) counts only those that run and return the
declared sort. Fake names are dropped fail-closed.

    py -3.11 backends_color.py         # self-report: ops, coverage, verify
"""
from __future__ import annotations

import json
import os

import numpy as np
from scipy import ndimage

try:
    import cv2
    _HAS_CV = True
except Exception:  # pragma: no cover
    _HAS_CV = False

HERE = os.path.dirname(os.path.abspath(__file__))
COLOR = "color"


def _to_color(v):
    """Coerce anything to H x W x 3 float64 in [0,1]."""
    v = np.asarray(v, np.float64)
    if v.ndim == 2:
        v = np.stack([v, v, v], -1)
    elif v.ndim == 3 and v.shape[-1] != 3:
        v = v[..., :3] if v.shape[-1] > 3 else np.repeat(v[..., :1], 3, -1)
    return np.clip(v, 0, 1)


def _gray(v):
    return np.clip(np.asarray(v, np.float64), 0, 1)


def _norm(x):
    x = np.asarray(x, np.float64)
    mx = float(np.max(np.abs(x)))
    return x / mx if mx > 1e-8 else x


def _safe(fn, out_sort=None):
    """Fail-soft wrapper -> the shared, RECORDING guard (backend_safe.guard).

    A failure degrades to a sort-valid fallback exactly as before, but the event
    is now written to the fallback ledger and strict mode re-raises, so a
    permanently broken op can no longer masquerade as a working identity.
    """
    from backend_safe import guard
    return guard(fn, out_sort)


# --------------------------------------------------------------------------- #
# color operator implementations                                              #
# --------------------------------------------------------------------------- #
def _cfa_to_rgb(v, a, b):                         # image -> color : Bayer demosaic (the bridge)
    """Bayer 配列（CFA: Color Filter Array）から RGB 画像へのデモザイク処理。HALCON の
    ``cfa_to_rgb``（単板カラーフィルタアレイ画像を RGB 画像に変換する）に近似。

    単一チャンネルのグレースケール画像を Bayer パターンの生データとみなし、
    OpenCV の ``cv2.cvtColor`` でデモザイクして 3 チャンネル RGB に復元する。
    `image` から `color` への橋渡し op（進化がカラー系統に入る唯一の入口）。

    a は Bayer パターンの並び順を 4 通り（BG/GB/RG/GR の並び）から選ぶ
    （``min(3, int(a * 4))`` で 0〜3 に量子化）。b は未使用。
    パターンが実際の入力と合わない場合、色ズレ・モアレが出る（本来の Bayer
    配置が分からない合成画像に対してはどれも「それらしい」RGB化でしかない）。
    """
    u = (_gray(v) * 255).astype(np.uint8)
    code = (cv2.COLOR_BayerBG2RGB, cv2.COLOR_BayerGB2RGB,
            cv2.COLOR_BayerRG2RGB, cv2.COLOR_BayerGR2RGB)[min(3, int(a * 4))]
    return cv2.cvtColor(u, code).astype(np.float64) / 255.0


def _trans_from_rgb(v, a, b):                     # color -> color : RGB -> {HSV,Lab,YUV,XYZ}
    """RGB 画像を別の色空間（HSV / Lab / YUV / XYZ）へ変換する。HALCON の
    ``trans_from_rgb``（RGB 色空間から任意の色空間への変換）に相当。

    内部は OpenCV の ``cv2.cvtColor`` を 8bit 経由で呼ぶだけで、変換先の
    色空間そのものの定義は OpenCV の実装に従う。

    a は変換先を 4 通り（HSV, Lab, YUV, XYZ の順）から選ぶ
    （``min(3, int(a * 4))``）。b は未使用。8bit 量子化を経由するため、
    逆変換（``trans_to_rgb``）と組み合わせても厳密には可逆でない。
    """
    c = (_to_color(v) * 255).astype(np.uint8)
    code, denom = ((cv2.COLOR_RGB2HSV, 255.0), (cv2.COLOR_RGB2Lab, 255.0),
                   (cv2.COLOR_RGB2YUV, 255.0), (cv2.COLOR_RGB2XYZ, 255.0))[min(3, int(a * 4))]
    return cv2.cvtColor(c, code).astype(np.float64) / denom


def _trans_to_rgb(v, a, b):                       # color -> color : HSV -> RGB (inverse transform)
    """色空間から RGB へ戻す逆変換。HALCON の ``trans_to_rgb``（任意の色空間から
    RGB 色空間への変換）に相当するとされるが、**実装は HSV→RGB の 1 方向だけ**
    しか持たない。

    ``trans_from_rgb`` は a で 4 色空間（HSV/Lab/YUV/XYZ）を選べるのに対し、
    この逆変換は常に入力を HSV とみなして ``cv2.COLOR_HSV2RGB`` を掛ける。
    Lab/YUV/XYZ から呼んだ場合は色空間の解釈を誤ったまま変換するため、
    出力は破綻した色になる。a, b は未使用。
    """
    c = (_to_color(v) * 255).astype(np.uint8)
    return cv2.cvtColor(c, cv2.COLOR_HSV2RGB).astype(np.float64) / 255.0


def _linear_trans_color(v, a, b):                 # color -> color : 3x3 channel mixing matrix
    """3x3 の混合行列でチャンネル間を線形変換する（アフィン色変換）。HALCON の
    ``linear_trans_color``（多チャンネル画像の色値のアフィン変換を計算する）
    に相当（本実装はオフセット項なしの純粋な線形変換）。

    対角成分 0.6 + 非対角 0.2 を基本形とし、a で位相 ``theta = pi * a`` を
    振って対角成分の一部を ``cos(theta)``/``sin(theta)`` で回転的に変化させた
    行列を作り、各行を合計 1 に正規化してから ``c @ M.T`` を掛ける。
    a が 0→1 で R/G 寄りの重みづけが周期的に入れ替わる。b は未使用。
    """
    c = _to_color(v)
    th = np.pi * a
    M = np.array([[0.6 + 0.4 * np.cos(th), 0.2, 0.2],
                  [0.2, 0.6 + 0.4 * np.sin(th), 0.2],
                  [0.2, 0.2, 0.6]], np.float64)
    M = M / M.sum(1, keepdims=True)
    return np.clip(c @ M.T, 0, 1)


def _principal_comp(v, a, b):                     # color -> color : PCA over the 3 channels
    """3 チャンネルの主成分分析（PCA）を行い、色空間を分散の大きい順に並べ替える。
    HALCON の ``principal_comp``（多チャンネル画像の主成分を計算する）に相当。

    画素を (H*W, 3) の行列とみなして平均を引き、共分散行列の固有値分解
    （``np.linalg.eigh``）で固有ベクトルを求め、固有値の降順に射影する。
    各成分は画像内で min-max により個別に [0,1] へ正規化するため、
    出力の明るさは元画像のスケールと無関係になる（正規化後は毎回フルレンジ）。
    a, b は未使用。
    """
    c = _to_color(v)
    H, W, _ = c.shape
    X = c.reshape(-1, 3)
    Xm = X - X.mean(0)
    cov = np.cov(Xm.T)
    w, vec = np.linalg.eigh(cov)
    order = np.argsort(w)[::-1]
    proj = Xm @ vec[:, order]
    proj = (proj - proj.min(0)) / (np.ptp(proj, axis=0) + 1e-8)
    return proj.reshape(H, W, 3)


def _rgb_to_gray(v, a, b):                        # color -> image : luminance
    """RGB 画像を輝度（グレースケール）に変換する。HALCON の ``rgb1_to_gray`` /
    ``rgb3_to_gray``（RGB 画像をグレースケール画像に変換する）の両方が、
    このひとつの実装に割り当てられている。

    ITU-R BT.601 系の重み ``0.299 R + 0.587 G + 0.114 B`` で輝度を計算する
    固定式。a, b は未使用。
    """
    c = _to_color(v)
    return c[..., 0] * 0.299 + c[..., 1] * 0.587 + c[..., 2] * 0.114


def _access_channel(v, a, b):                     # color -> image : pick one channel
    """多チャンネル画像から 1 チャンネルを取り出す。HALCON の ``access_channel``
    （多チャンネル画像の 1 チャンネルにアクセスする）に相当。

    a でチャンネル番号を 0(R)/1(G)/2(B) の 3 通りから選ぶ
    （``min(2, int(a * 3))``）。b は未使用。
    """
    return _to_color(v)[..., min(2, int(a * 3))]


def _edges_color(v, a, b):                        # color -> image : Di Zenzo color-gradient amplitude
    """カラーエッジの強度を検出する。HALCON の ``edges_color``（Canny/Deriche/Shen
    フィルタでカラーエッジを抽出する）に相当するとされるが、**実装はフィルタ
    選択式ではなく Di Zenzo のマルチチャンネル勾配法に固定**されている。

    各チャンネルに Sobel 勾配 (gx, gy) をかけ、勾配テンソル
    ``[[gxx, gxy], [gxy, gyy]]``（gxx=Σgx², gyy=Σgy², gxy=Σgx·gy）の最大
    固有値を画素ごとに求め、その平方根をエッジ強度として最大値で正規化する。
    a, b は未使用（HALCON 側にあるフィルタ種別・しきい値の選択はできない）。
    """
    c = _to_color(v)
    gx = np.stack([ndimage.sobel(c[..., k], 1) for k in range(3)], -1)
    gy = np.stack([ndimage.sobel(c[..., k], 0) for k in range(3)], -1)
    gxx = np.sum(gx * gx, -1)
    gyy = np.sum(gy * gy, -1)
    gxy = np.sum(gx * gy, -1)
    lam = 0.5 * (gxx + gyy + np.sqrt(np.maximum((gxx - gyy) ** 2 + 4 * gxy * gxy, 0)))
    return _norm(np.sqrt(np.maximum(lam, 0)))


def _edges_color_sub_pix(v, a, b):                # color -> contour
    """カラーエッジ上の連結成分を輪郭（contour）として取り出す。HALCON の
    ``edges_color_sub_pix``（Deriche/Shen/Canny でサブピクセル精度のカラー
    エッジを抽出する）に相当するとされるが、**実装はサブピクセル精度では
    ない**——``_edges_color`` の勾配強度をしきい値二値化し、8 連結の
    ラベリング（``scipy.ndimage.label``）でつないだ画素座標をそのまま
    輪郭点として返す（座標はすべて整数格子上）。3 画素未満の成分は捨てる。

    a はしきい値 ``0.15 + 0.5 * a`` を振る（大きいほど輪郭が減る）。b は
    未使用。戻り値は ``{"shape":..., "cs": [輪郭ごとの (N,2) 座標配列]}``。
    """
    amp = _edges_color(v, a, b)
    lab, n = ndimage.label(amp > (0.15 + 0.5 * a), structure=np.ones((3, 3)))
    cs = []
    for i in range(1, n + 1):
        ys, xs = np.where(lab == i)
        if len(ys) >= 3:
            cs.append(np.stack([ys, xs], 1).astype(np.float64))
    return {"shape": amp.shape, "cs": cs}


def _lines_color(v, a, b):                        # color -> contour : ridges on luminance
    """カラー画像の線（リッジ）を検出する。HALCON の ``lines_color``（カラーの
    線とその幅を検出する）に相当するとされるが、**線幅は推定しない**——輝度
    画像上のガウシアン・ラプラシアン応答をしきい値二値化して連結成分を
    輪郭として返すだけで、線幅（HALCON 側が返す値）に相当する出力は持たない。

    ``_rgb_to_gray`` で輝度化した後、``scipy.ndimage.gaussian_laplace`` を
    シグマ ``0.5 + 2.5 * a`` でかけて絶対値を最大値正規化し、
    ``0.2 + 0.4 * b`` でしきい値二値化して 8 連結ラベリングする。
    a はリッジの太さ（LoG のスケール）、b は検出しきい値を振る。
    3 画素未満の成分は捨てる。
    """
    g = _rgb_to_gray(v, a, b)
    r = _norm(np.abs(ndimage.gaussian_laplace(g, 0.5 + 2.5 * a)))
    lab, n = ndimage.label(r > (0.2 + 0.4 * b), structure=np.ones((3, 3)))
    cs = [np.stack(np.where(lab == i), 1).astype(np.float64) for i in range(1, n + 1)]
    return {"shape": g.shape, "cs": [c for c in cs if len(c) >= 3]}


def _count_channels(v, a, b):                     # color -> feature
    """画像のチャンネル数を数える。HALCON の ``count_channels``（画像のチャンネル
    数を数える）に相当。

    ``ndim == 3`` ならその最後の軸の長さ（チャンネル数）、そうでなければ
    （グレースケール扱いで）1 を返す。a, b は未使用。出力は `feature`
    （スカラー 1 個）。
    """
    c = np.asarray(v)
    return np.float64(c.shape[-1] if c.ndim == 3 else 1)


IMG = "image"
# (halcon, category, in_sort, out_sort, fn)
_DEFS = [
    ("cfa_to_rgb", "color", IMG, COLOR, _cfa_to_rgb),            # bridge image -> color
    ("trans_from_rgb", "color", COLOR, COLOR, _trans_from_rgb),
    ("trans_to_rgb", "color", COLOR, COLOR, _trans_to_rgb),
    ("linear_trans_color", "color", COLOR, COLOR, _linear_trans_color),
    ("principal_comp", "color", COLOR, COLOR, _principal_comp),
    ("rgb1_to_gray", "color", COLOR, IMG, _rgb_to_gray),
    ("rgb3_to_gray", "color", COLOR, IMG, _rgb_to_gray),
    ("access_channel", "color", COLOR, IMG, _access_channel),
    ("edges_color", "edges", COLOR, IMG, _edges_color),
    ("edges_color_sub_pix", "contour", COLOR, "contour", _edges_color_sub_pix),
    ("lines_color", "contour", COLOR, "contour", _lines_color),
    ("count_channels", "features", COLOR, "feature", _count_channels),
]


def _real_ops() -> set:
    """実在する HALCON 名。出荷される ``halcon_names_data`` を先に、checkout の JSON を次に読む。

    ★2026-09-19: JSON しか読んでおらず、wheel(data/ 無し)では空集合 → ``build`` の
    ``if real and n not in real`` が**全部通す no-op** になっていた(backends_auto が 0.1 系で潰した
    fail-open と同じ形)。名前の門は配布物側でも立っていなければならない。
    """
    try:
        from halcon_names_data import HALCON_NAMES
        if HALCON_NAMES:
            return set(HALCON_NAMES)
    except Exception:  # noqa: BLE001 - 生成物が無い checkout: JSON へ
        pass
    p = os.path.join(HERE, "data", "halcon_operators.json")
    if not os.path.exists(p):
        return set()
    return {o["name"] for o in json.load(open(p, encoding="utf-8"))["operators"]}


def build(Op, IMAGE, REGION, FEATURE, CONTOUR, norm, binm):
    """Return color Ops (fail-closed on fake names / missing cv2)."""
    if not _HAS_CV:
        build.dropped = ["(cv2 missing — color tier disabled)"]
        return []
    real = _real_ops()
    out, dropped = [], []
    for (n, cat, i, o, fn) in _DEFS:
        if real and n not in real:
            dropped.append(n)
            continue
        out.append(Op(n, cat, n, i, o, _safe(fn, o)))
    build.dropped = dropped
    return out


build.dropped = []


def coverage() -> dict:
    real = _real_ops()
    names = sorted({n for (n, *_ ) in _DEFS if (not real) or n in real}) if _HAS_CV else []
    return {"n_ops": len(names), "halcon_names": names, "has_cv2": _HAS_CV}


def verify() -> dict:
    """Color functional gate: run each op, check it returns the declared sort."""
    if not _HAS_CV:
        return {"n": 0, "pass": 0, "fail": ["cv2 missing"]}
    n = 48
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    gray = np.clip(xx / n + 0.1 * np.random.default_rng(0).random((n, n)), 0, 1)
    col = np.clip(np.stack([xx / n, yy / n, (xx + yy) / (2 * n)], -1)
                  + 0.05 * np.random.default_rng(1).random((n, n, 3)), 0, 1)
    passed, failed = [], []
    for (name, cat, i, o, fn) in _DEFS:
        base = gray if i == IMG else col
        try:
            out = fn(base.copy(), 0.5, 0.4)
            if o == COLOR:
                ok = isinstance(out, np.ndarray) and out.ndim == 3 and out.shape[-1] == 3
            elif o == IMG:
                ok = isinstance(out, np.ndarray) and out.ndim == 2
            elif o == "feature":
                ok = np.isfinite(float(np.asarray(out).reshape(-1)[0]))
            elif o == "contour":
                ok = isinstance(out, dict) and "cs" in out
            else:
                ok = False
            (passed if ok else failed).append(name)
        except Exception as e:  # noqa: BLE001
            failed.append("%s:%r" % (name, e))
    return {"n": len(_DEFS), "pass": len(passed), "fail": failed, "passing": passed}


if __name__ == "__main__":
    cov = coverage()
    v = verify()
    print("color sort tier: %d ops (cv2=%s, dropped %s)" % (cov["n_ops"], cov["has_cv2"], build.dropped))
    print("  functional gate: %d/%d pass" % (v["pass"], v["n"]))
    if v["fail"]:
        print("  FAIL:", v["fail"])
    print("  HALCON names:", ", ".join(cov["halcon_names"]))
